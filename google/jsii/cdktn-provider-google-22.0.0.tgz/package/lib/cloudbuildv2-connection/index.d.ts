/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface Cloudbuildv2ConnectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Allows clients to store small amounts of arbitrary data.
    *
    * **Note**: This field is non-authoritative, and will only manage the annotations present in your configuration.
    * Please refer to the field 'effective_annotations' for all of the annotations present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#annotations Cloudbuildv2Connection#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#deletion_policy Cloudbuildv2Connection#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * If disabled is set to true, functionality is disabled for this connection. Repository based API methods and webhooks processing for repositories in this connection will be disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#disabled Cloudbuildv2Connection#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#id Cloudbuildv2Connection#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location for the resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#location Cloudbuildv2Connection#location}
    */
    readonly location: string;
    /**
    * Immutable. The resource name of the connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#name Cloudbuildv2Connection#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#project Cloudbuildv2Connection#project}
    */
    readonly project?: string;
    /**
    * bitbucket_cloud_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#bitbucket_cloud_config Cloudbuildv2Connection#bitbucket_cloud_config}
    */
    readonly bitbucketCloudConfig?: Cloudbuildv2ConnectionBitbucketCloudConfig;
    /**
    * bitbucket_data_center_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#bitbucket_data_center_config Cloudbuildv2Connection#bitbucket_data_center_config}
    */
    readonly bitbucketDataCenterConfig?: Cloudbuildv2ConnectionBitbucketDataCenterConfig;
    /**
    * github_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#github_config Cloudbuildv2Connection#github_config}
    */
    readonly githubConfig?: Cloudbuildv2ConnectionGithubConfig;
    /**
    * github_enterprise_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#github_enterprise_config Cloudbuildv2Connection#github_enterprise_config}
    */
    readonly githubEnterpriseConfig?: Cloudbuildv2ConnectionGithubEnterpriseConfig;
    /**
    * gitlab_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#gitlab_config Cloudbuildv2Connection#gitlab_config}
    */
    readonly gitlabConfig?: Cloudbuildv2ConnectionGitlabConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#timeouts Cloudbuildv2Connection#timeouts}
    */
    readonly timeouts?: Cloudbuildv2ConnectionTimeouts;
}
export interface Cloudbuildv2ConnectionInstallationState {
}
export declare function cloudbuildv2ConnectionInstallationStateToTerraform(struct?: Cloudbuildv2ConnectionInstallationState): any;
export declare function cloudbuildv2ConnectionInstallationStateToHclTerraform(struct?: Cloudbuildv2ConnectionInstallationState): any;
export declare class Cloudbuildv2ConnectionInstallationStateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Cloudbuildv2ConnectionInstallationState | undefined;
    set internalValue(value: Cloudbuildv2ConnectionInstallationState | undefined);
    get actionUri(): string;
    get message(): string;
    get stage(): string;
}
export declare class Cloudbuildv2ConnectionInstallationStateList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Cloudbuildv2ConnectionInstallationStateOutputReference;
}
export interface Cloudbuildv2ConnectionBitbucketCloudConfigAuthorizerCredential {
    /**
    * Required. A SecretManager resource containing the user token that authorizes the Cloud Build connection. Format: 'projects/* /secrets/* /versions/*'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#user_token_secret_version Cloudbuildv2Connection#user_token_secret_version}
     *
    * Note: The above comment contained a comment block ending sequence (* followed by /). We have introduced a space between to prevent syntax errors. Please ignore the space.
    */
    readonly userTokenSecretVersion: string;
}
export declare function cloudbuildv2ConnectionBitbucketCloudConfigAuthorizerCredentialToTerraform(struct?: Cloudbuildv2ConnectionBitbucketCloudConfigAuthorizerCredentialOutputReference | Cloudbuildv2ConnectionBitbucketCloudConfigAuthorizerCredential): any;
export declare function cloudbuildv2ConnectionBitbucketCloudConfigAuthorizerCredentialToHclTerraform(struct?: Cloudbuildv2ConnectionBitbucketCloudConfigAuthorizerCredentialOutputReference | Cloudbuildv2ConnectionBitbucketCloudConfigAuthorizerCredential): any;
export declare class Cloudbuildv2ConnectionBitbucketCloudConfigAuthorizerCredentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Cloudbuildv2ConnectionBitbucketCloudConfigAuthorizerCredential | undefined;
    set internalValue(value: Cloudbuildv2ConnectionBitbucketCloudConfigAuthorizerCredential | undefined);
    private _userTokenSecretVersion?;
    get userTokenSecretVersion(): string;
    set userTokenSecretVersion(value: string);
    get userTokenSecretVersionInput(): string | undefined;
    get username(): string;
}
export interface Cloudbuildv2ConnectionBitbucketCloudConfigReadAuthorizerCredential {
    /**
    * Required. A SecretManager resource containing the user token that authorizes the Cloud Build connection. Format: 'projects/* /secrets/* /versions/*'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#user_token_secret_version Cloudbuildv2Connection#user_token_secret_version}
     *
    * Note: The above comment contained a comment block ending sequence (* followed by /). We have introduced a space between to prevent syntax errors. Please ignore the space.
    */
    readonly userTokenSecretVersion: string;
}
export declare function cloudbuildv2ConnectionBitbucketCloudConfigReadAuthorizerCredentialToTerraform(struct?: Cloudbuildv2ConnectionBitbucketCloudConfigReadAuthorizerCredentialOutputReference | Cloudbuildv2ConnectionBitbucketCloudConfigReadAuthorizerCredential): any;
export declare function cloudbuildv2ConnectionBitbucketCloudConfigReadAuthorizerCredentialToHclTerraform(struct?: Cloudbuildv2ConnectionBitbucketCloudConfigReadAuthorizerCredentialOutputReference | Cloudbuildv2ConnectionBitbucketCloudConfigReadAuthorizerCredential): any;
export declare class Cloudbuildv2ConnectionBitbucketCloudConfigReadAuthorizerCredentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Cloudbuildv2ConnectionBitbucketCloudConfigReadAuthorizerCredential | undefined;
    set internalValue(value: Cloudbuildv2ConnectionBitbucketCloudConfigReadAuthorizerCredential | undefined);
    private _userTokenSecretVersion?;
    get userTokenSecretVersion(): string;
    set userTokenSecretVersion(value: string);
    get userTokenSecretVersionInput(): string | undefined;
    get username(): string;
}
export interface Cloudbuildv2ConnectionBitbucketCloudConfig {
    /**
    * Required. Immutable. SecretManager resource containing the webhook secret used to verify webhook events, formatted as 'projects/* /secrets/* /versions/*'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#webhook_secret_secret_version Cloudbuildv2Connection#webhook_secret_secret_version}
     *
    * Note: The above comment contained a comment block ending sequence (* followed by /). We have introduced a space between to prevent syntax errors. Please ignore the space.
    */
    readonly webhookSecretSecretVersion: string;
    /**
    * The Bitbucket Cloud Workspace ID to be connected to Google Cloud Platform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#workspace Cloudbuildv2Connection#workspace}
    */
    readonly workspace: string;
    /**
    * authorizer_credential block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#authorizer_credential Cloudbuildv2Connection#authorizer_credential}
    */
    readonly authorizerCredential: Cloudbuildv2ConnectionBitbucketCloudConfigAuthorizerCredential;
    /**
    * read_authorizer_credential block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#read_authorizer_credential Cloudbuildv2Connection#read_authorizer_credential}
    */
    readonly readAuthorizerCredential: Cloudbuildv2ConnectionBitbucketCloudConfigReadAuthorizerCredential;
}
export declare function cloudbuildv2ConnectionBitbucketCloudConfigToTerraform(struct?: Cloudbuildv2ConnectionBitbucketCloudConfigOutputReference | Cloudbuildv2ConnectionBitbucketCloudConfig): any;
export declare function cloudbuildv2ConnectionBitbucketCloudConfigToHclTerraform(struct?: Cloudbuildv2ConnectionBitbucketCloudConfigOutputReference | Cloudbuildv2ConnectionBitbucketCloudConfig): any;
export declare class Cloudbuildv2ConnectionBitbucketCloudConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Cloudbuildv2ConnectionBitbucketCloudConfig | undefined;
    set internalValue(value: Cloudbuildv2ConnectionBitbucketCloudConfig | undefined);
    private _webhookSecretSecretVersion?;
    get webhookSecretSecretVersion(): string;
    set webhookSecretSecretVersion(value: string);
    get webhookSecretSecretVersionInput(): string | undefined;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    get workspaceInput(): string | undefined;
    private _authorizerCredential;
    get authorizerCredential(): Cloudbuildv2ConnectionBitbucketCloudConfigAuthorizerCredentialOutputReference;
    putAuthorizerCredential(value: Cloudbuildv2ConnectionBitbucketCloudConfigAuthorizerCredential): void;
    get authorizerCredentialInput(): Cloudbuildv2ConnectionBitbucketCloudConfigAuthorizerCredential | undefined;
    private _readAuthorizerCredential;
    get readAuthorizerCredential(): Cloudbuildv2ConnectionBitbucketCloudConfigReadAuthorizerCredentialOutputReference;
    putReadAuthorizerCredential(value: Cloudbuildv2ConnectionBitbucketCloudConfigReadAuthorizerCredential): void;
    get readAuthorizerCredentialInput(): Cloudbuildv2ConnectionBitbucketCloudConfigReadAuthorizerCredential | undefined;
}
export interface Cloudbuildv2ConnectionBitbucketDataCenterConfigAuthorizerCredential {
    /**
    * Required. A SecretManager resource containing the user token that authorizes the Cloud Build connection. Format: 'projects/* /secrets/* /versions/*'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#user_token_secret_version Cloudbuildv2Connection#user_token_secret_version}
     *
    * Note: The above comment contained a comment block ending sequence (* followed by /). We have introduced a space between to prevent syntax errors. Please ignore the space.
    */
    readonly userTokenSecretVersion: string;
}
export declare function cloudbuildv2ConnectionBitbucketDataCenterConfigAuthorizerCredentialToTerraform(struct?: Cloudbuildv2ConnectionBitbucketDataCenterConfigAuthorizerCredentialOutputReference | Cloudbuildv2ConnectionBitbucketDataCenterConfigAuthorizerCredential): any;
export declare function cloudbuildv2ConnectionBitbucketDataCenterConfigAuthorizerCredentialToHclTerraform(struct?: Cloudbuildv2ConnectionBitbucketDataCenterConfigAuthorizerCredentialOutputReference | Cloudbuildv2ConnectionBitbucketDataCenterConfigAuthorizerCredential): any;
export declare class Cloudbuildv2ConnectionBitbucketDataCenterConfigAuthorizerCredentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Cloudbuildv2ConnectionBitbucketDataCenterConfigAuthorizerCredential | undefined;
    set internalValue(value: Cloudbuildv2ConnectionBitbucketDataCenterConfigAuthorizerCredential | undefined);
    private _userTokenSecretVersion?;
    get userTokenSecretVersion(): string;
    set userTokenSecretVersion(value: string);
    get userTokenSecretVersionInput(): string | undefined;
    get username(): string;
}
export interface Cloudbuildv2ConnectionBitbucketDataCenterConfigReadAuthorizerCredential {
    /**
    * Required. A SecretManager resource containing the user token that authorizes the Cloud Build connection. Format: 'projects/* /secrets/* /versions/*'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#user_token_secret_version Cloudbuildv2Connection#user_token_secret_version}
     *
    * Note: The above comment contained a comment block ending sequence (* followed by /). We have introduced a space between to prevent syntax errors. Please ignore the space.
    */
    readonly userTokenSecretVersion: string;
}
export declare function cloudbuildv2ConnectionBitbucketDataCenterConfigReadAuthorizerCredentialToTerraform(struct?: Cloudbuildv2ConnectionBitbucketDataCenterConfigReadAuthorizerCredentialOutputReference | Cloudbuildv2ConnectionBitbucketDataCenterConfigReadAuthorizerCredential): any;
export declare function cloudbuildv2ConnectionBitbucketDataCenterConfigReadAuthorizerCredentialToHclTerraform(struct?: Cloudbuildv2ConnectionBitbucketDataCenterConfigReadAuthorizerCredentialOutputReference | Cloudbuildv2ConnectionBitbucketDataCenterConfigReadAuthorizerCredential): any;
export declare class Cloudbuildv2ConnectionBitbucketDataCenterConfigReadAuthorizerCredentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Cloudbuildv2ConnectionBitbucketDataCenterConfigReadAuthorizerCredential | undefined;
    set internalValue(value: Cloudbuildv2ConnectionBitbucketDataCenterConfigReadAuthorizerCredential | undefined);
    private _userTokenSecretVersion?;
    get userTokenSecretVersion(): string;
    set userTokenSecretVersion(value: string);
    get userTokenSecretVersionInput(): string | undefined;
    get username(): string;
}
export interface Cloudbuildv2ConnectionBitbucketDataCenterConfigServiceDirectoryConfig {
    /**
    * Required. The Service Directory service name. Format: projects/{project}/locations/{location}/namespaces/{namespace}/services/{service}.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#service Cloudbuildv2Connection#service}
    */
    readonly service: string;
}
export declare function cloudbuildv2ConnectionBitbucketDataCenterConfigServiceDirectoryConfigToTerraform(struct?: Cloudbuildv2ConnectionBitbucketDataCenterConfigServiceDirectoryConfigOutputReference | Cloudbuildv2ConnectionBitbucketDataCenterConfigServiceDirectoryConfig): any;
export declare function cloudbuildv2ConnectionBitbucketDataCenterConfigServiceDirectoryConfigToHclTerraform(struct?: Cloudbuildv2ConnectionBitbucketDataCenterConfigServiceDirectoryConfigOutputReference | Cloudbuildv2ConnectionBitbucketDataCenterConfigServiceDirectoryConfig): any;
export declare class Cloudbuildv2ConnectionBitbucketDataCenterConfigServiceDirectoryConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Cloudbuildv2ConnectionBitbucketDataCenterConfigServiceDirectoryConfig | undefined;
    set internalValue(value: Cloudbuildv2ConnectionBitbucketDataCenterConfigServiceDirectoryConfig | undefined);
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
}
export interface Cloudbuildv2ConnectionBitbucketDataCenterConfig {
    /**
    * The URI of the Bitbucket Data Center host this connection is for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#host_uri Cloudbuildv2Connection#host_uri}
    */
    readonly hostUri: string;
    /**
    * SSL certificate to use for requests to the Bitbucket Data Center.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#ssl_ca Cloudbuildv2Connection#ssl_ca}
    */
    readonly sslCa?: string;
    /**
    * Required. Immutable. SecretManager resource containing the webhook secret used to verify webhook events, formatted as 'projects/* /secrets/* /versions/*'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#webhook_secret_secret_version Cloudbuildv2Connection#webhook_secret_secret_version}
     *
    * Note: The above comment contained a comment block ending sequence (* followed by /). We have introduced a space between to prevent syntax errors. Please ignore the space.
    */
    readonly webhookSecretSecretVersion: string;
    /**
    * authorizer_credential block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#authorizer_credential Cloudbuildv2Connection#authorizer_credential}
    */
    readonly authorizerCredential: Cloudbuildv2ConnectionBitbucketDataCenterConfigAuthorizerCredential;
    /**
    * read_authorizer_credential block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#read_authorizer_credential Cloudbuildv2Connection#read_authorizer_credential}
    */
    readonly readAuthorizerCredential: Cloudbuildv2ConnectionBitbucketDataCenterConfigReadAuthorizerCredential;
    /**
    * service_directory_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#service_directory_config Cloudbuildv2Connection#service_directory_config}
    */
    readonly serviceDirectoryConfig?: Cloudbuildv2ConnectionBitbucketDataCenterConfigServiceDirectoryConfig;
}
export declare function cloudbuildv2ConnectionBitbucketDataCenterConfigToTerraform(struct?: Cloudbuildv2ConnectionBitbucketDataCenterConfigOutputReference | Cloudbuildv2ConnectionBitbucketDataCenterConfig): any;
export declare function cloudbuildv2ConnectionBitbucketDataCenterConfigToHclTerraform(struct?: Cloudbuildv2ConnectionBitbucketDataCenterConfigOutputReference | Cloudbuildv2ConnectionBitbucketDataCenterConfig): any;
export declare class Cloudbuildv2ConnectionBitbucketDataCenterConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Cloudbuildv2ConnectionBitbucketDataCenterConfig | undefined;
    set internalValue(value: Cloudbuildv2ConnectionBitbucketDataCenterConfig | undefined);
    private _hostUri?;
    get hostUri(): string;
    set hostUri(value: string);
    get hostUriInput(): string | undefined;
    get serverVersion(): string;
    private _sslCa?;
    get sslCa(): string;
    set sslCa(value: string);
    resetSslCa(): void;
    get sslCaInput(): string | undefined;
    private _webhookSecretSecretVersion?;
    get webhookSecretSecretVersion(): string;
    set webhookSecretSecretVersion(value: string);
    get webhookSecretSecretVersionInput(): string | undefined;
    private _authorizerCredential;
    get authorizerCredential(): Cloudbuildv2ConnectionBitbucketDataCenterConfigAuthorizerCredentialOutputReference;
    putAuthorizerCredential(value: Cloudbuildv2ConnectionBitbucketDataCenterConfigAuthorizerCredential): void;
    get authorizerCredentialInput(): Cloudbuildv2ConnectionBitbucketDataCenterConfigAuthorizerCredential | undefined;
    private _readAuthorizerCredential;
    get readAuthorizerCredential(): Cloudbuildv2ConnectionBitbucketDataCenterConfigReadAuthorizerCredentialOutputReference;
    putReadAuthorizerCredential(value: Cloudbuildv2ConnectionBitbucketDataCenterConfigReadAuthorizerCredential): void;
    get readAuthorizerCredentialInput(): Cloudbuildv2ConnectionBitbucketDataCenterConfigReadAuthorizerCredential | undefined;
    private _serviceDirectoryConfig;
    get serviceDirectoryConfig(): Cloudbuildv2ConnectionBitbucketDataCenterConfigServiceDirectoryConfigOutputReference;
    putServiceDirectoryConfig(value: Cloudbuildv2ConnectionBitbucketDataCenterConfigServiceDirectoryConfig): void;
    resetServiceDirectoryConfig(): void;
    get serviceDirectoryConfigInput(): Cloudbuildv2ConnectionBitbucketDataCenterConfigServiceDirectoryConfig | undefined;
}
export interface Cloudbuildv2ConnectionGithubConfigAuthorizerCredential {
    /**
    * A SecretManager resource containing the OAuth token that authorizes the Cloud Build connection. Format: 'projects/* /secrets/* /versions/*'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#oauth_token_secret_version Cloudbuildv2Connection#oauth_token_secret_version}
     *
    * Note: The above comment contained a comment block ending sequence (* followed by /). We have introduced a space between to prevent syntax errors. Please ignore the space.
    */
    readonly oauthTokenSecretVersion?: string;
}
export declare function cloudbuildv2ConnectionGithubConfigAuthorizerCredentialToTerraform(struct?: Cloudbuildv2ConnectionGithubConfigAuthorizerCredentialOutputReference | Cloudbuildv2ConnectionGithubConfigAuthorizerCredential): any;
export declare function cloudbuildv2ConnectionGithubConfigAuthorizerCredentialToHclTerraform(struct?: Cloudbuildv2ConnectionGithubConfigAuthorizerCredentialOutputReference | Cloudbuildv2ConnectionGithubConfigAuthorizerCredential): any;
export declare class Cloudbuildv2ConnectionGithubConfigAuthorizerCredentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Cloudbuildv2ConnectionGithubConfigAuthorizerCredential | undefined;
    set internalValue(value: Cloudbuildv2ConnectionGithubConfigAuthorizerCredential | undefined);
    private _oauthTokenSecretVersion?;
    get oauthTokenSecretVersion(): string;
    set oauthTokenSecretVersion(value: string);
    resetOauthTokenSecretVersion(): void;
    get oauthTokenSecretVersionInput(): string | undefined;
    get username(): string;
}
export interface Cloudbuildv2ConnectionGithubConfig {
    /**
    * GitHub App installation id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#app_installation_id Cloudbuildv2Connection#app_installation_id}
    */
    readonly appInstallationId?: number;
    /**
    * authorizer_credential block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#authorizer_credential Cloudbuildv2Connection#authorizer_credential}
    */
    readonly authorizerCredential?: Cloudbuildv2ConnectionGithubConfigAuthorizerCredential;
}
export declare function cloudbuildv2ConnectionGithubConfigToTerraform(struct?: Cloudbuildv2ConnectionGithubConfigOutputReference | Cloudbuildv2ConnectionGithubConfig): any;
export declare function cloudbuildv2ConnectionGithubConfigToHclTerraform(struct?: Cloudbuildv2ConnectionGithubConfigOutputReference | Cloudbuildv2ConnectionGithubConfig): any;
export declare class Cloudbuildv2ConnectionGithubConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Cloudbuildv2ConnectionGithubConfig | undefined;
    set internalValue(value: Cloudbuildv2ConnectionGithubConfig | undefined);
    private _appInstallationId?;
    get appInstallationId(): number;
    set appInstallationId(value: number);
    resetAppInstallationId(): void;
    get appInstallationIdInput(): number | undefined;
    private _authorizerCredential;
    get authorizerCredential(): Cloudbuildv2ConnectionGithubConfigAuthorizerCredentialOutputReference;
    putAuthorizerCredential(value: Cloudbuildv2ConnectionGithubConfigAuthorizerCredential): void;
    resetAuthorizerCredential(): void;
    get authorizerCredentialInput(): Cloudbuildv2ConnectionGithubConfigAuthorizerCredential | undefined;
}
export interface Cloudbuildv2ConnectionGithubEnterpriseConfigServiceDirectoryConfig {
    /**
    * Required. The Service Directory service name. Format: projects/{project}/locations/{location}/namespaces/{namespace}/services/{service}.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#service Cloudbuildv2Connection#service}
    */
    readonly service: string;
}
export declare function cloudbuildv2ConnectionGithubEnterpriseConfigServiceDirectoryConfigToTerraform(struct?: Cloudbuildv2ConnectionGithubEnterpriseConfigServiceDirectoryConfigOutputReference | Cloudbuildv2ConnectionGithubEnterpriseConfigServiceDirectoryConfig): any;
export declare function cloudbuildv2ConnectionGithubEnterpriseConfigServiceDirectoryConfigToHclTerraform(struct?: Cloudbuildv2ConnectionGithubEnterpriseConfigServiceDirectoryConfigOutputReference | Cloudbuildv2ConnectionGithubEnterpriseConfigServiceDirectoryConfig): any;
export declare class Cloudbuildv2ConnectionGithubEnterpriseConfigServiceDirectoryConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Cloudbuildv2ConnectionGithubEnterpriseConfigServiceDirectoryConfig | undefined;
    set internalValue(value: Cloudbuildv2ConnectionGithubEnterpriseConfigServiceDirectoryConfig | undefined);
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
}
export interface Cloudbuildv2ConnectionGithubEnterpriseConfig {
    /**
    * Id of the GitHub App created from the manifest.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#app_id Cloudbuildv2Connection#app_id}
    */
    readonly appId?: number;
    /**
    * ID of the installation of the GitHub App.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#app_installation_id Cloudbuildv2Connection#app_installation_id}
    */
    readonly appInstallationId?: number;
    /**
    * The URL-friendly name of the GitHub App.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#app_slug Cloudbuildv2Connection#app_slug}
    */
    readonly appSlug?: string;
    /**
    * Required. The URI of the GitHub Enterprise host this connection is for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#host_uri Cloudbuildv2Connection#host_uri}
    */
    readonly hostUri: string;
    /**
    * SecretManager resource containing the private key of the GitHub App, formatted as 'projects/* /secrets/* /versions/*'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#private_key_secret_version Cloudbuildv2Connection#private_key_secret_version}
     *
    * Note: The above comment contained a comment block ending sequence (* followed by /). We have introduced a space between to prevent syntax errors. Please ignore the space.
    */
    readonly privateKeySecretVersion?: string;
    /**
    * SSL certificate to use for requests to GitHub Enterprise.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#ssl_ca Cloudbuildv2Connection#ssl_ca}
    */
    readonly sslCa?: string;
    /**
    * SecretManager resource containing the webhook secret of the GitHub App, formatted as 'projects/* /secrets/* /versions/*'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#webhook_secret_secret_version Cloudbuildv2Connection#webhook_secret_secret_version}
     *
    * Note: The above comment contained a comment block ending sequence (* followed by /). We have introduced a space between to prevent syntax errors. Please ignore the space.
    */
    readonly webhookSecretSecretVersion?: string;
    /**
    * service_directory_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#service_directory_config Cloudbuildv2Connection#service_directory_config}
    */
    readonly serviceDirectoryConfig?: Cloudbuildv2ConnectionGithubEnterpriseConfigServiceDirectoryConfig;
}
export declare function cloudbuildv2ConnectionGithubEnterpriseConfigToTerraform(struct?: Cloudbuildv2ConnectionGithubEnterpriseConfigOutputReference | Cloudbuildv2ConnectionGithubEnterpriseConfig): any;
export declare function cloudbuildv2ConnectionGithubEnterpriseConfigToHclTerraform(struct?: Cloudbuildv2ConnectionGithubEnterpriseConfigOutputReference | Cloudbuildv2ConnectionGithubEnterpriseConfig): any;
export declare class Cloudbuildv2ConnectionGithubEnterpriseConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Cloudbuildv2ConnectionGithubEnterpriseConfig | undefined;
    set internalValue(value: Cloudbuildv2ConnectionGithubEnterpriseConfig | undefined);
    private _appId?;
    get appId(): number;
    set appId(value: number);
    resetAppId(): void;
    get appIdInput(): number | undefined;
    private _appInstallationId?;
    get appInstallationId(): number;
    set appInstallationId(value: number);
    resetAppInstallationId(): void;
    get appInstallationIdInput(): number | undefined;
    private _appSlug?;
    get appSlug(): string;
    set appSlug(value: string);
    resetAppSlug(): void;
    get appSlugInput(): string | undefined;
    private _hostUri?;
    get hostUri(): string;
    set hostUri(value: string);
    get hostUriInput(): string | undefined;
    private _privateKeySecretVersion?;
    get privateKeySecretVersion(): string;
    set privateKeySecretVersion(value: string);
    resetPrivateKeySecretVersion(): void;
    get privateKeySecretVersionInput(): string | undefined;
    private _sslCa?;
    get sslCa(): string;
    set sslCa(value: string);
    resetSslCa(): void;
    get sslCaInput(): string | undefined;
    private _webhookSecretSecretVersion?;
    get webhookSecretSecretVersion(): string;
    set webhookSecretSecretVersion(value: string);
    resetWebhookSecretSecretVersion(): void;
    get webhookSecretSecretVersionInput(): string | undefined;
    private _serviceDirectoryConfig;
    get serviceDirectoryConfig(): Cloudbuildv2ConnectionGithubEnterpriseConfigServiceDirectoryConfigOutputReference;
    putServiceDirectoryConfig(value: Cloudbuildv2ConnectionGithubEnterpriseConfigServiceDirectoryConfig): void;
    resetServiceDirectoryConfig(): void;
    get serviceDirectoryConfigInput(): Cloudbuildv2ConnectionGithubEnterpriseConfigServiceDirectoryConfig | undefined;
}
export interface Cloudbuildv2ConnectionGitlabConfigAuthorizerCredential {
    /**
    * Required. A SecretManager resource containing the user token that authorizes the Cloud Build connection. Format: 'projects/* /secrets/* /versions/*'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#user_token_secret_version Cloudbuildv2Connection#user_token_secret_version}
     *
    * Note: The above comment contained a comment block ending sequence (* followed by /). We have introduced a space between to prevent syntax errors. Please ignore the space.
    */
    readonly userTokenSecretVersion: string;
}
export declare function cloudbuildv2ConnectionGitlabConfigAuthorizerCredentialToTerraform(struct?: Cloudbuildv2ConnectionGitlabConfigAuthorizerCredentialOutputReference | Cloudbuildv2ConnectionGitlabConfigAuthorizerCredential): any;
export declare function cloudbuildv2ConnectionGitlabConfigAuthorizerCredentialToHclTerraform(struct?: Cloudbuildv2ConnectionGitlabConfigAuthorizerCredentialOutputReference | Cloudbuildv2ConnectionGitlabConfigAuthorizerCredential): any;
export declare class Cloudbuildv2ConnectionGitlabConfigAuthorizerCredentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Cloudbuildv2ConnectionGitlabConfigAuthorizerCredential | undefined;
    set internalValue(value: Cloudbuildv2ConnectionGitlabConfigAuthorizerCredential | undefined);
    private _userTokenSecretVersion?;
    get userTokenSecretVersion(): string;
    set userTokenSecretVersion(value: string);
    get userTokenSecretVersionInput(): string | undefined;
    get username(): string;
}
export interface Cloudbuildv2ConnectionGitlabConfigReadAuthorizerCredential {
    /**
    * Required. A SecretManager resource containing the user token that authorizes the Cloud Build connection. Format: 'projects/* /secrets/* /versions/*'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#user_token_secret_version Cloudbuildv2Connection#user_token_secret_version}
     *
    * Note: The above comment contained a comment block ending sequence (* followed by /). We have introduced a space between to prevent syntax errors. Please ignore the space.
    */
    readonly userTokenSecretVersion: string;
}
export declare function cloudbuildv2ConnectionGitlabConfigReadAuthorizerCredentialToTerraform(struct?: Cloudbuildv2ConnectionGitlabConfigReadAuthorizerCredentialOutputReference | Cloudbuildv2ConnectionGitlabConfigReadAuthorizerCredential): any;
export declare function cloudbuildv2ConnectionGitlabConfigReadAuthorizerCredentialToHclTerraform(struct?: Cloudbuildv2ConnectionGitlabConfigReadAuthorizerCredentialOutputReference | Cloudbuildv2ConnectionGitlabConfigReadAuthorizerCredential): any;
export declare class Cloudbuildv2ConnectionGitlabConfigReadAuthorizerCredentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Cloudbuildv2ConnectionGitlabConfigReadAuthorizerCredential | undefined;
    set internalValue(value: Cloudbuildv2ConnectionGitlabConfigReadAuthorizerCredential | undefined);
    private _userTokenSecretVersion?;
    get userTokenSecretVersion(): string;
    set userTokenSecretVersion(value: string);
    get userTokenSecretVersionInput(): string | undefined;
    get username(): string;
}
export interface Cloudbuildv2ConnectionGitlabConfigServiceDirectoryConfig {
    /**
    * Required. The Service Directory service name. Format: projects/{project}/locations/{location}/namespaces/{namespace}/services/{service}.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#service Cloudbuildv2Connection#service}
    */
    readonly service: string;
}
export declare function cloudbuildv2ConnectionGitlabConfigServiceDirectoryConfigToTerraform(struct?: Cloudbuildv2ConnectionGitlabConfigServiceDirectoryConfigOutputReference | Cloudbuildv2ConnectionGitlabConfigServiceDirectoryConfig): any;
export declare function cloudbuildv2ConnectionGitlabConfigServiceDirectoryConfigToHclTerraform(struct?: Cloudbuildv2ConnectionGitlabConfigServiceDirectoryConfigOutputReference | Cloudbuildv2ConnectionGitlabConfigServiceDirectoryConfig): any;
export declare class Cloudbuildv2ConnectionGitlabConfigServiceDirectoryConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Cloudbuildv2ConnectionGitlabConfigServiceDirectoryConfig | undefined;
    set internalValue(value: Cloudbuildv2ConnectionGitlabConfigServiceDirectoryConfig | undefined);
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
}
export interface Cloudbuildv2ConnectionGitlabConfig {
    /**
    * The URI of the GitLab Enterprise host this connection is for. If not specified, the default value is https://gitlab.com.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#host_uri Cloudbuildv2Connection#host_uri}
    */
    readonly hostUri?: string;
    /**
    * SSL certificate to use for requests to GitLab Enterprise.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#ssl_ca Cloudbuildv2Connection#ssl_ca}
    */
    readonly sslCa?: string;
    /**
    * Required. Immutable. SecretManager resource containing the webhook secret of a GitLab Enterprise project, formatted as 'projects/* /secrets/* /versions/*'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#webhook_secret_secret_version Cloudbuildv2Connection#webhook_secret_secret_version}
     *
    * Note: The above comment contained a comment block ending sequence (* followed by /). We have introduced a space between to prevent syntax errors. Please ignore the space.
    */
    readonly webhookSecretSecretVersion: string;
    /**
    * authorizer_credential block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#authorizer_credential Cloudbuildv2Connection#authorizer_credential}
    */
    readonly authorizerCredential: Cloudbuildv2ConnectionGitlabConfigAuthorizerCredential;
    /**
    * read_authorizer_credential block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#read_authorizer_credential Cloudbuildv2Connection#read_authorizer_credential}
    */
    readonly readAuthorizerCredential: Cloudbuildv2ConnectionGitlabConfigReadAuthorizerCredential;
    /**
    * service_directory_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#service_directory_config Cloudbuildv2Connection#service_directory_config}
    */
    readonly serviceDirectoryConfig?: Cloudbuildv2ConnectionGitlabConfigServiceDirectoryConfig;
}
export declare function cloudbuildv2ConnectionGitlabConfigToTerraform(struct?: Cloudbuildv2ConnectionGitlabConfigOutputReference | Cloudbuildv2ConnectionGitlabConfig): any;
export declare function cloudbuildv2ConnectionGitlabConfigToHclTerraform(struct?: Cloudbuildv2ConnectionGitlabConfigOutputReference | Cloudbuildv2ConnectionGitlabConfig): any;
export declare class Cloudbuildv2ConnectionGitlabConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Cloudbuildv2ConnectionGitlabConfig | undefined;
    set internalValue(value: Cloudbuildv2ConnectionGitlabConfig | undefined);
    private _hostUri?;
    get hostUri(): string;
    set hostUri(value: string);
    resetHostUri(): void;
    get hostUriInput(): string | undefined;
    get serverVersion(): string;
    private _sslCa?;
    get sslCa(): string;
    set sslCa(value: string);
    resetSslCa(): void;
    get sslCaInput(): string | undefined;
    private _webhookSecretSecretVersion?;
    get webhookSecretSecretVersion(): string;
    set webhookSecretSecretVersion(value: string);
    get webhookSecretSecretVersionInput(): string | undefined;
    private _authorizerCredential;
    get authorizerCredential(): Cloudbuildv2ConnectionGitlabConfigAuthorizerCredentialOutputReference;
    putAuthorizerCredential(value: Cloudbuildv2ConnectionGitlabConfigAuthorizerCredential): void;
    get authorizerCredentialInput(): Cloudbuildv2ConnectionGitlabConfigAuthorizerCredential | undefined;
    private _readAuthorizerCredential;
    get readAuthorizerCredential(): Cloudbuildv2ConnectionGitlabConfigReadAuthorizerCredentialOutputReference;
    putReadAuthorizerCredential(value: Cloudbuildv2ConnectionGitlabConfigReadAuthorizerCredential): void;
    get readAuthorizerCredentialInput(): Cloudbuildv2ConnectionGitlabConfigReadAuthorizerCredential | undefined;
    private _serviceDirectoryConfig;
    get serviceDirectoryConfig(): Cloudbuildv2ConnectionGitlabConfigServiceDirectoryConfigOutputReference;
    putServiceDirectoryConfig(value: Cloudbuildv2ConnectionGitlabConfigServiceDirectoryConfig): void;
    resetServiceDirectoryConfig(): void;
    get serviceDirectoryConfigInput(): Cloudbuildv2ConnectionGitlabConfigServiceDirectoryConfig | undefined;
}
export interface Cloudbuildv2ConnectionTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#create Cloudbuildv2Connection#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#delete Cloudbuildv2Connection#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#update Cloudbuildv2Connection#update}
    */
    readonly update?: string;
}
export declare function cloudbuildv2ConnectionTimeoutsToTerraform(struct?: Cloudbuildv2ConnectionTimeouts | cdktn.IResolvable): any;
export declare function cloudbuildv2ConnectionTimeoutsToHclTerraform(struct?: Cloudbuildv2ConnectionTimeouts | cdktn.IResolvable): any;
export declare class Cloudbuildv2ConnectionTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Cloudbuildv2ConnectionTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: Cloudbuildv2ConnectionTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection google_cloudbuildv2_connection}
*/
export declare class Cloudbuildv2Connection extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_cloudbuildv2_connection";
    /**
    * Generates CDKTN code for importing a Cloudbuildv2Connection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Cloudbuildv2Connection to import
    * @param importFromId The id of the existing Cloudbuildv2Connection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Cloudbuildv2Connection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_connection google_cloudbuildv2_connection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options Cloudbuildv2ConnectionConfig
    */
    constructor(scope: Construct, id: string, config: Cloudbuildv2ConnectionConfig);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _effectiveAnnotations;
    get effectiveAnnotations(): cdktn.StringMap;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _installationState;
    get installationState(): Cloudbuildv2ConnectionInstallationStateList;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get reconciling(): cdktn.IResolvable;
    get updateTime(): string;
    private _bitbucketCloudConfig;
    get bitbucketCloudConfig(): Cloudbuildv2ConnectionBitbucketCloudConfigOutputReference;
    putBitbucketCloudConfig(value: Cloudbuildv2ConnectionBitbucketCloudConfig): void;
    resetBitbucketCloudConfig(): void;
    get bitbucketCloudConfigInput(): Cloudbuildv2ConnectionBitbucketCloudConfig | undefined;
    private _bitbucketDataCenterConfig;
    get bitbucketDataCenterConfig(): Cloudbuildv2ConnectionBitbucketDataCenterConfigOutputReference;
    putBitbucketDataCenterConfig(value: Cloudbuildv2ConnectionBitbucketDataCenterConfig): void;
    resetBitbucketDataCenterConfig(): void;
    get bitbucketDataCenterConfigInput(): Cloudbuildv2ConnectionBitbucketDataCenterConfig | undefined;
    private _githubConfig;
    get githubConfig(): Cloudbuildv2ConnectionGithubConfigOutputReference;
    putGithubConfig(value: Cloudbuildv2ConnectionGithubConfig): void;
    resetGithubConfig(): void;
    get githubConfigInput(): Cloudbuildv2ConnectionGithubConfig | undefined;
    private _githubEnterpriseConfig;
    get githubEnterpriseConfig(): Cloudbuildv2ConnectionGithubEnterpriseConfigOutputReference;
    putGithubEnterpriseConfig(value: Cloudbuildv2ConnectionGithubEnterpriseConfig): void;
    resetGithubEnterpriseConfig(): void;
    get githubEnterpriseConfigInput(): Cloudbuildv2ConnectionGithubEnterpriseConfig | undefined;
    private _gitlabConfig;
    get gitlabConfig(): Cloudbuildv2ConnectionGitlabConfigOutputReference;
    putGitlabConfig(value: Cloudbuildv2ConnectionGitlabConfig): void;
    resetGitlabConfig(): void;
    get gitlabConfigInput(): Cloudbuildv2ConnectionGitlabConfig | undefined;
    private _timeouts;
    get timeouts(): Cloudbuildv2ConnectionTimeoutsOutputReference;
    putTimeouts(value: Cloudbuildv2ConnectionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | Cloudbuildv2ConnectionTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
