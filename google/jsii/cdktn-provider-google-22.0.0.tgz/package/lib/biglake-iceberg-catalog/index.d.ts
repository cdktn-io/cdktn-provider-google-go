/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BiglakeIcebergCatalogConfig extends cdktn.TerraformMetaArguments {
    /**
    * The catalog type of the IcebergCatalog.
    * * 'CATALOG_TYPE_GCS_BUCKET': Google Cloud Storage bucket catalog type.
    * * 'CATALOG_TYPE_BIGLAKE': BigLake catalog type.
    * * 'CATALOG_TYPE_FEDERATED': Federated catalog type, for integrating with external Iceberg REST Catalogs such as Databricks Unity Catalog or AWS Glue. Possible values: ["CATALOG_TYPE_GCS_BUCKET", "CATALOG_TYPE_BIGLAKE", "CATALOG_TYPE_FEDERATED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#catalog_type BiglakeIcebergCatalog#catalog_type}
    */
    readonly catalogType: string;
    /**
    * The credential mode used for the catalog. CREDENTIAL_MODE_END_USER - End user credentials, default. The authenticating user must have access to the catalog resources and the corresponding Google Cloud Storage files. CREDENTIAL_MODE_VENDED_CREDENTIALS - Use credential vending. The authenticating user must have access to the catalog resources and the system will provide the caller with downscoped credentials to access the Google Cloud Storage files. All table operations in this mode would require 'X-Iceberg-Access-Delegation' header with 'vended-credentials' value included. System will generate a service account and the catalog administrator must grant the service account appropriate permissions. Possible values: ["CREDENTIAL_MODE_END_USER", "CREDENTIAL_MODE_VENDED_CREDENTIALS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#credential_mode BiglakeIcebergCatalog#credential_mode}
    */
    readonly credentialMode?: string;
    /**
    * The default storage location for the catalog, e.g., 'gs://my-bucket'.
    * Output only when the catalog type is CATALOG_TYPE_GCS_BUCKET.
    * Required when the catalog type is CATALOG_TYPE_BIGLAKE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#default_location BiglakeIcebergCatalog#default_location}
    */
    readonly defaultLocation?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#deletion_policy BiglakeIcebergCatalog#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * A user-provided description of the catalog. Maximum 1024 UTF-8 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#description BiglakeIcebergCatalog#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#id BiglakeIcebergCatalog#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the IcebergCatalog.
    * For CATALOG_TYPE_GCS_BUCKET typed catalogs, the name needs to be the
    * exact same value of the GCS bucket's name. For example, for a bucket:
    * gs://bucket-name, the catalog name will be exactly "bucket-name".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#name BiglakeIcebergCatalog#name}
    */
    readonly name: string;
    /**
    * The primary location for mirroring the remote catalog metadata. It must be
    * a BigLake-supported location, and it should be proximate to the remote
    * catalog's location.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#primary_location BiglakeIcebergCatalog#primary_location}
    */
    readonly primaryLocation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#project BiglakeIcebergCatalog#project}
    */
    readonly project?: string;
    /**
    * federated_catalog_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#federated_catalog_options BiglakeIcebergCatalog#federated_catalog_options}
    */
    readonly federatedCatalogOptions?: BiglakeIcebergCatalogFederatedCatalogOptions;
    /**
    * restricted_locations_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#restricted_locations_config BiglakeIcebergCatalog#restricted_locations_config}
    */
    readonly restrictedLocationsConfig?: BiglakeIcebergCatalogRestrictedLocationsConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#timeouts BiglakeIcebergCatalog#timeouts}
    */
    readonly timeouts?: BiglakeIcebergCatalogTimeouts;
}
export interface BiglakeIcebergCatalogReplicas {
}
export declare function biglakeIcebergCatalogReplicasToTerraform(struct?: BiglakeIcebergCatalogReplicas): any;
export declare function biglakeIcebergCatalogReplicasToHclTerraform(struct?: BiglakeIcebergCatalogReplicas): any;
export declare class BiglakeIcebergCatalogReplicasOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BiglakeIcebergCatalogReplicas | undefined;
    set internalValue(value: BiglakeIcebergCatalogReplicas | undefined);
    get region(): string;
    get state(): string;
}
export declare class BiglakeIcebergCatalogReplicasList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BiglakeIcebergCatalogReplicasOutputReference;
}
export interface BiglakeIcebergCatalogFederatedCatalogOptionsRefreshStatusStatus {
}
export declare function biglakeIcebergCatalogFederatedCatalogOptionsRefreshStatusStatusToTerraform(struct?: BiglakeIcebergCatalogFederatedCatalogOptionsRefreshStatusStatus): any;
export declare function biglakeIcebergCatalogFederatedCatalogOptionsRefreshStatusStatusToHclTerraform(struct?: BiglakeIcebergCatalogFederatedCatalogOptionsRefreshStatusStatus): any;
export declare class BiglakeIcebergCatalogFederatedCatalogOptionsRefreshStatusStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BiglakeIcebergCatalogFederatedCatalogOptionsRefreshStatusStatus | undefined;
    set internalValue(value: BiglakeIcebergCatalogFederatedCatalogOptionsRefreshStatusStatus | undefined);
    get code(): number;
    get message(): string;
}
export declare class BiglakeIcebergCatalogFederatedCatalogOptionsRefreshStatusStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BiglakeIcebergCatalogFederatedCatalogOptionsRefreshStatusStatusOutputReference;
}
export interface BiglakeIcebergCatalogFederatedCatalogOptionsRefreshStatus {
}
export declare function biglakeIcebergCatalogFederatedCatalogOptionsRefreshStatusToTerraform(struct?: BiglakeIcebergCatalogFederatedCatalogOptionsRefreshStatus): any;
export declare function biglakeIcebergCatalogFederatedCatalogOptionsRefreshStatusToHclTerraform(struct?: BiglakeIcebergCatalogFederatedCatalogOptionsRefreshStatus): any;
export declare class BiglakeIcebergCatalogFederatedCatalogOptionsRefreshStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BiglakeIcebergCatalogFederatedCatalogOptionsRefreshStatus | undefined;
    set internalValue(value: BiglakeIcebergCatalogFederatedCatalogOptionsRefreshStatus | undefined);
    get endTime(): string;
    get startTime(): string;
    private _status;
    get status(): BiglakeIcebergCatalogFederatedCatalogOptionsRefreshStatusStatusList;
}
export declare class BiglakeIcebergCatalogFederatedCatalogOptionsRefreshStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BiglakeIcebergCatalogFederatedCatalogOptionsRefreshStatusOutputReference;
}
export interface BiglakeIcebergCatalogFederatedCatalogOptionsGlueCatalogInfo {
    /**
    * The AWS region where the Glue catalog is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#aws_region BiglakeIcebergCatalog#aws_region}
    */
    readonly awsRegion: string;
    /**
    * The ARN of the AWS IAM role to assume for accessing the Glue catalog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#aws_role_arn BiglakeIcebergCatalog#aws_role_arn}
    */
    readonly awsRoleArn: string;
    /**
    * The AWS Glue warehouse identifier (account ID or S3 table bucket).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#warehouse BiglakeIcebergCatalog#warehouse}
    */
    readonly warehouse: string;
}
export declare function biglakeIcebergCatalogFederatedCatalogOptionsGlueCatalogInfoToTerraform(struct?: BiglakeIcebergCatalogFederatedCatalogOptionsGlueCatalogInfoOutputReference | BiglakeIcebergCatalogFederatedCatalogOptionsGlueCatalogInfo): any;
export declare function biglakeIcebergCatalogFederatedCatalogOptionsGlueCatalogInfoToHclTerraform(struct?: BiglakeIcebergCatalogFederatedCatalogOptionsGlueCatalogInfoOutputReference | BiglakeIcebergCatalogFederatedCatalogOptionsGlueCatalogInfo): any;
export declare class BiglakeIcebergCatalogFederatedCatalogOptionsGlueCatalogInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BiglakeIcebergCatalogFederatedCatalogOptionsGlueCatalogInfo | undefined;
    set internalValue(value: BiglakeIcebergCatalogFederatedCatalogOptionsGlueCatalogInfo | undefined);
    private _awsRegion?;
    get awsRegion(): string;
    set awsRegion(value: string);
    get awsRegionInput(): string | undefined;
    private _awsRoleArn?;
    get awsRoleArn(): string;
    set awsRoleArn(value: string);
    get awsRoleArnInput(): string | undefined;
    private _warehouse?;
    get warehouse(): string;
    set warehouse(value: string);
    get warehouseInput(): string | undefined;
}
export interface BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshSchedule {
    /**
    * The interval between metadata refreshes, expressed as a duration
    * string (e.g., '300s').
    * The value must be at least 300s or 0s to disable refresh.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#refresh_interval BiglakeIcebergCatalog#refresh_interval}
    */
    readonly refreshInterval?: string;
}
export declare function biglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshScheduleToTerraform(struct?: BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshScheduleOutputReference | BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshSchedule): any;
export declare function biglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshScheduleToHclTerraform(struct?: BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshScheduleOutputReference | BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshSchedule): any;
export declare class BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshSchedule | undefined;
    set internalValue(value: BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshSchedule | undefined);
    private _refreshInterval?;
    get refreshInterval(): string;
    set refreshInterval(value: string);
    resetRefreshInterval(): void;
    get refreshIntervalInput(): string | undefined;
}
export interface BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshScope {
    /**
    * A list of namespace filters to limit which namespaces are
    * synchronized from the remote catalog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#namespace_filters BiglakeIcebergCatalog#namespace_filters}
    */
    readonly namespaceFilters?: string[];
}
export declare function biglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshScopeToTerraform(struct?: BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshScopeOutputReference | BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshScope): any;
export declare function biglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshScopeToHclTerraform(struct?: BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshScopeOutputReference | BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshScope): any;
export declare class BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshScopeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshScope | undefined;
    set internalValue(value: BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshScope | undefined);
    private _namespaceFilters?;
    get namespaceFilters(): string[];
    set namespaceFilters(value: string[]);
    resetNamespaceFilters(): void;
    get namespaceFiltersInput(): string[] | undefined;
}
export interface BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptions {
    /**
    * refresh_schedule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#refresh_schedule BiglakeIcebergCatalog#refresh_schedule}
    */
    readonly refreshSchedule?: BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshSchedule;
    /**
    * refresh_scope block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#refresh_scope BiglakeIcebergCatalog#refresh_scope}
    */
    readonly refreshScope?: BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshScope;
}
export declare function biglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsToTerraform(struct?: BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsOutputReference | BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptions): any;
export declare function biglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsToHclTerraform(struct?: BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsOutputReference | BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptions): any;
export declare class BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptions | undefined;
    set internalValue(value: BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptions | undefined);
    private _refreshSchedule;
    get refreshSchedule(): BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshScheduleOutputReference;
    putRefreshSchedule(value: BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshSchedule): void;
    resetRefreshSchedule(): void;
    get refreshScheduleInput(): BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshSchedule | undefined;
    private _refreshScope;
    get refreshScope(): BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshScopeOutputReference;
    putRefreshScope(value: BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshScope): void;
    resetRefreshScope(): void;
    get refreshScopeInput(): BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsRefreshScope | undefined;
}
export interface BiglakeIcebergCatalogFederatedCatalogOptionsUnityCatalogInfo {
    /**
    * The name of the catalog within the Unity Catalog instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#catalog_name BiglakeIcebergCatalog#catalog_name}
    */
    readonly catalogName: string;
    /**
    * The Databricks workspace instance name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#instance_name BiglakeIcebergCatalog#instance_name}
    */
    readonly instanceName: string;
    /**
    * The application ID of the Databricks service principal for OIDC authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#service_principal_application_id BiglakeIcebergCatalog#service_principal_application_id}
    */
    readonly servicePrincipalApplicationId?: string;
}
export declare function biglakeIcebergCatalogFederatedCatalogOptionsUnityCatalogInfoToTerraform(struct?: BiglakeIcebergCatalogFederatedCatalogOptionsUnityCatalogInfoOutputReference | BiglakeIcebergCatalogFederatedCatalogOptionsUnityCatalogInfo): any;
export declare function biglakeIcebergCatalogFederatedCatalogOptionsUnityCatalogInfoToHclTerraform(struct?: BiglakeIcebergCatalogFederatedCatalogOptionsUnityCatalogInfoOutputReference | BiglakeIcebergCatalogFederatedCatalogOptionsUnityCatalogInfo): any;
export declare class BiglakeIcebergCatalogFederatedCatalogOptionsUnityCatalogInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BiglakeIcebergCatalogFederatedCatalogOptionsUnityCatalogInfo | undefined;
    set internalValue(value: BiglakeIcebergCatalogFederatedCatalogOptionsUnityCatalogInfo | undefined);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    get catalogNameInput(): string | undefined;
    private _instanceName?;
    get instanceName(): string;
    set instanceName(value: string);
    get instanceNameInput(): string | undefined;
    private _servicePrincipalApplicationId?;
    get servicePrincipalApplicationId(): string;
    set servicePrincipalApplicationId(value: string);
    resetServicePrincipalApplicationId(): void;
    get servicePrincipalApplicationIdInput(): string | undefined;
}
export interface BiglakeIcebergCatalogFederatedCatalogOptions {
    /**
    * The secret resource name in Secret Manager, in the format
    * 'projects/{projectId}/locations/{location}/secrets/{secret_id}'.
    * Used to store credentials for authenticating with the remote catalog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#secret_name BiglakeIcebergCatalog#secret_name}
    */
    readonly secretName?: string;
    /**
    * The Service Directory service name for private network connectivity
    * through Cross-Cloud Interconnect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#service_directory_name BiglakeIcebergCatalog#service_directory_name}
    */
    readonly serviceDirectoryName?: string;
    /**
    * glue_catalog_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#glue_catalog_info BiglakeIcebergCatalog#glue_catalog_info}
    */
    readonly glueCatalogInfo?: BiglakeIcebergCatalogFederatedCatalogOptionsGlueCatalogInfo;
    /**
    * refresh_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#refresh_options BiglakeIcebergCatalog#refresh_options}
    */
    readonly refreshOptions?: BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptions;
    /**
    * unity_catalog_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#unity_catalog_info BiglakeIcebergCatalog#unity_catalog_info}
    */
    readonly unityCatalogInfo?: BiglakeIcebergCatalogFederatedCatalogOptionsUnityCatalogInfo;
}
export declare function biglakeIcebergCatalogFederatedCatalogOptionsToTerraform(struct?: BiglakeIcebergCatalogFederatedCatalogOptionsOutputReference | BiglakeIcebergCatalogFederatedCatalogOptions): any;
export declare function biglakeIcebergCatalogFederatedCatalogOptionsToHclTerraform(struct?: BiglakeIcebergCatalogFederatedCatalogOptionsOutputReference | BiglakeIcebergCatalogFederatedCatalogOptions): any;
export declare class BiglakeIcebergCatalogFederatedCatalogOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BiglakeIcebergCatalogFederatedCatalogOptions | undefined;
    set internalValue(value: BiglakeIcebergCatalogFederatedCatalogOptions | undefined);
    private _refreshStatus;
    get refreshStatus(): BiglakeIcebergCatalogFederatedCatalogOptionsRefreshStatusList;
    private _secretName?;
    get secretName(): string;
    set secretName(value: string);
    resetSecretName(): void;
    get secretNameInput(): string | undefined;
    private _serviceDirectoryName?;
    get serviceDirectoryName(): string;
    set serviceDirectoryName(value: string);
    resetServiceDirectoryName(): void;
    get serviceDirectoryNameInput(): string | undefined;
    private _glueCatalogInfo;
    get glueCatalogInfo(): BiglakeIcebergCatalogFederatedCatalogOptionsGlueCatalogInfoOutputReference;
    putGlueCatalogInfo(value: BiglakeIcebergCatalogFederatedCatalogOptionsGlueCatalogInfo): void;
    resetGlueCatalogInfo(): void;
    get glueCatalogInfoInput(): BiglakeIcebergCatalogFederatedCatalogOptionsGlueCatalogInfo | undefined;
    private _refreshOptions;
    get refreshOptions(): BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptionsOutputReference;
    putRefreshOptions(value: BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptions): void;
    resetRefreshOptions(): void;
    get refreshOptionsInput(): BiglakeIcebergCatalogFederatedCatalogOptionsRefreshOptions | undefined;
    private _unityCatalogInfo;
    get unityCatalogInfo(): BiglakeIcebergCatalogFederatedCatalogOptionsUnityCatalogInfoOutputReference;
    putUnityCatalogInfo(value: BiglakeIcebergCatalogFederatedCatalogOptionsUnityCatalogInfo): void;
    resetUnityCatalogInfo(): void;
    get unityCatalogInfoInput(): BiglakeIcebergCatalogFederatedCatalogOptionsUnityCatalogInfo | undefined;
}
export interface BiglakeIcebergCatalogRestrictedLocationsConfig {
    /**
    * A list of GCS locations (e.g., 'gs://my-other-bucket/...') that are
    * permitted for use by resources within this catalog. Each entry can be
    * either a GCS bucket or a path within it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#restricted_locations BiglakeIcebergCatalog#restricted_locations}
    */
    readonly restrictedLocations?: string[];
}
export declare function biglakeIcebergCatalogRestrictedLocationsConfigToTerraform(struct?: BiglakeIcebergCatalogRestrictedLocationsConfigOutputReference | BiglakeIcebergCatalogRestrictedLocationsConfig): any;
export declare function biglakeIcebergCatalogRestrictedLocationsConfigToHclTerraform(struct?: BiglakeIcebergCatalogRestrictedLocationsConfigOutputReference | BiglakeIcebergCatalogRestrictedLocationsConfig): any;
export declare class BiglakeIcebergCatalogRestrictedLocationsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BiglakeIcebergCatalogRestrictedLocationsConfig | undefined;
    set internalValue(value: BiglakeIcebergCatalogRestrictedLocationsConfig | undefined);
    private _restrictedLocations?;
    get restrictedLocations(): string[];
    set restrictedLocations(value: string[]);
    resetRestrictedLocations(): void;
    get restrictedLocationsInput(): string[] | undefined;
}
export interface BiglakeIcebergCatalogTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#create BiglakeIcebergCatalog#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#delete BiglakeIcebergCatalog#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#update BiglakeIcebergCatalog#update}
    */
    readonly update?: string;
}
export declare function biglakeIcebergCatalogTimeoutsToTerraform(struct?: BiglakeIcebergCatalogTimeouts | cdktn.IResolvable): any;
export declare function biglakeIcebergCatalogTimeoutsToHclTerraform(struct?: BiglakeIcebergCatalogTimeouts | cdktn.IResolvable): any;
export declare class BiglakeIcebergCatalogTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BiglakeIcebergCatalogTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BiglakeIcebergCatalogTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog google_biglake_iceberg_catalog}
*/
export declare class BiglakeIcebergCatalog extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_biglake_iceberg_catalog";
    /**
    * Generates CDKTN code for importing a BiglakeIcebergCatalog resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BiglakeIcebergCatalog to import
    * @param importFromId The id of the existing BiglakeIcebergCatalog that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BiglakeIcebergCatalog to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_catalog google_biglake_iceberg_catalog} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BiglakeIcebergCatalogConfig
    */
    constructor(scope: Construct, id: string, config: BiglakeIcebergCatalogConfig);
    get biglakeServiceAccount(): string;
    get biglakeServiceAccountId(): string;
    private _catalogType?;
    get catalogType(): string;
    set catalogType(value: string);
    get catalogTypeInput(): string | undefined;
    get createTime(): string;
    private _credentialMode?;
    get credentialMode(): string;
    set credentialMode(value: string);
    resetCredentialMode(): void;
    get credentialModeInput(): string | undefined;
    private _defaultLocation?;
    get defaultLocation(): string;
    set defaultLocation(value: string);
    resetDefaultLocation(): void;
    get defaultLocationInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _primaryLocation?;
    get primaryLocation(): string;
    set primaryLocation(value: string);
    resetPrimaryLocation(): void;
    get primaryLocationInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _replicas;
    get replicas(): BiglakeIcebergCatalogReplicasList;
    get storageRegions(): string[];
    get updateTime(): string;
    private _federatedCatalogOptions;
    get federatedCatalogOptions(): BiglakeIcebergCatalogFederatedCatalogOptionsOutputReference;
    putFederatedCatalogOptions(value: BiglakeIcebergCatalogFederatedCatalogOptions): void;
    resetFederatedCatalogOptions(): void;
    get federatedCatalogOptionsInput(): BiglakeIcebergCatalogFederatedCatalogOptions | undefined;
    private _restrictedLocationsConfig;
    get restrictedLocationsConfig(): BiglakeIcebergCatalogRestrictedLocationsConfigOutputReference;
    putRestrictedLocationsConfig(value: BiglakeIcebergCatalogRestrictedLocationsConfig): void;
    resetRestrictedLocationsConfig(): void;
    get restrictedLocationsConfigInput(): BiglakeIcebergCatalogRestrictedLocationsConfig | undefined;
    private _timeouts;
    get timeouts(): BiglakeIcebergCatalogTimeoutsOutputReference;
    putTimeouts(value: BiglakeIcebergCatalogTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BiglakeIcebergCatalogTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
