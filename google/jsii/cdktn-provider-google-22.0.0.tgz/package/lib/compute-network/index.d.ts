/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeNetworkConfig extends cdktn.TerraformMetaArguments {
    /**
    * When set to 'true', the network is created in "auto subnet mode" and
    * it will create a subnet for each region automatically across the
    * '10.128.0.0/9' address range.
    *
    * When set to 'false', the network is created in "custom subnet mode" so
    * the user can explicitly connect subnetwork resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network#auto_create_subnetworks ComputeNetwork#auto_create_subnetworks}
    */
    readonly autoCreateSubnetworks?: boolean | cdktn.IResolvable;
    /**
    * Enables/disables the comparison of MED across routes with different Neighbor ASNs.
    * This value can only be set if the --bgp-best-path-selection-mode is STANDARD
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network#bgp_always_compare_med ComputeNetwork#bgp_always_compare_med}
    */
    readonly bgpAlwaysCompareMed?: boolean | cdktn.IResolvable;
    /**
    * The BGP best selection algorithm to be employed. MODE can be LEGACY or STANDARD. Possible values: ["LEGACY", "STANDARD"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network#bgp_best_path_selection_mode ComputeNetwork#bgp_best_path_selection_mode}
    */
    readonly bgpBestPathSelectionMode?: string;
    /**
    * Choice of the behavior of inter-regional cost and MED in the BPS algorithm. Possible values: ["DEFAULT", "ADD_COST_TO_MED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network#bgp_inter_region_cost ComputeNetwork#bgp_inter_region_cost}
    */
    readonly bgpInterRegionCost?: string;
    /**
    * If set to 'true', the 'bgp_always_compare_med' field will be cleared.
    * If set to 'false' (the default), 'bgp_always_compare_med' will be set to the value specified in the configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network#delete_bgp_always_compare_med ComputeNetwork#delete_bgp_always_compare_med}
    */
    readonly deleteBgpAlwaysCompareMed?: boolean | cdktn.IResolvable;
    /**
    * If set to 'true', default routes ('0.0.0.0/0') will be deleted
    * immediately after network creation. Defaults to 'false'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network#delete_default_routes_on_create ComputeNetwork#delete_default_routes_on_create}
    */
    readonly deleteDefaultRoutesOnCreate?: boolean | cdktn.IResolvable;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network#deletion_policy ComputeNetwork#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource. The resource must be
    * recreated to modify this field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network#description ComputeNetwork#description}
    */
    readonly description?: string;
    /**
    * Enable ULA internal ipv6 on this network. Enabling this feature will assign
    * a /48 from google defined ULA prefix fd20::/20.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network#enable_ula_internal_ipv6 ComputeNetwork#enable_ula_internal_ipv6}
    */
    readonly enableUlaInternalIpv6?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network#id ComputeNetwork#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * When enabling ula internal ipv6, caller optionally can specify the /48 range
    * they want from the google defined ULA prefix fd20::/20. The input must be a
    * valid /48 ULA IPv6 address and must be within the fd20::/20. Operation will
    * fail if the speficied /48 is already in used by another resource.
    * If the field is not speficied, then a /48 range will be randomly allocated from fd20::/20 and returned via this field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network#internal_ipv6_range ComputeNetwork#internal_ipv6_range}
    */
    readonly internalIpv6Range?: string;
    /**
    * Maximum Transmission Unit in bytes. The default value is 1460 bytes.
    * The minimum value for this field is 1300 and the maximum value is 8896 bytes (jumbo frames).
    * Note that packets larger than 1500 bytes (standard Ethernet) can be subject to TCP-MSS clamping or dropped
    * with an ICMP 'Fragmentation-Needed' message if the packets are routed to the Internet or other VPCs
    * with varying MTUs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network#mtu ComputeNetwork#mtu}
    */
    readonly mtu?: number;
    /**
    * Name of the resource. Provided by the client when the resource is
    * created. The name must be 1-63 characters long, and comply with
    * RFC1035. Specifically, the name must be 1-63 characters long and match
    * the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the
    * first character must be a lowercase letter, and all following
    * characters must be a dash, lowercase letter, or digit, except the last
    * character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network#name ComputeNetwork#name}
    */
    readonly name: string;
    /**
    * Set the order that Firewall Rules and Firewall Policies are evaluated. Default value: "AFTER_CLASSIC_FIREWALL" Possible values: ["BEFORE_CLASSIC_FIREWALL", "AFTER_CLASSIC_FIREWALL"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network#network_firewall_policy_enforcement_order ComputeNetwork#network_firewall_policy_enforcement_order}
    */
    readonly networkFirewallPolicyEnforcementOrder?: string;
    /**
    * A full or partial URL of the network profile to apply to this network.
    * This field can be set only at resource creation time. For example, the
    * following are valid URLs:
    * * https://www.googleapis.com/compute/v1/projects/{projectId}/global/networkProfiles/{network_profile_name}
    * * projects/{projectId}/global/networkProfiles/{network_profile_name}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network#network_profile ComputeNetwork#network_profile}
    */
    readonly networkProfile?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network#project ComputeNetwork#project}
    */
    readonly project?: string;
    /**
    * The network-wide routing mode to use. If set to 'REGIONAL', this
    * network's cloud routers will only advertise routes with subnetworks
    * of this network in the same region as the router. If set to 'GLOBAL',
    * this network's cloud routers will advertise routes with all
    * subnetworks of this network, across regions. Possible values: ["REGIONAL", "GLOBAL"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network#routing_mode ComputeNetwork#routing_mode}
    */
    readonly routingMode?: string;
    /**
    * params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network#params ComputeNetwork#params}
    */
    readonly params?: ComputeNetworkParams;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network#timeouts ComputeNetwork#timeouts}
    */
    readonly timeouts?: ComputeNetworkTimeouts;
}
export interface ComputeNetworkParams {
    /**
    * Resource manager tags to be bound to the network. Tag keys and values have the
    * same definition as resource manager tags. Keys must be in the format tagKeys/{tag_key_id},
    * and values are in the format tagValues/456.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network#resource_manager_tags ComputeNetwork#resource_manager_tags}
    */
    readonly resourceManagerTags?: {
        [key: string]: string;
    };
}
export declare function computeNetworkParamsToTerraform(struct?: ComputeNetworkParamsOutputReference | ComputeNetworkParams): any;
export declare function computeNetworkParamsToHclTerraform(struct?: ComputeNetworkParamsOutputReference | ComputeNetworkParams): any;
export declare class ComputeNetworkParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeNetworkParams | undefined;
    set internalValue(value: ComputeNetworkParams | undefined);
    private _resourceManagerTags?;
    get resourceManagerTags(): {
        [key: string]: string;
    };
    set resourceManagerTags(value: {
        [key: string]: string;
    });
    resetResourceManagerTags(): void;
    get resourceManagerTagsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ComputeNetworkTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network#create ComputeNetwork#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network#delete ComputeNetwork#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network#update ComputeNetwork#update}
    */
    readonly update?: string;
}
export declare function computeNetworkTimeoutsToTerraform(struct?: ComputeNetworkTimeouts | cdktn.IResolvable): any;
export declare function computeNetworkTimeoutsToHclTerraform(struct?: ComputeNetworkTimeouts | cdktn.IResolvable): any;
export declare class ComputeNetworkTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeNetworkTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeNetworkTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network google_compute_network}
*/
export declare class ComputeNetwork extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_network";
    /**
    * Generates CDKTN code for importing a ComputeNetwork resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeNetwork to import
    * @param importFromId The id of the existing ComputeNetwork that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeNetwork to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network google_compute_network} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeNetworkConfig
    */
    constructor(scope: Construct, id: string, config: ComputeNetworkConfig);
    private _autoCreateSubnetworks?;
    get autoCreateSubnetworks(): boolean | cdktn.IResolvable;
    set autoCreateSubnetworks(value: boolean | cdktn.IResolvable);
    resetAutoCreateSubnetworks(): void;
    get autoCreateSubnetworksInput(): boolean | cdktn.IResolvable | undefined;
    private _bgpAlwaysCompareMed?;
    get bgpAlwaysCompareMed(): boolean | cdktn.IResolvable;
    set bgpAlwaysCompareMed(value: boolean | cdktn.IResolvable);
    resetBgpAlwaysCompareMed(): void;
    get bgpAlwaysCompareMedInput(): boolean | cdktn.IResolvable | undefined;
    private _bgpBestPathSelectionMode?;
    get bgpBestPathSelectionMode(): string;
    set bgpBestPathSelectionMode(value: string);
    resetBgpBestPathSelectionMode(): void;
    get bgpBestPathSelectionModeInput(): string | undefined;
    private _bgpInterRegionCost?;
    get bgpInterRegionCost(): string;
    set bgpInterRegionCost(value: string);
    resetBgpInterRegionCost(): void;
    get bgpInterRegionCostInput(): string | undefined;
    private _deleteBgpAlwaysCompareMed?;
    get deleteBgpAlwaysCompareMed(): boolean | cdktn.IResolvable;
    set deleteBgpAlwaysCompareMed(value: boolean | cdktn.IResolvable);
    resetDeleteBgpAlwaysCompareMed(): void;
    get deleteBgpAlwaysCompareMedInput(): boolean | cdktn.IResolvable | undefined;
    private _deleteDefaultRoutesOnCreate?;
    get deleteDefaultRoutesOnCreate(): boolean | cdktn.IResolvable;
    set deleteDefaultRoutesOnCreate(value: boolean | cdktn.IResolvable);
    resetDeleteDefaultRoutesOnCreate(): void;
    get deleteDefaultRoutesOnCreateInput(): boolean | cdktn.IResolvable | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enableUlaInternalIpv6?;
    get enableUlaInternalIpv6(): boolean | cdktn.IResolvable;
    set enableUlaInternalIpv6(value: boolean | cdktn.IResolvable);
    resetEnableUlaInternalIpv6(): void;
    get enableUlaInternalIpv6Input(): boolean | cdktn.IResolvable | undefined;
    get gatewayIpv4(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _internalIpv6Range?;
    get internalIpv6Range(): string;
    set internalIpv6Range(value: string);
    resetInternalIpv6Range(): void;
    get internalIpv6RangeInput(): string | undefined;
    private _mtu?;
    get mtu(): number;
    set mtu(value: number);
    resetMtu(): void;
    get mtuInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networkFirewallPolicyEnforcementOrder?;
    get networkFirewallPolicyEnforcementOrder(): string;
    set networkFirewallPolicyEnforcementOrder(value: string);
    resetNetworkFirewallPolicyEnforcementOrder(): void;
    get networkFirewallPolicyEnforcementOrderInput(): string | undefined;
    get networkId(): string;
    private _networkProfile?;
    get networkProfile(): string;
    set networkProfile(value: string);
    resetNetworkProfile(): void;
    get networkProfileInput(): string | undefined;
    get numericId(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _routingMode?;
    get routingMode(): string;
    set routingMode(value: string);
    resetRoutingMode(): void;
    get routingModeInput(): string | undefined;
    get selfLink(): string;
    private _params;
    get params(): ComputeNetworkParamsOutputReference;
    putParams(value: ComputeNetworkParams): void;
    resetParams(): void;
    get paramsInput(): ComputeNetworkParams | undefined;
    private _timeouts;
    get timeouts(): ComputeNetworkTimeoutsOutputReference;
    putTimeouts(value: ComputeNetworkTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeNetworkTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
