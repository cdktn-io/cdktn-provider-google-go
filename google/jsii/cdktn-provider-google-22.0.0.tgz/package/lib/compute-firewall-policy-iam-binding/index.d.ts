/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeFirewallPolicyIamBindingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_iam_binding#id ComputeFirewallPolicyIamBinding#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_iam_binding#members ComputeFirewallPolicyIamBinding#members}
    */
    readonly members: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_iam_binding#name ComputeFirewallPolicyIamBinding#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_iam_binding#role ComputeFirewallPolicyIamBinding#role}
    */
    readonly role: string;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_iam_binding#condition ComputeFirewallPolicyIamBinding#condition}
    */
    readonly condition?: ComputeFirewallPolicyIamBindingCondition;
}
export interface ComputeFirewallPolicyIamBindingCondition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_iam_binding#description ComputeFirewallPolicyIamBinding#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_iam_binding#expression ComputeFirewallPolicyIamBinding#expression}
    */
    readonly expression: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_iam_binding#title ComputeFirewallPolicyIamBinding#title}
    */
    readonly title: string;
}
export declare function computeFirewallPolicyIamBindingConditionToTerraform(struct?: ComputeFirewallPolicyIamBindingConditionOutputReference | ComputeFirewallPolicyIamBindingCondition): any;
export declare function computeFirewallPolicyIamBindingConditionToHclTerraform(struct?: ComputeFirewallPolicyIamBindingConditionOutputReference | ComputeFirewallPolicyIamBindingCondition): any;
export declare class ComputeFirewallPolicyIamBindingConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeFirewallPolicyIamBindingCondition | undefined;
    set internalValue(value: ComputeFirewallPolicyIamBindingCondition | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_iam_binding google_compute_firewall_policy_iam_binding}
*/
export declare class ComputeFirewallPolicyIamBinding extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_firewall_policy_iam_binding";
    /**
    * Generates CDKTN code for importing a ComputeFirewallPolicyIamBinding resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeFirewallPolicyIamBinding to import
    * @param importFromId The id of the existing ComputeFirewallPolicyIamBinding that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_iam_binding#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeFirewallPolicyIamBinding to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_iam_binding google_compute_firewall_policy_iam_binding} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeFirewallPolicyIamBindingConfig
    */
    constructor(scope: Construct, id: string, config: ComputeFirewallPolicyIamBindingConfig);
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _members?;
    get members(): string[];
    set members(value: string[]);
    get membersInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _condition;
    get condition(): ComputeFirewallPolicyIamBindingConditionOutputReference;
    putCondition(value: ComputeFirewallPolicyIamBindingCondition): void;
    resetCondition(): void;
    get conditionInput(): ComputeFirewallPolicyIamBindingCondition | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
