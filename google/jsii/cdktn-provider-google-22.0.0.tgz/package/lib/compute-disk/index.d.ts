/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeDiskConfig extends cdktn.TerraformMetaArguments {
    /**
    * The access mode of the disk.
    * For example:
    *   * READ_WRITE_SINGLE: The default AccessMode, means the disk can be attached to single instance in RW mode.
    *   * READ_WRITE_MANY: The AccessMode means the disk can be attached to multiple instances in RW mode.
    *   * READ_ONLY_SINGLE: The AccessMode means the disk can be attached to multiple instances in RO mode.
    * The AccessMode is only valid for Hyperdisk disk types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#access_mode ComputeDisk#access_mode}
    */
    readonly accessMode?: string;
    /**
    * The architecture of the disk. Values include 'X86_64', 'ARM64'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#architecture ComputeDisk#architecture}
    */
    readonly architecture?: string;
    /**
    * If set to true, a snapshot of the disk will be created before it is destroyed.
    * If your disk is encrypted with customer managed encryption keys these will be reused for the snapshot creation.
    * The name of the snapshot by default will be '{{disk-name}}-YYYYMMDD-HHmm'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#create_snapshot_before_destroy ComputeDisk#create_snapshot_before_destroy}
    */
    readonly createSnapshotBeforeDestroy?: boolean | cdktn.IResolvable;
    /**
    * This will set a custom name prefix for the snapshot that's created when the disk is deleted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#create_snapshot_before_destroy_prefix ComputeDisk#create_snapshot_before_destroy_prefix}
    */
    readonly createSnapshotBeforeDestroyPrefix?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#deletion_policy ComputeDisk#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource. Provide this property when
    * you create the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#description ComputeDisk#description}
    */
    readonly description?: string;
    /**
    * Whether this disk is using confidential compute mode.
    * Note: Only supported on hyperdisk skus, disk_encryption_key is required when setting to true
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#enable_confidential_compute ComputeDisk#enable_confidential_compute}
    */
    readonly enableConfidentialCompute?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#id ComputeDisk#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The image from which to initialize this disk. This can be
    * one of: the image's 'self_link', 'projects/{project}/global/images/{image}',
    * 'projects/{project}/global/images/family/{family}', 'global/images/{image}',
    * 'global/images/family/{family}', 'family/{family}', '{project}/{family}',
    * '{project}/{image}', '{family}', or '{image}'. If referred by family, the
    * images names must include the family name. If they don't, use the
    * [google_compute_image data source](/docs/providers/google/d/compute_image.html).
    * For instance, the image 'centos-6-v20180104' includes its family name 'centos-6'.
    * These images can be referred by family name here.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#image ComputeDisk#image}
    */
    readonly image?: string;
    /**
    * Labels to apply to this disk.  A list of key->value pairs.
    *
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#labels ComputeDisk#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Any applicable license URI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#licenses ComputeDisk#licenses}
    */
    readonly licenses?: string[];
    /**
    * Name of the resource. Provided by the client when the resource is
    * created. The name must be 1-63 characters long, and comply with
    * RFC1035. Specifically, the name must be 1-63 characters long and match
    * the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the
    * first character must be a lowercase letter, and all following
    * characters must be a dash, lowercase letter, or digit, except the last
    * character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#name ComputeDisk#name}
    */
    readonly name: string;
    /**
    * Physical block size of the persistent disk, in bytes. If not present
    * in a request, a default value is used. Currently supported sizes
    * are 4096 and 16384, other sizes may be added in the future.
    * If an unsupported value is requested, the error message will list
    * the supported values for the caller's project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#physical_block_size_bytes ComputeDisk#physical_block_size_bytes}
    */
    readonly physicalBlockSizeBytes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#project ComputeDisk#project}
    */
    readonly project?: string;
    /**
    * Indicates how many IOPS must be provisioned for the disk.
    * Note: Updating currently is only supported by hyperdisk skus without the need to delete and recreate the disk, hyperdisk
    * allows for an update of IOPS every 4 hours. To update your hyperdisk more frequently, you'll need to manually delete and recreate it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#provisioned_iops ComputeDisk#provisioned_iops}
    */
    readonly provisionedIops?: number;
    /**
    * Indicates how much Throughput must be provisioned for the disk.
    * Note: Updating currently is only supported by hyperdisk skus without the need to delete and recreate the disk, hyperdisk
    * allows for an update of Throughput every 4 hours. To update your hyperdisk more frequently, you'll need to manually delete and recreate it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#provisioned_throughput ComputeDisk#provisioned_throughput}
    */
    readonly provisionedThroughput?: number;
    /**
    * Size of the persistent disk, specified in GB. You can specify this
    * field when creating a persistent disk using the 'image' or
    * 'snapshot' parameter, or specify it alone to create an empty
    * persistent disk.
    *
    * If you specify this field along with 'image' or 'snapshot',
    * the value must not be less than the size of the image
    * or the size of the snapshot.
    *
    * ~>**NOTE** If you change the size, Terraform updates the disk size
    * if upsizing is detected but recreates the disk if downsizing is requested.
    * You can add 'lifecycle.prevent_destroy' in the config to prevent destroying
    * and recreating.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#size ComputeDisk#size}
    */
    readonly size?: number;
    /**
    * The source snapshot used to create this disk. You can provide this as
    * a partial or full URL to the resource. If the snapshot is in another
    * project than this disk, you must supply a full URL. For example, the
    * following are valid values:
    *
    * * 'https://www.googleapis.com/compute/v1/projects/project/global/snapshots/snapshot'
    * * 'projects/project/global/snapshots/snapshot'
    * * 'global/snapshots/snapshot'
    * * 'snapshot'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#snapshot ComputeDisk#snapshot}
    */
    readonly snapshot?: string;
    /**
    * The source disk used to create this disk. You can provide this as a partial or full URL to the resource.
    * For example, the following are valid values:
    *
    * * https://www.googleapis.com/compute/v1/projects/{project}/zones/{zone}/disks/{disk}
    * * https://www.googleapis.com/compute/v1/projects/{project}/regions/{region}/disks/{disk}
    * * projects/{project}/zones/{zone}/disks/{disk}
    * * projects/{project}/regions/{region}/disks/{disk}
    * * zones/{zone}/disks/{disk}
    * * regions/{region}/disks/{disk}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#source_disk ComputeDisk#source_disk}
    */
    readonly sourceDisk?: string;
    /**
    * The source instant snapshot used to create this disk. You can provide this as a partial or full URL to the resource.
    * For example, the following are valid values:
    *
    * * 'https://www.googleapis.com/compute/v1/projects/project/zones/zone/instantSnapshots/instantSnapshot'
    * * 'projects/project/zones/zone/instantSnapshots/instantSnapshot'
    * * 'zones/zone/instantSnapshots/instantSnapshot'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#source_instant_snapshot ComputeDisk#source_instant_snapshot}
    */
    readonly sourceInstantSnapshot?: string;
    /**
    * The full Google Cloud Storage URI where the disk image is stored.
    * This file must be a gzip-compressed tarball whose name ends in .tar.gz or virtual machine disk whose name ends in vmdk.
    * Valid URIs may start with gs:// or https://storage.googleapis.com/.
    * This flag is not optimized for creating multiple disks from a source storage object.
    * To create many disks from a source storage object, use gcloud compute images import instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#source_storage_object ComputeDisk#source_storage_object}
    */
    readonly sourceStorageObject?: string;
    /**
    * The URL or the name of the storage pool in which the new disk is created.
    * For example:
    * * https://www.googleapis.com/compute/v1/projects/{project}/zones/{zone}/storagePools/{storagePool}
    * * /projects/{project}/zones/{zone}/storagePools/{storagePool}
    * * /zones/{zone}/storagePools/{storagePool}
    * * /{storagePool}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#storage_pool ComputeDisk#storage_pool}
    */
    readonly storagePool?: string;
    /**
    * URL of the disk type resource describing which disk type to use to
    * create the disk. Provide this when creating the disk.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#type ComputeDisk#type}
    */
    readonly type?: string;
    /**
    * A reference to the zone where the disk resides.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#zone ComputeDisk#zone}
    */
    readonly zone?: string;
    /**
    * async_primary_disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#async_primary_disk ComputeDisk#async_primary_disk}
    */
    readonly asyncPrimaryDisk?: ComputeDiskAsyncPrimaryDisk;
    /**
    * disk_encryption_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#disk_encryption_key ComputeDisk#disk_encryption_key}
    */
    readonly diskEncryptionKey?: ComputeDiskDiskEncryptionKey;
    /**
    * guest_os_features block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#guest_os_features ComputeDisk#guest_os_features}
    */
    readonly guestOsFeatures?: ComputeDiskGuestOsFeatures[] | cdktn.IResolvable;
    /**
    * params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#params ComputeDisk#params}
    */
    readonly params?: ComputeDiskParams;
    /**
    * source_image_encryption_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#source_image_encryption_key ComputeDisk#source_image_encryption_key}
    */
    readonly sourceImageEncryptionKey?: ComputeDiskSourceImageEncryptionKey;
    /**
    * source_snapshot_encryption_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#source_snapshot_encryption_key ComputeDisk#source_snapshot_encryption_key}
    */
    readonly sourceSnapshotEncryptionKey?: ComputeDiskSourceSnapshotEncryptionKey;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#timeouts ComputeDisk#timeouts}
    */
    readonly timeouts?: ComputeDiskTimeouts;
}
export interface ComputeDiskAsyncPrimaryDisk {
    /**
    * Primary disk for asynchronous disk replication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#disk ComputeDisk#disk}
    */
    readonly disk: string;
}
export declare function computeDiskAsyncPrimaryDiskToTerraform(struct?: ComputeDiskAsyncPrimaryDiskOutputReference | ComputeDiskAsyncPrimaryDisk): any;
export declare function computeDiskAsyncPrimaryDiskToHclTerraform(struct?: ComputeDiskAsyncPrimaryDiskOutputReference | ComputeDiskAsyncPrimaryDisk): any;
export declare class ComputeDiskAsyncPrimaryDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeDiskAsyncPrimaryDisk | undefined;
    set internalValue(value: ComputeDiskAsyncPrimaryDisk | undefined);
    private _disk?;
    get disk(): string;
    set disk(value: string);
    get diskInput(): string | undefined;
}
export interface ComputeDiskDiskEncryptionKey {
    /**
    * The self link of the encryption key used to encrypt the disk. Also called KmsKeyName
    * in the cloud console. Your project's Compute Engine System service account
    * ('service-{{PROJECT_NUMBER}}@compute-system.iam.gserviceaccount.com') must have
    * 'roles/cloudkms.cryptoKeyEncrypterDecrypter' to use this feature.
    * See https://cloud.google.com/compute/docs/disks/customer-managed-encryption#encrypt_a_new_persistent_disk_with_your_own_keys
    *
    * Specify the key without a '/cryptoKeyVersions/' suffix.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#kms_key_self_link ComputeDisk#kms_key_self_link}
    */
    readonly kmsKeySelfLink?: string;
    /**
    * The service account used for the encryption request for the given KMS key.
    * If absent, the Compute Engine Service Agent service account is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#kms_key_service_account ComputeDisk#kms_key_service_account}
    */
    readonly kmsKeyServiceAccount?: string;
    /**
    * Specifies a 256-bit customer-supplied encryption key, encoded in
    * RFC 4648 base64 to either encrypt or decrypt this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#raw_key ComputeDisk#raw_key}
    */
    readonly rawKey?: string;
    /**
    * Specifies a 256-bit customer-supplied encryption key, encoded in
    * RFC 4648 base64 to either encrypt or decrypt this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#raw_key_wo ComputeDisk#raw_key_wo}
    */
    readonly rawKeyWo?: string;
    /**
    * Triggers update of 'raw_key_wo' write-only. Increment this value when an update to 'raw_key_wo' is needed. For more info see [updating write-only arguments](/docs/providers/google/guides/using_write_only_arguments.html#updating-write-only-arguments)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#raw_key_wo_version ComputeDisk#raw_key_wo_version}
    */
    readonly rawKeyWoVersion?: string;
    /**
    * Specifies an RFC 4648 base64 encoded, RSA-wrapped 2048-bit
    * customer-supplied encryption key to either encrypt or decrypt
    * this resource. You can provide either the rawKey or the rsaEncryptedKey.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#rsa_encrypted_key ComputeDisk#rsa_encrypted_key}
    */
    readonly rsaEncryptedKey?: string;
    /**
    * Specifies an RFC 4648 base64 encoded, RSA-wrapped 2048-bit
    * customer-supplied encryption key to either encrypt or decrypt
    * this resource. You can provide either the rawKey or the rsaEncryptedKey.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#rsa_encrypted_key_wo ComputeDisk#rsa_encrypted_key_wo}
    */
    readonly rsaEncryptedKeyWo?: string;
    /**
    * Triggers update of 'rsa_encrypted_key_wo' write-only. Increment this value when an update to 'rsa_encrypted_key_wo' is needed. For more info see [updating write-only arguments](/docs/providers/google/guides/using_write_only_arguments.html#updating-write-only-arguments)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#rsa_encrypted_key_wo_version ComputeDisk#rsa_encrypted_key_wo_version}
    */
    readonly rsaEncryptedKeyWoVersion?: string;
}
export declare function computeDiskDiskEncryptionKeyToTerraform(struct?: ComputeDiskDiskEncryptionKeyOutputReference | ComputeDiskDiskEncryptionKey): any;
export declare function computeDiskDiskEncryptionKeyToHclTerraform(struct?: ComputeDiskDiskEncryptionKeyOutputReference | ComputeDiskDiskEncryptionKey): any;
export declare class ComputeDiskDiskEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeDiskDiskEncryptionKey | undefined;
    set internalValue(value: ComputeDiskDiskEncryptionKey | undefined);
    private _kmsKeySelfLink?;
    get kmsKeySelfLink(): string;
    set kmsKeySelfLink(value: string);
    resetKmsKeySelfLink(): void;
    get kmsKeySelfLinkInput(): string | undefined;
    private _kmsKeyServiceAccount?;
    get kmsKeyServiceAccount(): string;
    set kmsKeyServiceAccount(value: string);
    resetKmsKeyServiceAccount(): void;
    get kmsKeyServiceAccountInput(): string | undefined;
    private _rawKey?;
    get rawKey(): string;
    set rawKey(value: string);
    resetRawKey(): void;
    get rawKeyInput(): string | undefined;
    private _rawKeyWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get rawKeyWo(): string;
    set rawKeyWo(value: string);
    resetRawKeyWo(): void;
    get rawKeyWoInput(): string | undefined;
    private _rawKeyWoVersion?;
    get rawKeyWoVersion(): string;
    set rawKeyWoVersion(value: string);
    resetRawKeyWoVersion(): void;
    get rawKeyWoVersionInput(): string | undefined;
    private _rsaEncryptedKey?;
    get rsaEncryptedKey(): string;
    set rsaEncryptedKey(value: string);
    resetRsaEncryptedKey(): void;
    get rsaEncryptedKeyInput(): string | undefined;
    private _rsaEncryptedKeyWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get rsaEncryptedKeyWo(): string;
    set rsaEncryptedKeyWo(value: string);
    resetRsaEncryptedKeyWo(): void;
    get rsaEncryptedKeyWoInput(): string | undefined;
    private _rsaEncryptedKeyWoVersion?;
    get rsaEncryptedKeyWoVersion(): string;
    set rsaEncryptedKeyWoVersion(value: string);
    resetRsaEncryptedKeyWoVersion(): void;
    get rsaEncryptedKeyWoVersionInput(): string | undefined;
    get sha256(): string;
}
export interface ComputeDiskGuestOsFeatures {
    /**
    * The type of supported feature. Read [Enabling guest operating system features](https://cloud.google.com/compute/docs/images/create-delete-deprecate-private-images#guest-os-features) to see a list of available options.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#type ComputeDisk#type}
    */
    readonly type: string;
}
export declare function computeDiskGuestOsFeaturesToTerraform(struct?: ComputeDiskGuestOsFeatures | cdktn.IResolvable): any;
export declare function computeDiskGuestOsFeaturesToHclTerraform(struct?: ComputeDiskGuestOsFeatures | cdktn.IResolvable): any;
export declare class ComputeDiskGuestOsFeaturesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeDiskGuestOsFeatures | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeDiskGuestOsFeatures | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class ComputeDiskGuestOsFeaturesList extends cdktn.ComplexList {
    internalValue?: ComputeDiskGuestOsFeatures[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeDiskGuestOsFeaturesOutputReference;
}
export interface ComputeDiskParams {
    /**
    * Resource manager tags to be bound to the disk. Tag keys and values have the
    * same definition as resource manager tags. Keys must be in the format tagKeys/{tag_key_id},
    * and values are in the format tagValues/456.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#resource_manager_tags ComputeDisk#resource_manager_tags}
    */
    readonly resourceManagerTags?: {
        [key: string]: string;
    };
}
export declare function computeDiskParamsToTerraform(struct?: ComputeDiskParamsOutputReference | ComputeDiskParams): any;
export declare function computeDiskParamsToHclTerraform(struct?: ComputeDiskParamsOutputReference | ComputeDiskParams): any;
export declare class ComputeDiskParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeDiskParams | undefined;
    set internalValue(value: ComputeDiskParams | undefined);
    private _resourceManagerTags?;
    get resourceManagerTags(): {
        [key: string]: string;
    };
    set resourceManagerTags(value: {
        [key: string]: string;
    });
    resetResourceManagerTags(): void;
    get resourceManagerTagsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ComputeDiskSourceImageEncryptionKey {
    /**
    * The self link of the encryption key used to encrypt the disk. Also called KmsKeyName
    * in the cloud console. Your project's Compute Engine System service account
    * ('service-{{PROJECT_NUMBER}}@compute-system.iam.gserviceaccount.com') must have
    * 'roles/cloudkms.cryptoKeyEncrypterDecrypter' to use this feature.
    * See https://cloud.google.com/compute/docs/disks/customer-managed-encryption#encrypt_a_new_persistent_disk_with_your_own_keys
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#kms_key_self_link ComputeDisk#kms_key_self_link}
    */
    readonly kmsKeySelfLink?: string;
    /**
    * The service account used for the encryption request for the given KMS key.
    * If absent, the Compute Engine Service Agent service account is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#kms_key_service_account ComputeDisk#kms_key_service_account}
    */
    readonly kmsKeyServiceAccount?: string;
    /**
    * Specifies a 256-bit customer-supplied encryption key, encoded in
    * RFC 4648 base64 to either encrypt or decrypt this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#raw_key ComputeDisk#raw_key}
    */
    readonly rawKey?: string;
}
export declare function computeDiskSourceImageEncryptionKeyToTerraform(struct?: ComputeDiskSourceImageEncryptionKeyOutputReference | ComputeDiskSourceImageEncryptionKey): any;
export declare function computeDiskSourceImageEncryptionKeyToHclTerraform(struct?: ComputeDiskSourceImageEncryptionKeyOutputReference | ComputeDiskSourceImageEncryptionKey): any;
export declare class ComputeDiskSourceImageEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeDiskSourceImageEncryptionKey | undefined;
    set internalValue(value: ComputeDiskSourceImageEncryptionKey | undefined);
    private _kmsKeySelfLink?;
    get kmsKeySelfLink(): string;
    set kmsKeySelfLink(value: string);
    resetKmsKeySelfLink(): void;
    get kmsKeySelfLinkInput(): string | undefined;
    private _kmsKeyServiceAccount?;
    get kmsKeyServiceAccount(): string;
    set kmsKeyServiceAccount(value: string);
    resetKmsKeyServiceAccount(): void;
    get kmsKeyServiceAccountInput(): string | undefined;
    private _rawKey?;
    get rawKey(): string;
    set rawKey(value: string);
    resetRawKey(): void;
    get rawKeyInput(): string | undefined;
    get sha256(): string;
}
export interface ComputeDiskSourceSnapshotEncryptionKey {
    /**
    * The self link of the encryption key used to encrypt the disk. Also called KmsKeyName
    * in the cloud console. Your project's Compute Engine System service account
    * ('service-{{PROJECT_NUMBER}}@compute-system.iam.gserviceaccount.com') must have
    * 'roles/cloudkms.cryptoKeyEncrypterDecrypter' to use this feature.
    * See https://cloud.google.com/compute/docs/disks/customer-managed-encryption#encrypt_a_new_persistent_disk_with_your_own_keys
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#kms_key_self_link ComputeDisk#kms_key_self_link}
    */
    readonly kmsKeySelfLink?: string;
    /**
    * The service account used for the encryption request for the given KMS key.
    * If absent, the Compute Engine Service Agent service account is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#kms_key_service_account ComputeDisk#kms_key_service_account}
    */
    readonly kmsKeyServiceAccount?: string;
    /**
    * Specifies a 256-bit customer-supplied encryption key, encoded in
    * RFC 4648 base64 to either encrypt or decrypt this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#raw_key ComputeDisk#raw_key}
    */
    readonly rawKey?: string;
}
export declare function computeDiskSourceSnapshotEncryptionKeyToTerraform(struct?: ComputeDiskSourceSnapshotEncryptionKeyOutputReference | ComputeDiskSourceSnapshotEncryptionKey): any;
export declare function computeDiskSourceSnapshotEncryptionKeyToHclTerraform(struct?: ComputeDiskSourceSnapshotEncryptionKeyOutputReference | ComputeDiskSourceSnapshotEncryptionKey): any;
export declare class ComputeDiskSourceSnapshotEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeDiskSourceSnapshotEncryptionKey | undefined;
    set internalValue(value: ComputeDiskSourceSnapshotEncryptionKey | undefined);
    private _kmsKeySelfLink?;
    get kmsKeySelfLink(): string;
    set kmsKeySelfLink(value: string);
    resetKmsKeySelfLink(): void;
    get kmsKeySelfLinkInput(): string | undefined;
    private _kmsKeyServiceAccount?;
    get kmsKeyServiceAccount(): string;
    set kmsKeyServiceAccount(value: string);
    resetKmsKeyServiceAccount(): void;
    get kmsKeyServiceAccountInput(): string | undefined;
    private _rawKey?;
    get rawKey(): string;
    set rawKey(value: string);
    resetRawKey(): void;
    get rawKeyInput(): string | undefined;
    get sha256(): string;
}
export interface ComputeDiskTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#create ComputeDisk#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#delete ComputeDisk#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#update ComputeDisk#update}
    */
    readonly update?: string;
}
export declare function computeDiskTimeoutsToTerraform(struct?: ComputeDiskTimeouts | cdktn.IResolvable): any;
export declare function computeDiskTimeoutsToHclTerraform(struct?: ComputeDiskTimeouts | cdktn.IResolvable): any;
export declare class ComputeDiskTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeDiskTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeDiskTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk google_compute_disk}
*/
export declare class ComputeDisk extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_disk";
    /**
    * Generates CDKTN code for importing a ComputeDisk resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeDisk to import
    * @param importFromId The id of the existing ComputeDisk that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeDisk to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_disk google_compute_disk} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeDiskConfig
    */
    constructor(scope: Construct, id: string, config: ComputeDiskConfig);
    private _accessMode?;
    get accessMode(): string;
    set accessMode(value: string);
    resetAccessMode(): void;
    get accessModeInput(): string | undefined;
    private _architecture?;
    get architecture(): string;
    set architecture(value: string);
    resetArchitecture(): void;
    get architectureInput(): string | undefined;
    private _createSnapshotBeforeDestroy?;
    get createSnapshotBeforeDestroy(): boolean | cdktn.IResolvable;
    set createSnapshotBeforeDestroy(value: boolean | cdktn.IResolvable);
    resetCreateSnapshotBeforeDestroy(): void;
    get createSnapshotBeforeDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _createSnapshotBeforeDestroyPrefix?;
    get createSnapshotBeforeDestroyPrefix(): string;
    set createSnapshotBeforeDestroyPrefix(value: string);
    resetCreateSnapshotBeforeDestroyPrefix(): void;
    get createSnapshotBeforeDestroyPrefixInput(): string | undefined;
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get diskId(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _enableConfidentialCompute?;
    get enableConfidentialCompute(): boolean | cdktn.IResolvable;
    set enableConfidentialCompute(value: boolean | cdktn.IResolvable);
    resetEnableConfidentialCompute(): void;
    get enableConfidentialComputeInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _image?;
    get image(): string;
    set image(value: string);
    resetImage(): void;
    get imageInput(): string | undefined;
    get labelFingerprint(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    get lastAttachTimestamp(): string;
    get lastDetachTimestamp(): string;
    private _licenses?;
    get licenses(): string[];
    set licenses(value: string[]);
    resetLicenses(): void;
    get licensesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _physicalBlockSizeBytes?;
    get physicalBlockSizeBytes(): number;
    set physicalBlockSizeBytes(value: number);
    resetPhysicalBlockSizeBytes(): void;
    get physicalBlockSizeBytesInput(): number | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _provisionedIops?;
    get provisionedIops(): number;
    set provisionedIops(value: number);
    resetProvisionedIops(): void;
    get provisionedIopsInput(): number | undefined;
    private _provisionedThroughput?;
    get provisionedThroughput(): number;
    set provisionedThroughput(value: number);
    resetProvisionedThroughput(): void;
    get provisionedThroughputInput(): number | undefined;
    get selfLink(): string;
    private _size?;
    get size(): number;
    set size(value: number);
    resetSize(): void;
    get sizeInput(): number | undefined;
    private _snapshot?;
    get snapshot(): string;
    set snapshot(value: string);
    resetSnapshot(): void;
    get snapshotInput(): string | undefined;
    private _sourceDisk?;
    get sourceDisk(): string;
    set sourceDisk(value: string);
    resetSourceDisk(): void;
    get sourceDiskInput(): string | undefined;
    get sourceDiskId(): string;
    get sourceImageId(): string;
    private _sourceInstantSnapshot?;
    get sourceInstantSnapshot(): string;
    set sourceInstantSnapshot(value: string);
    resetSourceInstantSnapshot(): void;
    get sourceInstantSnapshotInput(): string | undefined;
    get sourceInstantSnapshotId(): string;
    get sourceSnapshotId(): string;
    private _sourceStorageObject?;
    get sourceStorageObject(): string;
    set sourceStorageObject(value: string);
    resetSourceStorageObject(): void;
    get sourceStorageObjectInput(): string | undefined;
    private _storagePool?;
    get storagePool(): string;
    set storagePool(value: string);
    resetStoragePool(): void;
    get storagePoolInput(): string | undefined;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    get users(): string[];
    private _zone?;
    get zone(): string;
    set zone(value: string);
    resetZone(): void;
    get zoneInput(): string | undefined;
    private _asyncPrimaryDisk;
    get asyncPrimaryDisk(): ComputeDiskAsyncPrimaryDiskOutputReference;
    putAsyncPrimaryDisk(value: ComputeDiskAsyncPrimaryDisk): void;
    resetAsyncPrimaryDisk(): void;
    get asyncPrimaryDiskInput(): ComputeDiskAsyncPrimaryDisk | undefined;
    private _diskEncryptionKey;
    get diskEncryptionKey(): ComputeDiskDiskEncryptionKeyOutputReference;
    putDiskEncryptionKey(value: ComputeDiskDiskEncryptionKey): void;
    resetDiskEncryptionKey(): void;
    get diskEncryptionKeyInput(): ComputeDiskDiskEncryptionKey | undefined;
    private _guestOsFeatures;
    get guestOsFeatures(): ComputeDiskGuestOsFeaturesList;
    putGuestOsFeatures(value: ComputeDiskGuestOsFeatures[] | cdktn.IResolvable): void;
    resetGuestOsFeatures(): void;
    get guestOsFeaturesInput(): cdktn.IResolvable | ComputeDiskGuestOsFeatures[] | undefined;
    private _params;
    get params(): ComputeDiskParamsOutputReference;
    putParams(value: ComputeDiskParams): void;
    resetParams(): void;
    get paramsInput(): ComputeDiskParams | undefined;
    private _sourceImageEncryptionKey;
    get sourceImageEncryptionKey(): ComputeDiskSourceImageEncryptionKeyOutputReference;
    putSourceImageEncryptionKey(value: ComputeDiskSourceImageEncryptionKey): void;
    resetSourceImageEncryptionKey(): void;
    get sourceImageEncryptionKeyInput(): ComputeDiskSourceImageEncryptionKey | undefined;
    private _sourceSnapshotEncryptionKey;
    get sourceSnapshotEncryptionKey(): ComputeDiskSourceSnapshotEncryptionKeyOutputReference;
    putSourceSnapshotEncryptionKey(value: ComputeDiskSourceSnapshotEncryptionKey): void;
    resetSourceSnapshotEncryptionKey(): void;
    get sourceSnapshotEncryptionKeyInput(): ComputeDiskSourceSnapshotEncryptionKey | undefined;
    private _timeouts;
    get timeouts(): ComputeDiskTimeoutsOutputReference;
    putTimeouts(value: ComputeDiskTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeDiskTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
