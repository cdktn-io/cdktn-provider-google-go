/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeRegionNetworkFirewallPolicyWithRulesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#deletion_policy ComputeRegionNetworkFirewallPolicyWithRules#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#description ComputeRegionNetworkFirewallPolicyWithRules#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#id ComputeRegionNetworkFirewallPolicyWithRules#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * User-provided name of the Network firewall policy.
    * The name should be unique in the project in which the firewall policy is created.
    * The name must be 1-63 characters long, and comply with RFC1035. Specifically,
    * the name must be 1-63 characters long and match the regular expression [a-z]([-a-z0-9]*[a-z0-9])?
    * which means the first character must be a lowercase letter, and all following characters must be a dash,
    * lowercase letter, or digit, except the last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#name ComputeRegionNetworkFirewallPolicyWithRules#name}
    */
    readonly name: string;
    /**
    * Policy type is used to determine which resources (networks) the policy can be associated with.
    * A policy can be associated with a network only if the network has the matching policyType in its network profile.
    * Different policy types may support some of the Firewall Rules features. Possible values: ["VPC_POLICY", "RDMA_ROCE_POLICY", "RDMA_FALCON_POLICY", "ULL_POLICY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#policy_type ComputeRegionNetworkFirewallPolicyWithRules#policy_type}
    */
    readonly policyType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#project ComputeRegionNetworkFirewallPolicyWithRules#project}
    */
    readonly project?: string;
    /**
    * The region of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#region ComputeRegionNetworkFirewallPolicyWithRules#region}
    */
    readonly region?: string;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#rule ComputeRegionNetworkFirewallPolicyWithRules#rule}
    */
    readonly rule: ComputeRegionNetworkFirewallPolicyWithRulesRule[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#timeouts ComputeRegionNetworkFirewallPolicyWithRules#timeouts}
    */
    readonly timeouts?: ComputeRegionNetworkFirewallPolicyWithRulesTimeouts;
}
export interface ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchLayer4Config {
}
export declare function computeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchLayer4ConfigToTerraform(struct?: ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchLayer4Config): any;
export declare function computeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchLayer4ConfigToHclTerraform(struct?: ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchLayer4Config): any;
export declare class ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchLayer4ConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchLayer4Config | undefined;
    set internalValue(value: ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchLayer4Config | undefined);
    get ipProtocol(): string;
    get ports(): string[];
}
export declare class ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchLayer4ConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchLayer4ConfigOutputReference;
}
export interface ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchSrcSecureTag {
}
export declare function computeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchSrcSecureTagToTerraform(struct?: ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchSrcSecureTag): any;
export declare function computeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchSrcSecureTagToHclTerraform(struct?: ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchSrcSecureTag): any;
export declare class ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchSrcSecureTagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchSrcSecureTag | undefined;
    set internalValue(value: ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchSrcSecureTag | undefined);
    get name(): string;
    get state(): string;
}
export declare class ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchSrcSecureTagList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchSrcSecureTagOutputReference;
}
export interface ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatch {
}
export declare function computeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchToTerraform(struct?: ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatch): any;
export declare function computeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchToHclTerraform(struct?: ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatch): any;
export declare class ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatch | undefined;
    set internalValue(value: ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatch | undefined);
    get destAddressGroups(): string[];
    get destFqdns(): string[];
    get destIpRanges(): string[];
    get destRegionCodes(): string[];
    get destThreatIntelligences(): string[];
    private _layer4Config;
    get layer4Config(): ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchLayer4ConfigList;
    get srcAddressGroups(): string[];
    get srcFqdns(): string[];
    get srcIpRanges(): string[];
    get srcRegionCodes(): string[];
    private _srcSecureTag;
    get srcSecureTag(): ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchSrcSecureTagList;
    get srcThreatIntelligences(): string[];
}
export declare class ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchOutputReference;
}
export interface ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesTargetSecureTag {
}
export declare function computeRegionNetworkFirewallPolicyWithRulesPredefinedRulesTargetSecureTagToTerraform(struct?: ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesTargetSecureTag): any;
export declare function computeRegionNetworkFirewallPolicyWithRulesPredefinedRulesTargetSecureTagToHclTerraform(struct?: ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesTargetSecureTag): any;
export declare class ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesTargetSecureTagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesTargetSecureTag | undefined;
    set internalValue(value: ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesTargetSecureTag | undefined);
    get name(): string;
    get state(): string;
}
export declare class ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesTargetSecureTagList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesTargetSecureTagOutputReference;
}
export interface ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRules {
}
export declare function computeRegionNetworkFirewallPolicyWithRulesPredefinedRulesToTerraform(struct?: ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRules): any;
export declare function computeRegionNetworkFirewallPolicyWithRulesPredefinedRulesToHclTerraform(struct?: ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRules): any;
export declare class ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRules | undefined;
    set internalValue(value: ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRules | undefined);
    get action(): string;
    get description(): string;
    get direction(): string;
    get disabled(): cdktn.IResolvable;
    get enableLogging(): cdktn.IResolvable;
    private _match;
    get match(): ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesMatchList;
    get priority(): number;
    get ruleName(): string;
    get securityProfileGroup(): string;
    private _targetSecureTag;
    get targetSecureTag(): ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesTargetSecureTagList;
    get targetServiceAccounts(): string[];
    get tlsInspect(): cdktn.IResolvable;
}
export declare class ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesOutputReference;
}
export interface ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchLayer4Config {
    /**
    * The IP protocol to which this rule applies. The protocol
    * type is required when creating a firewall rule.
    * This value can either be one of the following well
    * known protocol strings (tcp, udp, icmp, esp, ah, ipip, sctp),
    * or the IP protocol number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#ip_protocol ComputeRegionNetworkFirewallPolicyWithRules#ip_protocol}
    */
    readonly ipProtocol: string;
    /**
    * An optional list of ports to which this rule applies. This field
    * is only applicable for UDP or TCP protocol. Each entry must be
    * either an integer or a range. If not specified, this rule
    * applies to connections through any port.
    * Example inputs include: ["22"], ["80","443"], and
    * ["12345-12349"].
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#ports ComputeRegionNetworkFirewallPolicyWithRules#ports}
    */
    readonly ports?: string[];
}
export declare function computeRegionNetworkFirewallPolicyWithRulesRuleMatchLayer4ConfigToTerraform(struct?: ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchLayer4Config | cdktn.IResolvable): any;
export declare function computeRegionNetworkFirewallPolicyWithRulesRuleMatchLayer4ConfigToHclTerraform(struct?: ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchLayer4Config | cdktn.IResolvable): any;
export declare class ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchLayer4ConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchLayer4Config | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchLayer4Config | cdktn.IResolvable | undefined);
    private _ipProtocol?;
    get ipProtocol(): string;
    set ipProtocol(value: string);
    get ipProtocolInput(): string | undefined;
    private _ports?;
    get ports(): string[];
    set ports(value: string[]);
    resetPorts(): void;
    get portsInput(): string[] | undefined;
}
export declare class ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchLayer4ConfigList extends cdktn.ComplexList {
    internalValue?: ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchLayer4Config[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchLayer4ConfigOutputReference;
}
export interface ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTag {
    /**
    * Name of the secure tag, created with TagManager's TagValue API.
    * @pattern tagValues/[0-9]+
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#name ComputeRegionNetworkFirewallPolicyWithRules#name}
    */
    readonly name?: string;
}
export declare function computeRegionNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTagToTerraform(struct?: ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTag | cdktn.IResolvable): any;
export declare function computeRegionNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTagToHclTerraform(struct?: ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTag | cdktn.IResolvable): any;
export declare class ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTag | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTag | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get state(): string;
}
export declare class ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTagList extends cdktn.ComplexList {
    internalValue?: ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTag[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTagOutputReference;
}
export interface ComputeRegionNetworkFirewallPolicyWithRulesRuleMatch {
    /**
    * Address groups which should be matched against the traffic destination.
    * Maximum number of destination address groups is 10.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#dest_address_groups ComputeRegionNetworkFirewallPolicyWithRules#dest_address_groups}
    */
    readonly destAddressGroups?: string[];
    /**
    * Fully Qualified Domain Name (FQDN) which should be matched against
    * traffic destination. Maximum number of destination fqdn allowed is 100.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#dest_fqdns ComputeRegionNetworkFirewallPolicyWithRules#dest_fqdns}
    */
    readonly destFqdns?: string[];
    /**
    * Destination IP address range in CIDR format. Required for
    * EGRESS rules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#dest_ip_ranges ComputeRegionNetworkFirewallPolicyWithRules#dest_ip_ranges}
    */
    readonly destIpRanges?: string[];
    /**
    * Region codes whose IP addresses will be used to match for destination
    * of traffic. Should be specified as 2 letter country code defined as per
    * ISO 3166 alpha-2 country codes. ex."US"
    * Maximum number of destination region codes allowed is 5000.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#dest_region_codes ComputeRegionNetworkFirewallPolicyWithRules#dest_region_codes}
    */
    readonly destRegionCodes?: string[];
    /**
    * Names of Network Threat Intelligence lists.
    * The IPs in these lists will be matched against traffic destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#dest_threat_intelligences ComputeRegionNetworkFirewallPolicyWithRules#dest_threat_intelligences}
    */
    readonly destThreatIntelligences?: string[];
    /**
    * Address groups which should be matched against the traffic source.
    * Maximum number of source address groups is 10.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#src_address_groups ComputeRegionNetworkFirewallPolicyWithRules#src_address_groups}
    */
    readonly srcAddressGroups?: string[];
    /**
    * Fully Qualified Domain Name (FQDN) which should be matched against
    * traffic source. Maximum number of source fqdn allowed is 100.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#src_fqdns ComputeRegionNetworkFirewallPolicyWithRules#src_fqdns}
    */
    readonly srcFqdns?: string[];
    /**
    * Source IP address range in CIDR format. Required for
    * INGRESS rules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#src_ip_ranges ComputeRegionNetworkFirewallPolicyWithRules#src_ip_ranges}
    */
    readonly srcIpRanges?: string[];
    /**
    * Region codes whose IP addresses will be used to match for source
    * of traffic. Should be specified as 2 letter country code defined as per
    * ISO 3166 alpha-2 country codes. ex."US"
    * Maximum number of source region codes allowed is 5000.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#src_region_codes ComputeRegionNetworkFirewallPolicyWithRules#src_region_codes}
    */
    readonly srcRegionCodes?: string[];
    /**
    * Names of Network Threat Intelligence lists.
    * The IPs in these lists will be matched against traffic source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#src_threat_intelligences ComputeRegionNetworkFirewallPolicyWithRules#src_threat_intelligences}
    */
    readonly srcThreatIntelligences?: string[];
    /**
    * layer4_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#layer4_config ComputeRegionNetworkFirewallPolicyWithRules#layer4_config}
    */
    readonly layer4Config: ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchLayer4Config[] | cdktn.IResolvable;
    /**
    * src_secure_tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#src_secure_tag ComputeRegionNetworkFirewallPolicyWithRules#src_secure_tag}
    */
    readonly srcSecureTag?: ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTag[] | cdktn.IResolvable;
}
export declare function computeRegionNetworkFirewallPolicyWithRulesRuleMatchToTerraform(struct?: ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchOutputReference | ComputeRegionNetworkFirewallPolicyWithRulesRuleMatch): any;
export declare function computeRegionNetworkFirewallPolicyWithRulesRuleMatchToHclTerraform(struct?: ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchOutputReference | ComputeRegionNetworkFirewallPolicyWithRulesRuleMatch): any;
export declare class ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionNetworkFirewallPolicyWithRulesRuleMatch | undefined;
    set internalValue(value: ComputeRegionNetworkFirewallPolicyWithRulesRuleMatch | undefined);
    private _destAddressGroups?;
    get destAddressGroups(): string[];
    set destAddressGroups(value: string[]);
    resetDestAddressGroups(): void;
    get destAddressGroupsInput(): string[] | undefined;
    private _destFqdns?;
    get destFqdns(): string[];
    set destFqdns(value: string[]);
    resetDestFqdns(): void;
    get destFqdnsInput(): string[] | undefined;
    private _destIpRanges?;
    get destIpRanges(): string[];
    set destIpRanges(value: string[]);
    resetDestIpRanges(): void;
    get destIpRangesInput(): string[] | undefined;
    private _destRegionCodes?;
    get destRegionCodes(): string[];
    set destRegionCodes(value: string[]);
    resetDestRegionCodes(): void;
    get destRegionCodesInput(): string[] | undefined;
    private _destThreatIntelligences?;
    get destThreatIntelligences(): string[];
    set destThreatIntelligences(value: string[]);
    resetDestThreatIntelligences(): void;
    get destThreatIntelligencesInput(): string[] | undefined;
    private _srcAddressGroups?;
    get srcAddressGroups(): string[];
    set srcAddressGroups(value: string[]);
    resetSrcAddressGroups(): void;
    get srcAddressGroupsInput(): string[] | undefined;
    private _srcFqdns?;
    get srcFqdns(): string[];
    set srcFqdns(value: string[]);
    resetSrcFqdns(): void;
    get srcFqdnsInput(): string[] | undefined;
    private _srcIpRanges?;
    get srcIpRanges(): string[];
    set srcIpRanges(value: string[]);
    resetSrcIpRanges(): void;
    get srcIpRangesInput(): string[] | undefined;
    private _srcRegionCodes?;
    get srcRegionCodes(): string[];
    set srcRegionCodes(value: string[]);
    resetSrcRegionCodes(): void;
    get srcRegionCodesInput(): string[] | undefined;
    private _srcThreatIntelligences?;
    get srcThreatIntelligences(): string[];
    set srcThreatIntelligences(value: string[]);
    resetSrcThreatIntelligences(): void;
    get srcThreatIntelligencesInput(): string[] | undefined;
    private _layer4Config;
    get layer4Config(): ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchLayer4ConfigList;
    putLayer4Config(value: ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchLayer4Config[] | cdktn.IResolvable): void;
    get layer4ConfigInput(): cdktn.IResolvable | ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchLayer4Config[] | undefined;
    private _srcSecureTag;
    get srcSecureTag(): ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTagList;
    putSrcSecureTag(value: ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTag[] | cdktn.IResolvable): void;
    resetSrcSecureTag(): void;
    get srcSecureTagInput(): cdktn.IResolvable | ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTag[] | undefined;
}
export interface ComputeRegionNetworkFirewallPolicyWithRulesRuleTargetSecureTag {
    /**
    * Name of the secure tag, created with TagManager's TagValue API.
    * @pattern tagValues/[0-9]+
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#name ComputeRegionNetworkFirewallPolicyWithRules#name}
    */
    readonly name?: string;
}
export declare function computeRegionNetworkFirewallPolicyWithRulesRuleTargetSecureTagToTerraform(struct?: ComputeRegionNetworkFirewallPolicyWithRulesRuleTargetSecureTag | cdktn.IResolvable): any;
export declare function computeRegionNetworkFirewallPolicyWithRulesRuleTargetSecureTagToHclTerraform(struct?: ComputeRegionNetworkFirewallPolicyWithRulesRuleTargetSecureTag | cdktn.IResolvable): any;
export declare class ComputeRegionNetworkFirewallPolicyWithRulesRuleTargetSecureTagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionNetworkFirewallPolicyWithRulesRuleTargetSecureTag | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionNetworkFirewallPolicyWithRulesRuleTargetSecureTag | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get state(): string;
}
export declare class ComputeRegionNetworkFirewallPolicyWithRulesRuleTargetSecureTagList extends cdktn.ComplexList {
    internalValue?: ComputeRegionNetworkFirewallPolicyWithRulesRuleTargetSecureTag[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionNetworkFirewallPolicyWithRulesRuleTargetSecureTagOutputReference;
}
export interface ComputeRegionNetworkFirewallPolicyWithRulesRule {
    /**
    * The Action to perform when the client connection triggers the rule. Can currently be either
    * "allow", "deny", "apply_security_profile_group" or "goto_next".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#action ComputeRegionNetworkFirewallPolicyWithRules#action}
    */
    readonly action: string;
    /**
    * A description of the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#description ComputeRegionNetworkFirewallPolicyWithRules#description}
    */
    readonly description?: string;
    /**
    * The direction in which this rule applies. If unspecified an INGRESS rule is created. Possible values: ["INGRESS", "EGRESS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#direction ComputeRegionNetworkFirewallPolicyWithRules#direction}
    */
    readonly direction?: string;
    /**
    * Denotes whether the firewall policy rule is disabled. When set to true,
    * the firewall policy rule is not enforced and traffic behaves as if it did
    * not exist. If this is unspecified, the firewall policy rule will be
    * enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#disabled ComputeRegionNetworkFirewallPolicyWithRules#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Denotes whether to enable logging for a particular rule.
    * If logging is enabled, logs will be exported to the
    * configured export destination in Stackdriver.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#enable_logging ComputeRegionNetworkFirewallPolicyWithRules#enable_logging}
    */
    readonly enableLogging?: boolean | cdktn.IResolvable;
    /**
    * An integer indicating the priority of a rule in the list. The priority must be a value
    * between 0 and 2147483647. Rules are evaluated from highest to lowest priority where 0 is the
    * highest priority and 2147483647 is the lowest priority.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#priority ComputeRegionNetworkFirewallPolicyWithRules#priority}
    */
    readonly priority: number;
    /**
    * An optional name for the rule. This field is not a unique identifier
    * and can be updated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#rule_name ComputeRegionNetworkFirewallPolicyWithRules#rule_name}
    */
    readonly ruleName?: string;
    /**
    * A fully-qualified URL of a SecurityProfile resource instance.
    * Example:
    * https://networksecurity.googleapis.com/v1/projects/{project}/locations/{location}/securityProfileGroups/my-security-profile-group
    * Must be specified if action is 'apply_security_profile_group'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#security_profile_group ComputeRegionNetworkFirewallPolicyWithRules#security_profile_group}
    */
    readonly securityProfileGroup?: string;
    /**
    * A list of forwarding rules to which this rule applies.
    * This field allows you to control which load balancers get this rule.
    * For example, the following are valid values:
    * - https://www.googleapis.com/compute/v1/projects/project/global/forwardingRules/forwardingRule
    * - https://www.googleapis.com/compute/v1/projects/project/regions/region/forwardingRules/forwardingRule
    * - projects/project/global/forwardingRules/forwardingRule
    * - projects/project/regions/region/forwardingRules/forwardingRule
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#target_forwarding_rules ComputeRegionNetworkFirewallPolicyWithRules#target_forwarding_rules}
    */
    readonly targetForwardingRules?: string[];
    /**
    * A list of service accounts indicating the sets of
    * instances that are applied with this rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#target_service_accounts ComputeRegionNetworkFirewallPolicyWithRules#target_service_accounts}
    */
    readonly targetServiceAccounts?: string[];
    /**
    * Target types of the firewall policy rule.
    * Default value is INSTANCES.
    * When target_type is INTERNAL_MANAGED_LB, target_forwarding_rules must be set Possible values: ["INSTANCES", "INTERNAL_MANAGED_LB"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#target_type ComputeRegionNetworkFirewallPolicyWithRules#target_type}
    */
    readonly targetType?: string;
    /**
    * Boolean flag indicating if the traffic should be TLS decrypted.
    * It can be set only if action = 'apply_security_profile_group' and cannot be set for other actions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#tls_inspect ComputeRegionNetworkFirewallPolicyWithRules#tls_inspect}
    */
    readonly tlsInspect?: boolean | cdktn.IResolvable;
    /**
    * match block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#match ComputeRegionNetworkFirewallPolicyWithRules#match}
    */
    readonly match: ComputeRegionNetworkFirewallPolicyWithRulesRuleMatch;
    /**
    * target_secure_tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#target_secure_tag ComputeRegionNetworkFirewallPolicyWithRules#target_secure_tag}
    */
    readonly targetSecureTag?: ComputeRegionNetworkFirewallPolicyWithRulesRuleTargetSecureTag[] | cdktn.IResolvable;
}
export declare function computeRegionNetworkFirewallPolicyWithRulesRuleToTerraform(struct?: ComputeRegionNetworkFirewallPolicyWithRulesRule | cdktn.IResolvable): any;
export declare function computeRegionNetworkFirewallPolicyWithRulesRuleToHclTerraform(struct?: ComputeRegionNetworkFirewallPolicyWithRulesRule | cdktn.IResolvable): any;
export declare class ComputeRegionNetworkFirewallPolicyWithRulesRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionNetworkFirewallPolicyWithRulesRule | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionNetworkFirewallPolicyWithRulesRule | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _enableLogging?;
    get enableLogging(): boolean | cdktn.IResolvable;
    set enableLogging(value: boolean | cdktn.IResolvable);
    resetEnableLogging(): void;
    get enableLoggingInput(): boolean | cdktn.IResolvable | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
    private _ruleName?;
    get ruleName(): string;
    set ruleName(value: string);
    resetRuleName(): void;
    get ruleNameInput(): string | undefined;
    private _securityProfileGroup?;
    get securityProfileGroup(): string;
    set securityProfileGroup(value: string);
    resetSecurityProfileGroup(): void;
    get securityProfileGroupInput(): string | undefined;
    private _targetForwardingRules?;
    get targetForwardingRules(): string[];
    set targetForwardingRules(value: string[]);
    resetTargetForwardingRules(): void;
    get targetForwardingRulesInput(): string[] | undefined;
    private _targetServiceAccounts?;
    get targetServiceAccounts(): string[];
    set targetServiceAccounts(value: string[]);
    resetTargetServiceAccounts(): void;
    get targetServiceAccountsInput(): string[] | undefined;
    private _targetType?;
    get targetType(): string;
    set targetType(value: string);
    resetTargetType(): void;
    get targetTypeInput(): string | undefined;
    private _tlsInspect?;
    get tlsInspect(): boolean | cdktn.IResolvable;
    set tlsInspect(value: boolean | cdktn.IResolvable);
    resetTlsInspect(): void;
    get tlsInspectInput(): boolean | cdktn.IResolvable | undefined;
    private _match;
    get match(): ComputeRegionNetworkFirewallPolicyWithRulesRuleMatchOutputReference;
    putMatch(value: ComputeRegionNetworkFirewallPolicyWithRulesRuleMatch): void;
    get matchInput(): ComputeRegionNetworkFirewallPolicyWithRulesRuleMatch | undefined;
    private _targetSecureTag;
    get targetSecureTag(): ComputeRegionNetworkFirewallPolicyWithRulesRuleTargetSecureTagList;
    putTargetSecureTag(value: ComputeRegionNetworkFirewallPolicyWithRulesRuleTargetSecureTag[] | cdktn.IResolvable): void;
    resetTargetSecureTag(): void;
    get targetSecureTagInput(): cdktn.IResolvable | ComputeRegionNetworkFirewallPolicyWithRulesRuleTargetSecureTag[] | undefined;
}
export declare class ComputeRegionNetworkFirewallPolicyWithRulesRuleList extends cdktn.ComplexList {
    internalValue?: ComputeRegionNetworkFirewallPolicyWithRulesRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionNetworkFirewallPolicyWithRulesRuleOutputReference;
}
export interface ComputeRegionNetworkFirewallPolicyWithRulesTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#create ComputeRegionNetworkFirewallPolicyWithRules#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#delete ComputeRegionNetworkFirewallPolicyWithRules#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#update ComputeRegionNetworkFirewallPolicyWithRules#update}
    */
    readonly update?: string;
}
export declare function computeRegionNetworkFirewallPolicyWithRulesTimeoutsToTerraform(struct?: ComputeRegionNetworkFirewallPolicyWithRulesTimeouts | cdktn.IResolvable): any;
export declare function computeRegionNetworkFirewallPolicyWithRulesTimeoutsToHclTerraform(struct?: ComputeRegionNetworkFirewallPolicyWithRulesTimeouts | cdktn.IResolvable): any;
export declare class ComputeRegionNetworkFirewallPolicyWithRulesTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionNetworkFirewallPolicyWithRulesTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionNetworkFirewallPolicyWithRulesTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules google_compute_region_network_firewall_policy_with_rules}
*/
export declare class ComputeRegionNetworkFirewallPolicyWithRules extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_region_network_firewall_policy_with_rules";
    /**
    * Generates CDKTN code for importing a ComputeRegionNetworkFirewallPolicyWithRules resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeRegionNetworkFirewallPolicyWithRules to import
    * @param importFromId The id of the existing ComputeRegionNetworkFirewallPolicyWithRules that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeRegionNetworkFirewallPolicyWithRules to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_firewall_policy_with_rules google_compute_region_network_firewall_policy_with_rules} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeRegionNetworkFirewallPolicyWithRulesConfig
    */
    constructor(scope: Construct, id: string, config: ComputeRegionNetworkFirewallPolicyWithRulesConfig);
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get fingerprint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get networkFirewallPolicyId(): string;
    private _policyType?;
    get policyType(): string;
    set policyType(value: string);
    resetPolicyType(): void;
    get policyTypeInput(): string | undefined;
    private _predefinedRules;
    get predefinedRules(): ComputeRegionNetworkFirewallPolicyWithRulesPredefinedRulesList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get ruleTupleCount(): number;
    get selfLink(): string;
    get selfLinkWithId(): string;
    private _rule;
    get rule(): ComputeRegionNetworkFirewallPolicyWithRulesRuleList;
    putRule(value: ComputeRegionNetworkFirewallPolicyWithRulesRule[] | cdktn.IResolvable): void;
    get ruleInput(): cdktn.IResolvable | ComputeRegionNetworkFirewallPolicyWithRulesRule[] | undefined;
    private _timeouts;
    get timeouts(): ComputeRegionNetworkFirewallPolicyWithRulesTimeoutsOutputReference;
    putTimeouts(value: ComputeRegionNetworkFirewallPolicyWithRulesTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeRegionNetworkFirewallPolicyWithRulesTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
