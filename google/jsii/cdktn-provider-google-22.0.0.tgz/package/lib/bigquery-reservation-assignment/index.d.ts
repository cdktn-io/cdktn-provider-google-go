/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BigqueryReservationAssignmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * The resource which will use the reservation. E.g. projects/myproject, folders/123, organizations/456.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_reservation_assignment#assignee BigqueryReservationAssignment#assignee}
    */
    readonly assignee: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_reservation_assignment#deletion_policy BigqueryReservationAssignment#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_reservation_assignment#id BigqueryReservationAssignment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Types of job, which could be specified when using the reservation. Possible values: JOB_TYPE_UNSPECIFIED, PIPELINE, QUERY, CONTINUOUS
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_reservation_assignment#job_type BigqueryReservationAssignment#job_type}
    */
    readonly jobType?: string;
    /**
    * The location for the resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_reservation_assignment#location BigqueryReservationAssignment#location}
    */
    readonly location?: string;
    /**
    * Optional. Represents the principal for this assignment. If not empty, jobs run by this principal will utilize the associated reservation. Otherwise, jobs will fall back to using the reservation assigned to the project, folder, or organization (in that order). If no reservation is assigned at any of these levels, on-demand capacity will be used. The supported formats are:
    * * 'principal://goog/subject/USER_EMAIL_ADDRESS' for users,
    * * 'principal://iam.googleapis.com/projects/-/serviceAccounts/SA_EMAIL_ADDRESS' for service accounts,
    * * 'principal://iam.googleapis.com/projects/PROJECT_NUMBER/locations/global/workloadIdentityPools/POOL_ID/subject/SUBJECT_ID' for workload identity pool identities.
    * * The special value 'unknown_or_deleted_user' represents principals which cannot be read from the user info service, for example deleted users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_reservation_assignment#principal BigqueryReservationAssignment#principal}
    */
    readonly principal?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_reservation_assignment#project BigqueryReservationAssignment#project}
    */
    readonly project?: string;
    /**
    * The reservation for the resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_reservation_assignment#reservation BigqueryReservationAssignment#reservation}
    */
    readonly reservation: string;
    /**
    * scheduling_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_reservation_assignment#scheduling_policy BigqueryReservationAssignment#scheduling_policy}
    */
    readonly schedulingPolicy?: BigqueryReservationAssignmentSchedulingPolicy;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_reservation_assignment#timeouts BigqueryReservationAssignment#timeouts}
    */
    readonly timeouts?: BigqueryReservationAssignmentTimeouts;
}
export interface BigqueryReservationAssignmentSchedulingPolicy {
    /**
    * If present and > 0, the reservation will attempt to limit the concurrency
    * of jobs running for any particular project within it to the given value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_reservation_assignment#concurrency BigqueryReservationAssignment#concurrency}
    */
    readonly concurrency?: number;
    /**
    * If present and > 0, the reservation will attempt to limit the slot
    * consumption of queries running for any particular project within it to
    * the given value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_reservation_assignment#max_slots BigqueryReservationAssignment#max_slots}
    */
    readonly maxSlots?: number;
}
export declare function bigqueryReservationAssignmentSchedulingPolicyToTerraform(struct?: BigqueryReservationAssignmentSchedulingPolicyOutputReference | BigqueryReservationAssignmentSchedulingPolicy): any;
export declare function bigqueryReservationAssignmentSchedulingPolicyToHclTerraform(struct?: BigqueryReservationAssignmentSchedulingPolicyOutputReference | BigqueryReservationAssignmentSchedulingPolicy): any;
export declare class BigqueryReservationAssignmentSchedulingPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryReservationAssignmentSchedulingPolicy | undefined;
    set internalValue(value: BigqueryReservationAssignmentSchedulingPolicy | undefined);
    private _concurrency?;
    get concurrency(): number;
    set concurrency(value: number);
    resetConcurrency(): void;
    get concurrencyInput(): number | undefined;
    private _maxSlots?;
    get maxSlots(): number;
    set maxSlots(value: number);
    resetMaxSlots(): void;
    get maxSlotsInput(): number | undefined;
}
export interface BigqueryReservationAssignmentTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_reservation_assignment#create BigqueryReservationAssignment#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_reservation_assignment#delete BigqueryReservationAssignment#delete}
    */
    readonly delete?: string;
}
export declare function bigqueryReservationAssignmentTimeoutsToTerraform(struct?: BigqueryReservationAssignmentTimeouts | cdktn.IResolvable): any;
export declare function bigqueryReservationAssignmentTimeoutsToHclTerraform(struct?: BigqueryReservationAssignmentTimeouts | cdktn.IResolvable): any;
export declare class BigqueryReservationAssignmentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryReservationAssignmentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BigqueryReservationAssignmentTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_reservation_assignment google_bigquery_reservation_assignment}
*/
export declare class BigqueryReservationAssignment extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_bigquery_reservation_assignment";
    /**
    * Generates CDKTN code for importing a BigqueryReservationAssignment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BigqueryReservationAssignment to import
    * @param importFromId The id of the existing BigqueryReservationAssignment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_reservation_assignment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BigqueryReservationAssignment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_reservation_assignment google_bigquery_reservation_assignment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BigqueryReservationAssignmentConfig
    */
    constructor(scope: Construct, id: string, config: BigqueryReservationAssignmentConfig);
    private _assignee?;
    get assignee(): string;
    set assignee(value: string);
    get assigneeInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _jobType?;
    get jobType(): string;
    set jobType(value: string);
    resetJobType(): void;
    get jobTypeInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    get name(): string;
    private _principal?;
    get principal(): string;
    set principal(value: string);
    resetPrincipal(): void;
    get principalInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _reservation?;
    get reservation(): string;
    set reservation(value: string);
    get reservationInput(): string | undefined;
    get state(): string;
    private _schedulingPolicy;
    get schedulingPolicy(): BigqueryReservationAssignmentSchedulingPolicyOutputReference;
    putSchedulingPolicy(value: BigqueryReservationAssignmentSchedulingPolicy): void;
    resetSchedulingPolicy(): void;
    get schedulingPolicyInput(): BigqueryReservationAssignmentSchedulingPolicy | undefined;
    private _timeouts;
    get timeouts(): BigqueryReservationAssignmentTimeoutsOutputReference;
    putTimeouts(value: BigqueryReservationAssignmentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BigqueryReservationAssignmentTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
