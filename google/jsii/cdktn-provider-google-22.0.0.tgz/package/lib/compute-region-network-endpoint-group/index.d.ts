/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeRegionNetworkEndpointGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group#deletion_policy ComputeRegionNetworkEndpointGroup#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource. Provide this property when
    * you create the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group#description ComputeRegionNetworkEndpointGroup#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group#id ComputeRegionNetworkEndpointGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the resource; provided by the client when the resource is
    * created. The name must be 1-63 characters long, and comply with
    * RFC1035. Specifically, the name must be 1-63 characters long and match
    * the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the
    * first character must be a lowercase letter, and all following
    * characters must be a dash, lowercase letter, or digit, except the last
    * character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group#name ComputeRegionNetworkEndpointGroup#name}
    */
    readonly name: string;
    /**
    * This field is only used for PSC and INTERNET NEGs.
    *
    * The URL of the network to which all network endpoints in the NEG belong. Uses
    * "default" project network if unspecified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group#network ComputeRegionNetworkEndpointGroup#network}
    */
    readonly network?: string;
    /**
    * Type of network endpoints in this network endpoint group. Defaults to SERVERLESS. Default value: "SERVERLESS" Possible values: ["SERVERLESS", "PRIVATE_SERVICE_CONNECT", "INTERNET_IP_PORT", "INTERNET_FQDN_PORT", "GCE_VM_IP_PORTMAP"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group#network_endpoint_type ComputeRegionNetworkEndpointGroup#network_endpoint_type}
    */
    readonly networkEndpointType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group#project ComputeRegionNetworkEndpointGroup#project}
    */
    readonly project?: string;
    /**
    * This field is only used for PSC and INTERNET NEGs.
    *
    * The target service url used to set up private service connection to
    * a Google API or a PSC Producer Service Attachment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group#psc_target_service ComputeRegionNetworkEndpointGroup#psc_target_service}
    */
    readonly pscTargetService?: string;
    /**
    * A reference to the region where the regional NEGs reside.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group#region ComputeRegionNetworkEndpointGroup#region}
    */
    readonly region: string;
    /**
    * This field is only used for PSC NEGs.
    *
    * Optional URL of the subnetwork to which all network endpoints in the NEG belong.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group#subnetwork ComputeRegionNetworkEndpointGroup#subnetwork}
    */
    readonly subnetwork?: string;
    /**
    * app_engine block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group#app_engine ComputeRegionNetworkEndpointGroup#app_engine}
    */
    readonly appEngine?: ComputeRegionNetworkEndpointGroupAppEngine;
    /**
    * cloud_function block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group#cloud_function ComputeRegionNetworkEndpointGroup#cloud_function}
    */
    readonly cloudFunction?: ComputeRegionNetworkEndpointGroupCloudFunction;
    /**
    * cloud_run block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group#cloud_run ComputeRegionNetworkEndpointGroup#cloud_run}
    */
    readonly cloudRun?: ComputeRegionNetworkEndpointGroupCloudRun;
    /**
    * psc_data block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group#psc_data ComputeRegionNetworkEndpointGroup#psc_data}
    */
    readonly pscData?: ComputeRegionNetworkEndpointGroupPscData;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group#timeouts ComputeRegionNetworkEndpointGroup#timeouts}
    */
    readonly timeouts?: ComputeRegionNetworkEndpointGroupTimeouts;
}
export interface ComputeRegionNetworkEndpointGroupAppEngine {
    /**
    * Optional serving service.
    * The service name must be 1-63 characters long, and comply with RFC1035.
    * Example value: "default", "my-service".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group#service ComputeRegionNetworkEndpointGroup#service}
    */
    readonly service?: string;
    /**
    * A template to parse service and version fields from a request URL.
    * URL mask allows for routing to multiple App Engine services without
    * having to create multiple Network Endpoint Groups and backend services.
    *
    * For example, the request URLs "foo1-dot-appname.appspot.com/v1" and
    * "foo1-dot-appname.appspot.com/v2" can be backed by the same Serverless NEG with
    * URL mask "-dot-appname.appspot.com/". The URL mask will parse
    * them to { service = "foo1", version = "v1" } and { service = "foo1", version = "v2" } respectively.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group#url_mask ComputeRegionNetworkEndpointGroup#url_mask}
    */
    readonly urlMask?: string;
    /**
    * Optional serving version.
    * The version must be 1-63 characters long, and comply with RFC1035.
    * Example value: "v1", "v2".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group#version ComputeRegionNetworkEndpointGroup#version}
    */
    readonly version?: string;
}
export declare function computeRegionNetworkEndpointGroupAppEngineToTerraform(struct?: ComputeRegionNetworkEndpointGroupAppEngineOutputReference | ComputeRegionNetworkEndpointGroupAppEngine): any;
export declare function computeRegionNetworkEndpointGroupAppEngineToHclTerraform(struct?: ComputeRegionNetworkEndpointGroupAppEngineOutputReference | ComputeRegionNetworkEndpointGroupAppEngine): any;
export declare class ComputeRegionNetworkEndpointGroupAppEngineOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionNetworkEndpointGroupAppEngine | undefined;
    set internalValue(value: ComputeRegionNetworkEndpointGroupAppEngine | undefined);
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
    private _urlMask?;
    get urlMask(): string;
    set urlMask(value: string);
    resetUrlMask(): void;
    get urlMaskInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export interface ComputeRegionNetworkEndpointGroupCloudFunction {
    /**
    * A user-defined name of the Cloud Function.
    * The function name is case-sensitive and must be 1-63 characters long.
    * Example value: "func1".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group#function ComputeRegionNetworkEndpointGroup#function}
    */
    readonly function?: string;
    /**
    * A template to parse function field from a request URL. URL mask allows
    * for routing to multiple Cloud Functions without having to create
    * multiple Network Endpoint Groups and backend services.
    *
    * For example, request URLs "mydomain.com/function1" and "mydomain.com/function2"
    * can be backed by the same Serverless NEG with URL mask "/". The URL mask
    * will parse them to { function = "function1" } and { function = "function2" } respectively.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group#url_mask ComputeRegionNetworkEndpointGroup#url_mask}
    */
    readonly urlMask?: string;
}
export declare function computeRegionNetworkEndpointGroupCloudFunctionToTerraform(struct?: ComputeRegionNetworkEndpointGroupCloudFunctionOutputReference | ComputeRegionNetworkEndpointGroupCloudFunction): any;
export declare function computeRegionNetworkEndpointGroupCloudFunctionToHclTerraform(struct?: ComputeRegionNetworkEndpointGroupCloudFunctionOutputReference | ComputeRegionNetworkEndpointGroupCloudFunction): any;
export declare class ComputeRegionNetworkEndpointGroupCloudFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionNetworkEndpointGroupCloudFunction | undefined;
    set internalValue(value: ComputeRegionNetworkEndpointGroupCloudFunction | undefined);
    private _function?;
    get function(): string;
    set function(value: string);
    resetFunction(): void;
    get functionInput(): string | undefined;
    private _urlMask?;
    get urlMask(): string;
    set urlMask(value: string);
    resetUrlMask(): void;
    get urlMaskInput(): string | undefined;
}
export interface ComputeRegionNetworkEndpointGroupCloudRun {
    /**
    * Cloud Run service is the main resource of Cloud Run.
    * The service must be 1-63 characters long, and comply with RFC1035.
    * Example value: "run-service".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group#service ComputeRegionNetworkEndpointGroup#service}
    */
    readonly service?: string;
    /**
    * Cloud Run tag represents the "named-revision" to provide
    * additional fine-grained traffic routing information.
    * The tag must be 1-63 characters long, and comply with RFC1035.
    * Example value: "revision-0010".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group#tag ComputeRegionNetworkEndpointGroup#tag}
    */
    readonly tag?: string;
    /**
    * A template to parse service and tag fields from a request URL.
    * URL mask allows for routing to multiple Run services without having
    * to create multiple network endpoint groups and backend services.
    *
    * For example, request URLs "foo1.domain.com/bar1" and "foo1.domain.com/bar2"
    * an be backed by the same Serverless Network Endpoint Group (NEG) with
    * URL mask ".domain.com/". The URL mask will parse them to { service="bar1", tag="foo1" }
    * and { service="bar2", tag="foo2" } respectively.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group#url_mask ComputeRegionNetworkEndpointGroup#url_mask}
    */
    readonly urlMask?: string;
}
export declare function computeRegionNetworkEndpointGroupCloudRunToTerraform(struct?: ComputeRegionNetworkEndpointGroupCloudRunOutputReference | ComputeRegionNetworkEndpointGroupCloudRun): any;
export declare function computeRegionNetworkEndpointGroupCloudRunToHclTerraform(struct?: ComputeRegionNetworkEndpointGroupCloudRunOutputReference | ComputeRegionNetworkEndpointGroupCloudRun): any;
export declare class ComputeRegionNetworkEndpointGroupCloudRunOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionNetworkEndpointGroupCloudRun | undefined;
    set internalValue(value: ComputeRegionNetworkEndpointGroupCloudRun | undefined);
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    resetTag(): void;
    get tagInput(): string | undefined;
    private _urlMask?;
    get urlMask(): string;
    set urlMask(value: string);
    resetUrlMask(): void;
    get urlMaskInput(): string | undefined;
}
export interface ComputeRegionNetworkEndpointGroupPscData {
    /**
    * The PSC producer port to use when consumer PSC NEG connects to a producer. If
    * this flag isn't specified for a PSC NEG with endpoint type
    * private-service-connect, then PSC NEG will be connected to a first port in the
    * available PSC producer port range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group#producer_port ComputeRegionNetworkEndpointGroup#producer_port}
    */
    readonly producerPort?: string;
}
export declare function computeRegionNetworkEndpointGroupPscDataToTerraform(struct?: ComputeRegionNetworkEndpointGroupPscDataOutputReference | ComputeRegionNetworkEndpointGroupPscData): any;
export declare function computeRegionNetworkEndpointGroupPscDataToHclTerraform(struct?: ComputeRegionNetworkEndpointGroupPscDataOutputReference | ComputeRegionNetworkEndpointGroupPscData): any;
export declare class ComputeRegionNetworkEndpointGroupPscDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionNetworkEndpointGroupPscData | undefined;
    set internalValue(value: ComputeRegionNetworkEndpointGroupPscData | undefined);
    private _producerPort?;
    get producerPort(): string;
    set producerPort(value: string);
    resetProducerPort(): void;
    get producerPortInput(): string | undefined;
}
export interface ComputeRegionNetworkEndpointGroupTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group#create ComputeRegionNetworkEndpointGroup#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group#delete ComputeRegionNetworkEndpointGroup#delete}
    */
    readonly delete?: string;
}
export declare function computeRegionNetworkEndpointGroupTimeoutsToTerraform(struct?: ComputeRegionNetworkEndpointGroupTimeouts | cdktn.IResolvable): any;
export declare function computeRegionNetworkEndpointGroupTimeoutsToHclTerraform(struct?: ComputeRegionNetworkEndpointGroupTimeouts | cdktn.IResolvable): any;
export declare class ComputeRegionNetworkEndpointGroupTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionNetworkEndpointGroupTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionNetworkEndpointGroupTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group google_compute_region_network_endpoint_group}
*/
export declare class ComputeRegionNetworkEndpointGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_region_network_endpoint_group";
    /**
    * Generates CDKTN code for importing a ComputeRegionNetworkEndpointGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeRegionNetworkEndpointGroup to import
    * @param importFromId The id of the existing ComputeRegionNetworkEndpointGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeRegionNetworkEndpointGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_network_endpoint_group google_compute_region_network_endpoint_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeRegionNetworkEndpointGroupConfig
    */
    constructor(scope: Construct, id: string, config: ComputeRegionNetworkEndpointGroupConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _network?;
    get network(): string;
    set network(value: string);
    resetNetwork(): void;
    get networkInput(): string | undefined;
    private _networkEndpointType?;
    get networkEndpointType(): string;
    set networkEndpointType(value: string);
    resetNetworkEndpointType(): void;
    get networkEndpointTypeInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _pscTargetService?;
    get pscTargetService(): string;
    set pscTargetService(value: string);
    resetPscTargetService(): void;
    get pscTargetServiceInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    get selfLink(): string;
    private _subnetwork?;
    get subnetwork(): string;
    set subnetwork(value: string);
    resetSubnetwork(): void;
    get subnetworkInput(): string | undefined;
    private _appEngine;
    get appEngine(): ComputeRegionNetworkEndpointGroupAppEngineOutputReference;
    putAppEngine(value: ComputeRegionNetworkEndpointGroupAppEngine): void;
    resetAppEngine(): void;
    get appEngineInput(): ComputeRegionNetworkEndpointGroupAppEngine | undefined;
    private _cloudFunction;
    get cloudFunction(): ComputeRegionNetworkEndpointGroupCloudFunctionOutputReference;
    putCloudFunction(value: ComputeRegionNetworkEndpointGroupCloudFunction): void;
    resetCloudFunction(): void;
    get cloudFunctionInput(): ComputeRegionNetworkEndpointGroupCloudFunction | undefined;
    private _cloudRun;
    get cloudRun(): ComputeRegionNetworkEndpointGroupCloudRunOutputReference;
    putCloudRun(value: ComputeRegionNetworkEndpointGroupCloudRun): void;
    resetCloudRun(): void;
    get cloudRunInput(): ComputeRegionNetworkEndpointGroupCloudRun | undefined;
    private _pscData;
    get pscData(): ComputeRegionNetworkEndpointGroupPscDataOutputReference;
    putPscData(value: ComputeRegionNetworkEndpointGroupPscData): void;
    resetPscData(): void;
    get pscDataInput(): ComputeRegionNetworkEndpointGroupPscData | undefined;
    private _timeouts;
    get timeouts(): ComputeRegionNetworkEndpointGroupTimeoutsOutputReference;
    putTimeouts(value: ComputeRegionNetworkEndpointGroupTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeRegionNetworkEndpointGroupTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
