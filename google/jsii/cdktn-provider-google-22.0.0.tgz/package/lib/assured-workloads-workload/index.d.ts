/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AssuredWorkloadsWorkloadConfig extends cdktn.TerraformMetaArguments {
    /**
    * Optional. Input only. The billing account used for the resources which are direct children of workload. This billing account is initially associated with the resources created as part of Workload creation. After the initial creation of these resources, the customer can change the assigned billing account. The resource name has the form `billingAccounts/{billing_account_id}`. For example, `billingAccounts/012345-567890-ABCDEF`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#billing_account AssuredWorkloadsWorkload#billing_account}
    */
    readonly billingAccount?: string;
    /**
    * Required. Immutable. Compliance Regime associated with this workload. Possible values: COMPLIANCE_REGIME_UNSPECIFIED, IL4, CJIS, FEDRAMP_HIGH, FEDRAMP_MODERATE, US_REGIONAL_ACCESS, HIPAA, HITRUST, EU_REGIONS_AND_SUPPORT, CA_REGIONS_AND_SUPPORT, ITAR, AU_REGIONS_AND_US_SUPPORT, ASSURED_WORKLOADS_FOR_PARTNERS, ISR_REGIONS, ISR_REGIONS_AND_SUPPORT, CA_PROTECTED_B, IL5, IL2, JP_REGIONS_AND_SUPPORT, KSA_REGIONS_AND_SUPPORT_WITH_SOVEREIGNTY_CONTROLS, REGIONAL_CONTROLS, HEALTHCARE_AND_LIFE_SCIENCES_CONTROLS, HEALTHCARE_AND_LIFE_SCIENCES_CONTROLS_US_SUPPORT, IRS_1075
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#compliance_regime AssuredWorkloadsWorkload#compliance_regime}
    */
    readonly complianceRegime: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#deletion_policy AssuredWorkloadsWorkload#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Required. The user-assigned display name of the Workload. When present it must be between 4 to 30 characters. Allowed characters are: lowercase and uppercase letters, numbers, hyphen, and spaces. Example: My Workload
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#display_name AssuredWorkloadsWorkload#display_name}
    */
    readonly displayName: string;
    /**
    * Optional. Indicates the sovereignty status of the given workload. Currently meant to be used by Europe/Canada customers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#enable_sovereign_controls AssuredWorkloadsWorkload#enable_sovereign_controls}
    */
    readonly enableSovereignControls?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#id AssuredWorkloadsWorkload#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Optional. Labels applied to the workload.
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field `effective_labels` for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#labels AssuredWorkloadsWorkload#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The location for the resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#location AssuredWorkloadsWorkload#location}
    */
    readonly location: string;
    /**
    * The organization for the resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#organization AssuredWorkloadsWorkload#organization}
    */
    readonly organization: string;
    /**
    * Optional. Partner regime associated with this workload. Possible values: PARTNER_UNSPECIFIED, LOCAL_CONTROLS_BY_S3NS, SOVEREIGN_CONTROLS_BY_T_SYSTEMS, SOVEREIGN_CONTROLS_BY_SIA_MINSAIT, SOVEREIGN_CONTROLS_BY_PSN, SOVEREIGN_CONTROLS_BY_CNTXT, SOVEREIGN_CONTROLS_BY_CNTXT_NO_EKM, SPAIN_DATA_BOUNDARY_BY_TELEFONICA
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#partner AssuredWorkloadsWorkload#partner}
    */
    readonly partner?: string;
    /**
    * Optional. Input only. Billing account necessary for purchasing services from Sovereign Partners. This field is required for creating SIA/PSN/CNTXT partner workloads. The caller should have 'billing.resourceAssociations.create' IAM permission on this billing-account. The format of this string is billingAccounts/AAAAAA-BBBBBB-CCCCCC.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#partner_services_billing_account AssuredWorkloadsWorkload#partner_services_billing_account}
    */
    readonly partnerServicesBillingAccount?: string;
    /**
    * Input only. The parent resource for the resources managed by this Assured Workload. May be either empty or a folder resource which is a child of the Workload parent. If not specified all resources are created under the parent organization. Format: folders/{folder_id}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#provisioned_resources_parent AssuredWorkloadsWorkload#provisioned_resources_parent}
    */
    readonly provisionedResourcesParent?: string;
    /**
    * Optional. Indicates whether the e-mail notification for a violation is enabled for a workload. This value will be by default True, and if not present will be considered as true. This should only be updated via updateWorkload call. Any Changes to this field during the createWorkload call will not be honored. This will always be true while creating the workload.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#violation_notifications_enabled AssuredWorkloadsWorkload#violation_notifications_enabled}
    */
    readonly violationNotificationsEnabled?: boolean | cdktn.IResolvable;
    /**
    * kms_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#kms_settings AssuredWorkloadsWorkload#kms_settings}
    */
    readonly kmsSettings?: AssuredWorkloadsWorkloadKmsSettings;
    /**
    * partner_permissions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#partner_permissions AssuredWorkloadsWorkload#partner_permissions}
    */
    readonly partnerPermissions?: AssuredWorkloadsWorkloadPartnerPermissions;
    /**
    * resource_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#resource_settings AssuredWorkloadsWorkload#resource_settings}
    */
    readonly resourceSettings?: AssuredWorkloadsWorkloadResourceSettings[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#timeouts AssuredWorkloadsWorkload#timeouts}
    */
    readonly timeouts?: AssuredWorkloadsWorkloadTimeouts;
    /**
    * workload_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#workload_options AssuredWorkloadsWorkload#workload_options}
    */
    readonly workloadOptions?: AssuredWorkloadsWorkloadWorkloadOptions;
}
export interface AssuredWorkloadsWorkloadComplianceStatus {
}
export declare function assuredWorkloadsWorkloadComplianceStatusToTerraform(struct?: AssuredWorkloadsWorkloadComplianceStatus): any;
export declare function assuredWorkloadsWorkloadComplianceStatusToHclTerraform(struct?: AssuredWorkloadsWorkloadComplianceStatus): any;
export declare class AssuredWorkloadsWorkloadComplianceStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AssuredWorkloadsWorkloadComplianceStatus | undefined;
    set internalValue(value: AssuredWorkloadsWorkloadComplianceStatus | undefined);
    get acknowledgedViolationCount(): number[];
    get activeViolationCount(): number[];
}
export declare class AssuredWorkloadsWorkloadComplianceStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AssuredWorkloadsWorkloadComplianceStatusOutputReference;
}
export interface AssuredWorkloadsWorkloadEkmProvisioningResponse {
}
export declare function assuredWorkloadsWorkloadEkmProvisioningResponseToTerraform(struct?: AssuredWorkloadsWorkloadEkmProvisioningResponse): any;
export declare function assuredWorkloadsWorkloadEkmProvisioningResponseToHclTerraform(struct?: AssuredWorkloadsWorkloadEkmProvisioningResponse): any;
export declare class AssuredWorkloadsWorkloadEkmProvisioningResponseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AssuredWorkloadsWorkloadEkmProvisioningResponse | undefined;
    set internalValue(value: AssuredWorkloadsWorkloadEkmProvisioningResponse | undefined);
    get ekmProvisioningErrorDomain(): string;
    get ekmProvisioningErrorMapping(): string;
    get ekmProvisioningState(): string;
}
export declare class AssuredWorkloadsWorkloadEkmProvisioningResponseList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AssuredWorkloadsWorkloadEkmProvisioningResponseOutputReference;
}
export interface AssuredWorkloadsWorkloadResources {
}
export declare function assuredWorkloadsWorkloadResourcesToTerraform(struct?: AssuredWorkloadsWorkloadResources): any;
export declare function assuredWorkloadsWorkloadResourcesToHclTerraform(struct?: AssuredWorkloadsWorkloadResources): any;
export declare class AssuredWorkloadsWorkloadResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AssuredWorkloadsWorkloadResources | undefined;
    set internalValue(value: AssuredWorkloadsWorkloadResources | undefined);
    get resourceId(): number;
    get resourceType(): string;
}
export declare class AssuredWorkloadsWorkloadResourcesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AssuredWorkloadsWorkloadResourcesOutputReference;
}
export interface AssuredWorkloadsWorkloadSaaEnrollmentResponse {
}
export declare function assuredWorkloadsWorkloadSaaEnrollmentResponseToTerraform(struct?: AssuredWorkloadsWorkloadSaaEnrollmentResponse): any;
export declare function assuredWorkloadsWorkloadSaaEnrollmentResponseToHclTerraform(struct?: AssuredWorkloadsWorkloadSaaEnrollmentResponse): any;
export declare class AssuredWorkloadsWorkloadSaaEnrollmentResponseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AssuredWorkloadsWorkloadSaaEnrollmentResponse | undefined;
    set internalValue(value: AssuredWorkloadsWorkloadSaaEnrollmentResponse | undefined);
    get setupErrors(): string[];
    get setupStatus(): string;
}
export declare class AssuredWorkloadsWorkloadSaaEnrollmentResponseList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AssuredWorkloadsWorkloadSaaEnrollmentResponseOutputReference;
}
export interface AssuredWorkloadsWorkloadKmsSettings {
    /**
    * Required. Input only. Immutable. The time at which the Key Management Service will automatically create a new version of the crypto key and mark it as the primary.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#next_rotation_time AssuredWorkloadsWorkload#next_rotation_time}
    */
    readonly nextRotationTime: string;
    /**
    * Required. Input only. Immutable. will be advanced by this period when the Key Management Service automatically rotates a key. Must be at least 24 hours and at most 876,000 hours.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#rotation_period AssuredWorkloadsWorkload#rotation_period}
    */
    readonly rotationPeriod: string;
}
export declare function assuredWorkloadsWorkloadKmsSettingsToTerraform(struct?: AssuredWorkloadsWorkloadKmsSettingsOutputReference | AssuredWorkloadsWorkloadKmsSettings): any;
export declare function assuredWorkloadsWorkloadKmsSettingsToHclTerraform(struct?: AssuredWorkloadsWorkloadKmsSettingsOutputReference | AssuredWorkloadsWorkloadKmsSettings): any;
export declare class AssuredWorkloadsWorkloadKmsSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AssuredWorkloadsWorkloadKmsSettings | undefined;
    set internalValue(value: AssuredWorkloadsWorkloadKmsSettings | undefined);
    private _nextRotationTime?;
    get nextRotationTime(): string;
    set nextRotationTime(value: string);
    get nextRotationTimeInput(): string | undefined;
    private _rotationPeriod?;
    get rotationPeriod(): string;
    set rotationPeriod(value: string);
    get rotationPeriodInput(): string | undefined;
}
export interface AssuredWorkloadsWorkloadPartnerPermissions {
    /**
    * Optional. Allow partner to view violation alerts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#assured_workloads_monitoring AssuredWorkloadsWorkload#assured_workloads_monitoring}
    */
    readonly assuredWorkloadsMonitoring?: boolean | cdktn.IResolvable;
    /**
    * Allow the partner to view inspectability logs and monitoring violations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#data_logs_viewer AssuredWorkloadsWorkload#data_logs_viewer}
    */
    readonly dataLogsViewer?: boolean | cdktn.IResolvable;
    /**
    * Optional. Allow partner to view access approval logs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#service_access_approver AssuredWorkloadsWorkload#service_access_approver}
    */
    readonly serviceAccessApprover?: boolean | cdktn.IResolvable;
}
export declare function assuredWorkloadsWorkloadPartnerPermissionsToTerraform(struct?: AssuredWorkloadsWorkloadPartnerPermissionsOutputReference | AssuredWorkloadsWorkloadPartnerPermissions): any;
export declare function assuredWorkloadsWorkloadPartnerPermissionsToHclTerraform(struct?: AssuredWorkloadsWorkloadPartnerPermissionsOutputReference | AssuredWorkloadsWorkloadPartnerPermissions): any;
export declare class AssuredWorkloadsWorkloadPartnerPermissionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AssuredWorkloadsWorkloadPartnerPermissions | undefined;
    set internalValue(value: AssuredWorkloadsWorkloadPartnerPermissions | undefined);
    private _assuredWorkloadsMonitoring?;
    get assuredWorkloadsMonitoring(): boolean | cdktn.IResolvable;
    set assuredWorkloadsMonitoring(value: boolean | cdktn.IResolvable);
    resetAssuredWorkloadsMonitoring(): void;
    get assuredWorkloadsMonitoringInput(): boolean | cdktn.IResolvable | undefined;
    private _dataLogsViewer?;
    get dataLogsViewer(): boolean | cdktn.IResolvable;
    set dataLogsViewer(value: boolean | cdktn.IResolvable);
    resetDataLogsViewer(): void;
    get dataLogsViewerInput(): boolean | cdktn.IResolvable | undefined;
    private _serviceAccessApprover?;
    get serviceAccessApprover(): boolean | cdktn.IResolvable;
    set serviceAccessApprover(value: boolean | cdktn.IResolvable);
    resetServiceAccessApprover(): void;
    get serviceAccessApproverInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AssuredWorkloadsWorkloadResourceSettings {
    /**
    * User-assigned resource display name. If not empty it will be used to create a resource with the specified name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#display_name AssuredWorkloadsWorkload#display_name}
    */
    readonly displayName?: string;
    /**
    * Resource identifier. For a project this represents projectId. If the project is already taken, the workload creation will fail. For KeyRing, this represents the keyring_id. For a folder, don't set this value as folder_id is assigned by Google.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#resource_id AssuredWorkloadsWorkload#resource_id}
    */
    readonly resourceId?: string;
    /**
    * Indicates the type of resource. This field should be specified to correspond the id to the right project type (CONSUMER_PROJECT or ENCRYPTION_KEYS_PROJECT) Possible values: RESOURCE_TYPE_UNSPECIFIED, CONSUMER_PROJECT, ENCRYPTION_KEYS_PROJECT, KEYRING, CONSUMER_FOLDER
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#resource_type AssuredWorkloadsWorkload#resource_type}
    */
    readonly resourceType?: string;
}
export declare function assuredWorkloadsWorkloadResourceSettingsToTerraform(struct?: AssuredWorkloadsWorkloadResourceSettings | cdktn.IResolvable): any;
export declare function assuredWorkloadsWorkloadResourceSettingsToHclTerraform(struct?: AssuredWorkloadsWorkloadResourceSettings | cdktn.IResolvable): any;
export declare class AssuredWorkloadsWorkloadResourceSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AssuredWorkloadsWorkloadResourceSettings | cdktn.IResolvable | undefined;
    set internalValue(value: AssuredWorkloadsWorkloadResourceSettings | cdktn.IResolvable | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    resetResourceId(): void;
    get resourceIdInput(): string | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    resetResourceType(): void;
    get resourceTypeInput(): string | undefined;
}
export declare class AssuredWorkloadsWorkloadResourceSettingsList extends cdktn.ComplexList {
    internalValue?: AssuredWorkloadsWorkloadResourceSettings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AssuredWorkloadsWorkloadResourceSettingsOutputReference;
}
export interface AssuredWorkloadsWorkloadTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#create AssuredWorkloadsWorkload#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#delete AssuredWorkloadsWorkload#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#update AssuredWorkloadsWorkload#update}
    */
    readonly update?: string;
}
export declare function assuredWorkloadsWorkloadTimeoutsToTerraform(struct?: AssuredWorkloadsWorkloadTimeouts | cdktn.IResolvable): any;
export declare function assuredWorkloadsWorkloadTimeoutsToHclTerraform(struct?: AssuredWorkloadsWorkloadTimeouts | cdktn.IResolvable): any;
export declare class AssuredWorkloadsWorkloadTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AssuredWorkloadsWorkloadTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AssuredWorkloadsWorkloadTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface AssuredWorkloadsWorkloadWorkloadOptions {
    /**
    * Indicates type of KAJ enrollment for the workload. Currently, only specifiying KEY_ACCESS_TRANSPARENCY_OFF is implemented to not enroll in KAT-level KAJ enrollment for Regional Controls workloads. Possible values: KAJ_ENROLLMENT_TYPE_UNSPECIFIED, FULL_KAJ, EKM_ONLY, KEY_ACCESS_TRANSPARENCY_OFF
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#kaj_enrollment_type AssuredWorkloadsWorkload#kaj_enrollment_type}
    */
    readonly kajEnrollmentType?: string;
}
export declare function assuredWorkloadsWorkloadWorkloadOptionsToTerraform(struct?: AssuredWorkloadsWorkloadWorkloadOptionsOutputReference | AssuredWorkloadsWorkloadWorkloadOptions): any;
export declare function assuredWorkloadsWorkloadWorkloadOptionsToHclTerraform(struct?: AssuredWorkloadsWorkloadWorkloadOptionsOutputReference | AssuredWorkloadsWorkloadWorkloadOptions): any;
export declare class AssuredWorkloadsWorkloadWorkloadOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AssuredWorkloadsWorkloadWorkloadOptions | undefined;
    set internalValue(value: AssuredWorkloadsWorkloadWorkloadOptions | undefined);
    private _kajEnrollmentType?;
    get kajEnrollmentType(): string;
    set kajEnrollmentType(value: string);
    resetKajEnrollmentType(): void;
    get kajEnrollmentTypeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload google_assured_workloads_workload}
*/
export declare class AssuredWorkloadsWorkload extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_assured_workloads_workload";
    /**
    * Generates CDKTN code for importing a AssuredWorkloadsWorkload resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AssuredWorkloadsWorkload to import
    * @param importFromId The id of the existing AssuredWorkloadsWorkload that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AssuredWorkloadsWorkload to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/assured_workloads_workload google_assured_workloads_workload} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AssuredWorkloadsWorkloadConfig
    */
    constructor(scope: Construct, id: string, config: AssuredWorkloadsWorkloadConfig);
    private _billingAccount?;
    get billingAccount(): string;
    set billingAccount(value: string);
    resetBillingAccount(): void;
    get billingAccountInput(): string | undefined;
    private _complianceRegime?;
    get complianceRegime(): string;
    set complianceRegime(value: string);
    get complianceRegimeInput(): string | undefined;
    private _complianceStatus;
    get complianceStatus(): AssuredWorkloadsWorkloadComplianceStatusList;
    get compliantButDisallowedServices(): string[];
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _ekmProvisioningResponse;
    get ekmProvisioningResponse(): AssuredWorkloadsWorkloadEkmProvisioningResponseList;
    private _enableSovereignControls?;
    get enableSovereignControls(): boolean | cdktn.IResolvable;
    set enableSovereignControls(value: boolean | cdktn.IResolvable);
    resetEnableSovereignControls(): void;
    get enableSovereignControlsInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get kajEnrollmentState(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _partner?;
    get partner(): string;
    set partner(value: string);
    resetPartner(): void;
    get partnerInput(): string | undefined;
    private _partnerServicesBillingAccount?;
    get partnerServicesBillingAccount(): string;
    set partnerServicesBillingAccount(value: string);
    resetPartnerServicesBillingAccount(): void;
    get partnerServicesBillingAccountInput(): string | undefined;
    private _provisionedResourcesParent?;
    get provisionedResourcesParent(): string;
    set provisionedResourcesParent(value: string);
    resetProvisionedResourcesParent(): void;
    get provisionedResourcesParentInput(): string | undefined;
    private _resources;
    get resources(): AssuredWorkloadsWorkloadResourcesList;
    private _saaEnrollmentResponse;
    get saaEnrollmentResponse(): AssuredWorkloadsWorkloadSaaEnrollmentResponseList;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _violationNotificationsEnabled?;
    get violationNotificationsEnabled(): boolean | cdktn.IResolvable;
    set violationNotificationsEnabled(value: boolean | cdktn.IResolvable);
    resetViolationNotificationsEnabled(): void;
    get violationNotificationsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _kmsSettings;
    get kmsSettings(): AssuredWorkloadsWorkloadKmsSettingsOutputReference;
    putKmsSettings(value: AssuredWorkloadsWorkloadKmsSettings): void;
    resetKmsSettings(): void;
    get kmsSettingsInput(): AssuredWorkloadsWorkloadKmsSettings | undefined;
    private _partnerPermissions;
    get partnerPermissions(): AssuredWorkloadsWorkloadPartnerPermissionsOutputReference;
    putPartnerPermissions(value: AssuredWorkloadsWorkloadPartnerPermissions): void;
    resetPartnerPermissions(): void;
    get partnerPermissionsInput(): AssuredWorkloadsWorkloadPartnerPermissions | undefined;
    private _resourceSettings;
    get resourceSettings(): AssuredWorkloadsWorkloadResourceSettingsList;
    putResourceSettings(value: AssuredWorkloadsWorkloadResourceSettings[] | cdktn.IResolvable): void;
    resetResourceSettings(): void;
    get resourceSettingsInput(): cdktn.IResolvable | AssuredWorkloadsWorkloadResourceSettings[] | undefined;
    private _timeouts;
    get timeouts(): AssuredWorkloadsWorkloadTimeoutsOutputReference;
    putTimeouts(value: AssuredWorkloadsWorkloadTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AssuredWorkloadsWorkloadTimeouts | undefined;
    private _workloadOptions;
    get workloadOptions(): AssuredWorkloadsWorkloadWorkloadOptionsOutputReference;
    putWorkloadOptions(value: AssuredWorkloadsWorkloadWorkloadOptions): void;
    resetWorkloadOptions(): void;
    get workloadOptionsInput(): AssuredWorkloadsWorkloadWorkloadOptions | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
