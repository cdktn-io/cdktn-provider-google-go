/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppEngineDomainMappingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/app_engine_domain_mapping#deletion_policy AppEngineDomainMapping#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Relative name of the domain serving the application. Example: example.com.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/app_engine_domain_mapping#domain_name AppEngineDomainMapping#domain_name}
    */
    readonly domainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/app_engine_domain_mapping#id AppEngineDomainMapping#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Whether the domain creation should override any existing mappings for this domain.
    * By default, overrides are rejected. Default value: "STRICT" Possible values: ["STRICT", "OVERRIDE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/app_engine_domain_mapping#override_strategy AppEngineDomainMapping#override_strategy}
    */
    readonly overrideStrategy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/app_engine_domain_mapping#project AppEngineDomainMapping#project}
    */
    readonly project?: string;
    /**
    * ssl_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/app_engine_domain_mapping#ssl_settings AppEngineDomainMapping#ssl_settings}
    */
    readonly sslSettings?: AppEngineDomainMappingSslSettings;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/app_engine_domain_mapping#timeouts AppEngineDomainMapping#timeouts}
    */
    readonly timeouts?: AppEngineDomainMappingTimeouts;
}
export interface AppEngineDomainMappingResourceRecords {
}
export declare function appEngineDomainMappingResourceRecordsToTerraform(struct?: AppEngineDomainMappingResourceRecords): any;
export declare function appEngineDomainMappingResourceRecordsToHclTerraform(struct?: AppEngineDomainMappingResourceRecords): any;
export declare class AppEngineDomainMappingResourceRecordsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppEngineDomainMappingResourceRecords | undefined;
    set internalValue(value: AppEngineDomainMappingResourceRecords | undefined);
    get name(): string;
    get rrdata(): string;
    get type(): string;
}
export declare class AppEngineDomainMappingResourceRecordsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppEngineDomainMappingResourceRecordsOutputReference;
}
export interface AppEngineDomainMappingSslSettings {
    /**
    * ID of the AuthorizedCertificate resource configuring SSL for the application. Clearing this field will
    * remove SSL support.
    * By default, a managed certificate is automatically created for every domain mapping. To omit SSL support
    * or to configure SSL manually, specify 'SslManagementType.MANUAL' on a 'CREATE' or 'UPDATE' request. You must be
    * authorized to administer the 'AuthorizedCertificate' resource to manually map it to a DomainMapping resource.
    * Example: 12345.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/app_engine_domain_mapping#certificate_id AppEngineDomainMapping#certificate_id}
    */
    readonly certificateId?: string;
    /**
    * SSL management type for this domain. If 'AUTOMATIC', a managed certificate is automatically provisioned.
    * If 'MANUAL', 'certificateId' must be manually specified in order to configure SSL for this domain. Possible values: ["AUTOMATIC", "MANUAL"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/app_engine_domain_mapping#ssl_management_type AppEngineDomainMapping#ssl_management_type}
    */
    readonly sslManagementType: string;
}
export declare function appEngineDomainMappingSslSettingsToTerraform(struct?: AppEngineDomainMappingSslSettingsOutputReference | AppEngineDomainMappingSslSettings): any;
export declare function appEngineDomainMappingSslSettingsToHclTerraform(struct?: AppEngineDomainMappingSslSettingsOutputReference | AppEngineDomainMappingSslSettings): any;
export declare class AppEngineDomainMappingSslSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppEngineDomainMappingSslSettings | undefined;
    set internalValue(value: AppEngineDomainMappingSslSettings | undefined);
    private _certificateId?;
    get certificateId(): string;
    set certificateId(value: string);
    resetCertificateId(): void;
    get certificateIdInput(): string | undefined;
    get pendingManagedCertificateId(): string;
    private _sslManagementType?;
    get sslManagementType(): string;
    set sslManagementType(value: string);
    get sslManagementTypeInput(): string | undefined;
}
export interface AppEngineDomainMappingTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/app_engine_domain_mapping#create AppEngineDomainMapping#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/app_engine_domain_mapping#delete AppEngineDomainMapping#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/app_engine_domain_mapping#update AppEngineDomainMapping#update}
    */
    readonly update?: string;
}
export declare function appEngineDomainMappingTimeoutsToTerraform(struct?: AppEngineDomainMappingTimeouts | cdktn.IResolvable): any;
export declare function appEngineDomainMappingTimeoutsToHclTerraform(struct?: AppEngineDomainMappingTimeouts | cdktn.IResolvable): any;
export declare class AppEngineDomainMappingTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppEngineDomainMappingTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AppEngineDomainMappingTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/app_engine_domain_mapping google_app_engine_domain_mapping}
*/
export declare class AppEngineDomainMapping extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_app_engine_domain_mapping";
    /**
    * Generates CDKTN code for importing a AppEngineDomainMapping resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppEngineDomainMapping to import
    * @param importFromId The id of the existing AppEngineDomainMapping that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/app_engine_domain_mapping#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppEngineDomainMapping to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/app_engine_domain_mapping google_app_engine_domain_mapping} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppEngineDomainMappingConfig
    */
    constructor(scope: Construct, id: string, config: AppEngineDomainMappingConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _overrideStrategy?;
    get overrideStrategy(): string;
    set overrideStrategy(value: string);
    resetOverrideStrategy(): void;
    get overrideStrategyInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _resourceRecords;
    get resourceRecords(): AppEngineDomainMappingResourceRecordsList;
    private _sslSettings;
    get sslSettings(): AppEngineDomainMappingSslSettingsOutputReference;
    putSslSettings(value: AppEngineDomainMappingSslSettings): void;
    resetSslSettings(): void;
    get sslSettingsInput(): AppEngineDomainMappingSslSettings | undefined;
    private _timeouts;
    get timeouts(): AppEngineDomainMappingTimeoutsOutputReference;
    putTimeouts(value: AppEngineDomainMappingTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AppEngineDomainMappingTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
