/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccessContextManagerServicePerimeterDryRunIngressPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_ingress_policy#deletion_policy AccessContextManagerServicePerimeterDryRunIngressPolicy#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_ingress_policy#id AccessContextManagerServicePerimeterDryRunIngressPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the Service Perimeter to add this resource to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_ingress_policy#perimeter AccessContextManagerServicePerimeterDryRunIngressPolicy#perimeter}
    */
    readonly perimeter: string;
    /**
    * Human readable title. Must be unique within the perimeter. Does not affect behavior.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_ingress_policy#title AccessContextManagerServicePerimeterDryRunIngressPolicy#title}
    */
    readonly title?: string;
    /**
    * ingress_from block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_ingress_policy#ingress_from AccessContextManagerServicePerimeterDryRunIngressPolicy#ingress_from}
    */
    readonly ingressFrom?: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFrom;
    /**
    * ingress_to block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_ingress_policy#ingress_to AccessContextManagerServicePerimeterDryRunIngressPolicy#ingress_to}
    */
    readonly ingressTo?: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressTo;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_ingress_policy#timeouts AccessContextManagerServicePerimeterDryRunIngressPolicy#timeouts}
    */
    readonly timeouts?: AccessContextManagerServicePerimeterDryRunIngressPolicyTimeouts;
}
export interface AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSourcesPscEndpoint {
    /**
    * The full resource name of the global forwarding rule that identifies a Private Service Connect endpoint.
    * Forwarding rule format: '//compute.googleapis.com/projects/{PROJECT_ID}/global/forwardingRules/{FORWARDING_RULE_ID}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_ingress_policy#forwarding_rule AccessContextManagerServicePerimeterDryRunIngressPolicy#forwarding_rule}
    */
    readonly forwardingRule?: string;
}
export declare function accessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSourcesPscEndpointToTerraform(struct?: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSourcesPscEndpointOutputReference | AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSourcesPscEndpoint): any;
export declare function accessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSourcesPscEndpointToHclTerraform(struct?: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSourcesPscEndpointOutputReference | AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSourcesPscEndpoint): any;
export declare class AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSourcesPscEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSourcesPscEndpoint | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSourcesPscEndpoint | undefined);
    private _forwardingRule?;
    get forwardingRule(): string;
    set forwardingRule(value: string);
    resetForwardingRule(): void;
    get forwardingRuleInput(): string | undefined;
}
export interface AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSources {
    /**
    * An 'AccessLevel' resource name that allow resources within the
    * 'ServicePerimeters' to be accessed from the internet. 'AccessLevels' listed
    * must be in the same policy as this 'ServicePerimeter'. Referencing a nonexistent
    * 'AccessLevel' will cause an error. If no 'AccessLevel' names are listed,
    * resources within the perimeter can only be accessed via Google Cloud calls
    * with request origins within the perimeter.
    * Example 'accessPolicies/MY_POLICY/accessLevels/MY_LEVEL.'
    * If * is specified, then all IngressSources will be allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_ingress_policy#access_level AccessContextManagerServicePerimeterDryRunIngressPolicy#access_level}
    */
    readonly accessLevel?: string;
    /**
    * A Google Cloud resource that is allowed to ingress the perimeter.
    * Requests from these resources will be allowed to access perimeter data.
    * Projects, folders, organizations, and VPC networks are allowed.
    * Project format: 'projects/{project_number}'
    * Folder format: 'folders/{folder_number}'
    * Organization format: 'organizations/{organization_number}'
    * VPC network format: '//compute.googleapis.com/projects/{PROJECT_ID}/global/networks/{NAME}'
    * The resource may be in any Google Cloud organization, not just the
    * organization that the perimeter is defined in. '*' is not allowed, the case
    * of allowing all Google Cloud resources only is not supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_ingress_policy#resource AccessContextManagerServicePerimeterDryRunIngressPolicy#resource}
    */
    readonly resource?: string;
    /**
    * psc_endpoint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_ingress_policy#psc_endpoint AccessContextManagerServicePerimeterDryRunIngressPolicy#psc_endpoint}
    */
    readonly pscEndpoint?: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSourcesPscEndpoint;
}
export declare function accessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSourcesToTerraform(struct?: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSources | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSourcesToHclTerraform(struct?: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSources | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSources | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSources | cdktn.IResolvable | undefined);
    private _accessLevel?;
    get accessLevel(): string;
    set accessLevel(value: string);
    resetAccessLevel(): void;
    get accessLevelInput(): string | undefined;
    private _resource?;
    get resource(): string;
    set resource(value: string);
    resetResource(): void;
    get resourceInput(): string | undefined;
    private _pscEndpoint;
    get pscEndpoint(): AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSourcesPscEndpointOutputReference;
    putPscEndpoint(value: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSourcesPscEndpoint): void;
    resetPscEndpoint(): void;
    get pscEndpointInput(): AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSourcesPscEndpoint | undefined;
}
export declare class AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSourcesList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSourcesOutputReference;
}
export interface AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFrom {
    /**
    * Identities can be an individual user, service account, Google group,
    * or third-party identity. For third-party identity, only single identities
    * are supported and other identity types are not supported.The v1 identities
    * that have the prefix user, group and serviceAccount in
    * https://cloud.google.com/iam/docs/principal-identifiers#v1 are supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_ingress_policy#identities AccessContextManagerServicePerimeterDryRunIngressPolicy#identities}
    */
    readonly identities?: string[];
    /**
    * Specifies the type of identities that are allowed access from outside the
    * perimeter. If left unspecified, then members of 'identities' field will be
    * allowed access. Possible values: ["ANY_IDENTITY", "ANY_USER_ACCOUNT", "ANY_SERVICE_ACCOUNT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_ingress_policy#identity_type AccessContextManagerServicePerimeterDryRunIngressPolicy#identity_type}
    */
    readonly identityType?: string;
    /**
    * sources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_ingress_policy#sources AccessContextManagerServicePerimeterDryRunIngressPolicy#sources}
    */
    readonly sources?: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSources[] | cdktn.IResolvable;
}
export declare function accessContextManagerServicePerimeterDryRunIngressPolicyIngressFromToTerraform(struct?: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromOutputReference | AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFrom): any;
export declare function accessContextManagerServicePerimeterDryRunIngressPolicyIngressFromToHclTerraform(struct?: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromOutputReference | AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFrom): any;
export declare class AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFrom | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFrom | undefined);
    private _identities?;
    get identities(): string[];
    set identities(value: string[]);
    resetIdentities(): void;
    get identitiesInput(): string[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
    private _sources;
    get sources(): AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSourcesList;
    putSources(value: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSources[] | cdktn.IResolvable): void;
    resetSources(): void;
    get sourcesInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromSources[] | undefined;
}
export interface AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperationsMethodSelectors {
    /**
    * Value for method should be a valid method name for the corresponding
    * serviceName in 'ApiOperation'. If '*' used as value for 'method', then
    * ALL methods and permissions are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_ingress_policy#method AccessContextManagerServicePerimeterDryRunIngressPolicy#method}
    */
    readonly method?: string;
    /**
    * Value for permission should be a valid Cloud IAM permission for the
    * corresponding 'serviceName' in 'ApiOperation'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_ingress_policy#permission AccessContextManagerServicePerimeterDryRunIngressPolicy#permission}
    */
    readonly permission?: string;
}
export declare function accessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperationsMethodSelectorsToTerraform(struct?: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperationsMethodSelectors | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperationsMethodSelectorsToHclTerraform(struct?: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperationsMethodSelectors | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperationsMethodSelectorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperationsMethodSelectors | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperationsMethodSelectors | cdktn.IResolvable | undefined);
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    resetPermission(): void;
    get permissionInput(): string | undefined;
}
export declare class AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperationsMethodSelectorsList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperationsMethodSelectors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperationsMethodSelectorsOutputReference;
}
export interface AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperations {
    /**
    * The name of the API whose methods or permissions the 'IngressPolicy' or
    * 'EgressPolicy' want to allow. A single 'ApiOperation' with 'serviceName'
    * field set to '*' will allow all methods AND permissions for all services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_ingress_policy#service_name AccessContextManagerServicePerimeterDryRunIngressPolicy#service_name}
    */
    readonly serviceName?: string;
    /**
    * method_selectors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_ingress_policy#method_selectors AccessContextManagerServicePerimeterDryRunIngressPolicy#method_selectors}
    */
    readonly methodSelectors?: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperationsMethodSelectors[] | cdktn.IResolvable;
}
export declare function accessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperationsToTerraform(struct?: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperations | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperationsToHclTerraform(struct?: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperations | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperations | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperations | cdktn.IResolvable | undefined);
    private _serviceName?;
    get serviceName(): string;
    set serviceName(value: string);
    resetServiceName(): void;
    get serviceNameInput(): string | undefined;
    private _methodSelectors;
    get methodSelectors(): AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperationsMethodSelectorsList;
    putMethodSelectors(value: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperationsMethodSelectors[] | cdktn.IResolvable): void;
    resetMethodSelectors(): void;
    get methodSelectorsInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperationsMethodSelectors[] | undefined;
}
export declare class AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperationsList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperationsOutputReference;
}
export interface AccessContextManagerServicePerimeterDryRunIngressPolicyIngressTo {
    /**
    * A list of resources protected by this 'ServicePerimeter', in the form
    * 'projects/{project_number}', 'folders/{folder_number}', or
    * 'organizations/{organization_number}',
    * that are allowed to be accessed by sources defined in the
    * corresponding 'IngressFrom'. A request matches if it contains
    * a resource in this list. If '*' is specified for resources,
    * then this 'IngressTo' rule will authorize access to all
    * resources inside the perimeter, provided that the request
    * also matches the 'operations' field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_ingress_policy#resources AccessContextManagerServicePerimeterDryRunIngressPolicy#resources}
    */
    readonly resources?: string[];
    /**
    * A list of IAM roles that represent the set of operations that the sources
    * specified in the corresponding 'IngressFrom'
    * are allowed to perform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_ingress_policy#roles AccessContextManagerServicePerimeterDryRunIngressPolicy#roles}
    */
    readonly roles?: string[];
    /**
    * operations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_ingress_policy#operations AccessContextManagerServicePerimeterDryRunIngressPolicy#operations}
    */
    readonly operations?: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperations[] | cdktn.IResolvable;
}
export declare function accessContextManagerServicePerimeterDryRunIngressPolicyIngressToToTerraform(struct?: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOutputReference | AccessContextManagerServicePerimeterDryRunIngressPolicyIngressTo): any;
export declare function accessContextManagerServicePerimeterDryRunIngressPolicyIngressToToHclTerraform(struct?: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOutputReference | AccessContextManagerServicePerimeterDryRunIngressPolicyIngressTo): any;
export declare class AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterDryRunIngressPolicyIngressTo | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressTo | undefined);
    private _resources?;
    get resources(): string[];
    set resources(value: string[]);
    resetResources(): void;
    get resourcesInput(): string[] | undefined;
    private _roles?;
    get roles(): string[];
    set roles(value: string[]);
    resetRoles(): void;
    get rolesInput(): string[] | undefined;
    private _operations;
    get operations(): AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperationsList;
    putOperations(value: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperations[] | cdktn.IResolvable): void;
    resetOperations(): void;
    get operationsInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOperations[] | undefined;
}
export interface AccessContextManagerServicePerimeterDryRunIngressPolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_ingress_policy#create AccessContextManagerServicePerimeterDryRunIngressPolicy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_ingress_policy#delete AccessContextManagerServicePerimeterDryRunIngressPolicy#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_ingress_policy#update AccessContextManagerServicePerimeterDryRunIngressPolicy#update}
    */
    readonly update?: string;
}
export declare function accessContextManagerServicePerimeterDryRunIngressPolicyTimeoutsToTerraform(struct?: AccessContextManagerServicePerimeterDryRunIngressPolicyTimeouts | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterDryRunIngressPolicyTimeoutsToHclTerraform(struct?: AccessContextManagerServicePerimeterDryRunIngressPolicyTimeouts | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterDryRunIngressPolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterDryRunIngressPolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterDryRunIngressPolicyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_ingress_policy google_access_context_manager_service_perimeter_dry_run_ingress_policy}
*/
export declare class AccessContextManagerServicePerimeterDryRunIngressPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_access_context_manager_service_perimeter_dry_run_ingress_policy";
    /**
    * Generates CDKTN code for importing a AccessContextManagerServicePerimeterDryRunIngressPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessContextManagerServicePerimeterDryRunIngressPolicy to import
    * @param importFromId The id of the existing AccessContextManagerServicePerimeterDryRunIngressPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_ingress_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessContextManagerServicePerimeterDryRunIngressPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_ingress_policy google_access_context_manager_service_perimeter_dry_run_ingress_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessContextManagerServicePerimeterDryRunIngressPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AccessContextManagerServicePerimeterDryRunIngressPolicyConfig);
    get accessPolicyId(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _perimeter?;
    get perimeter(): string;
    set perimeter(value: string);
    get perimeterInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _ingressFrom;
    get ingressFrom(): AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFromOutputReference;
    putIngressFrom(value: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFrom): void;
    resetIngressFrom(): void;
    get ingressFromInput(): AccessContextManagerServicePerimeterDryRunIngressPolicyIngressFrom | undefined;
    private _ingressTo;
    get ingressTo(): AccessContextManagerServicePerimeterDryRunIngressPolicyIngressToOutputReference;
    putIngressTo(value: AccessContextManagerServicePerimeterDryRunIngressPolicyIngressTo): void;
    resetIngressTo(): void;
    get ingressToInput(): AccessContextManagerServicePerimeterDryRunIngressPolicyIngressTo | undefined;
    private _timeouts;
    get timeouts(): AccessContextManagerServicePerimeterDryRunIngressPolicyTimeoutsOutputReference;
    putTimeouts(value: AccessContextManagerServicePerimeterDryRunIngressPolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterDryRunIngressPolicyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
