/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudRunV2InstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Unstructured key value map that may be set by external tools to store and arbitrary metadata. They are not queryable and should be preserved when modifying objects.
    * Cloud Run API v2 does not support annotations with 'run.googleapis.com', 'cloud.googleapis.com', 'serving.knative.dev', or 'autoscaling.knative.dev' namespaces, and they will be rejected in new resources.
    * This field follows Kubernetes annotations' namespacing, limits, and rules.
    *
    * **Note**: This field is non-authoritative, and will only manage the annotations present in your configuration.
    * Please refer to the field 'effective_annotations' for all of the annotations present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#annotations CloudRunV2Instance#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Arbitrary identifier for the API client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#client CloudRunV2Instance#client}
    */
    readonly client?: string;
    /**
    * Arbitrary version identifier for the API client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#client_version CloudRunV2Instance#client_version}
    */
    readonly clientVersion?: string;
    /**
    * Disables public resolution of the default URI of this Instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#default_uri_disabled CloudRunV2Instance#default_uri_disabled}
    */
    readonly defaultUriDisabled?: boolean | cdktn.IResolvable;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#deletion_policy CloudRunV2Instance#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * A reference to a customer managed encryption key (CMEK) to use to encrypt this container image. For more information, go to https://cloud.google.com/run/docs/securing/using-cmek
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#encryption_key CloudRunV2Instance#encryption_key}
    */
    readonly encryptionKey?: string;
    /**
    * The action to take if the encryption key is revoked. Possible values: ["PREVENT_NEW", "SHUTDOWN"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#encryption_key_revocation_action CloudRunV2Instance#encryption_key_revocation_action}
    */
    readonly encryptionKeyRevocationAction?: string;
    /**
    * If encryptionKeyRevocationAction is SHUTDOWN, the duration before shutting down all instances. The minimum increment is 1 hour.
    * A duration in seconds with up to nine fractional digits, ending with 's'. Example: "3.5s".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#encryption_key_shutdown_duration CloudRunV2Instance#encryption_key_shutdown_duration}
    */
    readonly encryptionKeyShutdownDuration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#id CloudRunV2Instance#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Provides the ingress settings for this Instance. On output, returns the currently observed ingress settings, or INGRESS_TRAFFIC_UNSPECIFIED if no revision is active. Possible values: ["INGRESS_TRAFFIC_ALL", "INGRESS_TRAFFIC_INTERNAL_ONLY", "INGRESS_TRAFFIC_INTERNAL_LOAD_BALANCER"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#ingress CloudRunV2Instance#ingress}
    */
    readonly ingress?: string;
    /**
    * Disables IAM permission check for run.routes.invoke for callers of this Instance. For more information, visit https://cloud.google.com/run/docs/securing/managing-access#invoker_check.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#invoker_iam_disabled CloudRunV2Instance#invoker_iam_disabled}
    */
    readonly invokerIamDisabled?: boolean | cdktn.IResolvable;
    /**
    * Unstructured key value map that can be used to organize and categorize objects. User-provided labels are shared with Google's billing system, so they can be used to filter, or break down billing charges by team, component,
    * environment, state, etc. For more information, visit https://docs.cloud.google.com/resource-manager/docs/creating-managing-labels or https://cloud.google.com/run/docs/configuring/labels.
    * Cloud Run API v2 does not support labels with 'run.googleapis.com', 'cloud.googleapis.com', 'serving.knative.dev', or 'autoscaling.knative.dev' namespaces, and they will be rejected.
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#labels CloudRunV2Instance#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The launch stage as defined by [Google Cloud Platform Launch Stages](https://cloud.google.com/products#product-launch-stages). Cloud Run supports ALPHA, BETA, and GA. If no value is specified, GA is assumed. Set the launch stage to a preview stage on input to allow use of preview features in that stage. On read (or output), describes whether the resource uses preview features.
    * For example, if ALPHA is provided as input, but only BETA and GA-level features are used, this field will be BETA on output. Possible values: ["UNIMPLEMENTED", "PRELAUNCH", "EARLY_ACCESS", "ALPHA", "BETA", "GA", "DEPRECATED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#launch_stage CloudRunV2Instance#launch_stage}
    */
    readonly launchStage?: string;
    /**
    * The location of the cloud run instance
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#location CloudRunV2Instance#location}
    */
    readonly location: string;
    /**
    * Name of the Instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#name CloudRunV2Instance#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#project CloudRunV2Instance#project}
    */
    readonly project?: string;
    /**
    * Restart policy for the Instance. If not provided, the default is ON_FAILURE. Possible values: ["ALWAYS", "ON_FAILURE", "NEVER"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#restart_policy CloudRunV2Instance#restart_policy}
    */
    readonly restartPolicy?: string;
    /**
    * Email address of the IAM service account associated with the Instance. The service account represents the identity of the running Instance, and determines what permissions the instance has.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#service_account CloudRunV2Instance#service_account}
    */
    readonly serviceAccount?: string;
    /**
    * containers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#containers CloudRunV2Instance#containers}
    */
    readonly containers: CloudRunV2InstanceContainers[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#timeouts CloudRunV2Instance#timeouts}
    */
    readonly timeouts?: CloudRunV2InstanceTimeouts;
    /**
    * volumes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#volumes CloudRunV2Instance#volumes}
    */
    readonly volumes?: CloudRunV2InstanceVolumes[] | cdktn.IResolvable;
}
export interface CloudRunV2InstanceConditions {
}
export declare function cloudRunV2InstanceConditionsToTerraform(struct?: CloudRunV2InstanceConditions): any;
export declare function cloudRunV2InstanceConditionsToHclTerraform(struct?: CloudRunV2InstanceConditions): any;
export declare class CloudRunV2InstanceConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2InstanceConditions | undefined;
    set internalValue(value: CloudRunV2InstanceConditions | undefined);
    get instanceReason(): string;
    get lastTransitionTime(): string;
    get message(): string;
    get reason(): string;
    get severity(): string;
    get state(): string;
    get type(): string;
}
export declare class CloudRunV2InstanceConditionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2InstanceConditionsOutputReference;
}
export interface CloudRunV2InstanceContainerStatuses {
}
export declare function cloudRunV2InstanceContainerStatusesToTerraform(struct?: CloudRunV2InstanceContainerStatuses): any;
export declare function cloudRunV2InstanceContainerStatusesToHclTerraform(struct?: CloudRunV2InstanceContainerStatuses): any;
export declare class CloudRunV2InstanceContainerStatusesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2InstanceContainerStatuses | undefined;
    set internalValue(value: CloudRunV2InstanceContainerStatuses | undefined);
    get imageDigest(): string;
    get name(): string;
}
export declare class CloudRunV2InstanceContainerStatusesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2InstanceContainerStatusesOutputReference;
}
export interface CloudRunV2InstanceTerminalCondition {
}
export declare function cloudRunV2InstanceTerminalConditionToTerraform(struct?: CloudRunV2InstanceTerminalCondition): any;
export declare function cloudRunV2InstanceTerminalConditionToHclTerraform(struct?: CloudRunV2InstanceTerminalCondition): any;
export declare class CloudRunV2InstanceTerminalConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2InstanceTerminalCondition | undefined;
    set internalValue(value: CloudRunV2InstanceTerminalCondition | undefined);
    get instanceReason(): string;
    get lastTransitionTime(): string;
    get message(): string;
    get reason(): string;
    get severity(): string;
    get state(): string;
    get type(): string;
}
export declare class CloudRunV2InstanceTerminalConditionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2InstanceTerminalConditionOutputReference;
}
export interface CloudRunV2InstanceContainersEnvValueSourceSecretKeyRef {
    /**
    * The name of the secret in Cloud Secret Manager. Format: {secretName} if the secret is in the same project. projects/{project}/secrets/{secretName} if the secret is in a different project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#secret CloudRunV2Instance#secret}
    */
    readonly secret: string;
    /**
    * The Cloud Secret Manager secret version. Can be 'latest' for the latest value or an integer for a specific version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#version CloudRunV2Instance#version}
    */
    readonly version: string;
}
export declare function cloudRunV2InstanceContainersEnvValueSourceSecretKeyRefToTerraform(struct?: CloudRunV2InstanceContainersEnvValueSourceSecretKeyRefOutputReference | CloudRunV2InstanceContainersEnvValueSourceSecretKeyRef): any;
export declare function cloudRunV2InstanceContainersEnvValueSourceSecretKeyRefToHclTerraform(struct?: CloudRunV2InstanceContainersEnvValueSourceSecretKeyRefOutputReference | CloudRunV2InstanceContainersEnvValueSourceSecretKeyRef): any;
export declare class CloudRunV2InstanceContainersEnvValueSourceSecretKeyRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2InstanceContainersEnvValueSourceSecretKeyRef | undefined;
    set internalValue(value: CloudRunV2InstanceContainersEnvValueSourceSecretKeyRef | undefined);
    private _secret?;
    get secret(): string;
    set secret(value: string);
    get secretInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
}
export interface CloudRunV2InstanceContainersEnvValueSource {
    /**
    * secret_key_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#secret_key_ref CloudRunV2Instance#secret_key_ref}
    */
    readonly secretKeyRef?: CloudRunV2InstanceContainersEnvValueSourceSecretKeyRef;
}
export declare function cloudRunV2InstanceContainersEnvValueSourceToTerraform(struct?: CloudRunV2InstanceContainersEnvValueSourceOutputReference | CloudRunV2InstanceContainersEnvValueSource): any;
export declare function cloudRunV2InstanceContainersEnvValueSourceToHclTerraform(struct?: CloudRunV2InstanceContainersEnvValueSourceOutputReference | CloudRunV2InstanceContainersEnvValueSource): any;
export declare class CloudRunV2InstanceContainersEnvValueSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2InstanceContainersEnvValueSource | undefined;
    set internalValue(value: CloudRunV2InstanceContainersEnvValueSource | undefined);
    private _secretKeyRef;
    get secretKeyRef(): CloudRunV2InstanceContainersEnvValueSourceSecretKeyRefOutputReference;
    putSecretKeyRef(value: CloudRunV2InstanceContainersEnvValueSourceSecretKeyRef): void;
    resetSecretKeyRef(): void;
    get secretKeyRefInput(): CloudRunV2InstanceContainersEnvValueSourceSecretKeyRef | undefined;
}
export interface CloudRunV2InstanceContainersEnv {
    /**
    * Name of the environment variable. Must be a C_IDENTIFIER, and may not exceed 32768 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#name CloudRunV2Instance#name}
    */
    readonly name: string;
    /**
    * Literal value of the environment variable. Defaults to "" and the maximum allowed length is 32768 characters. Variable references are not supported in Cloud Run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#value CloudRunV2Instance#value}
    */
    readonly value?: string;
    /**
    * value_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#value_source CloudRunV2Instance#value_source}
    */
    readonly valueSource?: CloudRunV2InstanceContainersEnvValueSource;
}
export declare function cloudRunV2InstanceContainersEnvToTerraform(struct?: CloudRunV2InstanceContainersEnv | cdktn.IResolvable): any;
export declare function cloudRunV2InstanceContainersEnvToHclTerraform(struct?: CloudRunV2InstanceContainersEnv | cdktn.IResolvable): any;
export declare class CloudRunV2InstanceContainersEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2InstanceContainersEnv | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2InstanceContainersEnv | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _valueSource;
    get valueSource(): CloudRunV2InstanceContainersEnvValueSourceOutputReference;
    putValueSource(value: CloudRunV2InstanceContainersEnvValueSource): void;
    resetValueSource(): void;
    get valueSourceInput(): CloudRunV2InstanceContainersEnvValueSource | undefined;
}
export declare class CloudRunV2InstanceContainersEnvList extends cdktn.ComplexList {
    internalValue?: CloudRunV2InstanceContainersEnv[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2InstanceContainersEnvOutputReference;
}
export interface CloudRunV2InstanceContainersLivenessProbeGrpc {
    /**
    * Optional. Port number of the gRPC service. Number must be in the range 1 to 65535. If not specified, defaults to the exposed port of the container, which is the value of container.ports[0].containerPort.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#port CloudRunV2Instance#port}
    */
    readonly port?: number;
    /**
    * Optional. Service is the name of the service to place in the gRPC HealthCheckRequest (see https://github.com/grpc/grpc/blob/master/doc/health-checking.md ). If this is not specified, the default behavior is defined by gRPC
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#service CloudRunV2Instance#service}
    */
    readonly service?: string;
}
export declare function cloudRunV2InstanceContainersLivenessProbeGrpcToTerraform(struct?: CloudRunV2InstanceContainersLivenessProbeGrpcOutputReference | CloudRunV2InstanceContainersLivenessProbeGrpc): any;
export declare function cloudRunV2InstanceContainersLivenessProbeGrpcToHclTerraform(struct?: CloudRunV2InstanceContainersLivenessProbeGrpcOutputReference | CloudRunV2InstanceContainersLivenessProbeGrpc): any;
export declare class CloudRunV2InstanceContainersLivenessProbeGrpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2InstanceContainersLivenessProbeGrpc | undefined;
    set internalValue(value: CloudRunV2InstanceContainersLivenessProbeGrpc | undefined);
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
}
export interface CloudRunV2InstanceContainersLivenessProbeHttpGetHttpHeaders {
    /**
    * Required. The header field name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#name CloudRunV2Instance#name}
    */
    readonly name?: string;
    /**
    * Optional. The header field value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#value CloudRunV2Instance#value}
    */
    readonly value?: string;
}
export declare function cloudRunV2InstanceContainersLivenessProbeHttpGetHttpHeadersToTerraform(struct?: CloudRunV2InstanceContainersLivenessProbeHttpGetHttpHeaders | cdktn.IResolvable): any;
export declare function cloudRunV2InstanceContainersLivenessProbeHttpGetHttpHeadersToHclTerraform(struct?: CloudRunV2InstanceContainersLivenessProbeHttpGetHttpHeaders | cdktn.IResolvable): any;
export declare class CloudRunV2InstanceContainersLivenessProbeHttpGetHttpHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2InstanceContainersLivenessProbeHttpGetHttpHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2InstanceContainersLivenessProbeHttpGetHttpHeaders | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudRunV2InstanceContainersLivenessProbeHttpGetHttpHeadersList extends cdktn.ComplexList {
    internalValue?: CloudRunV2InstanceContainersLivenessProbeHttpGetHttpHeaders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2InstanceContainersLivenessProbeHttpGetHttpHeadersOutputReference;
}
export interface CloudRunV2InstanceContainersLivenessProbeHttpGet {
    /**
    * Optional. Path to access on the HTTP server. Defaults to '/'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#path CloudRunV2Instance#path}
    */
    readonly path?: string;
    /**
    * Optional. Port number to access on the container. Must be in the range 1 to 65535. If not specified, defaults to the exposed port of the container, which is the value of container.ports[0].containerPort.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#port CloudRunV2Instance#port}
    */
    readonly port?: number;
    /**
    * http_headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#http_headers CloudRunV2Instance#http_headers}
    */
    readonly httpHeaders?: CloudRunV2InstanceContainersLivenessProbeHttpGetHttpHeaders[] | cdktn.IResolvable;
}
export declare function cloudRunV2InstanceContainersLivenessProbeHttpGetToTerraform(struct?: CloudRunV2InstanceContainersLivenessProbeHttpGetOutputReference | CloudRunV2InstanceContainersLivenessProbeHttpGet): any;
export declare function cloudRunV2InstanceContainersLivenessProbeHttpGetToHclTerraform(struct?: CloudRunV2InstanceContainersLivenessProbeHttpGetOutputReference | CloudRunV2InstanceContainersLivenessProbeHttpGet): any;
export declare class CloudRunV2InstanceContainersLivenessProbeHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2InstanceContainersLivenessProbeHttpGet | undefined;
    set internalValue(value: CloudRunV2InstanceContainersLivenessProbeHttpGet | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _httpHeaders;
    get httpHeaders(): CloudRunV2InstanceContainersLivenessProbeHttpGetHttpHeadersList;
    putHttpHeaders(value: CloudRunV2InstanceContainersLivenessProbeHttpGetHttpHeaders[] | cdktn.IResolvable): void;
    resetHttpHeaders(): void;
    get httpHeadersInput(): cdktn.IResolvable | CloudRunV2InstanceContainersLivenessProbeHttpGetHttpHeaders[] | undefined;
}
export interface CloudRunV2InstanceContainersLivenessProbe {
    /**
    * Optional. Minimum consecutive failures for the probe to be considered failed after having succeeded. Defaults to 3. Minimum value is 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#failure_threshold CloudRunV2Instance#failure_threshold}
    */
    readonly failureThreshold?: number;
    /**
    * Optional. Number of seconds after the container has started before the probe is initiated. Defaults to 0 seconds. Minimum value is 0. Maximum value for liveness probe is 3600. Maximum value for startup probe is 240.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#initial_delay_seconds CloudRunV2Instance#initial_delay_seconds}
    */
    readonly initialDelaySeconds?: number;
    /**
    * Optional. How often (in seconds) to perform the probe. Default to 10 seconds. Minimum value is 1. Maximum value for liveness probe is 3600. Maximum value for startup probe is 240. Must be greater or equal than timeout_seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#period_seconds CloudRunV2Instance#period_seconds}
    */
    readonly periodSeconds?: number;
    /**
    * Optional. Number of seconds after which the probe times out. Defaults to 1 second. Minimum value is 1. Maximum value is 3600. Must be smaller than period_seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#timeout_seconds CloudRunV2Instance#timeout_seconds}
    */
    readonly timeoutSeconds?: number;
    /**
    * grpc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#grpc CloudRunV2Instance#grpc}
    */
    readonly grpc?: CloudRunV2InstanceContainersLivenessProbeGrpc;
    /**
    * http_get block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#http_get CloudRunV2Instance#http_get}
    */
    readonly httpGet?: CloudRunV2InstanceContainersLivenessProbeHttpGet;
}
export declare function cloudRunV2InstanceContainersLivenessProbeToTerraform(struct?: CloudRunV2InstanceContainersLivenessProbeOutputReference | CloudRunV2InstanceContainersLivenessProbe): any;
export declare function cloudRunV2InstanceContainersLivenessProbeToHclTerraform(struct?: CloudRunV2InstanceContainersLivenessProbeOutputReference | CloudRunV2InstanceContainersLivenessProbe): any;
export declare class CloudRunV2InstanceContainersLivenessProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2InstanceContainersLivenessProbe | undefined;
    set internalValue(value: CloudRunV2InstanceContainersLivenessProbe | undefined);
    private _failureThreshold?;
    get failureThreshold(): number;
    set failureThreshold(value: number);
    resetFailureThreshold(): void;
    get failureThresholdInput(): number | undefined;
    private _initialDelaySeconds?;
    get initialDelaySeconds(): number;
    set initialDelaySeconds(value: number);
    resetInitialDelaySeconds(): void;
    get initialDelaySecondsInput(): number | undefined;
    private _periodSeconds?;
    get periodSeconds(): number;
    set periodSeconds(value: number);
    resetPeriodSeconds(): void;
    get periodSecondsInput(): number | undefined;
    private _timeoutSeconds?;
    get timeoutSeconds(): number;
    set timeoutSeconds(value: number);
    resetTimeoutSeconds(): void;
    get timeoutSecondsInput(): number | undefined;
    private _grpc;
    get grpc(): CloudRunV2InstanceContainersLivenessProbeGrpcOutputReference;
    putGrpc(value: CloudRunV2InstanceContainersLivenessProbeGrpc): void;
    resetGrpc(): void;
    get grpcInput(): CloudRunV2InstanceContainersLivenessProbeGrpc | undefined;
    private _httpGet;
    get httpGet(): CloudRunV2InstanceContainersLivenessProbeHttpGetOutputReference;
    putHttpGet(value: CloudRunV2InstanceContainersLivenessProbeHttpGet): void;
    resetHttpGet(): void;
    get httpGetInput(): CloudRunV2InstanceContainersLivenessProbeHttpGet | undefined;
}
export interface CloudRunV2InstanceContainersPorts {
    /**
    * Port number the container listens on. This must be a valid TCP port number, 0 < containerPort < 65536.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#container_port CloudRunV2Instance#container_port}
    */
    readonly containerPort?: number;
    /**
    * If specified, used to specify which protocol to use. Allowed values are "http1" and "h2c".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#name CloudRunV2Instance#name}
    */
    readonly name?: string;
}
export declare function cloudRunV2InstanceContainersPortsToTerraform(struct?: CloudRunV2InstanceContainersPorts | cdktn.IResolvable): any;
export declare function cloudRunV2InstanceContainersPortsToHclTerraform(struct?: CloudRunV2InstanceContainersPorts | cdktn.IResolvable): any;
export declare class CloudRunV2InstanceContainersPortsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2InstanceContainersPorts | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2InstanceContainersPorts | cdktn.IResolvable | undefined);
    private _containerPort?;
    get containerPort(): number;
    set containerPort(value: number);
    resetContainerPort(): void;
    get containerPortInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class CloudRunV2InstanceContainersPortsList extends cdktn.ComplexList {
    internalValue?: CloudRunV2InstanceContainersPorts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2InstanceContainersPortsOutputReference;
}
export interface CloudRunV2InstanceContainersResources {
    /**
    * Only memory and CPU are supported. Use key 'cpu' for CPU limit, 'memory' for memory limit. Note: The only supported values for CPU are '1', '2', '4', '6', and '8'. Setting 4 CPU requires at least 2Gi of memory, setting 6 or more CPU requires at least 4Gi of memory. The values of the map is string form of the 'quantity' k8s type: https://github.com/kubernetes/kubernetes/blob/master/staging/src/k8s.io/apimachinery/pkg/api/resource/quantity.go
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#limits CloudRunV2Instance#limits}
    */
    readonly limits?: {
        [key: string]: string;
    };
}
export declare function cloudRunV2InstanceContainersResourcesToTerraform(struct?: CloudRunV2InstanceContainersResourcesOutputReference | CloudRunV2InstanceContainersResources): any;
export declare function cloudRunV2InstanceContainersResourcesToHclTerraform(struct?: CloudRunV2InstanceContainersResourcesOutputReference | CloudRunV2InstanceContainersResources): any;
export declare class CloudRunV2InstanceContainersResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2InstanceContainersResources | undefined;
    set internalValue(value: CloudRunV2InstanceContainersResources | undefined);
    private _limits?;
    get limits(): {
        [key: string]: string;
    };
    set limits(value: {
        [key: string]: string;
    });
    resetLimits(): void;
    get limitsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface CloudRunV2InstanceContainersStartupProbeGrpc {
    /**
    * Optional. Port number of the gRPC service. Number must be in the range 1 to 65535. If not specified, defaults to the exposed port of the container, which is the value of container.ports[0].containerPort.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#port CloudRunV2Instance#port}
    */
    readonly port?: number;
    /**
    * Optional. Service is the name of the service to place in the gRPC HealthCheckRequest (see https://github.com/grpc/grpc/blob/master/doc/health-checking.md ). If this is not specified, the default behavior is defined by gRPC
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#service CloudRunV2Instance#service}
    */
    readonly service?: string;
}
export declare function cloudRunV2InstanceContainersStartupProbeGrpcToTerraform(struct?: CloudRunV2InstanceContainersStartupProbeGrpcOutputReference | CloudRunV2InstanceContainersStartupProbeGrpc): any;
export declare function cloudRunV2InstanceContainersStartupProbeGrpcToHclTerraform(struct?: CloudRunV2InstanceContainersStartupProbeGrpcOutputReference | CloudRunV2InstanceContainersStartupProbeGrpc): any;
export declare class CloudRunV2InstanceContainersStartupProbeGrpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2InstanceContainersStartupProbeGrpc | undefined;
    set internalValue(value: CloudRunV2InstanceContainersStartupProbeGrpc | undefined);
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
}
export interface CloudRunV2InstanceContainersStartupProbeHttpGetHttpHeaders {
    /**
    * Required. The header field name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#name CloudRunV2Instance#name}
    */
    readonly name?: string;
    /**
    * Optional. The header field value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#value CloudRunV2Instance#value}
    */
    readonly value?: string;
}
export declare function cloudRunV2InstanceContainersStartupProbeHttpGetHttpHeadersToTerraform(struct?: CloudRunV2InstanceContainersStartupProbeHttpGetHttpHeaders | cdktn.IResolvable): any;
export declare function cloudRunV2InstanceContainersStartupProbeHttpGetHttpHeadersToHclTerraform(struct?: CloudRunV2InstanceContainersStartupProbeHttpGetHttpHeaders | cdktn.IResolvable): any;
export declare class CloudRunV2InstanceContainersStartupProbeHttpGetHttpHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2InstanceContainersStartupProbeHttpGetHttpHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2InstanceContainersStartupProbeHttpGetHttpHeaders | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudRunV2InstanceContainersStartupProbeHttpGetHttpHeadersList extends cdktn.ComplexList {
    internalValue?: CloudRunV2InstanceContainersStartupProbeHttpGetHttpHeaders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2InstanceContainersStartupProbeHttpGetHttpHeadersOutputReference;
}
export interface CloudRunV2InstanceContainersStartupProbeHttpGet {
    /**
    * Optional. Path to access on the HTTP server. Defaults to '/'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#path CloudRunV2Instance#path}
    */
    readonly path?: string;
    /**
    * Optional. Port number to access on the container. Must be in the range 1 to 65535. If not specified, defaults to the exposed port of the container, which is the value of container.ports[0].containerPort.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#port CloudRunV2Instance#port}
    */
    readonly port?: number;
    /**
    * http_headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#http_headers CloudRunV2Instance#http_headers}
    */
    readonly httpHeaders?: CloudRunV2InstanceContainersStartupProbeHttpGetHttpHeaders[] | cdktn.IResolvable;
}
export declare function cloudRunV2InstanceContainersStartupProbeHttpGetToTerraform(struct?: CloudRunV2InstanceContainersStartupProbeHttpGetOutputReference | CloudRunV2InstanceContainersStartupProbeHttpGet): any;
export declare function cloudRunV2InstanceContainersStartupProbeHttpGetToHclTerraform(struct?: CloudRunV2InstanceContainersStartupProbeHttpGetOutputReference | CloudRunV2InstanceContainersStartupProbeHttpGet): any;
export declare class CloudRunV2InstanceContainersStartupProbeHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2InstanceContainersStartupProbeHttpGet | undefined;
    set internalValue(value: CloudRunV2InstanceContainersStartupProbeHttpGet | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _httpHeaders;
    get httpHeaders(): CloudRunV2InstanceContainersStartupProbeHttpGetHttpHeadersList;
    putHttpHeaders(value: CloudRunV2InstanceContainersStartupProbeHttpGetHttpHeaders[] | cdktn.IResolvable): void;
    resetHttpHeaders(): void;
    get httpHeadersInput(): cdktn.IResolvable | CloudRunV2InstanceContainersStartupProbeHttpGetHttpHeaders[] | undefined;
}
export interface CloudRunV2InstanceContainersStartupProbeTcpSocket {
    /**
    * Optional. Port number to access on the container. Must be in the range 1 to 65535. If not specified, defaults to the exposed port of the container, which is the value of container.ports[0].containerPort.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#port CloudRunV2Instance#port}
    */
    readonly port?: number;
}
export declare function cloudRunV2InstanceContainersStartupProbeTcpSocketToTerraform(struct?: CloudRunV2InstanceContainersStartupProbeTcpSocketOutputReference | CloudRunV2InstanceContainersStartupProbeTcpSocket): any;
export declare function cloudRunV2InstanceContainersStartupProbeTcpSocketToHclTerraform(struct?: CloudRunV2InstanceContainersStartupProbeTcpSocketOutputReference | CloudRunV2InstanceContainersStartupProbeTcpSocket): any;
export declare class CloudRunV2InstanceContainersStartupProbeTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2InstanceContainersStartupProbeTcpSocket | undefined;
    set internalValue(value: CloudRunV2InstanceContainersStartupProbeTcpSocket | undefined);
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
}
export interface CloudRunV2InstanceContainersStartupProbe {
    /**
    * Optional. Minimum consecutive failures for the probe to be considered failed after having succeeded. Defaults to 3. Minimum value is 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#failure_threshold CloudRunV2Instance#failure_threshold}
    */
    readonly failureThreshold?: number;
    /**
    * Optional. Number of seconds after the container has started before the probe is initiated. Defaults to 0 seconds. Minimum value is 0. Maximum value for liveness probe is 3600. Maximum value for startup probe is 240.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#initial_delay_seconds CloudRunV2Instance#initial_delay_seconds}
    */
    readonly initialDelaySeconds?: number;
    /**
    * Optional. How often (in seconds) to perform the probe. Default to 10 seconds. Minimum value is 1. Maximum value for liveness probe is 3600. Maximum value for startup probe is 240. Must be greater or equal than timeout_seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#period_seconds CloudRunV2Instance#period_seconds}
    */
    readonly periodSeconds?: number;
    /**
    * Optional. Number of seconds after which the probe times out. Defaults to 1 second. Minimum value is 1. Maximum value is 3600. Must be smaller than period_seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#timeout_seconds CloudRunV2Instance#timeout_seconds}
    */
    readonly timeoutSeconds?: number;
    /**
    * grpc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#grpc CloudRunV2Instance#grpc}
    */
    readonly grpc?: CloudRunV2InstanceContainersStartupProbeGrpc;
    /**
    * http_get block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#http_get CloudRunV2Instance#http_get}
    */
    readonly httpGet?: CloudRunV2InstanceContainersStartupProbeHttpGet;
    /**
    * tcp_socket block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#tcp_socket CloudRunV2Instance#tcp_socket}
    */
    readonly tcpSocket?: CloudRunV2InstanceContainersStartupProbeTcpSocket;
}
export declare function cloudRunV2InstanceContainersStartupProbeToTerraform(struct?: CloudRunV2InstanceContainersStartupProbeOutputReference | CloudRunV2InstanceContainersStartupProbe): any;
export declare function cloudRunV2InstanceContainersStartupProbeToHclTerraform(struct?: CloudRunV2InstanceContainersStartupProbeOutputReference | CloudRunV2InstanceContainersStartupProbe): any;
export declare class CloudRunV2InstanceContainersStartupProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2InstanceContainersStartupProbe | undefined;
    set internalValue(value: CloudRunV2InstanceContainersStartupProbe | undefined);
    private _failureThreshold?;
    get failureThreshold(): number;
    set failureThreshold(value: number);
    resetFailureThreshold(): void;
    get failureThresholdInput(): number | undefined;
    private _initialDelaySeconds?;
    get initialDelaySeconds(): number;
    set initialDelaySeconds(value: number);
    resetInitialDelaySeconds(): void;
    get initialDelaySecondsInput(): number | undefined;
    private _periodSeconds?;
    get periodSeconds(): number;
    set periodSeconds(value: number);
    resetPeriodSeconds(): void;
    get periodSecondsInput(): number | undefined;
    private _timeoutSeconds?;
    get timeoutSeconds(): number;
    set timeoutSeconds(value: number);
    resetTimeoutSeconds(): void;
    get timeoutSecondsInput(): number | undefined;
    private _grpc;
    get grpc(): CloudRunV2InstanceContainersStartupProbeGrpcOutputReference;
    putGrpc(value: CloudRunV2InstanceContainersStartupProbeGrpc): void;
    resetGrpc(): void;
    get grpcInput(): CloudRunV2InstanceContainersStartupProbeGrpc | undefined;
    private _httpGet;
    get httpGet(): CloudRunV2InstanceContainersStartupProbeHttpGetOutputReference;
    putHttpGet(value: CloudRunV2InstanceContainersStartupProbeHttpGet): void;
    resetHttpGet(): void;
    get httpGetInput(): CloudRunV2InstanceContainersStartupProbeHttpGet | undefined;
    private _tcpSocket;
    get tcpSocket(): CloudRunV2InstanceContainersStartupProbeTcpSocketOutputReference;
    putTcpSocket(value: CloudRunV2InstanceContainersStartupProbeTcpSocket): void;
    resetTcpSocket(): void;
    get tcpSocketInput(): CloudRunV2InstanceContainersStartupProbeTcpSocket | undefined;
}
export interface CloudRunV2InstanceContainersVolumeMounts {
    /**
    * Path within the container at which the volume should be mounted. Must not contain ':'. For Cloud SQL volumes, it can be left empty, or must otherwise be /cloudsql. All instances defined in the Volume will be available as /cloudsql/[instance]. For more information on Cloud SQL volumes, visit https://cloud.google.com/sql/docs/mysql/connect-run
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#mount_path CloudRunV2Instance#mount_path}
    */
    readonly mountPath: string;
    /**
    * This must match the Name of a Volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#name CloudRunV2Instance#name}
    */
    readonly name: string;
    /**
    * Path within the volume from which the container's volume should be mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#sub_path CloudRunV2Instance#sub_path}
    */
    readonly subPath?: string;
}
export declare function cloudRunV2InstanceContainersVolumeMountsToTerraform(struct?: CloudRunV2InstanceContainersVolumeMounts | cdktn.IResolvable): any;
export declare function cloudRunV2InstanceContainersVolumeMountsToHclTerraform(struct?: CloudRunV2InstanceContainersVolumeMounts | cdktn.IResolvable): any;
export declare class CloudRunV2InstanceContainersVolumeMountsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2InstanceContainersVolumeMounts | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2InstanceContainersVolumeMounts | cdktn.IResolvable | undefined);
    private _mountPath?;
    get mountPath(): string;
    set mountPath(value: string);
    get mountPathInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _subPath?;
    get subPath(): string;
    set subPath(value: string);
    resetSubPath(): void;
    get subPathInput(): string | undefined;
}
export declare class CloudRunV2InstanceContainersVolumeMountsList extends cdktn.ComplexList {
    internalValue?: CloudRunV2InstanceContainersVolumeMounts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2InstanceContainersVolumeMountsOutputReference;
}
export interface CloudRunV2InstanceContainers {
    /**
    * Arguments to the entrypoint. The docker image's CMD is used if this is not provided. Variable references $(VAR_NAME) are expanded using the container's environment. If a variable cannot be resolved, the reference in the input string will be unchanged. The $(VAR_NAME) syntax can be escaped with a double $$, ie: $$(VAR_NAME). Escaped references will never be expanded, regardless of whether the variable exists or not. More info: https://kubernetes.io/docs/tasks/inject-data-application/define-command-argument-container/#running-a-command-in-a-shell
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#args CloudRunV2Instance#args}
    */
    readonly args?: string[];
    /**
    * Entrypoint array. Not executed within a shell. The docker image's ENTRYPOINT is used if this is not provided. Variable references $(VAR_NAME) are expanded using the container's environment. If a variable cannot be resolved, the reference in the input string will be unchanged. The $(VAR_NAME) syntax can be escaped with a double $$, ie: $$(VAR_NAME). Escaped references will never be expanded, regardless of whether the variable exists or not. More info: https://kubernetes.io/docs/tasks/inject-data-application/define-command-argument-container/#running-a-command-in-a-shell
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#command CloudRunV2Instance#command}
    */
    readonly command?: string[];
    /**
    * URL of the Container image in Google Container Registry or Google Artifact Registry. More info: https://kubernetes.io/docs/concepts/containers/images
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#image CloudRunV2Instance#image}
    */
    readonly image: string;
    /**
    * Name of the container specified as a DNS_LABEL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#name CloudRunV2Instance#name}
    */
    readonly name?: string;
    /**
    * Container's working directory. If not specified, the container runtime's default will be used, which might be configured in the container image.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#working_dir CloudRunV2Instance#working_dir}
    */
    readonly workingDir?: string;
    /**
    * env block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#env CloudRunV2Instance#env}
    */
    readonly env?: CloudRunV2InstanceContainersEnv[] | cdktn.IResolvable;
    /**
    * liveness_probe block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#liveness_probe CloudRunV2Instance#liveness_probe}
    */
    readonly livenessProbe?: CloudRunV2InstanceContainersLivenessProbe;
    /**
    * ports block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#ports CloudRunV2Instance#ports}
    */
    readonly ports?: CloudRunV2InstanceContainersPorts[] | cdktn.IResolvable;
    /**
    * resources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#resources CloudRunV2Instance#resources}
    */
    readonly resources?: CloudRunV2InstanceContainersResources;
    /**
    * startup_probe block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#startup_probe CloudRunV2Instance#startup_probe}
    */
    readonly startupProbe?: CloudRunV2InstanceContainersStartupProbe;
    /**
    * volume_mounts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#volume_mounts CloudRunV2Instance#volume_mounts}
    */
    readonly volumeMounts?: CloudRunV2InstanceContainersVolumeMounts[] | cdktn.IResolvable;
}
export declare function cloudRunV2InstanceContainersToTerraform(struct?: CloudRunV2InstanceContainers | cdktn.IResolvable): any;
export declare function cloudRunV2InstanceContainersToHclTerraform(struct?: CloudRunV2InstanceContainers | cdktn.IResolvable): any;
export declare class CloudRunV2InstanceContainersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2InstanceContainers | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2InstanceContainers | cdktn.IResolvable | undefined);
    private _args?;
    get args(): string[];
    set args(value: string[]);
    resetArgs(): void;
    get argsInput(): string[] | undefined;
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
    private _image?;
    get image(): string;
    set image(value: string);
    get imageInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _workingDir?;
    get workingDir(): string;
    set workingDir(value: string);
    resetWorkingDir(): void;
    get workingDirInput(): string | undefined;
    private _env;
    get env(): CloudRunV2InstanceContainersEnvList;
    putEnv(value: CloudRunV2InstanceContainersEnv[] | cdktn.IResolvable): void;
    resetEnv(): void;
    get envInput(): cdktn.IResolvable | CloudRunV2InstanceContainersEnv[] | undefined;
    private _livenessProbe;
    get livenessProbe(): CloudRunV2InstanceContainersLivenessProbeOutputReference;
    putLivenessProbe(value: CloudRunV2InstanceContainersLivenessProbe): void;
    resetLivenessProbe(): void;
    get livenessProbeInput(): CloudRunV2InstanceContainersLivenessProbe | undefined;
    private _ports;
    get ports(): CloudRunV2InstanceContainersPortsList;
    putPorts(value: CloudRunV2InstanceContainersPorts[] | cdktn.IResolvable): void;
    resetPorts(): void;
    get portsInput(): cdktn.IResolvable | CloudRunV2InstanceContainersPorts[] | undefined;
    private _resources;
    get resources(): CloudRunV2InstanceContainersResourcesOutputReference;
    putResources(value: CloudRunV2InstanceContainersResources): void;
    resetResources(): void;
    get resourcesInput(): CloudRunV2InstanceContainersResources | undefined;
    private _startupProbe;
    get startupProbe(): CloudRunV2InstanceContainersStartupProbeOutputReference;
    putStartupProbe(value: CloudRunV2InstanceContainersStartupProbe): void;
    resetStartupProbe(): void;
    get startupProbeInput(): CloudRunV2InstanceContainersStartupProbe | undefined;
    private _volumeMounts;
    get volumeMounts(): CloudRunV2InstanceContainersVolumeMountsList;
    putVolumeMounts(value: CloudRunV2InstanceContainersVolumeMounts[] | cdktn.IResolvable): void;
    resetVolumeMounts(): void;
    get volumeMountsInput(): cdktn.IResolvable | CloudRunV2InstanceContainersVolumeMounts[] | undefined;
}
export declare class CloudRunV2InstanceContainersList extends cdktn.ComplexList {
    internalValue?: CloudRunV2InstanceContainers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2InstanceContainersOutputReference;
}
export interface CloudRunV2InstanceTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#create CloudRunV2Instance#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#delete CloudRunV2Instance#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#update CloudRunV2Instance#update}
    */
    readonly update?: string;
}
export declare function cloudRunV2InstanceTimeoutsToTerraform(struct?: CloudRunV2InstanceTimeouts | cdktn.IResolvable): any;
export declare function cloudRunV2InstanceTimeoutsToHclTerraform(struct?: CloudRunV2InstanceTimeouts | cdktn.IResolvable): any;
export declare class CloudRunV2InstanceTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2InstanceTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2InstanceTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface CloudRunV2InstanceVolumesCloudSqlInstance {
    /**
    * The Cloud SQL instance connection names, as can be found in https://console.cloud.google.com/sql/instances. Visit https://cloud.google.com/sql/docs/mysql/connect-run for more information on how to connect Cloud SQL and Cloud Run. Format: {project}:{location}:{instance}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#instances CloudRunV2Instance#instances}
    */
    readonly instances?: string[];
}
export declare function cloudRunV2InstanceVolumesCloudSqlInstanceToTerraform(struct?: CloudRunV2InstanceVolumesCloudSqlInstanceOutputReference | CloudRunV2InstanceVolumesCloudSqlInstance): any;
export declare function cloudRunV2InstanceVolumesCloudSqlInstanceToHclTerraform(struct?: CloudRunV2InstanceVolumesCloudSqlInstanceOutputReference | CloudRunV2InstanceVolumesCloudSqlInstance): any;
export declare class CloudRunV2InstanceVolumesCloudSqlInstanceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2InstanceVolumesCloudSqlInstance | undefined;
    set internalValue(value: CloudRunV2InstanceVolumesCloudSqlInstance | undefined);
    private _instances?;
    get instances(): string[];
    set instances(value: string[]);
    resetInstances(): void;
    get instancesInput(): string[] | undefined;
}
export interface CloudRunV2InstanceVolumesEmptyDir {
    /**
    * The different types of medium supported for EmptyDir. Default value: "MEMORY" Possible values: ["MEMORY", "DISK"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#medium CloudRunV2Instance#medium}
    */
    readonly medium?: string;
    /**
    * Limit on the storage usable by this EmptyDir volume. The size limit is also applicable for memory medium. The maximum usage on memory medium EmptyDir would be the minimum value between the SizeLimit specified here and the sum of memory limits of all containers in a pod. This field's values are of the 'Quantity' k8s type: https://kubernetes.io/docs/reference/kubernetes-api/common-definitions/quantity/. The default is nil which means that the limit is undefined. More info: https://kubernetes.io/docs/concepts/storage/volumes/#emptydir.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#size_limit CloudRunV2Instance#size_limit}
    */
    readonly sizeLimit?: string;
}
export declare function cloudRunV2InstanceVolumesEmptyDirToTerraform(struct?: CloudRunV2InstanceVolumesEmptyDirOutputReference | CloudRunV2InstanceVolumesEmptyDir): any;
export declare function cloudRunV2InstanceVolumesEmptyDirToHclTerraform(struct?: CloudRunV2InstanceVolumesEmptyDirOutputReference | CloudRunV2InstanceVolumesEmptyDir): any;
export declare class CloudRunV2InstanceVolumesEmptyDirOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2InstanceVolumesEmptyDir | undefined;
    set internalValue(value: CloudRunV2InstanceVolumesEmptyDir | undefined);
    private _medium?;
    get medium(): string;
    set medium(value: string);
    resetMedium(): void;
    get mediumInput(): string | undefined;
    private _sizeLimit?;
    get sizeLimit(): string;
    set sizeLimit(value: string);
    resetSizeLimit(): void;
    get sizeLimitInput(): string | undefined;
}
export interface CloudRunV2InstanceVolumesGcs {
    /**
    * GCS Bucket name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#bucket CloudRunV2Instance#bucket}
    */
    readonly bucket: string;
    /**
    * A list of flags to pass to the gcsfuse command for configuring this volume.
    * Flags should be passed without leading dashes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#mount_options CloudRunV2Instance#mount_options}
    */
    readonly mountOptions?: string[];
    /**
    * If true, mount the GCS bucket as read-only
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#read_only CloudRunV2Instance#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
}
export declare function cloudRunV2InstanceVolumesGcsToTerraform(struct?: CloudRunV2InstanceVolumesGcsOutputReference | CloudRunV2InstanceVolumesGcs): any;
export declare function cloudRunV2InstanceVolumesGcsToHclTerraform(struct?: CloudRunV2InstanceVolumesGcsOutputReference | CloudRunV2InstanceVolumesGcs): any;
export declare class CloudRunV2InstanceVolumesGcsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2InstanceVolumesGcs | undefined;
    set internalValue(value: CloudRunV2InstanceVolumesGcs | undefined);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _mountOptions?;
    get mountOptions(): string[];
    set mountOptions(value: string[]);
    resetMountOptions(): void;
    get mountOptionsInput(): string[] | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CloudRunV2InstanceVolumesNfs {
    /**
    * Path that is exported by the NFS server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#path CloudRunV2Instance#path}
    */
    readonly path: string;
    /**
    * If true, mount the NFS volume as read only
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#read_only CloudRunV2Instance#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Hostname or IP address of the NFS server
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#server CloudRunV2Instance#server}
    */
    readonly server: string;
}
export declare function cloudRunV2InstanceVolumesNfsToTerraform(struct?: CloudRunV2InstanceVolumesNfsOutputReference | CloudRunV2InstanceVolumesNfs): any;
export declare function cloudRunV2InstanceVolumesNfsToHclTerraform(struct?: CloudRunV2InstanceVolumesNfsOutputReference | CloudRunV2InstanceVolumesNfs): any;
export declare class CloudRunV2InstanceVolumesNfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2InstanceVolumesNfs | undefined;
    set internalValue(value: CloudRunV2InstanceVolumesNfs | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _server?;
    get server(): string;
    set server(value: string);
    get serverInput(): string | undefined;
}
export interface CloudRunV2InstanceVolumesSecretItems {
    /**
    * Integer octal mode bits to use on this file, must be a value between 01 and 0777 (octal). If 0 or not set, the Volume's default mode will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#mode CloudRunV2Instance#mode}
    */
    readonly mode?: number;
    /**
    * The relative path of the secret in the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#path CloudRunV2Instance#path}
    */
    readonly path: string;
    /**
    * The Cloud Secret Manager secret version. Can be 'latest' for the latest value or an integer for a specific version
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#version CloudRunV2Instance#version}
    */
    readonly version?: string;
}
export declare function cloudRunV2InstanceVolumesSecretItemsToTerraform(struct?: CloudRunV2InstanceVolumesSecretItems | cdktn.IResolvable): any;
export declare function cloudRunV2InstanceVolumesSecretItemsToHclTerraform(struct?: CloudRunV2InstanceVolumesSecretItems | cdktn.IResolvable): any;
export declare class CloudRunV2InstanceVolumesSecretItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2InstanceVolumesSecretItems | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2InstanceVolumesSecretItems | cdktn.IResolvable | undefined);
    private _mode?;
    get mode(): number;
    set mode(value: number);
    resetMode(): void;
    get modeInput(): number | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export declare class CloudRunV2InstanceVolumesSecretItemsList extends cdktn.ComplexList {
    internalValue?: CloudRunV2InstanceVolumesSecretItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2InstanceVolumesSecretItemsOutputReference;
}
export interface CloudRunV2InstanceVolumesSecret {
    /**
    * Integer representation of mode bits to use on created files by default. Must be a value between 0000 and 0777 (octal), defaulting to 0444. Directories within the path are not affected by this setting.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#default_mode CloudRunV2Instance#default_mode}
    */
    readonly defaultMode?: number;
    /**
    * The name of the secret in Cloud Secret Manager. Format: {secret} if the secret is in the same project. projects/{project}/secrets/{secret} if the secret is in a different project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#secret CloudRunV2Instance#secret}
    */
    readonly secret: string;
    /**
    * items block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#items CloudRunV2Instance#items}
    */
    readonly items?: CloudRunV2InstanceVolumesSecretItems[] | cdktn.IResolvable;
}
export declare function cloudRunV2InstanceVolumesSecretToTerraform(struct?: CloudRunV2InstanceVolumesSecretOutputReference | CloudRunV2InstanceVolumesSecret): any;
export declare function cloudRunV2InstanceVolumesSecretToHclTerraform(struct?: CloudRunV2InstanceVolumesSecretOutputReference | CloudRunV2InstanceVolumesSecret): any;
export declare class CloudRunV2InstanceVolumesSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2InstanceVolumesSecret | undefined;
    set internalValue(value: CloudRunV2InstanceVolumesSecret | undefined);
    private _defaultMode?;
    get defaultMode(): number;
    set defaultMode(value: number);
    resetDefaultMode(): void;
    get defaultModeInput(): number | undefined;
    private _secret?;
    get secret(): string;
    set secret(value: string);
    get secretInput(): string | undefined;
    private _items;
    get items(): CloudRunV2InstanceVolumesSecretItemsList;
    putItems(value: CloudRunV2InstanceVolumesSecretItems[] | cdktn.IResolvable): void;
    resetItems(): void;
    get itemsInput(): cdktn.IResolvable | CloudRunV2InstanceVolumesSecretItems[] | undefined;
}
export interface CloudRunV2InstanceVolumes {
    /**
    * Volume's name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#name CloudRunV2Instance#name}
    */
    readonly name: string;
    /**
    * cloud_sql_instance block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#cloud_sql_instance CloudRunV2Instance#cloud_sql_instance}
    */
    readonly cloudSqlInstance?: CloudRunV2InstanceVolumesCloudSqlInstance;
    /**
    * empty_dir block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#empty_dir CloudRunV2Instance#empty_dir}
    */
    readonly emptyDir?: CloudRunV2InstanceVolumesEmptyDir;
    /**
    * gcs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#gcs CloudRunV2Instance#gcs}
    */
    readonly gcs?: CloudRunV2InstanceVolumesGcs;
    /**
    * nfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#nfs CloudRunV2Instance#nfs}
    */
    readonly nfs?: CloudRunV2InstanceVolumesNfs;
    /**
    * secret block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#secret CloudRunV2Instance#secret}
    */
    readonly secret?: CloudRunV2InstanceVolumesSecret;
}
export declare function cloudRunV2InstanceVolumesToTerraform(struct?: CloudRunV2InstanceVolumes | cdktn.IResolvable): any;
export declare function cloudRunV2InstanceVolumesToHclTerraform(struct?: CloudRunV2InstanceVolumes | cdktn.IResolvable): any;
export declare class CloudRunV2InstanceVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2InstanceVolumes | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2InstanceVolumes | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _cloudSqlInstance;
    get cloudSqlInstance(): CloudRunV2InstanceVolumesCloudSqlInstanceOutputReference;
    putCloudSqlInstance(value: CloudRunV2InstanceVolumesCloudSqlInstance): void;
    resetCloudSqlInstance(): void;
    get cloudSqlInstanceInput(): CloudRunV2InstanceVolumesCloudSqlInstance | undefined;
    private _emptyDir;
    get emptyDir(): CloudRunV2InstanceVolumesEmptyDirOutputReference;
    putEmptyDir(value: CloudRunV2InstanceVolumesEmptyDir): void;
    resetEmptyDir(): void;
    get emptyDirInput(): CloudRunV2InstanceVolumesEmptyDir | undefined;
    private _gcs;
    get gcs(): CloudRunV2InstanceVolumesGcsOutputReference;
    putGcs(value: CloudRunV2InstanceVolumesGcs): void;
    resetGcs(): void;
    get gcsInput(): CloudRunV2InstanceVolumesGcs | undefined;
    private _nfs;
    get nfs(): CloudRunV2InstanceVolumesNfsOutputReference;
    putNfs(value: CloudRunV2InstanceVolumesNfs): void;
    resetNfs(): void;
    get nfsInput(): CloudRunV2InstanceVolumesNfs | undefined;
    private _secret;
    get secret(): CloudRunV2InstanceVolumesSecretOutputReference;
    putSecret(value: CloudRunV2InstanceVolumesSecret): void;
    resetSecret(): void;
    get secretInput(): CloudRunV2InstanceVolumesSecret | undefined;
}
export declare class CloudRunV2InstanceVolumesList extends cdktn.ComplexList {
    internalValue?: CloudRunV2InstanceVolumes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2InstanceVolumesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance google_cloud_run_v2_instance}
*/
export declare class CloudRunV2Instance extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_cloud_run_v2_instance";
    /**
    * Generates CDKTN code for importing a CloudRunV2Instance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudRunV2Instance to import
    * @param importFromId The id of the existing CloudRunV2Instance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudRunV2Instance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_run_v2_instance google_cloud_run_v2_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudRunV2InstanceConfig
    */
    constructor(scope: Construct, id: string, config: CloudRunV2InstanceConfig);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _client?;
    get client(): string;
    set client(value: string);
    resetClient(): void;
    get clientInput(): string | undefined;
    private _clientVersion?;
    get clientVersion(): string;
    set clientVersion(value: string);
    resetClientVersion(): void;
    get clientVersionInput(): string | undefined;
    private _conditions;
    get conditions(): CloudRunV2InstanceConditionsList;
    private _containerStatuses;
    get containerStatuses(): CloudRunV2InstanceContainerStatusesList;
    get createTime(): string;
    get creator(): string;
    private _defaultUriDisabled?;
    get defaultUriDisabled(): boolean | cdktn.IResolvable;
    set defaultUriDisabled(value: boolean | cdktn.IResolvable);
    resetDefaultUriDisabled(): void;
    get defaultUriDisabledInput(): boolean | cdktn.IResolvable | undefined;
    get deleteTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _effectiveAnnotations;
    get effectiveAnnotations(): cdktn.StringMap;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _encryptionKey?;
    get encryptionKey(): string;
    set encryptionKey(value: string);
    resetEncryptionKey(): void;
    get encryptionKeyInput(): string | undefined;
    private _encryptionKeyRevocationAction?;
    get encryptionKeyRevocationAction(): string;
    set encryptionKeyRevocationAction(value: string);
    resetEncryptionKeyRevocationAction(): void;
    get encryptionKeyRevocationActionInput(): string | undefined;
    private _encryptionKeyShutdownDuration?;
    get encryptionKeyShutdownDuration(): string;
    set encryptionKeyShutdownDuration(value: string);
    resetEncryptionKeyShutdownDuration(): void;
    get encryptionKeyShutdownDurationInput(): string | undefined;
    get etag(): string;
    get expireTime(): string;
    get generation(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ingress?;
    get ingress(): string;
    set ingress(value: string);
    resetIngress(): void;
    get ingressInput(): string | undefined;
    private _invokerIamDisabled?;
    get invokerIamDisabled(): boolean | cdktn.IResolvable;
    set invokerIamDisabled(value: boolean | cdktn.IResolvable);
    resetInvokerIamDisabled(): void;
    get invokerIamDisabledInput(): boolean | cdktn.IResolvable | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    get lastModifier(): string;
    private _launchStage?;
    get launchStage(): string;
    set launchStage(value: string);
    resetLaunchStage(): void;
    get launchStageInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get logUri(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get observedGeneration(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get reconciling(): cdktn.IResolvable;
    private _restartPolicy?;
    get restartPolicy(): string;
    set restartPolicy(value: string);
    resetRestartPolicy(): void;
    get restartPolicyInput(): string | undefined;
    get satisfiesPzs(): cdktn.IResolvable;
    private _serviceAccount?;
    get serviceAccount(): string;
    set serviceAccount(value: string);
    resetServiceAccount(): void;
    get serviceAccountInput(): string | undefined;
    private _terminalCondition;
    get terminalCondition(): CloudRunV2InstanceTerminalConditionList;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get uid(): string;
    get updateTime(): string;
    get urls(): string[];
    private _containers;
    get containers(): CloudRunV2InstanceContainersList;
    putContainers(value: CloudRunV2InstanceContainers[] | cdktn.IResolvable): void;
    get containersInput(): cdktn.IResolvable | CloudRunV2InstanceContainers[] | undefined;
    private _timeouts;
    get timeouts(): CloudRunV2InstanceTimeoutsOutputReference;
    putTimeouts(value: CloudRunV2InstanceTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CloudRunV2InstanceTimeouts | undefined;
    private _volumes;
    get volumes(): CloudRunV2InstanceVolumesList;
    putVolumes(value: CloudRunV2InstanceVolumes[] | cdktn.IResolvable): void;
    resetVolumes(): void;
    get volumesInput(): cdktn.IResolvable | CloudRunV2InstanceVolumes[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
