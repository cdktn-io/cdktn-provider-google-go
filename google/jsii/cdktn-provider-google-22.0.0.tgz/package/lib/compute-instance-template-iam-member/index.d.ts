/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeInstanceTemplateIamMemberConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_template_iam_member#id ComputeInstanceTemplateIamMember#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_template_iam_member#member ComputeInstanceTemplateIamMember#member}
    */
    readonly member: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_template_iam_member#name ComputeInstanceTemplateIamMember#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_template_iam_member#project ComputeInstanceTemplateIamMember#project}
    */
    readonly project?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_template_iam_member#role ComputeInstanceTemplateIamMember#role}
    */
    readonly role: string;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_template_iam_member#condition ComputeInstanceTemplateIamMember#condition}
    */
    readonly condition?: ComputeInstanceTemplateIamMemberCondition;
}
export interface ComputeInstanceTemplateIamMemberCondition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_template_iam_member#description ComputeInstanceTemplateIamMember#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_template_iam_member#expression ComputeInstanceTemplateIamMember#expression}
    */
    readonly expression: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_template_iam_member#title ComputeInstanceTemplateIamMember#title}
    */
    readonly title: string;
}
export declare function computeInstanceTemplateIamMemberConditionToTerraform(struct?: ComputeInstanceTemplateIamMemberConditionOutputReference | ComputeInstanceTemplateIamMemberCondition): any;
export declare function computeInstanceTemplateIamMemberConditionToHclTerraform(struct?: ComputeInstanceTemplateIamMemberConditionOutputReference | ComputeInstanceTemplateIamMemberCondition): any;
export declare class ComputeInstanceTemplateIamMemberConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceTemplateIamMemberCondition | undefined;
    set internalValue(value: ComputeInstanceTemplateIamMemberCondition | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_template_iam_member google_compute_instance_template_iam_member}
*/
export declare class ComputeInstanceTemplateIamMember extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_instance_template_iam_member";
    /**
    * Generates CDKTN code for importing a ComputeInstanceTemplateIamMember resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeInstanceTemplateIamMember to import
    * @param importFromId The id of the existing ComputeInstanceTemplateIamMember that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_template_iam_member#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeInstanceTemplateIamMember to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_template_iam_member google_compute_instance_template_iam_member} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeInstanceTemplateIamMemberConfig
    */
    constructor(scope: Construct, id: string, config: ComputeInstanceTemplateIamMemberConfig);
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _member?;
    get member(): string;
    set member(value: string);
    get memberInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _condition;
    get condition(): ComputeInstanceTemplateIamMemberConditionOutputReference;
    putCondition(value: ComputeInstanceTemplateIamMemberCondition): void;
    resetCondition(): void;
    get conditionInput(): ComputeInstanceTemplateIamMemberCondition | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
