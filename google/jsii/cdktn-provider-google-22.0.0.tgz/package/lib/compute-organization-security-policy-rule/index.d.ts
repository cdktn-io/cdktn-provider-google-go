/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeOrganizationSecurityPolicyRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Action to perform when the client connection triggers the rule. Valid actions are:
    * "allow": allow access to target.
    * "deny": deny access to target.
    * "goto_next": forward the request to the next hierarchical policy for evaluation.
    * "redirect": redirect to a different target. Parameters for this action can be configured via redirectOptions. Only EXTERNAL_302 redirect type is supported for organization security policies.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#action ComputeOrganizationSecurityPolicyRule#action}
    */
    readonly action: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#deletion_policy ComputeOrganizationSecurityPolicyRule#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * A description of the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#description ComputeOrganizationSecurityPolicyRule#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#id ComputeOrganizationSecurityPolicyRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the OrganizationSecurityPolicy this rule applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#policy_id ComputeOrganizationSecurityPolicyRule#policy_id}
    */
    readonly policyId: string;
    /**
    * If set to true, the specified action is not enforced.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#preview ComputeOrganizationSecurityPolicyRule#preview}
    */
    readonly preview?: boolean | cdktn.IResolvable;
    /**
    * An integer indicating the priority of a rule in the list. The priority must be a value
    * between 0 and 2147483647. Rules are evaluated from highest to lowest priority where 0 is the
    * highest priority and 2147483647 is the lowest prority.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#priority ComputeOrganizationSecurityPolicyRule#priority}
    */
    readonly priority: number;
    /**
    * header_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#header_action ComputeOrganizationSecurityPolicyRule#header_action}
    */
    readonly headerAction?: ComputeOrganizationSecurityPolicyRuleHeaderAction;
    /**
    * match block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#match ComputeOrganizationSecurityPolicyRule#match}
    */
    readonly match: ComputeOrganizationSecurityPolicyRuleMatch;
    /**
    * preconfigured_waf_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#preconfigured_waf_config ComputeOrganizationSecurityPolicyRule#preconfigured_waf_config}
    */
    readonly preconfiguredWafConfig?: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfig;
    /**
    * redirect_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#redirect_options ComputeOrganizationSecurityPolicyRule#redirect_options}
    */
    readonly redirectOptions?: ComputeOrganizationSecurityPolicyRuleRedirectOptions;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#timeouts ComputeOrganizationSecurityPolicyRule#timeouts}
    */
    readonly timeouts?: ComputeOrganizationSecurityPolicyRuleTimeouts;
}
export interface ComputeOrganizationSecurityPolicyRuleHeaderActionRequestHeadersToAdds {
    /**
    * The name of the header to set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#header_name ComputeOrganizationSecurityPolicyRule#header_name}
    */
    readonly headerName?: string;
    /**
    * The value to set the named header to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#header_value ComputeOrganizationSecurityPolicyRule#header_value}
    */
    readonly headerValue?: string;
}
export declare function computeOrganizationSecurityPolicyRuleHeaderActionRequestHeadersToAddsToTerraform(struct?: ComputeOrganizationSecurityPolicyRuleHeaderActionRequestHeadersToAdds | cdktn.IResolvable): any;
export declare function computeOrganizationSecurityPolicyRuleHeaderActionRequestHeadersToAddsToHclTerraform(struct?: ComputeOrganizationSecurityPolicyRuleHeaderActionRequestHeadersToAdds | cdktn.IResolvable): any;
export declare class ComputeOrganizationSecurityPolicyRuleHeaderActionRequestHeadersToAddsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeOrganizationSecurityPolicyRuleHeaderActionRequestHeadersToAdds | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeOrganizationSecurityPolicyRuleHeaderActionRequestHeadersToAdds | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    resetHeaderName(): void;
    get headerNameInput(): string | undefined;
    private _headerValue?;
    get headerValue(): string;
    set headerValue(value: string);
    resetHeaderValue(): void;
    get headerValueInput(): string | undefined;
}
export declare class ComputeOrganizationSecurityPolicyRuleHeaderActionRequestHeadersToAddsList extends cdktn.ComplexList {
    internalValue?: ComputeOrganizationSecurityPolicyRuleHeaderActionRequestHeadersToAdds[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeOrganizationSecurityPolicyRuleHeaderActionRequestHeadersToAddsOutputReference;
}
export interface ComputeOrganizationSecurityPolicyRuleHeaderAction {
    /**
    * request_headers_to_adds block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#request_headers_to_adds ComputeOrganizationSecurityPolicyRule#request_headers_to_adds}
    */
    readonly requestHeadersToAdds?: ComputeOrganizationSecurityPolicyRuleHeaderActionRequestHeadersToAdds[] | cdktn.IResolvable;
}
export declare function computeOrganizationSecurityPolicyRuleHeaderActionToTerraform(struct?: ComputeOrganizationSecurityPolicyRuleHeaderActionOutputReference | ComputeOrganizationSecurityPolicyRuleHeaderAction): any;
export declare function computeOrganizationSecurityPolicyRuleHeaderActionToHclTerraform(struct?: ComputeOrganizationSecurityPolicyRuleHeaderActionOutputReference | ComputeOrganizationSecurityPolicyRuleHeaderAction): any;
export declare class ComputeOrganizationSecurityPolicyRuleHeaderActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeOrganizationSecurityPolicyRuleHeaderAction | undefined;
    set internalValue(value: ComputeOrganizationSecurityPolicyRuleHeaderAction | undefined);
    private _requestHeadersToAdds;
    get requestHeadersToAdds(): ComputeOrganizationSecurityPolicyRuleHeaderActionRequestHeadersToAddsList;
    putRequestHeadersToAdds(value: ComputeOrganizationSecurityPolicyRuleHeaderActionRequestHeadersToAdds[] | cdktn.IResolvable): void;
    resetRequestHeadersToAdds(): void;
    get requestHeadersToAddsInput(): cdktn.IResolvable | ComputeOrganizationSecurityPolicyRuleHeaderActionRequestHeadersToAdds[] | undefined;
}
export interface ComputeOrganizationSecurityPolicyRuleMatchConfig {
    /**
    * Source IP address range in CIDR format. Required for
    * INGRESS rules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#src_ip_ranges ComputeOrganizationSecurityPolicyRule#src_ip_ranges}
    */
    readonly srcIpRanges?: string[];
}
export declare function computeOrganizationSecurityPolicyRuleMatchConfigToTerraform(struct?: ComputeOrganizationSecurityPolicyRuleMatchConfigOutputReference | ComputeOrganizationSecurityPolicyRuleMatchConfig): any;
export declare function computeOrganizationSecurityPolicyRuleMatchConfigToHclTerraform(struct?: ComputeOrganizationSecurityPolicyRuleMatchConfigOutputReference | ComputeOrganizationSecurityPolicyRuleMatchConfig): any;
export declare class ComputeOrganizationSecurityPolicyRuleMatchConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeOrganizationSecurityPolicyRuleMatchConfig | undefined;
    set internalValue(value: ComputeOrganizationSecurityPolicyRuleMatchConfig | undefined);
    private _srcIpRanges?;
    get srcIpRanges(): string[];
    set srcIpRanges(value: string[]);
    resetSrcIpRanges(): void;
    get srcIpRangesInput(): string[] | undefined;
}
export interface ComputeOrganizationSecurityPolicyRuleMatchExpr {
    /**
    * Textual representation of an expression in Common Expression Language syntax. The application context of the containing message determines which well-known feature set of CEL is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#expression ComputeOrganizationSecurityPolicyRule#expression}
    */
    readonly expression: string;
}
export declare function computeOrganizationSecurityPolicyRuleMatchExprToTerraform(struct?: ComputeOrganizationSecurityPolicyRuleMatchExprOutputReference | ComputeOrganizationSecurityPolicyRuleMatchExpr): any;
export declare function computeOrganizationSecurityPolicyRuleMatchExprToHclTerraform(struct?: ComputeOrganizationSecurityPolicyRuleMatchExprOutputReference | ComputeOrganizationSecurityPolicyRuleMatchExpr): any;
export declare class ComputeOrganizationSecurityPolicyRuleMatchExprOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeOrganizationSecurityPolicyRuleMatchExpr | undefined;
    set internalValue(value: ComputeOrganizationSecurityPolicyRuleMatchExpr | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
}
export interface ComputeOrganizationSecurityPolicyRuleMatch {
    /**
    * A description of the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#description ComputeOrganizationSecurityPolicyRule#description}
    */
    readonly description?: string;
    /**
    * Preconfigured versioned expression. For organization security policy rules,
    * the only supported type is "SRC_IPS_V1".
    * **NOTE** : 'FIREWALL' type is deprecated. Please use 'google_compute_firewall_policy_rule' resource instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#versioned_expr ComputeOrganizationSecurityPolicyRule#versioned_expr}
    */
    readonly versionedExpr?: string;
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#config ComputeOrganizationSecurityPolicyRule#config}
    */
    readonly config?: ComputeOrganizationSecurityPolicyRuleMatchConfig;
    /**
    * expr block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#expr ComputeOrganizationSecurityPolicyRule#expr}
    */
    readonly expr?: ComputeOrganizationSecurityPolicyRuleMatchExpr;
}
export declare function computeOrganizationSecurityPolicyRuleMatchToTerraform(struct?: ComputeOrganizationSecurityPolicyRuleMatchOutputReference | ComputeOrganizationSecurityPolicyRuleMatch): any;
export declare function computeOrganizationSecurityPolicyRuleMatchToHclTerraform(struct?: ComputeOrganizationSecurityPolicyRuleMatchOutputReference | ComputeOrganizationSecurityPolicyRuleMatch): any;
export declare class ComputeOrganizationSecurityPolicyRuleMatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeOrganizationSecurityPolicyRuleMatch | undefined;
    set internalValue(value: ComputeOrganizationSecurityPolicyRuleMatch | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _versionedExpr?;
    get versionedExpr(): string;
    set versionedExpr(value: string);
    resetVersionedExpr(): void;
    get versionedExprInput(): string | undefined;
    private _config;
    get config(): ComputeOrganizationSecurityPolicyRuleMatchConfigOutputReference;
    putConfig(value: ComputeOrganizationSecurityPolicyRuleMatchConfig): void;
    resetConfig(): void;
    get configInput(): ComputeOrganizationSecurityPolicyRuleMatchConfig | undefined;
    private _expr;
    get expr(): ComputeOrganizationSecurityPolicyRuleMatchExprOutputReference;
    putExpr(value: ComputeOrganizationSecurityPolicyRuleMatchExpr): void;
    resetExpr(): void;
    get exprInput(): ComputeOrganizationSecurityPolicyRuleMatchExpr | undefined;
}
export interface ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie {
    /**
    * You can specify an exact match or a partial match by using a field operator and a field value.
    * Available options:
    * EQUALS: The operator matches if the field value equals the specified value.
    * STARTS_WITH: The operator matches if the field value starts with the specified value.
    * ENDS_WITH: The operator matches if the field value ends with the specified value.
    * CONTAINS: The operator matches if the field value contains the specified value.
    * EQUALS_ANY: The operator matches if the field value is any value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#operator ComputeOrganizationSecurityPolicyRule#operator}
    */
    readonly operator: string;
    /**
    * A request field matching the specified value will be excluded from inspection during preconfigured WAF evaluation.
    * The field value must be given if the field operator is not EQUALS_ANY, and cannot be given if the field operator is EQUALS_ANY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#value ComputeOrganizationSecurityPolicyRule#value}
    */
    readonly value?: string;
}
export declare function computeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieToTerraform(struct?: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie | cdktn.IResolvable): any;
export declare function computeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieToHclTerraform(struct?: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie | cdktn.IResolvable): any;
export declare class ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieList extends cdktn.ComplexList {
    internalValue?: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieOutputReference;
}
export interface ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader {
    /**
    * You can specify an exact match or a partial match by using a field operator and a field value.
    * Available options:
    * EQUALS: The operator matches if the field value equals the specified value.
    * STARTS_WITH: The operator matches if the field value starts with the specified value.
    * ENDS_WITH: The operator matches if the field value ends with the specified value.
    * CONTAINS: The operator matches if the field value contains the specified value.
    * EQUALS_ANY: The operator matches if the field value is any value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#operator ComputeOrganizationSecurityPolicyRule#operator}
    */
    readonly operator: string;
    /**
    * A request field matching the specified value will be excluded from inspection during preconfigured WAF evaluation.
    * The field value must be given if the field operator is not EQUALS_ANY, and cannot be given if the field operator is EQUALS_ANY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#value ComputeOrganizationSecurityPolicyRule#value}
    */
    readonly value?: string;
}
export declare function computeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderToTerraform(struct?: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader | cdktn.IResolvable): any;
export declare function computeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderToHclTerraform(struct?: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader | cdktn.IResolvable): any;
export declare class ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderList extends cdktn.ComplexList {
    internalValue?: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderOutputReference;
}
export interface ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam {
    /**
    * You can specify an exact match or a partial match by using a field operator and a field value.
    * Available options:
    * EQUALS: The operator matches if the field value equals the specified value.
    * STARTS_WITH: The operator matches if the field value starts with the specified value.
    * ENDS_WITH: The operator matches if the field value ends with the specified value.
    * CONTAINS: The operator matches if the field value contains the specified value.
    * EQUALS_ANY: The operator matches if the field value is any value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#operator ComputeOrganizationSecurityPolicyRule#operator}
    */
    readonly operator: string;
    /**
    * A request field matching the specified value will be excluded from inspection during preconfigured WAF evaluation.
    * The field value must be given if the field operator is not EQUALS_ANY, and cannot be given if the field operator is EQUALS_ANY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#value ComputeOrganizationSecurityPolicyRule#value}
    */
    readonly value?: string;
}
export declare function computeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamToTerraform(struct?: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam | cdktn.IResolvable): any;
export declare function computeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamToHclTerraform(struct?: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam | cdktn.IResolvable): any;
export declare class ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamList extends cdktn.ComplexList {
    internalValue?: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamOutputReference;
}
export interface ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri {
    /**
    * You can specify an exact match or a partial match by using a field operator and a field value.
    * Available options:
    * EQUALS: The operator matches if the field value equals the specified value.
    * STARTS_WITH: The operator matches if the field value starts with the specified value.
    * ENDS_WITH: The operator matches if the field value ends with the specified value.
    * CONTAINS: The operator matches if the field value contains the specified value.
    * EQUALS_ANY: The operator matches if the field value is any value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#operator ComputeOrganizationSecurityPolicyRule#operator}
    */
    readonly operator: string;
    /**
    * A request field matching the specified value will be excluded from inspection during preconfigured WAF evaluation.
    * The field value must be given if the field operator is not EQUALS_ANY, and cannot be given if the field operator is EQUALS_ANY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#value ComputeOrganizationSecurityPolicyRule#value}
    */
    readonly value?: string;
}
export declare function computeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriToTerraform(struct?: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri | cdktn.IResolvable): any;
export declare function computeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriToHclTerraform(struct?: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri | cdktn.IResolvable): any;
export declare class ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriList extends cdktn.ComplexList {
    internalValue?: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriOutputReference;
}
export interface ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusion {
    /**
    * A list of target rule IDs under the WAF rule set to apply the preconfigured WAF exclusion.
    * If omitted, it refers to all the rule IDs under the WAF rule set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#target_rule_ids ComputeOrganizationSecurityPolicyRule#target_rule_ids}
    */
    readonly targetRuleIds?: string[];
    /**
    * Target WAF rule set to apply the preconfigured WAF exclusion.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#target_rule_set ComputeOrganizationSecurityPolicyRule#target_rule_set}
    */
    readonly targetRuleSet: string;
    /**
    * request_cookie block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#request_cookie ComputeOrganizationSecurityPolicyRule#request_cookie}
    */
    readonly requestCookie?: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie[] | cdktn.IResolvable;
    /**
    * request_header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#request_header ComputeOrganizationSecurityPolicyRule#request_header}
    */
    readonly requestHeader?: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader[] | cdktn.IResolvable;
    /**
    * request_query_param block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#request_query_param ComputeOrganizationSecurityPolicyRule#request_query_param}
    */
    readonly requestQueryParam?: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam[] | cdktn.IResolvable;
    /**
    * request_uri block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#request_uri ComputeOrganizationSecurityPolicyRule#request_uri}
    */
    readonly requestUri?: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri[] | cdktn.IResolvable;
}
export declare function computeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionToTerraform(struct?: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusion | cdktn.IResolvable): any;
export declare function computeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionToHclTerraform(struct?: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusion | cdktn.IResolvable): any;
export declare class ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusion | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusion | cdktn.IResolvable | undefined);
    private _targetRuleIds?;
    get targetRuleIds(): string[];
    set targetRuleIds(value: string[]);
    resetTargetRuleIds(): void;
    get targetRuleIdsInput(): string[] | undefined;
    private _targetRuleSet?;
    get targetRuleSet(): string;
    set targetRuleSet(value: string);
    get targetRuleSetInput(): string | undefined;
    private _requestCookie;
    get requestCookie(): ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieList;
    putRequestCookie(value: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie[] | cdktn.IResolvable): void;
    resetRequestCookie(): void;
    get requestCookieInput(): cdktn.IResolvable | ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie[] | undefined;
    private _requestHeader;
    get requestHeader(): ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderList;
    putRequestHeader(value: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader[] | cdktn.IResolvable): void;
    resetRequestHeader(): void;
    get requestHeaderInput(): cdktn.IResolvable | ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader[] | undefined;
    private _requestQueryParam;
    get requestQueryParam(): ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamList;
    putRequestQueryParam(value: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam[] | cdktn.IResolvable): void;
    resetRequestQueryParam(): void;
    get requestQueryParamInput(): cdktn.IResolvable | ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam[] | undefined;
    private _requestUri;
    get requestUri(): ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriList;
    putRequestUri(value: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri[] | cdktn.IResolvable): void;
    resetRequestUri(): void;
    get requestUriInput(): cdktn.IResolvable | ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri[] | undefined;
}
export declare class ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionList extends cdktn.ComplexList {
    internalValue?: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusion[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionOutputReference;
}
export interface ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfig {
    /**
    * exclusion block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#exclusion ComputeOrganizationSecurityPolicyRule#exclusion}
    */
    readonly exclusion?: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusion[] | cdktn.IResolvable;
}
export declare function computeOrganizationSecurityPolicyRulePreconfiguredWafConfigToTerraform(struct?: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigOutputReference | ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfig): any;
export declare function computeOrganizationSecurityPolicyRulePreconfiguredWafConfigToHclTerraform(struct?: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigOutputReference | ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfig): any;
export declare class ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfig | undefined;
    set internalValue(value: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfig | undefined);
    private _exclusion;
    get exclusion(): ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusionList;
    putExclusion(value: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusion[] | cdktn.IResolvable): void;
    resetExclusion(): void;
    get exclusionInput(): cdktn.IResolvable | ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigExclusion[] | undefined;
}
export interface ComputeOrganizationSecurityPolicyRuleRedirectOptions {
    /**
    * Target for the redirect action. This is required if the type is EXTERNAL_302.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#target ComputeOrganizationSecurityPolicyRule#target}
    */
    readonly target?: string;
    /**
    * Type of the redirect action. For organization security policies, only EXTERNAL_302 is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#type ComputeOrganizationSecurityPolicyRule#type}
    */
    readonly type: string;
}
export declare function computeOrganizationSecurityPolicyRuleRedirectOptionsToTerraform(struct?: ComputeOrganizationSecurityPolicyRuleRedirectOptionsOutputReference | ComputeOrganizationSecurityPolicyRuleRedirectOptions): any;
export declare function computeOrganizationSecurityPolicyRuleRedirectOptionsToHclTerraform(struct?: ComputeOrganizationSecurityPolicyRuleRedirectOptionsOutputReference | ComputeOrganizationSecurityPolicyRuleRedirectOptions): any;
export declare class ComputeOrganizationSecurityPolicyRuleRedirectOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeOrganizationSecurityPolicyRuleRedirectOptions | undefined;
    set internalValue(value: ComputeOrganizationSecurityPolicyRuleRedirectOptions | undefined);
    private _target?;
    get target(): string;
    set target(value: string);
    resetTarget(): void;
    get targetInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface ComputeOrganizationSecurityPolicyRuleTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#create ComputeOrganizationSecurityPolicyRule#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#delete ComputeOrganizationSecurityPolicyRule#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#update ComputeOrganizationSecurityPolicyRule#update}
    */
    readonly update?: string;
}
export declare function computeOrganizationSecurityPolicyRuleTimeoutsToTerraform(struct?: ComputeOrganizationSecurityPolicyRuleTimeouts | cdktn.IResolvable): any;
export declare function computeOrganizationSecurityPolicyRuleTimeoutsToHclTerraform(struct?: ComputeOrganizationSecurityPolicyRuleTimeouts | cdktn.IResolvable): any;
export declare class ComputeOrganizationSecurityPolicyRuleTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeOrganizationSecurityPolicyRuleTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeOrganizationSecurityPolicyRuleTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule google_compute_organization_security_policy_rule}
*/
export declare class ComputeOrganizationSecurityPolicyRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_organization_security_policy_rule";
    /**
    * Generates CDKTN code for importing a ComputeOrganizationSecurityPolicyRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeOrganizationSecurityPolicyRule to import
    * @param importFromId The id of the existing ComputeOrganizationSecurityPolicyRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeOrganizationSecurityPolicyRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_organization_security_policy_rule google_compute_organization_security_policy_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeOrganizationSecurityPolicyRuleConfig
    */
    constructor(scope: Construct, id: string, config: ComputeOrganizationSecurityPolicyRuleConfig);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    get policyIdInput(): string | undefined;
    private _preview?;
    get preview(): boolean | cdktn.IResolvable;
    set preview(value: boolean | cdktn.IResolvable);
    resetPreview(): void;
    get previewInput(): boolean | cdktn.IResolvable | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
    private _headerAction;
    get headerAction(): ComputeOrganizationSecurityPolicyRuleHeaderActionOutputReference;
    putHeaderAction(value: ComputeOrganizationSecurityPolicyRuleHeaderAction): void;
    resetHeaderAction(): void;
    get headerActionInput(): ComputeOrganizationSecurityPolicyRuleHeaderAction | undefined;
    private _match;
    get match(): ComputeOrganizationSecurityPolicyRuleMatchOutputReference;
    putMatch(value: ComputeOrganizationSecurityPolicyRuleMatch): void;
    get matchInput(): ComputeOrganizationSecurityPolicyRuleMatch | undefined;
    private _preconfiguredWafConfig;
    get preconfiguredWafConfig(): ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfigOutputReference;
    putPreconfiguredWafConfig(value: ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfig): void;
    resetPreconfiguredWafConfig(): void;
    get preconfiguredWafConfigInput(): ComputeOrganizationSecurityPolicyRulePreconfiguredWafConfig | undefined;
    private _redirectOptions;
    get redirectOptions(): ComputeOrganizationSecurityPolicyRuleRedirectOptionsOutputReference;
    putRedirectOptions(value: ComputeOrganizationSecurityPolicyRuleRedirectOptions): void;
    resetRedirectOptions(): void;
    get redirectOptionsInput(): ComputeOrganizationSecurityPolicyRuleRedirectOptions | undefined;
    private _timeouts;
    get timeouts(): ComputeOrganizationSecurityPolicyRuleTimeoutsOutputReference;
    putTimeouts(value: ComputeOrganizationSecurityPolicyRuleTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeOrganizationSecurityPolicyRuleTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
