/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeInterconnectAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether the VLAN attachment is enabled or disabled.  When using
    * PARTNER type this will Pre-Activate the interconnect attachment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#admin_enabled ComputeInterconnectAttachment#admin_enabled}
    */
    readonly adminEnabled?: boolean | cdktn.IResolvable;
    /**
    * Provisioned bandwidth capacity for the interconnect attachment.
    * For attachments of type DEDICATED, the user can set the bandwidth.
    * For attachments of type PARTNER, the Google Partner that is operating the interconnect must set the bandwidth.
    * Output only for PARTNER type, mutable for PARTNER_PROVIDER and DEDICATED,
    * Defaults to BPS_10G Possible values: ["BPS_50M", "BPS_100M", "BPS_200M", "BPS_300M", "BPS_400M", "BPS_500M", "BPS_1G", "BPS_2G", "BPS_5G", "BPS_10G", "BPS_20G", "BPS_50G", "BPS_100G", "BPS_400G"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#bandwidth ComputeInterconnectAttachment#bandwidth}
    */
    readonly bandwidth?: string;
    /**
    * Single IPv4 address + prefix length to be configured on the cloud router interface for this
    * interconnect attachment. Example: 203.0.113.1/29
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#candidate_cloud_router_ip_address ComputeInterconnectAttachment#candidate_cloud_router_ip_address}
    */
    readonly candidateCloudRouterIpAddress?: string;
    /**
    * Single IPv6 address + prefix length to be configured on the cloud router interface for this
    * interconnect attachment. Example: 2001:db8::1/125
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#candidate_cloud_router_ipv6_address ComputeInterconnectAttachment#candidate_cloud_router_ipv6_address}
    */
    readonly candidateCloudRouterIpv6Address?: string;
    /**
    * Single IPv4 address + prefix length to be configured on the customer router interface for this
    * interconnect attachment. Example: 203.0.113.2/29
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#candidate_customer_router_ip_address ComputeInterconnectAttachment#candidate_customer_router_ip_address}
    */
    readonly candidateCustomerRouterIpAddress?: string;
    /**
    * Single IPv6 address + prefix length to be configured on the customer router interface for this
    * interconnect attachment. Example: 2001:db8::2/125
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#candidate_customer_router_ipv6_address ComputeInterconnectAttachment#candidate_customer_router_ipv6_address}
    */
    readonly candidateCustomerRouterIpv6Address?: string;
    /**
    * Up to 16 candidate prefixes that can be used to restrict the allocation
    * of cloudRouterIpAddress and customerRouterIpAddress for this attachment.
    * All prefixes must be within link-local address space (169.254.0.0/16)
    * and must be /29 or shorter (/28, /27, etc). Google will attempt to select
    * an unused /29 from the supplied candidate prefix(es). The request will
    * fail if all possible /29s are in use on Google's edge. If not supplied,
    * Google will randomly select an unused /29 from all of link-local space.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#candidate_subnets ComputeInterconnectAttachment#candidate_subnets}
    */
    readonly candidateSubnets?: string[];
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#deletion_policy ComputeInterconnectAttachment#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#description ComputeInterconnectAttachment#description}
    */
    readonly description?: string;
    /**
    * Desired availability domain for the attachment. Only available for type
    * PARTNER, at creation time. For improved reliability, customers should
    * configure a pair of attachments with one per availability domain. The
    * selected availability domain will be provided to the Partner via the
    * pairing key so that the provisioned circuit will lie in the specified
    * domain. If not specified, the value will default to AVAILABILITY_DOMAIN_ANY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#edge_availability_domain ComputeInterconnectAttachment#edge_availability_domain}
    */
    readonly edgeAvailabilityDomain?: string;
    /**
    * Indicates the user-supplied encryption option of this interconnect
    * attachment. Can only be specified at attachment creation for PARTNER or
    * DEDICATED attachments.
    * * NONE - This is the default value, which means that the VLAN attachment
    * carries unencrypted traffic. VMs are able to send traffic to, or receive
    * traffic from, such a VLAN attachment.
    * * IPSEC - The VLAN attachment carries only encrypted traffic that is
    * encrypted by an IPsec device, such as an HA VPN gateway or third-party
    * IPsec VPN. VMs cannot directly send traffic to, or receive traffic from,
    * such a VLAN attachment. To use HA VPN over Cloud Interconnect, the VLAN
    * attachment must be created with this option. Default value: "NONE" Possible values: ["NONE", "IPSEC"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#encryption ComputeInterconnectAttachment#encryption}
    */
    readonly encryption?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#id ComputeInterconnectAttachment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * URL of the underlying Interconnect object that this attachment's
    * traffic will traverse through. Required if type is DEDICATED, must not
    * be set if type is PARTNER.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#interconnect ComputeInterconnectAttachment#interconnect}
    */
    readonly interconnect?: string;
    /**
    * URL of addresses that have been reserved for the interconnect attachment,
    * Used only for interconnect attachment that has the encryption option as
    * IPSEC.
    * The addresses must be RFC 1918 IP address ranges. When creating HA VPN
    * gateway over the interconnect attachment, if the attachment is configured
    * to use an RFC 1918 IP address, then the VPN gateway's IP address will be
    * allocated from the IP address range specified here.
    * For example, if the HA VPN gateway's interface 0 is paired to this
    * interconnect attachment, then an RFC 1918 IP address for the VPN gateway
    * interface 0 will be allocated from the IP address specified for this
    * interconnect attachment.
    * If this field is not specified for interconnect attachment that has
    * encryption option as IPSEC, later on when creating HA VPN gateway on this
    * interconnect attachment, the HA VPN gateway's IP address will be
    * allocated from regional external IP address pool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#ipsec_internal_addresses ComputeInterconnectAttachment#ipsec_internal_addresses}
    */
    readonly ipsecInternalAddresses?: string[];
    /**
    * Labels for this resource. These can only be added or modified by the setLabels
    * method. Each label key/value pair must comply with RFC1035. Label values may be empty.
    *
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#labels ComputeInterconnectAttachment#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Maximum Transmission Unit (MTU), in bytes, of packets passing through this interconnect attachment.
    * Valid values are 1440, 1460, 1500, and 8896. If not specified, the value will default to 1440.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#mtu ComputeInterconnectAttachment#mtu}
    */
    readonly mtu?: string;
    /**
    * Name of the resource. Provided by the client when the resource is created. The
    * name must be 1-63 characters long, and comply with RFC1035. Specifically, the
    * name must be 1-63 characters long and match the regular expression
    * '[a-z]([-a-z0-9]*[a-z0-9])?' which means the first character must be a
    * lowercase letter, and all following characters must be a dash, lowercase
    * letter, or digit, except the last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#name ComputeInterconnectAttachment#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#project ComputeInterconnectAttachment#project}
    */
    readonly project?: string;
    /**
    * Region where the regional interconnect attachment resides.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#region ComputeInterconnectAttachment#region}
    */
    readonly region?: string;
    /**
    * URL of the cloud router to be used for dynamic routing. This router must be in
    * the same region as this InterconnectAttachment. The InterconnectAttachment will
    * automatically connect the Interconnect to the network & region within which the
    * Cloud Router is configured.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#router ComputeInterconnectAttachment#router}
    */
    readonly router?: string;
    /**
    * The stack type for this interconnect attachment to identify whether the IPv6
    * feature is enabled or not. If not specified, IPV4_ONLY will be used.
    * This field can be both set at interconnect attachments creation and update
    * interconnect attachment operations. Possible values: ["IPV4_IPV6", "IPV4_ONLY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#stack_type ComputeInterconnectAttachment#stack_type}
    */
    readonly stackType?: string;
    /**
    * Length of the IPv4 subnet mask. Allowed values: 29 (default), 30. The default value is 29,
    * except for Cross-Cloud Interconnect connections that use an InterconnectRemoteLocation with a
    * constraints.subnetLengthRange.min equal to 30. For example, connections that use an Azure
    * remote location fall into this category. In these cases, the default value is 30, and
    * requesting 29 returns an error. Where both 29 and 30 are allowed, 29 is preferred, because it
    * gives Google Cloud Support more debugging visibility.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#subnet_length ComputeInterconnectAttachment#subnet_length}
    */
    readonly subnetLength?: number;
    /**
    * The type of InterconnectAttachment you wish to create. Defaults to
    * DEDICATED. Possible values: ["DEDICATED", "PARTNER", "PARTNER_PROVIDER", "L2_DEDICATED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#type ComputeInterconnectAttachment#type}
    */
    readonly type?: string;
    /**
    * The IEEE 802.1Q VLAN tag for this attachment, in the range 2-4094. When
    * using PARTNER type this will be managed upstream.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#vlan_tag8021q ComputeInterconnectAttachment#vlan_tag8021q}
    */
    readonly vlanTag8021Q?: number;
    /**
    * l2_forwarding block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#l2_forwarding ComputeInterconnectAttachment#l2_forwarding}
    */
    readonly l2Forwarding?: ComputeInterconnectAttachmentL2Forwarding;
    /**
    * params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#params ComputeInterconnectAttachment#params}
    */
    readonly params?: ComputeInterconnectAttachmentParams;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#timeouts ComputeInterconnectAttachment#timeouts}
    */
    readonly timeouts?: ComputeInterconnectAttachmentTimeouts;
}
export interface ComputeInterconnectAttachmentPrivateInterconnectInfo {
}
export declare function computeInterconnectAttachmentPrivateInterconnectInfoToTerraform(struct?: ComputeInterconnectAttachmentPrivateInterconnectInfo): any;
export declare function computeInterconnectAttachmentPrivateInterconnectInfoToHclTerraform(struct?: ComputeInterconnectAttachmentPrivateInterconnectInfo): any;
export declare class ComputeInterconnectAttachmentPrivateInterconnectInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInterconnectAttachmentPrivateInterconnectInfo | undefined;
    set internalValue(value: ComputeInterconnectAttachmentPrivateInterconnectInfo | undefined);
    get tag8021Q(): number;
}
export declare class ComputeInterconnectAttachmentPrivateInterconnectInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInterconnectAttachmentPrivateInterconnectInfoOutputReference;
}
export interface ComputeInterconnectAttachmentL2ForwardingApplianceMappingsInnerVlanToApplianceMappings {
    /**
    * The inner appliance IP address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#inner_appliance_ip_address ComputeInterconnectAttachment#inner_appliance_ip_address}
    */
    readonly innerApplianceIpAddress?: string;
    /**
    * List of inner VLAN tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#inner_vlan_tags ComputeInterconnectAttachment#inner_vlan_tags}
    */
    readonly innerVlanTags?: string[];
}
export declare function computeInterconnectAttachmentL2ForwardingApplianceMappingsInnerVlanToApplianceMappingsToTerraform(struct?: ComputeInterconnectAttachmentL2ForwardingApplianceMappingsInnerVlanToApplianceMappings | cdktn.IResolvable): any;
export declare function computeInterconnectAttachmentL2ForwardingApplianceMappingsInnerVlanToApplianceMappingsToHclTerraform(struct?: ComputeInterconnectAttachmentL2ForwardingApplianceMappingsInnerVlanToApplianceMappings | cdktn.IResolvable): any;
export declare class ComputeInterconnectAttachmentL2ForwardingApplianceMappingsInnerVlanToApplianceMappingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInterconnectAttachmentL2ForwardingApplianceMappingsInnerVlanToApplianceMappings | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInterconnectAttachmentL2ForwardingApplianceMappingsInnerVlanToApplianceMappings | cdktn.IResolvable | undefined);
    private _innerApplianceIpAddress?;
    get innerApplianceIpAddress(): string;
    set innerApplianceIpAddress(value: string);
    resetInnerApplianceIpAddress(): void;
    get innerApplianceIpAddressInput(): string | undefined;
    private _innerVlanTags?;
    get innerVlanTags(): string[];
    set innerVlanTags(value: string[]);
    resetInnerVlanTags(): void;
    get innerVlanTagsInput(): string[] | undefined;
}
export declare class ComputeInterconnectAttachmentL2ForwardingApplianceMappingsInnerVlanToApplianceMappingsList extends cdktn.ComplexList {
    internalValue?: ComputeInterconnectAttachmentL2ForwardingApplianceMappingsInnerVlanToApplianceMappings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInterconnectAttachmentL2ForwardingApplianceMappingsInnerVlanToApplianceMappingsOutputReference;
}
export interface ComputeInterconnectAttachmentL2ForwardingApplianceMappings {
    /**
    * The appliance IP address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#appliance_ip_address ComputeInterconnectAttachment#appliance_ip_address}
    */
    readonly applianceIpAddress?: string;
    /**
    * The name of this appliance mapping rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#name ComputeInterconnectAttachment#name}
    */
    readonly name?: string;
    /**
    * The VLAN tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#vlan_id ComputeInterconnectAttachment#vlan_id}
    */
    readonly vlanId?: string;
    /**
    * inner_vlan_to_appliance_mappings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#inner_vlan_to_appliance_mappings ComputeInterconnectAttachment#inner_vlan_to_appliance_mappings}
    */
    readonly innerVlanToApplianceMappings?: ComputeInterconnectAttachmentL2ForwardingApplianceMappingsInnerVlanToApplianceMappings[] | cdktn.IResolvable;
}
export declare function computeInterconnectAttachmentL2ForwardingApplianceMappingsToTerraform(struct?: ComputeInterconnectAttachmentL2ForwardingApplianceMappings | cdktn.IResolvable): any;
export declare function computeInterconnectAttachmentL2ForwardingApplianceMappingsToHclTerraform(struct?: ComputeInterconnectAttachmentL2ForwardingApplianceMappings | cdktn.IResolvable): any;
export declare class ComputeInterconnectAttachmentL2ForwardingApplianceMappingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInterconnectAttachmentL2ForwardingApplianceMappings | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInterconnectAttachmentL2ForwardingApplianceMappings | cdktn.IResolvable | undefined);
    private _applianceIpAddress?;
    get applianceIpAddress(): string;
    set applianceIpAddress(value: string);
    resetApplianceIpAddress(): void;
    get applianceIpAddressInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _vlanId?;
    get vlanId(): string;
    set vlanId(value: string);
    resetVlanId(): void;
    get vlanIdInput(): string | undefined;
    private _innerVlanToApplianceMappings;
    get innerVlanToApplianceMappings(): ComputeInterconnectAttachmentL2ForwardingApplianceMappingsInnerVlanToApplianceMappingsList;
    putInnerVlanToApplianceMappings(value: ComputeInterconnectAttachmentL2ForwardingApplianceMappingsInnerVlanToApplianceMappings[] | cdktn.IResolvable): void;
    resetInnerVlanToApplianceMappings(): void;
    get innerVlanToApplianceMappingsInput(): cdktn.IResolvable | ComputeInterconnectAttachmentL2ForwardingApplianceMappingsInnerVlanToApplianceMappings[] | undefined;
}
export declare class ComputeInterconnectAttachmentL2ForwardingApplianceMappingsList extends cdktn.ComplexList {
    internalValue?: ComputeInterconnectAttachmentL2ForwardingApplianceMappings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInterconnectAttachmentL2ForwardingApplianceMappingsOutputReference;
}
export interface ComputeInterconnectAttachmentL2ForwardingGeneveHeader {
    /**
    * VNI is a 24-bit unique virtual network identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#vni ComputeInterconnectAttachment#vni}
    */
    readonly vni?: number;
}
export declare function computeInterconnectAttachmentL2ForwardingGeneveHeaderToTerraform(struct?: ComputeInterconnectAttachmentL2ForwardingGeneveHeaderOutputReference | ComputeInterconnectAttachmentL2ForwardingGeneveHeader): any;
export declare function computeInterconnectAttachmentL2ForwardingGeneveHeaderToHclTerraform(struct?: ComputeInterconnectAttachmentL2ForwardingGeneveHeaderOutputReference | ComputeInterconnectAttachmentL2ForwardingGeneveHeader): any;
export declare class ComputeInterconnectAttachmentL2ForwardingGeneveHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInterconnectAttachmentL2ForwardingGeneveHeader | undefined;
    set internalValue(value: ComputeInterconnectAttachmentL2ForwardingGeneveHeader | undefined);
    private _vni?;
    get vni(): number;
    set vni(value: number);
    resetVni(): void;
    get vniInput(): number | undefined;
}
export interface ComputeInterconnectAttachmentL2Forwarding {
    /**
    * The default appliance IP address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#default_appliance_ip_address ComputeInterconnectAttachment#default_appliance_ip_address}
    */
    readonly defaultApplianceIpAddress?: string;
    /**
    * URL of the network to which this attachment belongs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#network ComputeInterconnectAttachment#network}
    */
    readonly network?: string;
    /**
    * The tunnel endpoint IP address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#tunnel_endpoint_ip_address ComputeInterconnectAttachment#tunnel_endpoint_ip_address}
    */
    readonly tunnelEndpointIpAddress?: string;
    /**
    * appliance_mappings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#appliance_mappings ComputeInterconnectAttachment#appliance_mappings}
    */
    readonly applianceMappings?: ComputeInterconnectAttachmentL2ForwardingApplianceMappings[] | cdktn.IResolvable;
    /**
    * geneve_header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#geneve_header ComputeInterconnectAttachment#geneve_header}
    */
    readonly geneveHeader?: ComputeInterconnectAttachmentL2ForwardingGeneveHeader;
}
export declare function computeInterconnectAttachmentL2ForwardingToTerraform(struct?: ComputeInterconnectAttachmentL2ForwardingOutputReference | ComputeInterconnectAttachmentL2Forwarding): any;
export declare function computeInterconnectAttachmentL2ForwardingToHclTerraform(struct?: ComputeInterconnectAttachmentL2ForwardingOutputReference | ComputeInterconnectAttachmentL2Forwarding): any;
export declare class ComputeInterconnectAttachmentL2ForwardingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInterconnectAttachmentL2Forwarding | undefined;
    set internalValue(value: ComputeInterconnectAttachmentL2Forwarding | undefined);
    private _defaultApplianceIpAddress?;
    get defaultApplianceIpAddress(): string;
    set defaultApplianceIpAddress(value: string);
    resetDefaultApplianceIpAddress(): void;
    get defaultApplianceIpAddressInput(): string | undefined;
    private _network?;
    get network(): string;
    set network(value: string);
    resetNetwork(): void;
    get networkInput(): string | undefined;
    private _tunnelEndpointIpAddress?;
    get tunnelEndpointIpAddress(): string;
    set tunnelEndpointIpAddress(value: string);
    resetTunnelEndpointIpAddress(): void;
    get tunnelEndpointIpAddressInput(): string | undefined;
    private _applianceMappings;
    get applianceMappings(): ComputeInterconnectAttachmentL2ForwardingApplianceMappingsList;
    putApplianceMappings(value: ComputeInterconnectAttachmentL2ForwardingApplianceMappings[] | cdktn.IResolvable): void;
    resetApplianceMappings(): void;
    get applianceMappingsInput(): cdktn.IResolvable | ComputeInterconnectAttachmentL2ForwardingApplianceMappings[] | undefined;
    private _geneveHeader;
    get geneveHeader(): ComputeInterconnectAttachmentL2ForwardingGeneveHeaderOutputReference;
    putGeneveHeader(value: ComputeInterconnectAttachmentL2ForwardingGeneveHeader): void;
    resetGeneveHeader(): void;
    get geneveHeaderInput(): ComputeInterconnectAttachmentL2ForwardingGeneveHeader | undefined;
}
export interface ComputeInterconnectAttachmentParams {
    /**
    * Resource manager tags to be bound to the interconnect attachment. Tag keys and values have the
    * same definition as resource manager tags. Keys must be in the format tagKeys/{tag_key_id},
    * and values are in the format tagValues/456.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#resource_manager_tags ComputeInterconnectAttachment#resource_manager_tags}
    */
    readonly resourceManagerTags?: {
        [key: string]: string;
    };
}
export declare function computeInterconnectAttachmentParamsToTerraform(struct?: ComputeInterconnectAttachmentParamsOutputReference | ComputeInterconnectAttachmentParams): any;
export declare function computeInterconnectAttachmentParamsToHclTerraform(struct?: ComputeInterconnectAttachmentParamsOutputReference | ComputeInterconnectAttachmentParams): any;
export declare class ComputeInterconnectAttachmentParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInterconnectAttachmentParams | undefined;
    set internalValue(value: ComputeInterconnectAttachmentParams | undefined);
    private _resourceManagerTags?;
    get resourceManagerTags(): {
        [key: string]: string;
    };
    set resourceManagerTags(value: {
        [key: string]: string;
    });
    resetResourceManagerTags(): void;
    get resourceManagerTagsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ComputeInterconnectAttachmentTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#create ComputeInterconnectAttachment#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#delete ComputeInterconnectAttachment#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#update ComputeInterconnectAttachment#update}
    */
    readonly update?: string;
}
export declare function computeInterconnectAttachmentTimeoutsToTerraform(struct?: ComputeInterconnectAttachmentTimeouts | cdktn.IResolvable): any;
export declare function computeInterconnectAttachmentTimeoutsToHclTerraform(struct?: ComputeInterconnectAttachmentTimeouts | cdktn.IResolvable): any;
export declare class ComputeInterconnectAttachmentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInterconnectAttachmentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInterconnectAttachmentTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment google_compute_interconnect_attachment}
*/
export declare class ComputeInterconnectAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_interconnect_attachment";
    /**
    * Generates CDKTN code for importing a ComputeInterconnectAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeInterconnectAttachment to import
    * @param importFromId The id of the existing ComputeInterconnectAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeInterconnectAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment google_compute_interconnect_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeInterconnectAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: ComputeInterconnectAttachmentConfig);
    private _adminEnabled?;
    get adminEnabled(): boolean | cdktn.IResolvable;
    set adminEnabled(value: boolean | cdktn.IResolvable);
    resetAdminEnabled(): void;
    get adminEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get attachmentGroup(): string;
    private _bandwidth?;
    get bandwidth(): string;
    set bandwidth(value: string);
    resetBandwidth(): void;
    get bandwidthInput(): string | undefined;
    private _candidateCloudRouterIpAddress?;
    get candidateCloudRouterIpAddress(): string;
    set candidateCloudRouterIpAddress(value: string);
    resetCandidateCloudRouterIpAddress(): void;
    get candidateCloudRouterIpAddressInput(): string | undefined;
    private _candidateCloudRouterIpv6Address?;
    get candidateCloudRouterIpv6Address(): string;
    set candidateCloudRouterIpv6Address(value: string);
    resetCandidateCloudRouterIpv6Address(): void;
    get candidateCloudRouterIpv6AddressInput(): string | undefined;
    private _candidateCustomerRouterIpAddress?;
    get candidateCustomerRouterIpAddress(): string;
    set candidateCustomerRouterIpAddress(value: string);
    resetCandidateCustomerRouterIpAddress(): void;
    get candidateCustomerRouterIpAddressInput(): string | undefined;
    private _candidateCustomerRouterIpv6Address?;
    get candidateCustomerRouterIpv6Address(): string;
    set candidateCustomerRouterIpv6Address(value: string);
    resetCandidateCustomerRouterIpv6Address(): void;
    get candidateCustomerRouterIpv6AddressInput(): string | undefined;
    private _candidateSubnets?;
    get candidateSubnets(): string[];
    set candidateSubnets(value: string[]);
    resetCandidateSubnets(): void;
    get candidateSubnetsInput(): string[] | undefined;
    get cloudRouterIpAddress(): string;
    get cloudRouterIpv6Address(): string;
    get creationTimestamp(): string;
    get customerRouterIpAddress(): string;
    get customerRouterIpv6Address(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _edgeAvailabilityDomain?;
    get edgeAvailabilityDomain(): string;
    set edgeAvailabilityDomain(value: string);
    resetEdgeAvailabilityDomain(): void;
    get edgeAvailabilityDomainInput(): string | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _encryption?;
    get encryption(): string;
    set encryption(value: string);
    resetEncryption(): void;
    get encryptionInput(): string | undefined;
    get googleReferenceId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _interconnect?;
    get interconnect(): string;
    set interconnect(value: string);
    resetInterconnect(): void;
    get interconnectInput(): string | undefined;
    private _ipsecInternalAddresses?;
    get ipsecInternalAddresses(): string[];
    set ipsecInternalAddresses(value: string[]);
    resetIpsecInternalAddresses(): void;
    get ipsecInternalAddressesInput(): string[] | undefined;
    get labelFingerprint(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _mtu?;
    get mtu(): string;
    set mtu(value: string);
    resetMtu(): void;
    get mtuInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get pairingKey(): string;
    get partnerAsn(): string;
    private _privateInterconnectInfo;
    get privateInterconnectInfo(): ComputeInterconnectAttachmentPrivateInterconnectInfoList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _router?;
    get router(): string;
    set router(value: string);
    resetRouter(): void;
    get routerInput(): string | undefined;
    get selfLink(): string;
    private _stackType?;
    get stackType(): string;
    set stackType(value: string);
    resetStackType(): void;
    get stackTypeInput(): string | undefined;
    get state(): string;
    private _subnetLength?;
    get subnetLength(): number;
    set subnetLength(value: number);
    resetSubnetLength(): void;
    get subnetLengthInput(): number | undefined;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _vlanTag8021Q?;
    get vlanTag8021Q(): number;
    set vlanTag8021Q(value: number);
    resetVlanTag8021Q(): void;
    get vlanTag8021QInput(): number | undefined;
    private _l2Forwarding;
    get l2Forwarding(): ComputeInterconnectAttachmentL2ForwardingOutputReference;
    putL2Forwarding(value: ComputeInterconnectAttachmentL2Forwarding): void;
    resetL2Forwarding(): void;
    get l2ForwardingInput(): ComputeInterconnectAttachmentL2Forwarding | undefined;
    private _params;
    get params(): ComputeInterconnectAttachmentParamsOutputReference;
    putParams(value: ComputeInterconnectAttachmentParams): void;
    resetParams(): void;
    get paramsInput(): ComputeInterconnectAttachmentParams | undefined;
    private _timeouts;
    get timeouts(): ComputeInterconnectAttachmentTimeoutsOutputReference;
    putTimeouts(value: ComputeInterconnectAttachmentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeInterconnectAttachmentTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
