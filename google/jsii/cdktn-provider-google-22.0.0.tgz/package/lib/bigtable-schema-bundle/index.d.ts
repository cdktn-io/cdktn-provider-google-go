/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BigtableSchemaBundleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_schema_bundle#deletion_policy BigtableSchemaBundle#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_schema_bundle#id BigtableSchemaBundle#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * If true, allow backwards incompatible changes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_schema_bundle#ignore_warnings BigtableSchemaBundle#ignore_warnings}
    */
    readonly ignoreWarnings?: boolean | cdktn.IResolvable;
    /**
    * The name of the instance to create the schema bundle within.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_schema_bundle#instance BigtableSchemaBundle#instance}
    */
    readonly instance?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_schema_bundle#project BigtableSchemaBundle#project}
    */
    readonly project?: string;
    /**
    * The unique name of the schema bundle in the form '[_a-zA-Z0-9][-_.a-zA-Z0-9]*'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_schema_bundle#schema_bundle_id BigtableSchemaBundle#schema_bundle_id}
    */
    readonly schemaBundleId: string;
    /**
    * The name of the table to create the schema bundle within.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_schema_bundle#table BigtableSchemaBundle#table}
    */
    readonly table?: string;
    /**
    * proto_schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_schema_bundle#proto_schema BigtableSchemaBundle#proto_schema}
    */
    readonly protoSchema: BigtableSchemaBundleProtoSchema;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_schema_bundle#timeouts BigtableSchemaBundle#timeouts}
    */
    readonly timeouts?: BigtableSchemaBundleTimeouts;
}
export interface BigtableSchemaBundleProtoSchema {
    /**
    * Base64 encoded content of the file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_schema_bundle#proto_descriptors BigtableSchemaBundle#proto_descriptors}
    */
    readonly protoDescriptors: string;
}
export declare function bigtableSchemaBundleProtoSchemaToTerraform(struct?: BigtableSchemaBundleProtoSchemaOutputReference | BigtableSchemaBundleProtoSchema): any;
export declare function bigtableSchemaBundleProtoSchemaToHclTerraform(struct?: BigtableSchemaBundleProtoSchemaOutputReference | BigtableSchemaBundleProtoSchema): any;
export declare class BigtableSchemaBundleProtoSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigtableSchemaBundleProtoSchema | undefined;
    set internalValue(value: BigtableSchemaBundleProtoSchema | undefined);
    private _protoDescriptors?;
    get protoDescriptors(): string;
    set protoDescriptors(value: string);
    get protoDescriptorsInput(): string | undefined;
}
export interface BigtableSchemaBundleTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_schema_bundle#create BigtableSchemaBundle#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_schema_bundle#delete BigtableSchemaBundle#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_schema_bundle#update BigtableSchemaBundle#update}
    */
    readonly update?: string;
}
export declare function bigtableSchemaBundleTimeoutsToTerraform(struct?: BigtableSchemaBundleTimeouts | cdktn.IResolvable): any;
export declare function bigtableSchemaBundleTimeoutsToHclTerraform(struct?: BigtableSchemaBundleTimeouts | cdktn.IResolvable): any;
export declare class BigtableSchemaBundleTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigtableSchemaBundleTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BigtableSchemaBundleTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_schema_bundle google_bigtable_schema_bundle}
*/
export declare class BigtableSchemaBundle extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_bigtable_schema_bundle";
    /**
    * Generates CDKTN code for importing a BigtableSchemaBundle resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BigtableSchemaBundle to import
    * @param importFromId The id of the existing BigtableSchemaBundle that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_schema_bundle#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BigtableSchemaBundle to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_schema_bundle google_bigtable_schema_bundle} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BigtableSchemaBundleConfig
    */
    constructor(scope: Construct, id: string, config: BigtableSchemaBundleConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ignoreWarnings?;
    get ignoreWarnings(): boolean | cdktn.IResolvable;
    set ignoreWarnings(value: boolean | cdktn.IResolvable);
    resetIgnoreWarnings(): void;
    get ignoreWarningsInput(): boolean | cdktn.IResolvable | undefined;
    private _instance?;
    get instance(): string;
    set instance(value: string);
    resetInstance(): void;
    get instanceInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _schemaBundleId?;
    get schemaBundleId(): string;
    set schemaBundleId(value: string);
    get schemaBundleIdInput(): string | undefined;
    private _table?;
    get table(): string;
    set table(value: string);
    resetTable(): void;
    get tableInput(): string | undefined;
    private _protoSchema;
    get protoSchema(): BigtableSchemaBundleProtoSchemaOutputReference;
    putProtoSchema(value: BigtableSchemaBundleProtoSchema): void;
    get protoSchemaInput(): BigtableSchemaBundleProtoSchema | undefined;
    private _timeouts;
    get timeouts(): BigtableSchemaBundleTimeoutsOutputReference;
    putTimeouts(value: BigtableSchemaBundleTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BigtableSchemaBundleTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
