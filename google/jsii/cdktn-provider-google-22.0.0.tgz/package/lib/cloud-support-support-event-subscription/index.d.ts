/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudSupportSupportEventSubscriptionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_support_support_event_subscription#deletion_policy CloudSupportSupportEventSubscription#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_support_support_event_subscription#id CloudSupportSupportEventSubscription#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The organization ID for the support event subscription.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_support_support_event_subscription#organization CloudSupportSupportEventSubscription#organization}
    */
    readonly organization: string;
    /**
    * The name of the Pub/Sub topic to publish notifications to.
    * Format: projects/{project}/topics/{topic}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_support_support_event_subscription#pub_sub_topic CloudSupportSupportEventSubscription#pub_sub_topic}
    */
    readonly pubSubTopic: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_support_support_event_subscription#timeouts CloudSupportSupportEventSubscription#timeouts}
    */
    readonly timeouts?: CloudSupportSupportEventSubscriptionTimeouts;
}
export interface CloudSupportSupportEventSubscriptionTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_support_support_event_subscription#create CloudSupportSupportEventSubscription#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_support_support_event_subscription#delete CloudSupportSupportEventSubscription#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_support_support_event_subscription#update CloudSupportSupportEventSubscription#update}
    */
    readonly update?: string;
}
export declare function cloudSupportSupportEventSubscriptionTimeoutsToTerraform(struct?: CloudSupportSupportEventSubscriptionTimeouts | cdktn.IResolvable): any;
export declare function cloudSupportSupportEventSubscriptionTimeoutsToHclTerraform(struct?: CloudSupportSupportEventSubscriptionTimeouts | cdktn.IResolvable): any;
export declare class CloudSupportSupportEventSubscriptionTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudSupportSupportEventSubscriptionTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CloudSupportSupportEventSubscriptionTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_support_support_event_subscription google_cloud_support_support_event_subscription}
*/
export declare class CloudSupportSupportEventSubscription extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_cloud_support_support_event_subscription";
    /**
    * Generates CDKTN code for importing a CloudSupportSupportEventSubscription resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudSupportSupportEventSubscription to import
    * @param importFromId The id of the existing CloudSupportSupportEventSubscription that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_support_support_event_subscription#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudSupportSupportEventSubscription to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_support_support_event_subscription google_cloud_support_support_event_subscription} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudSupportSupportEventSubscriptionConfig
    */
    constructor(scope: Construct, id: string, config: CloudSupportSupportEventSubscriptionConfig);
    get createTime(): string;
    get deleteTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    get failureReason(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _pubSubTopic?;
    get pubSubTopic(): string;
    set pubSubTopic(value: string);
    get pubSubTopicInput(): string | undefined;
    get purgeTime(): string;
    get state(): string;
    get updateTime(): string;
    private _timeouts;
    get timeouts(): CloudSupportSupportEventSubscriptionTimeoutsOutputReference;
    putTimeouts(value: CloudSupportSupportEventSubscriptionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CloudSupportSupportEventSubscriptionTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
