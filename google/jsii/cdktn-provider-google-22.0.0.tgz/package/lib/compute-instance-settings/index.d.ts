/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeInstanceSettingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_settings#deletion_policy ComputeInstanceSettings#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_settings#id ComputeInstanceSettings#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_settings#project ComputeInstanceSettings#project}
    */
    readonly project?: string;
    /**
    * A reference to the zone where the machine resides.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_settings#zone ComputeInstanceSettings#zone}
    */
    readonly zone: string;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_settings#metadata ComputeInstanceSettings#metadata}
    */
    readonly metadata?: ComputeInstanceSettingsMetadata;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_settings#timeouts ComputeInstanceSettings#timeouts}
    */
    readonly timeouts?: ComputeInstanceSettingsTimeouts;
}
export interface ComputeInstanceSettingsMetadata {
    /**
    * A metadata key/value items map. The total size of all keys and values must be less than 512KB
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_settings#items ComputeInstanceSettings#items}
    */
    readonly items?: {
        [key: string]: string;
    };
}
export declare function computeInstanceSettingsMetadataToTerraform(struct?: ComputeInstanceSettingsMetadataOutputReference | ComputeInstanceSettingsMetadata): any;
export declare function computeInstanceSettingsMetadataToHclTerraform(struct?: ComputeInstanceSettingsMetadataOutputReference | ComputeInstanceSettingsMetadata): any;
export declare class ComputeInstanceSettingsMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceSettingsMetadata | undefined;
    set internalValue(value: ComputeInstanceSettingsMetadata | undefined);
    private _items?;
    get items(): {
        [key: string]: string;
    };
    set items(value: {
        [key: string]: string;
    });
    resetItems(): void;
    get itemsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ComputeInstanceSettingsTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_settings#create ComputeInstanceSettings#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_settings#delete ComputeInstanceSettings#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_settings#update ComputeInstanceSettings#update}
    */
    readonly update?: string;
}
export declare function computeInstanceSettingsTimeoutsToTerraform(struct?: ComputeInstanceSettingsTimeouts | cdktn.IResolvable): any;
export declare function computeInstanceSettingsTimeoutsToHclTerraform(struct?: ComputeInstanceSettingsTimeouts | cdktn.IResolvable): any;
export declare class ComputeInstanceSettingsTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceSettingsTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInstanceSettingsTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_settings google_compute_instance_settings}
*/
export declare class ComputeInstanceSettings extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_instance_settings";
    /**
    * Generates CDKTN code for importing a ComputeInstanceSettings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeInstanceSettings to import
    * @param importFromId The id of the existing ComputeInstanceSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeInstanceSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_settings google_compute_instance_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeInstanceSettingsConfig
    */
    constructor(scope: Construct, id: string, config: ComputeInstanceSettingsConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    get fingerprint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    get zoneInput(): string | undefined;
    private _metadata;
    get metadata(): ComputeInstanceSettingsMetadataOutputReference;
    putMetadata(value: ComputeInstanceSettingsMetadata): void;
    resetMetadata(): void;
    get metadataInput(): ComputeInstanceSettingsMetadata | undefined;
    private _timeouts;
    get timeouts(): ComputeInstanceSettingsTimeoutsOutputReference;
    putTimeouts(value: ComputeInstanceSettingsTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeInstanceSettingsTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
