/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeRouterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#deletion_policy ComputeRouter#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#description ComputeRouter#description}
    */
    readonly description?: string;
    /**
    * Indicates if a router is dedicated for use with encrypted VLAN
    * attachments (interconnectAttachments).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#encrypted_interconnect_router ComputeRouter#encrypted_interconnect_router}
    */
    readonly encryptedInterconnectRouter?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#id ComputeRouter#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the resource. The name must be 1-63 characters long, and
    * comply with RFC1035. Specifically, the name must be 1-63 characters
    * long and match the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?'
    * which means the first character must be a lowercase letter, and all
    * following characters must be a dash, lowercase letter, or digit,
    * except the last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#name ComputeRouter#name}
    */
    readonly name: string;
    /**
    * A URI of an NCC Gateway spoke
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#ncc_gateway ComputeRouter#ncc_gateway}
    */
    readonly nccGateway?: string;
    /**
    * A reference to the network to which this router belongs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#network ComputeRouter#network}
    */
    readonly network?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#project ComputeRouter#project}
    */
    readonly project?: string;
    /**
    * Region where the router resides.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#region ComputeRouter#region}
    */
    readonly region?: string;
    /**
    * bgp block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#bgp ComputeRouter#bgp}
    */
    readonly bgp?: ComputeRouterBgp;
    /**
    * md5_authentication_keys block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#md5_authentication_keys ComputeRouter#md5_authentication_keys}
    */
    readonly md5AuthenticationKeys?: ComputeRouterMd5AuthenticationKeys;
    /**
    * params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#params ComputeRouter#params}
    */
    readonly params?: ComputeRouterParams;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#timeouts ComputeRouter#timeouts}
    */
    readonly timeouts?: ComputeRouterTimeouts;
}
export interface ComputeRouterBgpAdvertisedIpRanges {
    /**
    * User-specified description for the IP range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#description ComputeRouter#description}
    */
    readonly description?: string;
    /**
    * The IP range to advertise. The value must be a
    * CIDR-formatted string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#range ComputeRouter#range}
    */
    readonly range: string;
}
export declare function computeRouterBgpAdvertisedIpRangesToTerraform(struct?: ComputeRouterBgpAdvertisedIpRanges | cdktn.IResolvable): any;
export declare function computeRouterBgpAdvertisedIpRangesToHclTerraform(struct?: ComputeRouterBgpAdvertisedIpRanges | cdktn.IResolvable): any;
export declare class ComputeRouterBgpAdvertisedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRouterBgpAdvertisedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRouterBgpAdvertisedIpRanges | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _range?;
    get range(): string;
    set range(value: string);
    get rangeInput(): string | undefined;
}
export declare class ComputeRouterBgpAdvertisedIpRangesList extends cdktn.ComplexList {
    internalValue?: ComputeRouterBgpAdvertisedIpRanges[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRouterBgpAdvertisedIpRangesOutputReference;
}
export interface ComputeRouterBgp {
    /**
    * User-specified flag to indicate which mode to use for advertisement. Default value: "DEFAULT" Possible values: ["DEFAULT", "CUSTOM"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#advertise_mode ComputeRouter#advertise_mode}
    */
    readonly advertiseMode?: string;
    /**
    * User-specified list of prefix groups to advertise in custom mode.
    * This field can only be populated if advertiseMode is CUSTOM and
    * is advertised to all peers of the router. These groups will be
    * advertised in addition to any specified prefixes. Leave this field
    * blank to advertise no custom groups.
    *
    * This enum field has the one valid value: ALL_SUBNETS
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#advertised_groups ComputeRouter#advertised_groups}
    */
    readonly advertisedGroups?: string[];
    /**
    * Local BGP Autonomous System Number (ASN). Must be an RFC6996
    * private ASN, either 16-bit or 32-bit. The value will be fixed for
    * this router resource. All VPN tunnels that link to this router
    * will have the same local ASN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#asn ComputeRouter#asn}
    */
    readonly asn: number;
    /**
    * Explicitly specifies a range of valid BGP Identifiers for this Router.
    * It is provided as a link-local IPv4 range (from 169.254.0.0/16), of
    * size at least /30, even if the BGP sessions are over IPv6. It must
    * not overlap with any IPv4 BGP session ranges. Other vendors commonly
    * call this router ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#identifier_range ComputeRouter#identifier_range}
    */
    readonly identifierRange?: string;
    /**
    * The interval in seconds between BGP keepalive messages that are sent
    * to the peer. Hold time is three times the interval at which keepalive
    * messages are sent, and the hold time is the maximum number of seconds
    * allowed to elapse between successive keepalive messages that BGP
    * receives from a peer.
    *
    * BGP will use the smaller of either the local hold time value or the
    * peer's hold time value as the hold time for the BGP connection
    * between the two peers. If set, this value must be between 20 and 60.
    * The default is 20.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#keepalive_interval ComputeRouter#keepalive_interval}
    */
    readonly keepaliveInterval?: number;
    /**
    * advertised_ip_ranges block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#advertised_ip_ranges ComputeRouter#advertised_ip_ranges}
    */
    readonly advertisedIpRanges?: ComputeRouterBgpAdvertisedIpRanges[] | cdktn.IResolvable;
}
export declare function computeRouterBgpToTerraform(struct?: ComputeRouterBgpOutputReference | ComputeRouterBgp): any;
export declare function computeRouterBgpToHclTerraform(struct?: ComputeRouterBgpOutputReference | ComputeRouterBgp): any;
export declare class ComputeRouterBgpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRouterBgp | undefined;
    set internalValue(value: ComputeRouterBgp | undefined);
    private _advertiseMode?;
    get advertiseMode(): string;
    set advertiseMode(value: string);
    resetAdvertiseMode(): void;
    get advertiseModeInput(): string | undefined;
    private _advertisedGroups?;
    get advertisedGroups(): string[];
    set advertisedGroups(value: string[]);
    resetAdvertisedGroups(): void;
    get advertisedGroupsInput(): string[] | undefined;
    private _asn?;
    get asn(): number;
    set asn(value: number);
    get asnInput(): number | undefined;
    private _identifierRange?;
    get identifierRange(): string;
    set identifierRange(value: string);
    resetIdentifierRange(): void;
    get identifierRangeInput(): string | undefined;
    private _keepaliveInterval?;
    get keepaliveInterval(): number;
    set keepaliveInterval(value: number);
    resetKeepaliveInterval(): void;
    get keepaliveIntervalInput(): number | undefined;
    private _advertisedIpRanges;
    get advertisedIpRanges(): ComputeRouterBgpAdvertisedIpRangesList;
    putAdvertisedIpRanges(value: ComputeRouterBgpAdvertisedIpRanges[] | cdktn.IResolvable): void;
    resetAdvertisedIpRanges(): void;
    get advertisedIpRangesInput(): cdktn.IResolvable | ComputeRouterBgpAdvertisedIpRanges[] | undefined;
}
export interface ComputeRouterMd5AuthenticationKeys {
    /**
    * Value of the key used for MD5 authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#key ComputeRouter#key}
    */
    readonly key: string;
    /**
    * Name used to identify the key. Must be unique within a router.
    * Must be referenced by exactly one bgpPeer. Must comply with RFC1035.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#name ComputeRouter#name}
    */
    readonly name: string;
}
export declare function computeRouterMd5AuthenticationKeysToTerraform(struct?: ComputeRouterMd5AuthenticationKeysOutputReference | ComputeRouterMd5AuthenticationKeys): any;
export declare function computeRouterMd5AuthenticationKeysToHclTerraform(struct?: ComputeRouterMd5AuthenticationKeysOutputReference | ComputeRouterMd5AuthenticationKeys): any;
export declare class ComputeRouterMd5AuthenticationKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRouterMd5AuthenticationKeys | undefined;
    set internalValue(value: ComputeRouterMd5AuthenticationKeys | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface ComputeRouterParams {
    /**
    * Resource manager tags to be bound to the router. Tag keys and values have the
    * same definition as resource manager tags. Keys must be in the format tagKeys/{tag_key_id},
    * and values are in the format tagValues/456.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#resource_manager_tags ComputeRouter#resource_manager_tags}
    */
    readonly resourceManagerTags?: {
        [key: string]: string;
    };
}
export declare function computeRouterParamsToTerraform(struct?: ComputeRouterParamsOutputReference | ComputeRouterParams): any;
export declare function computeRouterParamsToHclTerraform(struct?: ComputeRouterParamsOutputReference | ComputeRouterParams): any;
export declare class ComputeRouterParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRouterParams | undefined;
    set internalValue(value: ComputeRouterParams | undefined);
    private _resourceManagerTags?;
    get resourceManagerTags(): {
        [key: string]: string;
    };
    set resourceManagerTags(value: {
        [key: string]: string;
    });
    resetResourceManagerTags(): void;
    get resourceManagerTagsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ComputeRouterTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#create ComputeRouter#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#delete ComputeRouter#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#update ComputeRouter#update}
    */
    readonly update?: string;
}
export declare function computeRouterTimeoutsToTerraform(struct?: ComputeRouterTimeouts | cdktn.IResolvable): any;
export declare function computeRouterTimeoutsToHclTerraform(struct?: ComputeRouterTimeouts | cdktn.IResolvable): any;
export declare class ComputeRouterTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRouterTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRouterTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router google_compute_router}
*/
export declare class ComputeRouter extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_router";
    /**
    * Generates CDKTN code for importing a ComputeRouter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeRouter to import
    * @param importFromId The id of the existing ComputeRouter that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeRouter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router google_compute_router} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeRouterConfig
    */
    constructor(scope: Construct, id: string, config: ComputeRouterConfig);
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _encryptedInterconnectRouter?;
    get encryptedInterconnectRouter(): boolean | cdktn.IResolvable;
    set encryptedInterconnectRouter(value: boolean | cdktn.IResolvable);
    resetEncryptedInterconnectRouter(): void;
    get encryptedInterconnectRouterInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nccGateway?;
    get nccGateway(): string;
    set nccGateway(value: string);
    resetNccGateway(): void;
    get nccGatewayInput(): string | undefined;
    private _network?;
    get network(): string;
    set network(value: string);
    resetNetwork(): void;
    get networkInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get routerId(): number;
    get selfLink(): string;
    private _bgp;
    get bgp(): ComputeRouterBgpOutputReference;
    putBgp(value: ComputeRouterBgp): void;
    resetBgp(): void;
    get bgpInput(): ComputeRouterBgp | undefined;
    private _md5AuthenticationKeys;
    get md5AuthenticationKeys(): ComputeRouterMd5AuthenticationKeysOutputReference;
    putMd5AuthenticationKeys(value: ComputeRouterMd5AuthenticationKeys): void;
    resetMd5AuthenticationKeys(): void;
    get md5AuthenticationKeysInput(): ComputeRouterMd5AuthenticationKeys | undefined;
    private _params;
    get params(): ComputeRouterParamsOutputReference;
    putParams(value: ComputeRouterParams): void;
    resetParams(): void;
    get paramsInput(): ComputeRouterParams | undefined;
    private _timeouts;
    get timeouts(): ComputeRouterTimeoutsOutputReference;
    putTimeouts(value: ComputeRouterTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeRouterTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
