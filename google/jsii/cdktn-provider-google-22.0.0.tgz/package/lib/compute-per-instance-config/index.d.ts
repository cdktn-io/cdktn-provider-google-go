/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputePerInstanceConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#deletion_policy ComputePerInstanceConfig#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#id ComputePerInstanceConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The instance group manager this instance config is part of.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#instance_group_manager ComputePerInstanceConfig#instance_group_manager}
    */
    readonly instanceGroupManager: string;
    /**
    * The minimal action to perform on the instance during an update.
    * Default is 'NONE'. Possible values are:
    * * REPLACE
    * * RESTART
    * * REFRESH
    * * NONE
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#minimal_action ComputePerInstanceConfig#minimal_action}
    */
    readonly minimalAction?: string;
    /**
    * The most disruptive action to perform on the instance during an update.
    * Default is 'REPLACE'. Possible values are:
    * * REPLACE
    * * RESTART
    * * REFRESH
    * * NONE
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#most_disruptive_allowed_action ComputePerInstanceConfig#most_disruptive_allowed_action}
    */
    readonly mostDisruptiveAllowedAction?: string;
    /**
    * The name for this per-instance config and its corresponding instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#name ComputePerInstanceConfig#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#project ComputePerInstanceConfig#project}
    */
    readonly project?: string;
    /**
    * When true, deleting this config will immediately remove the underlying instance.
    * When false, deleting this config will use the behavior as determined by remove_instance_on_destroy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#remove_instance_on_destroy ComputePerInstanceConfig#remove_instance_on_destroy}
    */
    readonly removeInstanceOnDestroy?: boolean | cdktn.IResolvable;
    /**
    * When true, deleting this config will immediately remove any specified state from the underlying instance.
    * When false, deleting this config will *not* immediately remove any state from the underlying instance.
    * State will be removed on the next instance recreation or update.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#remove_instance_state_on_destroy ComputePerInstanceConfig#remove_instance_state_on_destroy}
    */
    readonly removeInstanceStateOnDestroy?: boolean | cdktn.IResolvable;
    /**
    * Zone where the containing instance group manager is located
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#zone ComputePerInstanceConfig#zone}
    */
    readonly zone?: string;
    /**
    * preserved_state block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#preserved_state ComputePerInstanceConfig#preserved_state}
    */
    readonly preservedState?: ComputePerInstanceConfigPreservedState;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#timeouts ComputePerInstanceConfig#timeouts}
    */
    readonly timeouts?: ComputePerInstanceConfigTimeouts;
}
export interface ComputePerInstanceConfigPreservedStateDisk {
    /**
    * A value that prescribes what should happen to the stateful disk when the VM instance is deleted.
    * The available options are 'NEVER' and 'ON_PERMANENT_INSTANCE_DELETION'.
    * 'NEVER' - detach the disk when the VM is deleted, but do not delete the disk.
    * 'ON_PERMANENT_INSTANCE_DELETION' will delete the stateful disk when the VM is permanently
    * deleted from the instance group. Default value: "NEVER" Possible values: ["NEVER", "ON_PERMANENT_INSTANCE_DELETION"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#delete_rule ComputePerInstanceConfig#delete_rule}
    */
    readonly deleteRule?: string;
    /**
    * A unique device name that is reflected into the /dev/ tree of a Linux operating system running within the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#device_name ComputePerInstanceConfig#device_name}
    */
    readonly deviceName: string;
    /**
    * The mode of the disk. Default value: "READ_WRITE" Possible values: ["READ_ONLY", "READ_WRITE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#mode ComputePerInstanceConfig#mode}
    */
    readonly mode?: string;
    /**
    * The URI of an existing persistent disk to attach under the specified device-name in the format
    * 'projects/project-id/zones/zone/disks/disk-name'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#source ComputePerInstanceConfig#source}
    */
    readonly source: string;
}
export declare function computePerInstanceConfigPreservedStateDiskToTerraform(struct?: ComputePerInstanceConfigPreservedStateDisk | cdktn.IResolvable): any;
export declare function computePerInstanceConfigPreservedStateDiskToHclTerraform(struct?: ComputePerInstanceConfigPreservedStateDisk | cdktn.IResolvable): any;
export declare class ComputePerInstanceConfigPreservedStateDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputePerInstanceConfigPreservedStateDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ComputePerInstanceConfigPreservedStateDisk | cdktn.IResolvable | undefined);
    private _deleteRule?;
    get deleteRule(): string;
    set deleteRule(value: string);
    resetDeleteRule(): void;
    get deleteRuleInput(): string | undefined;
    private _deviceName?;
    get deviceName(): string;
    set deviceName(value: string);
    get deviceNameInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
}
export declare class ComputePerInstanceConfigPreservedStateDiskList extends cdktn.ComplexList {
    internalValue?: ComputePerInstanceConfigPreservedStateDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputePerInstanceConfigPreservedStateDiskOutputReference;
}
export interface ComputePerInstanceConfigPreservedStateExternalIpIpAddress {
    /**
    * The URL of the reservation for this IP address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#address ComputePerInstanceConfig#address}
    */
    readonly address?: string;
}
export declare function computePerInstanceConfigPreservedStateExternalIpIpAddressToTerraform(struct?: ComputePerInstanceConfigPreservedStateExternalIpIpAddressOutputReference | ComputePerInstanceConfigPreservedStateExternalIpIpAddress): any;
export declare function computePerInstanceConfigPreservedStateExternalIpIpAddressToHclTerraform(struct?: ComputePerInstanceConfigPreservedStateExternalIpIpAddressOutputReference | ComputePerInstanceConfigPreservedStateExternalIpIpAddress): any;
export declare class ComputePerInstanceConfigPreservedStateExternalIpIpAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputePerInstanceConfigPreservedStateExternalIpIpAddress | undefined;
    set internalValue(value: ComputePerInstanceConfigPreservedStateExternalIpIpAddress | undefined);
    private _address?;
    get address(): string;
    set address(value: string);
    resetAddress(): void;
    get addressInput(): string | undefined;
}
export interface ComputePerInstanceConfigPreservedStateExternalIp {
    /**
    * These stateful IPs will never be released during autohealing, update or VM instance recreate operations. This flag is used to configure if the IP reservation should be deleted after it is no longer used by the group, e.g. when the given instance or the whole group is deleted. Default value: "NEVER" Possible values: ["NEVER", "ON_PERMANENT_INSTANCE_DELETION"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#auto_delete ComputePerInstanceConfig#auto_delete}
    */
    readonly autoDelete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#interface_name ComputePerInstanceConfig#interface_name}
    */
    readonly interfaceName: string;
    /**
    * ip_address block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#ip_address ComputePerInstanceConfig#ip_address}
    */
    readonly ipAddress?: ComputePerInstanceConfigPreservedStateExternalIpIpAddress;
}
export declare function computePerInstanceConfigPreservedStateExternalIpToTerraform(struct?: ComputePerInstanceConfigPreservedStateExternalIp | cdktn.IResolvable): any;
export declare function computePerInstanceConfigPreservedStateExternalIpToHclTerraform(struct?: ComputePerInstanceConfigPreservedStateExternalIp | cdktn.IResolvable): any;
export declare class ComputePerInstanceConfigPreservedStateExternalIpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputePerInstanceConfigPreservedStateExternalIp | cdktn.IResolvable | undefined;
    set internalValue(value: ComputePerInstanceConfigPreservedStateExternalIp | cdktn.IResolvable | undefined);
    private _autoDelete?;
    get autoDelete(): string;
    set autoDelete(value: string);
    resetAutoDelete(): void;
    get autoDeleteInput(): string | undefined;
    private _interfaceName?;
    get interfaceName(): string;
    set interfaceName(value: string);
    get interfaceNameInput(): string | undefined;
    private _ipAddress;
    get ipAddress(): ComputePerInstanceConfigPreservedStateExternalIpIpAddressOutputReference;
    putIpAddress(value: ComputePerInstanceConfigPreservedStateExternalIpIpAddress): void;
    resetIpAddress(): void;
    get ipAddressInput(): ComputePerInstanceConfigPreservedStateExternalIpIpAddress | undefined;
}
export declare class ComputePerInstanceConfigPreservedStateExternalIpList extends cdktn.ComplexList {
    internalValue?: ComputePerInstanceConfigPreservedStateExternalIp[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputePerInstanceConfigPreservedStateExternalIpOutputReference;
}
export interface ComputePerInstanceConfigPreservedStateInternalIpIpAddress {
    /**
    * The URL of the reservation for this IP address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#address ComputePerInstanceConfig#address}
    */
    readonly address?: string;
}
export declare function computePerInstanceConfigPreservedStateInternalIpIpAddressToTerraform(struct?: ComputePerInstanceConfigPreservedStateInternalIpIpAddressOutputReference | ComputePerInstanceConfigPreservedStateInternalIpIpAddress): any;
export declare function computePerInstanceConfigPreservedStateInternalIpIpAddressToHclTerraform(struct?: ComputePerInstanceConfigPreservedStateInternalIpIpAddressOutputReference | ComputePerInstanceConfigPreservedStateInternalIpIpAddress): any;
export declare class ComputePerInstanceConfigPreservedStateInternalIpIpAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputePerInstanceConfigPreservedStateInternalIpIpAddress | undefined;
    set internalValue(value: ComputePerInstanceConfigPreservedStateInternalIpIpAddress | undefined);
    private _address?;
    get address(): string;
    set address(value: string);
    resetAddress(): void;
    get addressInput(): string | undefined;
}
export interface ComputePerInstanceConfigPreservedStateInternalIp {
    /**
    * These stateful IPs will never be released during autohealing, update or VM instance recreate operations. This flag is used to configure if the IP reservation should be deleted after it is no longer used by the group, e.g. when the given instance or the whole group is deleted. Default value: "NEVER" Possible values: ["NEVER", "ON_PERMANENT_INSTANCE_DELETION"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#auto_delete ComputePerInstanceConfig#auto_delete}
    */
    readonly autoDelete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#interface_name ComputePerInstanceConfig#interface_name}
    */
    readonly interfaceName: string;
    /**
    * ip_address block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#ip_address ComputePerInstanceConfig#ip_address}
    */
    readonly ipAddress?: ComputePerInstanceConfigPreservedStateInternalIpIpAddress;
}
export declare function computePerInstanceConfigPreservedStateInternalIpToTerraform(struct?: ComputePerInstanceConfigPreservedStateInternalIp | cdktn.IResolvable): any;
export declare function computePerInstanceConfigPreservedStateInternalIpToHclTerraform(struct?: ComputePerInstanceConfigPreservedStateInternalIp | cdktn.IResolvable): any;
export declare class ComputePerInstanceConfigPreservedStateInternalIpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputePerInstanceConfigPreservedStateInternalIp | cdktn.IResolvable | undefined;
    set internalValue(value: ComputePerInstanceConfigPreservedStateInternalIp | cdktn.IResolvable | undefined);
    private _autoDelete?;
    get autoDelete(): string;
    set autoDelete(value: string);
    resetAutoDelete(): void;
    get autoDeleteInput(): string | undefined;
    private _interfaceName?;
    get interfaceName(): string;
    set interfaceName(value: string);
    get interfaceNameInput(): string | undefined;
    private _ipAddress;
    get ipAddress(): ComputePerInstanceConfigPreservedStateInternalIpIpAddressOutputReference;
    putIpAddress(value: ComputePerInstanceConfigPreservedStateInternalIpIpAddress): void;
    resetIpAddress(): void;
    get ipAddressInput(): ComputePerInstanceConfigPreservedStateInternalIpIpAddress | undefined;
}
export declare class ComputePerInstanceConfigPreservedStateInternalIpList extends cdktn.ComplexList {
    internalValue?: ComputePerInstanceConfigPreservedStateInternalIp[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputePerInstanceConfigPreservedStateInternalIpOutputReference;
}
export interface ComputePerInstanceConfigPreservedState {
    /**
    * Preserved metadata defined for this instance. This is a list of key->value pairs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#metadata ComputePerInstanceConfig#metadata}
    */
    readonly metadata?: {
        [key: string]: string;
    };
    /**
    * disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#disk ComputePerInstanceConfig#disk}
    */
    readonly disk?: ComputePerInstanceConfigPreservedStateDisk[] | cdktn.IResolvable;
    /**
    * external_ip block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#external_ip ComputePerInstanceConfig#external_ip}
    */
    readonly externalIp?: ComputePerInstanceConfigPreservedStateExternalIp[] | cdktn.IResolvable;
    /**
    * internal_ip block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#internal_ip ComputePerInstanceConfig#internal_ip}
    */
    readonly internalIp?: ComputePerInstanceConfigPreservedStateInternalIp[] | cdktn.IResolvable;
}
export declare function computePerInstanceConfigPreservedStateToTerraform(struct?: ComputePerInstanceConfigPreservedStateOutputReference | ComputePerInstanceConfigPreservedState): any;
export declare function computePerInstanceConfigPreservedStateToHclTerraform(struct?: ComputePerInstanceConfigPreservedStateOutputReference | ComputePerInstanceConfigPreservedState): any;
export declare class ComputePerInstanceConfigPreservedStateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputePerInstanceConfigPreservedState | undefined;
    set internalValue(value: ComputePerInstanceConfigPreservedState | undefined);
    private _metadata?;
    get metadata(): {
        [key: string]: string;
    };
    set metadata(value: {
        [key: string]: string;
    });
    resetMetadata(): void;
    get metadataInput(): {
        [key: string]: string;
    } | undefined;
    private _disk;
    get disk(): ComputePerInstanceConfigPreservedStateDiskList;
    putDisk(value: ComputePerInstanceConfigPreservedStateDisk[] | cdktn.IResolvable): void;
    resetDisk(): void;
    get diskInput(): cdktn.IResolvable | ComputePerInstanceConfigPreservedStateDisk[] | undefined;
    private _externalIp;
    get externalIp(): ComputePerInstanceConfigPreservedStateExternalIpList;
    putExternalIp(value: ComputePerInstanceConfigPreservedStateExternalIp[] | cdktn.IResolvable): void;
    resetExternalIp(): void;
    get externalIpInput(): cdktn.IResolvable | ComputePerInstanceConfigPreservedStateExternalIp[] | undefined;
    private _internalIp;
    get internalIp(): ComputePerInstanceConfigPreservedStateInternalIpList;
    putInternalIp(value: ComputePerInstanceConfigPreservedStateInternalIp[] | cdktn.IResolvable): void;
    resetInternalIp(): void;
    get internalIpInput(): cdktn.IResolvable | ComputePerInstanceConfigPreservedStateInternalIp[] | undefined;
}
export interface ComputePerInstanceConfigTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#create ComputePerInstanceConfig#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#delete ComputePerInstanceConfig#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#update ComputePerInstanceConfig#update}
    */
    readonly update?: string;
}
export declare function computePerInstanceConfigTimeoutsToTerraform(struct?: ComputePerInstanceConfigTimeouts | cdktn.IResolvable): any;
export declare function computePerInstanceConfigTimeoutsToHclTerraform(struct?: ComputePerInstanceConfigTimeouts | cdktn.IResolvable): any;
export declare class ComputePerInstanceConfigTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputePerInstanceConfigTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputePerInstanceConfigTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config google_compute_per_instance_config}
*/
export declare class ComputePerInstanceConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_per_instance_config";
    /**
    * Generates CDKTN code for importing a ComputePerInstanceConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputePerInstanceConfig to import
    * @param importFromId The id of the existing ComputePerInstanceConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputePerInstanceConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_per_instance_config google_compute_per_instance_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputePerInstanceConfigConfig
    */
    constructor(scope: Construct, id: string, config: ComputePerInstanceConfigConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceGroupManager?;
    get instanceGroupManager(): string;
    set instanceGroupManager(value: string);
    get instanceGroupManagerInput(): string | undefined;
    private _minimalAction?;
    get minimalAction(): string;
    set minimalAction(value: string);
    resetMinimalAction(): void;
    get minimalActionInput(): string | undefined;
    private _mostDisruptiveAllowedAction?;
    get mostDisruptiveAllowedAction(): string;
    set mostDisruptiveAllowedAction(value: string);
    resetMostDisruptiveAllowedAction(): void;
    get mostDisruptiveAllowedActionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _removeInstanceOnDestroy?;
    get removeInstanceOnDestroy(): boolean | cdktn.IResolvable;
    set removeInstanceOnDestroy(value: boolean | cdktn.IResolvable);
    resetRemoveInstanceOnDestroy(): void;
    get removeInstanceOnDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _removeInstanceStateOnDestroy?;
    get removeInstanceStateOnDestroy(): boolean | cdktn.IResolvable;
    set removeInstanceStateOnDestroy(value: boolean | cdktn.IResolvable);
    resetRemoveInstanceStateOnDestroy(): void;
    get removeInstanceStateOnDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    resetZone(): void;
    get zoneInput(): string | undefined;
    private _preservedState;
    get preservedState(): ComputePerInstanceConfigPreservedStateOutputReference;
    putPreservedState(value: ComputePerInstanceConfigPreservedState): void;
    resetPreservedState(): void;
    get preservedStateInput(): ComputePerInstanceConfigPreservedState | undefined;
    private _timeouts;
    get timeouts(): ComputePerInstanceConfigTimeoutsOutputReference;
    putTimeouts(value: ComputePerInstanceConfigTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputePerInstanceConfigTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
