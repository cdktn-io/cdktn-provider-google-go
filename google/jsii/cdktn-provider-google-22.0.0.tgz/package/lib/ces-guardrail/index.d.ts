/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CesGuardrailConfig extends cdktn.TerraformMetaArguments {
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#app CesGuardrail#app}
    */
    readonly app: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#deletion_policy CesGuardrail#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Description of the guardrail.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#description CesGuardrail#description}
    */
    readonly description?: string;
    /**
    * Display name of the guardrail.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#display_name CesGuardrail#display_name}
    */
    readonly displayName: string;
    /**
    * Whether the guardrail is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#enabled CesGuardrail#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The ID to use for the guardrail, which will become the final component of
    * the guardrail's resource name. If not provided, a unique ID will be
    * automatically assigned for the guardrail.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#guardrail_id CesGuardrail#guardrail_id}
    */
    readonly guardrailId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#id CesGuardrail#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#location CesGuardrail#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#project CesGuardrail#project}
    */
    readonly project?: string;
    /**
    * action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#action CesGuardrail#action}
    */
    readonly action?: CesGuardrailAction;
    /**
    * code_callback block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#code_callback CesGuardrail#code_callback}
    */
    readonly codeCallback?: CesGuardrailCodeCallback;
    /**
    * content_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#content_filter CesGuardrail#content_filter}
    */
    readonly contentFilter?: CesGuardrailContentFilter;
    /**
    * llm_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#llm_policy CesGuardrail#llm_policy}
    */
    readonly llmPolicy?: CesGuardrailLlmPolicy;
    /**
    * llm_prompt_security block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#llm_prompt_security CesGuardrail#llm_prompt_security}
    */
    readonly llmPromptSecurity?: CesGuardrailLlmPromptSecurity;
    /**
    * model_safety block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#model_safety CesGuardrail#model_safety}
    */
    readonly modelSafety?: CesGuardrailModelSafety;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#timeouts CesGuardrail#timeouts}
    */
    readonly timeouts?: CesGuardrailTimeouts;
}
export interface CesGuardrailActionGenerativeAnswer {
    /**
    * The prompt to use for the generative answer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#prompt CesGuardrail#prompt}
    */
    readonly prompt: string;
}
export declare function cesGuardrailActionGenerativeAnswerToTerraform(struct?: CesGuardrailActionGenerativeAnswerOutputReference | CesGuardrailActionGenerativeAnswer): any;
export declare function cesGuardrailActionGenerativeAnswerToHclTerraform(struct?: CesGuardrailActionGenerativeAnswerOutputReference | CesGuardrailActionGenerativeAnswer): any;
export declare class CesGuardrailActionGenerativeAnswerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesGuardrailActionGenerativeAnswer | undefined;
    set internalValue(value: CesGuardrailActionGenerativeAnswer | undefined);
    private _prompt?;
    get prompt(): string;
    set prompt(value: string);
    get promptInput(): string | undefined;
}
export interface CesGuardrailActionRespondImmediatelyResponses {
    /**
    * Whether the response is disabled. Disabled responses are not used by the
    * agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#disabled CesGuardrail#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Text for the agent to respond with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#text CesGuardrail#text}
    */
    readonly text: string;
}
export declare function cesGuardrailActionRespondImmediatelyResponsesToTerraform(struct?: CesGuardrailActionRespondImmediatelyResponses | cdktn.IResolvable): any;
export declare function cesGuardrailActionRespondImmediatelyResponsesToHclTerraform(struct?: CesGuardrailActionRespondImmediatelyResponses | cdktn.IResolvable): any;
export declare class CesGuardrailActionRespondImmediatelyResponsesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesGuardrailActionRespondImmediatelyResponses | cdktn.IResolvable | undefined;
    set internalValue(value: CesGuardrailActionRespondImmediatelyResponses | cdktn.IResolvable | undefined);
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _text?;
    get text(): string;
    set text(value: string);
    get textInput(): string | undefined;
}
export declare class CesGuardrailActionRespondImmediatelyResponsesList extends cdktn.ComplexList {
    internalValue?: CesGuardrailActionRespondImmediatelyResponses[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesGuardrailActionRespondImmediatelyResponsesOutputReference;
}
export interface CesGuardrailActionRespondImmediately {
    /**
    * responses block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#responses CesGuardrail#responses}
    */
    readonly responses: CesGuardrailActionRespondImmediatelyResponses[] | cdktn.IResolvable;
}
export declare function cesGuardrailActionRespondImmediatelyToTerraform(struct?: CesGuardrailActionRespondImmediatelyOutputReference | CesGuardrailActionRespondImmediately): any;
export declare function cesGuardrailActionRespondImmediatelyToHclTerraform(struct?: CesGuardrailActionRespondImmediatelyOutputReference | CesGuardrailActionRespondImmediately): any;
export declare class CesGuardrailActionRespondImmediatelyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesGuardrailActionRespondImmediately | undefined;
    set internalValue(value: CesGuardrailActionRespondImmediately | undefined);
    private _responses;
    get responses(): CesGuardrailActionRespondImmediatelyResponsesList;
    putResponses(value: CesGuardrailActionRespondImmediatelyResponses[] | cdktn.IResolvable): void;
    get responsesInput(): cdktn.IResolvable | CesGuardrailActionRespondImmediatelyResponses[] | undefined;
}
export interface CesGuardrailActionTransferAgent {
    /**
    * The name of the agent to transfer the conversation to. The agent must be
    * in the same app as the current agent.
    * Format:
    * 'projects/{project}/locations/{location}/apps/{app}/agents/{agent}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#agent CesGuardrail#agent}
    */
    readonly agent: string;
}
export declare function cesGuardrailActionTransferAgentToTerraform(struct?: CesGuardrailActionTransferAgentOutputReference | CesGuardrailActionTransferAgent): any;
export declare function cesGuardrailActionTransferAgentToHclTerraform(struct?: CesGuardrailActionTransferAgentOutputReference | CesGuardrailActionTransferAgent): any;
export declare class CesGuardrailActionTransferAgentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesGuardrailActionTransferAgent | undefined;
    set internalValue(value: CesGuardrailActionTransferAgent | undefined);
    private _agent?;
    get agent(): string;
    set agent(value: string);
    get agentInput(): string | undefined;
}
export interface CesGuardrailAction {
    /**
    * generative_answer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#generative_answer CesGuardrail#generative_answer}
    */
    readonly generativeAnswer?: CesGuardrailActionGenerativeAnswer;
    /**
    * respond_immediately block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#respond_immediately CesGuardrail#respond_immediately}
    */
    readonly respondImmediately?: CesGuardrailActionRespondImmediately;
    /**
    * transfer_agent block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#transfer_agent CesGuardrail#transfer_agent}
    */
    readonly transferAgent?: CesGuardrailActionTransferAgent;
}
export declare function cesGuardrailActionToTerraform(struct?: CesGuardrailActionOutputReference | CesGuardrailAction): any;
export declare function cesGuardrailActionToHclTerraform(struct?: CesGuardrailActionOutputReference | CesGuardrailAction): any;
export declare class CesGuardrailActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesGuardrailAction | undefined;
    set internalValue(value: CesGuardrailAction | undefined);
    private _generativeAnswer;
    get generativeAnswer(): CesGuardrailActionGenerativeAnswerOutputReference;
    putGenerativeAnswer(value: CesGuardrailActionGenerativeAnswer): void;
    resetGenerativeAnswer(): void;
    get generativeAnswerInput(): CesGuardrailActionGenerativeAnswer | undefined;
    private _respondImmediately;
    get respondImmediately(): CesGuardrailActionRespondImmediatelyOutputReference;
    putRespondImmediately(value: CesGuardrailActionRespondImmediately): void;
    resetRespondImmediately(): void;
    get respondImmediatelyInput(): CesGuardrailActionRespondImmediately | undefined;
    private _transferAgent;
    get transferAgent(): CesGuardrailActionTransferAgentOutputReference;
    putTransferAgent(value: CesGuardrailActionTransferAgent): void;
    resetTransferAgent(): void;
    get transferAgentInput(): CesGuardrailActionTransferAgent | undefined;
}
export interface CesGuardrailCodeCallbackAfterAgentCallback {
    /**
    * Human-readable description of the callback.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#description CesGuardrail#description}
    */
    readonly description?: string;
    /**
    * Whether the callback is disabled. Disabled callbacks are ignored by the
    * agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#disabled CesGuardrail#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * If enabled, the callback will also be executed on intermediate model
    * outputs. This setting only affects after model callback.
    * **ENABLE WITH CAUTION**. Typically after model callback only needs to be
    * executed after receiving all model responses. Enabling proactive execution
    * may have negative implication on the execution cost and latency, and
    * should only be enabled in rare situations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#proactive_execution_enabled CesGuardrail#proactive_execution_enabled}
    */
    readonly proactiveExecutionEnabled?: boolean | cdktn.IResolvable;
    /**
    * The python code to execute for the callback.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#python_code CesGuardrail#python_code}
    */
    readonly pythonCode: string;
}
export declare function cesGuardrailCodeCallbackAfterAgentCallbackToTerraform(struct?: CesGuardrailCodeCallbackAfterAgentCallbackOutputReference | CesGuardrailCodeCallbackAfterAgentCallback): any;
export declare function cesGuardrailCodeCallbackAfterAgentCallbackToHclTerraform(struct?: CesGuardrailCodeCallbackAfterAgentCallbackOutputReference | CesGuardrailCodeCallbackAfterAgentCallback): any;
export declare class CesGuardrailCodeCallbackAfterAgentCallbackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesGuardrailCodeCallbackAfterAgentCallback | undefined;
    set internalValue(value: CesGuardrailCodeCallbackAfterAgentCallback | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _proactiveExecutionEnabled?;
    get proactiveExecutionEnabled(): boolean | cdktn.IResolvable;
    set proactiveExecutionEnabled(value: boolean | cdktn.IResolvable);
    resetProactiveExecutionEnabled(): void;
    get proactiveExecutionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _pythonCode?;
    get pythonCode(): string;
    set pythonCode(value: string);
    get pythonCodeInput(): string | undefined;
}
export interface CesGuardrailCodeCallbackAfterModelCallback {
    /**
    * Human-readable description of the callback.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#description CesGuardrail#description}
    */
    readonly description?: string;
    /**
    * Whether the callback is disabled. Disabled callbacks are ignored by the
    * agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#disabled CesGuardrail#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * If enabled, the callback will also be executed on intermediate model
    * outputs. This setting only affects after model callback.
    * **ENABLE WITH CAUTION**. Typically after model callback only needs to be
    * executed after receiving all model responses. Enabling proactive execution
    * may have negative implication on the execution cost and latency, and
    * should only be enabled in rare situations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#proactive_execution_enabled CesGuardrail#proactive_execution_enabled}
    */
    readonly proactiveExecutionEnabled?: boolean | cdktn.IResolvable;
    /**
    * The python code to execute for the callback.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#python_code CesGuardrail#python_code}
    */
    readonly pythonCode: string;
}
export declare function cesGuardrailCodeCallbackAfterModelCallbackToTerraform(struct?: CesGuardrailCodeCallbackAfterModelCallbackOutputReference | CesGuardrailCodeCallbackAfterModelCallback): any;
export declare function cesGuardrailCodeCallbackAfterModelCallbackToHclTerraform(struct?: CesGuardrailCodeCallbackAfterModelCallbackOutputReference | CesGuardrailCodeCallbackAfterModelCallback): any;
export declare class CesGuardrailCodeCallbackAfterModelCallbackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesGuardrailCodeCallbackAfterModelCallback | undefined;
    set internalValue(value: CesGuardrailCodeCallbackAfterModelCallback | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _proactiveExecutionEnabled?;
    get proactiveExecutionEnabled(): boolean | cdktn.IResolvable;
    set proactiveExecutionEnabled(value: boolean | cdktn.IResolvable);
    resetProactiveExecutionEnabled(): void;
    get proactiveExecutionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _pythonCode?;
    get pythonCode(): string;
    set pythonCode(value: string);
    get pythonCodeInput(): string | undefined;
}
export interface CesGuardrailCodeCallbackBeforeAgentCallback {
    /**
    * Human-readable description of the callback.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#description CesGuardrail#description}
    */
    readonly description?: string;
    /**
    * Whether the callback is disabled. Disabled callbacks are ignored by the
    * agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#disabled CesGuardrail#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * If enabled, the callback will also be executed on intermediate model
    * outputs. This setting only affects after model callback.
    * **ENABLE WITH CAUTION**. Typically after model callback only needs to be
    * executed after receiving all model responses. Enabling proactive execution
    * may have negative implication on the execution cost and latency, and
    * should only be enabled in rare situations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#proactive_execution_enabled CesGuardrail#proactive_execution_enabled}
    */
    readonly proactiveExecutionEnabled?: boolean | cdktn.IResolvable;
    /**
    * The python code to execute for the callback.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#python_code CesGuardrail#python_code}
    */
    readonly pythonCode: string;
}
export declare function cesGuardrailCodeCallbackBeforeAgentCallbackToTerraform(struct?: CesGuardrailCodeCallbackBeforeAgentCallbackOutputReference | CesGuardrailCodeCallbackBeforeAgentCallback): any;
export declare function cesGuardrailCodeCallbackBeforeAgentCallbackToHclTerraform(struct?: CesGuardrailCodeCallbackBeforeAgentCallbackOutputReference | CesGuardrailCodeCallbackBeforeAgentCallback): any;
export declare class CesGuardrailCodeCallbackBeforeAgentCallbackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesGuardrailCodeCallbackBeforeAgentCallback | undefined;
    set internalValue(value: CesGuardrailCodeCallbackBeforeAgentCallback | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _proactiveExecutionEnabled?;
    get proactiveExecutionEnabled(): boolean | cdktn.IResolvable;
    set proactiveExecutionEnabled(value: boolean | cdktn.IResolvable);
    resetProactiveExecutionEnabled(): void;
    get proactiveExecutionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _pythonCode?;
    get pythonCode(): string;
    set pythonCode(value: string);
    get pythonCodeInput(): string | undefined;
}
export interface CesGuardrailCodeCallbackBeforeModelCallback {
    /**
    * Human-readable description of the callback.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#description CesGuardrail#description}
    */
    readonly description?: string;
    /**
    * Whether the callback is disabled. Disabled callbacks are ignored by the
    * agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#disabled CesGuardrail#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * If enabled, the callback will also be executed on intermediate model
    * outputs. This setting only affects after model callback.
    * **ENABLE WITH CAUTION**. Typically after model callback only needs to be
    * executed after receiving all model responses. Enabling proactive execution
    * may have negative implication on the execution cost and latency, and
    * should only be enabled in rare situations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#proactive_execution_enabled CesGuardrail#proactive_execution_enabled}
    */
    readonly proactiveExecutionEnabled?: boolean | cdktn.IResolvable;
    /**
    * The python code to execute for the callback.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#python_code CesGuardrail#python_code}
    */
    readonly pythonCode: string;
}
export declare function cesGuardrailCodeCallbackBeforeModelCallbackToTerraform(struct?: CesGuardrailCodeCallbackBeforeModelCallbackOutputReference | CesGuardrailCodeCallbackBeforeModelCallback): any;
export declare function cesGuardrailCodeCallbackBeforeModelCallbackToHclTerraform(struct?: CesGuardrailCodeCallbackBeforeModelCallbackOutputReference | CesGuardrailCodeCallbackBeforeModelCallback): any;
export declare class CesGuardrailCodeCallbackBeforeModelCallbackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesGuardrailCodeCallbackBeforeModelCallback | undefined;
    set internalValue(value: CesGuardrailCodeCallbackBeforeModelCallback | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _proactiveExecutionEnabled?;
    get proactiveExecutionEnabled(): boolean | cdktn.IResolvable;
    set proactiveExecutionEnabled(value: boolean | cdktn.IResolvable);
    resetProactiveExecutionEnabled(): void;
    get proactiveExecutionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _pythonCode?;
    get pythonCode(): string;
    set pythonCode(value: string);
    get pythonCodeInput(): string | undefined;
}
export interface CesGuardrailCodeCallback {
    /**
    * after_agent_callback block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#after_agent_callback CesGuardrail#after_agent_callback}
    */
    readonly afterAgentCallback?: CesGuardrailCodeCallbackAfterAgentCallback;
    /**
    * after_model_callback block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#after_model_callback CesGuardrail#after_model_callback}
    */
    readonly afterModelCallback?: CesGuardrailCodeCallbackAfterModelCallback;
    /**
    * before_agent_callback block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#before_agent_callback CesGuardrail#before_agent_callback}
    */
    readonly beforeAgentCallback?: CesGuardrailCodeCallbackBeforeAgentCallback;
    /**
    * before_model_callback block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#before_model_callback CesGuardrail#before_model_callback}
    */
    readonly beforeModelCallback?: CesGuardrailCodeCallbackBeforeModelCallback;
}
export declare function cesGuardrailCodeCallbackToTerraform(struct?: CesGuardrailCodeCallbackOutputReference | CesGuardrailCodeCallback): any;
export declare function cesGuardrailCodeCallbackToHclTerraform(struct?: CesGuardrailCodeCallbackOutputReference | CesGuardrailCodeCallback): any;
export declare class CesGuardrailCodeCallbackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesGuardrailCodeCallback | undefined;
    set internalValue(value: CesGuardrailCodeCallback | undefined);
    private _afterAgentCallback;
    get afterAgentCallback(): CesGuardrailCodeCallbackAfterAgentCallbackOutputReference;
    putAfterAgentCallback(value: CesGuardrailCodeCallbackAfterAgentCallback): void;
    resetAfterAgentCallback(): void;
    get afterAgentCallbackInput(): CesGuardrailCodeCallbackAfterAgentCallback | undefined;
    private _afterModelCallback;
    get afterModelCallback(): CesGuardrailCodeCallbackAfterModelCallbackOutputReference;
    putAfterModelCallback(value: CesGuardrailCodeCallbackAfterModelCallback): void;
    resetAfterModelCallback(): void;
    get afterModelCallbackInput(): CesGuardrailCodeCallbackAfterModelCallback | undefined;
    private _beforeAgentCallback;
    get beforeAgentCallback(): CesGuardrailCodeCallbackBeforeAgentCallbackOutputReference;
    putBeforeAgentCallback(value: CesGuardrailCodeCallbackBeforeAgentCallback): void;
    resetBeforeAgentCallback(): void;
    get beforeAgentCallbackInput(): CesGuardrailCodeCallbackBeforeAgentCallback | undefined;
    private _beforeModelCallback;
    get beforeModelCallback(): CesGuardrailCodeCallbackBeforeModelCallbackOutputReference;
    putBeforeModelCallback(value: CesGuardrailCodeCallbackBeforeModelCallback): void;
    resetBeforeModelCallback(): void;
    get beforeModelCallbackInput(): CesGuardrailCodeCallbackBeforeModelCallback | undefined;
}
export interface CesGuardrailContentFilter {
    /**
    * List of banned phrases. Applies to both user inputs and agent responses.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#banned_contents CesGuardrail#banned_contents}
    */
    readonly bannedContents?: string[];
    /**
    * List of banned phrases. Applies only to agent responses.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#banned_contents_in_agent_response CesGuardrail#banned_contents_in_agent_response}
    */
    readonly bannedContentsInAgentResponse?: string[];
    /**
    * List of banned phrases. Applies only to user inputs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#banned_contents_in_user_input CesGuardrail#banned_contents_in_user_input}
    */
    readonly bannedContentsInUserInput?: string[];
    /**
    * If true, diacritics are ignored during matching.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#disregard_diacritics CesGuardrail#disregard_diacritics}
    */
    readonly disregardDiacritics?: boolean | cdktn.IResolvable;
    /**
    * Match type for the content filter.
    * Possible values:
    * SIMPLE_STRING_MATCH
    * WORD_BOUNDARY_STRING_MATCH
    * REGEXP_MATCH
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#match_type CesGuardrail#match_type}
    */
    readonly matchType: string;
}
export declare function cesGuardrailContentFilterToTerraform(struct?: CesGuardrailContentFilterOutputReference | CesGuardrailContentFilter): any;
export declare function cesGuardrailContentFilterToHclTerraform(struct?: CesGuardrailContentFilterOutputReference | CesGuardrailContentFilter): any;
export declare class CesGuardrailContentFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesGuardrailContentFilter | undefined;
    set internalValue(value: CesGuardrailContentFilter | undefined);
    private _bannedContents?;
    get bannedContents(): string[];
    set bannedContents(value: string[]);
    resetBannedContents(): void;
    get bannedContentsInput(): string[] | undefined;
    private _bannedContentsInAgentResponse?;
    get bannedContentsInAgentResponse(): string[];
    set bannedContentsInAgentResponse(value: string[]);
    resetBannedContentsInAgentResponse(): void;
    get bannedContentsInAgentResponseInput(): string[] | undefined;
    private _bannedContentsInUserInput?;
    get bannedContentsInUserInput(): string[];
    set bannedContentsInUserInput(value: string[]);
    resetBannedContentsInUserInput(): void;
    get bannedContentsInUserInputInput(): string[] | undefined;
    private _disregardDiacritics?;
    get disregardDiacritics(): boolean | cdktn.IResolvable;
    set disregardDiacritics(value: boolean | cdktn.IResolvable);
    resetDisregardDiacritics(): void;
    get disregardDiacriticsInput(): boolean | cdktn.IResolvable | undefined;
    private _matchType?;
    get matchType(): string;
    set matchType(value: string);
    get matchTypeInput(): string | undefined;
}
export interface CesGuardrailLlmPolicyModelSettings {
    /**
    * The LLM model that the agent should use.
    * If not set, the agent will inherit the model from its parent agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#model CesGuardrail#model}
    */
    readonly model?: string;
    /**
    * If set, this temperature will be used for the LLM model. Temperature
    * controls the randomness of the model's responses. Lower temperatures
    * produce responses that are more predictable. Higher temperatures produce
    * responses that are more creative.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#temperature CesGuardrail#temperature}
    */
    readonly temperature?: number;
    /**
    * The thinking level of the model. Possible values: ["DEFAULT", "LOW", "MEDIUM", "HIGH"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#thinking_level CesGuardrail#thinking_level}
    */
    readonly thinkingLevel?: string;
}
export declare function cesGuardrailLlmPolicyModelSettingsToTerraform(struct?: CesGuardrailLlmPolicyModelSettingsOutputReference | CesGuardrailLlmPolicyModelSettings): any;
export declare function cesGuardrailLlmPolicyModelSettingsToHclTerraform(struct?: CesGuardrailLlmPolicyModelSettingsOutputReference | CesGuardrailLlmPolicyModelSettings): any;
export declare class CesGuardrailLlmPolicyModelSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesGuardrailLlmPolicyModelSettings | undefined;
    set internalValue(value: CesGuardrailLlmPolicyModelSettings | undefined);
    private _model?;
    get model(): string;
    set model(value: string);
    resetModel(): void;
    get modelInput(): string | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _thinkingLevel?;
    get thinkingLevel(): string;
    set thinkingLevel(value: string);
    resetThinkingLevel(): void;
    get thinkingLevelInput(): string | undefined;
}
export interface CesGuardrailLlmPolicy {
    /**
    * By default, the LLM policy check is bypassed for short utterances.
    * Enabling this setting applies the policy check to all utterances,
    * including those that would normally be skipped.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#allow_short_utterance CesGuardrail#allow_short_utterance}
    */
    readonly allowShortUtterance?: boolean | cdktn.IResolvable;
    /**
    * If an error occurs during the policy check, fail open and do not trigger
    * the guardrail.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#fail_open CesGuardrail#fail_open}
    */
    readonly failOpen?: boolean | cdktn.IResolvable;
    /**
    * When checking this policy, consider the last 'n' messages in the
    * conversation.
    * When not set a default value of 10 will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#max_conversation_messages CesGuardrail#max_conversation_messages}
    */
    readonly maxConversationMessages?: number;
    /**
    * Defines when to apply the policy check during the conversation. If set to
    * 'POLICY_SCOPE_UNSPECIFIED', the policy will be applied to the user input.
    * When applying the policy to the agent response, additional latency will
    * be introduced before the agent can respond.
    * Possible values:
    * USER_QUERY
    * AGENT_RESPONSE
    * USER_QUERY_AND_AGENT_RESPONSE Possible values: ["USER_QUERY", "AGENT_RESPONSE", "USER_QUERY_AND_AGENT_RESPONSE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#policy_scope CesGuardrail#policy_scope}
    */
    readonly policyScope: string;
    /**
    * Policy prompt.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#prompt CesGuardrail#prompt}
    */
    readonly prompt: string;
    /**
    * model_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#model_settings CesGuardrail#model_settings}
    */
    readonly modelSettings?: CesGuardrailLlmPolicyModelSettings;
}
export declare function cesGuardrailLlmPolicyToTerraform(struct?: CesGuardrailLlmPolicyOutputReference | CesGuardrailLlmPolicy): any;
export declare function cesGuardrailLlmPolicyToHclTerraform(struct?: CesGuardrailLlmPolicyOutputReference | CesGuardrailLlmPolicy): any;
export declare class CesGuardrailLlmPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesGuardrailLlmPolicy | undefined;
    set internalValue(value: CesGuardrailLlmPolicy | undefined);
    private _allowShortUtterance?;
    get allowShortUtterance(): boolean | cdktn.IResolvable;
    set allowShortUtterance(value: boolean | cdktn.IResolvable);
    resetAllowShortUtterance(): void;
    get allowShortUtteranceInput(): boolean | cdktn.IResolvable | undefined;
    private _failOpen?;
    get failOpen(): boolean | cdktn.IResolvable;
    set failOpen(value: boolean | cdktn.IResolvable);
    resetFailOpen(): void;
    get failOpenInput(): boolean | cdktn.IResolvable | undefined;
    private _maxConversationMessages?;
    get maxConversationMessages(): number;
    set maxConversationMessages(value: number);
    resetMaxConversationMessages(): void;
    get maxConversationMessagesInput(): number | undefined;
    private _policyScope?;
    get policyScope(): string;
    set policyScope(value: string);
    get policyScopeInput(): string | undefined;
    private _prompt?;
    get prompt(): string;
    set prompt(value: string);
    get promptInput(): string | undefined;
    private _modelSettings;
    get modelSettings(): CesGuardrailLlmPolicyModelSettingsOutputReference;
    putModelSettings(value: CesGuardrailLlmPolicyModelSettings): void;
    resetModelSettings(): void;
    get modelSettingsInput(): CesGuardrailLlmPolicyModelSettings | undefined;
}
export interface CesGuardrailLlmPromptSecurityCustomPolicyModelSettings {
    /**
    * The LLM model that the agent should use.
    * If not set, the agent will inherit the model from its parent agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#model CesGuardrail#model}
    */
    readonly model?: string;
    /**
    * If set, this temperature will be used for the LLM model. Temperature
    * controls the randomness of the model's responses. Lower temperatures
    * produce responses that are more predictable. Higher temperatures produce
    * responses that are more creative.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#temperature CesGuardrail#temperature}
    */
    readonly temperature?: number;
    /**
    * The thinking level of the model. Possible values: ["DEFAULT", "LOW", "MEDIUM", "HIGH"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#thinking_level CesGuardrail#thinking_level}
    */
    readonly thinkingLevel?: string;
}
export declare function cesGuardrailLlmPromptSecurityCustomPolicyModelSettingsToTerraform(struct?: CesGuardrailLlmPromptSecurityCustomPolicyModelSettingsOutputReference | CesGuardrailLlmPromptSecurityCustomPolicyModelSettings): any;
export declare function cesGuardrailLlmPromptSecurityCustomPolicyModelSettingsToHclTerraform(struct?: CesGuardrailLlmPromptSecurityCustomPolicyModelSettingsOutputReference | CesGuardrailLlmPromptSecurityCustomPolicyModelSettings): any;
export declare class CesGuardrailLlmPromptSecurityCustomPolicyModelSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesGuardrailLlmPromptSecurityCustomPolicyModelSettings | undefined;
    set internalValue(value: CesGuardrailLlmPromptSecurityCustomPolicyModelSettings | undefined);
    private _model?;
    get model(): string;
    set model(value: string);
    resetModel(): void;
    get modelInput(): string | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _thinkingLevel?;
    get thinkingLevel(): string;
    set thinkingLevel(value: string);
    resetThinkingLevel(): void;
    get thinkingLevelInput(): string | undefined;
}
export interface CesGuardrailLlmPromptSecurityCustomPolicy {
    /**
    * By default, the LLM policy check is bypassed for short utterances.
    * Enabling this setting applies the policy check to all utterances,
    * including those that would normally be skipped.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#allow_short_utterance CesGuardrail#allow_short_utterance}
    */
    readonly allowShortUtterance?: boolean | cdktn.IResolvable;
    /**
    * If an error occurs during the policy check, fail open and do not trigger
    * the guardrail.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#fail_open CesGuardrail#fail_open}
    */
    readonly failOpen?: boolean | cdktn.IResolvable;
    /**
    * When checking this policy, consider the last 'n' messages in the
    * conversation.
    * When not set a default value of 10 will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#max_conversation_messages CesGuardrail#max_conversation_messages}
    */
    readonly maxConversationMessages?: number;
    /**
    * Defines when to apply the policy check during the conversation. If set to
    * 'POLICY_SCOPE_UNSPECIFIED', the policy will be applied to the user input.
    * When applying the policy to the agent response, additional latency will
    * be introduced before the agent can respond.
    * Possible values:
    * USER_QUERY
    * AGENT_RESPONSE
    * USER_QUERY_AND_AGENT_RESPONSE
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#policy_scope CesGuardrail#policy_scope}
    */
    readonly policyScope: string;
    /**
    * Policy prompt.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#prompt CesGuardrail#prompt}
    */
    readonly prompt: string;
    /**
    * model_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#model_settings CesGuardrail#model_settings}
    */
    readonly modelSettings?: CesGuardrailLlmPromptSecurityCustomPolicyModelSettings;
}
export declare function cesGuardrailLlmPromptSecurityCustomPolicyToTerraform(struct?: CesGuardrailLlmPromptSecurityCustomPolicyOutputReference | CesGuardrailLlmPromptSecurityCustomPolicy): any;
export declare function cesGuardrailLlmPromptSecurityCustomPolicyToHclTerraform(struct?: CesGuardrailLlmPromptSecurityCustomPolicyOutputReference | CesGuardrailLlmPromptSecurityCustomPolicy): any;
export declare class CesGuardrailLlmPromptSecurityCustomPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesGuardrailLlmPromptSecurityCustomPolicy | undefined;
    set internalValue(value: CesGuardrailLlmPromptSecurityCustomPolicy | undefined);
    private _allowShortUtterance?;
    get allowShortUtterance(): boolean | cdktn.IResolvable;
    set allowShortUtterance(value: boolean | cdktn.IResolvable);
    resetAllowShortUtterance(): void;
    get allowShortUtteranceInput(): boolean | cdktn.IResolvable | undefined;
    private _failOpen?;
    get failOpen(): boolean | cdktn.IResolvable;
    set failOpen(value: boolean | cdktn.IResolvable);
    resetFailOpen(): void;
    get failOpenInput(): boolean | cdktn.IResolvable | undefined;
    private _maxConversationMessages?;
    get maxConversationMessages(): number;
    set maxConversationMessages(value: number);
    resetMaxConversationMessages(): void;
    get maxConversationMessagesInput(): number | undefined;
    private _policyScope?;
    get policyScope(): string;
    set policyScope(value: string);
    get policyScopeInput(): string | undefined;
    private _prompt?;
    get prompt(): string;
    set prompt(value: string);
    get promptInput(): string | undefined;
    private _modelSettings;
    get modelSettings(): CesGuardrailLlmPromptSecurityCustomPolicyModelSettingsOutputReference;
    putModelSettings(value: CesGuardrailLlmPromptSecurityCustomPolicyModelSettings): void;
    resetModelSettings(): void;
    get modelSettingsInput(): CesGuardrailLlmPromptSecurityCustomPolicyModelSettings | undefined;
}
export interface CesGuardrailLlmPromptSecurityDefaultSettings {
}
export declare function cesGuardrailLlmPromptSecurityDefaultSettingsToTerraform(struct?: CesGuardrailLlmPromptSecurityDefaultSettingsOutputReference | CesGuardrailLlmPromptSecurityDefaultSettings): any;
export declare function cesGuardrailLlmPromptSecurityDefaultSettingsToHclTerraform(struct?: CesGuardrailLlmPromptSecurityDefaultSettingsOutputReference | CesGuardrailLlmPromptSecurityDefaultSettings): any;
export declare class CesGuardrailLlmPromptSecurityDefaultSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesGuardrailLlmPromptSecurityDefaultSettings | undefined;
    set internalValue(value: CesGuardrailLlmPromptSecurityDefaultSettings | undefined);
    get defaultPromptTemplate(): string;
}
export interface CesGuardrailLlmPromptSecurity {
    /**
    * Determines the behavior when the guardrail encounters an LLM error.
    * - If true: the guardrail is bypassed.
    * - If false (default): the guardrail triggers/blocks.
    * Note: If a custom policy is provided, this field is ignored in favor of
    * the policy's 'failOpen' configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#fail_open CesGuardrail#fail_open}
    */
    readonly failOpen?: boolean | cdktn.IResolvable;
    /**
    * custom_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#custom_policy CesGuardrail#custom_policy}
    */
    readonly customPolicy?: CesGuardrailLlmPromptSecurityCustomPolicy;
    /**
    * default_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#default_settings CesGuardrail#default_settings}
    */
    readonly defaultSettings?: CesGuardrailLlmPromptSecurityDefaultSettings;
}
export declare function cesGuardrailLlmPromptSecurityToTerraform(struct?: CesGuardrailLlmPromptSecurityOutputReference | CesGuardrailLlmPromptSecurity): any;
export declare function cesGuardrailLlmPromptSecurityToHclTerraform(struct?: CesGuardrailLlmPromptSecurityOutputReference | CesGuardrailLlmPromptSecurity): any;
export declare class CesGuardrailLlmPromptSecurityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesGuardrailLlmPromptSecurity | undefined;
    set internalValue(value: CesGuardrailLlmPromptSecurity | undefined);
    private _failOpen?;
    get failOpen(): boolean | cdktn.IResolvable;
    set failOpen(value: boolean | cdktn.IResolvable);
    resetFailOpen(): void;
    get failOpenInput(): boolean | cdktn.IResolvable | undefined;
    private _customPolicy;
    get customPolicy(): CesGuardrailLlmPromptSecurityCustomPolicyOutputReference;
    putCustomPolicy(value: CesGuardrailLlmPromptSecurityCustomPolicy): void;
    resetCustomPolicy(): void;
    get customPolicyInput(): CesGuardrailLlmPromptSecurityCustomPolicy | undefined;
    private _defaultSettings;
    get defaultSettings(): CesGuardrailLlmPromptSecurityDefaultSettingsOutputReference;
    putDefaultSettings(value: CesGuardrailLlmPromptSecurityDefaultSettings): void;
    resetDefaultSettings(): void;
    get defaultSettingsInput(): CesGuardrailLlmPromptSecurityDefaultSettings | undefined;
}
export interface CesGuardrailModelSafetySafetySettings {
    /**
    * The harm category.
    * Possible values:
    * HARM_CATEGORY_HATE_SPEECH
    * HARM_CATEGORY_DANGEROUS_CONTENT
    * HARM_CATEGORY_HARASSMENT
    * HARM_CATEGORY_SEXUALLY_EXPLICIT Possible values: ["HARM_CATEGORY_HATE_SPEECH", "HARM_CATEGORY_DANGEROUS_CONTENT", "HARM_CATEGORY_HARASSMENT", "HARM_CATEGORY_SEXUALLY_EXPLICIT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#category CesGuardrail#category}
    */
    readonly category: string;
    /**
    * The harm block threshold.
    * Possible values:
    * BLOCK_LOW_AND_ABOVE
    * BLOCK_MEDIUM_AND_ABOVE
    * BLOCK_ONLY_HIGH
    * BLOCK_NONE
    * OFF Possible values: ["BLOCK_LOW_AND_ABOVE", "BLOCK_MEDIUM_AND_ABOVE", "BLOCK_ONLY_HIGH", "BLOCK_NONE", "OFF"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#threshold CesGuardrail#threshold}
    */
    readonly threshold: string;
}
export declare function cesGuardrailModelSafetySafetySettingsToTerraform(struct?: CesGuardrailModelSafetySafetySettings | cdktn.IResolvable): any;
export declare function cesGuardrailModelSafetySafetySettingsToHclTerraform(struct?: CesGuardrailModelSafetySafetySettings | cdktn.IResolvable): any;
export declare class CesGuardrailModelSafetySafetySettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesGuardrailModelSafetySafetySettings | cdktn.IResolvable | undefined;
    set internalValue(value: CesGuardrailModelSafetySafetySettings | cdktn.IResolvable | undefined);
    private _category?;
    get category(): string;
    set category(value: string);
    get categoryInput(): string | undefined;
    private _threshold?;
    get threshold(): string;
    set threshold(value: string);
    get thresholdInput(): string | undefined;
}
export declare class CesGuardrailModelSafetySafetySettingsList extends cdktn.ComplexList {
    internalValue?: CesGuardrailModelSafetySafetySettings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesGuardrailModelSafetySafetySettingsOutputReference;
}
export interface CesGuardrailModelSafety {
    /**
    * safety_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#safety_settings CesGuardrail#safety_settings}
    */
    readonly safetySettings: CesGuardrailModelSafetySafetySettings[] | cdktn.IResolvable;
}
export declare function cesGuardrailModelSafetyToTerraform(struct?: CesGuardrailModelSafetyOutputReference | CesGuardrailModelSafety): any;
export declare function cesGuardrailModelSafetyToHclTerraform(struct?: CesGuardrailModelSafetyOutputReference | CesGuardrailModelSafety): any;
export declare class CesGuardrailModelSafetyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesGuardrailModelSafety | undefined;
    set internalValue(value: CesGuardrailModelSafety | undefined);
    private _safetySettings;
    get safetySettings(): CesGuardrailModelSafetySafetySettingsList;
    putSafetySettings(value: CesGuardrailModelSafetySafetySettings[] | cdktn.IResolvable): void;
    get safetySettingsInput(): cdktn.IResolvable | CesGuardrailModelSafetySafetySettings[] | undefined;
}
export interface CesGuardrailTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#create CesGuardrail#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#delete CesGuardrail#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#update CesGuardrail#update}
    */
    readonly update?: string;
}
export declare function cesGuardrailTimeoutsToTerraform(struct?: CesGuardrailTimeouts | cdktn.IResolvable): any;
export declare function cesGuardrailTimeoutsToHclTerraform(struct?: CesGuardrailTimeouts | cdktn.IResolvable): any;
export declare class CesGuardrailTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesGuardrailTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CesGuardrailTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail google_ces_guardrail}
*/
export declare class CesGuardrail extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_ces_guardrail";
    /**
    * Generates CDKTN code for importing a CesGuardrail resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CesGuardrail to import
    * @param importFromId The id of the existing CesGuardrail that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CesGuardrail to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_guardrail google_ces_guardrail} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CesGuardrailConfig
    */
    constructor(scope: Construct, id: string, config: CesGuardrailConfig);
    private _app?;
    get app(): string;
    set app(value: string);
    get appInput(): string | undefined;
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get etag(): string;
    private _guardrailId?;
    get guardrailId(): string;
    set guardrailId(value: string);
    get guardrailIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get updateTime(): string;
    private _action;
    get action(): CesGuardrailActionOutputReference;
    putAction(value: CesGuardrailAction): void;
    resetAction(): void;
    get actionInput(): CesGuardrailAction | undefined;
    private _codeCallback;
    get codeCallback(): CesGuardrailCodeCallbackOutputReference;
    putCodeCallback(value: CesGuardrailCodeCallback): void;
    resetCodeCallback(): void;
    get codeCallbackInput(): CesGuardrailCodeCallback | undefined;
    private _contentFilter;
    get contentFilter(): CesGuardrailContentFilterOutputReference;
    putContentFilter(value: CesGuardrailContentFilter): void;
    resetContentFilter(): void;
    get contentFilterInput(): CesGuardrailContentFilter | undefined;
    private _llmPolicy;
    get llmPolicy(): CesGuardrailLlmPolicyOutputReference;
    putLlmPolicy(value: CesGuardrailLlmPolicy): void;
    resetLlmPolicy(): void;
    get llmPolicyInput(): CesGuardrailLlmPolicy | undefined;
    private _llmPromptSecurity;
    get llmPromptSecurity(): CesGuardrailLlmPromptSecurityOutputReference;
    putLlmPromptSecurity(value: CesGuardrailLlmPromptSecurity): void;
    resetLlmPromptSecurity(): void;
    get llmPromptSecurityInput(): CesGuardrailLlmPromptSecurity | undefined;
    private _modelSafety;
    get modelSafety(): CesGuardrailModelSafetyOutputReference;
    putModelSafety(value: CesGuardrailModelSafety): void;
    resetModelSafety(): void;
    get modelSafetyInput(): CesGuardrailModelSafety | undefined;
    private _timeouts;
    get timeouts(): CesGuardrailTimeoutsOutputReference;
    putTimeouts(value: CesGuardrailTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CesGuardrailTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
