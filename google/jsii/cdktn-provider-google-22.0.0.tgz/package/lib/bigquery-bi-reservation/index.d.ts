/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BigqueryBiReservationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_bi_reservation#deletion_policy BigqueryBiReservation#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_bi_reservation#id BigqueryBiReservation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * LOCATION_DESCRIPTION
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_bi_reservation#location BigqueryBiReservation#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_bi_reservation#project BigqueryBiReservation#project}
    */
    readonly project?: string;
    /**
    * Size of a reservation, in bytes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_bi_reservation#size BigqueryBiReservation#size}
    */
    readonly size?: number;
    /**
    * preferred_tables block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_bi_reservation#preferred_tables BigqueryBiReservation#preferred_tables}
    */
    readonly preferredTables?: BigqueryBiReservationPreferredTables[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_bi_reservation#timeouts BigqueryBiReservation#timeouts}
    */
    readonly timeouts?: BigqueryBiReservationTimeouts;
}
export interface BigqueryBiReservationPreferredTables {
    /**
    * The ID of the dataset in the above project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_bi_reservation#dataset_id BigqueryBiReservation#dataset_id}
    */
    readonly datasetId?: string;
    /**
    * The assigned project ID of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_bi_reservation#project_id BigqueryBiReservation#project_id}
    */
    readonly projectId?: string;
    /**
    * The ID of the table in the above dataset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_bi_reservation#table_id BigqueryBiReservation#table_id}
    */
    readonly tableId?: string;
}
export declare function bigqueryBiReservationPreferredTablesToTerraform(struct?: BigqueryBiReservationPreferredTables | cdktn.IResolvable): any;
export declare function bigqueryBiReservationPreferredTablesToHclTerraform(struct?: BigqueryBiReservationPreferredTables | cdktn.IResolvable): any;
export declare class BigqueryBiReservationPreferredTablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BigqueryBiReservationPreferredTables | cdktn.IResolvable | undefined;
    set internalValue(value: BigqueryBiReservationPreferredTables | cdktn.IResolvable | undefined);
    private _datasetId?;
    get datasetId(): string;
    set datasetId(value: string);
    resetDatasetId(): void;
    get datasetIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _tableId?;
    get tableId(): string;
    set tableId(value: string);
    resetTableId(): void;
    get tableIdInput(): string | undefined;
}
export declare class BigqueryBiReservationPreferredTablesList extends cdktn.ComplexList {
    internalValue?: BigqueryBiReservationPreferredTables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BigqueryBiReservationPreferredTablesOutputReference;
}
export interface BigqueryBiReservationTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_bi_reservation#create BigqueryBiReservation#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_bi_reservation#delete BigqueryBiReservation#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_bi_reservation#update BigqueryBiReservation#update}
    */
    readonly update?: string;
}
export declare function bigqueryBiReservationTimeoutsToTerraform(struct?: BigqueryBiReservationTimeouts | cdktn.IResolvable): any;
export declare function bigqueryBiReservationTimeoutsToHclTerraform(struct?: BigqueryBiReservationTimeouts | cdktn.IResolvable): any;
export declare class BigqueryBiReservationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryBiReservationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BigqueryBiReservationTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_bi_reservation google_bigquery_bi_reservation}
*/
export declare class BigqueryBiReservation extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_bigquery_bi_reservation";
    /**
    * Generates CDKTN code for importing a BigqueryBiReservation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BigqueryBiReservation to import
    * @param importFromId The id of the existing BigqueryBiReservation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_bi_reservation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BigqueryBiReservation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_bi_reservation google_bigquery_bi_reservation} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BigqueryBiReservationConfig
    */
    constructor(scope: Construct, id: string, config: BigqueryBiReservationConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    resetSize(): void;
    get sizeInput(): number | undefined;
    get updateTime(): string;
    private _preferredTables;
    get preferredTables(): BigqueryBiReservationPreferredTablesList;
    putPreferredTables(value: BigqueryBiReservationPreferredTables[] | cdktn.IResolvable): void;
    resetPreferredTables(): void;
    get preferredTablesInput(): cdktn.IResolvable | BigqueryBiReservationPreferredTables[] | undefined;
    private _timeouts;
    get timeouts(): BigqueryBiReservationTimeoutsOutputReference;
    putTimeouts(value: BigqueryBiReservationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BigqueryBiReservationTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
