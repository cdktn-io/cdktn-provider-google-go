/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeInstanceFromTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * If true, allows Terraform to stop the instance to update its properties. If you try to update a property that requires stopping the instance without setting this field, the update will fail.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#allow_stopping_for_update ComputeInstanceFromTemplate#allow_stopping_for_update}
    */
    readonly allowStoppingForUpdate?: boolean | cdktn.IResolvable;
    /**
    * Whether sending and receiving of packets with non-matching source or destination IPs is allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#can_ip_forward ComputeInstanceFromTemplate#can_ip_forward}
    */
    readonly canIpForward?: boolean | cdktn.IResolvable;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#deletion_policy ComputeInstanceFromTemplate#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Whether deletion protection is enabled on this instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#deletion_protection ComputeInstanceFromTemplate#deletion_protection}
    */
    readonly deletionProtection?: boolean | cdktn.IResolvable;
    /**
    * A brief description of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#description ComputeInstanceFromTemplate#description}
    */
    readonly description?: string;
    /**
    * Desired status of the instance. Either "RUNNING", "SUSPENDED" or "TERMINATED".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#desired_status ComputeInstanceFromTemplate#desired_status}
    */
    readonly desiredStatus?: string;
    /**
    * Whether the instance has virtual displays enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#enable_display ComputeInstanceFromTemplate#enable_display}
    */
    readonly enableDisplay?: boolean | cdktn.IResolvable;
    /**
    * A custom hostname for the instance. Must be a fully qualified DNS name and RFC-1035-valid. Valid format is a series of labels 1-63 characters long matching the regular expression [a-z]([-a-z0-9]*[a-z0-9]), concatenated with periods. The entire hostname must not exceed 253 characters. Changing this forces a new resource to be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#hostname ComputeInstanceFromTemplate#hostname}
    */
    readonly hostname?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#id ComputeInstanceFromTemplate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Action to be taken when a customer's encryption key is revoked. Supports "STOP" and "NONE", with "NONE" being the default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#key_revocation_action_type ComputeInstanceFromTemplate#key_revocation_action_type}
    */
    readonly keyRevocationActionType?: string;
    /**
    * A set of key/value label pairs assigned to the instance.
    *
    * 				**Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * 				Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#labels ComputeInstanceFromTemplate#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The machine type to create.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#machine_type ComputeInstanceFromTemplate#machine_type}
    */
    readonly machineType?: string;
    /**
    * Metadata key/value pairs made available within the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#metadata ComputeInstanceFromTemplate#metadata}
    */
    readonly metadata?: {
        [key: string]: string;
    };
    /**
    * Metadata startup scripts made available within the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#metadata_startup_script ComputeInstanceFromTemplate#metadata_startup_script}
    */
    readonly metadataStartupScript?: string;
    /**
    * The minimum CPU platform specified for the VM instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#min_cpu_platform ComputeInstanceFromTemplate#min_cpu_platform}
    */
    readonly minCpuPlatform?: string;
    /**
    * The name of the instance. One of name or self_link must be provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#name ComputeInstanceFromTemplate#name}
    */
    readonly name: string;
    /**
    * The ID of the project in which the resource belongs. If self_link is provided, this value is ignored. If neither self_link nor project are provided, the provider project is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#project ComputeInstanceFromTemplate#project}
    */
    readonly project?: string;
    /**
    * A list of self_links of resource policies to attach to the instance. Currently a max of 1 resource policy is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#resource_policies ComputeInstanceFromTemplate#resource_policies}
    */
    readonly resourcePolicies?: string[];
    /**
    * Name or self link of an instance template to create the instance based on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#source_instance_template ComputeInstanceFromTemplate#source_instance_template}
    */
    readonly sourceInstanceTemplate: string;
    /**
    * The list of tags attached to the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#tags ComputeInstanceFromTemplate#tags}
    */
    readonly tags?: string[];
    /**
    * The zone of the instance. If self_link is provided, this value is ignored. If neither self_link nor zone are provided, the provider zone is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#zone ComputeInstanceFromTemplate#zone}
    */
    readonly zone?: string;
    /**
    * advanced_machine_features block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#advanced_machine_features ComputeInstanceFromTemplate#advanced_machine_features}
    */
    readonly advancedMachineFeatures?: ComputeInstanceFromTemplateAdvancedMachineFeatures;
    /**
    * attached_disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#attached_disk ComputeInstanceFromTemplate#attached_disk}
    */
    readonly attachedDisk?: ComputeInstanceFromTemplateAttachedDisk[] | cdktn.IResolvable;
    /**
    * boot_disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#boot_disk ComputeInstanceFromTemplate#boot_disk}
    */
    readonly bootDisk?: ComputeInstanceFromTemplateBootDisk;
    /**
    * confidential_instance_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#confidential_instance_config ComputeInstanceFromTemplate#confidential_instance_config}
    */
    readonly confidentialInstanceConfig?: ComputeInstanceFromTemplateConfidentialInstanceConfig;
    /**
    * guest_accelerator block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#guest_accelerator ComputeInstanceFromTemplate#guest_accelerator}
    */
    readonly guestAccelerator?: ComputeInstanceFromTemplateGuestAccelerator[] | cdktn.IResolvable;
    /**
    * instance_encryption_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#instance_encryption_key ComputeInstanceFromTemplate#instance_encryption_key}
    */
    readonly instanceEncryptionKey?: ComputeInstanceFromTemplateInstanceEncryptionKey;
    /**
    * network_interface block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#network_interface ComputeInstanceFromTemplate#network_interface}
    */
    readonly networkInterface?: ComputeInstanceFromTemplateNetworkInterface[] | cdktn.IResolvable;
    /**
    * network_performance_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#network_performance_config ComputeInstanceFromTemplate#network_performance_config}
    */
    readonly networkPerformanceConfig?: ComputeInstanceFromTemplateNetworkPerformanceConfig;
    /**
    * params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#params ComputeInstanceFromTemplate#params}
    */
    readonly params?: ComputeInstanceFromTemplateParams;
    /**
    * reservation_affinity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#reservation_affinity ComputeInstanceFromTemplate#reservation_affinity}
    */
    readonly reservationAffinity?: ComputeInstanceFromTemplateReservationAffinity;
    /**
    * scheduling block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#scheduling ComputeInstanceFromTemplate#scheduling}
    */
    readonly scheduling?: ComputeInstanceFromTemplateScheduling;
    /**
    * scratch_disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#scratch_disk ComputeInstanceFromTemplate#scratch_disk}
    */
    readonly scratchDisk?: ComputeInstanceFromTemplateScratchDisk[] | cdktn.IResolvable;
    /**
    * service_account block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#service_account ComputeInstanceFromTemplate#service_account}
    */
    readonly serviceAccount?: ComputeInstanceFromTemplateServiceAccount;
    /**
    * shielded_instance_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#shielded_instance_config ComputeInstanceFromTemplate#shielded_instance_config}
    */
    readonly shieldedInstanceConfig?: ComputeInstanceFromTemplateShieldedInstanceConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#timeouts ComputeInstanceFromTemplate#timeouts}
    */
    readonly timeouts?: ComputeInstanceFromTemplateTimeouts;
    /**
    * workload_identity_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#workload_identity_config ComputeInstanceFromTemplate#workload_identity_config}
    */
    readonly workloadIdentityConfig?: ComputeInstanceFromTemplateWorkloadIdentityConfig;
}
export interface ComputeInstanceFromTemplateAdvancedMachineFeatures {
    /**
    * Whether to enable nested virtualization or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#enable_nested_virtualization ComputeInstanceFromTemplate#enable_nested_virtualization}
    */
    readonly enableNestedVirtualization?: boolean | cdktn.IResolvable;
    /**
    * Whether to enable UEFI networking for the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#enable_uefi_networking ComputeInstanceFromTemplate#enable_uefi_networking}
    */
    readonly enableUefiNetworking?: boolean | cdktn.IResolvable;
    /**
    * The PMU is a hardware component within the CPU core that monitors how the processor runs code. Valid values for the level of PMU are "STANDARD", "ENHANCED", and "ARCHITECTURAL".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#performance_monitoring_unit ComputeInstanceFromTemplate#performance_monitoring_unit}
    */
    readonly performanceMonitoringUnit?: string;
    /**
    * The number of threads per physical core. To disable simultaneous multithreading (SMT) set this to 1. If unset, the maximum number of threads supported per core by the underlying processor is assumed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#threads_per_core ComputeInstanceFromTemplate#threads_per_core}
    */
    readonly threadsPerCore?: number;
    /**
    * Turbo frequency mode to use for the instance. Currently supported modes is "ALL_CORE_MAX".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#turbo_mode ComputeInstanceFromTemplate#turbo_mode}
    */
    readonly turboMode?: string;
    /**
    * The number of physical cores to expose to an instance. Multiply by the number of threads per core to compute the total number of virtual CPUs to expose to the instance. If unset, the number of cores is inferred from the instance\'s nominal CPU count and the underlying platform\'s SMT width.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#visible_core_count ComputeInstanceFromTemplate#visible_core_count}
    */
    readonly visibleCoreCount?: number;
}
export declare function computeInstanceFromTemplateAdvancedMachineFeaturesToTerraform(struct?: ComputeInstanceFromTemplateAdvancedMachineFeaturesOutputReference | ComputeInstanceFromTemplateAdvancedMachineFeatures): any;
export declare function computeInstanceFromTemplateAdvancedMachineFeaturesToHclTerraform(struct?: ComputeInstanceFromTemplateAdvancedMachineFeaturesOutputReference | ComputeInstanceFromTemplateAdvancedMachineFeatures): any;
export declare class ComputeInstanceFromTemplateAdvancedMachineFeaturesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceFromTemplateAdvancedMachineFeatures | undefined;
    set internalValue(value: ComputeInstanceFromTemplateAdvancedMachineFeatures | undefined);
    private _enableNestedVirtualization?;
    get enableNestedVirtualization(): boolean | cdktn.IResolvable;
    set enableNestedVirtualization(value: boolean | cdktn.IResolvable);
    resetEnableNestedVirtualization(): void;
    get enableNestedVirtualizationInput(): boolean | cdktn.IResolvable | undefined;
    private _enableUefiNetworking?;
    get enableUefiNetworking(): boolean | cdktn.IResolvable;
    set enableUefiNetworking(value: boolean | cdktn.IResolvable);
    resetEnableUefiNetworking(): void;
    get enableUefiNetworkingInput(): boolean | cdktn.IResolvable | undefined;
    private _performanceMonitoringUnit?;
    get performanceMonitoringUnit(): string;
    set performanceMonitoringUnit(value: string);
    resetPerformanceMonitoringUnit(): void;
    get performanceMonitoringUnitInput(): string | undefined;
    private _threadsPerCore?;
    get threadsPerCore(): number;
    set threadsPerCore(value: number);
    resetThreadsPerCore(): void;
    get threadsPerCoreInput(): number | undefined;
    private _turboMode?;
    get turboMode(): string;
    set turboMode(value: string);
    resetTurboMode(): void;
    get turboModeInput(): string | undefined;
    private _visibleCoreCount?;
    get visibleCoreCount(): number;
    set visibleCoreCount(value: number);
    resetVisibleCoreCount(): void;
    get visibleCoreCountInput(): number | undefined;
}
export interface ComputeInstanceFromTemplateAttachedDisk {
    /**
    * Name with which the attached disk is accessible under /dev/disk/by-id/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#device_name ComputeInstanceFromTemplate#device_name}
    */
    readonly deviceName?: string;
    /**
    * A 256-bit customer-supplied encryption key, encoded in RFC 4648 base64 to encrypt this disk. Only one of kms_key_self_link, disk_encryption_key_rsa and disk_encryption_key_raw may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#disk_encryption_key_raw ComputeInstanceFromTemplate#disk_encryption_key_raw}
    */
    readonly diskEncryptionKeyRaw?: string;
    /**
    * Specifies an RFC 4648 base64 encoded, RSA-wrapped 2048-bit customer-supplied encryption key to either encrypt or decrypt this resource. Only one of kms_key_self_link, disk_encryption_key_rsa and disk_encryption_key_raw may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#disk_encryption_key_rsa ComputeInstanceFromTemplate#disk_encryption_key_rsa}
    */
    readonly diskEncryptionKeyRsa?: string;
    /**
    * The service account being used for the encryption request for the given KMS key. If absent, the Compute Engine default service account is used
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#disk_encryption_service_account ComputeInstanceFromTemplate#disk_encryption_service_account}
    */
    readonly diskEncryptionServiceAccount?: string;
    /**
    * Whether to force attach the regional disk even if it's currently attached to another instance. If you try to force attach a zonal disk to an instance, you will receive an error. Setting this parameter cause VM recreation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#force_attach ComputeInstanceFromTemplate#force_attach}
    */
    readonly forceAttach?: boolean | cdktn.IResolvable;
    /**
    * The self_link of the encryption key that is stored in Google Cloud KMS to encrypt this disk. Only one of kms_key_self_link, disk_encryption_key_rsa and disk_encryption_key_raw may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#kms_key_self_link ComputeInstanceFromTemplate#kms_key_self_link}
    */
    readonly kmsKeySelfLink?: string;
    /**
    * Read/write mode for the disk. One of "READ_ONLY" or "READ_WRITE".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#mode ComputeInstanceFromTemplate#mode}
    */
    readonly mode?: string;
    /**
    * The name or self_link of the disk attached to this instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#source ComputeInstanceFromTemplate#source}
    */
    readonly source: string;
}
export declare function computeInstanceFromTemplateAttachedDiskToTerraform(struct?: ComputeInstanceFromTemplateAttachedDisk | cdktn.IResolvable): any;
export declare function computeInstanceFromTemplateAttachedDiskToHclTerraform(struct?: ComputeInstanceFromTemplateAttachedDisk | cdktn.IResolvable): any;
export declare class ComputeInstanceFromTemplateAttachedDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceFromTemplateAttachedDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInstanceFromTemplateAttachedDisk | cdktn.IResolvable | undefined);
    private _deviceName?;
    get deviceName(): string;
    set deviceName(value: string);
    resetDeviceName(): void;
    get deviceNameInput(): string | undefined;
    private _diskEncryptionKeyRaw?;
    get diskEncryptionKeyRaw(): string;
    set diskEncryptionKeyRaw(value: string);
    resetDiskEncryptionKeyRaw(): void;
    get diskEncryptionKeyRawInput(): string | undefined;
    private _diskEncryptionKeyRsa?;
    get diskEncryptionKeyRsa(): string;
    set diskEncryptionKeyRsa(value: string);
    resetDiskEncryptionKeyRsa(): void;
    get diskEncryptionKeyRsaInput(): string | undefined;
    get diskEncryptionKeySha256(): string;
    private _diskEncryptionServiceAccount?;
    get diskEncryptionServiceAccount(): string;
    set diskEncryptionServiceAccount(value: string);
    resetDiskEncryptionServiceAccount(): void;
    get diskEncryptionServiceAccountInput(): string | undefined;
    private _forceAttach?;
    get forceAttach(): boolean | cdktn.IResolvable;
    set forceAttach(value: boolean | cdktn.IResolvable);
    resetForceAttach(): void;
    get forceAttachInput(): boolean | cdktn.IResolvable | undefined;
    private _kmsKeySelfLink?;
    get kmsKeySelfLink(): string;
    set kmsKeySelfLink(value: string);
    resetKmsKeySelfLink(): void;
    get kmsKeySelfLinkInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
}
export declare class ComputeInstanceFromTemplateAttachedDiskList extends cdktn.ComplexList {
    internalValue?: ComputeInstanceFromTemplateAttachedDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceFromTemplateAttachedDiskOutputReference;
}
export interface ComputeInstanceFromTemplateBootDiskInitializeParamsSourceImageEncryptionKey {
    /**
    * The self link of the encryption key that is stored in Google Cloud KMS. Only one of kms_key_self_link, rsa_encrypted_key and raw_key may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#kms_key_self_link ComputeInstanceFromTemplate#kms_key_self_link}
    */
    readonly kmsKeySelfLink?: string;
    /**
    * The service account being used for the encryption request for the given KMS key. If absent, the Compute Engine default service account is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#kms_key_service_account ComputeInstanceFromTemplate#kms_key_service_account}
    */
    readonly kmsKeyServiceAccount?: string;
    /**
    * Specifies a 256-bit customer-supplied encryption key, encoded in RFC 4648 base64 to either encrypt or decrypt this resource. Only one of kms_key_self_link, rsa_encrypted_key and raw_key may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#raw_key ComputeInstanceFromTemplate#raw_key}
    */
    readonly rawKey?: string;
    /**
    * Specifies an RFC 4648 base64 encoded, RSA-wrapped 2048-bit customer-supplied encryption key to either encrypt or decrypt this resource. Only one of kms_key_self_link, rsa_encrypted_key and raw_key may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#rsa_encrypted_key ComputeInstanceFromTemplate#rsa_encrypted_key}
    */
    readonly rsaEncryptedKey?: string;
}
export declare function computeInstanceFromTemplateBootDiskInitializeParamsSourceImageEncryptionKeyToTerraform(struct?: ComputeInstanceFromTemplateBootDiskInitializeParamsSourceImageEncryptionKeyOutputReference | ComputeInstanceFromTemplateBootDiskInitializeParamsSourceImageEncryptionKey): any;
export declare function computeInstanceFromTemplateBootDiskInitializeParamsSourceImageEncryptionKeyToHclTerraform(struct?: ComputeInstanceFromTemplateBootDiskInitializeParamsSourceImageEncryptionKeyOutputReference | ComputeInstanceFromTemplateBootDiskInitializeParamsSourceImageEncryptionKey): any;
export declare class ComputeInstanceFromTemplateBootDiskInitializeParamsSourceImageEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceFromTemplateBootDiskInitializeParamsSourceImageEncryptionKey | undefined;
    set internalValue(value: ComputeInstanceFromTemplateBootDiskInitializeParamsSourceImageEncryptionKey | undefined);
    private _kmsKeySelfLink?;
    get kmsKeySelfLink(): string;
    set kmsKeySelfLink(value: string);
    resetKmsKeySelfLink(): void;
    get kmsKeySelfLinkInput(): string | undefined;
    private _kmsKeyServiceAccount?;
    get kmsKeyServiceAccount(): string;
    set kmsKeyServiceAccount(value: string);
    resetKmsKeyServiceAccount(): void;
    get kmsKeyServiceAccountInput(): string | undefined;
    private _rawKey?;
    get rawKey(): string;
    set rawKey(value: string);
    resetRawKey(): void;
    get rawKeyInput(): string | undefined;
    private _rsaEncryptedKey?;
    get rsaEncryptedKey(): string;
    set rsaEncryptedKey(value: string);
    resetRsaEncryptedKey(): void;
    get rsaEncryptedKeyInput(): string | undefined;
    get sha256(): string;
}
export interface ComputeInstanceFromTemplateBootDiskInitializeParamsSourceSnapshotEncryptionKey {
    /**
    * The self link of the encryption key that is stored in Google Cloud KMS. Only one of kms_key_self_link, rsa_encrypted_key and raw_key may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#kms_key_self_link ComputeInstanceFromTemplate#kms_key_self_link}
    */
    readonly kmsKeySelfLink?: string;
    /**
    * The service account being used for the encryption request for the given KMS key. If absent, the Compute Engine default service account is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#kms_key_service_account ComputeInstanceFromTemplate#kms_key_service_account}
    */
    readonly kmsKeyServiceAccount?: string;
    /**
    * Specifies a 256-bit customer-supplied encryption key, encoded in RFC 4648 base64 to either encrypt or decrypt this resource. Only one of kms_key_self_link, rsa_encrypted_key and raw_key may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#raw_key ComputeInstanceFromTemplate#raw_key}
    */
    readonly rawKey?: string;
    /**
    * Specifies an RFC 4648 base64 encoded, RSA-wrapped 2048-bit customer-supplied encryption key to either encrypt or decrypt this resource. Only one of kms_key_self_link, rsa_encrypted_key and raw_key may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#rsa_encrypted_key ComputeInstanceFromTemplate#rsa_encrypted_key}
    */
    readonly rsaEncryptedKey?: string;
}
export declare function computeInstanceFromTemplateBootDiskInitializeParamsSourceSnapshotEncryptionKeyToTerraform(struct?: ComputeInstanceFromTemplateBootDiskInitializeParamsSourceSnapshotEncryptionKeyOutputReference | ComputeInstanceFromTemplateBootDiskInitializeParamsSourceSnapshotEncryptionKey): any;
export declare function computeInstanceFromTemplateBootDiskInitializeParamsSourceSnapshotEncryptionKeyToHclTerraform(struct?: ComputeInstanceFromTemplateBootDiskInitializeParamsSourceSnapshotEncryptionKeyOutputReference | ComputeInstanceFromTemplateBootDiskInitializeParamsSourceSnapshotEncryptionKey): any;
export declare class ComputeInstanceFromTemplateBootDiskInitializeParamsSourceSnapshotEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceFromTemplateBootDiskInitializeParamsSourceSnapshotEncryptionKey | undefined;
    set internalValue(value: ComputeInstanceFromTemplateBootDiskInitializeParamsSourceSnapshotEncryptionKey | undefined);
    private _kmsKeySelfLink?;
    get kmsKeySelfLink(): string;
    set kmsKeySelfLink(value: string);
    resetKmsKeySelfLink(): void;
    get kmsKeySelfLinkInput(): string | undefined;
    private _kmsKeyServiceAccount?;
    get kmsKeyServiceAccount(): string;
    set kmsKeyServiceAccount(value: string);
    resetKmsKeyServiceAccount(): void;
    get kmsKeyServiceAccountInput(): string | undefined;
    private _rawKey?;
    get rawKey(): string;
    set rawKey(value: string);
    resetRawKey(): void;
    get rawKeyInput(): string | undefined;
    private _rsaEncryptedKey?;
    get rsaEncryptedKey(): string;
    set rsaEncryptedKey(value: string);
    resetRsaEncryptedKey(): void;
    get rsaEncryptedKeyInput(): string | undefined;
    get sha256(): string;
}
export interface ComputeInstanceFromTemplateBootDiskInitializeParams {
    /**
    * The architecture of the disk. One of "X86_64" or "ARM64".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#architecture ComputeInstanceFromTemplate#architecture}
    */
    readonly architecture?: string;
    /**
    * A flag to enable confidential compute mode on boot disk
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#enable_confidential_compute ComputeInstanceFromTemplate#enable_confidential_compute}
    */
    readonly enableConfidentialCompute?: boolean | cdktn.IResolvable;
    /**
    * The image from which this disk was initialised.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#image ComputeInstanceFromTemplate#image}
    */
    readonly image?: string;
    /**
    * A set of key/value label pairs assigned to the disk.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#labels ComputeInstanceFromTemplate#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Indicates how many IOPS to provision for the disk. This sets the number of I/O operations per second that the disk can handle.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#provisioned_iops ComputeInstanceFromTemplate#provisioned_iops}
    */
    readonly provisionedIops?: number;
    /**
    * Indicates how much throughput to provision for the disk. This sets the number of throughput mb per second that the disk can handle.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#provisioned_throughput ComputeInstanceFromTemplate#provisioned_throughput}
    */
    readonly provisionedThroughput?: number;
    /**
    * A list of short names or self_links of zones in which to create a regional disk.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#replica_zones ComputeInstanceFromTemplate#replica_zones}
    */
    readonly replicaZones?: string[];
    /**
    * A map of resource manager tags. Resource manager tag keys and values have the same definition as resource manager tags. Keys must be in the format tagKeys/{tag_key_id}, and values are in the format tagValues/456. The field is ignored (both PUT & PATCH) when empty.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#resource_manager_tags ComputeInstanceFromTemplate#resource_manager_tags}
    */
    readonly resourceManagerTags?: {
        [key: string]: string;
    };
    /**
    * A list of self_links of resource policies to attach to the instance's boot disk. Modifying this list will cause the instance to recreate. Currently a max of 1 resource policy is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#resource_policies ComputeInstanceFromTemplate#resource_policies}
    */
    readonly resourcePolicies?: string[];
    /**
    * The size of the image in gigabytes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#size ComputeInstanceFromTemplate#size}
    */
    readonly size?: number;
    /**
    * The snapshot from which this disk was initialised.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#snapshot ComputeInstanceFromTemplate#snapshot}
    */
    readonly snapshot?: string;
    /**
    * The URL of the storage pool in which the new disk is created
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#storage_pool ComputeInstanceFromTemplate#storage_pool}
    */
    readonly storagePool?: string;
    /**
    * The Google Compute Engine disk type. Such as pd-standard, pd-ssd or pd-balanced.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#type ComputeInstanceFromTemplate#type}
    */
    readonly type?: string;
    /**
    * source_image_encryption_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#source_image_encryption_key ComputeInstanceFromTemplate#source_image_encryption_key}
    */
    readonly sourceImageEncryptionKey?: ComputeInstanceFromTemplateBootDiskInitializeParamsSourceImageEncryptionKey;
    /**
    * source_snapshot_encryption_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#source_snapshot_encryption_key ComputeInstanceFromTemplate#source_snapshot_encryption_key}
    */
    readonly sourceSnapshotEncryptionKey?: ComputeInstanceFromTemplateBootDiskInitializeParamsSourceSnapshotEncryptionKey;
}
export declare function computeInstanceFromTemplateBootDiskInitializeParamsToTerraform(struct?: ComputeInstanceFromTemplateBootDiskInitializeParamsOutputReference | ComputeInstanceFromTemplateBootDiskInitializeParams): any;
export declare function computeInstanceFromTemplateBootDiskInitializeParamsToHclTerraform(struct?: ComputeInstanceFromTemplateBootDiskInitializeParamsOutputReference | ComputeInstanceFromTemplateBootDiskInitializeParams): any;
export declare class ComputeInstanceFromTemplateBootDiskInitializeParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceFromTemplateBootDiskInitializeParams | undefined;
    set internalValue(value: ComputeInstanceFromTemplateBootDiskInitializeParams | undefined);
    private _architecture?;
    get architecture(): string;
    set architecture(value: string);
    resetArchitecture(): void;
    get architectureInput(): string | undefined;
    private _enableConfidentialCompute?;
    get enableConfidentialCompute(): boolean | cdktn.IResolvable;
    set enableConfidentialCompute(value: boolean | cdktn.IResolvable);
    resetEnableConfidentialCompute(): void;
    get enableConfidentialComputeInput(): boolean | cdktn.IResolvable | undefined;
    private _image?;
    get image(): string;
    set image(value: string);
    resetImage(): void;
    get imageInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _provisionedIops?;
    get provisionedIops(): number;
    set provisionedIops(value: number);
    resetProvisionedIops(): void;
    get provisionedIopsInput(): number | undefined;
    private _provisionedThroughput?;
    get provisionedThroughput(): number;
    set provisionedThroughput(value: number);
    resetProvisionedThroughput(): void;
    get provisionedThroughputInput(): number | undefined;
    private _replicaZones?;
    get replicaZones(): string[];
    set replicaZones(value: string[]);
    resetReplicaZones(): void;
    get replicaZonesInput(): string[] | undefined;
    private _resourceManagerTags?;
    get resourceManagerTags(): {
        [key: string]: string;
    };
    set resourceManagerTags(value: {
        [key: string]: string;
    });
    resetResourceManagerTags(): void;
    get resourceManagerTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _resourcePolicies?;
    get resourcePolicies(): string[];
    set resourcePolicies(value: string[]);
    resetResourcePolicies(): void;
    get resourcePoliciesInput(): string[] | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    resetSize(): void;
    get sizeInput(): number | undefined;
    private _snapshot?;
    get snapshot(): string;
    set snapshot(value: string);
    resetSnapshot(): void;
    get snapshotInput(): string | undefined;
    private _storagePool?;
    get storagePool(): string;
    set storagePool(value: string);
    resetStoragePool(): void;
    get storagePoolInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _sourceImageEncryptionKey;
    get sourceImageEncryptionKey(): ComputeInstanceFromTemplateBootDiskInitializeParamsSourceImageEncryptionKeyOutputReference;
    putSourceImageEncryptionKey(value: ComputeInstanceFromTemplateBootDiskInitializeParamsSourceImageEncryptionKey): void;
    resetSourceImageEncryptionKey(): void;
    get sourceImageEncryptionKeyInput(): ComputeInstanceFromTemplateBootDiskInitializeParamsSourceImageEncryptionKey | undefined;
    private _sourceSnapshotEncryptionKey;
    get sourceSnapshotEncryptionKey(): ComputeInstanceFromTemplateBootDiskInitializeParamsSourceSnapshotEncryptionKeyOutputReference;
    putSourceSnapshotEncryptionKey(value: ComputeInstanceFromTemplateBootDiskInitializeParamsSourceSnapshotEncryptionKey): void;
    resetSourceSnapshotEncryptionKey(): void;
    get sourceSnapshotEncryptionKeyInput(): ComputeInstanceFromTemplateBootDiskInitializeParamsSourceSnapshotEncryptionKey | undefined;
}
export interface ComputeInstanceFromTemplateBootDisk {
    /**
    * Whether the disk will be auto-deleted when the instance is deleted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#auto_delete ComputeInstanceFromTemplate#auto_delete}
    */
    readonly autoDelete?: boolean | cdktn.IResolvable;
    /**
    * Name with which attached disk will be accessible under /dev/disk/by-id/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#device_name ComputeInstanceFromTemplate#device_name}
    */
    readonly deviceName?: string;
    /**
    * A 256-bit customer-supplied encryption key, encoded in RFC 4648 base64 to encrypt this disk. Only one of kms_key_self_link, disk_encryption_key_raw and disk_encryption_key_rsa may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#disk_encryption_key_raw ComputeInstanceFromTemplate#disk_encryption_key_raw}
    */
    readonly diskEncryptionKeyRaw?: string;
    /**
    * Specifies an RFC 4648 base64 encoded, RSA-wrapped 2048-bit customer-supplied encryption key to either encrypt or decrypt this resource. Only one of kms_key_self_link, disk_encryption_key_raw and disk_encryption_key_rsa may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#disk_encryption_key_rsa ComputeInstanceFromTemplate#disk_encryption_key_rsa}
    */
    readonly diskEncryptionKeyRsa?: string;
    /**
    * The service account being used for the encryption request for the given KMS key. If absent, the Compute Engine default service account is used
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#disk_encryption_service_account ComputeInstanceFromTemplate#disk_encryption_service_account}
    */
    readonly diskEncryptionServiceAccount?: string;
    /**
    * Whether to force attach the regional disk even if it's currently attached to another instance. If you try to force attach a zonal disk to an instance, you will receive an error. Setting this parameter cause VM recreation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#force_attach ComputeInstanceFromTemplate#force_attach}
    */
    readonly forceAttach?: boolean | cdktn.IResolvable;
    /**
    * A list of features to enable on the guest operating system. Applicable only for bootable images.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#guest_os_features ComputeInstanceFromTemplate#guest_os_features}
    */
    readonly guestOsFeatures?: string[];
    /**
    * The disk interface used for attaching this disk. One of SCSI or NVME. (This field is shared with attached_disk and only used for specific cases, please don't specify this field without advice from Google.)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#interface ComputeInstanceFromTemplate#interface}
    */
    readonly interface?: string;
    /**
    * The self_link of the encryption key that is stored in Google Cloud KMS to encrypt this disk. Only one of kms_key_self_link, disk_encryption_key_raw and disk_encryption_key_rsa may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#kms_key_self_link ComputeInstanceFromTemplate#kms_key_self_link}
    */
    readonly kmsKeySelfLink?: string;
    /**
    * Read/write mode for the disk. One of "READ_ONLY" or "READ_WRITE".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#mode ComputeInstanceFromTemplate#mode}
    */
    readonly mode?: string;
    /**
    * The name or self_link of the disk attached to this instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#source ComputeInstanceFromTemplate#source}
    */
    readonly source?: string;
    /**
    * initialize_params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#initialize_params ComputeInstanceFromTemplate#initialize_params}
    */
    readonly initializeParams?: ComputeInstanceFromTemplateBootDiskInitializeParams;
}
export declare function computeInstanceFromTemplateBootDiskToTerraform(struct?: ComputeInstanceFromTemplateBootDiskOutputReference | ComputeInstanceFromTemplateBootDisk): any;
export declare function computeInstanceFromTemplateBootDiskToHclTerraform(struct?: ComputeInstanceFromTemplateBootDiskOutputReference | ComputeInstanceFromTemplateBootDisk): any;
export declare class ComputeInstanceFromTemplateBootDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceFromTemplateBootDisk | undefined;
    set internalValue(value: ComputeInstanceFromTemplateBootDisk | undefined);
    private _autoDelete?;
    get autoDelete(): boolean | cdktn.IResolvable;
    set autoDelete(value: boolean | cdktn.IResolvable);
    resetAutoDelete(): void;
    get autoDeleteInput(): boolean | cdktn.IResolvable | undefined;
    private _deviceName?;
    get deviceName(): string;
    set deviceName(value: string);
    resetDeviceName(): void;
    get deviceNameInput(): string | undefined;
    private _diskEncryptionKeyRaw?;
    get diskEncryptionKeyRaw(): string;
    set diskEncryptionKeyRaw(value: string);
    resetDiskEncryptionKeyRaw(): void;
    get diskEncryptionKeyRawInput(): string | undefined;
    private _diskEncryptionKeyRsa?;
    get diskEncryptionKeyRsa(): string;
    set diskEncryptionKeyRsa(value: string);
    resetDiskEncryptionKeyRsa(): void;
    get diskEncryptionKeyRsaInput(): string | undefined;
    get diskEncryptionKeySha256(): string;
    private _diskEncryptionServiceAccount?;
    get diskEncryptionServiceAccount(): string;
    set diskEncryptionServiceAccount(value: string);
    resetDiskEncryptionServiceAccount(): void;
    get diskEncryptionServiceAccountInput(): string | undefined;
    private _forceAttach?;
    get forceAttach(): boolean | cdktn.IResolvable;
    set forceAttach(value: boolean | cdktn.IResolvable);
    resetForceAttach(): void;
    get forceAttachInput(): boolean | cdktn.IResolvable | undefined;
    private _guestOsFeatures?;
    get guestOsFeatures(): string[];
    set guestOsFeatures(value: string[]);
    resetGuestOsFeatures(): void;
    get guestOsFeaturesInput(): string[] | undefined;
    private _interface?;
    get interface(): string;
    set interface(value: string);
    resetInterface(): void;
    get interfaceInput(): string | undefined;
    private _kmsKeySelfLink?;
    get kmsKeySelfLink(): string;
    set kmsKeySelfLink(value: string);
    resetKmsKeySelfLink(): void;
    get kmsKeySelfLinkInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _initializeParams;
    get initializeParams(): ComputeInstanceFromTemplateBootDiskInitializeParamsOutputReference;
    putInitializeParams(value: ComputeInstanceFromTemplateBootDiskInitializeParams): void;
    resetInitializeParams(): void;
    get initializeParamsInput(): ComputeInstanceFromTemplateBootDiskInitializeParams | undefined;
}
export interface ComputeInstanceFromTemplateConfidentialInstanceConfig {
    /**
    *
    * 								The confidential computing technology the instance uses.
    * 								SEV is an AMD feature. TDX is an Intel feature. One of the following
    * 								values is required: SEV, SEV_SNP, TDX. If SEV_SNP, min_cpu_platform =
    * 								"AMD Milan" is currently required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#confidential_instance_type ComputeInstanceFromTemplate#confidential_instance_type}
    */
    readonly confidentialInstanceType?: string;
    /**
    * Defines whether the instance should have confidential compute enabled. Field will be deprecated in a future release
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#enable_confidential_compute ComputeInstanceFromTemplate#enable_confidential_compute}
    */
    readonly enableConfidentialCompute?: boolean | cdktn.IResolvable;
}
export declare function computeInstanceFromTemplateConfidentialInstanceConfigToTerraform(struct?: ComputeInstanceFromTemplateConfidentialInstanceConfigOutputReference | ComputeInstanceFromTemplateConfidentialInstanceConfig): any;
export declare function computeInstanceFromTemplateConfidentialInstanceConfigToHclTerraform(struct?: ComputeInstanceFromTemplateConfidentialInstanceConfigOutputReference | ComputeInstanceFromTemplateConfidentialInstanceConfig): any;
export declare class ComputeInstanceFromTemplateConfidentialInstanceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceFromTemplateConfidentialInstanceConfig | undefined;
    set internalValue(value: ComputeInstanceFromTemplateConfidentialInstanceConfig | undefined);
    private _confidentialInstanceType?;
    get confidentialInstanceType(): string;
    set confidentialInstanceType(value: string);
    resetConfidentialInstanceType(): void;
    get confidentialInstanceTypeInput(): string | undefined;
    private _enableConfidentialCompute?;
    get enableConfidentialCompute(): boolean | cdktn.IResolvable;
    set enableConfidentialCompute(value: boolean | cdktn.IResolvable);
    resetEnableConfidentialCompute(): void;
    get enableConfidentialComputeInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ComputeInstanceFromTemplateGuestAccelerator {
    /**
    * The number of the guest accelerator cards exposed to this instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#count ComputeInstanceFromTemplate#count}
    */
    readonly count: number;
    /**
    * The accelerator type resource exposed to this instance. E.g. nvidia-tesla-k80.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#type ComputeInstanceFromTemplate#type}
    */
    readonly type: string;
}
export declare function computeInstanceFromTemplateGuestAcceleratorToTerraform(struct?: ComputeInstanceFromTemplateGuestAccelerator | cdktn.IResolvable): any;
export declare function computeInstanceFromTemplateGuestAcceleratorToHclTerraform(struct?: ComputeInstanceFromTemplateGuestAccelerator | cdktn.IResolvable): any;
export declare class ComputeInstanceFromTemplateGuestAcceleratorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceFromTemplateGuestAccelerator | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInstanceFromTemplateGuestAccelerator | cdktn.IResolvable | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    get countInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class ComputeInstanceFromTemplateGuestAcceleratorList extends cdktn.ComplexList {
    internalValue?: ComputeInstanceFromTemplateGuestAccelerator[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceFromTemplateGuestAcceleratorOutputReference;
}
export interface ComputeInstanceFromTemplateInstanceEncryptionKey {
    /**
    * The self link of the encryption key that is stored in Google Cloud KMS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#kms_key_self_link ComputeInstanceFromTemplate#kms_key_self_link}
    */
    readonly kmsKeySelfLink?: string;
    /**
    * The service account being used for the encryption request for the given KMS key. If absent, the Compute Engine default service account is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#kms_key_service_account ComputeInstanceFromTemplate#kms_key_service_account}
    */
    readonly kmsKeyServiceAccount?: string;
}
export declare function computeInstanceFromTemplateInstanceEncryptionKeyToTerraform(struct?: ComputeInstanceFromTemplateInstanceEncryptionKeyOutputReference | ComputeInstanceFromTemplateInstanceEncryptionKey): any;
export declare function computeInstanceFromTemplateInstanceEncryptionKeyToHclTerraform(struct?: ComputeInstanceFromTemplateInstanceEncryptionKeyOutputReference | ComputeInstanceFromTemplateInstanceEncryptionKey): any;
export declare class ComputeInstanceFromTemplateInstanceEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceFromTemplateInstanceEncryptionKey | undefined;
    set internalValue(value: ComputeInstanceFromTemplateInstanceEncryptionKey | undefined);
    private _kmsKeySelfLink?;
    get kmsKeySelfLink(): string;
    set kmsKeySelfLink(value: string);
    resetKmsKeySelfLink(): void;
    get kmsKeySelfLinkInput(): string | undefined;
    private _kmsKeyServiceAccount?;
    get kmsKeyServiceAccount(): string;
    set kmsKeyServiceAccount(value: string);
    resetKmsKeyServiceAccount(): void;
    get kmsKeyServiceAccountInput(): string | undefined;
    get sha256(): string;
}
export interface ComputeInstanceFromTemplateNetworkInterfaceAccessConfig {
    /**
    * The IP address that is be 1:1 mapped to the instance's network ip.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#nat_ip ComputeInstanceFromTemplate#nat_ip}
    */
    readonly natIp?: string;
    /**
    * The networking tier used for configuring this instance. One of PREMIUM or STANDARD.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#network_tier ComputeInstanceFromTemplate#network_tier}
    */
    readonly networkTier?: string;
    /**
    * The DNS domain name for the public PTR record.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#public_ptr_domain_name ComputeInstanceFromTemplate#public_ptr_domain_name}
    */
    readonly publicPtrDomainName?: string;
}
export declare function computeInstanceFromTemplateNetworkInterfaceAccessConfigToTerraform(struct?: ComputeInstanceFromTemplateNetworkInterfaceAccessConfig | cdktn.IResolvable): any;
export declare function computeInstanceFromTemplateNetworkInterfaceAccessConfigToHclTerraform(struct?: ComputeInstanceFromTemplateNetworkInterfaceAccessConfig | cdktn.IResolvable): any;
export declare class ComputeInstanceFromTemplateNetworkInterfaceAccessConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceFromTemplateNetworkInterfaceAccessConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInstanceFromTemplateNetworkInterfaceAccessConfig | cdktn.IResolvable | undefined);
    private _natIp?;
    get natIp(): string;
    set natIp(value: string);
    resetNatIp(): void;
    get natIpInput(): string | undefined;
    private _networkTier?;
    get networkTier(): string;
    set networkTier(value: string);
    resetNetworkTier(): void;
    get networkTierInput(): string | undefined;
    private _publicPtrDomainName?;
    get publicPtrDomainName(): string;
    set publicPtrDomainName(value: string);
    resetPublicPtrDomainName(): void;
    get publicPtrDomainNameInput(): string | undefined;
}
export declare class ComputeInstanceFromTemplateNetworkInterfaceAccessConfigList extends cdktn.ComplexList {
    internalValue?: ComputeInstanceFromTemplateNetworkInterfaceAccessConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceFromTemplateNetworkInterfaceAccessConfigOutputReference;
}
export interface ComputeInstanceFromTemplateNetworkInterfaceAliasIpRange {
    /**
    * The IP CIDR range represented by this alias IP range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#ip_cidr_range ComputeInstanceFromTemplate#ip_cidr_range}
    */
    readonly ipCidrRange: string;
    /**
    * The subnetwork secondary range name specifying the secondary range from which to allocate the IP CIDR range for this alias IP range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#subnetwork_range_name ComputeInstanceFromTemplate#subnetwork_range_name}
    */
    readonly subnetworkRangeName?: string;
}
export declare function computeInstanceFromTemplateNetworkInterfaceAliasIpRangeToTerraform(struct?: ComputeInstanceFromTemplateNetworkInterfaceAliasIpRange | cdktn.IResolvable): any;
export declare function computeInstanceFromTemplateNetworkInterfaceAliasIpRangeToHclTerraform(struct?: ComputeInstanceFromTemplateNetworkInterfaceAliasIpRange | cdktn.IResolvable): any;
export declare class ComputeInstanceFromTemplateNetworkInterfaceAliasIpRangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceFromTemplateNetworkInterfaceAliasIpRange | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInstanceFromTemplateNetworkInterfaceAliasIpRange | cdktn.IResolvable | undefined);
    private _ipCidrRange?;
    get ipCidrRange(): string;
    set ipCidrRange(value: string);
    get ipCidrRangeInput(): string | undefined;
    private _subnetworkRangeName?;
    get subnetworkRangeName(): string;
    set subnetworkRangeName(value: string);
    resetSubnetworkRangeName(): void;
    get subnetworkRangeNameInput(): string | undefined;
}
export declare class ComputeInstanceFromTemplateNetworkInterfaceAliasIpRangeList extends cdktn.ComplexList {
    internalValue?: ComputeInstanceFromTemplateNetworkInterfaceAliasIpRange[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceFromTemplateNetworkInterfaceAliasIpRangeOutputReference;
}
export interface ComputeInstanceFromTemplateNetworkInterfaceIpv6AccessConfig {
    /**
    * The first IPv6 address of the external IPv6 range associated with this instance, prefix length is stored in externalIpv6PrefixLength in ipv6AccessConfig. To use a static external IP address, it must be unused and in the same region as the instance's zone. If not specified, Google Cloud will automatically assign an external IPv6 address from the instance's subnetwork.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#external_ipv6 ComputeInstanceFromTemplate#external_ipv6}
    */
    readonly externalIpv6?: string;
    /**
    * The prefix length of the external IPv6 range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#external_ipv6_prefix_length ComputeInstanceFromTemplate#external_ipv6_prefix_length}
    */
    readonly externalIpv6PrefixLength?: string;
    /**
    * The name of this access configuration. In ipv6AccessConfigs, the recommended name is External IPv6.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#name ComputeInstanceFromTemplate#name}
    */
    readonly name?: string;
    /**
    * The service-level to be provided for IPv6 traffic when the subnet has an external subnet. Only PREMIUM tier is valid for IPv6
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#network_tier ComputeInstanceFromTemplate#network_tier}
    */
    readonly networkTier: string;
    /**
    * The domain name to be used when creating DNSv6 records for the external IPv6 ranges.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#public_ptr_domain_name ComputeInstanceFromTemplate#public_ptr_domain_name}
    */
    readonly publicPtrDomainName?: string;
}
export declare function computeInstanceFromTemplateNetworkInterfaceIpv6AccessConfigToTerraform(struct?: ComputeInstanceFromTemplateNetworkInterfaceIpv6AccessConfig | cdktn.IResolvable): any;
export declare function computeInstanceFromTemplateNetworkInterfaceIpv6AccessConfigToHclTerraform(struct?: ComputeInstanceFromTemplateNetworkInterfaceIpv6AccessConfig | cdktn.IResolvable): any;
export declare class ComputeInstanceFromTemplateNetworkInterfaceIpv6AccessConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceFromTemplateNetworkInterfaceIpv6AccessConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInstanceFromTemplateNetworkInterfaceIpv6AccessConfig | cdktn.IResolvable | undefined);
    private _externalIpv6?;
    get externalIpv6(): string;
    set externalIpv6(value: string);
    resetExternalIpv6(): void;
    get externalIpv6Input(): string | undefined;
    private _externalIpv6PrefixLength?;
    get externalIpv6PrefixLength(): string;
    set externalIpv6PrefixLength(value: string);
    resetExternalIpv6PrefixLength(): void;
    get externalIpv6PrefixLengthInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _networkTier?;
    get networkTier(): string;
    set networkTier(value: string);
    get networkTierInput(): string | undefined;
    private _publicPtrDomainName?;
    get publicPtrDomainName(): string;
    set publicPtrDomainName(value: string);
    resetPublicPtrDomainName(): void;
    get publicPtrDomainNameInput(): string | undefined;
}
export declare class ComputeInstanceFromTemplateNetworkInterfaceIpv6AccessConfigList extends cdktn.ComplexList {
    internalValue?: ComputeInstanceFromTemplateNetworkInterfaceIpv6AccessConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceFromTemplateNetworkInterfaceIpv6AccessConfigOutputReference;
}
export interface ComputeInstanceFromTemplateNetworkInterface {
    /**
    * If true, DNS resolution will be enabled over this interface. Only valid with network_attachment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#enable_vpc_scoped_dns ComputeInstanceFromTemplate#enable_vpc_scoped_dns}
    */
    readonly enableVpcScopedDns?: boolean | cdktn.IResolvable;
    /**
    * Indicates whether igmp query is enabled on the network interface or not. If enabled, also indicates the version of IGMP supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#igmp_query ComputeInstanceFromTemplate#igmp_query}
    */
    readonly igmpQuery?: string;
    /**
    * The prefix length of the primary internal IPv6 range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#internal_ipv6_prefix_length ComputeInstanceFromTemplate#internal_ipv6_prefix_length}
    */
    readonly internalIpv6PrefixLength?: number;
    /**
    * An IPv6 internal network address for this network interface. If not specified, Google Cloud will automatically assign an internal IPv6 address from the instance's subnetwork.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#ipv6_address ComputeInstanceFromTemplate#ipv6_address}
    */
    readonly ipv6Address?: string;
    /**
    * The name or self_link of the network attached to this interface.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#network ComputeInstanceFromTemplate#network}
    */
    readonly network?: string;
    /**
    * The URL of the network attachment that this interface should connect to in the following format: projects/{projectNumber}/regions/{region_name}/networkAttachments/{network_attachment_name}.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#network_attachment ComputeInstanceFromTemplate#network_attachment}
    */
    readonly networkAttachment?: string;
    /**
    * The private IP address assigned to the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#network_ip ComputeInstanceFromTemplate#network_ip}
    */
    readonly networkIp?: string;
    /**
    * The type of vNIC to be used on this interface. Possible values:GVNIC, VIRTIO_NET, IDPF, MRDMA, IRDMA and IDPF
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#nic_type ComputeInstanceFromTemplate#nic_type}
    */
    readonly nicType?: string;
    /**
    * The networking queue count that's specified by users for the network interface. Both Rx and Tx queues will be set to this number. It will be empty if not specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#queue_count ComputeInstanceFromTemplate#queue_count}
    */
    readonly queueCount?: number;
    /**
    * Producer Service's Service class Id for the region of this network interface. Can only be used with network_attachment. It is not possible to use on its own; however, network_attachment can be used without service_class_id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#service_class_id ComputeInstanceFromTemplate#service_class_id}
    */
    readonly serviceClassId?: string;
    /**
    * The stack type for this network interface to identify whether the IPv6 feature is enabled or not. If not specified, IPV4_ONLY will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#stack_type ComputeInstanceFromTemplate#stack_type}
    */
    readonly stackType?: string;
    /**
    * The name or self_link of the subnetwork attached to this interface.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#subnetwork ComputeInstanceFromTemplate#subnetwork}
    */
    readonly subnetwork?: string;
    /**
    * The project in which the subnetwork belongs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#subnetwork_project ComputeInstanceFromTemplate#subnetwork_project}
    */
    readonly subnetworkProject?: string;
    /**
    * VLAN tag of a dynamic network interface, must be an integer in the range from 2 to 255 inclusively.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#vlan ComputeInstanceFromTemplate#vlan}
    */
    readonly vlan?: number;
    /**
    * access_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#access_config ComputeInstanceFromTemplate#access_config}
    */
    readonly accessConfig?: ComputeInstanceFromTemplateNetworkInterfaceAccessConfig[] | cdktn.IResolvable;
    /**
    * alias_ip_range block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#alias_ip_range ComputeInstanceFromTemplate#alias_ip_range}
    */
    readonly aliasIpRange?: ComputeInstanceFromTemplateNetworkInterfaceAliasIpRange[] | cdktn.IResolvable;
    /**
    * ipv6_access_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#ipv6_access_config ComputeInstanceFromTemplate#ipv6_access_config}
    */
    readonly ipv6AccessConfig?: ComputeInstanceFromTemplateNetworkInterfaceIpv6AccessConfig[] | cdktn.IResolvable;
}
export declare function computeInstanceFromTemplateNetworkInterfaceToTerraform(struct?: ComputeInstanceFromTemplateNetworkInterface | cdktn.IResolvable): any;
export declare function computeInstanceFromTemplateNetworkInterfaceToHclTerraform(struct?: ComputeInstanceFromTemplateNetworkInterface | cdktn.IResolvable): any;
export declare class ComputeInstanceFromTemplateNetworkInterfaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceFromTemplateNetworkInterface | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInstanceFromTemplateNetworkInterface | cdktn.IResolvable | undefined);
    private _enableVpcScopedDns?;
    get enableVpcScopedDns(): boolean | cdktn.IResolvable;
    set enableVpcScopedDns(value: boolean | cdktn.IResolvable);
    resetEnableVpcScopedDns(): void;
    get enableVpcScopedDnsInput(): boolean | cdktn.IResolvable | undefined;
    private _igmpQuery?;
    get igmpQuery(): string;
    set igmpQuery(value: string);
    resetIgmpQuery(): void;
    get igmpQueryInput(): string | undefined;
    private _internalIpv6PrefixLength?;
    get internalIpv6PrefixLength(): number;
    set internalIpv6PrefixLength(value: number);
    resetInternalIpv6PrefixLength(): void;
    get internalIpv6PrefixLengthInput(): number | undefined;
    get ipv6AccessType(): string;
    private _ipv6Address?;
    get ipv6Address(): string;
    set ipv6Address(value: string);
    resetIpv6Address(): void;
    get ipv6AddressInput(): string | undefined;
    get name(): string;
    private _network?;
    get network(): string;
    set network(value: string);
    resetNetwork(): void;
    get networkInput(): string | undefined;
    private _networkAttachment?;
    get networkAttachment(): string;
    set networkAttachment(value: string);
    resetNetworkAttachment(): void;
    get networkAttachmentInput(): string | undefined;
    private _networkIp?;
    get networkIp(): string;
    set networkIp(value: string);
    resetNetworkIp(): void;
    get networkIpInput(): string | undefined;
    private _nicType?;
    get nicType(): string;
    set nicType(value: string);
    resetNicType(): void;
    get nicTypeInput(): string | undefined;
    get parentNicName(): string;
    private _queueCount?;
    get queueCount(): number;
    set queueCount(value: number);
    resetQueueCount(): void;
    get queueCountInput(): number | undefined;
    private _serviceClassId?;
    get serviceClassId(): string;
    set serviceClassId(value: string);
    resetServiceClassId(): void;
    get serviceClassIdInput(): string | undefined;
    private _stackType?;
    get stackType(): string;
    set stackType(value: string);
    resetStackType(): void;
    get stackTypeInput(): string | undefined;
    private _subnetwork?;
    get subnetwork(): string;
    set subnetwork(value: string);
    resetSubnetwork(): void;
    get subnetworkInput(): string | undefined;
    private _subnetworkProject?;
    get subnetworkProject(): string;
    set subnetworkProject(value: string);
    resetSubnetworkProject(): void;
    get subnetworkProjectInput(): string | undefined;
    private _vlan?;
    get vlan(): number;
    set vlan(value: number);
    resetVlan(): void;
    get vlanInput(): number | undefined;
    private _accessConfig;
    get accessConfig(): ComputeInstanceFromTemplateNetworkInterfaceAccessConfigList;
    putAccessConfig(value: ComputeInstanceFromTemplateNetworkInterfaceAccessConfig[] | cdktn.IResolvable): void;
    resetAccessConfig(): void;
    get accessConfigInput(): cdktn.IResolvable | ComputeInstanceFromTemplateNetworkInterfaceAccessConfig[] | undefined;
    private _aliasIpRange;
    get aliasIpRange(): ComputeInstanceFromTemplateNetworkInterfaceAliasIpRangeList;
    putAliasIpRange(value: ComputeInstanceFromTemplateNetworkInterfaceAliasIpRange[] | cdktn.IResolvable): void;
    resetAliasIpRange(): void;
    get aliasIpRangeInput(): cdktn.IResolvable | ComputeInstanceFromTemplateNetworkInterfaceAliasIpRange[] | undefined;
    private _ipv6AccessConfig;
    get ipv6AccessConfig(): ComputeInstanceFromTemplateNetworkInterfaceIpv6AccessConfigList;
    putIpv6AccessConfig(value: ComputeInstanceFromTemplateNetworkInterfaceIpv6AccessConfig[] | cdktn.IResolvable): void;
    resetIpv6AccessConfig(): void;
    get ipv6AccessConfigInput(): cdktn.IResolvable | ComputeInstanceFromTemplateNetworkInterfaceIpv6AccessConfig[] | undefined;
}
export declare class ComputeInstanceFromTemplateNetworkInterfaceList extends cdktn.ComplexList {
    internalValue?: ComputeInstanceFromTemplateNetworkInterface[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceFromTemplateNetworkInterfaceOutputReference;
}
export interface ComputeInstanceFromTemplateNetworkPerformanceConfig {
    /**
    * The egress bandwidth tier to enable. Possible values:TIER_1, DEFAULT
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#total_egress_bandwidth_tier ComputeInstanceFromTemplate#total_egress_bandwidth_tier}
    */
    readonly totalEgressBandwidthTier: string;
}
export declare function computeInstanceFromTemplateNetworkPerformanceConfigToTerraform(struct?: ComputeInstanceFromTemplateNetworkPerformanceConfigOutputReference | ComputeInstanceFromTemplateNetworkPerformanceConfig): any;
export declare function computeInstanceFromTemplateNetworkPerformanceConfigToHclTerraform(struct?: ComputeInstanceFromTemplateNetworkPerformanceConfigOutputReference | ComputeInstanceFromTemplateNetworkPerformanceConfig): any;
export declare class ComputeInstanceFromTemplateNetworkPerformanceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceFromTemplateNetworkPerformanceConfig | undefined;
    set internalValue(value: ComputeInstanceFromTemplateNetworkPerformanceConfig | undefined);
    private _totalEgressBandwidthTier?;
    get totalEgressBandwidthTier(): string;
    set totalEgressBandwidthTier(value: string);
    get totalEgressBandwidthTierInput(): string | undefined;
}
export interface ComputeInstanceFromTemplateParams {
    /**
    * A map of resource manager tags. Resource manager tag keys and values have the same definition as resource manager tags. Keys must be in the format tagKeys/{tag_key_id}, and values are in the format tagValues/456. The field is ignored (both PUT & PATCH) when empty.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#resource_manager_tags ComputeInstanceFromTemplate#resource_manager_tags}
    */
    readonly resourceManagerTags?: {
        [key: string]: string;
    };
}
export declare function computeInstanceFromTemplateParamsToTerraform(struct?: ComputeInstanceFromTemplateParamsOutputReference | ComputeInstanceFromTemplateParams): any;
export declare function computeInstanceFromTemplateParamsToHclTerraform(struct?: ComputeInstanceFromTemplateParamsOutputReference | ComputeInstanceFromTemplateParams): any;
export declare class ComputeInstanceFromTemplateParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceFromTemplateParams | undefined;
    set internalValue(value: ComputeInstanceFromTemplateParams | undefined);
    private _resourceManagerTags?;
    get resourceManagerTags(): {
        [key: string]: string;
    };
    set resourceManagerTags(value: {
        [key: string]: string;
    });
    resetResourceManagerTags(): void;
    get resourceManagerTagsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ComputeInstanceFromTemplateReservationAffinitySpecificReservation {
    /**
    * Corresponds to the label key of a reservation resource. To target a SPECIFIC_RESERVATION by name, specify compute.googleapis.com/reservation-name as the key and specify the name of your reservation as the only value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#key ComputeInstanceFromTemplate#key}
    */
    readonly key: string;
    /**
    * Corresponds to the label values of a reservation resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#values ComputeInstanceFromTemplate#values}
    */
    readonly values: string[];
}
export declare function computeInstanceFromTemplateReservationAffinitySpecificReservationToTerraform(struct?: ComputeInstanceFromTemplateReservationAffinitySpecificReservationOutputReference | ComputeInstanceFromTemplateReservationAffinitySpecificReservation): any;
export declare function computeInstanceFromTemplateReservationAffinitySpecificReservationToHclTerraform(struct?: ComputeInstanceFromTemplateReservationAffinitySpecificReservationOutputReference | ComputeInstanceFromTemplateReservationAffinitySpecificReservation): any;
export declare class ComputeInstanceFromTemplateReservationAffinitySpecificReservationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceFromTemplateReservationAffinitySpecificReservation | undefined;
    set internalValue(value: ComputeInstanceFromTemplateReservationAffinitySpecificReservation | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export interface ComputeInstanceFromTemplateReservationAffinity {
    /**
    * The type of reservation from which this instance can consume resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#type ComputeInstanceFromTemplate#type}
    */
    readonly type: string;
    /**
    * specific_reservation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#specific_reservation ComputeInstanceFromTemplate#specific_reservation}
    */
    readonly specificReservation?: ComputeInstanceFromTemplateReservationAffinitySpecificReservation;
}
export declare function computeInstanceFromTemplateReservationAffinityToTerraform(struct?: ComputeInstanceFromTemplateReservationAffinityOutputReference | ComputeInstanceFromTemplateReservationAffinity): any;
export declare function computeInstanceFromTemplateReservationAffinityToHclTerraform(struct?: ComputeInstanceFromTemplateReservationAffinityOutputReference | ComputeInstanceFromTemplateReservationAffinity): any;
export declare class ComputeInstanceFromTemplateReservationAffinityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceFromTemplateReservationAffinity | undefined;
    set internalValue(value: ComputeInstanceFromTemplateReservationAffinity | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _specificReservation;
    get specificReservation(): ComputeInstanceFromTemplateReservationAffinitySpecificReservationOutputReference;
    putSpecificReservation(value: ComputeInstanceFromTemplateReservationAffinitySpecificReservation): void;
    resetSpecificReservation(): void;
    get specificReservationInput(): ComputeInstanceFromTemplateReservationAffinitySpecificReservation | undefined;
}
export interface ComputeInstanceFromTemplateSchedulingLocalSsdRecoveryTimeout {
    /**
    * Span of time that's a fraction of a second at nanosecond
    * resolution. Durations less than one second are represented
    * with a 0 seconds field and a positive nanos field. Must
    * be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#nanos ComputeInstanceFromTemplate#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second.
    * Must be from 0 to 315,576,000,000 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#seconds ComputeInstanceFromTemplate#seconds}
    */
    readonly seconds: number;
}
export declare function computeInstanceFromTemplateSchedulingLocalSsdRecoveryTimeoutToTerraform(struct?: ComputeInstanceFromTemplateSchedulingLocalSsdRecoveryTimeoutOutputReference | ComputeInstanceFromTemplateSchedulingLocalSsdRecoveryTimeout): any;
export declare function computeInstanceFromTemplateSchedulingLocalSsdRecoveryTimeoutToHclTerraform(struct?: ComputeInstanceFromTemplateSchedulingLocalSsdRecoveryTimeoutOutputReference | ComputeInstanceFromTemplateSchedulingLocalSsdRecoveryTimeout): any;
export declare class ComputeInstanceFromTemplateSchedulingLocalSsdRecoveryTimeoutOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceFromTemplateSchedulingLocalSsdRecoveryTimeout | undefined;
    set internalValue(value: ComputeInstanceFromTemplateSchedulingLocalSsdRecoveryTimeout | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): number;
    set seconds(value: number);
    get secondsInput(): number | undefined;
}
export interface ComputeInstanceFromTemplateSchedulingMaxRunDuration {
    /**
    * Span of time that's a fraction of a second at nanosecond
    * resolution. Durations less than one second are represented
    * with a 0 seconds field and a positive nanos field. Must
    * be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#nanos ComputeInstanceFromTemplate#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second.
    * Must be from 0 to 315,576,000,000 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#seconds ComputeInstanceFromTemplate#seconds}
    */
    readonly seconds: number;
}
export declare function computeInstanceFromTemplateSchedulingMaxRunDurationToTerraform(struct?: ComputeInstanceFromTemplateSchedulingMaxRunDurationOutputReference | ComputeInstanceFromTemplateSchedulingMaxRunDuration): any;
export declare function computeInstanceFromTemplateSchedulingMaxRunDurationToHclTerraform(struct?: ComputeInstanceFromTemplateSchedulingMaxRunDurationOutputReference | ComputeInstanceFromTemplateSchedulingMaxRunDuration): any;
export declare class ComputeInstanceFromTemplateSchedulingMaxRunDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceFromTemplateSchedulingMaxRunDuration | undefined;
    set internalValue(value: ComputeInstanceFromTemplateSchedulingMaxRunDuration | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): number;
    set seconds(value: number);
    get secondsInput(): number | undefined;
}
export interface ComputeInstanceFromTemplateSchedulingNodeAffinities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#key ComputeInstanceFromTemplate#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#operator ComputeInstanceFromTemplate#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#values ComputeInstanceFromTemplate#values}
    */
    readonly values: string[];
}
export declare function computeInstanceFromTemplateSchedulingNodeAffinitiesToTerraform(struct?: ComputeInstanceFromTemplateSchedulingNodeAffinities | cdktn.IResolvable): any;
export declare function computeInstanceFromTemplateSchedulingNodeAffinitiesToHclTerraform(struct?: ComputeInstanceFromTemplateSchedulingNodeAffinities | cdktn.IResolvable): any;
export declare class ComputeInstanceFromTemplateSchedulingNodeAffinitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceFromTemplateSchedulingNodeAffinities | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInstanceFromTemplateSchedulingNodeAffinities | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class ComputeInstanceFromTemplateSchedulingNodeAffinitiesList extends cdktn.ComplexList {
    internalValue?: ComputeInstanceFromTemplateSchedulingNodeAffinities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceFromTemplateSchedulingNodeAffinitiesOutputReference;
}
export interface ComputeInstanceFromTemplateSchedulingOnInstanceStopAction {
    /**
    * If true, the contents of any attached Local SSD disks will be discarded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#discard_local_ssd ComputeInstanceFromTemplate#discard_local_ssd}
    */
    readonly discardLocalSsd?: boolean | cdktn.IResolvable;
}
export declare function computeInstanceFromTemplateSchedulingOnInstanceStopActionToTerraform(struct?: ComputeInstanceFromTemplateSchedulingOnInstanceStopActionOutputReference | ComputeInstanceFromTemplateSchedulingOnInstanceStopAction): any;
export declare function computeInstanceFromTemplateSchedulingOnInstanceStopActionToHclTerraform(struct?: ComputeInstanceFromTemplateSchedulingOnInstanceStopActionOutputReference | ComputeInstanceFromTemplateSchedulingOnInstanceStopAction): any;
export declare class ComputeInstanceFromTemplateSchedulingOnInstanceStopActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceFromTemplateSchedulingOnInstanceStopAction | undefined;
    set internalValue(value: ComputeInstanceFromTemplateSchedulingOnInstanceStopAction | undefined);
    private _discardLocalSsd?;
    get discardLocalSsd(): boolean | cdktn.IResolvable;
    set discardLocalSsd(value: boolean | cdktn.IResolvable);
    resetDiscardLocalSsd(): void;
    get discardLocalSsdInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ComputeInstanceFromTemplateSchedulingPreemptionNoticeDuration {
    /**
    * Span of time that's a fraction of a second at nanosecond resolution. Durations less than one second are represented with a 0 seconds field and a positive nanos field. Must be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#nanos ComputeInstanceFromTemplate#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second. Must be from 0 to 315,576,000,000 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#seconds ComputeInstanceFromTemplate#seconds}
    */
    readonly seconds: number;
}
export declare function computeInstanceFromTemplateSchedulingPreemptionNoticeDurationToTerraform(struct?: ComputeInstanceFromTemplateSchedulingPreemptionNoticeDurationOutputReference | ComputeInstanceFromTemplateSchedulingPreemptionNoticeDuration): any;
export declare function computeInstanceFromTemplateSchedulingPreemptionNoticeDurationToHclTerraform(struct?: ComputeInstanceFromTemplateSchedulingPreemptionNoticeDurationOutputReference | ComputeInstanceFromTemplateSchedulingPreemptionNoticeDuration): any;
export declare class ComputeInstanceFromTemplateSchedulingPreemptionNoticeDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceFromTemplateSchedulingPreemptionNoticeDuration | undefined;
    set internalValue(value: ComputeInstanceFromTemplateSchedulingPreemptionNoticeDuration | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): number;
    set seconds(value: number);
    get secondsInput(): number | undefined;
}
export interface ComputeInstanceFromTemplateScheduling {
    /**
    * Specifies if the instance should be restarted if it was terminated by Compute Engine (not a user).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#automatic_restart ComputeInstanceFromTemplate#automatic_restart}
    */
    readonly automaticRestart?: boolean | cdktn.IResolvable;
    /**
    * Specifies the availability domain, which this instance should be scheduled on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#availability_domain ComputeInstanceFromTemplate#availability_domain}
    */
    readonly availabilityDomain?: number;
    /**
    * Specify the time in seconds for host error detection, the value must be within the range of [90, 330] with the increment of 30, if unset, the default behavior of host error recovery will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#host_error_timeout_seconds ComputeInstanceFromTemplate#host_error_timeout_seconds}
    */
    readonly hostErrorTimeoutSeconds?: number;
    /**
    * Specifies the action GCE should take when SPOT VM is preempted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#instance_termination_action ComputeInstanceFromTemplate#instance_termination_action}
    */
    readonly instanceTerminationAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#min_node_cpus ComputeInstanceFromTemplate#min_node_cpus}
    */
    readonly minNodeCpus?: number;
    /**
    * Describes maintenance behavior for the instance. One of MIGRATE or TERMINATE,
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#on_host_maintenance ComputeInstanceFromTemplate#on_host_maintenance}
    */
    readonly onHostMaintenance?: string;
    /**
    * Whether the instance is preemptible.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#preemptible ComputeInstanceFromTemplate#preemptible}
    */
    readonly preemptible?: boolean | cdktn.IResolvable;
    /**
    * Describes the desired provisioning model for the instance. Possible values are STANDARD, SPOT, FLEX_START, and RESERVATION_BOUND. For STANDARD, resources are provisioned immediately. For SPOT, resources are offered at a discount compared to standard pricing but may be preempted. For FLEX_START, resources are offered at a discount with flexible start times. For RESERVATION_BOUND, the instance is bound to a specific reservation and will only consume capacity from that reservation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#provisioning_model ComputeInstanceFromTemplate#provisioning_model}
    */
    readonly provisioningModel?: string;
    /**
    * Specifies the timestamp, when the instance will be terminated,
    * in RFC3339 text format. If specified, the instance termination action
    * will be performed at the termination time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#termination_time ComputeInstanceFromTemplate#termination_time}
    */
    readonly terminationTime?: string;
    /**
    * local_ssd_recovery_timeout block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#local_ssd_recovery_timeout ComputeInstanceFromTemplate#local_ssd_recovery_timeout}
    */
    readonly localSsdRecoveryTimeout?: ComputeInstanceFromTemplateSchedulingLocalSsdRecoveryTimeout;
    /**
    * max_run_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#max_run_duration ComputeInstanceFromTemplate#max_run_duration}
    */
    readonly maxRunDuration?: ComputeInstanceFromTemplateSchedulingMaxRunDuration;
    /**
    * node_affinities block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#node_affinities ComputeInstanceFromTemplate#node_affinities}
    */
    readonly nodeAffinities?: ComputeInstanceFromTemplateSchedulingNodeAffinities[] | cdktn.IResolvable;
    /**
    * on_instance_stop_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#on_instance_stop_action ComputeInstanceFromTemplate#on_instance_stop_action}
    */
    readonly onInstanceStopAction?: ComputeInstanceFromTemplateSchedulingOnInstanceStopAction;
    /**
    * preemption_notice_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#preemption_notice_duration ComputeInstanceFromTemplate#preemption_notice_duration}
    */
    readonly preemptionNoticeDuration?: ComputeInstanceFromTemplateSchedulingPreemptionNoticeDuration;
}
export declare function computeInstanceFromTemplateSchedulingToTerraform(struct?: ComputeInstanceFromTemplateSchedulingOutputReference | ComputeInstanceFromTemplateScheduling): any;
export declare function computeInstanceFromTemplateSchedulingToHclTerraform(struct?: ComputeInstanceFromTemplateSchedulingOutputReference | ComputeInstanceFromTemplateScheduling): any;
export declare class ComputeInstanceFromTemplateSchedulingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceFromTemplateScheduling | undefined;
    set internalValue(value: ComputeInstanceFromTemplateScheduling | undefined);
    private _automaticRestart?;
    get automaticRestart(): boolean | cdktn.IResolvable;
    set automaticRestart(value: boolean | cdktn.IResolvable);
    resetAutomaticRestart(): void;
    get automaticRestartInput(): boolean | cdktn.IResolvable | undefined;
    private _availabilityDomain?;
    get availabilityDomain(): number;
    set availabilityDomain(value: number);
    resetAvailabilityDomain(): void;
    get availabilityDomainInput(): number | undefined;
    private _hostErrorTimeoutSeconds?;
    get hostErrorTimeoutSeconds(): number;
    set hostErrorTimeoutSeconds(value: number);
    resetHostErrorTimeoutSeconds(): void;
    get hostErrorTimeoutSecondsInput(): number | undefined;
    private _instanceTerminationAction?;
    get instanceTerminationAction(): string;
    set instanceTerminationAction(value: string);
    resetInstanceTerminationAction(): void;
    get instanceTerminationActionInput(): string | undefined;
    private _minNodeCpus?;
    get minNodeCpus(): number;
    set minNodeCpus(value: number);
    resetMinNodeCpus(): void;
    get minNodeCpusInput(): number | undefined;
    private _onHostMaintenance?;
    get onHostMaintenance(): string;
    set onHostMaintenance(value: string);
    resetOnHostMaintenance(): void;
    get onHostMaintenanceInput(): string | undefined;
    private _preemptible?;
    get preemptible(): boolean | cdktn.IResolvable;
    set preemptible(value: boolean | cdktn.IResolvable);
    resetPreemptible(): void;
    get preemptibleInput(): boolean | cdktn.IResolvable | undefined;
    private _provisioningModel?;
    get provisioningModel(): string;
    set provisioningModel(value: string);
    resetProvisioningModel(): void;
    get provisioningModelInput(): string | undefined;
    private _terminationTime?;
    get terminationTime(): string;
    set terminationTime(value: string);
    resetTerminationTime(): void;
    get terminationTimeInput(): string | undefined;
    private _localSsdRecoveryTimeout;
    get localSsdRecoveryTimeout(): ComputeInstanceFromTemplateSchedulingLocalSsdRecoveryTimeoutOutputReference;
    putLocalSsdRecoveryTimeout(value: ComputeInstanceFromTemplateSchedulingLocalSsdRecoveryTimeout): void;
    resetLocalSsdRecoveryTimeout(): void;
    get localSsdRecoveryTimeoutInput(): ComputeInstanceFromTemplateSchedulingLocalSsdRecoveryTimeout | undefined;
    private _maxRunDuration;
    get maxRunDuration(): ComputeInstanceFromTemplateSchedulingMaxRunDurationOutputReference;
    putMaxRunDuration(value: ComputeInstanceFromTemplateSchedulingMaxRunDuration): void;
    resetMaxRunDuration(): void;
    get maxRunDurationInput(): ComputeInstanceFromTemplateSchedulingMaxRunDuration | undefined;
    private _nodeAffinities;
    get nodeAffinities(): ComputeInstanceFromTemplateSchedulingNodeAffinitiesList;
    putNodeAffinities(value: ComputeInstanceFromTemplateSchedulingNodeAffinities[] | cdktn.IResolvable): void;
    resetNodeAffinities(): void;
    get nodeAffinitiesInput(): cdktn.IResolvable | ComputeInstanceFromTemplateSchedulingNodeAffinities[] | undefined;
    private _onInstanceStopAction;
    get onInstanceStopAction(): ComputeInstanceFromTemplateSchedulingOnInstanceStopActionOutputReference;
    putOnInstanceStopAction(value: ComputeInstanceFromTemplateSchedulingOnInstanceStopAction): void;
    resetOnInstanceStopAction(): void;
    get onInstanceStopActionInput(): ComputeInstanceFromTemplateSchedulingOnInstanceStopAction | undefined;
    private _preemptionNoticeDuration;
    get preemptionNoticeDuration(): ComputeInstanceFromTemplateSchedulingPreemptionNoticeDurationOutputReference;
    putPreemptionNoticeDuration(value: ComputeInstanceFromTemplateSchedulingPreemptionNoticeDuration): void;
    resetPreemptionNoticeDuration(): void;
    get preemptionNoticeDurationInput(): ComputeInstanceFromTemplateSchedulingPreemptionNoticeDuration | undefined;
}
export interface ComputeInstanceFromTemplateScratchDisk {
    /**
    * Name with which the attached disk is accessible under /dev/disk/by-id/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#device_name ComputeInstanceFromTemplate#device_name}
    */
    readonly deviceName?: string;
    /**
    * The disk interface used for attaching this disk. One of SCSI or NVME.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#interface ComputeInstanceFromTemplate#interface}
    */
    readonly interface: string;
    /**
    * The size of the disk in gigabytes. One of 375 or 3000.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#size ComputeInstanceFromTemplate#size}
    */
    readonly size?: number;
}
export declare function computeInstanceFromTemplateScratchDiskToTerraform(struct?: ComputeInstanceFromTemplateScratchDisk | cdktn.IResolvable): any;
export declare function computeInstanceFromTemplateScratchDiskToHclTerraform(struct?: ComputeInstanceFromTemplateScratchDisk | cdktn.IResolvable): any;
export declare class ComputeInstanceFromTemplateScratchDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceFromTemplateScratchDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInstanceFromTemplateScratchDisk | cdktn.IResolvable | undefined);
    private _deviceName?;
    get deviceName(): string;
    set deviceName(value: string);
    resetDeviceName(): void;
    get deviceNameInput(): string | undefined;
    private _interface?;
    get interface(): string;
    set interface(value: string);
    get interfaceInput(): string | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    resetSize(): void;
    get sizeInput(): number | undefined;
}
export declare class ComputeInstanceFromTemplateScratchDiskList extends cdktn.ComplexList {
    internalValue?: ComputeInstanceFromTemplateScratchDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceFromTemplateScratchDiskOutputReference;
}
export interface ComputeInstanceFromTemplateServiceAccount {
    /**
    * The service account e-mail address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#email ComputeInstanceFromTemplate#email}
    */
    readonly email?: string;
    /**
    * A list of service scopes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#scopes ComputeInstanceFromTemplate#scopes}
    */
    readonly scopes: string[];
}
export declare function computeInstanceFromTemplateServiceAccountToTerraform(struct?: ComputeInstanceFromTemplateServiceAccountOutputReference | ComputeInstanceFromTemplateServiceAccount): any;
export declare function computeInstanceFromTemplateServiceAccountToHclTerraform(struct?: ComputeInstanceFromTemplateServiceAccountOutputReference | ComputeInstanceFromTemplateServiceAccount): any;
export declare class ComputeInstanceFromTemplateServiceAccountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceFromTemplateServiceAccount | undefined;
    set internalValue(value: ComputeInstanceFromTemplateServiceAccount | undefined);
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    get scopesInput(): string[] | undefined;
}
export interface ComputeInstanceFromTemplateShieldedInstanceConfig {
    /**
    * Whether integrity monitoring is enabled for the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#enable_integrity_monitoring ComputeInstanceFromTemplate#enable_integrity_monitoring}
    */
    readonly enableIntegrityMonitoring?: boolean | cdktn.IResolvable;
    /**
    * Whether secure boot is enabled for the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#enable_secure_boot ComputeInstanceFromTemplate#enable_secure_boot}
    */
    readonly enableSecureBoot?: boolean | cdktn.IResolvable;
    /**
    * Whether the instance uses vTPM.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#enable_vtpm ComputeInstanceFromTemplate#enable_vtpm}
    */
    readonly enableVtpm?: boolean | cdktn.IResolvable;
}
export declare function computeInstanceFromTemplateShieldedInstanceConfigToTerraform(struct?: ComputeInstanceFromTemplateShieldedInstanceConfigOutputReference | ComputeInstanceFromTemplateShieldedInstanceConfig): any;
export declare function computeInstanceFromTemplateShieldedInstanceConfigToHclTerraform(struct?: ComputeInstanceFromTemplateShieldedInstanceConfigOutputReference | ComputeInstanceFromTemplateShieldedInstanceConfig): any;
export declare class ComputeInstanceFromTemplateShieldedInstanceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceFromTemplateShieldedInstanceConfig | undefined;
    set internalValue(value: ComputeInstanceFromTemplateShieldedInstanceConfig | undefined);
    private _enableIntegrityMonitoring?;
    get enableIntegrityMonitoring(): boolean | cdktn.IResolvable;
    set enableIntegrityMonitoring(value: boolean | cdktn.IResolvable);
    resetEnableIntegrityMonitoring(): void;
    get enableIntegrityMonitoringInput(): boolean | cdktn.IResolvable | undefined;
    private _enableSecureBoot?;
    get enableSecureBoot(): boolean | cdktn.IResolvable;
    set enableSecureBoot(value: boolean | cdktn.IResolvable);
    resetEnableSecureBoot(): void;
    get enableSecureBootInput(): boolean | cdktn.IResolvable | undefined;
    private _enableVtpm?;
    get enableVtpm(): boolean | cdktn.IResolvable;
    set enableVtpm(value: boolean | cdktn.IResolvable);
    resetEnableVtpm(): void;
    get enableVtpmInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ComputeInstanceFromTemplateTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#create ComputeInstanceFromTemplate#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#delete ComputeInstanceFromTemplate#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#update ComputeInstanceFromTemplate#update}
    */
    readonly update?: string;
}
export declare function computeInstanceFromTemplateTimeoutsToTerraform(struct?: ComputeInstanceFromTemplateTimeouts | cdktn.IResolvable): any;
export declare function computeInstanceFromTemplateTimeoutsToHclTerraform(struct?: ComputeInstanceFromTemplateTimeouts | cdktn.IResolvable): any;
export declare class ComputeInstanceFromTemplateTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceFromTemplateTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInstanceFromTemplateTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface ComputeInstanceFromTemplateWorkloadIdentityConfig {
    /**
    * Identity SPIFFE id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#identity ComputeInstanceFromTemplate#identity}
    */
    readonly identity?: string;
    /**
    * Specifies whether identity certificates are enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#identity_certificate_enabled ComputeInstanceFromTemplate#identity_certificate_enabled}
    */
    readonly identityCertificateEnabled?: boolean | cdktn.IResolvable;
}
export declare function computeInstanceFromTemplateWorkloadIdentityConfigToTerraform(struct?: ComputeInstanceFromTemplateWorkloadIdentityConfigOutputReference | ComputeInstanceFromTemplateWorkloadIdentityConfig): any;
export declare function computeInstanceFromTemplateWorkloadIdentityConfigToHclTerraform(struct?: ComputeInstanceFromTemplateWorkloadIdentityConfigOutputReference | ComputeInstanceFromTemplateWorkloadIdentityConfig): any;
export declare class ComputeInstanceFromTemplateWorkloadIdentityConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceFromTemplateWorkloadIdentityConfig | undefined;
    set internalValue(value: ComputeInstanceFromTemplateWorkloadIdentityConfig | undefined);
    private _identity?;
    get identity(): string;
    set identity(value: string);
    resetIdentity(): void;
    get identityInput(): string | undefined;
    private _identityCertificateEnabled?;
    get identityCertificateEnabled(): boolean | cdktn.IResolvable;
    set identityCertificateEnabled(value: boolean | cdktn.IResolvable);
    resetIdentityCertificateEnabled(): void;
    get identityCertificateEnabledInput(): boolean | cdktn.IResolvable | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template google_compute_instance_from_template}
*/
export declare class ComputeInstanceFromTemplate extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_instance_from_template";
    /**
    * Generates CDKTN code for importing a ComputeInstanceFromTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeInstanceFromTemplate to import
    * @param importFromId The id of the existing ComputeInstanceFromTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeInstanceFromTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_instance_from_template google_compute_instance_from_template} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeInstanceFromTemplateConfig
    */
    constructor(scope: Construct, id: string, config: ComputeInstanceFromTemplateConfig);
    private _allowStoppingForUpdate?;
    get allowStoppingForUpdate(): boolean | cdktn.IResolvable;
    set allowStoppingForUpdate(value: boolean | cdktn.IResolvable);
    resetAllowStoppingForUpdate(): void;
    get allowStoppingForUpdateInput(): boolean | cdktn.IResolvable | undefined;
    private _canIpForward?;
    get canIpForward(): boolean | cdktn.IResolvable;
    set canIpForward(value: boolean | cdktn.IResolvable);
    resetCanIpForward(): void;
    get canIpForwardInput(): boolean | cdktn.IResolvable | undefined;
    get cpuPlatform(): string;
    get creationTimestamp(): string;
    get currentStatus(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _deletionProtection?;
    get deletionProtection(): boolean | cdktn.IResolvable;
    set deletionProtection(value: boolean | cdktn.IResolvable);
    resetDeletionProtection(): void;
    get deletionProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _desiredStatus?;
    get desiredStatus(): string;
    set desiredStatus(value: string);
    resetDesiredStatus(): void;
    get desiredStatusInput(): string | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _enableDisplay?;
    get enableDisplay(): boolean | cdktn.IResolvable;
    set enableDisplay(value: boolean | cdktn.IResolvable);
    resetEnableDisplay(): void;
    get enableDisplayInput(): boolean | cdktn.IResolvable | undefined;
    private _hostname?;
    get hostname(): string;
    set hostname(value: string);
    resetHostname(): void;
    get hostnameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get instanceId(): string;
    private _keyRevocationActionType?;
    get keyRevocationActionType(): string;
    set keyRevocationActionType(value: string);
    resetKeyRevocationActionType(): void;
    get keyRevocationActionTypeInput(): string | undefined;
    get labelFingerprint(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _machineType?;
    get machineType(): string;
    set machineType(value: string);
    resetMachineType(): void;
    get machineTypeInput(): string | undefined;
    private _metadata?;
    get metadata(): {
        [key: string]: string;
    };
    set metadata(value: {
        [key: string]: string;
    });
    resetMetadata(): void;
    get metadataInput(): {
        [key: string]: string;
    } | undefined;
    get metadataFingerprint(): string;
    private _metadataStartupScript?;
    get metadataStartupScript(): string;
    set metadataStartupScript(value: string);
    resetMetadataStartupScript(): void;
    get metadataStartupScriptInput(): string | undefined;
    private _minCpuPlatform?;
    get minCpuPlatform(): string;
    set minCpuPlatform(value: string);
    resetMinCpuPlatform(): void;
    get minCpuPlatformInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _resourcePolicies?;
    get resourcePolicies(): string[];
    set resourcePolicies(value: string[]);
    resetResourcePolicies(): void;
    get resourcePoliciesInput(): string[] | undefined;
    get selfLink(): string;
    private _sourceInstanceTemplate?;
    get sourceInstanceTemplate(): string;
    set sourceInstanceTemplate(value: string);
    get sourceInstanceTemplateInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    get tagsFingerprint(): string;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    resetZone(): void;
    get zoneInput(): string | undefined;
    private _advancedMachineFeatures;
    get advancedMachineFeatures(): ComputeInstanceFromTemplateAdvancedMachineFeaturesOutputReference;
    putAdvancedMachineFeatures(value: ComputeInstanceFromTemplateAdvancedMachineFeatures): void;
    resetAdvancedMachineFeatures(): void;
    get advancedMachineFeaturesInput(): ComputeInstanceFromTemplateAdvancedMachineFeatures | undefined;
    private _attachedDisk;
    get attachedDisk(): ComputeInstanceFromTemplateAttachedDiskList;
    putAttachedDisk(value: ComputeInstanceFromTemplateAttachedDisk[] | cdktn.IResolvable): void;
    resetAttachedDisk(): void;
    get attachedDiskInput(): cdktn.IResolvable | ComputeInstanceFromTemplateAttachedDisk[] | undefined;
    private _bootDisk;
    get bootDisk(): ComputeInstanceFromTemplateBootDiskOutputReference;
    putBootDisk(value: ComputeInstanceFromTemplateBootDisk): void;
    resetBootDisk(): void;
    get bootDiskInput(): ComputeInstanceFromTemplateBootDisk | undefined;
    private _confidentialInstanceConfig;
    get confidentialInstanceConfig(): ComputeInstanceFromTemplateConfidentialInstanceConfigOutputReference;
    putConfidentialInstanceConfig(value: ComputeInstanceFromTemplateConfidentialInstanceConfig): void;
    resetConfidentialInstanceConfig(): void;
    get confidentialInstanceConfigInput(): ComputeInstanceFromTemplateConfidentialInstanceConfig | undefined;
    private _guestAccelerator;
    get guestAccelerator(): ComputeInstanceFromTemplateGuestAcceleratorList;
    putGuestAccelerator(value: ComputeInstanceFromTemplateGuestAccelerator[] | cdktn.IResolvable): void;
    resetGuestAccelerator(): void;
    get guestAcceleratorInput(): cdktn.IResolvable | ComputeInstanceFromTemplateGuestAccelerator[] | undefined;
    private _instanceEncryptionKey;
    get instanceEncryptionKey(): ComputeInstanceFromTemplateInstanceEncryptionKeyOutputReference;
    putInstanceEncryptionKey(value: ComputeInstanceFromTemplateInstanceEncryptionKey): void;
    resetInstanceEncryptionKey(): void;
    get instanceEncryptionKeyInput(): ComputeInstanceFromTemplateInstanceEncryptionKey | undefined;
    private _networkInterface;
    get networkInterface(): ComputeInstanceFromTemplateNetworkInterfaceList;
    putNetworkInterface(value: ComputeInstanceFromTemplateNetworkInterface[] | cdktn.IResolvable): void;
    resetNetworkInterface(): void;
    get networkInterfaceInput(): cdktn.IResolvable | ComputeInstanceFromTemplateNetworkInterface[] | undefined;
    private _networkPerformanceConfig;
    get networkPerformanceConfig(): ComputeInstanceFromTemplateNetworkPerformanceConfigOutputReference;
    putNetworkPerformanceConfig(value: ComputeInstanceFromTemplateNetworkPerformanceConfig): void;
    resetNetworkPerformanceConfig(): void;
    get networkPerformanceConfigInput(): ComputeInstanceFromTemplateNetworkPerformanceConfig | undefined;
    private _params;
    get params(): ComputeInstanceFromTemplateParamsOutputReference;
    putParams(value: ComputeInstanceFromTemplateParams): void;
    resetParams(): void;
    get paramsInput(): ComputeInstanceFromTemplateParams | undefined;
    private _reservationAffinity;
    get reservationAffinity(): ComputeInstanceFromTemplateReservationAffinityOutputReference;
    putReservationAffinity(value: ComputeInstanceFromTemplateReservationAffinity): void;
    resetReservationAffinity(): void;
    get reservationAffinityInput(): ComputeInstanceFromTemplateReservationAffinity | undefined;
    private _scheduling;
    get scheduling(): ComputeInstanceFromTemplateSchedulingOutputReference;
    putScheduling(value: ComputeInstanceFromTemplateScheduling): void;
    resetScheduling(): void;
    get schedulingInput(): ComputeInstanceFromTemplateScheduling | undefined;
    private _scratchDisk;
    get scratchDisk(): ComputeInstanceFromTemplateScratchDiskList;
    putScratchDisk(value: ComputeInstanceFromTemplateScratchDisk[] | cdktn.IResolvable): void;
    resetScratchDisk(): void;
    get scratchDiskInput(): cdktn.IResolvable | ComputeInstanceFromTemplateScratchDisk[] | undefined;
    private _serviceAccount;
    get serviceAccount(): ComputeInstanceFromTemplateServiceAccountOutputReference;
    putServiceAccount(value: ComputeInstanceFromTemplateServiceAccount): void;
    resetServiceAccount(): void;
    get serviceAccountInput(): ComputeInstanceFromTemplateServiceAccount | undefined;
    private _shieldedInstanceConfig;
    get shieldedInstanceConfig(): ComputeInstanceFromTemplateShieldedInstanceConfigOutputReference;
    putShieldedInstanceConfig(value: ComputeInstanceFromTemplateShieldedInstanceConfig): void;
    resetShieldedInstanceConfig(): void;
    get shieldedInstanceConfigInput(): ComputeInstanceFromTemplateShieldedInstanceConfig | undefined;
    private _timeouts;
    get timeouts(): ComputeInstanceFromTemplateTimeoutsOutputReference;
    putTimeouts(value: ComputeInstanceFromTemplateTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeInstanceFromTemplateTimeouts | undefined;
    private _workloadIdentityConfig;
    get workloadIdentityConfig(): ComputeInstanceFromTemplateWorkloadIdentityConfigOutputReference;
    putWorkloadIdentityConfig(value: ComputeInstanceFromTemplateWorkloadIdentityConfig): void;
    resetWorkloadIdentityConfig(): void;
    get workloadIdentityConfigInput(): ComputeInstanceFromTemplateWorkloadIdentityConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
