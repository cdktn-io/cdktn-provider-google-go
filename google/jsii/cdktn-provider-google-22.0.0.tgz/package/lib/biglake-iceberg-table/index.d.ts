/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BiglakeIcebergTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the IcebergCatalog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#catalog BiglakeIcebergTable#catalog}
    */
    readonly catalog: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#deletion_policy BiglakeIcebergTable#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#id BiglakeIcebergTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#location BiglakeIcebergTable#location}
    */
    readonly location?: string;
    /**
    * The name of the table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#name BiglakeIcebergTable#name}
    */
    readonly name: string;
    /**
    * The parent namespace of the table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#namespace BiglakeIcebergTable#namespace}
    */
    readonly namespace: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#project BiglakeIcebergTable#project}
    */
    readonly project?: string;
    /**
    * User-defined properties for the table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#properties BiglakeIcebergTable#properties}
    */
    readonly properties?: {
        [key: string]: string;
    };
    /**
    * partition_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#partition_spec BiglakeIcebergTable#partition_spec}
    */
    readonly partitionSpec?: BiglakeIcebergTablePartitionSpec;
    /**
    * schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#schema BiglakeIcebergTable#schema}
    */
    readonly schema: BiglakeIcebergTableSchema;
    /**
    * sort_order block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#sort_order BiglakeIcebergTable#sort_order}
    */
    readonly sortOrder?: BiglakeIcebergTableSortOrder;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#timeouts BiglakeIcebergTable#timeouts}
    */
    readonly timeouts?: BiglakeIcebergTableTimeouts;
}
export interface BiglakeIcebergTablePartitionSpecFields {
    /**
    * The name of the partition field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#name BiglakeIcebergTable#name}
    */
    readonly name: string;
    /**
    * The source field ID for the partition field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#source_id BiglakeIcebergTable#source_id}
    */
    readonly sourceId: number;
    /**
    * The transform to apply to the source field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#transform BiglakeIcebergTable#transform}
    */
    readonly transform: string;
}
export declare function biglakeIcebergTablePartitionSpecFieldsToTerraform(struct?: BiglakeIcebergTablePartitionSpecFields | cdktn.IResolvable): any;
export declare function biglakeIcebergTablePartitionSpecFieldsToHclTerraform(struct?: BiglakeIcebergTablePartitionSpecFields | cdktn.IResolvable): any;
export declare class BiglakeIcebergTablePartitionSpecFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BiglakeIcebergTablePartitionSpecFields | cdktn.IResolvable | undefined;
    set internalValue(value: BiglakeIcebergTablePartitionSpecFields | cdktn.IResolvable | undefined);
    get fieldId(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _sourceId?;
    get sourceId(): number;
    set sourceId(value: number);
    get sourceIdInput(): number | undefined;
    private _transform?;
    get transform(): string;
    set transform(value: string);
    get transformInput(): string | undefined;
}
export declare class BiglakeIcebergTablePartitionSpecFieldsList extends cdktn.ComplexList {
    internalValue?: BiglakeIcebergTablePartitionSpecFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BiglakeIcebergTablePartitionSpecFieldsOutputReference;
}
export interface BiglakeIcebergTablePartitionSpec {
    /**
    * fields block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#fields BiglakeIcebergTable#fields}
    */
    readonly fields: BiglakeIcebergTablePartitionSpecFields[] | cdktn.IResolvable;
}
export declare function biglakeIcebergTablePartitionSpecToTerraform(struct?: BiglakeIcebergTablePartitionSpecOutputReference | BiglakeIcebergTablePartitionSpec): any;
export declare function biglakeIcebergTablePartitionSpecToHclTerraform(struct?: BiglakeIcebergTablePartitionSpecOutputReference | BiglakeIcebergTablePartitionSpec): any;
export declare class BiglakeIcebergTablePartitionSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BiglakeIcebergTablePartitionSpec | undefined;
    set internalValue(value: BiglakeIcebergTablePartitionSpec | undefined);
    get specId(): number;
    private _fields;
    get fields(): BiglakeIcebergTablePartitionSpecFieldsList;
    putFields(value: BiglakeIcebergTablePartitionSpecFields[] | cdktn.IResolvable): void;
    get fieldsInput(): cdktn.IResolvable | BiglakeIcebergTablePartitionSpecFields[] | undefined;
}
export interface BiglakeIcebergTableSchemaFields {
    /**
    * A description of the field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#doc BiglakeIcebergTable#doc}
    */
    readonly doc?: string;
    /**
    * The unique identifier of the field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#id BiglakeIcebergTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: number;
    /**
    * The name of the field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#name BiglakeIcebergTable#name}
    */
    readonly name: string;
    /**
    * Whether the field is required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#required BiglakeIcebergTable#required}
    */
    readonly required: boolean | cdktn.IResolvable;
    /**
    * The type of the field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#type BiglakeIcebergTable#type}
    */
    readonly type: string;
}
export declare function biglakeIcebergTableSchemaFieldsToTerraform(struct?: BiglakeIcebergTableSchemaFields | cdktn.IResolvable): any;
export declare function biglakeIcebergTableSchemaFieldsToHclTerraform(struct?: BiglakeIcebergTableSchemaFields | cdktn.IResolvable): any;
export declare class BiglakeIcebergTableSchemaFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BiglakeIcebergTableSchemaFields | cdktn.IResolvable | undefined;
    set internalValue(value: BiglakeIcebergTableSchemaFields | cdktn.IResolvable | undefined);
    private _doc?;
    get doc(): string;
    set doc(value: string);
    resetDoc(): void;
    get docInput(): string | undefined;
    private _id?;
    get id(): number;
    set id(value: number);
    get idInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _required?;
    get required(): boolean | cdktn.IResolvable;
    set required(value: boolean | cdktn.IResolvable);
    get requiredInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BiglakeIcebergTableSchemaFieldsList extends cdktn.ComplexList {
    internalValue?: BiglakeIcebergTableSchemaFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BiglakeIcebergTableSchemaFieldsOutputReference;
}
export interface BiglakeIcebergTableSchema {
    /**
    * The field IDs that make up the identifier for the table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#identifier_field_ids BiglakeIcebergTable#identifier_field_ids}
    */
    readonly identifierFieldIds?: number[];
    /**
    * The type of the schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#type BiglakeIcebergTable#type}
    */
    readonly type?: string;
    /**
    * fields block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#fields BiglakeIcebergTable#fields}
    */
    readonly fields: BiglakeIcebergTableSchemaFields[] | cdktn.IResolvable;
}
export declare function biglakeIcebergTableSchemaToTerraform(struct?: BiglakeIcebergTableSchemaOutputReference | BiglakeIcebergTableSchema): any;
export declare function biglakeIcebergTableSchemaToHclTerraform(struct?: BiglakeIcebergTableSchemaOutputReference | BiglakeIcebergTableSchema): any;
export declare class BiglakeIcebergTableSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BiglakeIcebergTableSchema | undefined;
    set internalValue(value: BiglakeIcebergTableSchema | undefined);
    private _identifierFieldIds?;
    get identifierFieldIds(): number[];
    set identifierFieldIds(value: number[]);
    resetIdentifierFieldIds(): void;
    get identifierFieldIdsInput(): number[] | undefined;
    get schemaId(): number;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _fields;
    get fields(): BiglakeIcebergTableSchemaFieldsList;
    putFields(value: BiglakeIcebergTableSchemaFields[] | cdktn.IResolvable): void;
    get fieldsInput(): cdktn.IResolvable | BiglakeIcebergTableSchemaFields[] | undefined;
}
export interface BiglakeIcebergTableSortOrderFields {
    /**
    * The sort direction for the sort field. Possible values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#direction BiglakeIcebergTable#direction}
    */
    readonly direction: string;
    /**
    * The null ordering for the sort field. Possible values: "nulls-first", "nulls-last".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#null_order BiglakeIcebergTable#null_order}
    */
    readonly nullOrder: string;
    /**
    * The source field ID for the sort field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#source_id BiglakeIcebergTable#source_id}
    */
    readonly sourceId: number;
    /**
    * The transform to apply to the source field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#transform BiglakeIcebergTable#transform}
    */
    readonly transform: string;
}
export declare function biglakeIcebergTableSortOrderFieldsToTerraform(struct?: BiglakeIcebergTableSortOrderFields | cdktn.IResolvable): any;
export declare function biglakeIcebergTableSortOrderFieldsToHclTerraform(struct?: BiglakeIcebergTableSortOrderFields | cdktn.IResolvable): any;
export declare class BiglakeIcebergTableSortOrderFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BiglakeIcebergTableSortOrderFields | cdktn.IResolvable | undefined;
    set internalValue(value: BiglakeIcebergTableSortOrderFields | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    get directionInput(): string | undefined;
    private _nullOrder?;
    get nullOrder(): string;
    set nullOrder(value: string);
    get nullOrderInput(): string | undefined;
    private _sourceId?;
    get sourceId(): number;
    set sourceId(value: number);
    get sourceIdInput(): number | undefined;
    private _transform?;
    get transform(): string;
    set transform(value: string);
    get transformInput(): string | undefined;
}
export declare class BiglakeIcebergTableSortOrderFieldsList extends cdktn.ComplexList {
    internalValue?: BiglakeIcebergTableSortOrderFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BiglakeIcebergTableSortOrderFieldsOutputReference;
}
export interface BiglakeIcebergTableSortOrder {
    /**
    * fields block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#fields BiglakeIcebergTable#fields}
    */
    readonly fields: BiglakeIcebergTableSortOrderFields[] | cdktn.IResolvable;
}
export declare function biglakeIcebergTableSortOrderToTerraform(struct?: BiglakeIcebergTableSortOrderOutputReference | BiglakeIcebergTableSortOrder): any;
export declare function biglakeIcebergTableSortOrderToHclTerraform(struct?: BiglakeIcebergTableSortOrderOutputReference | BiglakeIcebergTableSortOrder): any;
export declare class BiglakeIcebergTableSortOrderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BiglakeIcebergTableSortOrder | undefined;
    set internalValue(value: BiglakeIcebergTableSortOrder | undefined);
    get orderId(): number;
    private _fields;
    get fields(): BiglakeIcebergTableSortOrderFieldsList;
    putFields(value: BiglakeIcebergTableSortOrderFields[] | cdktn.IResolvable): void;
    get fieldsInput(): cdktn.IResolvable | BiglakeIcebergTableSortOrderFields[] | undefined;
}
export interface BiglakeIcebergTableTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#create BiglakeIcebergTable#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#delete BiglakeIcebergTable#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#update BiglakeIcebergTable#update}
    */
    readonly update?: string;
}
export declare function biglakeIcebergTableTimeoutsToTerraform(struct?: BiglakeIcebergTableTimeouts | cdktn.IResolvable): any;
export declare function biglakeIcebergTableTimeoutsToHclTerraform(struct?: BiglakeIcebergTableTimeouts | cdktn.IResolvable): any;
export declare class BiglakeIcebergTableTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BiglakeIcebergTableTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BiglakeIcebergTableTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table google_biglake_iceberg_table}
*/
export declare class BiglakeIcebergTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_biglake_iceberg_table";
    /**
    * Generates CDKTN code for importing a BiglakeIcebergTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BiglakeIcebergTable to import
    * @param importFromId The id of the existing BiglakeIcebergTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BiglakeIcebergTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_table google_biglake_iceberg_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BiglakeIcebergTableConfig
    */
    constructor(scope: Construct, id: string, config: BiglakeIcebergTableConfig);
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    get catalogInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    get namespaceInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _properties?;
    get properties(): {
        [key: string]: string;
    };
    set properties(value: {
        [key: string]: string;
    });
    resetProperties(): void;
    get propertiesInput(): {
        [key: string]: string;
    } | undefined;
    private _partitionSpec;
    get partitionSpec(): BiglakeIcebergTablePartitionSpecOutputReference;
    putPartitionSpec(value: BiglakeIcebergTablePartitionSpec): void;
    resetPartitionSpec(): void;
    get partitionSpecInput(): BiglakeIcebergTablePartitionSpec | undefined;
    private _schema;
    get schema(): BiglakeIcebergTableSchemaOutputReference;
    putSchema(value: BiglakeIcebergTableSchema): void;
    get schemaInput(): BiglakeIcebergTableSchema | undefined;
    private _sortOrder;
    get sortOrder(): BiglakeIcebergTableSortOrderOutputReference;
    putSortOrder(value: BiglakeIcebergTableSortOrder): void;
    resetSortOrder(): void;
    get sortOrderInput(): BiglakeIcebergTableSortOrder | undefined;
    private _timeouts;
    get timeouts(): BiglakeIcebergTableTimeoutsOutputReference;
    putTimeouts(value: BiglakeIcebergTableTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BiglakeIcebergTableTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
