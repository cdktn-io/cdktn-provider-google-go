/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigeeDatastoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_datastore#deletion_policy ApigeeDatastore#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The display name for the datastore.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_datastore#display_name ApigeeDatastore#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_datastore#id ApigeeDatastore#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The Apigee Organization associated with the Apigee datastore,
    * in the format 'organizations/{{org_name}}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_datastore#org_id ApigeeDatastore#org_id}
    */
    readonly orgId: string;
    /**
    * The type of target for the datastore. Must be 'gcs' for Google
    * Cloud Storage or 'bigquery' for BigQuery.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_datastore#target_type ApigeeDatastore#target_type}
    */
    readonly targetType: string;
    /**
    * datastore_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_datastore#datastore_config ApigeeDatastore#datastore_config}
    */
    readonly datastoreConfig: ApigeeDatastoreDatastoreConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_datastore#timeouts ApigeeDatastore#timeouts}
    */
    readonly timeouts?: ApigeeDatastoreTimeouts;
}
export interface ApigeeDatastoreDatastoreConfig {
    /**
    * The name of the Cloud Storage bucket. Required for 'gcs' target type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_datastore#bucket_name ApigeeDatastore#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * The name of the BigQuery dataset. Required for 'bigquery' target type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_datastore#dataset_name ApigeeDatastore#dataset_name}
    */
    readonly datasetName?: string;
    /**
    * The path within the Cloud Storage bucket. Used for 'gcs' target type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_datastore#path ApigeeDatastore#path}
    */
    readonly path?: string;
    /**
    * The GCP project ID that the datastore target resides in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_datastore#project_id ApigeeDatastore#project_id}
    */
    readonly projectId: string;
    /**
    * The prefix for BigQuery table names. Used for 'bigquery' target type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_datastore#table_prefix ApigeeDatastore#table_prefix}
    */
    readonly tablePrefix?: string;
}
export declare function apigeeDatastoreDatastoreConfigToTerraform(struct?: ApigeeDatastoreDatastoreConfigOutputReference | ApigeeDatastoreDatastoreConfig): any;
export declare function apigeeDatastoreDatastoreConfigToHclTerraform(struct?: ApigeeDatastoreDatastoreConfigOutputReference | ApigeeDatastoreDatastoreConfig): any;
export declare class ApigeeDatastoreDatastoreConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeDatastoreDatastoreConfig | undefined;
    set internalValue(value: ApigeeDatastoreDatastoreConfig | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _datasetName?;
    get datasetName(): string;
    set datasetName(value: string);
    resetDatasetName(): void;
    get datasetNameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _tablePrefix?;
    get tablePrefix(): string;
    set tablePrefix(value: string);
    resetTablePrefix(): void;
    get tablePrefixInput(): string | undefined;
}
export interface ApigeeDatastoreTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_datastore#create ApigeeDatastore#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_datastore#delete ApigeeDatastore#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_datastore#update ApigeeDatastore#update}
    */
    readonly update?: string;
}
export declare function apigeeDatastoreTimeoutsToTerraform(struct?: ApigeeDatastoreTimeouts | cdktn.IResolvable): any;
export declare function apigeeDatastoreTimeoutsToHclTerraform(struct?: ApigeeDatastoreTimeouts | cdktn.IResolvable): any;
export declare class ApigeeDatastoreTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeDatastoreTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeDatastoreTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_datastore google_apigee_datastore}
*/
export declare class ApigeeDatastore extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apigee_datastore";
    /**
    * Generates CDKTN code for importing a ApigeeDatastore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigeeDatastore to import
    * @param importFromId The id of the existing ApigeeDatastore that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_datastore#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigeeDatastore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_datastore google_apigee_datastore} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigeeDatastoreConfig
    */
    constructor(scope: Construct, id: string, config: ApigeeDatastoreConfig);
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdateTime(): string;
    get name(): string;
    get org(): string;
    private _orgId?;
    get orgId(): string;
    set orgId(value: string);
    get orgIdInput(): string | undefined;
    get selfAttribute(): string;
    private _targetType?;
    get targetType(): string;
    set targetType(value: string);
    get targetTypeInput(): string | undefined;
    private _datastoreConfig;
    get datastoreConfig(): ApigeeDatastoreDatastoreConfigOutputReference;
    putDatastoreConfig(value: ApigeeDatastoreDatastoreConfig): void;
    get datastoreConfigInput(): ApigeeDatastoreDatastoreConfig | undefined;
    private _timeouts;
    get timeouts(): ApigeeDatastoreTimeoutsOutputReference;
    putTimeouts(value: ApigeeDatastoreTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApigeeDatastoreTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
