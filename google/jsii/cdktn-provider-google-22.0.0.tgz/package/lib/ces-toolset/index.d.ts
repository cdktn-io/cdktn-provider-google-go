/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CesToolsetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#app CesToolset#app}
    */
    readonly app: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#deletion_policy CesToolset#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The description of the toolset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#description CesToolset#description}
    */
    readonly description?: string;
    /**
    * The display name of the toolset. Must be unique within the same app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#display_name CesToolset#display_name}
    */
    readonly displayName?: string;
    /**
    * Possible values:
    * SYNCHRONOUS
    * ASYNCHRONOUS
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#execution_type CesToolset#execution_type}
    */
    readonly executionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#id CesToolset#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#location CesToolset#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#project CesToolset#project}
    */
    readonly project?: string;
    /**
    * The timeout for the toolset execution. If not set, the default timeout is
    * 30 seconds for 'SYNCHRONOUS' toolsets and 60 seconds for 'ASYNCHRONOUS'
    * toolsets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#timeout CesToolset#timeout}
    */
    readonly timeout?: string;
    /**
    * The ID to use for the toolset, which will become the final component of
    * the toolset's resource name. If not provided, a unique ID will be
    * automatically assigned for the toolset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#toolset_id CesToolset#toolset_id}
    */
    readonly toolsetId: string;
    /**
    * connector_toolset block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#connector_toolset CesToolset#connector_toolset}
    */
    readonly connectorToolset?: CesToolsetConnectorToolset;
    /**
    * mcp_toolset block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#mcp_toolset CesToolset#mcp_toolset}
    */
    readonly mcpToolset?: CesToolsetMcpToolset;
    /**
    * open_api_toolset block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#open_api_toolset CesToolset#open_api_toolset}
    */
    readonly openApiToolset?: CesToolsetOpenApiToolset;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#timeouts CesToolset#timeouts}
    */
    readonly timeouts?: CesToolsetTimeouts;
    /**
    * tool_fake_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#tool_fake_config CesToolset#tool_fake_config}
    */
    readonly toolFakeConfig?: CesToolsetToolFakeConfig;
}
export interface CesToolsetConnectorToolsetAuthConfigOauth2AuthCodeConfig {
    /**
    * Oauth token parameter name to pass through.
    * Must be in the format '$context.variables.<name_of_variable>'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#oauth_token CesToolset#oauth_token}
    */
    readonly oauthToken: string;
}
export declare function cesToolsetConnectorToolsetAuthConfigOauth2AuthCodeConfigToTerraform(struct?: CesToolsetConnectorToolsetAuthConfigOauth2AuthCodeConfigOutputReference | CesToolsetConnectorToolsetAuthConfigOauth2AuthCodeConfig): any;
export declare function cesToolsetConnectorToolsetAuthConfigOauth2AuthCodeConfigToHclTerraform(struct?: CesToolsetConnectorToolsetAuthConfigOauth2AuthCodeConfigOutputReference | CesToolsetConnectorToolsetAuthConfigOauth2AuthCodeConfig): any;
export declare class CesToolsetConnectorToolsetAuthConfigOauth2AuthCodeConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolsetConnectorToolsetAuthConfigOauth2AuthCodeConfig | undefined;
    set internalValue(value: CesToolsetConnectorToolsetAuthConfigOauth2AuthCodeConfig | undefined);
    private _oauthToken?;
    get oauthToken(): string;
    set oauthToken(value: string);
    get oauthTokenInput(): string | undefined;
}
export interface CesToolsetConnectorToolsetAuthConfigOauth2JwtBearerConfig {
    /**
    * Client parameter name to pass through.
    * Must be in the format '$context.variables.<name_of_variable>'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#client_key CesToolset#client_key}
    */
    readonly clientKey: string;
    /**
    * Issuer parameter name to pass through.
    * Must be in the format '$context.variables.<name_of_variable>'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#issuer CesToolset#issuer}
    */
    readonly issuer: string;
    /**
    * Subject parameter name to pass through.
    * Must be in the format '$context.variables.<name_of_variable>'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#subject CesToolset#subject}
    */
    readonly subject: string;
}
export declare function cesToolsetConnectorToolsetAuthConfigOauth2JwtBearerConfigToTerraform(struct?: CesToolsetConnectorToolsetAuthConfigOauth2JwtBearerConfigOutputReference | CesToolsetConnectorToolsetAuthConfigOauth2JwtBearerConfig): any;
export declare function cesToolsetConnectorToolsetAuthConfigOauth2JwtBearerConfigToHclTerraform(struct?: CesToolsetConnectorToolsetAuthConfigOauth2JwtBearerConfigOutputReference | CesToolsetConnectorToolsetAuthConfigOauth2JwtBearerConfig): any;
export declare class CesToolsetConnectorToolsetAuthConfigOauth2JwtBearerConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolsetConnectorToolsetAuthConfigOauth2JwtBearerConfig | undefined;
    set internalValue(value: CesToolsetConnectorToolsetAuthConfigOauth2JwtBearerConfig | undefined);
    private _clientKey?;
    get clientKey(): string;
    set clientKey(value: string);
    get clientKeyInput(): string | undefined;
    private _issuer?;
    get issuer(): string;
    set issuer(value: string);
    get issuerInput(): string | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
}
export interface CesToolsetConnectorToolsetAuthConfig {
    /**
    * oauth2_auth_code_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#oauth2_auth_code_config CesToolset#oauth2_auth_code_config}
    */
    readonly oauth2AuthCodeConfig?: CesToolsetConnectorToolsetAuthConfigOauth2AuthCodeConfig;
    /**
    * oauth2_jwt_bearer_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#oauth2_jwt_bearer_config CesToolset#oauth2_jwt_bearer_config}
    */
    readonly oauth2JwtBearerConfig?: CesToolsetConnectorToolsetAuthConfigOauth2JwtBearerConfig;
}
export declare function cesToolsetConnectorToolsetAuthConfigToTerraform(struct?: CesToolsetConnectorToolsetAuthConfigOutputReference | CesToolsetConnectorToolsetAuthConfig): any;
export declare function cesToolsetConnectorToolsetAuthConfigToHclTerraform(struct?: CesToolsetConnectorToolsetAuthConfigOutputReference | CesToolsetConnectorToolsetAuthConfig): any;
export declare class CesToolsetConnectorToolsetAuthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolsetConnectorToolsetAuthConfig | undefined;
    set internalValue(value: CesToolsetConnectorToolsetAuthConfig | undefined);
    private _oauth2AuthCodeConfig;
    get oauth2AuthCodeConfig(): CesToolsetConnectorToolsetAuthConfigOauth2AuthCodeConfigOutputReference;
    putOauth2AuthCodeConfig(value: CesToolsetConnectorToolsetAuthConfigOauth2AuthCodeConfig): void;
    resetOauth2AuthCodeConfig(): void;
    get oauth2AuthCodeConfigInput(): CesToolsetConnectorToolsetAuthConfigOauth2AuthCodeConfig | undefined;
    private _oauth2JwtBearerConfig;
    get oauth2JwtBearerConfig(): CesToolsetConnectorToolsetAuthConfigOauth2JwtBearerConfigOutputReference;
    putOauth2JwtBearerConfig(value: CesToolsetConnectorToolsetAuthConfigOauth2JwtBearerConfig): void;
    resetOauth2JwtBearerConfig(): void;
    get oauth2JwtBearerConfigInput(): CesToolsetConnectorToolsetAuthConfigOauth2JwtBearerConfig | undefined;
}
export interface CesToolsetConnectorToolsetConnectorActionsEntityOperation {
    /**
    * ID of the entity.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#entity_id CesToolset#entity_id}
    */
    readonly entityId: string;
    /**
    * Operation to perform on the entity.
    * Possible values:
    * LIST
    * GET
    * CREATE
    * UPDATE
    * DELETE
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#operation CesToolset#operation}
    */
    readonly operation: string;
}
export declare function cesToolsetConnectorToolsetConnectorActionsEntityOperationToTerraform(struct?: CesToolsetConnectorToolsetConnectorActionsEntityOperationOutputReference | CesToolsetConnectorToolsetConnectorActionsEntityOperation): any;
export declare function cesToolsetConnectorToolsetConnectorActionsEntityOperationToHclTerraform(struct?: CesToolsetConnectorToolsetConnectorActionsEntityOperationOutputReference | CesToolsetConnectorToolsetConnectorActionsEntityOperation): any;
export declare class CesToolsetConnectorToolsetConnectorActionsEntityOperationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolsetConnectorToolsetConnectorActionsEntityOperation | undefined;
    set internalValue(value: CesToolsetConnectorToolsetConnectorActionsEntityOperation | undefined);
    private _entityId?;
    get entityId(): string;
    set entityId(value: string);
    get entityIdInput(): string | undefined;
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
}
export interface CesToolsetConnectorToolsetConnectorActions {
    /**
    * ID of a Connection action for the tool to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#connection_action_id CesToolset#connection_action_id}
    */
    readonly connectionActionId?: string;
    /**
    * Entity fields to use as inputs for the operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#input_fields CesToolset#input_fields}
    */
    readonly inputFields?: string[];
    /**
    * Entity fields to return from the operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#output_fields CesToolset#output_fields}
    */
    readonly outputFields?: string[];
    /**
    * entity_operation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#entity_operation CesToolset#entity_operation}
    */
    readonly entityOperation?: CesToolsetConnectorToolsetConnectorActionsEntityOperation;
}
export declare function cesToolsetConnectorToolsetConnectorActionsToTerraform(struct?: CesToolsetConnectorToolsetConnectorActions | cdktn.IResolvable): any;
export declare function cesToolsetConnectorToolsetConnectorActionsToHclTerraform(struct?: CesToolsetConnectorToolsetConnectorActions | cdktn.IResolvable): any;
export declare class CesToolsetConnectorToolsetConnectorActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolsetConnectorToolsetConnectorActions | cdktn.IResolvable | undefined;
    set internalValue(value: CesToolsetConnectorToolsetConnectorActions | cdktn.IResolvable | undefined);
    private _connectionActionId?;
    get connectionActionId(): string;
    set connectionActionId(value: string);
    resetConnectionActionId(): void;
    get connectionActionIdInput(): string | undefined;
    private _inputFields?;
    get inputFields(): string[];
    set inputFields(value: string[]);
    resetInputFields(): void;
    get inputFieldsInput(): string[] | undefined;
    private _outputFields?;
    get outputFields(): string[];
    set outputFields(value: string[]);
    resetOutputFields(): void;
    get outputFieldsInput(): string[] | undefined;
    private _entityOperation;
    get entityOperation(): CesToolsetConnectorToolsetConnectorActionsEntityOperationOutputReference;
    putEntityOperation(value: CesToolsetConnectorToolsetConnectorActionsEntityOperation): void;
    resetEntityOperation(): void;
    get entityOperationInput(): CesToolsetConnectorToolsetConnectorActionsEntityOperation | undefined;
}
export declare class CesToolsetConnectorToolsetConnectorActionsList extends cdktn.ComplexList {
    internalValue?: CesToolsetConnectorToolsetConnectorActions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolsetConnectorToolsetConnectorActionsOutputReference;
}
export interface CesToolsetConnectorToolset {
    /**
    * The full resource name of the referenced Integration Connectors
    * Connection.
    * Format:
    * 'projects/{project}/locations/{location}/connections/{connection}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#connection CesToolset#connection}
    */
    readonly connection: string;
    /**
    * auth_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#auth_config CesToolset#auth_config}
    */
    readonly authConfig?: CesToolsetConnectorToolsetAuthConfig;
    /**
    * connector_actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#connector_actions CesToolset#connector_actions}
    */
    readonly connectorActions: CesToolsetConnectorToolsetConnectorActions[] | cdktn.IResolvable;
}
export declare function cesToolsetConnectorToolsetToTerraform(struct?: CesToolsetConnectorToolsetOutputReference | CesToolsetConnectorToolset): any;
export declare function cesToolsetConnectorToolsetToHclTerraform(struct?: CesToolsetConnectorToolsetOutputReference | CesToolsetConnectorToolset): any;
export declare class CesToolsetConnectorToolsetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolsetConnectorToolset | undefined;
    set internalValue(value: CesToolsetConnectorToolset | undefined);
    private _connection?;
    get connection(): string;
    set connection(value: string);
    get connectionInput(): string | undefined;
    private _authConfig;
    get authConfig(): CesToolsetConnectorToolsetAuthConfigOutputReference;
    putAuthConfig(value: CesToolsetConnectorToolsetAuthConfig): void;
    resetAuthConfig(): void;
    get authConfigInput(): CesToolsetConnectorToolsetAuthConfig | undefined;
    private _connectorActions;
    get connectorActions(): CesToolsetConnectorToolsetConnectorActionsList;
    putConnectorActions(value: CesToolsetConnectorToolsetConnectorActions[] | cdktn.IResolvable): void;
    get connectorActionsInput(): cdktn.IResolvable | CesToolsetConnectorToolsetConnectorActions[] | undefined;
}
export interface CesToolsetMcpToolsetApiAuthenticationApiKeyConfig {
    /**
    * The name of the SecretManager secret version resource storing the API key.
    * Format: 'projects/{project}/secrets/{secret}/versions/{version}'
    * Note: You should grant 'roles/secretmanager.secretAccessor' role to the CES
    * service agent
    * 'service-@gcp-sa-ces.iam.gserviceaccount.com'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#api_key_secret_version CesToolset#api_key_secret_version}
    */
    readonly apiKeySecretVersion: string;
    /**
    * The parameter name or the header name of the API key.
    * E.g., If the API request is "https://example.com/act?X-Api-Key=", "X-Api-Key" would be the parameter name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#key_name CesToolset#key_name}
    */
    readonly keyName: string;
    /**
    * Key location in the request. For API key auth on MCP toolsets,
    * the API key can only be sent in the request header.
    * Possible values:
    * HEADER
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#request_location CesToolset#request_location}
    */
    readonly requestLocation: string;
}
export declare function cesToolsetMcpToolsetApiAuthenticationApiKeyConfigToTerraform(struct?: CesToolsetMcpToolsetApiAuthenticationApiKeyConfigOutputReference | CesToolsetMcpToolsetApiAuthenticationApiKeyConfig): any;
export declare function cesToolsetMcpToolsetApiAuthenticationApiKeyConfigToHclTerraform(struct?: CesToolsetMcpToolsetApiAuthenticationApiKeyConfigOutputReference | CesToolsetMcpToolsetApiAuthenticationApiKeyConfig): any;
export declare class CesToolsetMcpToolsetApiAuthenticationApiKeyConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolsetMcpToolsetApiAuthenticationApiKeyConfig | undefined;
    set internalValue(value: CesToolsetMcpToolsetApiAuthenticationApiKeyConfig | undefined);
    private _apiKeySecretVersion?;
    get apiKeySecretVersion(): string;
    set apiKeySecretVersion(value: string);
    get apiKeySecretVersionInput(): string | undefined;
    private _keyName?;
    get keyName(): string;
    set keyName(value: string);
    get keyNameInput(): string | undefined;
    private _requestLocation?;
    get requestLocation(): string;
    set requestLocation(value: string);
    get requestLocationInput(): string | undefined;
}
export interface CesToolsetMcpToolsetApiAuthenticationBearerTokenConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#token CesToolset#token}
    */
    readonly token?: string;
}
export declare function cesToolsetMcpToolsetApiAuthenticationBearerTokenConfigToTerraform(struct?: CesToolsetMcpToolsetApiAuthenticationBearerTokenConfigOutputReference | CesToolsetMcpToolsetApiAuthenticationBearerTokenConfig): any;
export declare function cesToolsetMcpToolsetApiAuthenticationBearerTokenConfigToHclTerraform(struct?: CesToolsetMcpToolsetApiAuthenticationBearerTokenConfigOutputReference | CesToolsetMcpToolsetApiAuthenticationBearerTokenConfig): any;
export declare class CesToolsetMcpToolsetApiAuthenticationBearerTokenConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolsetMcpToolsetApiAuthenticationBearerTokenConfig | undefined;
    set internalValue(value: CesToolsetMcpToolsetApiAuthenticationBearerTokenConfig | undefined);
    private _token?;
    get token(): string;
    set token(value: string);
    resetToken(): void;
    get tokenInput(): string | undefined;
}
export interface CesToolsetMcpToolsetApiAuthenticationOauthConfig {
    /**
    * The client ID from the OAuth provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#client_id CesToolset#client_id}
    */
    readonly clientId: string;
    /**
    * The name of the SecretManager secret version resource storing the
    * client secret.
    * Format: 'projects/{project}/secrets/{secret}/versions/{version}'
    *
    * Note: You should grant 'roles/secretmanager.secretAccessor' role to the CES
    * service agent
    * 'service-@gcp-sa-ces.iam.gserviceaccount.com'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#client_secret_version CesToolset#client_secret_version}
    */
    readonly clientSecretVersion: string;
    /**
    * OAuth grant types.
    * Possible values:
    * CLIENT_CREDENTIAL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#oauth_grant_type CesToolset#oauth_grant_type}
    */
    readonly oauthGrantType: string;
    /**
    * The OAuth scopes to grant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#scopes CesToolset#scopes}
    */
    readonly scopes?: string[];
    /**
    * The token endpoint in the OAuth provider to exchange for an access token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#token_endpoint CesToolset#token_endpoint}
    */
    readonly tokenEndpoint: string;
}
export declare function cesToolsetMcpToolsetApiAuthenticationOauthConfigToTerraform(struct?: CesToolsetMcpToolsetApiAuthenticationOauthConfigOutputReference | CesToolsetMcpToolsetApiAuthenticationOauthConfig): any;
export declare function cesToolsetMcpToolsetApiAuthenticationOauthConfigToHclTerraform(struct?: CesToolsetMcpToolsetApiAuthenticationOauthConfigOutputReference | CesToolsetMcpToolsetApiAuthenticationOauthConfig): any;
export declare class CesToolsetMcpToolsetApiAuthenticationOauthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolsetMcpToolsetApiAuthenticationOauthConfig | undefined;
    set internalValue(value: CesToolsetMcpToolsetApiAuthenticationOauthConfig | undefined);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    get clientIdInput(): string | undefined;
    private _clientSecretVersion?;
    get clientSecretVersion(): string;
    set clientSecretVersion(value: string);
    get clientSecretVersionInput(): string | undefined;
    private _oauthGrantType?;
    get oauthGrantType(): string;
    set oauthGrantType(value: string);
    get oauthGrantTypeInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
    private _tokenEndpoint?;
    get tokenEndpoint(): string;
    set tokenEndpoint(value: string);
    get tokenEndpointInput(): string | undefined;
}
export interface CesToolsetMcpToolsetApiAuthenticationServiceAccountAuthConfig {
    /**
    * The OAuth scopes to grant. If not specified, the default scope
    * 'https://www.googleapis.com/auth/cloud-platform' is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#scopes CesToolset#scopes}
    */
    readonly scopes?: string[];
    /**
    * The email address of the service account used for authenticatation. CES
    * uses this service account to exchange an access token and the access token
    * is then sent in the 'Authorization' header of the request.
    *
    * The service account must have the
    * 'roles/iam.serviceAccountTokenCreator' role granted to the
    * CES service agent
    * 'service-@gcp-sa-ces.iam.gserviceaccount.com'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#service_account CesToolset#service_account}
    */
    readonly serviceAccount: string;
}
export declare function cesToolsetMcpToolsetApiAuthenticationServiceAccountAuthConfigToTerraform(struct?: CesToolsetMcpToolsetApiAuthenticationServiceAccountAuthConfigOutputReference | CesToolsetMcpToolsetApiAuthenticationServiceAccountAuthConfig): any;
export declare function cesToolsetMcpToolsetApiAuthenticationServiceAccountAuthConfigToHclTerraform(struct?: CesToolsetMcpToolsetApiAuthenticationServiceAccountAuthConfigOutputReference | CesToolsetMcpToolsetApiAuthenticationServiceAccountAuthConfig): any;
export declare class CesToolsetMcpToolsetApiAuthenticationServiceAccountAuthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolsetMcpToolsetApiAuthenticationServiceAccountAuthConfig | undefined;
    set internalValue(value: CesToolsetMcpToolsetApiAuthenticationServiceAccountAuthConfig | undefined);
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
    private _serviceAccount?;
    get serviceAccount(): string;
    set serviceAccount(value: string);
    get serviceAccountInput(): string | undefined;
}
export interface CesToolsetMcpToolsetApiAuthenticationServiceAgentIdTokenAuthConfig {
}
export declare function cesToolsetMcpToolsetApiAuthenticationServiceAgentIdTokenAuthConfigToTerraform(struct?: CesToolsetMcpToolsetApiAuthenticationServiceAgentIdTokenAuthConfigOutputReference | CesToolsetMcpToolsetApiAuthenticationServiceAgentIdTokenAuthConfig): any;
export declare function cesToolsetMcpToolsetApiAuthenticationServiceAgentIdTokenAuthConfigToHclTerraform(struct?: CesToolsetMcpToolsetApiAuthenticationServiceAgentIdTokenAuthConfigOutputReference | CesToolsetMcpToolsetApiAuthenticationServiceAgentIdTokenAuthConfig): any;
export declare class CesToolsetMcpToolsetApiAuthenticationServiceAgentIdTokenAuthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolsetMcpToolsetApiAuthenticationServiceAgentIdTokenAuthConfig | undefined;
    set internalValue(value: CesToolsetMcpToolsetApiAuthenticationServiceAgentIdTokenAuthConfig | undefined);
}
export interface CesToolsetMcpToolsetApiAuthentication {
    /**
    * api_key_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#api_key_config CesToolset#api_key_config}
    */
    readonly apiKeyConfig?: CesToolsetMcpToolsetApiAuthenticationApiKeyConfig;
    /**
    * bearer_token_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#bearer_token_config CesToolset#bearer_token_config}
    */
    readonly bearerTokenConfig?: CesToolsetMcpToolsetApiAuthenticationBearerTokenConfig;
    /**
    * oauth_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#oauth_config CesToolset#oauth_config}
    */
    readonly oauthConfig?: CesToolsetMcpToolsetApiAuthenticationOauthConfig;
    /**
    * service_account_auth_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#service_account_auth_config CesToolset#service_account_auth_config}
    */
    readonly serviceAccountAuthConfig?: CesToolsetMcpToolsetApiAuthenticationServiceAccountAuthConfig;
    /**
    * service_agent_id_token_auth_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#service_agent_id_token_auth_config CesToolset#service_agent_id_token_auth_config}
    */
    readonly serviceAgentIdTokenAuthConfig?: CesToolsetMcpToolsetApiAuthenticationServiceAgentIdTokenAuthConfig;
}
export declare function cesToolsetMcpToolsetApiAuthenticationToTerraform(struct?: CesToolsetMcpToolsetApiAuthenticationOutputReference | CesToolsetMcpToolsetApiAuthentication): any;
export declare function cesToolsetMcpToolsetApiAuthenticationToHclTerraform(struct?: CesToolsetMcpToolsetApiAuthenticationOutputReference | CesToolsetMcpToolsetApiAuthentication): any;
export declare class CesToolsetMcpToolsetApiAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolsetMcpToolsetApiAuthentication | undefined;
    set internalValue(value: CesToolsetMcpToolsetApiAuthentication | undefined);
    private _apiKeyConfig;
    get apiKeyConfig(): CesToolsetMcpToolsetApiAuthenticationApiKeyConfigOutputReference;
    putApiKeyConfig(value: CesToolsetMcpToolsetApiAuthenticationApiKeyConfig): void;
    resetApiKeyConfig(): void;
    get apiKeyConfigInput(): CesToolsetMcpToolsetApiAuthenticationApiKeyConfig | undefined;
    private _bearerTokenConfig;
    get bearerTokenConfig(): CesToolsetMcpToolsetApiAuthenticationBearerTokenConfigOutputReference;
    putBearerTokenConfig(value: CesToolsetMcpToolsetApiAuthenticationBearerTokenConfig): void;
    resetBearerTokenConfig(): void;
    get bearerTokenConfigInput(): CesToolsetMcpToolsetApiAuthenticationBearerTokenConfig | undefined;
    private _oauthConfig;
    get oauthConfig(): CesToolsetMcpToolsetApiAuthenticationOauthConfigOutputReference;
    putOauthConfig(value: CesToolsetMcpToolsetApiAuthenticationOauthConfig): void;
    resetOauthConfig(): void;
    get oauthConfigInput(): CesToolsetMcpToolsetApiAuthenticationOauthConfig | undefined;
    private _serviceAccountAuthConfig;
    get serviceAccountAuthConfig(): CesToolsetMcpToolsetApiAuthenticationServiceAccountAuthConfigOutputReference;
    putServiceAccountAuthConfig(value: CesToolsetMcpToolsetApiAuthenticationServiceAccountAuthConfig): void;
    resetServiceAccountAuthConfig(): void;
    get serviceAccountAuthConfigInput(): CesToolsetMcpToolsetApiAuthenticationServiceAccountAuthConfig | undefined;
    private _serviceAgentIdTokenAuthConfig;
    get serviceAgentIdTokenAuthConfig(): CesToolsetMcpToolsetApiAuthenticationServiceAgentIdTokenAuthConfigOutputReference;
    putServiceAgentIdTokenAuthConfig(value: CesToolsetMcpToolsetApiAuthenticationServiceAgentIdTokenAuthConfig): void;
    resetServiceAgentIdTokenAuthConfig(): void;
    get serviceAgentIdTokenAuthConfigInput(): CesToolsetMcpToolsetApiAuthenticationServiceAgentIdTokenAuthConfig | undefined;
}
export interface CesToolsetMcpToolsetServiceDirectoryConfig {
    /**
    * The name of [Service
    * Directory](https://cloud.google.com/service-directory) service.
    * Format:
    * 'projects/{project}/locations/{location}/namespaces/{namespace}/services/{service}'.
    * Location of the service directory must be the same as the location of the
    * app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#service CesToolset#service}
    */
    readonly service: string;
}
export declare function cesToolsetMcpToolsetServiceDirectoryConfigToTerraform(struct?: CesToolsetMcpToolsetServiceDirectoryConfigOutputReference | CesToolsetMcpToolsetServiceDirectoryConfig): any;
export declare function cesToolsetMcpToolsetServiceDirectoryConfigToHclTerraform(struct?: CesToolsetMcpToolsetServiceDirectoryConfigOutputReference | CesToolsetMcpToolsetServiceDirectoryConfig): any;
export declare class CesToolsetMcpToolsetServiceDirectoryConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolsetMcpToolsetServiceDirectoryConfig | undefined;
    set internalValue(value: CesToolsetMcpToolsetServiceDirectoryConfig | undefined);
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
}
export interface CesToolsetMcpToolsetTlsConfigCaCerts {
    /**
    * The allowed custom CA certificates (in DER format) for
    * HTTPS verification. This overrides the default SSL trust store. If this
    * is empty or unspecified, CES will use Google's default trust
    * store to verify certificates. N.B. Make sure the HTTPS server
    * certificates are signed with "subject alt name". For instance a
    * certificate can be self-signed using the following command,
    * openssl x509 -req -days 200 -in example.com.csr \
    * -signkey example.com.key \
    * -out example.com.crt \
    * -extfile <(printf "\nsubjectAltName='DNS:www.example.com'")
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#cert CesToolset#cert}
    */
    readonly cert: string;
    /**
    * The name of the allowed custom CA certificates. This
    * can be used to disambiguate the custom CA certificates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#display_name CesToolset#display_name}
    */
    readonly displayName: string;
}
export declare function cesToolsetMcpToolsetTlsConfigCaCertsToTerraform(struct?: CesToolsetMcpToolsetTlsConfigCaCerts | cdktn.IResolvable): any;
export declare function cesToolsetMcpToolsetTlsConfigCaCertsToHclTerraform(struct?: CesToolsetMcpToolsetTlsConfigCaCerts | cdktn.IResolvable): any;
export declare class CesToolsetMcpToolsetTlsConfigCaCertsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolsetMcpToolsetTlsConfigCaCerts | cdktn.IResolvable | undefined;
    set internalValue(value: CesToolsetMcpToolsetTlsConfigCaCerts | cdktn.IResolvable | undefined);
    private _cert?;
    get cert(): string;
    set cert(value: string);
    get certInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
}
export declare class CesToolsetMcpToolsetTlsConfigCaCertsList extends cdktn.ComplexList {
    internalValue?: CesToolsetMcpToolsetTlsConfigCaCerts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolsetMcpToolsetTlsConfigCaCertsOutputReference;
}
export interface CesToolsetMcpToolsetTlsConfig {
    /**
    * ca_certs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#ca_certs CesToolset#ca_certs}
    */
    readonly caCerts: CesToolsetMcpToolsetTlsConfigCaCerts[] | cdktn.IResolvable;
}
export declare function cesToolsetMcpToolsetTlsConfigToTerraform(struct?: CesToolsetMcpToolsetTlsConfigOutputReference | CesToolsetMcpToolsetTlsConfig): any;
export declare function cesToolsetMcpToolsetTlsConfigToHclTerraform(struct?: CesToolsetMcpToolsetTlsConfigOutputReference | CesToolsetMcpToolsetTlsConfig): any;
export declare class CesToolsetMcpToolsetTlsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolsetMcpToolsetTlsConfig | undefined;
    set internalValue(value: CesToolsetMcpToolsetTlsConfig | undefined);
    private _caCerts;
    get caCerts(): CesToolsetMcpToolsetTlsConfigCaCertsList;
    putCaCerts(value: CesToolsetMcpToolsetTlsConfigCaCerts[] | cdktn.IResolvable): void;
    get caCertsInput(): cdktn.IResolvable | CesToolsetMcpToolsetTlsConfigCaCerts[] | undefined;
}
export interface CesToolsetMcpToolsetToolOverrides {
    /**
    * The description override for the tool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#description_override CesToolset#description_override}
    */
    readonly descriptionOverride?: string;
    /**
    * The name override for the tool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#name_override CesToolset#name_override}
    */
    readonly nameOverride?: string;
    /**
    * The name of the tool to be overridden.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#tool CesToolset#tool}
    */
    readonly tool: string;
}
export declare function cesToolsetMcpToolsetToolOverridesToTerraform(struct?: CesToolsetMcpToolsetToolOverrides | cdktn.IResolvable): any;
export declare function cesToolsetMcpToolsetToolOverridesToHclTerraform(struct?: CesToolsetMcpToolsetToolOverrides | cdktn.IResolvable): any;
export declare class CesToolsetMcpToolsetToolOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolsetMcpToolsetToolOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: CesToolsetMcpToolsetToolOverrides | cdktn.IResolvable | undefined);
    private _descriptionOverride?;
    get descriptionOverride(): string;
    set descriptionOverride(value: string);
    resetDescriptionOverride(): void;
    get descriptionOverrideInput(): string | undefined;
    private _nameOverride?;
    get nameOverride(): string;
    set nameOverride(value: string);
    resetNameOverride(): void;
    get nameOverrideInput(): string | undefined;
    private _tool?;
    get tool(): string;
    set tool(value: string);
    get toolInput(): string | undefined;
}
export declare class CesToolsetMcpToolsetToolOverridesList extends cdktn.ComplexList {
    internalValue?: CesToolsetMcpToolsetToolOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolsetMcpToolsetToolOverridesOutputReference;
}
export interface CesToolsetMcpToolset {
    /**
    * The custom headers to send in the request to the MCP server. The values
    * must be in the format '$context.variables.<name_of_variable>' and can be
    * set in the session variables. See
    * https://docs.cloud.google.com/customer-engagement-ai/conversational-agents/ps/tool/open-api#openapi-injection
    * for more details.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#custom_headers CesToolset#custom_headers}
    */
    readonly customHeaders?: {
        [key: string]: string;
    };
    /**
    * The address of the MCP server, for example, "https://example.com/mcp/". If
    * the server is built with the MCP SDK, the url should be suffixed with
    * "/mcp/". Only Streamable HTTP transport based servers are supported. See
    * https://modelcontextprotocol.io/specification/2025-03-26/basic/transports#streamable-http
    * for more details.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#server_address CesToolset#server_address}
    */
    readonly serverAddress: string;
    /**
    * api_authentication block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#api_authentication CesToolset#api_authentication}
    */
    readonly apiAuthentication?: CesToolsetMcpToolsetApiAuthentication;
    /**
    * service_directory_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#service_directory_config CesToolset#service_directory_config}
    */
    readonly serviceDirectoryConfig?: CesToolsetMcpToolsetServiceDirectoryConfig;
    /**
    * tls_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#tls_config CesToolset#tls_config}
    */
    readonly tlsConfig?: CesToolsetMcpToolsetTlsConfig;
    /**
    * tool_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#tool_overrides CesToolset#tool_overrides}
    */
    readonly toolOverrides?: CesToolsetMcpToolsetToolOverrides[] | cdktn.IResolvable;
}
export declare function cesToolsetMcpToolsetToTerraform(struct?: CesToolsetMcpToolsetOutputReference | CesToolsetMcpToolset): any;
export declare function cesToolsetMcpToolsetToHclTerraform(struct?: CesToolsetMcpToolsetOutputReference | CesToolsetMcpToolset): any;
export declare class CesToolsetMcpToolsetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolsetMcpToolset | undefined;
    set internalValue(value: CesToolsetMcpToolset | undefined);
    private _customHeaders?;
    get customHeaders(): {
        [key: string]: string;
    };
    set customHeaders(value: {
        [key: string]: string;
    });
    resetCustomHeaders(): void;
    get customHeadersInput(): {
        [key: string]: string;
    } | undefined;
    private _serverAddress?;
    get serverAddress(): string;
    set serverAddress(value: string);
    get serverAddressInput(): string | undefined;
    private _apiAuthentication;
    get apiAuthentication(): CesToolsetMcpToolsetApiAuthenticationOutputReference;
    putApiAuthentication(value: CesToolsetMcpToolsetApiAuthentication): void;
    resetApiAuthentication(): void;
    get apiAuthenticationInput(): CesToolsetMcpToolsetApiAuthentication | undefined;
    private _serviceDirectoryConfig;
    get serviceDirectoryConfig(): CesToolsetMcpToolsetServiceDirectoryConfigOutputReference;
    putServiceDirectoryConfig(value: CesToolsetMcpToolsetServiceDirectoryConfig): void;
    resetServiceDirectoryConfig(): void;
    get serviceDirectoryConfigInput(): CesToolsetMcpToolsetServiceDirectoryConfig | undefined;
    private _tlsConfig;
    get tlsConfig(): CesToolsetMcpToolsetTlsConfigOutputReference;
    putTlsConfig(value: CesToolsetMcpToolsetTlsConfig): void;
    resetTlsConfig(): void;
    get tlsConfigInput(): CesToolsetMcpToolsetTlsConfig | undefined;
    private _toolOverrides;
    get toolOverrides(): CesToolsetMcpToolsetToolOverridesList;
    putToolOverrides(value: CesToolsetMcpToolsetToolOverrides[] | cdktn.IResolvable): void;
    resetToolOverrides(): void;
    get toolOverridesInput(): cdktn.IResolvable | CesToolsetMcpToolsetToolOverrides[] | undefined;
}
export interface CesToolsetOpenApiToolsetApiAuthenticationApiKeyConfig {
    /**
    * The name of the SecretManager secret version resource storing the API key.
    * Format: 'projects/{project}/secrets/{secret}/versions/{version}'
    * Note: You should grant 'roles/secretmanager.secretAccessor' role to the CES
    * service agent
    * 'service-@gcp-sa-ces.iam.gserviceaccount.com'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#api_key_secret_version CesToolset#api_key_secret_version}
    */
    readonly apiKeySecretVersion: string;
    /**
    * The parameter name or the header name of the API key.
    * E.g., If the API request is "https://example.com/act?X-Api-Key=", "X-Api-Key" would be the parameter name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#key_name CesToolset#key_name}
    */
    readonly keyName: string;
    /**
    * Key location in the request.
    * Possible values:
    * HEADER
    * QUERY_STRING
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#request_location CesToolset#request_location}
    */
    readonly requestLocation: string;
}
export declare function cesToolsetOpenApiToolsetApiAuthenticationApiKeyConfigToTerraform(struct?: CesToolsetOpenApiToolsetApiAuthenticationApiKeyConfigOutputReference | CesToolsetOpenApiToolsetApiAuthenticationApiKeyConfig): any;
export declare function cesToolsetOpenApiToolsetApiAuthenticationApiKeyConfigToHclTerraform(struct?: CesToolsetOpenApiToolsetApiAuthenticationApiKeyConfigOutputReference | CesToolsetOpenApiToolsetApiAuthenticationApiKeyConfig): any;
export declare class CesToolsetOpenApiToolsetApiAuthenticationApiKeyConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolsetOpenApiToolsetApiAuthenticationApiKeyConfig | undefined;
    set internalValue(value: CesToolsetOpenApiToolsetApiAuthenticationApiKeyConfig | undefined);
    private _apiKeySecretVersion?;
    get apiKeySecretVersion(): string;
    set apiKeySecretVersion(value: string);
    get apiKeySecretVersionInput(): string | undefined;
    private _keyName?;
    get keyName(): string;
    set keyName(value: string);
    get keyNameInput(): string | undefined;
    private _requestLocation?;
    get requestLocation(): string;
    set requestLocation(value: string);
    get requestLocationInput(): string | undefined;
}
export interface CesToolsetOpenApiToolsetApiAuthenticationBearerTokenConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#token CesToolset#token}
    */
    readonly token?: string;
}
export declare function cesToolsetOpenApiToolsetApiAuthenticationBearerTokenConfigToTerraform(struct?: CesToolsetOpenApiToolsetApiAuthenticationBearerTokenConfigOutputReference | CesToolsetOpenApiToolsetApiAuthenticationBearerTokenConfig): any;
export declare function cesToolsetOpenApiToolsetApiAuthenticationBearerTokenConfigToHclTerraform(struct?: CesToolsetOpenApiToolsetApiAuthenticationBearerTokenConfigOutputReference | CesToolsetOpenApiToolsetApiAuthenticationBearerTokenConfig): any;
export declare class CesToolsetOpenApiToolsetApiAuthenticationBearerTokenConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolsetOpenApiToolsetApiAuthenticationBearerTokenConfig | undefined;
    set internalValue(value: CesToolsetOpenApiToolsetApiAuthenticationBearerTokenConfig | undefined);
    private _token?;
    get token(): string;
    set token(value: string);
    resetToken(): void;
    get tokenInput(): string | undefined;
}
export interface CesToolsetOpenApiToolsetApiAuthenticationOauthConfig {
    /**
    * The client ID from the OAuth provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#client_id CesToolset#client_id}
    */
    readonly clientId: string;
    /**
    * The name of the SecretManager secret version resource storing the
    * client secret.
    * Format: 'projects/{project}/secrets/{secret}/versions/{version}'
    *
    * Note: You should grant 'roles/secretmanager.secretAccessor' role to the CES
    * service agent
    * 'service-@gcp-sa-ces.iam.gserviceaccount.com'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#client_secret_version CesToolset#client_secret_version}
    */
    readonly clientSecretVersion: string;
    /**
    * OAuth grant types.
    * Possible values:
    * CLIENT_CREDENTIAL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#oauth_grant_type CesToolset#oauth_grant_type}
    */
    readonly oauthGrantType: string;
    /**
    * The OAuth scopes to grant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#scopes CesToolset#scopes}
    */
    readonly scopes?: string[];
    /**
    * The token endpoint in the OAuth provider to exchange for an access token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#token_endpoint CesToolset#token_endpoint}
    */
    readonly tokenEndpoint: string;
}
export declare function cesToolsetOpenApiToolsetApiAuthenticationOauthConfigToTerraform(struct?: CesToolsetOpenApiToolsetApiAuthenticationOauthConfigOutputReference | CesToolsetOpenApiToolsetApiAuthenticationOauthConfig): any;
export declare function cesToolsetOpenApiToolsetApiAuthenticationOauthConfigToHclTerraform(struct?: CesToolsetOpenApiToolsetApiAuthenticationOauthConfigOutputReference | CesToolsetOpenApiToolsetApiAuthenticationOauthConfig): any;
export declare class CesToolsetOpenApiToolsetApiAuthenticationOauthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolsetOpenApiToolsetApiAuthenticationOauthConfig | undefined;
    set internalValue(value: CesToolsetOpenApiToolsetApiAuthenticationOauthConfig | undefined);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    get clientIdInput(): string | undefined;
    private _clientSecretVersion?;
    get clientSecretVersion(): string;
    set clientSecretVersion(value: string);
    get clientSecretVersionInput(): string | undefined;
    private _oauthGrantType?;
    get oauthGrantType(): string;
    set oauthGrantType(value: string);
    get oauthGrantTypeInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
    private _tokenEndpoint?;
    get tokenEndpoint(): string;
    set tokenEndpoint(value: string);
    get tokenEndpointInput(): string | undefined;
}
export interface CesToolsetOpenApiToolsetApiAuthenticationServiceAccountAuthConfig {
    /**
    * The OAuth scopes to grant. If not specified, the default scope
    * 'https://www.googleapis.com/auth/cloud-platform' is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#scopes CesToolset#scopes}
    */
    readonly scopes?: string[];
    /**
    * The email address of the service account used for authenticatation. CES
    * uses this service account to exchange an access token and the access token
    * is then sent in the 'Authorization' header of the request.
    *
    * The service account must have the
    * 'roles/iam.serviceAccountTokenCreator' role granted to the
    * CES service agent
    * 'service-@gcp-sa-ces.iam.gserviceaccount.com'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#service_account CesToolset#service_account}
    */
    readonly serviceAccount: string;
}
export declare function cesToolsetOpenApiToolsetApiAuthenticationServiceAccountAuthConfigToTerraform(struct?: CesToolsetOpenApiToolsetApiAuthenticationServiceAccountAuthConfigOutputReference | CesToolsetOpenApiToolsetApiAuthenticationServiceAccountAuthConfig): any;
export declare function cesToolsetOpenApiToolsetApiAuthenticationServiceAccountAuthConfigToHclTerraform(struct?: CesToolsetOpenApiToolsetApiAuthenticationServiceAccountAuthConfigOutputReference | CesToolsetOpenApiToolsetApiAuthenticationServiceAccountAuthConfig): any;
export declare class CesToolsetOpenApiToolsetApiAuthenticationServiceAccountAuthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolsetOpenApiToolsetApiAuthenticationServiceAccountAuthConfig | undefined;
    set internalValue(value: CesToolsetOpenApiToolsetApiAuthenticationServiceAccountAuthConfig | undefined);
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
    private _serviceAccount?;
    get serviceAccount(): string;
    set serviceAccount(value: string);
    get serviceAccountInput(): string | undefined;
}
export interface CesToolsetOpenApiToolsetApiAuthenticationServiceAgentIdTokenAuthConfig {
}
export declare function cesToolsetOpenApiToolsetApiAuthenticationServiceAgentIdTokenAuthConfigToTerraform(struct?: CesToolsetOpenApiToolsetApiAuthenticationServiceAgentIdTokenAuthConfigOutputReference | CesToolsetOpenApiToolsetApiAuthenticationServiceAgentIdTokenAuthConfig): any;
export declare function cesToolsetOpenApiToolsetApiAuthenticationServiceAgentIdTokenAuthConfigToHclTerraform(struct?: CesToolsetOpenApiToolsetApiAuthenticationServiceAgentIdTokenAuthConfigOutputReference | CesToolsetOpenApiToolsetApiAuthenticationServiceAgentIdTokenAuthConfig): any;
export declare class CesToolsetOpenApiToolsetApiAuthenticationServiceAgentIdTokenAuthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolsetOpenApiToolsetApiAuthenticationServiceAgentIdTokenAuthConfig | undefined;
    set internalValue(value: CesToolsetOpenApiToolsetApiAuthenticationServiceAgentIdTokenAuthConfig | undefined);
}
export interface CesToolsetOpenApiToolsetApiAuthentication {
    /**
    * api_key_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#api_key_config CesToolset#api_key_config}
    */
    readonly apiKeyConfig?: CesToolsetOpenApiToolsetApiAuthenticationApiKeyConfig;
    /**
    * bearer_token_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#bearer_token_config CesToolset#bearer_token_config}
    */
    readonly bearerTokenConfig?: CesToolsetOpenApiToolsetApiAuthenticationBearerTokenConfig;
    /**
    * oauth_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#oauth_config CesToolset#oauth_config}
    */
    readonly oauthConfig?: CesToolsetOpenApiToolsetApiAuthenticationOauthConfig;
    /**
    * service_account_auth_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#service_account_auth_config CesToolset#service_account_auth_config}
    */
    readonly serviceAccountAuthConfig?: CesToolsetOpenApiToolsetApiAuthenticationServiceAccountAuthConfig;
    /**
    * service_agent_id_token_auth_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#service_agent_id_token_auth_config CesToolset#service_agent_id_token_auth_config}
    */
    readonly serviceAgentIdTokenAuthConfig?: CesToolsetOpenApiToolsetApiAuthenticationServiceAgentIdTokenAuthConfig;
}
export declare function cesToolsetOpenApiToolsetApiAuthenticationToTerraform(struct?: CesToolsetOpenApiToolsetApiAuthenticationOutputReference | CesToolsetOpenApiToolsetApiAuthentication): any;
export declare function cesToolsetOpenApiToolsetApiAuthenticationToHclTerraform(struct?: CesToolsetOpenApiToolsetApiAuthenticationOutputReference | CesToolsetOpenApiToolsetApiAuthentication): any;
export declare class CesToolsetOpenApiToolsetApiAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolsetOpenApiToolsetApiAuthentication | undefined;
    set internalValue(value: CesToolsetOpenApiToolsetApiAuthentication | undefined);
    private _apiKeyConfig;
    get apiKeyConfig(): CesToolsetOpenApiToolsetApiAuthenticationApiKeyConfigOutputReference;
    putApiKeyConfig(value: CesToolsetOpenApiToolsetApiAuthenticationApiKeyConfig): void;
    resetApiKeyConfig(): void;
    get apiKeyConfigInput(): CesToolsetOpenApiToolsetApiAuthenticationApiKeyConfig | undefined;
    private _bearerTokenConfig;
    get bearerTokenConfig(): CesToolsetOpenApiToolsetApiAuthenticationBearerTokenConfigOutputReference;
    putBearerTokenConfig(value: CesToolsetOpenApiToolsetApiAuthenticationBearerTokenConfig): void;
    resetBearerTokenConfig(): void;
    get bearerTokenConfigInput(): CesToolsetOpenApiToolsetApiAuthenticationBearerTokenConfig | undefined;
    private _oauthConfig;
    get oauthConfig(): CesToolsetOpenApiToolsetApiAuthenticationOauthConfigOutputReference;
    putOauthConfig(value: CesToolsetOpenApiToolsetApiAuthenticationOauthConfig): void;
    resetOauthConfig(): void;
    get oauthConfigInput(): CesToolsetOpenApiToolsetApiAuthenticationOauthConfig | undefined;
    private _serviceAccountAuthConfig;
    get serviceAccountAuthConfig(): CesToolsetOpenApiToolsetApiAuthenticationServiceAccountAuthConfigOutputReference;
    putServiceAccountAuthConfig(value: CesToolsetOpenApiToolsetApiAuthenticationServiceAccountAuthConfig): void;
    resetServiceAccountAuthConfig(): void;
    get serviceAccountAuthConfigInput(): CesToolsetOpenApiToolsetApiAuthenticationServiceAccountAuthConfig | undefined;
    private _serviceAgentIdTokenAuthConfig;
    get serviceAgentIdTokenAuthConfig(): CesToolsetOpenApiToolsetApiAuthenticationServiceAgentIdTokenAuthConfigOutputReference;
    putServiceAgentIdTokenAuthConfig(value: CesToolsetOpenApiToolsetApiAuthenticationServiceAgentIdTokenAuthConfig): void;
    resetServiceAgentIdTokenAuthConfig(): void;
    get serviceAgentIdTokenAuthConfigInput(): CesToolsetOpenApiToolsetApiAuthenticationServiceAgentIdTokenAuthConfig | undefined;
}
export interface CesToolsetOpenApiToolsetServiceDirectoryConfig {
    /**
    * The name of [Service
    * Directory](https://cloud.google.com/service-directory) service.
    * Format:
    * 'projects/{project}/locations/{location}/namespaces/{namespace}/services/{service}'.
    * Location of the service directory must be the same as the location of the
    * app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#service CesToolset#service}
    */
    readonly service: string;
}
export declare function cesToolsetOpenApiToolsetServiceDirectoryConfigToTerraform(struct?: CesToolsetOpenApiToolsetServiceDirectoryConfigOutputReference | CesToolsetOpenApiToolsetServiceDirectoryConfig): any;
export declare function cesToolsetOpenApiToolsetServiceDirectoryConfigToHclTerraform(struct?: CesToolsetOpenApiToolsetServiceDirectoryConfigOutputReference | CesToolsetOpenApiToolsetServiceDirectoryConfig): any;
export declare class CesToolsetOpenApiToolsetServiceDirectoryConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolsetOpenApiToolsetServiceDirectoryConfig | undefined;
    set internalValue(value: CesToolsetOpenApiToolsetServiceDirectoryConfig | undefined);
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
}
export interface CesToolsetOpenApiToolsetTlsConfigCaCerts {
    /**
    * The allowed custom CA certificates (in DER format) for
    * HTTPS verification. This overrides the default SSL trust store. If this
    * is empty or unspecified, CES will use Google's default trust
    * store to verify certificates. N.B. Make sure the HTTPS server
    * certificates are signed with "subject alt name". For instance a
    * certificate can be self-signed using the following command,
    * openssl x509 -req -days 200 -in example.com.csr \
    * -signkey example.com.key \
    * -out example.com.crt \
    * -extfile <(printf "\nsubjectAltName='DNS:www.example.com'")
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#cert CesToolset#cert}
    */
    readonly cert: string;
    /**
    * The name of the allowed custom CA certificates. This
    * can be used to disambiguate the custom CA certificates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#display_name CesToolset#display_name}
    */
    readonly displayName: string;
}
export declare function cesToolsetOpenApiToolsetTlsConfigCaCertsToTerraform(struct?: CesToolsetOpenApiToolsetTlsConfigCaCerts | cdktn.IResolvable): any;
export declare function cesToolsetOpenApiToolsetTlsConfigCaCertsToHclTerraform(struct?: CesToolsetOpenApiToolsetTlsConfigCaCerts | cdktn.IResolvable): any;
export declare class CesToolsetOpenApiToolsetTlsConfigCaCertsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolsetOpenApiToolsetTlsConfigCaCerts | cdktn.IResolvable | undefined;
    set internalValue(value: CesToolsetOpenApiToolsetTlsConfigCaCerts | cdktn.IResolvable | undefined);
    private _cert?;
    get cert(): string;
    set cert(value: string);
    get certInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
}
export declare class CesToolsetOpenApiToolsetTlsConfigCaCertsList extends cdktn.ComplexList {
    internalValue?: CesToolsetOpenApiToolsetTlsConfigCaCerts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolsetOpenApiToolsetTlsConfigCaCertsOutputReference;
}
export interface CesToolsetOpenApiToolsetTlsConfig {
    /**
    * ca_certs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#ca_certs CesToolset#ca_certs}
    */
    readonly caCerts: CesToolsetOpenApiToolsetTlsConfigCaCerts[] | cdktn.IResolvable;
}
export declare function cesToolsetOpenApiToolsetTlsConfigToTerraform(struct?: CesToolsetOpenApiToolsetTlsConfigOutputReference | CesToolsetOpenApiToolsetTlsConfig): any;
export declare function cesToolsetOpenApiToolsetTlsConfigToHclTerraform(struct?: CesToolsetOpenApiToolsetTlsConfigOutputReference | CesToolsetOpenApiToolsetTlsConfig): any;
export declare class CesToolsetOpenApiToolsetTlsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolsetOpenApiToolsetTlsConfig | undefined;
    set internalValue(value: CesToolsetOpenApiToolsetTlsConfig | undefined);
    private _caCerts;
    get caCerts(): CesToolsetOpenApiToolsetTlsConfigCaCertsList;
    putCaCerts(value: CesToolsetOpenApiToolsetTlsConfigCaCerts[] | cdktn.IResolvable): void;
    get caCertsInput(): cdktn.IResolvable | CesToolsetOpenApiToolsetTlsConfigCaCerts[] | undefined;
}
export interface CesToolsetOpenApiToolset {
    /**
    * If true, the agent will ignore unknown fields in the API response for all
    * operations defined in the OpenAPI schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#ignore_unknown_fields CesToolset#ignore_unknown_fields}
    */
    readonly ignoreUnknownFields?: boolean | cdktn.IResolvable;
    /**
    * The OpenAPI schema of the toolset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#open_api_schema CesToolset#open_api_schema}
    */
    readonly openApiSchema: string;
    /**
    * api_authentication block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#api_authentication CesToolset#api_authentication}
    */
    readonly apiAuthentication?: CesToolsetOpenApiToolsetApiAuthentication;
    /**
    * service_directory_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#service_directory_config CesToolset#service_directory_config}
    */
    readonly serviceDirectoryConfig?: CesToolsetOpenApiToolsetServiceDirectoryConfig;
    /**
    * tls_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#tls_config CesToolset#tls_config}
    */
    readonly tlsConfig?: CesToolsetOpenApiToolsetTlsConfig;
}
export declare function cesToolsetOpenApiToolsetToTerraform(struct?: CesToolsetOpenApiToolsetOutputReference | CesToolsetOpenApiToolset): any;
export declare function cesToolsetOpenApiToolsetToHclTerraform(struct?: CesToolsetOpenApiToolsetOutputReference | CesToolsetOpenApiToolset): any;
export declare class CesToolsetOpenApiToolsetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolsetOpenApiToolset | undefined;
    set internalValue(value: CesToolsetOpenApiToolset | undefined);
    private _ignoreUnknownFields?;
    get ignoreUnknownFields(): boolean | cdktn.IResolvable;
    set ignoreUnknownFields(value: boolean | cdktn.IResolvable);
    resetIgnoreUnknownFields(): void;
    get ignoreUnknownFieldsInput(): boolean | cdktn.IResolvable | undefined;
    private _openApiSchema?;
    get openApiSchema(): string;
    set openApiSchema(value: string);
    get openApiSchemaInput(): string | undefined;
    get url(): string;
    private _apiAuthentication;
    get apiAuthentication(): CesToolsetOpenApiToolsetApiAuthenticationOutputReference;
    putApiAuthentication(value: CesToolsetOpenApiToolsetApiAuthentication): void;
    resetApiAuthentication(): void;
    get apiAuthenticationInput(): CesToolsetOpenApiToolsetApiAuthentication | undefined;
    private _serviceDirectoryConfig;
    get serviceDirectoryConfig(): CesToolsetOpenApiToolsetServiceDirectoryConfigOutputReference;
    putServiceDirectoryConfig(value: CesToolsetOpenApiToolsetServiceDirectoryConfig): void;
    resetServiceDirectoryConfig(): void;
    get serviceDirectoryConfigInput(): CesToolsetOpenApiToolsetServiceDirectoryConfig | undefined;
    private _tlsConfig;
    get tlsConfig(): CesToolsetOpenApiToolsetTlsConfigOutputReference;
    putTlsConfig(value: CesToolsetOpenApiToolsetTlsConfig): void;
    resetTlsConfig(): void;
    get tlsConfigInput(): CesToolsetOpenApiToolsetTlsConfig | undefined;
}
export interface CesToolsetTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#create CesToolset#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#delete CesToolset#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#update CesToolset#update}
    */
    readonly update?: string;
}
export declare function cesToolsetTimeoutsToTerraform(struct?: CesToolsetTimeouts | cdktn.IResolvable): any;
export declare function cesToolsetTimeoutsToHclTerraform(struct?: CesToolsetTimeouts | cdktn.IResolvable): any;
export declare class CesToolsetTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolsetTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CesToolsetTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface CesToolsetToolFakeConfigCodeBlock {
    /**
    * Python code which will be invoked in tool fake mode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#python_code CesToolset#python_code}
    */
    readonly pythonCode: string;
}
export declare function cesToolsetToolFakeConfigCodeBlockToTerraform(struct?: CesToolsetToolFakeConfigCodeBlockOutputReference | CesToolsetToolFakeConfigCodeBlock): any;
export declare function cesToolsetToolFakeConfigCodeBlockToHclTerraform(struct?: CesToolsetToolFakeConfigCodeBlockOutputReference | CesToolsetToolFakeConfigCodeBlock): any;
export declare class CesToolsetToolFakeConfigCodeBlockOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolsetToolFakeConfigCodeBlock | undefined;
    set internalValue(value: CesToolsetToolFakeConfigCodeBlock | undefined);
    private _pythonCode?;
    get pythonCode(): string;
    set pythonCode(value: string);
    get pythonCodeInput(): string | undefined;
}
export interface CesToolsetToolFakeConfig {
    /**
    * Whether the tool is using fake mode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#enable_fake_mode CesToolset#enable_fake_mode}
    */
    readonly enableFakeMode?: boolean | cdktn.IResolvable;
    /**
    * code_block block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#code_block CesToolset#code_block}
    */
    readonly codeBlock?: CesToolsetToolFakeConfigCodeBlock;
}
export declare function cesToolsetToolFakeConfigToTerraform(struct?: CesToolsetToolFakeConfigOutputReference | CesToolsetToolFakeConfig): any;
export declare function cesToolsetToolFakeConfigToHclTerraform(struct?: CesToolsetToolFakeConfigOutputReference | CesToolsetToolFakeConfig): any;
export declare class CesToolsetToolFakeConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolsetToolFakeConfig | undefined;
    set internalValue(value: CesToolsetToolFakeConfig | undefined);
    private _enableFakeMode?;
    get enableFakeMode(): boolean | cdktn.IResolvable;
    set enableFakeMode(value: boolean | cdktn.IResolvable);
    resetEnableFakeMode(): void;
    get enableFakeModeInput(): boolean | cdktn.IResolvable | undefined;
    private _codeBlock;
    get codeBlock(): CesToolsetToolFakeConfigCodeBlockOutputReference;
    putCodeBlock(value: CesToolsetToolFakeConfigCodeBlock): void;
    resetCodeBlock(): void;
    get codeBlockInput(): CesToolsetToolFakeConfigCodeBlock | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset google_ces_toolset}
*/
export declare class CesToolset extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_ces_toolset";
    /**
    * Generates CDKTN code for importing a CesToolset resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CesToolset to import
    * @param importFromId The id of the existing CesToolset that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CesToolset to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_toolset google_ces_toolset} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CesToolsetConfig
    */
    constructor(scope: Construct, id: string, config: CesToolsetConfig);
    private _app?;
    get app(): string;
    set app(value: string);
    get appInput(): string | undefined;
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    get etag(): string;
    private _executionType?;
    get executionType(): string;
    set executionType(value: string);
    resetExecutionType(): void;
    get executionTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _timeout?;
    get timeout(): string;
    set timeout(value: string);
    resetTimeout(): void;
    get timeoutInput(): string | undefined;
    private _toolsetId?;
    get toolsetId(): string;
    set toolsetId(value: string);
    get toolsetIdInput(): string | undefined;
    get updateTime(): string;
    private _connectorToolset;
    get connectorToolset(): CesToolsetConnectorToolsetOutputReference;
    putConnectorToolset(value: CesToolsetConnectorToolset): void;
    resetConnectorToolset(): void;
    get connectorToolsetInput(): CesToolsetConnectorToolset | undefined;
    private _mcpToolset;
    get mcpToolset(): CesToolsetMcpToolsetOutputReference;
    putMcpToolset(value: CesToolsetMcpToolset): void;
    resetMcpToolset(): void;
    get mcpToolsetInput(): CesToolsetMcpToolset | undefined;
    private _openApiToolset;
    get openApiToolset(): CesToolsetOpenApiToolsetOutputReference;
    putOpenApiToolset(value: CesToolsetOpenApiToolset): void;
    resetOpenApiToolset(): void;
    get openApiToolsetInput(): CesToolsetOpenApiToolset | undefined;
    private _timeouts;
    get timeouts(): CesToolsetTimeoutsOutputReference;
    putTimeouts(value: CesToolsetTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CesToolsetTimeouts | undefined;
    private _toolFakeConfig;
    get toolFakeConfig(): CesToolsetToolFakeConfigOutputReference;
    putToolFakeConfig(value: CesToolsetToolFakeConfig): void;
    resetToolFakeConfig(): void;
    get toolFakeConfigInput(): CesToolsetToolFakeConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
