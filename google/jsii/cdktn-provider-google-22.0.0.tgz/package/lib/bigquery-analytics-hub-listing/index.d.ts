/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BigqueryAnalyticsHubListingConfig extends cdktn.TerraformMetaArguments {
    /**
    * If true, the listing is only available to get the resource metadata. Listing is non subscribable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#allow_only_metadata_sharing BigqueryAnalyticsHubListing#allow_only_metadata_sharing}
    */
    readonly allowOnlyMetadataSharing?: boolean | cdktn.IResolvable;
    /**
    * Categories of the listing. Up to two categories are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#categories BigqueryAnalyticsHubListing#categories}
    */
    readonly categories?: string[];
    /**
    * The ID of the data exchange. Must contain only Unicode letters, numbers (0-9), underscores (_). Should not use characters that require URL-escaping, or characters outside of ASCII, spaces.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#data_exchange_id BigqueryAnalyticsHubListing#data_exchange_id}
    */
    readonly dataExchangeId: string;
    /**
    * If the listing is commercial then this field must be set to true, otherwise a failure is thrown. This acts as a safety guard to avoid deleting commercial listings accidentally.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#delete_commercial BigqueryAnalyticsHubListing#delete_commercial}
    */
    readonly deleteCommercial?: boolean | cdktn.IResolvable;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#deletion_policy BigqueryAnalyticsHubListing#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Short description of the listing. The description must not contain Unicode non-characters and C0 and C1 control codes except tabs (HT), new lines (LF), carriage returns (CR), and page breaks (FF).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#description BigqueryAnalyticsHubListing#description}
    */
    readonly description?: string;
    /**
    * Specifies the type of discovery on the discovery page. Cannot be set for a restricted listing. Note that this does not control the visibility of the exchange/listing which is defined by IAM permission. Possible values: ["DISCOVERY_TYPE_PRIVATE", "DISCOVERY_TYPE_PUBLIC"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#discovery_type BigqueryAnalyticsHubListing#discovery_type}
    */
    readonly discoveryType?: string;
    /**
    * Human-readable display name of the listing. The display name must contain only Unicode letters, numbers (0-9), underscores (_), dashes (-), spaces ( ), ampersands (&) and can't start or end with spaces.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#display_name BigqueryAnalyticsHubListing#display_name}
    */
    readonly displayName: string;
    /**
    * Documentation describing the listing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#documentation BigqueryAnalyticsHubListing#documentation}
    */
    readonly documentation?: string;
    /**
    * Base64 encoded image representing the listing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#icon BigqueryAnalyticsHubListing#icon}
    */
    readonly icon?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#id BigqueryAnalyticsHubListing#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the listing. Must contain only Unicode letters, numbers (0-9), underscores (_). Should not use characters that require URL-escaping, or characters outside of ASCII, spaces.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#listing_id BigqueryAnalyticsHubListing#listing_id}
    */
    readonly listingId: string;
    /**
    * The name of the location this data exchange listing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#location BigqueryAnalyticsHubListing#location}
    */
    readonly location: string;
    /**
    * If true, subscriber email logging is enabled and all queries on the linked dataset will log the email address of the querying user. Once enabled, this setting cannot be turned off.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#log_linked_dataset_query_user_email BigqueryAnalyticsHubListing#log_linked_dataset_query_user_email}
    */
    readonly logLinkedDatasetQueryUserEmail?: boolean | cdktn.IResolvable;
    /**
    * Email or URL of the primary point of contact of the listing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#primary_contact BigqueryAnalyticsHubListing#primary_contact}
    */
    readonly primaryContact?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#project BigqueryAnalyticsHubListing#project}
    */
    readonly project?: string;
    /**
    * Email or URL of the request access of the listing. Subscribers can use this reference to request access.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#request_access BigqueryAnalyticsHubListing#request_access}
    */
    readonly requestAccess?: string;
    /**
    * bigquery_dataset block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#bigquery_dataset BigqueryAnalyticsHubListing#bigquery_dataset}
    */
    readonly bigqueryDataset?: BigqueryAnalyticsHubListingBigqueryDataset;
    /**
    * data_provider block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#data_provider BigqueryAnalyticsHubListing#data_provider}
    */
    readonly dataProvider?: BigqueryAnalyticsHubListingDataProvider;
    /**
    * publisher block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#publisher BigqueryAnalyticsHubListing#publisher}
    */
    readonly publisher?: BigqueryAnalyticsHubListingPublisher;
    /**
    * pubsub_topic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#pubsub_topic BigqueryAnalyticsHubListing#pubsub_topic}
    */
    readonly pubsubTopic?: BigqueryAnalyticsHubListingPubsubTopic;
    /**
    * restricted_export_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#restricted_export_config BigqueryAnalyticsHubListing#restricted_export_config}
    */
    readonly restrictedExportConfig?: BigqueryAnalyticsHubListingRestrictedExportConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#timeouts BigqueryAnalyticsHubListing#timeouts}
    */
    readonly timeouts?: BigqueryAnalyticsHubListingTimeouts;
}
export interface BigqueryAnalyticsHubListingCommercialInfoCloudMarketplace {
}
export declare function bigqueryAnalyticsHubListingCommercialInfoCloudMarketplaceToTerraform(struct?: BigqueryAnalyticsHubListingCommercialInfoCloudMarketplace): any;
export declare function bigqueryAnalyticsHubListingCommercialInfoCloudMarketplaceToHclTerraform(struct?: BigqueryAnalyticsHubListingCommercialInfoCloudMarketplace): any;
export declare class BigqueryAnalyticsHubListingCommercialInfoCloudMarketplaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BigqueryAnalyticsHubListingCommercialInfoCloudMarketplace | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingCommercialInfoCloudMarketplace | undefined);
    get commercialState(): string;
    get service(): string;
}
export declare class BigqueryAnalyticsHubListingCommercialInfoCloudMarketplaceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BigqueryAnalyticsHubListingCommercialInfoCloudMarketplaceOutputReference;
}
export interface BigqueryAnalyticsHubListingCommercialInfo {
}
export declare function bigqueryAnalyticsHubListingCommercialInfoToTerraform(struct?: BigqueryAnalyticsHubListingCommercialInfo): any;
export declare function bigqueryAnalyticsHubListingCommercialInfoToHclTerraform(struct?: BigqueryAnalyticsHubListingCommercialInfo): any;
export declare class BigqueryAnalyticsHubListingCommercialInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BigqueryAnalyticsHubListingCommercialInfo | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingCommercialInfo | undefined);
    private _cloudMarketplace;
    get cloudMarketplace(): BigqueryAnalyticsHubListingCommercialInfoCloudMarketplaceList;
}
export declare class BigqueryAnalyticsHubListingCommercialInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BigqueryAnalyticsHubListingCommercialInfoOutputReference;
}
export interface BigqueryAnalyticsHubListingBigqueryDatasetEffectiveReplicas {
}
export declare function bigqueryAnalyticsHubListingBigqueryDatasetEffectiveReplicasToTerraform(struct?: BigqueryAnalyticsHubListingBigqueryDatasetEffectiveReplicas): any;
export declare function bigqueryAnalyticsHubListingBigqueryDatasetEffectiveReplicasToHclTerraform(struct?: BigqueryAnalyticsHubListingBigqueryDatasetEffectiveReplicas): any;
export declare class BigqueryAnalyticsHubListingBigqueryDatasetEffectiveReplicasOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BigqueryAnalyticsHubListingBigqueryDatasetEffectiveReplicas | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingBigqueryDatasetEffectiveReplicas | undefined);
    get location(): string;
    get primaryState(): string;
    get replicaState(): string;
}
export declare class BigqueryAnalyticsHubListingBigqueryDatasetEffectiveReplicasList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BigqueryAnalyticsHubListingBigqueryDatasetEffectiveReplicasOutputReference;
}
export interface BigqueryAnalyticsHubListingBigqueryDatasetSelectedResources {
    /**
    * Format: For routine: projects/{projectId}/datasets/{datasetId}/routines/{routineId} Example:"projects/test_project/datasets/test_dataset/routines/test_routine"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#routine BigqueryAnalyticsHubListing#routine}
    */
    readonly routine?: string;
    /**
    * Format: For table: projects/{projectId}/datasets/{datasetId}/tables/{tableId} Example:"projects/test_project/datasets/test_dataset/tables/test_table"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#table BigqueryAnalyticsHubListing#table}
    */
    readonly table?: string;
}
export declare function bigqueryAnalyticsHubListingBigqueryDatasetSelectedResourcesToTerraform(struct?: BigqueryAnalyticsHubListingBigqueryDatasetSelectedResources | cdktn.IResolvable): any;
export declare function bigqueryAnalyticsHubListingBigqueryDatasetSelectedResourcesToHclTerraform(struct?: BigqueryAnalyticsHubListingBigqueryDatasetSelectedResources | cdktn.IResolvable): any;
export declare class BigqueryAnalyticsHubListingBigqueryDatasetSelectedResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BigqueryAnalyticsHubListingBigqueryDatasetSelectedResources | cdktn.IResolvable | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingBigqueryDatasetSelectedResources | cdktn.IResolvable | undefined);
    private _routine?;
    get routine(): string;
    set routine(value: string);
    resetRoutine(): void;
    get routineInput(): string | undefined;
    private _table?;
    get table(): string;
    set table(value: string);
    resetTable(): void;
    get tableInput(): string | undefined;
}
export declare class BigqueryAnalyticsHubListingBigqueryDatasetSelectedResourcesList extends cdktn.ComplexList {
    internalValue?: BigqueryAnalyticsHubListingBigqueryDatasetSelectedResources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BigqueryAnalyticsHubListingBigqueryDatasetSelectedResourcesOutputReference;
}
export interface BigqueryAnalyticsHubListingBigqueryDataset {
    /**
    * Resource name of the dataset source for this listing. e.g. projects/myproject/datasets/123
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#dataset BigqueryAnalyticsHubListing#dataset}
    */
    readonly dataset: string;
    /**
    * A list of regions where the publisher has created shared dataset replicas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#replica_locations BigqueryAnalyticsHubListing#replica_locations}
    */
    readonly replicaLocations?: string[];
    /**
    * selected_resources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#selected_resources BigqueryAnalyticsHubListing#selected_resources}
    */
    readonly selectedResources?: BigqueryAnalyticsHubListingBigqueryDatasetSelectedResources[] | cdktn.IResolvable;
}
export declare function bigqueryAnalyticsHubListingBigqueryDatasetToTerraform(struct?: BigqueryAnalyticsHubListingBigqueryDatasetOutputReference | BigqueryAnalyticsHubListingBigqueryDataset): any;
export declare function bigqueryAnalyticsHubListingBigqueryDatasetToHclTerraform(struct?: BigqueryAnalyticsHubListingBigqueryDatasetOutputReference | BigqueryAnalyticsHubListingBigqueryDataset): any;
export declare class BigqueryAnalyticsHubListingBigqueryDatasetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryAnalyticsHubListingBigqueryDataset | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingBigqueryDataset | undefined);
    private _dataset?;
    get dataset(): string;
    set dataset(value: string);
    get datasetInput(): string | undefined;
    private _effectiveReplicas;
    get effectiveReplicas(): BigqueryAnalyticsHubListingBigqueryDatasetEffectiveReplicasList;
    private _replicaLocations?;
    get replicaLocations(): string[];
    set replicaLocations(value: string[]);
    resetReplicaLocations(): void;
    get replicaLocationsInput(): string[] | undefined;
    private _selectedResources;
    get selectedResources(): BigqueryAnalyticsHubListingBigqueryDatasetSelectedResourcesList;
    putSelectedResources(value: BigqueryAnalyticsHubListingBigqueryDatasetSelectedResources[] | cdktn.IResolvable): void;
    resetSelectedResources(): void;
    get selectedResourcesInput(): cdktn.IResolvable | BigqueryAnalyticsHubListingBigqueryDatasetSelectedResources[] | undefined;
}
export interface BigqueryAnalyticsHubListingDataProvider {
    /**
    * Name of the data provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#name BigqueryAnalyticsHubListing#name}
    */
    readonly name: string;
    /**
    * Email or URL of the data provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#primary_contact BigqueryAnalyticsHubListing#primary_contact}
    */
    readonly primaryContact?: string;
}
export declare function bigqueryAnalyticsHubListingDataProviderToTerraform(struct?: BigqueryAnalyticsHubListingDataProviderOutputReference | BigqueryAnalyticsHubListingDataProvider): any;
export declare function bigqueryAnalyticsHubListingDataProviderToHclTerraform(struct?: BigqueryAnalyticsHubListingDataProviderOutputReference | BigqueryAnalyticsHubListingDataProvider): any;
export declare class BigqueryAnalyticsHubListingDataProviderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryAnalyticsHubListingDataProvider | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingDataProvider | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _primaryContact?;
    get primaryContact(): string;
    set primaryContact(value: string);
    resetPrimaryContact(): void;
    get primaryContactInput(): string | undefined;
}
export interface BigqueryAnalyticsHubListingPublisher {
    /**
    * Name of the listing publisher.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#name BigqueryAnalyticsHubListing#name}
    */
    readonly name: string;
    /**
    * Email or URL of the listing publisher.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#primary_contact BigqueryAnalyticsHubListing#primary_contact}
    */
    readonly primaryContact?: string;
}
export declare function bigqueryAnalyticsHubListingPublisherToTerraform(struct?: BigqueryAnalyticsHubListingPublisherOutputReference | BigqueryAnalyticsHubListingPublisher): any;
export declare function bigqueryAnalyticsHubListingPublisherToHclTerraform(struct?: BigqueryAnalyticsHubListingPublisherOutputReference | BigqueryAnalyticsHubListingPublisher): any;
export declare class BigqueryAnalyticsHubListingPublisherOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryAnalyticsHubListingPublisher | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingPublisher | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _primaryContact?;
    get primaryContact(): string;
    set primaryContact(value: string);
    resetPrimaryContact(): void;
    get primaryContactInput(): string | undefined;
}
export interface BigqueryAnalyticsHubListingPubsubTopic {
    /**
    * Region hint on where the data might be published. Data affinity regions are modifiable.
    * See https://cloud.google.com/about/locations for full listing of possible Cloud regions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#data_affinity_regions BigqueryAnalyticsHubListing#data_affinity_regions}
    */
    readonly dataAffinityRegions?: string[];
    /**
    * Resource name of the Pub/Sub topic source for this listing. e.g. projects/myproject/topics/topicId
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#topic BigqueryAnalyticsHubListing#topic}
    */
    readonly topic: string;
}
export declare function bigqueryAnalyticsHubListingPubsubTopicToTerraform(struct?: BigqueryAnalyticsHubListingPubsubTopicOutputReference | BigqueryAnalyticsHubListingPubsubTopic): any;
export declare function bigqueryAnalyticsHubListingPubsubTopicToHclTerraform(struct?: BigqueryAnalyticsHubListingPubsubTopicOutputReference | BigqueryAnalyticsHubListingPubsubTopic): any;
export declare class BigqueryAnalyticsHubListingPubsubTopicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryAnalyticsHubListingPubsubTopic | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingPubsubTopic | undefined);
    private _dataAffinityRegions?;
    get dataAffinityRegions(): string[];
    set dataAffinityRegions(value: string[]);
    resetDataAffinityRegions(): void;
    get dataAffinityRegionsInput(): string[] | undefined;
    private _topic?;
    get topic(): string;
    set topic(value: string);
    get topicInput(): string | undefined;
}
export interface BigqueryAnalyticsHubListingRestrictedExportConfig {
    /**
    * If true, enable restricted export.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#enabled BigqueryAnalyticsHubListing#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * If true, restrict export of query result derived from restricted linked dataset table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#restrict_query_result BigqueryAnalyticsHubListing#restrict_query_result}
    */
    readonly restrictQueryResult?: boolean | cdktn.IResolvable;
}
export declare function bigqueryAnalyticsHubListingRestrictedExportConfigToTerraform(struct?: BigqueryAnalyticsHubListingRestrictedExportConfigOutputReference | BigqueryAnalyticsHubListingRestrictedExportConfig): any;
export declare function bigqueryAnalyticsHubListingRestrictedExportConfigToHclTerraform(struct?: BigqueryAnalyticsHubListingRestrictedExportConfigOutputReference | BigqueryAnalyticsHubListingRestrictedExportConfig): any;
export declare class BigqueryAnalyticsHubListingRestrictedExportConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryAnalyticsHubListingRestrictedExportConfig | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingRestrictedExportConfig | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get restrictDirectTableAccess(): cdktn.IResolvable;
    private _restrictQueryResult?;
    get restrictQueryResult(): boolean | cdktn.IResolvable;
    set restrictQueryResult(value: boolean | cdktn.IResolvable);
    resetRestrictQueryResult(): void;
    get restrictQueryResultInput(): boolean | cdktn.IResolvable | undefined;
}
export interface BigqueryAnalyticsHubListingTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#create BigqueryAnalyticsHubListing#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#delete BigqueryAnalyticsHubListing#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#update BigqueryAnalyticsHubListing#update}
    */
    readonly update?: string;
}
export declare function bigqueryAnalyticsHubListingTimeoutsToTerraform(struct?: BigqueryAnalyticsHubListingTimeouts | cdktn.IResolvable): any;
export declare function bigqueryAnalyticsHubListingTimeoutsToHclTerraform(struct?: BigqueryAnalyticsHubListingTimeouts | cdktn.IResolvable): any;
export declare class BigqueryAnalyticsHubListingTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryAnalyticsHubListingTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing google_bigquery_analytics_hub_listing}
*/
export declare class BigqueryAnalyticsHubListing extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_bigquery_analytics_hub_listing";
    /**
    * Generates CDKTN code for importing a BigqueryAnalyticsHubListing resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BigqueryAnalyticsHubListing to import
    * @param importFromId The id of the existing BigqueryAnalyticsHubListing that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BigqueryAnalyticsHubListing to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing google_bigquery_analytics_hub_listing} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BigqueryAnalyticsHubListingConfig
    */
    constructor(scope: Construct, id: string, config: BigqueryAnalyticsHubListingConfig);
    private _allowOnlyMetadataSharing?;
    get allowOnlyMetadataSharing(): boolean | cdktn.IResolvable;
    set allowOnlyMetadataSharing(value: boolean | cdktn.IResolvable);
    resetAllowOnlyMetadataSharing(): void;
    get allowOnlyMetadataSharingInput(): boolean | cdktn.IResolvable | undefined;
    private _categories?;
    get categories(): string[];
    set categories(value: string[]);
    resetCategories(): void;
    get categoriesInput(): string[] | undefined;
    private _commercialInfo;
    get commercialInfo(): BigqueryAnalyticsHubListingCommercialInfoList;
    private _dataExchangeId?;
    get dataExchangeId(): string;
    set dataExchangeId(value: string);
    get dataExchangeIdInput(): string | undefined;
    private _deleteCommercial?;
    get deleteCommercial(): boolean | cdktn.IResolvable;
    set deleteCommercial(value: boolean | cdktn.IResolvable);
    resetDeleteCommercial(): void;
    get deleteCommercialInput(): boolean | cdktn.IResolvable | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _discoveryType?;
    get discoveryType(): string;
    set discoveryType(value: string);
    resetDiscoveryType(): void;
    get discoveryTypeInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _documentation?;
    get documentation(): string;
    set documentation(value: string);
    resetDocumentation(): void;
    get documentationInput(): string | undefined;
    private _icon?;
    get icon(): string;
    set icon(value: string);
    resetIcon(): void;
    get iconInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _listingId?;
    get listingId(): string;
    set listingId(value: string);
    get listingIdInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _logLinkedDatasetQueryUserEmail?;
    get logLinkedDatasetQueryUserEmail(): boolean | cdktn.IResolvable;
    set logLinkedDatasetQueryUserEmail(value: boolean | cdktn.IResolvable);
    resetLogLinkedDatasetQueryUserEmail(): void;
    get logLinkedDatasetQueryUserEmailInput(): boolean | cdktn.IResolvable | undefined;
    get name(): string;
    private _primaryContact?;
    get primaryContact(): string;
    set primaryContact(value: string);
    resetPrimaryContact(): void;
    get primaryContactInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _requestAccess?;
    get requestAccess(): string;
    set requestAccess(value: string);
    resetRequestAccess(): void;
    get requestAccessInput(): string | undefined;
    get state(): string;
    private _bigqueryDataset;
    get bigqueryDataset(): BigqueryAnalyticsHubListingBigqueryDatasetOutputReference;
    putBigqueryDataset(value: BigqueryAnalyticsHubListingBigqueryDataset): void;
    resetBigqueryDataset(): void;
    get bigqueryDatasetInput(): BigqueryAnalyticsHubListingBigqueryDataset | undefined;
    private _dataProvider;
    get dataProvider(): BigqueryAnalyticsHubListingDataProviderOutputReference;
    putDataProvider(value: BigqueryAnalyticsHubListingDataProvider): void;
    resetDataProvider(): void;
    get dataProviderInput(): BigqueryAnalyticsHubListingDataProvider | undefined;
    private _publisher;
    get publisher(): BigqueryAnalyticsHubListingPublisherOutputReference;
    putPublisher(value: BigqueryAnalyticsHubListingPublisher): void;
    resetPublisher(): void;
    get publisherInput(): BigqueryAnalyticsHubListingPublisher | undefined;
    private _pubsubTopic;
    get pubsubTopic(): BigqueryAnalyticsHubListingPubsubTopicOutputReference;
    putPubsubTopic(value: BigqueryAnalyticsHubListingPubsubTopic): void;
    resetPubsubTopic(): void;
    get pubsubTopicInput(): BigqueryAnalyticsHubListingPubsubTopic | undefined;
    private _restrictedExportConfig;
    get restrictedExportConfig(): BigqueryAnalyticsHubListingRestrictedExportConfigOutputReference;
    putRestrictedExportConfig(value: BigqueryAnalyticsHubListingRestrictedExportConfig): void;
    resetRestrictedExportConfig(): void;
    get restrictedExportConfigInput(): BigqueryAnalyticsHubListingRestrictedExportConfig | undefined;
    private _timeouts;
    get timeouts(): BigqueryAnalyticsHubListingTimeoutsOutputReference;
    putTimeouts(value: BigqueryAnalyticsHubListingTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BigqueryAnalyticsHubListingTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
