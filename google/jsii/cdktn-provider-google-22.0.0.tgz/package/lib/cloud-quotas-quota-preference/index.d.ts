/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudQuotasQuotaPreferenceConfig extends cdktn.TerraformMetaArguments {
    /**
    * An email address that can be used for quota related communication between the Google Cloud and the user in case the Google Cloud needs further information to make a decision on whether the user preferred quota can be granted.
    *
    * The Google account for the email address must have quota update permission for the project, folder or organization this quota preference is for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_quotas_quota_preference#contact_email CloudQuotasQuotaPreference#contact_email}
    */
    readonly contactEmail?: string;
    /**
    * The dimensions that this quota preference applies to. The key of the map entry is the name of a dimension, such as "region", "zone", "network_id", and the value of the map entry is the dimension value. If a dimension is missing from the map of dimensions, the quota preference applies to all the dimension values except for those that have other quota preferences configured for the specific value.
    *
    * NOTE: QuotaPreferences can only be applied across all values of "user" and "resource" dimension. Do not set values for "user" or "resource" in the dimension map.
    *
    * Example: '{"provider": "Foo Inc"}' where "provider" is a service specific dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_quotas_quota_preference#dimensions CloudQuotasQuotaPreference#dimensions}
    */
    readonly dimensions?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_quotas_quota_preference#id CloudQuotasQuotaPreference#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The list of quota safety checks to be ignored. Default value: "QUOTA_SAFETY_CHECK_UNSPECIFIED" Possible values: ["QUOTA_SAFETY_CHECK_UNSPECIFIED", "QUOTA_DECREASE_BELOW_USAGE", "QUOTA_DECREASE_PERCENTAGE_TOO_HIGH"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_quotas_quota_preference#ignore_safety_checks CloudQuotasQuotaPreference#ignore_safety_checks}
    */
    readonly ignoreSafetyChecks?: string;
    /**
    * The reason / justification for this quota preference.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_quotas_quota_preference#justification CloudQuotasQuotaPreference#justification}
    */
    readonly justification?: string;
    /**
    * The resource name of the quota preference. Required except in the CREATE requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_quotas_quota_preference#name CloudQuotasQuotaPreference#name}
    */
    readonly name?: string;
    /**
    * The parent of the quota preference. Allowed parents are "projects/[project-id / number]" or "folders/[folder-id / number]" or "organizations/[org-id / number]".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_quotas_quota_preference#parent CloudQuotasQuotaPreference#parent}
    */
    readonly parent?: string;
    /**
    * The id of the quota to which the quota preference is applied. A quota id is unique in the service.
    * Example: 'CPUS-per-project-region'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_quotas_quota_preference#quota_id CloudQuotasQuotaPreference#quota_id}
    */
    readonly quotaId?: string;
    /**
    * The name of the service to which the quota preference is applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_quotas_quota_preference#service CloudQuotasQuotaPreference#service}
    */
    readonly service?: string;
    /**
    * quota_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_quotas_quota_preference#quota_config CloudQuotasQuotaPreference#quota_config}
    */
    readonly quotaConfig: CloudQuotasQuotaPreferenceQuotaConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_quotas_quota_preference#timeouts CloudQuotasQuotaPreference#timeouts}
    */
    readonly timeouts?: CloudQuotasQuotaPreferenceTimeouts;
}
export interface CloudQuotasQuotaPreferenceQuotaConfig {
    /**
    * The annotations map for clients to store small amounts of arbitrary data. Do not put PII or other sensitive information here. See https://google.aip.dev/128#annotations.
    *
    * An object containing a list of "key: value" pairs. Example: '{ "name": "wrench", "mass": "1.3kg", "count": "3" }'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_quotas_quota_preference#annotations CloudQuotasQuotaPreference#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * The preferred value. Must be greater than or equal to -1. If set to -1, it means the value is "unlimited".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_quotas_quota_preference#preferred_value CloudQuotasQuotaPreference#preferred_value}
    */
    readonly preferredValue: string;
}
export declare function cloudQuotasQuotaPreferenceQuotaConfigToTerraform(struct?: CloudQuotasQuotaPreferenceQuotaConfigOutputReference | CloudQuotasQuotaPreferenceQuotaConfig): any;
export declare function cloudQuotasQuotaPreferenceQuotaConfigToHclTerraform(struct?: CloudQuotasQuotaPreferenceQuotaConfigOutputReference | CloudQuotasQuotaPreferenceQuotaConfig): any;
export declare class CloudQuotasQuotaPreferenceQuotaConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudQuotasQuotaPreferenceQuotaConfig | undefined;
    set internalValue(value: CloudQuotasQuotaPreferenceQuotaConfig | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    get grantedValue(): string;
    private _preferredValue?;
    get preferredValue(): string;
    set preferredValue(value: string);
    get preferredValueInput(): string | undefined;
    get requestOrigin(): string;
    get stateDetail(): string;
    get traceId(): string;
}
export interface CloudQuotasQuotaPreferenceTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_quotas_quota_preference#create CloudQuotasQuotaPreference#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_quotas_quota_preference#delete CloudQuotasQuotaPreference#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_quotas_quota_preference#update CloudQuotasQuotaPreference#update}
    */
    readonly update?: string;
}
export declare function cloudQuotasQuotaPreferenceTimeoutsToTerraform(struct?: CloudQuotasQuotaPreferenceTimeouts | cdktn.IResolvable): any;
export declare function cloudQuotasQuotaPreferenceTimeoutsToHclTerraform(struct?: CloudQuotasQuotaPreferenceTimeouts | cdktn.IResolvable): any;
export declare class CloudQuotasQuotaPreferenceTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudQuotasQuotaPreferenceTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CloudQuotasQuotaPreferenceTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_quotas_quota_preference google_cloud_quotas_quota_preference}
*/
export declare class CloudQuotasQuotaPreference extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_cloud_quotas_quota_preference";
    /**
    * Generates CDKTN code for importing a CloudQuotasQuotaPreference resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudQuotasQuotaPreference to import
    * @param importFromId The id of the existing CloudQuotasQuotaPreference that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_quotas_quota_preference#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudQuotasQuotaPreference to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_quotas_quota_preference google_cloud_quotas_quota_preference} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudQuotasQuotaPreferenceConfig
    */
    constructor(scope: Construct, id: string, config: CloudQuotasQuotaPreferenceConfig);
    private _contactEmail?;
    get contactEmail(): string;
    set contactEmail(value: string);
    resetContactEmail(): void;
    get contactEmailInput(): string | undefined;
    get createTime(): string;
    private _dimensions?;
    get dimensions(): {
        [key: string]: string;
    };
    set dimensions(value: {
        [key: string]: string;
    });
    resetDimensions(): void;
    get dimensionsInput(): {
        [key: string]: string;
    } | undefined;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ignoreSafetyChecks?;
    get ignoreSafetyChecks(): string;
    set ignoreSafetyChecks(value: string);
    resetIgnoreSafetyChecks(): void;
    get ignoreSafetyChecksInput(): string | undefined;
    private _justification?;
    get justification(): string;
    set justification(value: string);
    resetJustification(): void;
    get justificationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    resetParent(): void;
    get parentInput(): string | undefined;
    private _quotaId?;
    get quotaId(): string;
    set quotaId(value: string);
    resetQuotaId(): void;
    get quotaIdInput(): string | undefined;
    get reconciling(): cdktn.IResolvable;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
    get updateTime(): string;
    private _quotaConfig;
    get quotaConfig(): CloudQuotasQuotaPreferenceQuotaConfigOutputReference;
    putQuotaConfig(value: CloudQuotasQuotaPreferenceQuotaConfig): void;
    get quotaConfigInput(): CloudQuotasQuotaPreferenceQuotaConfig | undefined;
    private _timeouts;
    get timeouts(): CloudQuotasQuotaPreferenceTimeoutsOutputReference;
    putTimeouts(value: CloudQuotasQuotaPreferenceTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CloudQuotasQuotaPreferenceTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
