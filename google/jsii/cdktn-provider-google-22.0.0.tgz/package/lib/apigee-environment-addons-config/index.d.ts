/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigeeEnvironmentAddonsConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Flag to enable/disable Analytics.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment_addons_config#analytics_enabled ApigeeEnvironmentAddonsConfig#analytics_enabled}
    */
    readonly analyticsEnabled?: boolean | cdktn.IResolvable;
    /**
    * The Apigee environment group associated with the Apigee environment,
    * in the format 'organizations/{{org_name}}/environments/{{env_name}}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment_addons_config#env_id ApigeeEnvironmentAddonsConfig#env_id}
    */
    readonly envId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment_addons_config#id ApigeeEnvironmentAddonsConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment_addons_config#timeouts ApigeeEnvironmentAddonsConfig#timeouts}
    */
    readonly timeouts?: ApigeeEnvironmentAddonsConfigTimeouts;
}
export interface ApigeeEnvironmentAddonsConfigTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment_addons_config#create ApigeeEnvironmentAddonsConfig#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment_addons_config#delete ApigeeEnvironmentAddonsConfig#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment_addons_config#update ApigeeEnvironmentAddonsConfig#update}
    */
    readonly update?: string;
}
export declare function apigeeEnvironmentAddonsConfigTimeoutsToTerraform(struct?: ApigeeEnvironmentAddonsConfigTimeouts | cdktn.IResolvable): any;
export declare function apigeeEnvironmentAddonsConfigTimeoutsToHclTerraform(struct?: ApigeeEnvironmentAddonsConfigTimeouts | cdktn.IResolvable): any;
export declare class ApigeeEnvironmentAddonsConfigTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeEnvironmentAddonsConfigTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeEnvironmentAddonsConfigTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment_addons_config google_apigee_environment_addons_config}
*/
export declare class ApigeeEnvironmentAddonsConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apigee_environment_addons_config";
    /**
    * Generates CDKTN code for importing a ApigeeEnvironmentAddonsConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigeeEnvironmentAddonsConfig to import
    * @param importFromId The id of the existing ApigeeEnvironmentAddonsConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment_addons_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigeeEnvironmentAddonsConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment_addons_config google_apigee_environment_addons_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigeeEnvironmentAddonsConfigConfig
    */
    constructor(scope: Construct, id: string, config: ApigeeEnvironmentAddonsConfigConfig);
    private _analyticsEnabled?;
    get analyticsEnabled(): boolean | cdktn.IResolvable;
    set analyticsEnabled(value: boolean | cdktn.IResolvable);
    resetAnalyticsEnabled(): void;
    get analyticsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _envId?;
    get envId(): string;
    set envId(value: string);
    get envIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _timeouts;
    get timeouts(): ApigeeEnvironmentAddonsConfigTimeoutsOutputReference;
    putTimeouts(value: ApigeeEnvironmentAddonsConfigTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApigeeEnvironmentAddonsConfigTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
