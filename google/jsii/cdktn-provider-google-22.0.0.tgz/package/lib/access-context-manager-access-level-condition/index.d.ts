/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccessContextManagerAccessLevelConditionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the Access Level to add this condition to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level_condition#access_level AccessContextManagerAccessLevelCondition#access_level}
    */
    readonly accessLevel: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level_condition#deletion_policy AccessContextManagerAccessLevelCondition#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level_condition#id AccessContextManagerAccessLevelCondition#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A list of CIDR block IP subnetwork specification. May be IPv4
    * or IPv6.
    * Note that for a CIDR IP address block, the specified IP address
    * portion must be properly truncated (i.e. all the host bits must
    * be zero) or the input is considered malformed. For example,
    * "192.0.2.0/24" is accepted but "192.0.2.1/24" is not. Similarly,
    * for IPv6, "2001:db8::/32" is accepted whereas "2001:db8::1/32"
    * is not. The originating IP of a request must be in one of the
    * listed subnets in order for this Condition to be true.
    * If empty, all IP addresses are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level_condition#ip_subnetworks AccessContextManagerAccessLevelCondition#ip_subnetworks}
    */
    readonly ipSubnetworks?: string[];
    /**
    * An allowed list of members (users, service accounts).
    * Using groups is not supported yet.
    *
    * The signed-in user originating the request must be a part of one
    * of the provided members. If not specified, a request may come
    * from any user (logged in/not logged in, not present in any
    * groups, etc.).
    * Formats: 'user:{emailid}', 'serviceAccount:{emailid}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level_condition#members AccessContextManagerAccessLevelCondition#members}
    */
    readonly members?: string[];
    /**
    * Whether to negate the Condition. If true, the Condition becomes
    * a NAND over its non-empty fields, each field must be false for
    * the Condition overall to be satisfied. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level_condition#negate AccessContextManagerAccessLevelCondition#negate}
    */
    readonly negate?: boolean | cdktn.IResolvable;
    /**
    * The request must originate from one of the provided
    * countries/regions.
    * Format: A valid ISO 3166-1 alpha-2 code.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level_condition#regions AccessContextManagerAccessLevelCondition#regions}
    */
    readonly regions?: string[];
    /**
    * A list of other access levels defined in the same Policy,
    * referenced by resource name. Referencing an AccessLevel which
    * does not exist is an error. All access levels listed must be
    * granted for the Condition to be true.
    * Format: accessPolicies/{policy_id}/accessLevels/{short_name}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level_condition#required_access_levels AccessContextManagerAccessLevelCondition#required_access_levels}
    */
    readonly requiredAccessLevels?: string[];
    /**
    * device_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level_condition#device_policy AccessContextManagerAccessLevelCondition#device_policy}
    */
    readonly devicePolicy?: AccessContextManagerAccessLevelConditionDevicePolicy;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level_condition#timeouts AccessContextManagerAccessLevelCondition#timeouts}
    */
    readonly timeouts?: AccessContextManagerAccessLevelConditionTimeouts;
    /**
    * vpc_network_sources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level_condition#vpc_network_sources AccessContextManagerAccessLevelCondition#vpc_network_sources}
    */
    readonly vpcNetworkSources?: AccessContextManagerAccessLevelConditionVpcNetworkSources[] | cdktn.IResolvable;
}
export interface AccessContextManagerAccessLevelConditionDevicePolicyOsConstraints {
    /**
    * The minimum allowed OS version. If not set, any version
    * of this OS satisfies the constraint.
    * Format: "major.minor.patch" such as "10.5.301", "9.2.1".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level_condition#minimum_version AccessContextManagerAccessLevelCondition#minimum_version}
    */
    readonly minimumVersion?: string;
    /**
    * The operating system type of the device. Possible values: ["OS_UNSPECIFIED", "DESKTOP_MAC", "DESKTOP_WINDOWS", "DESKTOP_LINUX", "DESKTOP_CHROME_OS", "ANDROID", "IOS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level_condition#os_type AccessContextManagerAccessLevelCondition#os_type}
    */
    readonly osType: string;
}
export declare function accessContextManagerAccessLevelConditionDevicePolicyOsConstraintsToTerraform(struct?: AccessContextManagerAccessLevelConditionDevicePolicyOsConstraints | cdktn.IResolvable): any;
export declare function accessContextManagerAccessLevelConditionDevicePolicyOsConstraintsToHclTerraform(struct?: AccessContextManagerAccessLevelConditionDevicePolicyOsConstraints | cdktn.IResolvable): any;
export declare class AccessContextManagerAccessLevelConditionDevicePolicyOsConstraintsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerAccessLevelConditionDevicePolicyOsConstraints | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerAccessLevelConditionDevicePolicyOsConstraints | cdktn.IResolvable | undefined);
    private _minimumVersion?;
    get minimumVersion(): string;
    set minimumVersion(value: string);
    resetMinimumVersion(): void;
    get minimumVersionInput(): string | undefined;
    private _osType?;
    get osType(): string;
    set osType(value: string);
    get osTypeInput(): string | undefined;
}
export declare class AccessContextManagerAccessLevelConditionDevicePolicyOsConstraintsList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerAccessLevelConditionDevicePolicyOsConstraints[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerAccessLevelConditionDevicePolicyOsConstraintsOutputReference;
}
export interface AccessContextManagerAccessLevelConditionDevicePolicy {
    /**
    * A list of allowed device management levels.
    * An empty list allows all management levels. Possible values: ["MANAGEMENT_UNSPECIFIED", "NONE", "BASIC", "COMPLETE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level_condition#allowed_device_management_levels AccessContextManagerAccessLevelCondition#allowed_device_management_levels}
    */
    readonly allowedDeviceManagementLevels?: string[];
    /**
    * A list of allowed encryptions statuses.
    * An empty list allows all statuses. Possible values: ["ENCRYPTION_UNSPECIFIED", "ENCRYPTION_UNSUPPORTED", "UNENCRYPTED", "ENCRYPTED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level_condition#allowed_encryption_statuses AccessContextManagerAccessLevelCondition#allowed_encryption_statuses}
    */
    readonly allowedEncryptionStatuses?: string[];
    /**
    * Whether the device needs to be approved by the customer admin.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level_condition#require_admin_approval AccessContextManagerAccessLevelCondition#require_admin_approval}
    */
    readonly requireAdminApproval?: boolean | cdktn.IResolvable;
    /**
    * Whether the device needs to be corp owned.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level_condition#require_corp_owned AccessContextManagerAccessLevelCondition#require_corp_owned}
    */
    readonly requireCorpOwned?: boolean | cdktn.IResolvable;
    /**
    * Whether or not screenlock is required for the DevicePolicy
    * to be true. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level_condition#require_screen_lock AccessContextManagerAccessLevelCondition#require_screen_lock}
    */
    readonly requireScreenLock?: boolean | cdktn.IResolvable;
    /**
    * os_constraints block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level_condition#os_constraints AccessContextManagerAccessLevelCondition#os_constraints}
    */
    readonly osConstraints?: AccessContextManagerAccessLevelConditionDevicePolicyOsConstraints[] | cdktn.IResolvable;
}
export declare function accessContextManagerAccessLevelConditionDevicePolicyToTerraform(struct?: AccessContextManagerAccessLevelConditionDevicePolicyOutputReference | AccessContextManagerAccessLevelConditionDevicePolicy): any;
export declare function accessContextManagerAccessLevelConditionDevicePolicyToHclTerraform(struct?: AccessContextManagerAccessLevelConditionDevicePolicyOutputReference | AccessContextManagerAccessLevelConditionDevicePolicy): any;
export declare class AccessContextManagerAccessLevelConditionDevicePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerAccessLevelConditionDevicePolicy | undefined;
    set internalValue(value: AccessContextManagerAccessLevelConditionDevicePolicy | undefined);
    private _allowedDeviceManagementLevels?;
    get allowedDeviceManagementLevels(): string[];
    set allowedDeviceManagementLevels(value: string[]);
    resetAllowedDeviceManagementLevels(): void;
    get allowedDeviceManagementLevelsInput(): string[] | undefined;
    private _allowedEncryptionStatuses?;
    get allowedEncryptionStatuses(): string[];
    set allowedEncryptionStatuses(value: string[]);
    resetAllowedEncryptionStatuses(): void;
    get allowedEncryptionStatusesInput(): string[] | undefined;
    private _requireAdminApproval?;
    get requireAdminApproval(): boolean | cdktn.IResolvable;
    set requireAdminApproval(value: boolean | cdktn.IResolvable);
    resetRequireAdminApproval(): void;
    get requireAdminApprovalInput(): boolean | cdktn.IResolvable | undefined;
    private _requireCorpOwned?;
    get requireCorpOwned(): boolean | cdktn.IResolvable;
    set requireCorpOwned(value: boolean | cdktn.IResolvable);
    resetRequireCorpOwned(): void;
    get requireCorpOwnedInput(): boolean | cdktn.IResolvable | undefined;
    private _requireScreenLock?;
    get requireScreenLock(): boolean | cdktn.IResolvable;
    set requireScreenLock(value: boolean | cdktn.IResolvable);
    resetRequireScreenLock(): void;
    get requireScreenLockInput(): boolean | cdktn.IResolvable | undefined;
    private _osConstraints;
    get osConstraints(): AccessContextManagerAccessLevelConditionDevicePolicyOsConstraintsList;
    putOsConstraints(value: AccessContextManagerAccessLevelConditionDevicePolicyOsConstraints[] | cdktn.IResolvable): void;
    resetOsConstraints(): void;
    get osConstraintsInput(): cdktn.IResolvable | AccessContextManagerAccessLevelConditionDevicePolicyOsConstraints[] | undefined;
}
export interface AccessContextManagerAccessLevelConditionTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level_condition#create AccessContextManagerAccessLevelCondition#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level_condition#delete AccessContextManagerAccessLevelCondition#delete}
    */
    readonly delete?: string;
}
export declare function accessContextManagerAccessLevelConditionTimeoutsToTerraform(struct?: AccessContextManagerAccessLevelConditionTimeouts | cdktn.IResolvable): any;
export declare function accessContextManagerAccessLevelConditionTimeoutsToHclTerraform(struct?: AccessContextManagerAccessLevelConditionTimeouts | cdktn.IResolvable): any;
export declare class AccessContextManagerAccessLevelConditionTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerAccessLevelConditionTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerAccessLevelConditionTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
export interface AccessContextManagerAccessLevelConditionVpcNetworkSourcesVpcSubnetwork {
    /**
    * Required. Network name to be allowed by this Access Level. Networks of foreign organizations requires 'compute.network.get' permission to be granted to caller.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level_condition#network AccessContextManagerAccessLevelCondition#network}
    */
    readonly network: string;
    /**
    * CIDR block IP subnetwork specification. Must be IPv4.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level_condition#vpc_ip_subnetworks AccessContextManagerAccessLevelCondition#vpc_ip_subnetworks}
    */
    readonly vpcIpSubnetworks?: string[];
}
export declare function accessContextManagerAccessLevelConditionVpcNetworkSourcesVpcSubnetworkToTerraform(struct?: AccessContextManagerAccessLevelConditionVpcNetworkSourcesVpcSubnetworkOutputReference | AccessContextManagerAccessLevelConditionVpcNetworkSourcesVpcSubnetwork): any;
export declare function accessContextManagerAccessLevelConditionVpcNetworkSourcesVpcSubnetworkToHclTerraform(struct?: AccessContextManagerAccessLevelConditionVpcNetworkSourcesVpcSubnetworkOutputReference | AccessContextManagerAccessLevelConditionVpcNetworkSourcesVpcSubnetwork): any;
export declare class AccessContextManagerAccessLevelConditionVpcNetworkSourcesVpcSubnetworkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerAccessLevelConditionVpcNetworkSourcesVpcSubnetwork | undefined;
    set internalValue(value: AccessContextManagerAccessLevelConditionVpcNetworkSourcesVpcSubnetwork | undefined);
    private _network?;
    get network(): string;
    set network(value: string);
    get networkInput(): string | undefined;
    private _vpcIpSubnetworks?;
    get vpcIpSubnetworks(): string[];
    set vpcIpSubnetworks(value: string[]);
    resetVpcIpSubnetworks(): void;
    get vpcIpSubnetworksInput(): string[] | undefined;
}
export interface AccessContextManagerAccessLevelConditionVpcNetworkSources {
    /**
    * vpc_subnetwork block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level_condition#vpc_subnetwork AccessContextManagerAccessLevelCondition#vpc_subnetwork}
    */
    readonly vpcSubnetwork?: AccessContextManagerAccessLevelConditionVpcNetworkSourcesVpcSubnetwork;
}
export declare function accessContextManagerAccessLevelConditionVpcNetworkSourcesToTerraform(struct?: AccessContextManagerAccessLevelConditionVpcNetworkSources | cdktn.IResolvable): any;
export declare function accessContextManagerAccessLevelConditionVpcNetworkSourcesToHclTerraform(struct?: AccessContextManagerAccessLevelConditionVpcNetworkSources | cdktn.IResolvable): any;
export declare class AccessContextManagerAccessLevelConditionVpcNetworkSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerAccessLevelConditionVpcNetworkSources | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerAccessLevelConditionVpcNetworkSources | cdktn.IResolvable | undefined);
    private _vpcSubnetwork;
    get vpcSubnetwork(): AccessContextManagerAccessLevelConditionVpcNetworkSourcesVpcSubnetworkOutputReference;
    putVpcSubnetwork(value: AccessContextManagerAccessLevelConditionVpcNetworkSourcesVpcSubnetwork): void;
    resetVpcSubnetwork(): void;
    get vpcSubnetworkInput(): AccessContextManagerAccessLevelConditionVpcNetworkSourcesVpcSubnetwork | undefined;
}
export declare class AccessContextManagerAccessLevelConditionVpcNetworkSourcesList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerAccessLevelConditionVpcNetworkSources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerAccessLevelConditionVpcNetworkSourcesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level_condition google_access_context_manager_access_level_condition}
*/
export declare class AccessContextManagerAccessLevelCondition extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_access_context_manager_access_level_condition";
    /**
    * Generates CDKTN code for importing a AccessContextManagerAccessLevelCondition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessContextManagerAccessLevelCondition to import
    * @param importFromId The id of the existing AccessContextManagerAccessLevelCondition that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level_condition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessContextManagerAccessLevelCondition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level_condition google_access_context_manager_access_level_condition} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessContextManagerAccessLevelConditionConfig
    */
    constructor(scope: Construct, id: string, config: AccessContextManagerAccessLevelConditionConfig);
    private _accessLevel?;
    get accessLevel(): string;
    set accessLevel(value: string);
    get accessLevelInput(): string | undefined;
    get accessPolicyId(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipSubnetworks?;
    get ipSubnetworks(): string[];
    set ipSubnetworks(value: string[]);
    resetIpSubnetworks(): void;
    get ipSubnetworksInput(): string[] | undefined;
    private _members?;
    get members(): string[];
    set members(value: string[]);
    resetMembers(): void;
    get membersInput(): string[] | undefined;
    private _negate?;
    get negate(): boolean | cdktn.IResolvable;
    set negate(value: boolean | cdktn.IResolvable);
    resetNegate(): void;
    get negateInput(): boolean | cdktn.IResolvable | undefined;
    private _regions?;
    get regions(): string[];
    set regions(value: string[]);
    resetRegions(): void;
    get regionsInput(): string[] | undefined;
    private _requiredAccessLevels?;
    get requiredAccessLevels(): string[];
    set requiredAccessLevels(value: string[]);
    resetRequiredAccessLevels(): void;
    get requiredAccessLevelsInput(): string[] | undefined;
    private _devicePolicy;
    get devicePolicy(): AccessContextManagerAccessLevelConditionDevicePolicyOutputReference;
    putDevicePolicy(value: AccessContextManagerAccessLevelConditionDevicePolicy): void;
    resetDevicePolicy(): void;
    get devicePolicyInput(): AccessContextManagerAccessLevelConditionDevicePolicy | undefined;
    private _timeouts;
    get timeouts(): AccessContextManagerAccessLevelConditionTimeoutsOutputReference;
    putTimeouts(value: AccessContextManagerAccessLevelConditionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AccessContextManagerAccessLevelConditionTimeouts | undefined;
    private _vpcNetworkSources;
    get vpcNetworkSources(): AccessContextManagerAccessLevelConditionVpcNetworkSourcesList;
    putVpcNetworkSources(value: AccessContextManagerAccessLevelConditionVpcNetworkSources[] | cdktn.IResolvable): void;
    resetVpcNetworkSources(): void;
    get vpcNetworkSourcesInput(): cdktn.IResolvable | AccessContextManagerAccessLevelConditionVpcNetworkSources[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
