/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChronicleFindingsRefinementConfig extends cdktn.TerraformMetaArguments {
    /**
    * Display name of the findings refinement.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_findings_refinement#display_name ChronicleFindingsRefinement#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_findings_refinement#id ChronicleFindingsRefinement#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_findings_refinement#instance ChronicleFindingsRefinement#instance}
    */
    readonly instance: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_findings_refinement#location ChronicleFindingsRefinement#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_findings_refinement#project ChronicleFindingsRefinement#project}
    */
    readonly project?: string;
    /**
    * The query for the findings refinement. Works in conjunction with the type
    * field to determine the findings refinement behavior. The syntax of this
    * query is the same as a UDM search string. See the following for more
    * information:
    * https://cloud.google.com/chronicle/docs/investigation/udm-search
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_findings_refinement#query ChronicleFindingsRefinement#query}
    */
    readonly query?: string;
    /**
    * DETECTION_EXCLUSION is the only supported type of findings refinement.
    * Possible values:
    * DETECTION_EXCLUSION
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_findings_refinement#type ChronicleFindingsRefinement#type}
    */
    readonly type?: string;
    /**
    * outcome_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_findings_refinement#outcome_filters ChronicleFindingsRefinement#outcome_filters}
    */
    readonly outcomeFilters?: ChronicleFindingsRefinementOutcomeFilters[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_findings_refinement#timeouts ChronicleFindingsRefinement#timeouts}
    */
    readonly timeouts?: ChronicleFindingsRefinementTimeouts;
}
export interface ChronicleFindingsRefinementOutcomeFilters {
    /**
    * The operator to be applied to the outcome variable.
    * Possible values:
    * EQUAL
    * CONTAINS
    * MATCHES_REGEX
    * MATCHES_CIDR
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_findings_refinement#outcome_filter_operator ChronicleFindingsRefinement#outcome_filter_operator}
    */
    readonly outcomeFilterOperator: string;
    /**
    * The value of the outcome variable to match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_findings_refinement#outcome_value ChronicleFindingsRefinement#outcome_value}
    */
    readonly outcomeValue: string;
    /**
    * The outcome variable name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_findings_refinement#outcome_variable ChronicleFindingsRefinement#outcome_variable}
    */
    readonly outcomeVariable: string;
}
export declare function chronicleFindingsRefinementOutcomeFiltersToTerraform(struct?: ChronicleFindingsRefinementOutcomeFilters | cdktn.IResolvable): any;
export declare function chronicleFindingsRefinementOutcomeFiltersToHclTerraform(struct?: ChronicleFindingsRefinementOutcomeFilters | cdktn.IResolvable): any;
export declare class ChronicleFindingsRefinementOutcomeFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleFindingsRefinementOutcomeFilters | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleFindingsRefinementOutcomeFilters | cdktn.IResolvable | undefined);
    private _outcomeFilterOperator?;
    get outcomeFilterOperator(): string;
    set outcomeFilterOperator(value: string);
    get outcomeFilterOperatorInput(): string | undefined;
    private _outcomeValue?;
    get outcomeValue(): string;
    set outcomeValue(value: string);
    get outcomeValueInput(): string | undefined;
    private _outcomeVariable?;
    get outcomeVariable(): string;
    set outcomeVariable(value: string);
    get outcomeVariableInput(): string | undefined;
}
export declare class ChronicleFindingsRefinementOutcomeFiltersList extends cdktn.ComplexList {
    internalValue?: ChronicleFindingsRefinementOutcomeFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleFindingsRefinementOutcomeFiltersOutputReference;
}
export interface ChronicleFindingsRefinementTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_findings_refinement#create ChronicleFindingsRefinement#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_findings_refinement#delete ChronicleFindingsRefinement#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_findings_refinement#update ChronicleFindingsRefinement#update}
    */
    readonly update?: string;
}
export declare function chronicleFindingsRefinementTimeoutsToTerraform(struct?: ChronicleFindingsRefinementTimeouts | cdktn.IResolvable): any;
export declare function chronicleFindingsRefinementTimeoutsToHclTerraform(struct?: ChronicleFindingsRefinementTimeouts | cdktn.IResolvable): any;
export declare class ChronicleFindingsRefinementTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleFindingsRefinementTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleFindingsRefinementTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_findings_refinement google_chronicle_findings_refinement}
*/
export declare class ChronicleFindingsRefinement extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_chronicle_findings_refinement";
    /**
    * Generates CDKTN code for importing a ChronicleFindingsRefinement resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChronicleFindingsRefinement to import
    * @param importFromId The id of the existing ChronicleFindingsRefinement that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_findings_refinement#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChronicleFindingsRefinement to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_findings_refinement google_chronicle_findings_refinement} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChronicleFindingsRefinementConfig
    */
    constructor(scope: Construct, id: string, config: ChronicleFindingsRefinementConfig);
    get createTime(): string;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instance?;
    get instance(): string;
    set instance(value: string);
    get instanceInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    get updateTime(): string;
    private _outcomeFilters;
    get outcomeFilters(): ChronicleFindingsRefinementOutcomeFiltersList;
    putOutcomeFilters(value: ChronicleFindingsRefinementOutcomeFilters[] | cdktn.IResolvable): void;
    resetOutcomeFilters(): void;
    get outcomeFiltersInput(): cdktn.IResolvable | ChronicleFindingsRefinementOutcomeFilters[] | undefined;
    private _timeouts;
    get timeouts(): ChronicleFindingsRefinementTimeoutsOutputReference;
    putTimeouts(value: ChronicleFindingsRefinementTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ChronicleFindingsRefinementTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
