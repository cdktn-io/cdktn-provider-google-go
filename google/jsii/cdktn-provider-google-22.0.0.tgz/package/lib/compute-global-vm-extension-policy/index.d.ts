/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeGlobalVmExtensionPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_global_vm_extension_policy#deletion_policy ComputeGlobalVmExtensionPolicy#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_global_vm_extension_policy#description ComputeGlobalVmExtensionPolicy#description}
    */
    readonly description?: string;
    /**
    * Name of the resource. Provided by the client when the resource is created. The name must be 1-63 characters long and match the regular expression '^[a-z]([-a-z0-9]{0,61}[a-z0-9])?$' to comply with RFC1035.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_global_vm_extension_policy#name ComputeGlobalVmExtensionPolicy#name}
    */
    readonly name: string;
    /**
    * Used to resolve conflicts when multiple policies are active. Defaults to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_global_vm_extension_policy#priority ComputeGlobalVmExtensionPolicy#priority}
    */
    readonly priority?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_global_vm_extension_policy#project ComputeGlobalVmExtensionPolicy#project}
    */
    readonly project?: string;
    /**
    * extension_policies block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_global_vm_extension_policy#extension_policies ComputeGlobalVmExtensionPolicy#extension_policies}
    */
    readonly extensionPolicies: ComputeGlobalVmExtensionPolicyExtensionPolicies[] | cdktn.IResolvable;
    /**
    * instance_selectors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_global_vm_extension_policy#instance_selectors ComputeGlobalVmExtensionPolicy#instance_selectors}
    */
    readonly instanceSelectors?: ComputeGlobalVmExtensionPolicyInstanceSelectors[] | cdktn.IResolvable;
    /**
    * rollout_operation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_global_vm_extension_policy#rollout_operation ComputeGlobalVmExtensionPolicy#rollout_operation}
    */
    readonly rolloutOperation: ComputeGlobalVmExtensionPolicyRolloutOperation;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_global_vm_extension_policy#timeouts ComputeGlobalVmExtensionPolicy#timeouts}
    */
    readonly timeouts?: ComputeGlobalVmExtensionPolicyTimeouts;
}
export interface ComputeGlobalVmExtensionPolicyExtensionPolicies {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_global_vm_extension_policy#extension_name ComputeGlobalVmExtensionPolicy#extension_name}
    */
    readonly extensionName: string;
    /**
    * The version pinning for the extension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_global_vm_extension_policy#pinned_version ComputeGlobalVmExtensionPolicy#pinned_version}
    */
    readonly pinnedVersion?: string;
    /**
    * String configuration payload.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_global_vm_extension_policy#string_config ComputeGlobalVmExtensionPolicy#string_config}
    */
    readonly stringConfig?: string;
}
export declare function computeGlobalVmExtensionPolicyExtensionPoliciesToTerraform(struct?: ComputeGlobalVmExtensionPolicyExtensionPolicies | cdktn.IResolvable): any;
export declare function computeGlobalVmExtensionPolicyExtensionPoliciesToHclTerraform(struct?: ComputeGlobalVmExtensionPolicyExtensionPolicies | cdktn.IResolvable): any;
export declare class ComputeGlobalVmExtensionPolicyExtensionPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeGlobalVmExtensionPolicyExtensionPolicies | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeGlobalVmExtensionPolicyExtensionPolicies | cdktn.IResolvable | undefined);
    private _extensionName?;
    get extensionName(): string;
    set extensionName(value: string);
    get extensionNameInput(): string | undefined;
    private _pinnedVersion?;
    get pinnedVersion(): string;
    set pinnedVersion(value: string);
    resetPinnedVersion(): void;
    get pinnedVersionInput(): string | undefined;
    private _stringConfig?;
    get stringConfig(): string;
    set stringConfig(value: string);
    resetStringConfig(): void;
    get stringConfigInput(): string | undefined;
}
export declare class ComputeGlobalVmExtensionPolicyExtensionPoliciesList extends cdktn.ComplexList {
    internalValue?: ComputeGlobalVmExtensionPolicyExtensionPolicies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeGlobalVmExtensionPolicyExtensionPoliciesOutputReference;
}
export interface ComputeGlobalVmExtensionPolicyInstanceSelectorsLabelSelector {
    /**
    * Labels as key value pairs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_global_vm_extension_policy#inclusion_labels ComputeGlobalVmExtensionPolicy#inclusion_labels}
    */
    readonly inclusionLabels?: {
        [key: string]: string;
    };
}
export declare function computeGlobalVmExtensionPolicyInstanceSelectorsLabelSelectorToTerraform(struct?: ComputeGlobalVmExtensionPolicyInstanceSelectorsLabelSelectorOutputReference | ComputeGlobalVmExtensionPolicyInstanceSelectorsLabelSelector): any;
export declare function computeGlobalVmExtensionPolicyInstanceSelectorsLabelSelectorToHclTerraform(struct?: ComputeGlobalVmExtensionPolicyInstanceSelectorsLabelSelectorOutputReference | ComputeGlobalVmExtensionPolicyInstanceSelectorsLabelSelector): any;
export declare class ComputeGlobalVmExtensionPolicyInstanceSelectorsLabelSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeGlobalVmExtensionPolicyInstanceSelectorsLabelSelector | undefined;
    set internalValue(value: ComputeGlobalVmExtensionPolicyInstanceSelectorsLabelSelector | undefined);
    private _inclusionLabels?;
    get inclusionLabels(): {
        [key: string]: string;
    };
    set inclusionLabels(value: {
        [key: string]: string;
    });
    resetInclusionLabels(): void;
    get inclusionLabelsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ComputeGlobalVmExtensionPolicyInstanceSelectors {
    /**
    * label_selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_global_vm_extension_policy#label_selector ComputeGlobalVmExtensionPolicy#label_selector}
    */
    readonly labelSelector?: ComputeGlobalVmExtensionPolicyInstanceSelectorsLabelSelector;
}
export declare function computeGlobalVmExtensionPolicyInstanceSelectorsToTerraform(struct?: ComputeGlobalVmExtensionPolicyInstanceSelectors | cdktn.IResolvable): any;
export declare function computeGlobalVmExtensionPolicyInstanceSelectorsToHclTerraform(struct?: ComputeGlobalVmExtensionPolicyInstanceSelectors | cdktn.IResolvable): any;
export declare class ComputeGlobalVmExtensionPolicyInstanceSelectorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeGlobalVmExtensionPolicyInstanceSelectors | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeGlobalVmExtensionPolicyInstanceSelectors | cdktn.IResolvable | undefined);
    private _labelSelector;
    get labelSelector(): ComputeGlobalVmExtensionPolicyInstanceSelectorsLabelSelectorOutputReference;
    putLabelSelector(value: ComputeGlobalVmExtensionPolicyInstanceSelectorsLabelSelector): void;
    resetLabelSelector(): void;
    get labelSelectorInput(): ComputeGlobalVmExtensionPolicyInstanceSelectorsLabelSelector | undefined;
}
export declare class ComputeGlobalVmExtensionPolicyInstanceSelectorsList extends cdktn.ComplexList {
    internalValue?: ComputeGlobalVmExtensionPolicyInstanceSelectors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeGlobalVmExtensionPolicyInstanceSelectorsOutputReference;
}
export interface ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusCurrentRolloutsLocationRolloutStatus {
}
export declare function computeGlobalVmExtensionPolicyRolloutOperationRolloutStatusCurrentRolloutsLocationRolloutStatusToTerraform(struct?: ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusCurrentRolloutsLocationRolloutStatus): any;
export declare function computeGlobalVmExtensionPolicyRolloutOperationRolloutStatusCurrentRolloutsLocationRolloutStatusToHclTerraform(struct?: ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusCurrentRolloutsLocationRolloutStatus): any;
export declare class ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusCurrentRolloutsLocationRolloutStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusCurrentRolloutsLocationRolloutStatus | undefined;
    set internalValue(value: ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusCurrentRolloutsLocationRolloutStatus | undefined);
    get locationName(): string;
    get state(): string;
}
export declare class ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusCurrentRolloutsLocationRolloutStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusCurrentRolloutsLocationRolloutStatusOutputReference;
}
export interface ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusCurrentRollouts {
}
export declare function computeGlobalVmExtensionPolicyRolloutOperationRolloutStatusCurrentRolloutsToTerraform(struct?: ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusCurrentRollouts): any;
export declare function computeGlobalVmExtensionPolicyRolloutOperationRolloutStatusCurrentRolloutsToHclTerraform(struct?: ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusCurrentRollouts): any;
export declare class ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusCurrentRolloutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusCurrentRollouts | undefined;
    set internalValue(value: ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusCurrentRollouts | undefined);
    private _locationRolloutStatus;
    get locationRolloutStatus(): ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusCurrentRolloutsLocationRolloutStatusList;
    get rollout(): string;
    get rolloutPlan(): string;
    get state(): string;
}
export declare class ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusCurrentRolloutsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusCurrentRolloutsOutputReference;
}
export interface ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusPreviousRolloutLocationRolloutStatus {
}
export declare function computeGlobalVmExtensionPolicyRolloutOperationRolloutStatusPreviousRolloutLocationRolloutStatusToTerraform(struct?: ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusPreviousRolloutLocationRolloutStatus): any;
export declare function computeGlobalVmExtensionPolicyRolloutOperationRolloutStatusPreviousRolloutLocationRolloutStatusToHclTerraform(struct?: ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusPreviousRolloutLocationRolloutStatus): any;
export declare class ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusPreviousRolloutLocationRolloutStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusPreviousRolloutLocationRolloutStatus | undefined;
    set internalValue(value: ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusPreviousRolloutLocationRolloutStatus | undefined);
    get locationName(): string;
    get state(): string;
}
export declare class ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusPreviousRolloutLocationRolloutStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusPreviousRolloutLocationRolloutStatusOutputReference;
}
export interface ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusPreviousRollout {
}
export declare function computeGlobalVmExtensionPolicyRolloutOperationRolloutStatusPreviousRolloutToTerraform(struct?: ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusPreviousRollout): any;
export declare function computeGlobalVmExtensionPolicyRolloutOperationRolloutStatusPreviousRolloutToHclTerraform(struct?: ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusPreviousRollout): any;
export declare class ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusPreviousRolloutOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusPreviousRollout | undefined;
    set internalValue(value: ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusPreviousRollout | undefined);
    private _locationRolloutStatus;
    get locationRolloutStatus(): ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusPreviousRolloutLocationRolloutStatusList;
    get rollout(): string;
    get rolloutPlan(): string;
    get state(): string;
}
export declare class ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusPreviousRolloutList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusPreviousRolloutOutputReference;
}
export interface ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatus {
}
export declare function computeGlobalVmExtensionPolicyRolloutOperationRolloutStatusToTerraform(struct?: ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatus): any;
export declare function computeGlobalVmExtensionPolicyRolloutOperationRolloutStatusToHclTerraform(struct?: ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatus): any;
export declare class ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatus | undefined;
    set internalValue(value: ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatus | undefined);
    private _currentRollouts;
    get currentRollouts(): ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusCurrentRolloutsList;
    private _previousRollout;
    get previousRollout(): ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusPreviousRolloutList;
}
export declare class ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusOutputReference;
}
export interface ComputeGlobalVmExtensionPolicyRolloutOperationRolloutInput {
    /**
    * Specifies the behavior of the rollout if a conflict is detected.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_global_vm_extension_policy#conflict_behavior ComputeGlobalVmExtensionPolicy#conflict_behavior}
    */
    readonly conflictBehavior?: string;
    /**
    * The name of the rollout plan.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_global_vm_extension_policy#name ComputeGlobalVmExtensionPolicy#name}
    */
    readonly name?: string;
    /**
    * Specifies the predefined rollout plan for the policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_global_vm_extension_policy#predefined_rollout_plan ComputeGlobalVmExtensionPolicy#predefined_rollout_plan}
    */
    readonly predefinedRolloutPlan?: string;
    /**
    * The UUID that identifies a policy rollout retry attempt. It should only be set when retrying an existing rollout. Updating this field along with other policy fields (description, extension_policies, instance_selectors, priority) in the same plan will return an error.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_global_vm_extension_policy#retry_uuid ComputeGlobalVmExtensionPolicy#retry_uuid}
    */
    readonly retryUuid?: string;
}
export declare function computeGlobalVmExtensionPolicyRolloutOperationRolloutInputToTerraform(struct?: ComputeGlobalVmExtensionPolicyRolloutOperationRolloutInputOutputReference | ComputeGlobalVmExtensionPolicyRolloutOperationRolloutInput): any;
export declare function computeGlobalVmExtensionPolicyRolloutOperationRolloutInputToHclTerraform(struct?: ComputeGlobalVmExtensionPolicyRolloutOperationRolloutInputOutputReference | ComputeGlobalVmExtensionPolicyRolloutOperationRolloutInput): any;
export declare class ComputeGlobalVmExtensionPolicyRolloutOperationRolloutInputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeGlobalVmExtensionPolicyRolloutOperationRolloutInput | undefined;
    set internalValue(value: ComputeGlobalVmExtensionPolicyRolloutOperationRolloutInput | undefined);
    private _conflictBehavior?;
    get conflictBehavior(): string;
    set conflictBehavior(value: string);
    resetConflictBehavior(): void;
    get conflictBehaviorInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _predefinedRolloutPlan?;
    get predefinedRolloutPlan(): string;
    set predefinedRolloutPlan(value: string);
    resetPredefinedRolloutPlan(): void;
    get predefinedRolloutPlanInput(): string | undefined;
    private _retryUuid?;
    get retryUuid(): string;
    set retryUuid(value: string);
    resetRetryUuid(): void;
    get retryUuidInput(): string | undefined;
}
export interface ComputeGlobalVmExtensionPolicyRolloutOperation {
    /**
    * rollout_input block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_global_vm_extension_policy#rollout_input ComputeGlobalVmExtensionPolicy#rollout_input}
    */
    readonly rolloutInput: ComputeGlobalVmExtensionPolicyRolloutOperationRolloutInput;
}
export declare function computeGlobalVmExtensionPolicyRolloutOperationToTerraform(struct?: ComputeGlobalVmExtensionPolicyRolloutOperationOutputReference | ComputeGlobalVmExtensionPolicyRolloutOperation): any;
export declare function computeGlobalVmExtensionPolicyRolloutOperationToHclTerraform(struct?: ComputeGlobalVmExtensionPolicyRolloutOperationOutputReference | ComputeGlobalVmExtensionPolicyRolloutOperation): any;
export declare class ComputeGlobalVmExtensionPolicyRolloutOperationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeGlobalVmExtensionPolicyRolloutOperation | undefined;
    set internalValue(value: ComputeGlobalVmExtensionPolicyRolloutOperation | undefined);
    private _rolloutStatus;
    get rolloutStatus(): ComputeGlobalVmExtensionPolicyRolloutOperationRolloutStatusList;
    private _rolloutInput;
    get rolloutInput(): ComputeGlobalVmExtensionPolicyRolloutOperationRolloutInputOutputReference;
    putRolloutInput(value: ComputeGlobalVmExtensionPolicyRolloutOperationRolloutInput): void;
    get rolloutInputInput(): ComputeGlobalVmExtensionPolicyRolloutOperationRolloutInput | undefined;
}
export interface ComputeGlobalVmExtensionPolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_global_vm_extension_policy#create ComputeGlobalVmExtensionPolicy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_global_vm_extension_policy#delete ComputeGlobalVmExtensionPolicy#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_global_vm_extension_policy#update ComputeGlobalVmExtensionPolicy#update}
    */
    readonly update?: string;
}
export declare function computeGlobalVmExtensionPolicyTimeoutsToTerraform(struct?: ComputeGlobalVmExtensionPolicyTimeouts | cdktn.IResolvable): any;
export declare function computeGlobalVmExtensionPolicyTimeoutsToHclTerraform(struct?: ComputeGlobalVmExtensionPolicyTimeouts | cdktn.IResolvable): any;
export declare class ComputeGlobalVmExtensionPolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeGlobalVmExtensionPolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeGlobalVmExtensionPolicyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_global_vm_extension_policy google_compute_global_vm_extension_policy}
*/
export declare class ComputeGlobalVmExtensionPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_global_vm_extension_policy";
    /**
    * Generates CDKTN code for importing a ComputeGlobalVmExtensionPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeGlobalVmExtensionPolicy to import
    * @param importFromId The id of the existing ComputeGlobalVmExtensionPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_global_vm_extension_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeGlobalVmExtensionPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_global_vm_extension_policy google_compute_global_vm_extension_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeGlobalVmExtensionPolicyConfig
    */
    constructor(scope: Construct, id: string, config: ComputeGlobalVmExtensionPolicyConfig);
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get kind(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get scopedResourceStatus(): string;
    get selfLink(): string;
    get updateTimestamp(): string;
    private _extensionPolicies;
    get extensionPolicies(): ComputeGlobalVmExtensionPolicyExtensionPoliciesList;
    putExtensionPolicies(value: ComputeGlobalVmExtensionPolicyExtensionPolicies[] | cdktn.IResolvable): void;
    get extensionPoliciesInput(): cdktn.IResolvable | ComputeGlobalVmExtensionPolicyExtensionPolicies[] | undefined;
    private _instanceSelectors;
    get instanceSelectors(): ComputeGlobalVmExtensionPolicyInstanceSelectorsList;
    putInstanceSelectors(value: ComputeGlobalVmExtensionPolicyInstanceSelectors[] | cdktn.IResolvable): void;
    resetInstanceSelectors(): void;
    get instanceSelectorsInput(): cdktn.IResolvable | ComputeGlobalVmExtensionPolicyInstanceSelectors[] | undefined;
    private _rolloutOperation;
    get rolloutOperation(): ComputeGlobalVmExtensionPolicyRolloutOperationOutputReference;
    putRolloutOperation(value: ComputeGlobalVmExtensionPolicyRolloutOperation): void;
    get rolloutOperationInput(): ComputeGlobalVmExtensionPolicyRolloutOperation | undefined;
    private _timeouts;
    get timeouts(): ComputeGlobalVmExtensionPolicyTimeoutsOutputReference;
    putTimeouts(value: ComputeGlobalVmExtensionPolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeGlobalVmExtensionPolicyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
