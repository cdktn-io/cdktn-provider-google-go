/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BigqueryAnalyticsHubListingSubscriptionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the data exchange. Must contain only Unicode letters, numbers (0-9), underscores (_). Should not use characters that require URL-escaping, or characters outside of ASCII, spaces.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#data_exchange_id BigqueryAnalyticsHubListingSubscription#data_exchange_id}
    */
    readonly dataExchangeId: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#deletion_policy BigqueryAnalyticsHubListingSubscription#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#id BigqueryAnalyticsHubListingSubscription#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the listing. Must contain only Unicode letters, numbers (0-9), underscores (_). Should not use characters that require URL-escaping, or characters outside of ASCII, spaces.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#listing_id BigqueryAnalyticsHubListingSubscription#listing_id}
    */
    readonly listingId: string;
    /**
    * The name of the location of the data exchange. Distinct from the location of the destination data set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#location BigqueryAnalyticsHubListingSubscription#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#project BigqueryAnalyticsHubListingSubscription#project}
    */
    readonly project?: string;
    /**
    * destination_dataset block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#destination_dataset BigqueryAnalyticsHubListingSubscription#destination_dataset}
    */
    readonly destinationDataset?: BigqueryAnalyticsHubListingSubscriptionDestinationDataset;
    /**
    * destination_pubsub_subscription block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#destination_pubsub_subscription BigqueryAnalyticsHubListingSubscription#destination_pubsub_subscription}
    */
    readonly destinationPubsubSubscription?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscription;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#timeouts BigqueryAnalyticsHubListingSubscription#timeouts}
    */
    readonly timeouts?: BigqueryAnalyticsHubListingSubscriptionTimeouts;
}
export interface BigqueryAnalyticsHubListingSubscriptionCommercialInfoCloudMarketplace {
}
export declare function bigqueryAnalyticsHubListingSubscriptionCommercialInfoCloudMarketplaceToTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionCommercialInfoCloudMarketplace): any;
export declare function bigqueryAnalyticsHubListingSubscriptionCommercialInfoCloudMarketplaceToHclTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionCommercialInfoCloudMarketplace): any;
export declare class BigqueryAnalyticsHubListingSubscriptionCommercialInfoCloudMarketplaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BigqueryAnalyticsHubListingSubscriptionCommercialInfoCloudMarketplace | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingSubscriptionCommercialInfoCloudMarketplace | undefined);
    get order(): string;
}
export declare class BigqueryAnalyticsHubListingSubscriptionCommercialInfoCloudMarketplaceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BigqueryAnalyticsHubListingSubscriptionCommercialInfoCloudMarketplaceOutputReference;
}
export interface BigqueryAnalyticsHubListingSubscriptionCommercialInfo {
}
export declare function bigqueryAnalyticsHubListingSubscriptionCommercialInfoToTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionCommercialInfo): any;
export declare function bigqueryAnalyticsHubListingSubscriptionCommercialInfoToHclTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionCommercialInfo): any;
export declare class BigqueryAnalyticsHubListingSubscriptionCommercialInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BigqueryAnalyticsHubListingSubscriptionCommercialInfo | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingSubscriptionCommercialInfo | undefined);
    private _cloudMarketplace;
    get cloudMarketplace(): BigqueryAnalyticsHubListingSubscriptionCommercialInfoCloudMarketplaceList;
}
export declare class BigqueryAnalyticsHubListingSubscriptionCommercialInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BigqueryAnalyticsHubListingSubscriptionCommercialInfoOutputReference;
}
export interface BigqueryAnalyticsHubListingSubscriptionLinkedDatasetMap {
}
export declare function bigqueryAnalyticsHubListingSubscriptionLinkedDatasetMapToTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionLinkedDatasetMap): any;
export declare function bigqueryAnalyticsHubListingSubscriptionLinkedDatasetMapToHclTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionLinkedDatasetMap): any;
export declare class BigqueryAnalyticsHubListingSubscriptionLinkedDatasetMapOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BigqueryAnalyticsHubListingSubscriptionLinkedDatasetMap | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingSubscriptionLinkedDatasetMap | undefined);
    get linkedDataset(): string;
    get linkedPubsubSubscription(): string;
    get listing(): string;
    get resourceName(): string;
}
export declare class BigqueryAnalyticsHubListingSubscriptionLinkedDatasetMapList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BigqueryAnalyticsHubListingSubscriptionLinkedDatasetMapOutputReference;
}
export interface BigqueryAnalyticsHubListingSubscriptionLinkedResources {
}
export declare function bigqueryAnalyticsHubListingSubscriptionLinkedResourcesToTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionLinkedResources): any;
export declare function bigqueryAnalyticsHubListingSubscriptionLinkedResourcesToHclTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionLinkedResources): any;
export declare class BigqueryAnalyticsHubListingSubscriptionLinkedResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BigqueryAnalyticsHubListingSubscriptionLinkedResources | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingSubscriptionLinkedResources | undefined);
    get linkedDataset(): string;
    get linkedPubsubSubscription(): string;
    get listing(): string;
}
export declare class BigqueryAnalyticsHubListingSubscriptionLinkedResourcesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BigqueryAnalyticsHubListingSubscriptionLinkedResourcesOutputReference;
}
export interface BigqueryAnalyticsHubListingSubscriptionDestinationDatasetDatasetReference {
    /**
    * A unique ID for this dataset, without the project name. The ID must contain only letters (a-z, A-Z), numbers (0-9), or underscores (_). The maximum length is 1,024 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#dataset_id BigqueryAnalyticsHubListingSubscription#dataset_id}
    */
    readonly datasetId: string;
    /**
    * The ID of the project containing this dataset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#project_id BigqueryAnalyticsHubListingSubscription#project_id}
    */
    readonly projectId: string;
}
export declare function bigqueryAnalyticsHubListingSubscriptionDestinationDatasetDatasetReferenceToTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionDestinationDatasetDatasetReferenceOutputReference | BigqueryAnalyticsHubListingSubscriptionDestinationDatasetDatasetReference): any;
export declare function bigqueryAnalyticsHubListingSubscriptionDestinationDatasetDatasetReferenceToHclTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionDestinationDatasetDatasetReferenceOutputReference | BigqueryAnalyticsHubListingSubscriptionDestinationDatasetDatasetReference): any;
export declare class BigqueryAnalyticsHubListingSubscriptionDestinationDatasetDatasetReferenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryAnalyticsHubListingSubscriptionDestinationDatasetDatasetReference | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingSubscriptionDestinationDatasetDatasetReference | undefined);
    private _datasetId?;
    get datasetId(): string;
    set datasetId(value: string);
    get datasetIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
}
export interface BigqueryAnalyticsHubListingSubscriptionDestinationDataset {
    /**
    * A user-friendly description of the dataset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#description BigqueryAnalyticsHubListingSubscription#description}
    */
    readonly description?: string;
    /**
    * A descriptive name for the dataset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#friendly_name BigqueryAnalyticsHubListingSubscription#friendly_name}
    */
    readonly friendlyName?: string;
    /**
    * The labels associated with this dataset. You can use these to
    * organize and group your datasets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#labels BigqueryAnalyticsHubListingSubscription#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The geographic location where the dataset should reside.
    * See https://cloud.google.com/bigquery/docs/locations for supported locations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#location BigqueryAnalyticsHubListingSubscription#location}
    */
    readonly location: string;
    /**
    * List of regions where the subscriber wants dataset replicas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#replica_locations BigqueryAnalyticsHubListingSubscription#replica_locations}
    */
    readonly replicaLocations?: string[];
    /**
    * dataset_reference block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#dataset_reference BigqueryAnalyticsHubListingSubscription#dataset_reference}
    */
    readonly datasetReference: BigqueryAnalyticsHubListingSubscriptionDestinationDatasetDatasetReference;
}
export declare function bigqueryAnalyticsHubListingSubscriptionDestinationDatasetToTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionDestinationDatasetOutputReference | BigqueryAnalyticsHubListingSubscriptionDestinationDataset): any;
export declare function bigqueryAnalyticsHubListingSubscriptionDestinationDatasetToHclTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionDestinationDatasetOutputReference | BigqueryAnalyticsHubListingSubscriptionDestinationDataset): any;
export declare class BigqueryAnalyticsHubListingSubscriptionDestinationDatasetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryAnalyticsHubListingSubscriptionDestinationDataset | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingSubscriptionDestinationDataset | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _friendlyName?;
    get friendlyName(): string;
    set friendlyName(value: string);
    resetFriendlyName(): void;
    get friendlyNameInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _replicaLocations?;
    get replicaLocations(): string[];
    set replicaLocations(value: string[]);
    resetReplicaLocations(): void;
    get replicaLocationsInput(): string[] | undefined;
    private _datasetReference;
    get datasetReference(): BigqueryAnalyticsHubListingSubscriptionDestinationDatasetDatasetReferenceOutputReference;
    putDatasetReference(value: BigqueryAnalyticsHubListingSubscriptionDestinationDatasetDatasetReference): void;
    get datasetReferenceInput(): BigqueryAnalyticsHubListingSubscriptionDestinationDatasetDatasetReference | undefined;
}
export interface BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionBigqueryConfig {
    /**
    * When true and 'useTopicSchema' is true, any fields that are a part of the topic schema that are
    * not part of the BigQuery table schema are dropped when writing to BigQuery. Otherwise, the schemas
    * must be kept in sync and any messages with extra fields are not written and remain in the
    * subscription's backlog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#drop_unknown_fields BigqueryAnalyticsHubListingSubscription#drop_unknown_fields}
    */
    readonly dropUnknownFields?: boolean | cdktn.IResolvable;
    /**
    * The service account to use to write to BigQuery. The subscription creator or updater that
    * specifies this field must have 'iam.serviceAccounts.actAs' permission on the service account.
    * If not specified, the Pub/Sub service agent,
    * service-{project_number}@gcp-sa-pubsub.iam.gserviceaccount.com, is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#service_account_email BigqueryAnalyticsHubListingSubscription#service_account_email}
    */
    readonly serviceAccountEmail?: string;
    /**
    * The name of the table to which to write data, of the form
    * {projectId}.{datasetId}.{tableId}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#table BigqueryAnalyticsHubListingSubscription#table}
    */
    readonly table?: string;
    /**
    * When true, use the BigQuery table's schema as the columns to write to in BigQuery.
    * 'useTableSchema' and 'useTopicSchema' cannot be enabled at the same time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#use_table_schema BigqueryAnalyticsHubListingSubscription#use_table_schema}
    */
    readonly useTableSchema?: boolean | cdktn.IResolvable;
    /**
    * When true, use the topic's schema as the columns to write to in BigQuery,
    * if it exists. 'useTopicSchema' and 'useTableSchema' cannot be enabled at the same time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#use_topic_schema BigqueryAnalyticsHubListingSubscription#use_topic_schema}
    */
    readonly useTopicSchema?: boolean | cdktn.IResolvable;
    /**
    * When true, write the subscription name, message_id, publish_time, attributes, and ordering_key
    * to additional columns in the table. The subscription name, message_id, and publish_time fields
    * are put in their own columns while all other message properties (other than data) are written
    * to a JSON object in the attributes column.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#write_metadata BigqueryAnalyticsHubListingSubscription#write_metadata}
    */
    readonly writeMetadata?: boolean | cdktn.IResolvable;
}
export declare function bigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionBigqueryConfigToTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionBigqueryConfigOutputReference | BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionBigqueryConfig): any;
export declare function bigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionBigqueryConfigToHclTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionBigqueryConfigOutputReference | BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionBigqueryConfig): any;
export declare class BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionBigqueryConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionBigqueryConfig | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionBigqueryConfig | undefined);
    private _dropUnknownFields?;
    get dropUnknownFields(): boolean | cdktn.IResolvable;
    set dropUnknownFields(value: boolean | cdktn.IResolvable);
    resetDropUnknownFields(): void;
    get dropUnknownFieldsInput(): boolean | cdktn.IResolvable | undefined;
    private _serviceAccountEmail?;
    get serviceAccountEmail(): string;
    set serviceAccountEmail(value: string);
    resetServiceAccountEmail(): void;
    get serviceAccountEmailInput(): string | undefined;
    private _table?;
    get table(): string;
    set table(value: string);
    resetTable(): void;
    get tableInput(): string | undefined;
    private _useTableSchema?;
    get useTableSchema(): boolean | cdktn.IResolvable;
    set useTableSchema(value: boolean | cdktn.IResolvable);
    resetUseTableSchema(): void;
    get useTableSchemaInput(): boolean | cdktn.IResolvable | undefined;
    private _useTopicSchema?;
    get useTopicSchema(): boolean | cdktn.IResolvable;
    set useTopicSchema(value: boolean | cdktn.IResolvable);
    resetUseTopicSchema(): void;
    get useTopicSchemaInput(): boolean | cdktn.IResolvable | undefined;
    private _writeMetadata?;
    get writeMetadata(): boolean | cdktn.IResolvable;
    set writeMetadata(value: boolean | cdktn.IResolvable);
    resetWriteMetadata(): void;
    get writeMetadataInput(): boolean | cdktn.IResolvable | undefined;
}
export interface BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfigAvroConfig {
    /**
    * When true, the output Cloud Storage file will be serialized using
    * the topic schema, if it exists.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#use_topic_schema BigqueryAnalyticsHubListingSubscription#use_topic_schema}
    */
    readonly useTopicSchema?: boolean | cdktn.IResolvable;
    /**
    * When true, write the subscription name, message_id, publish_time, attributes, and ordering_key
    * as additional fields in the output. The subscription name, message_id, and publish_time fields
    * are put in their own fields while all other message properties other than data (for example,
    * an ordering_key, if present) are added as entries in the attributes map.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#write_metadata BigqueryAnalyticsHubListingSubscription#write_metadata}
    */
    readonly writeMetadata?: boolean | cdktn.IResolvable;
}
export declare function bigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfigAvroConfigToTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfigAvroConfigOutputReference | BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfigAvroConfig): any;
export declare function bigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfigAvroConfigToHclTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfigAvroConfigOutputReference | BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfigAvroConfig): any;
export declare class BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfigAvroConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfigAvroConfig | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfigAvroConfig | undefined);
    private _useTopicSchema?;
    get useTopicSchema(): boolean | cdktn.IResolvable;
    set useTopicSchema(value: boolean | cdktn.IResolvable);
    resetUseTopicSchema(): void;
    get useTopicSchemaInput(): boolean | cdktn.IResolvable | undefined;
    private _writeMetadata?;
    get writeMetadata(): boolean | cdktn.IResolvable;
    set writeMetadata(value: boolean | cdktn.IResolvable);
    resetWriteMetadata(): void;
    get writeMetadataInput(): boolean | cdktn.IResolvable | undefined;
}
export interface BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfig {
    /**
    * User-provided name for the Cloud Storage bucket. The bucket must be created by the user.
    * The bucket name must be without any prefix like "gs://". See the
    * [bucket naming requirements](https://cloud.google.com/storage/docs/buckets#naming).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#bucket BigqueryAnalyticsHubListingSubscription#bucket}
    */
    readonly bucket?: string;
    /**
    * User-provided format string specifying how to represent datetimes in Cloud Storage filenames.
    * See the [datetime format guidance](https://cloud.google.com/pubsub/docs/create-cloudstorage-subscription#file_names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#filename_datetime_format BigqueryAnalyticsHubListingSubscription#filename_datetime_format}
    */
    readonly filenameDatetimeFormat?: string;
    /**
    * User-provided prefix for Cloud Storage filename. See the
    * [object naming requirements](https://cloud.google.com/storage/docs/objects#naming).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#filename_prefix BigqueryAnalyticsHubListingSubscription#filename_prefix}
    */
    readonly filenamePrefix?: string;
    /**
    * User-provided suffix for Cloud Storage filename. See the
    * [object naming requirements](https://cloud.google.com/storage/docs/objects#naming).
    * Must not end in "/".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#filename_suffix BigqueryAnalyticsHubListingSubscription#filename_suffix}
    */
    readonly filenameSuffix?: string;
    /**
    * The maximum bytes that can be written to a Cloud Storage file before a new file is created.
    * Min 1 KB, max 10 GiB. The maxBytes limit may be exceeded in cases where messages are larger
    * than the limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#max_bytes BigqueryAnalyticsHubListingSubscription#max_bytes}
    */
    readonly maxBytes?: string;
    /**
    * The maximum duration that can elapse before a new Cloud Storage file is created.
    * Min 1 minute, max 10 minutes, default 5 minutes. May not exceed the subscription's
    * acknowledgement deadline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#max_duration BigqueryAnalyticsHubListingSubscription#max_duration}
    */
    readonly maxDuration?: string;
    /**
    * The maximum number of messages that can be written to a Cloud Storage file before a new file
    * is created. Min 1000 messages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#max_messages BigqueryAnalyticsHubListingSubscription#max_messages}
    */
    readonly maxMessages?: string;
    /**
    * The service account to use to write to Cloud Storage. The subscription creator or updater that
    * specifies this field must have 'iam.serviceAccounts.actAs' permission on the service account.
    * If not specified, the Pub/Sub service agent,
    * service-{project_number}@gcp-sa-pubsub.iam.gserviceaccount.com, is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#service_account_email BigqueryAnalyticsHubListingSubscription#service_account_email}
    */
    readonly serviceAccountEmail?: string;
    /**
    * avro_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#avro_config BigqueryAnalyticsHubListingSubscription#avro_config}
    */
    readonly avroConfig?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfigAvroConfig;
}
export declare function bigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfigToTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfigOutputReference | BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfig): any;
export declare function bigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfigToHclTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfigOutputReference | BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfig): any;
export declare class BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfig | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfig | undefined);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    resetBucket(): void;
    get bucketInput(): string | undefined;
    private _filenameDatetimeFormat?;
    get filenameDatetimeFormat(): string;
    set filenameDatetimeFormat(value: string);
    resetFilenameDatetimeFormat(): void;
    get filenameDatetimeFormatInput(): string | undefined;
    private _filenamePrefix?;
    get filenamePrefix(): string;
    set filenamePrefix(value: string);
    resetFilenamePrefix(): void;
    get filenamePrefixInput(): string | undefined;
    private _filenameSuffix?;
    get filenameSuffix(): string;
    set filenameSuffix(value: string);
    resetFilenameSuffix(): void;
    get filenameSuffixInput(): string | undefined;
    private _maxBytes?;
    get maxBytes(): string;
    set maxBytes(value: string);
    resetMaxBytes(): void;
    get maxBytesInput(): string | undefined;
    private _maxDuration?;
    get maxDuration(): string;
    set maxDuration(value: string);
    resetMaxDuration(): void;
    get maxDurationInput(): string | undefined;
    private _maxMessages?;
    get maxMessages(): string;
    set maxMessages(value: string);
    resetMaxMessages(): void;
    get maxMessagesInput(): string | undefined;
    private _serviceAccountEmail?;
    get serviceAccountEmail(): string;
    set serviceAccountEmail(value: string);
    resetServiceAccountEmail(): void;
    get serviceAccountEmailInput(): string | undefined;
    private _avroConfig;
    get avroConfig(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfigAvroConfigOutputReference;
    putAvroConfig(value: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfigAvroConfig): void;
    resetAvroConfig(): void;
    get avroConfigInput(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfigAvroConfig | undefined;
}
export interface BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionDeadLetterPolicy {
    /**
    * The name of the topic to which dead letter messages should be published. Format is
    * 'projects/{project}/topics/{topic}'. The Pub/Sub service account associated with the enclosing
    * subscription's parent project (i.e., service-{project_number}@gcp-sa-pubsub.iam.gserviceaccount.com)
    * must have permission to Publish() to this topic. The operation will fail if the topic does not exist.
    * Users should ensure that there is a subscription attached to this topic since messages published to
    * a topic with no subscriptions are lost.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#dead_letter_topic BigqueryAnalyticsHubListingSubscription#dead_letter_topic}
    */
    readonly deadLetterTopic?: string;
    /**
    * The maximum number of delivery attempts for any message. The value must be between 5 and 100.
    * The number of delivery attempts is defined as 1 + (the sum of number of NACKs and number of times
    * the acknowledgement deadline has been exceeded for the message). A NACK is any call to
    * ModifyAckDeadline with a 0 deadline. Note that client libraries may automatically extend
    * ack_deadlines. This field will be honored on a best effort basis. If this parameter is 0, a
    * default value of 5 is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#max_delivery_attempts BigqueryAnalyticsHubListingSubscription#max_delivery_attempts}
    */
    readonly maxDeliveryAttempts?: number;
}
export declare function bigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionDeadLetterPolicyToTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionDeadLetterPolicyOutputReference | BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionDeadLetterPolicy): any;
export declare function bigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionDeadLetterPolicyToHclTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionDeadLetterPolicyOutputReference | BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionDeadLetterPolicy): any;
export declare class BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionDeadLetterPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionDeadLetterPolicy | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionDeadLetterPolicy | undefined);
    private _deadLetterTopic?;
    get deadLetterTopic(): string;
    set deadLetterTopic(value: string);
    resetDeadLetterTopic(): void;
    get deadLetterTopicInput(): string | undefined;
    private _maxDeliveryAttempts?;
    get maxDeliveryAttempts(): number;
    set maxDeliveryAttempts(value: number);
    resetMaxDeliveryAttempts(): void;
    get maxDeliveryAttemptsInput(): number | undefined;
}
export interface BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionExpirationPolicy {
    /**
    * Specifies the "time-to-live" duration for an associated resource. The resource expires if it
    * is not active for a period of 'ttl'. The definition of "activity" depends on the type of the
    * associated resource. The minimum and maximum allowed values for 'ttl' depend on the type of
    * the associated resource, as well. If 'ttl' is not set, the associated resource never expires.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#ttl BigqueryAnalyticsHubListingSubscription#ttl}
    */
    readonly ttl?: string;
}
export declare function bigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionExpirationPolicyToTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionExpirationPolicyOutputReference | BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionExpirationPolicy): any;
export declare function bigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionExpirationPolicyToHclTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionExpirationPolicyOutputReference | BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionExpirationPolicy): any;
export declare class BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionExpirationPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionExpirationPolicy | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionExpirationPolicy | undefined);
    private _ttl?;
    get ttl(): string;
    set ttl(value: string);
    resetTtl(): void;
    get ttlInput(): string | undefined;
}
export interface BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigNoWrapper {
    /**
    * When true, writes the Pub/Sub message metadata to 'x-goog-pubsub-<KEY>:<VAL>' headers of the
    * HTTP request. Writes the Pub/Sub message attributes to '<KEY>:<VAL>' headers of the HTTP request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#write_metadata BigqueryAnalyticsHubListingSubscription#write_metadata}
    */
    readonly writeMetadata?: boolean | cdktn.IResolvable;
}
export declare function bigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigNoWrapperToTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigNoWrapperOutputReference | BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigNoWrapper): any;
export declare function bigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigNoWrapperToHclTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigNoWrapperOutputReference | BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigNoWrapper): any;
export declare class BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigNoWrapperOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigNoWrapper | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigNoWrapper | undefined);
    private _writeMetadata?;
    get writeMetadata(): boolean | cdktn.IResolvable;
    set writeMetadata(value: boolean | cdktn.IResolvable);
    resetWriteMetadata(): void;
    get writeMetadataInput(): boolean | cdktn.IResolvable | undefined;
}
export interface BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigOidcToken {
    /**
    * Audience to be used when generating OIDC token. The audience claim identifies the recipients
    * that the JWT is intended for. The audience value is a single case-sensitive string. Having
    * multiple values (array) for the audience field is not supported. More info about the OIDC JWT
    * token audience here: https://tools.ietf.org/html/rfc7519#section-4.1.3 Note: if not specified,
    * the Push endpoint URL will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#audience BigqueryAnalyticsHubListingSubscription#audience}
    */
    readonly audience?: string;
    /**
    * Service account email used for generating the OIDC token. For more information
    * on setting up authentication, see Push subscriptions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#service_account_email BigqueryAnalyticsHubListingSubscription#service_account_email}
    */
    readonly serviceAccountEmail?: string;
}
export declare function bigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigOidcTokenToTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigOidcTokenOutputReference | BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigOidcToken): any;
export declare function bigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigOidcTokenToHclTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigOidcTokenOutputReference | BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigOidcToken): any;
export declare class BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigOidcTokenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigOidcToken | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigOidcToken | undefined);
    private _audience?;
    get audience(): string;
    set audience(value: string);
    resetAudience(): void;
    get audienceInput(): string | undefined;
    private _serviceAccountEmail?;
    get serviceAccountEmail(): string;
    set serviceAccountEmail(value: string);
    resetServiceAccountEmail(): void;
    get serviceAccountEmailInput(): string | undefined;
}
export interface BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfig {
    /**
    * Endpoint configuration attributes that can be used to control different aspects of the message delivery.
    * The only currently supported attribute is 'x-goog-version', which you can use to change the format of the
    * pushed message. This attribute indicates the version of the data expected by the endpoint. This controls
    * the shape of the pushed message (i.e., its fields and metadata). If not present during the
    * 'CreateSubscription' call, it will default to the version of the Pub/Sub API used to make such call.
    * If not present in a 'ModifyPushConfig' call, its value will not be changed. 'GetSubscription' calls
    * will always return a valid version, even if the subscription was created without this attribute.
    * The only supported values for the 'x-goog-version' attribute are: 'v1beta1': uses the push format
    * defined in the v1beta1 Pub/Sub API. 'v1' or 'v1beta2': uses the push format defined in the v1 Pub/Sub API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#attributes BigqueryAnalyticsHubListingSubscription#attributes}
    */
    readonly attributes?: {
        [key: string]: string;
    };
    /**
    * A URL locating the endpoint to which messages should be pushed.
    * For example, a Webhook endpoint might use 'https://example.com/push'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#push_endpoint BigqueryAnalyticsHubListingSubscription#push_endpoint}
    */
    readonly pushEndpoint?: string;
    /**
    * no_wrapper block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#no_wrapper BigqueryAnalyticsHubListingSubscription#no_wrapper}
    */
    readonly noWrapper?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigNoWrapper;
    /**
    * oidc_token block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#oidc_token BigqueryAnalyticsHubListingSubscription#oidc_token}
    */
    readonly oidcToken?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigOidcToken;
}
export declare function bigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigToTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigOutputReference | BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfig): any;
export declare function bigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigToHclTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigOutputReference | BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfig): any;
export declare class BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfig | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfig | undefined);
    private _attributes?;
    get attributes(): {
        [key: string]: string;
    };
    set attributes(value: {
        [key: string]: string;
    });
    resetAttributes(): void;
    get attributesInput(): {
        [key: string]: string;
    } | undefined;
    private _pushEndpoint?;
    get pushEndpoint(): string;
    set pushEndpoint(value: string);
    resetPushEndpoint(): void;
    get pushEndpointInput(): string | undefined;
    private _noWrapper;
    get noWrapper(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigNoWrapperOutputReference;
    putNoWrapper(value: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigNoWrapper): void;
    resetNoWrapper(): void;
    get noWrapperInput(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigNoWrapper | undefined;
    private _oidcToken;
    get oidcToken(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigOidcTokenOutputReference;
    putOidcToken(value: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigOidcToken): void;
    resetOidcToken(): void;
    get oidcTokenInput(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigOidcToken | undefined;
}
export interface BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionRetryPolicy {
    /**
    * The maximum delay between consecutive deliveries of a given message.
    * Value should be between 0 and 600 seconds. Defaults to 600 seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#maximum_backoff BigqueryAnalyticsHubListingSubscription#maximum_backoff}
    */
    readonly maximumBackoff?: string;
    /**
    * The minimum delay between consecutive deliveries of a given message.
    * Value should be between 0 and 600 seconds. Defaults to 10 seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#minimum_backoff BigqueryAnalyticsHubListingSubscription#minimum_backoff}
    */
    readonly minimumBackoff?: string;
}
export declare function bigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionRetryPolicyToTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionRetryPolicyOutputReference | BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionRetryPolicy): any;
export declare function bigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionRetryPolicyToHclTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionRetryPolicyOutputReference | BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionRetryPolicy): any;
export declare class BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionRetryPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionRetryPolicy | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionRetryPolicy | undefined);
    private _maximumBackoff?;
    get maximumBackoff(): string;
    set maximumBackoff(value: string);
    resetMaximumBackoff(): void;
    get maximumBackoffInput(): string | undefined;
    private _minimumBackoff?;
    get minimumBackoff(): string;
    set minimumBackoff(value: string);
    resetMinimumBackoff(): void;
    get minimumBackoffInput(): string | undefined;
}
export interface BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscription {
    /**
    * The approximate amount of time (on a best-effort basis) Pub/Sub waits for the subscriber to
    * acknowledge receipt before resending the message. In the interval after the message is delivered
    * and before it is acknowledged, it is considered to be outstanding. During that time period, the
    * message will not be redelivered (on a best-effort basis). For pull subscriptions, this value is
    * used as the initial value for the ack deadline. To override this value for a given message, call
    * 'ModifyAckDeadline' with the corresponding 'ack_id' if using non-streaming pull or send the
    * 'ack_id' in a 'StreamingModifyAckDeadlineRequest' if using streaming pull. The minimum custom
    * deadline you can specify is 10 seconds. The maximum custom deadline you can specify is 600
    * seconds (10 minutes). If this parameter is 0, a default value of 10 seconds is used. For push
    * delivery, this value is also used to set the request timeout for the call to the push endpoint.
    * If the subscriber never acknowledges the message, the Pub/Sub system will eventually redeliver
    * the message.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#ack_deadline_seconds BigqueryAnalyticsHubListingSubscription#ack_deadline_seconds}
    */
    readonly ackDeadlineSeconds?: number;
    /**
    * Indicates whether the subscription is detached from its topic. Detached subscriptions don't
    * receive messages from their topic and don't retain any backlog. 'Pull' and 'StreamingPull'
    * requests will return FAILED_PRECONDITION. If the subscription is a push subscription, pushes
    * to the endpoint will not be made.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#detached BigqueryAnalyticsHubListingSubscription#detached}
    */
    readonly detached?: boolean | cdktn.IResolvable;
    /**
    * If true, Pub/Sub provides the following guarantees for the delivery of a message with a given
    * value of 'message_id' on this subscription: The message sent to a subscriber is guaranteed not
    * to be resent before the message's acknowledgement deadline expires. An acknowledged message will
    * not be resent to a subscriber. Note that subscribers may still receive multiple copies of a
    * message when 'enableExactlyOnceDelivery' is true if the message was published multiple times by
    * a publisher client. These copies are considered distinct by Pub/Sub and have distinct 'message_id'
    * values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#enable_exactly_once_delivery BigqueryAnalyticsHubListingSubscription#enable_exactly_once_delivery}
    */
    readonly enableExactlyOnceDelivery?: boolean | cdktn.IResolvable;
    /**
    * If true, messages published with the same 'ordering_key' in 'PubsubMessage'
    * will be delivered to the subscribers in the order in which they are received
    * by the Pub/Sub system. Otherwise, they may be delivered in any order.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#enable_message_ordering BigqueryAnalyticsHubListingSubscription#enable_message_ordering}
    */
    readonly enableMessageOrdering?: boolean | cdktn.IResolvable;
    /**
    * An expression written in the Pub/Sub filter language. If non-empty, then only 'PubsubMessage's
    * whose 'attributes' field matches the filter are delivered on this subscription. If empty, then
    * no messages are filtered out.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#filter BigqueryAnalyticsHubListingSubscription#filter}
    */
    readonly filter?: string;
    /**
    * See [Creating and managing labels](https://cloud.google.com/pubsub/docs/labels).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#labels BigqueryAnalyticsHubListingSubscription#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * How long to retain unacknowledged messages in the subscription's backlog, from the moment a
    * message is published. If 'retainAckedMessages' is true, then this also configures the retention
    * of acknowledged messages, and thus configures how far back in time a Seek can be done. Defaults
    * to 7 days. Cannot be more than 31 days or less than 10 minutes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#message_retention_duration BigqueryAnalyticsHubListingSubscription#message_retention_duration}
    */
    readonly messageRetentionDuration?: string;
    /**
    * Name of the subscription. Format is 'projects/{project}/subscriptions/{sub}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#name BigqueryAnalyticsHubListingSubscription#name}
    */
    readonly name: string;
    /**
    * Indicates whether to retain acknowledged messages. If true, then messages are not expunged from
    * the subscription's backlog, even if they are acknowledged, until they fall out of the
    * 'messageRetentionDuration' window. This must be true if you would like to Seek to a timestamp
    * in the past to replay previously-acknowledged messages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#retain_acked_messages BigqueryAnalyticsHubListingSubscription#retain_acked_messages}
    */
    readonly retainAckedMessages?: boolean | cdktn.IResolvable;
    /**
    * bigquery_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#bigquery_config BigqueryAnalyticsHubListingSubscription#bigquery_config}
    */
    readonly bigqueryConfig?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionBigqueryConfig;
    /**
    * cloud_storage_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#cloud_storage_config BigqueryAnalyticsHubListingSubscription#cloud_storage_config}
    */
    readonly cloudStorageConfig?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfig;
    /**
    * dead_letter_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#dead_letter_policy BigqueryAnalyticsHubListingSubscription#dead_letter_policy}
    */
    readonly deadLetterPolicy?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionDeadLetterPolicy;
    /**
    * expiration_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#expiration_policy BigqueryAnalyticsHubListingSubscription#expiration_policy}
    */
    readonly expirationPolicy?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionExpirationPolicy;
    /**
    * push_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#push_config BigqueryAnalyticsHubListingSubscription#push_config}
    */
    readonly pushConfig?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfig;
    /**
    * retry_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#retry_policy BigqueryAnalyticsHubListingSubscription#retry_policy}
    */
    readonly retryPolicy?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionRetryPolicy;
}
export declare function bigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionToTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionOutputReference | BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscription): any;
export declare function bigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionToHclTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionOutputReference | BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscription): any;
export declare class BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscription | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscription | undefined);
    private _ackDeadlineSeconds?;
    get ackDeadlineSeconds(): number;
    set ackDeadlineSeconds(value: number);
    resetAckDeadlineSeconds(): void;
    get ackDeadlineSecondsInput(): number | undefined;
    private _detached?;
    get detached(): boolean | cdktn.IResolvable;
    set detached(value: boolean | cdktn.IResolvable);
    resetDetached(): void;
    get detachedInput(): boolean | cdktn.IResolvable | undefined;
    private _enableExactlyOnceDelivery?;
    get enableExactlyOnceDelivery(): boolean | cdktn.IResolvable;
    set enableExactlyOnceDelivery(value: boolean | cdktn.IResolvable);
    resetEnableExactlyOnceDelivery(): void;
    get enableExactlyOnceDeliveryInput(): boolean | cdktn.IResolvable | undefined;
    private _enableMessageOrdering?;
    get enableMessageOrdering(): boolean | cdktn.IResolvable;
    set enableMessageOrdering(value: boolean | cdktn.IResolvable);
    resetEnableMessageOrdering(): void;
    get enableMessageOrderingInput(): boolean | cdktn.IResolvable | undefined;
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _messageRetentionDuration?;
    get messageRetentionDuration(): string;
    set messageRetentionDuration(value: string);
    resetMessageRetentionDuration(): void;
    get messageRetentionDurationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _retainAckedMessages?;
    get retainAckedMessages(): boolean | cdktn.IResolvable;
    set retainAckedMessages(value: boolean | cdktn.IResolvable);
    resetRetainAckedMessages(): void;
    get retainAckedMessagesInput(): boolean | cdktn.IResolvable | undefined;
    private _bigqueryConfig;
    get bigqueryConfig(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionBigqueryConfigOutputReference;
    putBigqueryConfig(value: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionBigqueryConfig): void;
    resetBigqueryConfig(): void;
    get bigqueryConfigInput(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionBigqueryConfig | undefined;
    private _cloudStorageConfig;
    get cloudStorageConfig(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfigOutputReference;
    putCloudStorageConfig(value: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfig): void;
    resetCloudStorageConfig(): void;
    get cloudStorageConfigInput(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionCloudStorageConfig | undefined;
    private _deadLetterPolicy;
    get deadLetterPolicy(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionDeadLetterPolicyOutputReference;
    putDeadLetterPolicy(value: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionDeadLetterPolicy): void;
    resetDeadLetterPolicy(): void;
    get deadLetterPolicyInput(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionDeadLetterPolicy | undefined;
    private _expirationPolicy;
    get expirationPolicy(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionExpirationPolicyOutputReference;
    putExpirationPolicy(value: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionExpirationPolicy): void;
    resetExpirationPolicy(): void;
    get expirationPolicyInput(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionExpirationPolicy | undefined;
    private _pushConfig;
    get pushConfig(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfigOutputReference;
    putPushConfig(value: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfig): void;
    resetPushConfig(): void;
    get pushConfigInput(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionPushConfig | undefined;
    private _retryPolicy;
    get retryPolicy(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionRetryPolicyOutputReference;
    putRetryPolicy(value: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionRetryPolicy): void;
    resetRetryPolicy(): void;
    get retryPolicyInput(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionRetryPolicy | undefined;
}
export interface BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscription {
    /**
    * pubsub_subscription block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#pubsub_subscription BigqueryAnalyticsHubListingSubscription#pubsub_subscription}
    */
    readonly pubsubSubscription: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscription;
}
export declare function bigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionToTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionOutputReference | BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscription): any;
export declare function bigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionToHclTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionOutputReference | BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscription): any;
export declare class BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscription | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscription | undefined);
    private _pubsubSubscription;
    get pubsubSubscription(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscriptionOutputReference;
    putPubsubSubscription(value: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscription): void;
    get pubsubSubscriptionInput(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionPubsubSubscription | undefined;
}
export interface BigqueryAnalyticsHubListingSubscriptionTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#create BigqueryAnalyticsHubListingSubscription#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#delete BigqueryAnalyticsHubListingSubscription#delete}
    */
    readonly delete?: string;
}
export declare function bigqueryAnalyticsHubListingSubscriptionTimeoutsToTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionTimeouts | cdktn.IResolvable): any;
export declare function bigqueryAnalyticsHubListingSubscriptionTimeoutsToHclTerraform(struct?: BigqueryAnalyticsHubListingSubscriptionTimeouts | cdktn.IResolvable): any;
export declare class BigqueryAnalyticsHubListingSubscriptionTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryAnalyticsHubListingSubscriptionTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BigqueryAnalyticsHubListingSubscriptionTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription google_bigquery_analytics_hub_listing_subscription}
*/
export declare class BigqueryAnalyticsHubListingSubscription extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_bigquery_analytics_hub_listing_subscription";
    /**
    * Generates CDKTN code for importing a BigqueryAnalyticsHubListingSubscription resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BigqueryAnalyticsHubListingSubscription to import
    * @param importFromId The id of the existing BigqueryAnalyticsHubListingSubscription that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BigqueryAnalyticsHubListingSubscription to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_analytics_hub_listing_subscription google_bigquery_analytics_hub_listing_subscription} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BigqueryAnalyticsHubListingSubscriptionConfig
    */
    constructor(scope: Construct, id: string, config: BigqueryAnalyticsHubListingSubscriptionConfig);
    private _commercialInfo;
    get commercialInfo(): BigqueryAnalyticsHubListingSubscriptionCommercialInfoList;
    get creationTime(): string;
    private _dataExchangeId?;
    get dataExchangeId(): string;
    set dataExchangeId(value: string);
    get dataExchangeIdInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastModifyTime(): string;
    private _linkedDatasetMap;
    get linkedDatasetMap(): BigqueryAnalyticsHubListingSubscriptionLinkedDatasetMapList;
    private _linkedResources;
    get linkedResources(): BigqueryAnalyticsHubListingSubscriptionLinkedResourcesList;
    private _listingId?;
    get listingId(): string;
    set listingId(value: string);
    get listingIdInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get logLinkedDatasetQueryUserEmail(): cdktn.IResolvable;
    get name(): string;
    get organizationDisplayName(): string;
    get organizationId(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get resourceType(): string;
    get state(): string;
    get subscriberContact(): string;
    get subscriptionId(): string;
    private _destinationDataset;
    get destinationDataset(): BigqueryAnalyticsHubListingSubscriptionDestinationDatasetOutputReference;
    putDestinationDataset(value: BigqueryAnalyticsHubListingSubscriptionDestinationDataset): void;
    resetDestinationDataset(): void;
    get destinationDatasetInput(): BigqueryAnalyticsHubListingSubscriptionDestinationDataset | undefined;
    private _destinationPubsubSubscription;
    get destinationPubsubSubscription(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscriptionOutputReference;
    putDestinationPubsubSubscription(value: BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscription): void;
    resetDestinationPubsubSubscription(): void;
    get destinationPubsubSubscriptionInput(): BigqueryAnalyticsHubListingSubscriptionDestinationPubsubSubscription | undefined;
    private _timeouts;
    get timeouts(): BigqueryAnalyticsHubListingSubscriptionTimeoutsOutputReference;
    putTimeouts(value: BigqueryAnalyticsHubListingSubscriptionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BigqueryAnalyticsHubListingSubscriptionTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
