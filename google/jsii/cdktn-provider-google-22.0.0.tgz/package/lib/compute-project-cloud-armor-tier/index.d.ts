/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeProjectCloudArmorTierConfig extends cdktn.TerraformMetaArguments {
    /**
    * Managed protection tier to be set. Possible values: ["CA_STANDARD", "CA_ENTERPRISE_PAYGO", "CA_ENTERPRISE_ANNUAL"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_project_cloud_armor_tier#cloud_armor_tier ComputeProjectCloudArmorTier#cloud_armor_tier}
    */
    readonly cloudArmorTier: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_project_cloud_armor_tier#deletion_policy ComputeProjectCloudArmorTier#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_project_cloud_armor_tier#id ComputeProjectCloudArmorTier#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_project_cloud_armor_tier#project ComputeProjectCloudArmorTier#project}
    */
    readonly project?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_project_cloud_armor_tier#timeouts ComputeProjectCloudArmorTier#timeouts}
    */
    readonly timeouts?: ComputeProjectCloudArmorTierTimeouts;
}
export interface ComputeProjectCloudArmorTierTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_project_cloud_armor_tier#create ComputeProjectCloudArmorTier#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_project_cloud_armor_tier#delete ComputeProjectCloudArmorTier#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_project_cloud_armor_tier#update ComputeProjectCloudArmorTier#update}
    */
    readonly update?: string;
}
export declare function computeProjectCloudArmorTierTimeoutsToTerraform(struct?: ComputeProjectCloudArmorTierTimeouts | cdktn.IResolvable): any;
export declare function computeProjectCloudArmorTierTimeoutsToHclTerraform(struct?: ComputeProjectCloudArmorTierTimeouts | cdktn.IResolvable): any;
export declare class ComputeProjectCloudArmorTierTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeProjectCloudArmorTierTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeProjectCloudArmorTierTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_project_cloud_armor_tier google_compute_project_cloud_armor_tier}
*/
export declare class ComputeProjectCloudArmorTier extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_project_cloud_armor_tier";
    /**
    * Generates CDKTN code for importing a ComputeProjectCloudArmorTier resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeProjectCloudArmorTier to import
    * @param importFromId The id of the existing ComputeProjectCloudArmorTier that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_project_cloud_armor_tier#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeProjectCloudArmorTier to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_project_cloud_armor_tier google_compute_project_cloud_armor_tier} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeProjectCloudArmorTierConfig
    */
    constructor(scope: Construct, id: string, config: ComputeProjectCloudArmorTierConfig);
    private _cloudArmorTier?;
    get cloudArmorTier(): string;
    set cloudArmorTier(value: string);
    get cloudArmorTierInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _timeouts;
    get timeouts(): ComputeProjectCloudArmorTierTimeoutsOutputReference;
    putTimeouts(value: ComputeProjectCloudArmorTierTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeProjectCloudArmorTierTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
