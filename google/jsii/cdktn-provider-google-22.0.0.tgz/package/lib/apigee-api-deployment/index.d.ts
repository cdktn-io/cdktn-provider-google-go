/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigeeApiDeploymentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_api_deployment#deletion_policy ApigeeApiDeployment#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The Apigee Environment associated with the Apigee API deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_api_deployment#environment ApigeeApiDeployment#environment}
    */
    readonly environment: string;
    /**
    * The Apigee Organization associated with the Apigee API deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_api_deployment#org_id ApigeeApiDeployment#org_id}
    */
    readonly orgId: string;
    /**
    * The Apigee API associated with the Apigee API deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_api_deployment#proxy_id ApigeeApiDeployment#proxy_id}
    */
    readonly proxyId: string;
    /**
    * The revision of the API proxy to be deployed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_api_deployment#revision ApigeeApiDeployment#revision}
    */
    readonly revision: string;
    /**
    * The Google Cloud IAM service account to use as the identity for the deployed proxy. The format must be '{ACCOUNT_ID}@{PROJECT}.iam.gserviceaccount.com'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_api_deployment#service_account ApigeeApiDeployment#service_account}
    */
    readonly serviceAccount?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_api_deployment#timeouts ApigeeApiDeployment#timeouts}
    */
    readonly timeouts?: ApigeeApiDeploymentTimeouts;
}
export interface ApigeeApiDeploymentTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_api_deployment#create ApigeeApiDeployment#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_api_deployment#delete ApigeeApiDeployment#delete}
    */
    readonly delete?: string;
}
export declare function apigeeApiDeploymentTimeoutsToTerraform(struct?: ApigeeApiDeploymentTimeouts | cdktn.IResolvable): any;
export declare function apigeeApiDeploymentTimeoutsToHclTerraform(struct?: ApigeeApiDeploymentTimeouts | cdktn.IResolvable): any;
export declare class ApigeeApiDeploymentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeApiDeploymentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeApiDeploymentTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_api_deployment google_apigee_api_deployment}
*/
export declare class ApigeeApiDeployment extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apigee_api_deployment";
    /**
    * Generates CDKTN code for importing a ApigeeApiDeployment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigeeApiDeployment to import
    * @param importFromId The id of the existing ApigeeApiDeployment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_api_deployment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigeeApiDeployment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_api_deployment google_apigee_api_deployment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigeeApiDeploymentConfig
    */
    constructor(scope: Construct, id: string, config: ApigeeApiDeploymentConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _environment?;
    get environment(): string;
    set environment(value: string);
    get environmentInput(): string | undefined;
    get id(): string;
    private _orgId?;
    get orgId(): string;
    set orgId(value: string);
    get orgIdInput(): string | undefined;
    private _proxyId?;
    get proxyId(): string;
    set proxyId(value: string);
    get proxyIdInput(): string | undefined;
    private _revision?;
    get revision(): string;
    set revision(value: string);
    get revisionInput(): string | undefined;
    private _serviceAccount?;
    get serviceAccount(): string;
    set serviceAccount(value: string);
    resetServiceAccount(): void;
    get serviceAccountInput(): string | undefined;
    private _timeouts;
    get timeouts(): ApigeeApiDeploymentTimeoutsOutputReference;
    putTimeouts(value: ApigeeApiDeploymentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApigeeApiDeploymentTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
