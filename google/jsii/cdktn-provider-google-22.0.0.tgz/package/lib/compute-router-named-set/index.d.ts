/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeRouterNamedSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_named_set#deletion_policy ComputeRouterNamedSet#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of the Named Set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_named_set#description ComputeRouterNamedSet#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_named_set#id ComputeRouterNamedSet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the Named Set, which must be a resource ID segment and unique
    * within all named sets owned by the Router.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_named_set#name ComputeRouterNamedSet#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_named_set#project ComputeRouterNamedSet#project}
    */
    readonly project?: string;
    /**
    * Region where the router resides.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_named_set#region ComputeRouterNamedSet#region}
    */
    readonly region?: string;
    /**
    * The name of the Cloud Router in which this Named Set will be configured.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_named_set#router ComputeRouterNamedSet#router}
    */
    readonly router: string;
    /**
    * The type of the Named Set. Possible values: ["NAMED_SET_TYPE_PREFIX", "NAMED_SET_TYPE_COMMUNITY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_named_set#type ComputeRouterNamedSet#type}
    */
    readonly type: string;
    /**
    * elements block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_named_set#elements ComputeRouterNamedSet#elements}
    */
    readonly elements?: ComputeRouterNamedSetElements[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_named_set#timeouts ComputeRouterNamedSet#timeouts}
    */
    readonly timeouts?: ComputeRouterNamedSetTimeouts;
}
export interface ComputeRouterNamedSetElements {
    /**
    * Description of the expression.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_named_set#description ComputeRouterNamedSet#description}
    */
    readonly description?: string;
    /**
    * Textual representation of an expression in Common Expression Language syntax.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_named_set#expression ComputeRouterNamedSet#expression}
    */
    readonly expression: string;
    /**
    * String indicating the location of the expression for error reporting, e.g. a file name and a position in the file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_named_set#location ComputeRouterNamedSet#location}
    */
    readonly location?: string;
    /**
    * Title for the expression, i.e. a short string describing its purpose.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_named_set#title ComputeRouterNamedSet#title}
    */
    readonly title?: string;
}
export declare function computeRouterNamedSetElementsToTerraform(struct?: ComputeRouterNamedSetElements | cdktn.IResolvable): any;
export declare function computeRouterNamedSetElementsToHclTerraform(struct?: ComputeRouterNamedSetElements | cdktn.IResolvable): any;
export declare class ComputeRouterNamedSetElementsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRouterNamedSetElements | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRouterNamedSetElements | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
}
export declare class ComputeRouterNamedSetElementsList extends cdktn.ComplexList {
    internalValue?: ComputeRouterNamedSetElements[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRouterNamedSetElementsOutputReference;
}
export interface ComputeRouterNamedSetTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_named_set#create ComputeRouterNamedSet#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_named_set#delete ComputeRouterNamedSet#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_named_set#update ComputeRouterNamedSet#update}
    */
    readonly update?: string;
}
export declare function computeRouterNamedSetTimeoutsToTerraform(struct?: ComputeRouterNamedSetTimeouts | cdktn.IResolvable): any;
export declare function computeRouterNamedSetTimeoutsToHclTerraform(struct?: ComputeRouterNamedSetTimeouts | cdktn.IResolvable): any;
export declare class ComputeRouterNamedSetTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRouterNamedSetTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRouterNamedSetTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_named_set google_compute_router_named_set}
*/
export declare class ComputeRouterNamedSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_router_named_set";
    /**
    * Generates CDKTN code for importing a ComputeRouterNamedSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeRouterNamedSet to import
    * @param importFromId The id of the existing ComputeRouterNamedSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_named_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeRouterNamedSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_named_set google_compute_router_named_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeRouterNamedSetConfig
    */
    constructor(scope: Construct, id: string, config: ComputeRouterNamedSetConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get fingerprint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _router?;
    get router(): string;
    set router(value: string);
    get routerInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _elements;
    get elements(): ComputeRouterNamedSetElementsList;
    putElements(value: ComputeRouterNamedSetElements[] | cdktn.IResolvable): void;
    resetElements(): void;
    get elementsInput(): cdktn.IResolvable | ComputeRouterNamedSetElements[] | undefined;
    private _timeouts;
    get timeouts(): ComputeRouterNamedSetTimeoutsOutputReference;
    putTimeouts(value: ComputeRouterNamedSetTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeRouterNamedSetTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
