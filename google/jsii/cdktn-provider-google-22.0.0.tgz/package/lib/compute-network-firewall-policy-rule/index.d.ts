/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeNetworkFirewallPolicyRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Action to perform when the client connection triggers the rule. Valid actions are "allow", "deny", "goto_next" and "apply_security_profile_group".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#action ComputeNetworkFirewallPolicyRule#action}
    */
    readonly action: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#deletion_policy ComputeNetworkFirewallPolicyRule#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description for this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#description ComputeNetworkFirewallPolicyRule#description}
    */
    readonly description?: string;
    /**
    * The direction in which this rule applies. Possible values: ["INGRESS", "EGRESS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#direction ComputeNetworkFirewallPolicyRule#direction}
    */
    readonly direction: string;
    /**
    * Denotes whether the firewall policy rule is disabled.
    * When set to true, the firewall policy rule is not enforced and traffic behaves as if it did not exist.
    * If this is unspecified, the firewall policy rule will be enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#disabled ComputeNetworkFirewallPolicyRule#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Denotes whether to enable logging for a particular rule.
    * If logging is enabled, logs will be exported to the configured export destination in Stackdriver.
    * Logs may be exported to BigQuery or Pub/Sub.
    * Note: you cannot enable logging on "goto_next" rules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#enable_logging ComputeNetworkFirewallPolicyRule#enable_logging}
    */
    readonly enableLogging?: boolean | cdktn.IResolvable;
    /**
    * The firewall policy of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#firewall_policy ComputeNetworkFirewallPolicyRule#firewall_policy}
    */
    readonly firewallPolicy: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#id ComputeNetworkFirewallPolicyRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * An integer indicating the priority of a rule in the list.
    * The priority must be a positive value between 0 and 2147483647.
    * Rules are evaluated from highest to lowest priority where 0 is the highest priority and 2147483647 is the lowest prority.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#priority ComputeNetworkFirewallPolicyRule#priority}
    */
    readonly priority: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#project ComputeNetworkFirewallPolicyRule#project}
    */
    readonly project?: string;
    /**
    * An optional name for the rule. This field is not a unique identifier and can be updated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#rule_name ComputeNetworkFirewallPolicyRule#rule_name}
    */
    readonly ruleName?: string;
    /**
    * A fully-qualified URL of a SecurityProfile resource instance.
    * Example: https://networksecurity.googleapis.com/v1/projects/{project}/locations/{location}/securityProfileGroups/my-security-profile-group
    * Must be specified if action = 'apply_security_profile_group' and cannot be specified for other actions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#security_profile_group ComputeNetworkFirewallPolicyRule#security_profile_group}
    */
    readonly securityProfileGroup?: string;
    /**
    * A list of forwarding rules to which this rule applies.
    * This field allows you to control which load balancers get this rule.
    * For example, the following are valid values:
    * - https://www.googleapis.com/compute/v1/projects/project/global/forwardingRules/forwardingRule
    * - https://www.googleapis.com/compute/v1/projects/project/regions/region/forwardingRules/forwardingRule
    * - projects/project/global/forwardingRules/forwardingRule
    * - projects/project/regions/region/forwardingRules/forwardingRule
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#target_forwarding_rules ComputeNetworkFirewallPolicyRule#target_forwarding_rules}
    */
    readonly targetForwardingRules?: string[];
    /**
    * A list of service accounts indicating the sets of instances that are applied with this rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#target_service_accounts ComputeNetworkFirewallPolicyRule#target_service_accounts}
    */
    readonly targetServiceAccounts?: string[];
    /**
    * Target types of the firewall policy rule.
    * Default value is INSTANCES.
    * When target_type is INTERNAL_MANAGED_LB, target_forwarding_rules must be set Possible values: ["INSTANCES", "INTERNAL_MANAGED_LB"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#target_type ComputeNetworkFirewallPolicyRule#target_type}
    */
    readonly targetType?: string;
    /**
    * Boolean flag indicating if the traffic should be TLS decrypted.
    * Can be set only if action = 'apply_security_profile_group' and cannot be set for other actions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#tls_inspect ComputeNetworkFirewallPolicyRule#tls_inspect}
    */
    readonly tlsInspect?: boolean | cdktn.IResolvable;
    /**
    * match block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#match ComputeNetworkFirewallPolicyRule#match}
    */
    readonly match: ComputeNetworkFirewallPolicyRuleMatch;
    /**
    * target_secure_tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#target_secure_tags ComputeNetworkFirewallPolicyRule#target_secure_tags}
    */
    readonly targetSecureTags?: ComputeNetworkFirewallPolicyRuleTargetSecureTags[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#timeouts ComputeNetworkFirewallPolicyRule#timeouts}
    */
    readonly timeouts?: ComputeNetworkFirewallPolicyRuleTimeouts;
}
export interface ComputeNetworkFirewallPolicyRuleMatchLayer4Configs {
    /**
    * The IP protocol to which this rule applies. The protocol type is required when creating a firewall rule.
    * This value can either be one of the following well known protocol strings (tcp, udp, icmp, esp, ah, ipip, sctp), or the IP protocol number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#ip_protocol ComputeNetworkFirewallPolicyRule#ip_protocol}
    */
    readonly ipProtocol: string;
    /**
    * An optional list of ports to which this rule applies. This field is only applicable for UDP or TCP protocol. Each entry must be either an integer or a range. If not specified, this rule applies to connections through any port.
    * Example inputs include: ["22"], ["80","443"], and ["12345-12349"].
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#ports ComputeNetworkFirewallPolicyRule#ports}
    */
    readonly ports?: string[];
}
export declare function computeNetworkFirewallPolicyRuleMatchLayer4ConfigsToTerraform(struct?: ComputeNetworkFirewallPolicyRuleMatchLayer4Configs | cdktn.IResolvable): any;
export declare function computeNetworkFirewallPolicyRuleMatchLayer4ConfigsToHclTerraform(struct?: ComputeNetworkFirewallPolicyRuleMatchLayer4Configs | cdktn.IResolvable): any;
export declare class ComputeNetworkFirewallPolicyRuleMatchLayer4ConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeNetworkFirewallPolicyRuleMatchLayer4Configs | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeNetworkFirewallPolicyRuleMatchLayer4Configs | cdktn.IResolvable | undefined);
    private _ipProtocol?;
    get ipProtocol(): string;
    set ipProtocol(value: string);
    get ipProtocolInput(): string | undefined;
    private _ports?;
    get ports(): string[];
    set ports(value: string[]);
    resetPorts(): void;
    get portsInput(): string[] | undefined;
}
export declare class ComputeNetworkFirewallPolicyRuleMatchLayer4ConfigsList extends cdktn.ComplexList {
    internalValue?: ComputeNetworkFirewallPolicyRuleMatchLayer4Configs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeNetworkFirewallPolicyRuleMatchLayer4ConfigsOutputReference;
}
export interface ComputeNetworkFirewallPolicyRuleMatchSrcSecureTags {
    /**
    * Name of the secure tag, created with TagManager's TagValue API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#name ComputeNetworkFirewallPolicyRule#name}
    */
    readonly name?: string;
}
export declare function computeNetworkFirewallPolicyRuleMatchSrcSecureTagsToTerraform(struct?: ComputeNetworkFirewallPolicyRuleMatchSrcSecureTags | cdktn.IResolvable): any;
export declare function computeNetworkFirewallPolicyRuleMatchSrcSecureTagsToHclTerraform(struct?: ComputeNetworkFirewallPolicyRuleMatchSrcSecureTags | cdktn.IResolvable): any;
export declare class ComputeNetworkFirewallPolicyRuleMatchSrcSecureTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeNetworkFirewallPolicyRuleMatchSrcSecureTags | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeNetworkFirewallPolicyRuleMatchSrcSecureTags | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get state(): string;
}
export declare class ComputeNetworkFirewallPolicyRuleMatchSrcSecureTagsList extends cdktn.ComplexList {
    internalValue?: ComputeNetworkFirewallPolicyRuleMatchSrcSecureTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeNetworkFirewallPolicyRuleMatchSrcSecureTagsOutputReference;
}
export interface ComputeNetworkFirewallPolicyRuleMatch {
    /**
    * Address groups which should be matched against the traffic destination. Maximum number of destination address groups is 10.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#dest_address_groups ComputeNetworkFirewallPolicyRule#dest_address_groups}
    */
    readonly destAddressGroups?: string[];
    /**
    * Fully Qualified Domain Name (FQDN) which should be matched against traffic destination. Maximum number of destination fqdn allowed is 100.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#dest_fqdns ComputeNetworkFirewallPolicyRule#dest_fqdns}
    */
    readonly destFqdns?: string[];
    /**
    * CIDR IP address range. Maximum number of destination CIDR IP ranges allowed is 5000.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#dest_ip_ranges ComputeNetworkFirewallPolicyRule#dest_ip_ranges}
    */
    readonly destIpRanges?: string[];
    /**
    * Network context of the traffic destination. Possible values: ["UNSPECIFIED", "INTERNET", "INTRA_VPC", "NON_INTERNET", "VPC_NETWORKS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#dest_network_context ComputeNetworkFirewallPolicyRule#dest_network_context}
    */
    readonly destNetworkContext?: string;
    /**
    * Region codes whose IP addresses will be used to match for destination of traffic. Should be specified as 2 letter country code defined as per ISO 3166 alpha-2 country codes. ex."US" Maximum number of dest region codes allowed is 5000.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#dest_region_codes ComputeNetworkFirewallPolicyRule#dest_region_codes}
    */
    readonly destRegionCodes?: string[];
    /**
    * Names of Network Threat Intelligence lists. The IPs in these lists will be matched against traffic destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#dest_threat_intelligences ComputeNetworkFirewallPolicyRule#dest_threat_intelligences}
    */
    readonly destThreatIntelligences?: string[];
    /**
    * Address groups which should be matched against the traffic source. Maximum number of source address groups is 10.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#src_address_groups ComputeNetworkFirewallPolicyRule#src_address_groups}
    */
    readonly srcAddressGroups?: string[];
    /**
    * Fully Qualified Domain Name (FQDN) which should be matched against traffic source. Maximum number of source fqdn allowed is 100.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#src_fqdns ComputeNetworkFirewallPolicyRule#src_fqdns}
    */
    readonly srcFqdns?: string[];
    /**
    * CIDR IP address range. Maximum number of source CIDR IP ranges allowed is 5000.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#src_ip_ranges ComputeNetworkFirewallPolicyRule#src_ip_ranges}
    */
    readonly srcIpRanges?: string[];
    /**
    * Network context of the traffic source. Possible values: ["UNSPECIFIED", "INTERNET", "INTRA_VPC", "NON_INTERNET", "VPC_NETWORKS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#src_network_context ComputeNetworkFirewallPolicyRule#src_network_context}
    */
    readonly srcNetworkContext?: string;
    /**
    * Networks of the traffic source. It can be either a full or partial url.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#src_networks ComputeNetworkFirewallPolicyRule#src_networks}
    */
    readonly srcNetworks?: string[];
    /**
    * Region codes whose IP addresses will be used to match for source of traffic. Should be specified as 2 letter country code defined as per ISO 3166 alpha-2 country codes. ex."US" Maximum number of source region codes allowed is 5000.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#src_region_codes ComputeNetworkFirewallPolicyRule#src_region_codes}
    */
    readonly srcRegionCodes?: string[];
    /**
    * Names of Network Threat Intelligence lists. The IPs in these lists will be matched against traffic source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#src_threat_intelligences ComputeNetworkFirewallPolicyRule#src_threat_intelligences}
    */
    readonly srcThreatIntelligences?: string[];
    /**
    * layer4_configs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#layer4_configs ComputeNetworkFirewallPolicyRule#layer4_configs}
    */
    readonly layer4Configs: ComputeNetworkFirewallPolicyRuleMatchLayer4Configs[] | cdktn.IResolvable;
    /**
    * src_secure_tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#src_secure_tags ComputeNetworkFirewallPolicyRule#src_secure_tags}
    */
    readonly srcSecureTags?: ComputeNetworkFirewallPolicyRuleMatchSrcSecureTags[] | cdktn.IResolvable;
}
export declare function computeNetworkFirewallPolicyRuleMatchToTerraform(struct?: ComputeNetworkFirewallPolicyRuleMatchOutputReference | ComputeNetworkFirewallPolicyRuleMatch): any;
export declare function computeNetworkFirewallPolicyRuleMatchToHclTerraform(struct?: ComputeNetworkFirewallPolicyRuleMatchOutputReference | ComputeNetworkFirewallPolicyRuleMatch): any;
export declare class ComputeNetworkFirewallPolicyRuleMatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeNetworkFirewallPolicyRuleMatch | undefined;
    set internalValue(value: ComputeNetworkFirewallPolicyRuleMatch | undefined);
    private _destAddressGroups?;
    get destAddressGroups(): string[];
    set destAddressGroups(value: string[]);
    resetDestAddressGroups(): void;
    get destAddressGroupsInput(): string[] | undefined;
    private _destFqdns?;
    get destFqdns(): string[];
    set destFqdns(value: string[]);
    resetDestFqdns(): void;
    get destFqdnsInput(): string[] | undefined;
    private _destIpRanges?;
    get destIpRanges(): string[];
    set destIpRanges(value: string[]);
    resetDestIpRanges(): void;
    get destIpRangesInput(): string[] | undefined;
    private _destNetworkContext?;
    get destNetworkContext(): string;
    set destNetworkContext(value: string);
    resetDestNetworkContext(): void;
    get destNetworkContextInput(): string | undefined;
    private _destRegionCodes?;
    get destRegionCodes(): string[];
    set destRegionCodes(value: string[]);
    resetDestRegionCodes(): void;
    get destRegionCodesInput(): string[] | undefined;
    private _destThreatIntelligences?;
    get destThreatIntelligences(): string[];
    set destThreatIntelligences(value: string[]);
    resetDestThreatIntelligences(): void;
    get destThreatIntelligencesInput(): string[] | undefined;
    private _srcAddressGroups?;
    get srcAddressGroups(): string[];
    set srcAddressGroups(value: string[]);
    resetSrcAddressGroups(): void;
    get srcAddressGroupsInput(): string[] | undefined;
    private _srcFqdns?;
    get srcFqdns(): string[];
    set srcFqdns(value: string[]);
    resetSrcFqdns(): void;
    get srcFqdnsInput(): string[] | undefined;
    private _srcIpRanges?;
    get srcIpRanges(): string[];
    set srcIpRanges(value: string[]);
    resetSrcIpRanges(): void;
    get srcIpRangesInput(): string[] | undefined;
    private _srcNetworkContext?;
    get srcNetworkContext(): string;
    set srcNetworkContext(value: string);
    resetSrcNetworkContext(): void;
    get srcNetworkContextInput(): string | undefined;
    private _srcNetworks?;
    get srcNetworks(): string[];
    set srcNetworks(value: string[]);
    resetSrcNetworks(): void;
    get srcNetworksInput(): string[] | undefined;
    private _srcRegionCodes?;
    get srcRegionCodes(): string[];
    set srcRegionCodes(value: string[]);
    resetSrcRegionCodes(): void;
    get srcRegionCodesInput(): string[] | undefined;
    private _srcThreatIntelligences?;
    get srcThreatIntelligences(): string[];
    set srcThreatIntelligences(value: string[]);
    resetSrcThreatIntelligences(): void;
    get srcThreatIntelligencesInput(): string[] | undefined;
    private _layer4Configs;
    get layer4Configs(): ComputeNetworkFirewallPolicyRuleMatchLayer4ConfigsList;
    putLayer4Configs(value: ComputeNetworkFirewallPolicyRuleMatchLayer4Configs[] | cdktn.IResolvable): void;
    get layer4ConfigsInput(): cdktn.IResolvable | ComputeNetworkFirewallPolicyRuleMatchLayer4Configs[] | undefined;
    private _srcSecureTags;
    get srcSecureTags(): ComputeNetworkFirewallPolicyRuleMatchSrcSecureTagsList;
    putSrcSecureTags(value: ComputeNetworkFirewallPolicyRuleMatchSrcSecureTags[] | cdktn.IResolvable): void;
    resetSrcSecureTags(): void;
    get srcSecureTagsInput(): cdktn.IResolvable | ComputeNetworkFirewallPolicyRuleMatchSrcSecureTags[] | undefined;
}
export interface ComputeNetworkFirewallPolicyRuleTargetSecureTags {
    /**
    * Name of the secure tag, created with TagManager's TagValue API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#name ComputeNetworkFirewallPolicyRule#name}
    */
    readonly name?: string;
}
export declare function computeNetworkFirewallPolicyRuleTargetSecureTagsToTerraform(struct?: ComputeNetworkFirewallPolicyRuleTargetSecureTags | cdktn.IResolvable): any;
export declare function computeNetworkFirewallPolicyRuleTargetSecureTagsToHclTerraform(struct?: ComputeNetworkFirewallPolicyRuleTargetSecureTags | cdktn.IResolvable): any;
export declare class ComputeNetworkFirewallPolicyRuleTargetSecureTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeNetworkFirewallPolicyRuleTargetSecureTags | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeNetworkFirewallPolicyRuleTargetSecureTags | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get state(): string;
}
export declare class ComputeNetworkFirewallPolicyRuleTargetSecureTagsList extends cdktn.ComplexList {
    internalValue?: ComputeNetworkFirewallPolicyRuleTargetSecureTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeNetworkFirewallPolicyRuleTargetSecureTagsOutputReference;
}
export interface ComputeNetworkFirewallPolicyRuleTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#create ComputeNetworkFirewallPolicyRule#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#delete ComputeNetworkFirewallPolicyRule#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#update ComputeNetworkFirewallPolicyRule#update}
    */
    readonly update?: string;
}
export declare function computeNetworkFirewallPolicyRuleTimeoutsToTerraform(struct?: ComputeNetworkFirewallPolicyRuleTimeouts | cdktn.IResolvable): any;
export declare function computeNetworkFirewallPolicyRuleTimeoutsToHclTerraform(struct?: ComputeNetworkFirewallPolicyRuleTimeouts | cdktn.IResolvable): any;
export declare class ComputeNetworkFirewallPolicyRuleTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeNetworkFirewallPolicyRuleTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeNetworkFirewallPolicyRuleTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule google_compute_network_firewall_policy_rule}
*/
export declare class ComputeNetworkFirewallPolicyRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_network_firewall_policy_rule";
    /**
    * Generates CDKTN code for importing a ComputeNetworkFirewallPolicyRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeNetworkFirewallPolicyRule to import
    * @param importFromId The id of the existing ComputeNetworkFirewallPolicyRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeNetworkFirewallPolicyRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_firewall_policy_rule google_compute_network_firewall_policy_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeNetworkFirewallPolicyRuleConfig
    */
    constructor(scope: Construct, id: string, config: ComputeNetworkFirewallPolicyRuleConfig);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    get directionInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _enableLogging?;
    get enableLogging(): boolean | cdktn.IResolvable;
    set enableLogging(value: boolean | cdktn.IResolvable);
    resetEnableLogging(): void;
    get enableLoggingInput(): boolean | cdktn.IResolvable | undefined;
    private _firewallPolicy?;
    get firewallPolicy(): string;
    set firewallPolicy(value: string);
    get firewallPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get kind(): string;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _ruleName?;
    get ruleName(): string;
    set ruleName(value: string);
    resetRuleName(): void;
    get ruleNameInput(): string | undefined;
    get ruleTupleCount(): number;
    private _securityProfileGroup?;
    get securityProfileGroup(): string;
    set securityProfileGroup(value: string);
    resetSecurityProfileGroup(): void;
    get securityProfileGroupInput(): string | undefined;
    private _targetForwardingRules?;
    get targetForwardingRules(): string[];
    set targetForwardingRules(value: string[]);
    resetTargetForwardingRules(): void;
    get targetForwardingRulesInput(): string[] | undefined;
    private _targetServiceAccounts?;
    get targetServiceAccounts(): string[];
    set targetServiceAccounts(value: string[]);
    resetTargetServiceAccounts(): void;
    get targetServiceAccountsInput(): string[] | undefined;
    private _targetType?;
    get targetType(): string;
    set targetType(value: string);
    resetTargetType(): void;
    get targetTypeInput(): string | undefined;
    private _tlsInspect?;
    get tlsInspect(): boolean | cdktn.IResolvable;
    set tlsInspect(value: boolean | cdktn.IResolvable);
    resetTlsInspect(): void;
    get tlsInspectInput(): boolean | cdktn.IResolvable | undefined;
    private _match;
    get match(): ComputeNetworkFirewallPolicyRuleMatchOutputReference;
    putMatch(value: ComputeNetworkFirewallPolicyRuleMatch): void;
    get matchInput(): ComputeNetworkFirewallPolicyRuleMatch | undefined;
    private _targetSecureTags;
    get targetSecureTags(): ComputeNetworkFirewallPolicyRuleTargetSecureTagsList;
    putTargetSecureTags(value: ComputeNetworkFirewallPolicyRuleTargetSecureTags[] | cdktn.IResolvable): void;
    resetTargetSecureTags(): void;
    get targetSecureTagsInput(): cdktn.IResolvable | ComputeNetworkFirewallPolicyRuleTargetSecureTags[] | undefined;
    private _timeouts;
    get timeouts(): ComputeNetworkFirewallPolicyRuleTimeoutsOutputReference;
    putTimeouts(value: ComputeNetworkFirewallPolicyRuleTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeNetworkFirewallPolicyRuleTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
