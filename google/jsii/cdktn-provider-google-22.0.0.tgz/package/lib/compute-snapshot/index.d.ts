/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeSnapshotConfig extends cdktn.TerraformMetaArguments {
    /**
    * Creates the new snapshot in the snapshot chain labeled with the
    * specified name. The chain name must be 1-63 characters long and
    * comply with RFC1035. This is an uncommon option only for advanced
    * service owners who needs to create separate snapshot chains, for
    * example, for chargeback tracking.  When you describe your snapshot
    * resource, this field is visible only if it has a non-empty value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#chain_name ComputeSnapshot#chain_name}
    */
    readonly chainName?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#deletion_policy ComputeSnapshot#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#description ComputeSnapshot#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#id ComputeSnapshot#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Labels to apply to this Snapshot.
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#labels ComputeSnapshot#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the resource; provided by the client when the resource is
    * created. The name must be 1-63 characters long, and comply with
    * RFC1035. Specifically, the name must be 1-63 characters long and match
    * the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the
    * first character must be a lowercase letter, and all following
    * characters must be a dash, lowercase letter, or digit, except the last
    * character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#name ComputeSnapshot#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#project ComputeSnapshot#project}
    */
    readonly project?: string;
    /**
    * Indicates the type of the snapshot. Possible values: ["ARCHIVE", "STANDARD"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#snapshot_type ComputeSnapshot#snapshot_type}
    */
    readonly snapshotType?: string;
    /**
    * A reference to the disk used to create this snapshot.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#source_disk ComputeSnapshot#source_disk}
    */
    readonly sourceDisk?: string;
    /**
    * A reference to the instant snapshot used to create this snapshot.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#source_instant_snapshot ComputeSnapshot#source_instant_snapshot}
    */
    readonly sourceInstantSnapshot?: string;
    /**
    * Cloud Storage bucket storage location of the snapshot (regional or multi-regional).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#storage_locations ComputeSnapshot#storage_locations}
    */
    readonly storageLocations?: string[];
    /**
    * A reference to the zone where the disk is hosted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#zone ComputeSnapshot#zone}
    */
    readonly zone?: string;
    /**
    * params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#params ComputeSnapshot#params}
    */
    readonly params?: ComputeSnapshotParams;
    /**
    * snapshot_encryption_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#snapshot_encryption_key ComputeSnapshot#snapshot_encryption_key}
    */
    readonly snapshotEncryptionKey?: ComputeSnapshotSnapshotEncryptionKey;
    /**
    * source_disk_encryption_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#source_disk_encryption_key ComputeSnapshot#source_disk_encryption_key}
    */
    readonly sourceDiskEncryptionKey?: ComputeSnapshotSourceDiskEncryptionKey;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#timeouts ComputeSnapshot#timeouts}
    */
    readonly timeouts?: ComputeSnapshotTimeouts;
}
export interface ComputeSnapshotParams {
    /**
    * Resource manager tags to be bound to the snapshot. Tag keys and values have the
    * same definition as resource manager tags. Keys must be in the format tagKeys/{tag_key_id},
    * and values are in the format tagValues/456.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#resource_manager_tags ComputeSnapshot#resource_manager_tags}
    */
    readonly resourceManagerTags?: {
        [key: string]: string;
    };
}
export declare function computeSnapshotParamsToTerraform(struct?: ComputeSnapshotParamsOutputReference | ComputeSnapshotParams): any;
export declare function computeSnapshotParamsToHclTerraform(struct?: ComputeSnapshotParamsOutputReference | ComputeSnapshotParams): any;
export declare class ComputeSnapshotParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSnapshotParams | undefined;
    set internalValue(value: ComputeSnapshotParams | undefined);
    private _resourceManagerTags?;
    get resourceManagerTags(): {
        [key: string]: string;
    };
    set resourceManagerTags(value: {
        [key: string]: string;
    });
    resetResourceManagerTags(): void;
    get resourceManagerTagsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ComputeSnapshotSnapshotEncryptionKey {
    /**
    * The name of the encryption key that is stored in Google Cloud KMS.
    *
    * Specify the key without a '/cryptoKeyVersions/' suffix.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#kms_key_self_link ComputeSnapshot#kms_key_self_link}
    */
    readonly kmsKeySelfLink?: string;
    /**
    * The service account used for the encryption request for the given KMS key.
    * If absent, the Compute Engine Service Agent service account is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#kms_key_service_account ComputeSnapshot#kms_key_service_account}
    */
    readonly kmsKeyServiceAccount?: string;
    /**
    * Specifies a 256-bit customer-supplied encryption key, encoded in
    * RFC 4648 base64 to either encrypt or decrypt this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#raw_key ComputeSnapshot#raw_key}
    */
    readonly rawKey?: string;
    /**
    * Specifies an encryption key stored in Google Cloud KMS, encoded in
    * RFC 4648 base64 to either encrypt or decrypt this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#rsa_encrypted_key ComputeSnapshot#rsa_encrypted_key}
    */
    readonly rsaEncryptedKey?: string;
}
export declare function computeSnapshotSnapshotEncryptionKeyToTerraform(struct?: ComputeSnapshotSnapshotEncryptionKeyOutputReference | ComputeSnapshotSnapshotEncryptionKey): any;
export declare function computeSnapshotSnapshotEncryptionKeyToHclTerraform(struct?: ComputeSnapshotSnapshotEncryptionKeyOutputReference | ComputeSnapshotSnapshotEncryptionKey): any;
export declare class ComputeSnapshotSnapshotEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSnapshotSnapshotEncryptionKey | undefined;
    set internalValue(value: ComputeSnapshotSnapshotEncryptionKey | undefined);
    private _kmsKeySelfLink?;
    get kmsKeySelfLink(): string;
    set kmsKeySelfLink(value: string);
    resetKmsKeySelfLink(): void;
    get kmsKeySelfLinkInput(): string | undefined;
    private _kmsKeyServiceAccount?;
    get kmsKeyServiceAccount(): string;
    set kmsKeyServiceAccount(value: string);
    resetKmsKeyServiceAccount(): void;
    get kmsKeyServiceAccountInput(): string | undefined;
    private _rawKey?;
    get rawKey(): string;
    set rawKey(value: string);
    resetRawKey(): void;
    get rawKeyInput(): string | undefined;
    private _rsaEncryptedKey?;
    get rsaEncryptedKey(): string;
    set rsaEncryptedKey(value: string);
    resetRsaEncryptedKey(): void;
    get rsaEncryptedKeyInput(): string | undefined;
    get sha256(): string;
}
export interface ComputeSnapshotSourceDiskEncryptionKey {
    /**
    * The name of the encryption key that is stored in Google Cloud KMS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#kms_key_self_link ComputeSnapshot#kms_key_self_link}
    */
    readonly kmsKeySelfLink?: string;
    /**
    * The service account used for the encryption request for the given KMS key.
    * If absent, the Compute Engine Service Agent service account is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#kms_key_service_account ComputeSnapshot#kms_key_service_account}
    */
    readonly kmsKeyServiceAccount?: string;
    /**
    * Specifies a 256-bit customer-supplied encryption key, encoded in
    * RFC 4648 base64 to either encrypt or decrypt this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#raw_key ComputeSnapshot#raw_key}
    */
    readonly rawKey?: string;
    /**
    * Specifies an encryption key stored in Google Cloud KMS, encoded in
    * RFC 4648 base64 to either encrypt or decrypt this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#rsa_encrypted_key ComputeSnapshot#rsa_encrypted_key}
    */
    readonly rsaEncryptedKey?: string;
}
export declare function computeSnapshotSourceDiskEncryptionKeyToTerraform(struct?: ComputeSnapshotSourceDiskEncryptionKeyOutputReference | ComputeSnapshotSourceDiskEncryptionKey): any;
export declare function computeSnapshotSourceDiskEncryptionKeyToHclTerraform(struct?: ComputeSnapshotSourceDiskEncryptionKeyOutputReference | ComputeSnapshotSourceDiskEncryptionKey): any;
export declare class ComputeSnapshotSourceDiskEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSnapshotSourceDiskEncryptionKey | undefined;
    set internalValue(value: ComputeSnapshotSourceDiskEncryptionKey | undefined);
    private _kmsKeySelfLink?;
    get kmsKeySelfLink(): string;
    set kmsKeySelfLink(value: string);
    resetKmsKeySelfLink(): void;
    get kmsKeySelfLinkInput(): string | undefined;
    private _kmsKeyServiceAccount?;
    get kmsKeyServiceAccount(): string;
    set kmsKeyServiceAccount(value: string);
    resetKmsKeyServiceAccount(): void;
    get kmsKeyServiceAccountInput(): string | undefined;
    private _rawKey?;
    get rawKey(): string;
    set rawKey(value: string);
    resetRawKey(): void;
    get rawKeyInput(): string | undefined;
    private _rsaEncryptedKey?;
    get rsaEncryptedKey(): string;
    set rsaEncryptedKey(value: string);
    resetRsaEncryptedKey(): void;
    get rsaEncryptedKeyInput(): string | undefined;
}
export interface ComputeSnapshotTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#create ComputeSnapshot#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#delete ComputeSnapshot#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#update ComputeSnapshot#update}
    */
    readonly update?: string;
}
export declare function computeSnapshotTimeoutsToTerraform(struct?: ComputeSnapshotTimeouts | cdktn.IResolvable): any;
export declare function computeSnapshotTimeoutsToHclTerraform(struct?: ComputeSnapshotTimeouts | cdktn.IResolvable): any;
export declare class ComputeSnapshotTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSnapshotTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeSnapshotTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot google_compute_snapshot}
*/
export declare class ComputeSnapshot extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_snapshot";
    /**
    * Generates CDKTN code for importing a ComputeSnapshot resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeSnapshot to import
    * @param importFromId The id of the existing ComputeSnapshot that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeSnapshot to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_snapshot google_compute_snapshot} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeSnapshotConfig
    */
    constructor(scope: Construct, id: string, config: ComputeSnapshotConfig);
    private _chainName?;
    get chainName(): string;
    set chainName(value: string);
    resetChainName(): void;
    get chainNameInput(): string | undefined;
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get diskSizeGb(): number;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get labelFingerprint(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    get licenses(): string[];
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get selfLink(): string;
    get snapshotId(): number;
    private _snapshotType?;
    get snapshotType(): string;
    set snapshotType(value: string);
    resetSnapshotType(): void;
    get snapshotTypeInput(): string | undefined;
    private _sourceDisk?;
    get sourceDisk(): string;
    set sourceDisk(value: string);
    resetSourceDisk(): void;
    get sourceDiskInput(): string | undefined;
    private _sourceInstantSnapshot?;
    get sourceInstantSnapshot(): string;
    set sourceInstantSnapshot(value: string);
    resetSourceInstantSnapshot(): void;
    get sourceInstantSnapshotInput(): string | undefined;
    get storageBytes(): number;
    private _storageLocations?;
    get storageLocations(): string[];
    set storageLocations(value: string[]);
    resetStorageLocations(): void;
    get storageLocationsInput(): string[] | undefined;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    resetZone(): void;
    get zoneInput(): string | undefined;
    private _params;
    get params(): ComputeSnapshotParamsOutputReference;
    putParams(value: ComputeSnapshotParams): void;
    resetParams(): void;
    get paramsInput(): ComputeSnapshotParams | undefined;
    private _snapshotEncryptionKey;
    get snapshotEncryptionKey(): ComputeSnapshotSnapshotEncryptionKeyOutputReference;
    putSnapshotEncryptionKey(value: ComputeSnapshotSnapshotEncryptionKey): void;
    resetSnapshotEncryptionKey(): void;
    get snapshotEncryptionKeyInput(): ComputeSnapshotSnapshotEncryptionKey | undefined;
    private _sourceDiskEncryptionKey;
    get sourceDiskEncryptionKey(): ComputeSnapshotSourceDiskEncryptionKeyOutputReference;
    putSourceDiskEncryptionKey(value: ComputeSnapshotSourceDiskEncryptionKey): void;
    resetSourceDiskEncryptionKey(): void;
    get sourceDiskEncryptionKeyInput(): ComputeSnapshotSourceDiskEncryptionKey | undefined;
    private _timeouts;
    get timeouts(): ComputeSnapshotTimeoutsOutputReference;
    putTimeouts(value: ComputeSnapshotTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeSnapshotTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
