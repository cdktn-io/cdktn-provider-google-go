/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApihubCurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID to use for the curation resource, which will become the final
    * component of the curations's resource name. This field is optional.
    *
    * * If provided, the same will be used. The service will throw an error if
    * the specified ID is already used by another curation resource in the API
    * hub.
    * * If not provided, a system generated ID will be used.
    *
    * This value should be 4-500 characters, and valid characters
    * are /a-z[0-9]-_/.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_curation#curation_id ApihubCuration#curation_id}
    */
    readonly curationId: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_curation#deletion_policy ApihubCuration#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The description of the curation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_curation#description ApihubCuration#description}
    */
    readonly description?: string;
    /**
    * The display name of the curation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_curation#display_name ApihubCuration#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_curation#id ApihubCuration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_curation#location ApihubCuration#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_curation#project ApihubCuration#project}
    */
    readonly project?: string;
    /**
    * endpoint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_curation#endpoint ApihubCuration#endpoint}
    */
    readonly endpoint: ApihubCurationEndpoint;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_curation#timeouts ApihubCuration#timeouts}
    */
    readonly timeouts?: ApihubCurationTimeouts;
}
export interface ApihubCurationPluginInstanceActions {
}
export declare function apihubCurationPluginInstanceActionsToTerraform(struct?: ApihubCurationPluginInstanceActions): any;
export declare function apihubCurationPluginInstanceActionsToHclTerraform(struct?: ApihubCurationPluginInstanceActions): any;
export declare class ApihubCurationPluginInstanceActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApihubCurationPluginInstanceActions | undefined;
    set internalValue(value: ApihubCurationPluginInstanceActions | undefined);
    get actionId(): string;
    get pluginInstance(): string;
}
export declare class ApihubCurationPluginInstanceActionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApihubCurationPluginInstanceActionsOutputReference;
}
export interface ApihubCurationEndpointApplicationIntegrationEndpointDetails {
    /**
    * The API trigger ID of the Application Integration workflow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_curation#trigger_id ApihubCuration#trigger_id}
    */
    readonly triggerId: string;
    /**
    * The endpoint URI should be a valid REST URI for triggering an Application
    * Integration.
    * Format:
    * 'https://integrations.googleapis.com/v1/{name=projects/* /locations/* /integrations/*}:execute'
    * or
    * 'https://{location}-integrations.googleapis.com/v1/{name=projects/* /locations/* /integrations/*}:execute'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_curation#uri ApihubCuration#uri}
     *
    * Note: The above comment contained a comment block ending sequence (* followed by /). We have introduced a space between to prevent syntax errors. Please ignore the space.
    */
    readonly uri: string;
}
export declare function apihubCurationEndpointApplicationIntegrationEndpointDetailsToTerraform(struct?: ApihubCurationEndpointApplicationIntegrationEndpointDetailsOutputReference | ApihubCurationEndpointApplicationIntegrationEndpointDetails): any;
export declare function apihubCurationEndpointApplicationIntegrationEndpointDetailsToHclTerraform(struct?: ApihubCurationEndpointApplicationIntegrationEndpointDetailsOutputReference | ApihubCurationEndpointApplicationIntegrationEndpointDetails): any;
export declare class ApihubCurationEndpointApplicationIntegrationEndpointDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApihubCurationEndpointApplicationIntegrationEndpointDetails | undefined;
    set internalValue(value: ApihubCurationEndpointApplicationIntegrationEndpointDetails | undefined);
    private _triggerId?;
    get triggerId(): string;
    set triggerId(value: string);
    get triggerIdInput(): string | undefined;
    private _uri?;
    get uri(): string;
    set uri(value: string);
    get uriInput(): string | undefined;
}
export interface ApihubCurationEndpoint {
    /**
    * application_integration_endpoint_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_curation#application_integration_endpoint_details ApihubCuration#application_integration_endpoint_details}
    */
    readonly applicationIntegrationEndpointDetails: ApihubCurationEndpointApplicationIntegrationEndpointDetails;
}
export declare function apihubCurationEndpointToTerraform(struct?: ApihubCurationEndpointOutputReference | ApihubCurationEndpoint): any;
export declare function apihubCurationEndpointToHclTerraform(struct?: ApihubCurationEndpointOutputReference | ApihubCurationEndpoint): any;
export declare class ApihubCurationEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApihubCurationEndpoint | undefined;
    set internalValue(value: ApihubCurationEndpoint | undefined);
    private _applicationIntegrationEndpointDetails;
    get applicationIntegrationEndpointDetails(): ApihubCurationEndpointApplicationIntegrationEndpointDetailsOutputReference;
    putApplicationIntegrationEndpointDetails(value: ApihubCurationEndpointApplicationIntegrationEndpointDetails): void;
    get applicationIntegrationEndpointDetailsInput(): ApihubCurationEndpointApplicationIntegrationEndpointDetails | undefined;
}
export interface ApihubCurationTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_curation#create ApihubCuration#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_curation#delete ApihubCuration#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_curation#update ApihubCuration#update}
    */
    readonly update?: string;
}
export declare function apihubCurationTimeoutsToTerraform(struct?: ApihubCurationTimeouts | cdktn.IResolvable): any;
export declare function apihubCurationTimeoutsToHclTerraform(struct?: ApihubCurationTimeouts | cdktn.IResolvable): any;
export declare class ApihubCurationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApihubCurationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApihubCurationTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_curation google_apihub_curation}
*/
export declare class ApihubCuration extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apihub_curation";
    /**
    * Generates CDKTN code for importing a ApihubCuration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApihubCuration to import
    * @param importFromId The id of the existing ApihubCuration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_curation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApihubCuration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_curation google_apihub_curation} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApihubCurationConfig
    */
    constructor(scope: Construct, id: string, config: ApihubCurationConfig);
    get createTime(): string;
    private _curationId?;
    get curationId(): string;
    set curationId(value: string);
    get curationIdInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastExecutionErrorCode(): string;
    get lastExecutionErrorMessage(): string;
    get lastExecutionState(): string;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _pluginInstanceActions;
    get pluginInstanceActions(): ApihubCurationPluginInstanceActionsList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get updateTime(): string;
    private _endpoint;
    get endpoint(): ApihubCurationEndpointOutputReference;
    putEndpoint(value: ApihubCurationEndpoint): void;
    get endpointInput(): ApihubCurationEndpoint | undefined;
    private _timeouts;
    get timeouts(): ApihubCurationTimeoutsOutputReference;
    putTimeouts(value: ApihubCurationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApihubCurationTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
