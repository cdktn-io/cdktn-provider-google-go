/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ClouddomainsRegistrationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The list of contact notices that the caller acknowledges. Possible value is PUBLIC_CONTACT_DATA_ACKNOWLEDGEMENT
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#contact_notices ClouddomainsRegistration#contact_notices}
    */
    readonly contactNotices?: string[];
    /**
    * Required. The domain name. Unicode domain names must be expressed in Punycode format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#domain_name ClouddomainsRegistration#domain_name}
    */
    readonly domainName: string;
    /**
    * The list of domain notices that you acknowledge. Possible value is HSTS_PRELOADED
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#domain_notices ClouddomainsRegistration#domain_notices}
    */
    readonly domainNotices?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#id ClouddomainsRegistration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Set of labels associated with the Registration.
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#labels ClouddomainsRegistration#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The location for the resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#location ClouddomainsRegistration#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#project ClouddomainsRegistration#project}
    */
    readonly project?: string;
    /**
    * contact_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#contact_settings ClouddomainsRegistration#contact_settings}
    */
    readonly contactSettings: ClouddomainsRegistrationContactSettings;
    /**
    * dns_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#dns_settings ClouddomainsRegistration#dns_settings}
    */
    readonly dnsSettings?: ClouddomainsRegistrationDnsSettings;
    /**
    * management_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#management_settings ClouddomainsRegistration#management_settings}
    */
    readonly managementSettings?: ClouddomainsRegistrationManagementSettings;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#timeouts ClouddomainsRegistration#timeouts}
    */
    readonly timeouts?: ClouddomainsRegistrationTimeouts;
    /**
    * yearly_price block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#yearly_price ClouddomainsRegistration#yearly_price}
    */
    readonly yearlyPrice: ClouddomainsRegistrationYearlyPrice;
}
export interface ClouddomainsRegistrationContactSettingsAdminContactPostalAddress {
    /**
    * Unstructured address lines describing the lower levels of an address.
    * Because values in addressLines do not have type information and may sometimes contain multiple values in a single
    * field (e.g. "Austin, TX"), it is important that the line order is clear. The order of address lines should be
    * "envelope order" for the country/region of the address. In places where this can vary (e.g. Japan), address_language
    * is used to make it explicit (e.g. "ja" for large-to-small ordering and "ja-Latn" or "en" for small-to-large). This way,
    * the most specific line of an address can be selected based on the language.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#address_lines ClouddomainsRegistration#address_lines}
    */
    readonly addressLines?: string[];
    /**
    * Highest administrative subdivision which is used for postal addresses of a country or region. For example, this can be a state,
    * a province, an oblast, or a prefecture. Specifically, for Spain this is the province and not the autonomous community
    * (e.g. "Barcelona" and not "Catalonia"). Many countries don't use an administrative area in postal addresses. E.g. in Switzerland
    * this should be left unpopulated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#administrative_area ClouddomainsRegistration#administrative_area}
    */
    readonly administrativeArea?: string;
    /**
    * Generally refers to the city/town portion of the address. Examples: US city, IT comune, UK post town. In regions of the world
    * where localities are not well defined or do not fit into this structure well, leave locality empty and use addressLines.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#locality ClouddomainsRegistration#locality}
    */
    readonly locality?: string;
    /**
    * The name of the organization at the address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#organization ClouddomainsRegistration#organization}
    */
    readonly organization?: string;
    /**
    * Postal code of the address. Not all countries use or require postal codes to be present, but where they are used,
    * they may trigger additional validation with other parts of the address (e.g. state/zip validation in the U.S.A.).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#postal_code ClouddomainsRegistration#postal_code}
    */
    readonly postalCode?: string;
    /**
    * The recipient at the address. This field may, under certain circumstances, contain multiline information. For example,
    * it might contain "care of" information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#recipients ClouddomainsRegistration#recipients}
    */
    readonly recipients?: string[];
    /**
    * Required. CLDR region code of the country/region of the address. This is never inferred and it is up to the user to
    * ensure the value is correct. See https://cldr.unicode.org/ and
    * https://www.unicode.org/cldr/charts/30/supplemental/territory_information.html for details. Example: "CH" for Switzerland.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#region_code ClouddomainsRegistration#region_code}
    */
    readonly regionCode: string;
}
export declare function clouddomainsRegistrationContactSettingsAdminContactPostalAddressToTerraform(struct?: ClouddomainsRegistrationContactSettingsAdminContactPostalAddressOutputReference | ClouddomainsRegistrationContactSettingsAdminContactPostalAddress): any;
export declare function clouddomainsRegistrationContactSettingsAdminContactPostalAddressToHclTerraform(struct?: ClouddomainsRegistrationContactSettingsAdminContactPostalAddressOutputReference | ClouddomainsRegistrationContactSettingsAdminContactPostalAddress): any;
export declare class ClouddomainsRegistrationContactSettingsAdminContactPostalAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddomainsRegistrationContactSettingsAdminContactPostalAddress | undefined;
    set internalValue(value: ClouddomainsRegistrationContactSettingsAdminContactPostalAddress | undefined);
    private _addressLines?;
    get addressLines(): string[];
    set addressLines(value: string[]);
    resetAddressLines(): void;
    get addressLinesInput(): string[] | undefined;
    private _administrativeArea?;
    get administrativeArea(): string;
    set administrativeArea(value: string);
    resetAdministrativeArea(): void;
    get administrativeAreaInput(): string | undefined;
    private _locality?;
    get locality(): string;
    set locality(value: string);
    resetLocality(): void;
    get localityInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _postalCode?;
    get postalCode(): string;
    set postalCode(value: string);
    resetPostalCode(): void;
    get postalCodeInput(): string | undefined;
    private _recipients?;
    get recipients(): string[];
    set recipients(value: string[]);
    resetRecipients(): void;
    get recipientsInput(): string[] | undefined;
    private _regionCode?;
    get regionCode(): string;
    set regionCode(value: string);
    get regionCodeInput(): string | undefined;
}
export interface ClouddomainsRegistrationContactSettingsAdminContact {
    /**
    * Required. Email address of the contact.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#email ClouddomainsRegistration#email}
    */
    readonly email: string;
    /**
    * Fax number of the contact in international format. For example, "+1-800-555-0123".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#fax_number ClouddomainsRegistration#fax_number}
    */
    readonly faxNumber?: string;
    /**
    * Required. Phone number of the contact in international format. For example, "+1-800-555-0123".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#phone_number ClouddomainsRegistration#phone_number}
    */
    readonly phoneNumber: string;
    /**
    * postal_address block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#postal_address ClouddomainsRegistration#postal_address}
    */
    readonly postalAddress: ClouddomainsRegistrationContactSettingsAdminContactPostalAddress;
}
export declare function clouddomainsRegistrationContactSettingsAdminContactToTerraform(struct?: ClouddomainsRegistrationContactSettingsAdminContactOutputReference | ClouddomainsRegistrationContactSettingsAdminContact): any;
export declare function clouddomainsRegistrationContactSettingsAdminContactToHclTerraform(struct?: ClouddomainsRegistrationContactSettingsAdminContactOutputReference | ClouddomainsRegistrationContactSettingsAdminContact): any;
export declare class ClouddomainsRegistrationContactSettingsAdminContactOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddomainsRegistrationContactSettingsAdminContact | undefined;
    set internalValue(value: ClouddomainsRegistrationContactSettingsAdminContact | undefined);
    private _email?;
    get email(): string;
    set email(value: string);
    get emailInput(): string | undefined;
    private _faxNumber?;
    get faxNumber(): string;
    set faxNumber(value: string);
    resetFaxNumber(): void;
    get faxNumberInput(): string | undefined;
    private _phoneNumber?;
    get phoneNumber(): string;
    set phoneNumber(value: string);
    get phoneNumberInput(): string | undefined;
    private _postalAddress;
    get postalAddress(): ClouddomainsRegistrationContactSettingsAdminContactPostalAddressOutputReference;
    putPostalAddress(value: ClouddomainsRegistrationContactSettingsAdminContactPostalAddress): void;
    get postalAddressInput(): ClouddomainsRegistrationContactSettingsAdminContactPostalAddress | undefined;
}
export interface ClouddomainsRegistrationContactSettingsRegistrantContactPostalAddress {
    /**
    * Unstructured address lines describing the lower levels of an address.
    * Because values in addressLines do not have type information and may sometimes contain multiple values in a single
    * field (e.g. "Austin, TX"), it is important that the line order is clear. The order of address lines should be
    * "envelope order" for the country/region of the address. In places where this can vary (e.g. Japan), address_language
    * is used to make it explicit (e.g. "ja" for large-to-small ordering and "ja-Latn" or "en" for small-to-large). This way,
    * the most specific line of an address can be selected based on the language.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#address_lines ClouddomainsRegistration#address_lines}
    */
    readonly addressLines?: string[];
    /**
    * Highest administrative subdivision which is used for postal addresses of a country or region. For example, this can be a state,
    * a province, an oblast, or a prefecture. Specifically, for Spain this is the province and not the autonomous community
    * (e.g. "Barcelona" and not "Catalonia"). Many countries don't use an administrative area in postal addresses. E.g. in Switzerland
    * this should be left unpopulated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#administrative_area ClouddomainsRegistration#administrative_area}
    */
    readonly administrativeArea?: string;
    /**
    * Generally refers to the city/town portion of the address. Examples: US city, IT comune, UK post town. In regions of the world
    * where localities are not well defined or do not fit into this structure well, leave locality empty and use addressLines.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#locality ClouddomainsRegistration#locality}
    */
    readonly locality?: string;
    /**
    * The name of the organization at the address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#organization ClouddomainsRegistration#organization}
    */
    readonly organization?: string;
    /**
    * Postal code of the address. Not all countries use or require postal codes to be present, but where they are used,
    * they may trigger additional validation with other parts of the address (e.g. state/zip validation in the U.S.A.).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#postal_code ClouddomainsRegistration#postal_code}
    */
    readonly postalCode?: string;
    /**
    * The recipient at the address. This field may, under certain circumstances, contain multiline information. For example,
    * it might contain "care of" information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#recipients ClouddomainsRegistration#recipients}
    */
    readonly recipients?: string[];
    /**
    * Required. CLDR region code of the country/region of the address. This is never inferred and it is up to the user to
    * ensure the value is correct. See https://cldr.unicode.org/ and
    * https://www.unicode.org/cldr/charts/30/supplemental/territory_information.html for details. Example: "CH" for Switzerland.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#region_code ClouddomainsRegistration#region_code}
    */
    readonly regionCode: string;
}
export declare function clouddomainsRegistrationContactSettingsRegistrantContactPostalAddressToTerraform(struct?: ClouddomainsRegistrationContactSettingsRegistrantContactPostalAddressOutputReference | ClouddomainsRegistrationContactSettingsRegistrantContactPostalAddress): any;
export declare function clouddomainsRegistrationContactSettingsRegistrantContactPostalAddressToHclTerraform(struct?: ClouddomainsRegistrationContactSettingsRegistrantContactPostalAddressOutputReference | ClouddomainsRegistrationContactSettingsRegistrantContactPostalAddress): any;
export declare class ClouddomainsRegistrationContactSettingsRegistrantContactPostalAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddomainsRegistrationContactSettingsRegistrantContactPostalAddress | undefined;
    set internalValue(value: ClouddomainsRegistrationContactSettingsRegistrantContactPostalAddress | undefined);
    private _addressLines?;
    get addressLines(): string[];
    set addressLines(value: string[]);
    resetAddressLines(): void;
    get addressLinesInput(): string[] | undefined;
    private _administrativeArea?;
    get administrativeArea(): string;
    set administrativeArea(value: string);
    resetAdministrativeArea(): void;
    get administrativeAreaInput(): string | undefined;
    private _locality?;
    get locality(): string;
    set locality(value: string);
    resetLocality(): void;
    get localityInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _postalCode?;
    get postalCode(): string;
    set postalCode(value: string);
    resetPostalCode(): void;
    get postalCodeInput(): string | undefined;
    private _recipients?;
    get recipients(): string[];
    set recipients(value: string[]);
    resetRecipients(): void;
    get recipientsInput(): string[] | undefined;
    private _regionCode?;
    get regionCode(): string;
    set regionCode(value: string);
    get regionCodeInput(): string | undefined;
}
export interface ClouddomainsRegistrationContactSettingsRegistrantContact {
    /**
    * Required. Email address of the contact.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#email ClouddomainsRegistration#email}
    */
    readonly email: string;
    /**
    * Fax number of the contact in international format. For example, "+1-800-555-0123".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#fax_number ClouddomainsRegistration#fax_number}
    */
    readonly faxNumber?: string;
    /**
    * Required. Phone number of the contact in international format. For example, "+1-800-555-0123".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#phone_number ClouddomainsRegistration#phone_number}
    */
    readonly phoneNumber: string;
    /**
    * postal_address block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#postal_address ClouddomainsRegistration#postal_address}
    */
    readonly postalAddress: ClouddomainsRegistrationContactSettingsRegistrantContactPostalAddress;
}
export declare function clouddomainsRegistrationContactSettingsRegistrantContactToTerraform(struct?: ClouddomainsRegistrationContactSettingsRegistrantContactOutputReference | ClouddomainsRegistrationContactSettingsRegistrantContact): any;
export declare function clouddomainsRegistrationContactSettingsRegistrantContactToHclTerraform(struct?: ClouddomainsRegistrationContactSettingsRegistrantContactOutputReference | ClouddomainsRegistrationContactSettingsRegistrantContact): any;
export declare class ClouddomainsRegistrationContactSettingsRegistrantContactOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddomainsRegistrationContactSettingsRegistrantContact | undefined;
    set internalValue(value: ClouddomainsRegistrationContactSettingsRegistrantContact | undefined);
    private _email?;
    get email(): string;
    set email(value: string);
    get emailInput(): string | undefined;
    private _faxNumber?;
    get faxNumber(): string;
    set faxNumber(value: string);
    resetFaxNumber(): void;
    get faxNumberInput(): string | undefined;
    private _phoneNumber?;
    get phoneNumber(): string;
    set phoneNumber(value: string);
    get phoneNumberInput(): string | undefined;
    private _postalAddress;
    get postalAddress(): ClouddomainsRegistrationContactSettingsRegistrantContactPostalAddressOutputReference;
    putPostalAddress(value: ClouddomainsRegistrationContactSettingsRegistrantContactPostalAddress): void;
    get postalAddressInput(): ClouddomainsRegistrationContactSettingsRegistrantContactPostalAddress | undefined;
}
export interface ClouddomainsRegistrationContactSettingsTechnicalContactPostalAddress {
    /**
    * Unstructured address lines describing the lower levels of an address.
    * Because values in addressLines do not have type information and may sometimes contain multiple values in a single
    * field (e.g. "Austin, TX"), it is important that the line order is clear. The order of address lines should be
    * "envelope order" for the country/region of the address. In places where this can vary (e.g. Japan), address_language
    * is used to make it explicit (e.g. "ja" for large-to-small ordering and "ja-Latn" or "en" for small-to-large). This way,
    * the most specific line of an address can be selected based on the language.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#address_lines ClouddomainsRegistration#address_lines}
    */
    readonly addressLines?: string[];
    /**
    * Highest administrative subdivision which is used for postal addresses of a country or region. For example, this can be a state,
    * a province, an oblast, or a prefecture. Specifically, for Spain this is the province and not the autonomous community
    * (e.g. "Barcelona" and not "Catalonia"). Many countries don't use an administrative area in postal addresses. E.g. in Switzerland
    * this should be left unpopulated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#administrative_area ClouddomainsRegistration#administrative_area}
    */
    readonly administrativeArea?: string;
    /**
    * Generally refers to the city/town portion of the address. Examples: US city, IT comune, UK post town. In regions of the world
    * where localities are not well defined or do not fit into this structure well, leave locality empty and use addressLines.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#locality ClouddomainsRegistration#locality}
    */
    readonly locality?: string;
    /**
    * The name of the organization at the address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#organization ClouddomainsRegistration#organization}
    */
    readonly organization?: string;
    /**
    * Postal code of the address. Not all countries use or require postal codes to be present, but where they are used,
    * they may trigger additional validation with other parts of the address (e.g. state/zip validation in the U.S.A.).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#postal_code ClouddomainsRegistration#postal_code}
    */
    readonly postalCode?: string;
    /**
    * The recipient at the address. This field may, under certain circumstances, contain multiline information. For example,
    * it might contain "care of" information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#recipients ClouddomainsRegistration#recipients}
    */
    readonly recipients?: string[];
    /**
    * Required. CLDR region code of the country/region of the address. This is never inferred and it is up to the user to
    * ensure the value is correct. See https://cldr.unicode.org/ and
    * https://www.unicode.org/cldr/charts/30/supplemental/territory_information.html for details. Example: "CH" for Switzerland.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#region_code ClouddomainsRegistration#region_code}
    */
    readonly regionCode: string;
}
export declare function clouddomainsRegistrationContactSettingsTechnicalContactPostalAddressToTerraform(struct?: ClouddomainsRegistrationContactSettingsTechnicalContactPostalAddressOutputReference | ClouddomainsRegistrationContactSettingsTechnicalContactPostalAddress): any;
export declare function clouddomainsRegistrationContactSettingsTechnicalContactPostalAddressToHclTerraform(struct?: ClouddomainsRegistrationContactSettingsTechnicalContactPostalAddressOutputReference | ClouddomainsRegistrationContactSettingsTechnicalContactPostalAddress): any;
export declare class ClouddomainsRegistrationContactSettingsTechnicalContactPostalAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddomainsRegistrationContactSettingsTechnicalContactPostalAddress | undefined;
    set internalValue(value: ClouddomainsRegistrationContactSettingsTechnicalContactPostalAddress | undefined);
    private _addressLines?;
    get addressLines(): string[];
    set addressLines(value: string[]);
    resetAddressLines(): void;
    get addressLinesInput(): string[] | undefined;
    private _administrativeArea?;
    get administrativeArea(): string;
    set administrativeArea(value: string);
    resetAdministrativeArea(): void;
    get administrativeAreaInput(): string | undefined;
    private _locality?;
    get locality(): string;
    set locality(value: string);
    resetLocality(): void;
    get localityInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _postalCode?;
    get postalCode(): string;
    set postalCode(value: string);
    resetPostalCode(): void;
    get postalCodeInput(): string | undefined;
    private _recipients?;
    get recipients(): string[];
    set recipients(value: string[]);
    resetRecipients(): void;
    get recipientsInput(): string[] | undefined;
    private _regionCode?;
    get regionCode(): string;
    set regionCode(value: string);
    get regionCodeInput(): string | undefined;
}
export interface ClouddomainsRegistrationContactSettingsTechnicalContact {
    /**
    * Required. Email address of the contact.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#email ClouddomainsRegistration#email}
    */
    readonly email: string;
    /**
    * Fax number of the contact in international format. For example, "+1-800-555-0123".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#fax_number ClouddomainsRegistration#fax_number}
    */
    readonly faxNumber?: string;
    /**
    * Required. Phone number of the contact in international format. For example, "+1-800-555-0123".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#phone_number ClouddomainsRegistration#phone_number}
    */
    readonly phoneNumber: string;
    /**
    * postal_address block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#postal_address ClouddomainsRegistration#postal_address}
    */
    readonly postalAddress: ClouddomainsRegistrationContactSettingsTechnicalContactPostalAddress;
}
export declare function clouddomainsRegistrationContactSettingsTechnicalContactToTerraform(struct?: ClouddomainsRegistrationContactSettingsTechnicalContactOutputReference | ClouddomainsRegistrationContactSettingsTechnicalContact): any;
export declare function clouddomainsRegistrationContactSettingsTechnicalContactToHclTerraform(struct?: ClouddomainsRegistrationContactSettingsTechnicalContactOutputReference | ClouddomainsRegistrationContactSettingsTechnicalContact): any;
export declare class ClouddomainsRegistrationContactSettingsTechnicalContactOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddomainsRegistrationContactSettingsTechnicalContact | undefined;
    set internalValue(value: ClouddomainsRegistrationContactSettingsTechnicalContact | undefined);
    private _email?;
    get email(): string;
    set email(value: string);
    get emailInput(): string | undefined;
    private _faxNumber?;
    get faxNumber(): string;
    set faxNumber(value: string);
    resetFaxNumber(): void;
    get faxNumberInput(): string | undefined;
    private _phoneNumber?;
    get phoneNumber(): string;
    set phoneNumber(value: string);
    get phoneNumberInput(): string | undefined;
    private _postalAddress;
    get postalAddress(): ClouddomainsRegistrationContactSettingsTechnicalContactPostalAddressOutputReference;
    putPostalAddress(value: ClouddomainsRegistrationContactSettingsTechnicalContactPostalAddress): void;
    get postalAddressInput(): ClouddomainsRegistrationContactSettingsTechnicalContactPostalAddress | undefined;
}
export interface ClouddomainsRegistrationContactSettings {
    /**
    * Required. Privacy setting for the contacts associated with the Registration.
    * Values are PUBLIC_CONTACT_DATA, PRIVATE_CONTACT_DATA, and REDACTED_CONTACT_DATA
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#privacy ClouddomainsRegistration#privacy}
    */
    readonly privacy: string;
    /**
    * admin_contact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#admin_contact ClouddomainsRegistration#admin_contact}
    */
    readonly adminContact: ClouddomainsRegistrationContactSettingsAdminContact;
    /**
    * registrant_contact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#registrant_contact ClouddomainsRegistration#registrant_contact}
    */
    readonly registrantContact: ClouddomainsRegistrationContactSettingsRegistrantContact;
    /**
    * technical_contact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#technical_contact ClouddomainsRegistration#technical_contact}
    */
    readonly technicalContact: ClouddomainsRegistrationContactSettingsTechnicalContact;
}
export declare function clouddomainsRegistrationContactSettingsToTerraform(struct?: ClouddomainsRegistrationContactSettingsOutputReference | ClouddomainsRegistrationContactSettings): any;
export declare function clouddomainsRegistrationContactSettingsToHclTerraform(struct?: ClouddomainsRegistrationContactSettingsOutputReference | ClouddomainsRegistrationContactSettings): any;
export declare class ClouddomainsRegistrationContactSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddomainsRegistrationContactSettings | undefined;
    set internalValue(value: ClouddomainsRegistrationContactSettings | undefined);
    private _privacy?;
    get privacy(): string;
    set privacy(value: string);
    get privacyInput(): string | undefined;
    private _adminContact;
    get adminContact(): ClouddomainsRegistrationContactSettingsAdminContactOutputReference;
    putAdminContact(value: ClouddomainsRegistrationContactSettingsAdminContact): void;
    get adminContactInput(): ClouddomainsRegistrationContactSettingsAdminContact | undefined;
    private _registrantContact;
    get registrantContact(): ClouddomainsRegistrationContactSettingsRegistrantContactOutputReference;
    putRegistrantContact(value: ClouddomainsRegistrationContactSettingsRegistrantContact): void;
    get registrantContactInput(): ClouddomainsRegistrationContactSettingsRegistrantContact | undefined;
    private _technicalContact;
    get technicalContact(): ClouddomainsRegistrationContactSettingsTechnicalContactOutputReference;
    putTechnicalContact(value: ClouddomainsRegistrationContactSettingsTechnicalContact): void;
    get technicalContactInput(): ClouddomainsRegistrationContactSettingsTechnicalContact | undefined;
}
export interface ClouddomainsRegistrationDnsSettingsCustomDnsDsRecords {
    /**
    * The algorithm used to generate the referenced DNSKEY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#algorithm ClouddomainsRegistration#algorithm}
    */
    readonly algorithm?: string;
    /**
    * The digest generated from the referenced DNSKEY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#digest ClouddomainsRegistration#digest}
    */
    readonly digest?: string;
    /**
    * The hash function used to generate the digest of the referenced DNSKEY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#digest_type ClouddomainsRegistration#digest_type}
    */
    readonly digestType?: string;
    /**
    * The key tag of the record. Must be set in range 0 -- 65535.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#key_tag ClouddomainsRegistration#key_tag}
    */
    readonly keyTag?: number;
}
export declare function clouddomainsRegistrationDnsSettingsCustomDnsDsRecordsToTerraform(struct?: ClouddomainsRegistrationDnsSettingsCustomDnsDsRecords | cdktn.IResolvable): any;
export declare function clouddomainsRegistrationDnsSettingsCustomDnsDsRecordsToHclTerraform(struct?: ClouddomainsRegistrationDnsSettingsCustomDnsDsRecords | cdktn.IResolvable): any;
export declare class ClouddomainsRegistrationDnsSettingsCustomDnsDsRecordsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ClouddomainsRegistrationDnsSettingsCustomDnsDsRecords | cdktn.IResolvable | undefined;
    set internalValue(value: ClouddomainsRegistrationDnsSettingsCustomDnsDsRecords | cdktn.IResolvable | undefined);
    private _algorithm?;
    get algorithm(): string;
    set algorithm(value: string);
    resetAlgorithm(): void;
    get algorithmInput(): string | undefined;
    private _digest?;
    get digest(): string;
    set digest(value: string);
    resetDigest(): void;
    get digestInput(): string | undefined;
    private _digestType?;
    get digestType(): string;
    set digestType(value: string);
    resetDigestType(): void;
    get digestTypeInput(): string | undefined;
    private _keyTag?;
    get keyTag(): number;
    set keyTag(value: number);
    resetKeyTag(): void;
    get keyTagInput(): number | undefined;
}
export declare class ClouddomainsRegistrationDnsSettingsCustomDnsDsRecordsList extends cdktn.ComplexList {
    internalValue?: ClouddomainsRegistrationDnsSettingsCustomDnsDsRecords[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ClouddomainsRegistrationDnsSettingsCustomDnsDsRecordsOutputReference;
}
export interface ClouddomainsRegistrationDnsSettingsCustomDns {
    /**
    * Required. A list of name servers that store the DNS zone for this domain. Each name server is a domain
    * name, with Unicode domain names expressed in Punycode format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#name_servers ClouddomainsRegistration#name_servers}
    */
    readonly nameServers: string[];
    /**
    * ds_records block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#ds_records ClouddomainsRegistration#ds_records}
    */
    readonly dsRecords?: ClouddomainsRegistrationDnsSettingsCustomDnsDsRecords[] | cdktn.IResolvable;
}
export declare function clouddomainsRegistrationDnsSettingsCustomDnsToTerraform(struct?: ClouddomainsRegistrationDnsSettingsCustomDnsOutputReference | ClouddomainsRegistrationDnsSettingsCustomDns): any;
export declare function clouddomainsRegistrationDnsSettingsCustomDnsToHclTerraform(struct?: ClouddomainsRegistrationDnsSettingsCustomDnsOutputReference | ClouddomainsRegistrationDnsSettingsCustomDns): any;
export declare class ClouddomainsRegistrationDnsSettingsCustomDnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddomainsRegistrationDnsSettingsCustomDns | undefined;
    set internalValue(value: ClouddomainsRegistrationDnsSettingsCustomDns | undefined);
    private _nameServers?;
    get nameServers(): string[];
    set nameServers(value: string[]);
    get nameServersInput(): string[] | undefined;
    private _dsRecords;
    get dsRecords(): ClouddomainsRegistrationDnsSettingsCustomDnsDsRecordsList;
    putDsRecords(value: ClouddomainsRegistrationDnsSettingsCustomDnsDsRecords[] | cdktn.IResolvable): void;
    resetDsRecords(): void;
    get dsRecordsInput(): cdktn.IResolvable | ClouddomainsRegistrationDnsSettingsCustomDnsDsRecords[] | undefined;
}
export interface ClouddomainsRegistrationDnsSettingsGlueRecords {
    /**
    * Required. Domain name of the host in Punycode format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#host_name ClouddomainsRegistration#host_name}
    */
    readonly hostName: string;
    /**
    * List of IPv4 addresses corresponding to this host in the standard decimal format (e.g. 198.51.100.1).
    * At least one of ipv4_address and ipv6_address must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#ipv4_addresses ClouddomainsRegistration#ipv4_addresses}
    */
    readonly ipv4Addresses?: string[];
    /**
    * List of IPv4 addresses corresponding to this host in the standard decimal format (e.g. 198.51.100.1).
    * At least one of ipv4_address and ipv6_address must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#ipv6_addresses ClouddomainsRegistration#ipv6_addresses}
    */
    readonly ipv6Addresses?: string[];
}
export declare function clouddomainsRegistrationDnsSettingsGlueRecordsToTerraform(struct?: ClouddomainsRegistrationDnsSettingsGlueRecords | cdktn.IResolvable): any;
export declare function clouddomainsRegistrationDnsSettingsGlueRecordsToHclTerraform(struct?: ClouddomainsRegistrationDnsSettingsGlueRecords | cdktn.IResolvable): any;
export declare class ClouddomainsRegistrationDnsSettingsGlueRecordsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ClouddomainsRegistrationDnsSettingsGlueRecords | cdktn.IResolvable | undefined;
    set internalValue(value: ClouddomainsRegistrationDnsSettingsGlueRecords | cdktn.IResolvable | undefined);
    private _hostName?;
    get hostName(): string;
    set hostName(value: string);
    get hostNameInput(): string | undefined;
    private _ipv4Addresses?;
    get ipv4Addresses(): string[];
    set ipv4Addresses(value: string[]);
    resetIpv4Addresses(): void;
    get ipv4AddressesInput(): string[] | undefined;
    private _ipv6Addresses?;
    get ipv6Addresses(): string[];
    set ipv6Addresses(value: string[]);
    resetIpv6Addresses(): void;
    get ipv6AddressesInput(): string[] | undefined;
}
export declare class ClouddomainsRegistrationDnsSettingsGlueRecordsList extends cdktn.ComplexList {
    internalValue?: ClouddomainsRegistrationDnsSettingsGlueRecords[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ClouddomainsRegistrationDnsSettingsGlueRecordsOutputReference;
}
export interface ClouddomainsRegistrationDnsSettings {
    /**
    * custom_dns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#custom_dns ClouddomainsRegistration#custom_dns}
    */
    readonly customDns?: ClouddomainsRegistrationDnsSettingsCustomDns;
    /**
    * glue_records block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#glue_records ClouddomainsRegistration#glue_records}
    */
    readonly glueRecords?: ClouddomainsRegistrationDnsSettingsGlueRecords[] | cdktn.IResolvable;
}
export declare function clouddomainsRegistrationDnsSettingsToTerraform(struct?: ClouddomainsRegistrationDnsSettingsOutputReference | ClouddomainsRegistrationDnsSettings): any;
export declare function clouddomainsRegistrationDnsSettingsToHclTerraform(struct?: ClouddomainsRegistrationDnsSettingsOutputReference | ClouddomainsRegistrationDnsSettings): any;
export declare class ClouddomainsRegistrationDnsSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddomainsRegistrationDnsSettings | undefined;
    set internalValue(value: ClouddomainsRegistrationDnsSettings | undefined);
    private _customDns;
    get customDns(): ClouddomainsRegistrationDnsSettingsCustomDnsOutputReference;
    putCustomDns(value: ClouddomainsRegistrationDnsSettingsCustomDns): void;
    resetCustomDns(): void;
    get customDnsInput(): ClouddomainsRegistrationDnsSettingsCustomDns | undefined;
    private _glueRecords;
    get glueRecords(): ClouddomainsRegistrationDnsSettingsGlueRecordsList;
    putGlueRecords(value: ClouddomainsRegistrationDnsSettingsGlueRecords[] | cdktn.IResolvable): void;
    resetGlueRecords(): void;
    get glueRecordsInput(): cdktn.IResolvable | ClouddomainsRegistrationDnsSettingsGlueRecords[] | undefined;
}
export interface ClouddomainsRegistrationManagementSettings {
    /**
    * The desired renewal method for this Registration. The actual renewalMethod is automatically updated to reflect this choice.
    * If unset or equal to RENEWAL_METHOD_UNSPECIFIED, the actual renewalMethod is treated as if it were set to AUTOMATIC_RENEWAL.
    * You cannot use RENEWAL_DISABLED during resource creation, and you can update the renewal status only when the Registration
    * resource has state ACTIVE or SUSPENDED.
    *
    * When preferredRenewalMethod is set to AUTOMATIC_RENEWAL, the actual renewalMethod can be set to RENEWAL_DISABLED in case of
    * problems with the billing account or reported domain abuse. In such cases, check the issues field on the Registration. After
    * the problem is resolved, the renewalMethod is automatically updated to preferredRenewalMethod in a few hours.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#preferred_renewal_method ClouddomainsRegistration#preferred_renewal_method}
    */
    readonly preferredRenewalMethod?: string;
    /**
    * Controls whether the domain can be transferred to another registrar. Values are UNLOCKED or LOCKED.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#transfer_lock_state ClouddomainsRegistration#transfer_lock_state}
    */
    readonly transferLockState?: string;
}
export declare function clouddomainsRegistrationManagementSettingsToTerraform(struct?: ClouddomainsRegistrationManagementSettingsOutputReference | ClouddomainsRegistrationManagementSettings): any;
export declare function clouddomainsRegistrationManagementSettingsToHclTerraform(struct?: ClouddomainsRegistrationManagementSettingsOutputReference | ClouddomainsRegistrationManagementSettings): any;
export declare class ClouddomainsRegistrationManagementSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddomainsRegistrationManagementSettings | undefined;
    set internalValue(value: ClouddomainsRegistrationManagementSettings | undefined);
    private _preferredRenewalMethod?;
    get preferredRenewalMethod(): string;
    set preferredRenewalMethod(value: string);
    resetPreferredRenewalMethod(): void;
    get preferredRenewalMethodInput(): string | undefined;
    get renewalMethod(): string;
    private _transferLockState?;
    get transferLockState(): string;
    set transferLockState(value: string);
    resetTransferLockState(): void;
    get transferLockStateInput(): string | undefined;
}
export interface ClouddomainsRegistrationTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#create ClouddomainsRegistration#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#delete ClouddomainsRegistration#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#update ClouddomainsRegistration#update}
    */
    readonly update?: string;
}
export declare function clouddomainsRegistrationTimeoutsToTerraform(struct?: ClouddomainsRegistrationTimeouts | cdktn.IResolvable): any;
export declare function clouddomainsRegistrationTimeoutsToHclTerraform(struct?: ClouddomainsRegistrationTimeouts | cdktn.IResolvable): any;
export declare class ClouddomainsRegistrationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddomainsRegistrationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ClouddomainsRegistrationTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface ClouddomainsRegistrationYearlyPrice {
    /**
    * The three-letter currency code defined in ISO 4217.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#currency_code ClouddomainsRegistration#currency_code}
    */
    readonly currencyCode?: string;
    /**
    * The whole units of the amount. For example if currencyCode is "USD", then 1 unit is one US dollar.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#units ClouddomainsRegistration#units}
    */
    readonly units?: string;
}
export declare function clouddomainsRegistrationYearlyPriceToTerraform(struct?: ClouddomainsRegistrationYearlyPriceOutputReference | ClouddomainsRegistrationYearlyPrice): any;
export declare function clouddomainsRegistrationYearlyPriceToHclTerraform(struct?: ClouddomainsRegistrationYearlyPriceOutputReference | ClouddomainsRegistrationYearlyPrice): any;
export declare class ClouddomainsRegistrationYearlyPriceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddomainsRegistrationYearlyPrice | undefined;
    set internalValue(value: ClouddomainsRegistrationYearlyPrice | undefined);
    private _currencyCode?;
    get currencyCode(): string;
    set currencyCode(value: string);
    resetCurrencyCode(): void;
    get currencyCodeInput(): string | undefined;
    private _units?;
    get units(): string;
    set units(value: string);
    resetUnits(): void;
    get unitsInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration google_clouddomains_registration}
*/
export declare class ClouddomainsRegistration extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_clouddomains_registration";
    /**
    * Generates CDKTN code for importing a ClouddomainsRegistration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ClouddomainsRegistration to import
    * @param importFromId The id of the existing ClouddomainsRegistration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ClouddomainsRegistration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/clouddomains_registration google_clouddomains_registration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ClouddomainsRegistrationConfig
    */
    constructor(scope: Construct, id: string, config: ClouddomainsRegistrationConfig);
    private _contactNotices?;
    get contactNotices(): string[];
    set contactNotices(value: string[]);
    resetContactNotices(): void;
    get contactNoticesInput(): string[] | undefined;
    get createTime(): string;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _domainNotices?;
    get domainNotices(): string[];
    set domainNotices(value: string[]);
    resetDomainNotices(): void;
    get domainNoticesInput(): string[] | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get expireTime(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get issues(): string[];
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get registerFailureReason(): string;
    get state(): string;
    get supportedPrivacy(): string[];
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _contactSettings;
    get contactSettings(): ClouddomainsRegistrationContactSettingsOutputReference;
    putContactSettings(value: ClouddomainsRegistrationContactSettings): void;
    get contactSettingsInput(): ClouddomainsRegistrationContactSettings | undefined;
    private _dnsSettings;
    get dnsSettings(): ClouddomainsRegistrationDnsSettingsOutputReference;
    putDnsSettings(value: ClouddomainsRegistrationDnsSettings): void;
    resetDnsSettings(): void;
    get dnsSettingsInput(): ClouddomainsRegistrationDnsSettings | undefined;
    private _managementSettings;
    get managementSettings(): ClouddomainsRegistrationManagementSettingsOutputReference;
    putManagementSettings(value: ClouddomainsRegistrationManagementSettings): void;
    resetManagementSettings(): void;
    get managementSettingsInput(): ClouddomainsRegistrationManagementSettings | undefined;
    private _timeouts;
    get timeouts(): ClouddomainsRegistrationTimeoutsOutputReference;
    putTimeouts(value: ClouddomainsRegistrationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ClouddomainsRegistrationTimeouts | undefined;
    private _yearlyPrice;
    get yearlyPrice(): ClouddomainsRegistrationYearlyPriceOutputReference;
    putYearlyPrice(value: ClouddomainsRegistrationYearlyPrice): void;
    get yearlyPriceInput(): ClouddomainsRegistrationYearlyPrice | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
