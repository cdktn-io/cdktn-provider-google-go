/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeSharedVpcServiceProjectConfig extends cdktn.TerraformMetaArguments {
    /**
    * The deletion policy for the shared VPC service. Setting ABANDON allows the resource
    * 				to be abandoned rather than deleted. Possible values are: "ABANDON".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_shared_vpc_service_project#deletion_policy ComputeSharedVpcServiceProject#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The ID of a host project to associate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_shared_vpc_service_project#host_project ComputeSharedVpcServiceProject#host_project}
    */
    readonly hostProject: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_shared_vpc_service_project#id ComputeSharedVpcServiceProject#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the project that will serve as a Shared VPC service project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_shared_vpc_service_project#service_project ComputeSharedVpcServiceProject#service_project}
    */
    readonly serviceProject: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_shared_vpc_service_project#timeouts ComputeSharedVpcServiceProject#timeouts}
    */
    readonly timeouts?: ComputeSharedVpcServiceProjectTimeouts;
}
export interface ComputeSharedVpcServiceProjectTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_shared_vpc_service_project#create ComputeSharedVpcServiceProject#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_shared_vpc_service_project#delete ComputeSharedVpcServiceProject#delete}
    */
    readonly delete?: string;
}
export declare function computeSharedVpcServiceProjectTimeoutsToTerraform(struct?: ComputeSharedVpcServiceProjectTimeouts | cdktn.IResolvable): any;
export declare function computeSharedVpcServiceProjectTimeoutsToHclTerraform(struct?: ComputeSharedVpcServiceProjectTimeouts | cdktn.IResolvable): any;
export declare class ComputeSharedVpcServiceProjectTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSharedVpcServiceProjectTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeSharedVpcServiceProjectTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_shared_vpc_service_project google_compute_shared_vpc_service_project}
*/
export declare class ComputeSharedVpcServiceProject extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_shared_vpc_service_project";
    /**
    * Generates CDKTN code for importing a ComputeSharedVpcServiceProject resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeSharedVpcServiceProject to import
    * @param importFromId The id of the existing ComputeSharedVpcServiceProject that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_shared_vpc_service_project#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeSharedVpcServiceProject to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_shared_vpc_service_project google_compute_shared_vpc_service_project} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeSharedVpcServiceProjectConfig
    */
    constructor(scope: Construct, id: string, config: ComputeSharedVpcServiceProjectConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _hostProject?;
    get hostProject(): string;
    set hostProject(value: string);
    get hostProjectInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _serviceProject?;
    get serviceProject(): string;
    set serviceProject(value: string);
    get serviceProjectInput(): string | undefined;
    private _timeouts;
    get timeouts(): ComputeSharedVpcServiceProjectTimeoutsOutputReference;
    putTimeouts(value: ComputeSharedVpcServiceProjectTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeSharedVpcServiceProjectTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
