/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CesAppRootAgentAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID or fully qualified resource name of the agent to associate as the
    * root agent of the app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_app_root_agent_association#agent_id CesAppRootAgentAssociation#agent_id}
    */
    readonly agentId: string;
    /**
    * The ID of the App. Used to construct the app resource name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_app_root_agent_association#app_id CesAppRootAgentAssociation#app_id}
    */
    readonly appId: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_app_root_agent_association#deletion_policy CesAppRootAgentAssociation#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_app_root_agent_association#id CesAppRootAgentAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the App.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_app_root_agent_association#location CesAppRootAgentAssociation#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_app_root_agent_association#project CesAppRootAgentAssociation#project}
    */
    readonly project?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_app_root_agent_association#timeouts CesAppRootAgentAssociation#timeouts}
    */
    readonly timeouts?: CesAppRootAgentAssociationTimeouts;
}
export interface CesAppRootAgentAssociationTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_app_root_agent_association#create CesAppRootAgentAssociation#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_app_root_agent_association#delete CesAppRootAgentAssociation#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_app_root_agent_association#update CesAppRootAgentAssociation#update}
    */
    readonly update?: string;
}
export declare function cesAppRootAgentAssociationTimeoutsToTerraform(struct?: CesAppRootAgentAssociationTimeouts | cdktn.IResolvable): any;
export declare function cesAppRootAgentAssociationTimeoutsToHclTerraform(struct?: CesAppRootAgentAssociationTimeouts | cdktn.IResolvable): any;
export declare class CesAppRootAgentAssociationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppRootAgentAssociationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CesAppRootAgentAssociationTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_app_root_agent_association google_ces_app_root_agent_association}
*/
export declare class CesAppRootAgentAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_ces_app_root_agent_association";
    /**
    * Generates CDKTN code for importing a CesAppRootAgentAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CesAppRootAgentAssociation to import
    * @param importFromId The id of the existing CesAppRootAgentAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_app_root_agent_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CesAppRootAgentAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_app_root_agent_association google_ces_app_root_agent_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CesAppRootAgentAssociationConfig
    */
    constructor(scope: Construct, id: string, config: CesAppRootAgentAssociationConfig);
    private _agentId?;
    get agentId(): string;
    set agentId(value: string);
    get agentIdInput(): string | undefined;
    private _appId?;
    get appId(): string;
    set appId(value: string);
    get appIdInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _timeouts;
    get timeouts(): CesAppRootAgentAssociationTimeoutsOutputReference;
    putTimeouts(value: CesAppRootAgentAssociationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CesAppRootAgentAssociationTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
