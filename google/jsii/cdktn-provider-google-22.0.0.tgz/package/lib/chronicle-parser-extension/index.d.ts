/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChronicleParserExtensionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Parser config could be a cbn snippet.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#cbn_snippet ChronicleParserExtension#cbn_snippet}
    */
    readonly cbnSnippet?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#deletion_policy ChronicleParserExtension#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#id ChronicleParserExtension#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#instance ChronicleParserExtension#instance}
    */
    readonly instance: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#location ChronicleParserExtension#location}
    */
    readonly location: string;
    /**
    * Raw log used to assist the user in creation of augmentation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#log ChronicleParserExtension#log}
    */
    readonly log?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#log_type ChronicleParserExtension#log_type}
    */
    readonly logType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#project ChronicleParserExtension#project}
    */
    readonly project?: string;
    /**
    * Flag to bypass parser extension validation.
    * If enabled, the parser extension won't be rejected during the validation
    * phase and validation will be skipped.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#validation_skipped ChronicleParserExtension#validation_skipped}
    */
    readonly validationSkipped?: boolean | cdktn.IResolvable;
    /**
    * dynamic_parsing block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#dynamic_parsing ChronicleParserExtension#dynamic_parsing}
    */
    readonly dynamicParsing?: ChronicleParserExtensionDynamicParsing;
    /**
    * field_extractors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#field_extractors ChronicleParserExtension#field_extractors}
    */
    readonly fieldExtractors?: ChronicleParserExtensionFieldExtractors;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#timeouts ChronicleParserExtension#timeouts}
    */
    readonly timeouts?: ChronicleParserExtensionTimeouts;
}
export interface ChronicleParserExtensionDynamicParsingOptedFields {
    /**
    * Path of the log field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#path ChronicleParserExtension#path}
    */
    readonly path?: string;
    /**
    * Sample value of the log field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#sample_value ChronicleParserExtension#sample_value}
    */
    readonly sampleValue?: string;
}
export declare function chronicleParserExtensionDynamicParsingOptedFieldsToTerraform(struct?: ChronicleParserExtensionDynamicParsingOptedFields | cdktn.IResolvable): any;
export declare function chronicleParserExtensionDynamicParsingOptedFieldsToHclTerraform(struct?: ChronicleParserExtensionDynamicParsingOptedFields | cdktn.IResolvable): any;
export declare class ChronicleParserExtensionDynamicParsingOptedFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleParserExtensionDynamicParsingOptedFields | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleParserExtensionDynamicParsingOptedFields | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _sampleValue?;
    get sampleValue(): string;
    set sampleValue(value: string);
    resetSampleValue(): void;
    get sampleValueInput(): string | undefined;
}
export declare class ChronicleParserExtensionDynamicParsingOptedFieldsList extends cdktn.ComplexList {
    internalValue?: ChronicleParserExtensionDynamicParsingOptedFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleParserExtensionDynamicParsingOptedFieldsOutputReference;
}
export interface ChronicleParserExtensionDynamicParsing {
    /**
    * opted_fields block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#opted_fields ChronicleParserExtension#opted_fields}
    */
    readonly optedFields?: ChronicleParserExtensionDynamicParsingOptedFields[] | cdktn.IResolvable;
}
export declare function chronicleParserExtensionDynamicParsingToTerraform(struct?: ChronicleParserExtensionDynamicParsingOutputReference | ChronicleParserExtensionDynamicParsing): any;
export declare function chronicleParserExtensionDynamicParsingToHclTerraform(struct?: ChronicleParserExtensionDynamicParsingOutputReference | ChronicleParserExtensionDynamicParsing): any;
export declare class ChronicleParserExtensionDynamicParsingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleParserExtensionDynamicParsing | undefined;
    set internalValue(value: ChronicleParserExtensionDynamicParsing | undefined);
    private _optedFields;
    get optedFields(): ChronicleParserExtensionDynamicParsingOptedFieldsList;
    putOptedFields(value: ChronicleParserExtensionDynamicParsingOptedFields[] | cdktn.IResolvable): void;
    resetOptedFields(): void;
    get optedFieldsInput(): cdktn.IResolvable | ChronicleParserExtensionDynamicParsingOptedFields[] | undefined;
}
export interface ChronicleParserExtensionFieldExtractorsExtractors {
    /**
    * Path in generated event which is to be populated. This is required if the
    * FieldExtractor is used to specify the parser extension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#destination_path ChronicleParserExtension#destination_path}
    */
    readonly destinationPath?: string;
    /**
    * Field path could be a json path, xml path or csv column name
    * depending on log format. It refers to a section or substring in raw log.
    * This is required if the FieldExtractor is used to specify the parser
    * extension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#field_path ChronicleParserExtension#field_path}
    */
    readonly fieldPath?: string;
    /**
    * Operator used for precondition.
    * Possible values:
    * EQUALS
    * NOT_EQUALS
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#precondition_op ChronicleParserExtension#precondition_op}
    */
    readonly preconditionOp?: string;
    /**
    * Precondition path could be a json path, xml path or csv column name
    * depending on log format. It refers to a section or substring in raw log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#precondition_path ChronicleParserExtension#precondition_path}
    */
    readonly preconditionPath?: string;
    /**
    * Precondition value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#precondition_value ChronicleParserExtension#precondition_value}
    */
    readonly preconditionValue?: string;
    /**
    * Value to be mapped to the destination path directly.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#value ChronicleParserExtension#value}
    */
    readonly value?: string;
}
export declare function chronicleParserExtensionFieldExtractorsExtractorsToTerraform(struct?: ChronicleParserExtensionFieldExtractorsExtractors | cdktn.IResolvable): any;
export declare function chronicleParserExtensionFieldExtractorsExtractorsToHclTerraform(struct?: ChronicleParserExtensionFieldExtractorsExtractors | cdktn.IResolvable): any;
export declare class ChronicleParserExtensionFieldExtractorsExtractorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleParserExtensionFieldExtractorsExtractors | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleParserExtensionFieldExtractorsExtractors | cdktn.IResolvable | undefined);
    private _destinationPath?;
    get destinationPath(): string;
    set destinationPath(value: string);
    resetDestinationPath(): void;
    get destinationPathInput(): string | undefined;
    private _fieldPath?;
    get fieldPath(): string;
    set fieldPath(value: string);
    resetFieldPath(): void;
    get fieldPathInput(): string | undefined;
    private _preconditionOp?;
    get preconditionOp(): string;
    set preconditionOp(value: string);
    resetPreconditionOp(): void;
    get preconditionOpInput(): string | undefined;
    private _preconditionPath?;
    get preconditionPath(): string;
    set preconditionPath(value: string);
    resetPreconditionPath(): void;
    get preconditionPathInput(): string | undefined;
    private _preconditionValue?;
    get preconditionValue(): string;
    set preconditionValue(value: string);
    resetPreconditionValue(): void;
    get preconditionValueInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ChronicleParserExtensionFieldExtractorsExtractorsList extends cdktn.ComplexList {
    internalValue?: ChronicleParserExtensionFieldExtractorsExtractors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleParserExtensionFieldExtractorsExtractorsOutputReference;
}
export interface ChronicleParserExtensionFieldExtractorsPreprocessConfig {
    /**
    * GROK Regex to extract the structured part of the log.
    * syntax documentation:
    * www.elastic.co/guide/en/logstash/current/plugins-filters-grok.html
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#grok_regex ChronicleParserExtension#grok_regex}
    */
    readonly grokRegex?: string;
    /**
    * Target field name for the structured part of the log.
    * This should match a SEMANTIC identifier from the grok expression.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#target ChronicleParserExtension#target}
    */
    readonly target?: string;
}
export declare function chronicleParserExtensionFieldExtractorsPreprocessConfigToTerraform(struct?: ChronicleParserExtensionFieldExtractorsPreprocessConfigOutputReference | ChronicleParserExtensionFieldExtractorsPreprocessConfig): any;
export declare function chronicleParserExtensionFieldExtractorsPreprocessConfigToHclTerraform(struct?: ChronicleParserExtensionFieldExtractorsPreprocessConfigOutputReference | ChronicleParserExtensionFieldExtractorsPreprocessConfig): any;
export declare class ChronicleParserExtensionFieldExtractorsPreprocessConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleParserExtensionFieldExtractorsPreprocessConfig | undefined;
    set internalValue(value: ChronicleParserExtensionFieldExtractorsPreprocessConfig | undefined);
    private _grokRegex?;
    get grokRegex(): string;
    set grokRegex(value: string);
    resetGrokRegex(): void;
    get grokRegexInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    resetTarget(): void;
    get targetInput(): string | undefined;
}
export interface ChronicleParserExtensionFieldExtractors {
    /**
    * Whether to append repeated fields or not.
    * When false, repeated fields will be replaced.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#append_repeated_fields ChronicleParserExtension#append_repeated_fields}
    */
    readonly appendRepeatedFields?: boolean | cdktn.IResolvable;
    /**
    * Possible values:
    * JSON
    * CSV
    * XML
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#log_format ChronicleParserExtension#log_format}
    */
    readonly logFormat?: string;
    /**
    * extractors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#extractors ChronicleParserExtension#extractors}
    */
    readonly extractors?: ChronicleParserExtensionFieldExtractorsExtractors[] | cdktn.IResolvable;
    /**
    * preprocess_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#preprocess_config ChronicleParserExtension#preprocess_config}
    */
    readonly preprocessConfig?: ChronicleParserExtensionFieldExtractorsPreprocessConfig;
}
export declare function chronicleParserExtensionFieldExtractorsToTerraform(struct?: ChronicleParserExtensionFieldExtractorsOutputReference | ChronicleParserExtensionFieldExtractors): any;
export declare function chronicleParserExtensionFieldExtractorsToHclTerraform(struct?: ChronicleParserExtensionFieldExtractorsOutputReference | ChronicleParserExtensionFieldExtractors): any;
export declare class ChronicleParserExtensionFieldExtractorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleParserExtensionFieldExtractors | undefined;
    set internalValue(value: ChronicleParserExtensionFieldExtractors | undefined);
    private _appendRepeatedFields?;
    get appendRepeatedFields(): boolean | cdktn.IResolvable;
    set appendRepeatedFields(value: boolean | cdktn.IResolvable);
    resetAppendRepeatedFields(): void;
    get appendRepeatedFieldsInput(): boolean | cdktn.IResolvable | undefined;
    private _logFormat?;
    get logFormat(): string;
    set logFormat(value: string);
    resetLogFormat(): void;
    get logFormatInput(): string | undefined;
    get transformedCbnSnippet(): string;
    private _extractors;
    get extractors(): ChronicleParserExtensionFieldExtractorsExtractorsList;
    putExtractors(value: ChronicleParserExtensionFieldExtractorsExtractors[] | cdktn.IResolvable): void;
    resetExtractors(): void;
    get extractorsInput(): cdktn.IResolvable | ChronicleParserExtensionFieldExtractorsExtractors[] | undefined;
    private _preprocessConfig;
    get preprocessConfig(): ChronicleParserExtensionFieldExtractorsPreprocessConfigOutputReference;
    putPreprocessConfig(value: ChronicleParserExtensionFieldExtractorsPreprocessConfig): void;
    resetPreprocessConfig(): void;
    get preprocessConfigInput(): ChronicleParserExtensionFieldExtractorsPreprocessConfig | undefined;
}
export interface ChronicleParserExtensionTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#create ChronicleParserExtension#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#delete ChronicleParserExtension#delete}
    */
    readonly delete?: string;
}
export declare function chronicleParserExtensionTimeoutsToTerraform(struct?: ChronicleParserExtensionTimeouts | cdktn.IResolvable): any;
export declare function chronicleParserExtensionTimeoutsToHclTerraform(struct?: ChronicleParserExtensionTimeouts | cdktn.IResolvable): any;
export declare class ChronicleParserExtensionTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleParserExtensionTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleParserExtensionTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension google_chronicle_parser_extension}
*/
export declare class ChronicleParserExtension extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_chronicle_parser_extension";
    /**
    * Generates CDKTN code for importing a ChronicleParserExtension resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChronicleParserExtension to import
    * @param importFromId The id of the existing ChronicleParserExtension that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChronicleParserExtension to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_parser_extension google_chronicle_parser_extension} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChronicleParserExtensionConfig
    */
    constructor(scope: Construct, id: string, config: ChronicleParserExtensionConfig);
    private _cbnSnippet?;
    get cbnSnippet(): string;
    set cbnSnippet(value: string);
    resetCbnSnippet(): void;
    get cbnSnippetInput(): string | undefined;
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    get extensionValidationReport(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instance?;
    get instance(): string;
    set instance(value: string);
    get instanceInput(): string | undefined;
    get lastLiveTime(): string;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _log?;
    get log(): string;
    set log(value: string);
    resetLog(): void;
    get logInput(): string | undefined;
    private _logType?;
    get logType(): string;
    set logType(value: string);
    get logTypeInput(): string | undefined;
    get name(): string;
    get parserextension(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get state(): string;
    get stateLastChangedTime(): string;
    get validationReport(): string;
    private _validationSkipped?;
    get validationSkipped(): boolean | cdktn.IResolvable;
    set validationSkipped(value: boolean | cdktn.IResolvable);
    resetValidationSkipped(): void;
    get validationSkippedInput(): boolean | cdktn.IResolvable | undefined;
    private _dynamicParsing;
    get dynamicParsing(): ChronicleParserExtensionDynamicParsingOutputReference;
    putDynamicParsing(value: ChronicleParserExtensionDynamicParsing): void;
    resetDynamicParsing(): void;
    get dynamicParsingInput(): ChronicleParserExtensionDynamicParsing | undefined;
    private _fieldExtractors;
    get fieldExtractors(): ChronicleParserExtensionFieldExtractorsOutputReference;
    putFieldExtractors(value: ChronicleParserExtensionFieldExtractors): void;
    resetFieldExtractors(): void;
    get fieldExtractorsInput(): ChronicleParserExtensionFieldExtractors | undefined;
    private _timeouts;
    get timeouts(): ChronicleParserExtensionTimeoutsOutputReference;
    putTimeouts(value: ChronicleParserExtensionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ChronicleParserExtensionTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
