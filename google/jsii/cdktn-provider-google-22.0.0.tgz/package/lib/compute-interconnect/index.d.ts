/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeInterconnectConfig extends cdktn.TerraformMetaArguments {
    /**
    * Administrative status of the interconnect. When this is set to true, the Interconnect is
    * functional and can carry traffic. When set to false, no packets can be carried over the
    * interconnect and no BGP routes are exchanged over it. By default, the status is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#admin_enabled ComputeInterconnect#admin_enabled}
    */
    readonly adminEnabled?: boolean | cdktn.IResolvable;
    /**
    * Customer name, to put in the Letter of Authorization as the party authorized to request a
    * crossconnect. This field is required for Dedicated and Partner Interconnect, should not be specified
    * for cross-cloud interconnect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#customer_name ComputeInterconnect#customer_name}
    */
    readonly customerName?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#deletion_policy ComputeInterconnect#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource. Provide this property when you create the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#description ComputeInterconnect#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#id ComputeInterconnect#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Type of interconnect. Note that a value IT_PRIVATE has been deprecated in favor of DEDICATED.
    * Can take one of the following values:
    *   - PARTNER: A partner-managed interconnection shared between customers though a partner.
    *   - DEDICATED: A dedicated physical interconnection with the customer. Possible values: ["DEDICATED", "PARTNER", "IT_PRIVATE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#interconnect_type ComputeInterconnect#interconnect_type}
    */
    readonly interconnectType: string;
    /**
    * Labels for this resource. These can only be added or modified by the setLabels
    * method. Each label key/value pair must comply with RFC1035. Label values may be empty.
    *
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#labels ComputeInterconnect#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Type of link requested. Note that this field indicates the speed of each of the links in the
    * bundle, not the speed of the entire bundle. Can take one of the following values:
    *   - LINK_TYPE_ETHERNET_10G_LR: A 10G Ethernet with LR optics.
    *   - LINK_TYPE_ETHERNET_100G_LR: A 100G Ethernet with LR optics.
    *   - LINK_TYPE_ETHERNET_400G_LR4: A 400G Ethernet with LR4 optics Possible values: ["LINK_TYPE_ETHERNET_10G_LR", "LINK_TYPE_ETHERNET_100G_LR", "LINK_TYPE_ETHERNET_400G_LR4"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#link_type ComputeInterconnect#link_type}
    */
    readonly linkType: string;
    /**
    * URL of the InterconnectLocation object that represents where this connection is requested to be provisioned.
    * Specifies the location inside Google's Networks.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#location ComputeInterconnect#location}
    */
    readonly location: string;
    /**
    * Enable or disable MACsec on this Interconnect connection.
    * MACsec enablement fails if the MACsec object is not specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#macsec_enabled ComputeInterconnect#macsec_enabled}
    */
    readonly macsecEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the resource. Provided by the client when the resource is created. The name must be
    * 1-63 characters long, and comply with RFC1035. Specifically, the name must be 1-63 characters
    * long and match the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the first
    * character must be a lowercase letter, and all following characters must be a dash,
    * lowercase letter, or digit, except the last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#name ComputeInterconnect#name}
    */
    readonly name: string;
    /**
    * Email address to contact the customer NOC for operations and maintenance notifications
    * regarding this Interconnect. If specified, this will be used for notifications in addition to
    * all other forms described, such as Cloud Monitoring logs alerting and Cloud Notifications.
    * This field is required for users who sign up for Cloud Interconnect using workforce identity
    * federation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#noc_contact_email ComputeInterconnect#noc_contact_email}
    */
    readonly nocContactEmail?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#project ComputeInterconnect#project}
    */
    readonly project?: string;
    /**
    * Indicates that this is a Cross-Cloud Interconnect. This field specifies the location outside
    * of Google's network that the interconnect is connected to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#remote_location ComputeInterconnect#remote_location}
    */
    readonly remoteLocation?: string;
    /**
    * List of features to request for this Interconnect connection. This field is only applicable during Interconnect creation and cannot be modified later.
    * Possible values include:
    * - 'IF_MACSEC': Provisions the connection on hardware ports that support MACsec (Media Access Control Security). If not specified, the system may allocate non-MACsec capable ports if available.
    * - 'IF_L2_FORWARDING': Provisions the connection for Layer 2 (L2) traffic forwarding. If not specified, the connection defaults to Layer 3 (L3) traffic forwarding.
    * - 'IF_CROSS_SITE_NETWORK': Provisions the connection exclusively for Cross-Site Networking.
    *       Note: 'MACSEC' is a legacy value for compatibility reasons. 'IF_MACSEC' should be used. Choosing 'MACSEC' can result in allocation of non-MACsec capable ports, if available. Possible values: ["MACSEC", "CROSS_SITE_NETWORK", "IF_MACSEC", "IF_L2_FORWARDING"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#requested_features ComputeInterconnect#requested_features}
    */
    readonly requestedFeatures?: string[];
    /**
    * Target number of physical links in the link bundle, as requested by the customer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#requested_link_count ComputeInterconnect#requested_link_count}
    */
    readonly requestedLinkCount: number;
    /**
    * macsec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#macsec ComputeInterconnect#macsec}
    */
    readonly macsec?: ComputeInterconnectMacsec;
    /**
    * params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#params ComputeInterconnect#params}
    */
    readonly params?: ComputeInterconnectParams;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#timeouts ComputeInterconnect#timeouts}
    */
    readonly timeouts?: ComputeInterconnectTimeouts;
}
export interface ComputeInterconnectCircuitInfos {
}
export declare function computeInterconnectCircuitInfosToTerraform(struct?: ComputeInterconnectCircuitInfos): any;
export declare function computeInterconnectCircuitInfosToHclTerraform(struct?: ComputeInterconnectCircuitInfos): any;
export declare class ComputeInterconnectCircuitInfosOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInterconnectCircuitInfos | undefined;
    set internalValue(value: ComputeInterconnectCircuitInfos | undefined);
    get customerDemarcId(): string;
    get googleCircuitId(): string;
    get googleDemarcId(): string;
}
export declare class ComputeInterconnectCircuitInfosList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInterconnectCircuitInfosOutputReference;
}
export interface ComputeInterconnectExpectedOutages {
}
export declare function computeInterconnectExpectedOutagesToTerraform(struct?: ComputeInterconnectExpectedOutages): any;
export declare function computeInterconnectExpectedOutagesToHclTerraform(struct?: ComputeInterconnectExpectedOutages): any;
export declare class ComputeInterconnectExpectedOutagesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInterconnectExpectedOutages | undefined;
    set internalValue(value: ComputeInterconnectExpectedOutages | undefined);
    get affectedCircuits(): string[];
    get description(): string;
    get endTime(): string;
    get issueType(): string;
    get name(): string;
    get source(): string;
    get startTime(): string;
    get state(): string;
}
export declare class ComputeInterconnectExpectedOutagesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInterconnectExpectedOutagesOutputReference;
}
export interface ComputeInterconnectMacsecPreSharedKeys {
    /**
    * If set to true, the Interconnect connection is configured with a should-secure
    * MACsec security policy, that allows the Google router to fallback to cleartext
    * traffic if the MKA session cannot be established. By default, the Interconnect
    * connection is configured with a must-secure security policy that drops all traffic
    * if the MKA session cannot be established with your router.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#fail_open ComputeInterconnect#fail_open}
    */
    readonly failOpen?: boolean | cdktn.IResolvable;
    /**
    * A name for this pre-shared key. The name must be 1-63 characters long, and
    *  comply with RFC1035. Specifically, the name must be 1-63 characters long and match
    *  the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the first character
    *  must be a lowercase letter, and all following characters must be a dash, lowercase
    *  letter, or digit, except the last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#name ComputeInterconnect#name}
    */
    readonly name: string;
    /**
    * A RFC3339 timestamp on or after which the key is valid. startTime can be in the
    * future. If the keychain has a single key, startTime can be omitted. If the keychain
    * has multiple keys, startTime is mandatory for each key. The start times of keys must
    * be in increasing order. The start times of two consecutive keys must be at least 6
    * hours apart.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#start_time ComputeInterconnect#start_time}
    */
    readonly startTime?: string;
}
export declare function computeInterconnectMacsecPreSharedKeysToTerraform(struct?: ComputeInterconnectMacsecPreSharedKeys | cdktn.IResolvable): any;
export declare function computeInterconnectMacsecPreSharedKeysToHclTerraform(struct?: ComputeInterconnectMacsecPreSharedKeys | cdktn.IResolvable): any;
export declare class ComputeInterconnectMacsecPreSharedKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInterconnectMacsecPreSharedKeys | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInterconnectMacsecPreSharedKeys | cdktn.IResolvable | undefined);
    private _failOpen?;
    get failOpen(): boolean | cdktn.IResolvable;
    set failOpen(value: boolean | cdktn.IResolvable);
    resetFailOpen(): void;
    get failOpenInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    resetStartTime(): void;
    get startTimeInput(): string | undefined;
}
export declare class ComputeInterconnectMacsecPreSharedKeysList extends cdktn.ComplexList {
    internalValue?: ComputeInterconnectMacsecPreSharedKeys[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInterconnectMacsecPreSharedKeysOutputReference;
}
export interface ComputeInterconnectMacsec {
    /**
    * If set to true, the Interconnect connection is configured with a should-secure
    * MACsec security policy, that allows the Google router to fallback to cleartext
    * traffic if the MKA session cannot be established. By default, the Interconnect
    * connection is configured with a must-secure security policy that drops all traffic
    * if the MKA session cannot be established with your router.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#fail_open ComputeInterconnect#fail_open}
    */
    readonly failOpen?: boolean | cdktn.IResolvable;
    /**
    * pre_shared_keys block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#pre_shared_keys ComputeInterconnect#pre_shared_keys}
    */
    readonly preSharedKeys: ComputeInterconnectMacsecPreSharedKeys[] | cdktn.IResolvable;
}
export declare function computeInterconnectMacsecToTerraform(struct?: ComputeInterconnectMacsecOutputReference | ComputeInterconnectMacsec): any;
export declare function computeInterconnectMacsecToHclTerraform(struct?: ComputeInterconnectMacsecOutputReference | ComputeInterconnectMacsec): any;
export declare class ComputeInterconnectMacsecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInterconnectMacsec | undefined;
    set internalValue(value: ComputeInterconnectMacsec | undefined);
    private _failOpen?;
    get failOpen(): boolean | cdktn.IResolvable;
    set failOpen(value: boolean | cdktn.IResolvable);
    resetFailOpen(): void;
    get failOpenInput(): boolean | cdktn.IResolvable | undefined;
    private _preSharedKeys;
    get preSharedKeys(): ComputeInterconnectMacsecPreSharedKeysList;
    putPreSharedKeys(value: ComputeInterconnectMacsecPreSharedKeys[] | cdktn.IResolvable): void;
    get preSharedKeysInput(): cdktn.IResolvable | ComputeInterconnectMacsecPreSharedKeys[] | undefined;
}
export interface ComputeInterconnectParams {
    /**
    * Resource manager tags to be bound to the interconnect. Tag keys and values have the
    * same definition as resource manager tags. Keys must be in the format tagKeys/{tag_key_id},
    * and values are in the format tagValues/456.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#resource_manager_tags ComputeInterconnect#resource_manager_tags}
    */
    readonly resourceManagerTags?: {
        [key: string]: string;
    };
}
export declare function computeInterconnectParamsToTerraform(struct?: ComputeInterconnectParamsOutputReference | ComputeInterconnectParams): any;
export declare function computeInterconnectParamsToHclTerraform(struct?: ComputeInterconnectParamsOutputReference | ComputeInterconnectParams): any;
export declare class ComputeInterconnectParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInterconnectParams | undefined;
    set internalValue(value: ComputeInterconnectParams | undefined);
    private _resourceManagerTags?;
    get resourceManagerTags(): {
        [key: string]: string;
    };
    set resourceManagerTags(value: {
        [key: string]: string;
    });
    resetResourceManagerTags(): void;
    get resourceManagerTagsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ComputeInterconnectTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#create ComputeInterconnect#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#delete ComputeInterconnect#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#update ComputeInterconnect#update}
    */
    readonly update?: string;
}
export declare function computeInterconnectTimeoutsToTerraform(struct?: ComputeInterconnectTimeouts | cdktn.IResolvable): any;
export declare function computeInterconnectTimeoutsToHclTerraform(struct?: ComputeInterconnectTimeouts | cdktn.IResolvable): any;
export declare class ComputeInterconnectTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInterconnectTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInterconnectTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect google_compute_interconnect}
*/
export declare class ComputeInterconnect extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_interconnect";
    /**
    * Generates CDKTN code for importing a ComputeInterconnect resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeInterconnect to import
    * @param importFromId The id of the existing ComputeInterconnect that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeInterconnect to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect google_compute_interconnect} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeInterconnectConfig
    */
    constructor(scope: Construct, id: string, config: ComputeInterconnectConfig);
    private _adminEnabled?;
    get adminEnabled(): boolean | cdktn.IResolvable;
    set adminEnabled(value: boolean | cdktn.IResolvable);
    resetAdminEnabled(): void;
    get adminEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get availableFeatures(): string[];
    private _circuitInfos;
    get circuitInfos(): ComputeInterconnectCircuitInfosList;
    get creationTimestamp(): string;
    private _customerName?;
    get customerName(): string;
    set customerName(value: string);
    resetCustomerName(): void;
    get customerNameInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get effectiveLocation(): string;
    private _expectedOutages;
    get expectedOutages(): ComputeInterconnectExpectedOutagesList;
    get googleIpAddress(): string;
    get googleReferenceId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get interconnectAttachments(): string[];
    get interconnectGroups(): string[];
    private _interconnectType?;
    get interconnectType(): string;
    set interconnectType(value: string);
    get interconnectTypeInput(): string | undefined;
    get labelFingerprint(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _linkType?;
    get linkType(): string;
    set linkType(value: string);
    get linkTypeInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _macsecEnabled?;
    get macsecEnabled(): boolean | cdktn.IResolvable;
    set macsecEnabled(value: boolean | cdktn.IResolvable);
    resetMacsecEnabled(): void;
    get macsecEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nocContactEmail?;
    get nocContactEmail(): string;
    set nocContactEmail(value: string);
    resetNocContactEmail(): void;
    get nocContactEmailInput(): string | undefined;
    get operationalStatus(): string;
    get peerIpAddress(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get provisionedLinkCount(): number;
    private _remoteLocation?;
    get remoteLocation(): string;
    set remoteLocation(value: string);
    resetRemoteLocation(): void;
    get remoteLocationInput(): string | undefined;
    private _requestedFeatures?;
    get requestedFeatures(): string[];
    set requestedFeatures(value: string[]);
    resetRequestedFeatures(): void;
    get requestedFeaturesInput(): string[] | undefined;
    private _requestedLinkCount?;
    get requestedLinkCount(): number;
    set requestedLinkCount(value: number);
    get requestedLinkCountInput(): number | undefined;
    get satisfiesPzs(): cdktn.IResolvable;
    get state(): string;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get wireGroups(): string[];
    private _macsec;
    get macsec(): ComputeInterconnectMacsecOutputReference;
    putMacsec(value: ComputeInterconnectMacsec): void;
    resetMacsec(): void;
    get macsecInput(): ComputeInterconnectMacsec | undefined;
    private _params;
    get params(): ComputeInterconnectParamsOutputReference;
    putParams(value: ComputeInterconnectParams): void;
    resetParams(): void;
    get paramsInput(): ComputeInterconnectParams | undefined;
    private _timeouts;
    get timeouts(): ComputeInterconnectTimeoutsOutputReference;
    putTimeouts(value: ComputeInterconnectTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeInterconnectTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
