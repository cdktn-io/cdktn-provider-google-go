/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface Cloudbuildv2RepositoryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Allows clients to store small amounts of arbitrary data.
    *
    * **Note**: This field is non-authoritative, and will only manage the annotations present in your configuration.
    * Please refer to the field 'effective_annotations' for all of the annotations present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_repository#annotations Cloudbuildv2Repository#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_repository#deletion_policy Cloudbuildv2Repository#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_repository#id Cloudbuildv2Repository#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location for the resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_repository#location Cloudbuildv2Repository#location}
    */
    readonly location?: string;
    /**
    * Name of the repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_repository#name Cloudbuildv2Repository#name}
    */
    readonly name: string;
    /**
    * The connection for the resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_repository#parent_connection Cloudbuildv2Repository#parent_connection}
    */
    readonly parentConnection: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_repository#project Cloudbuildv2Repository#project}
    */
    readonly project?: string;
    /**
    * Required. Git Clone HTTPS URI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_repository#remote_uri Cloudbuildv2Repository#remote_uri}
    */
    readonly remoteUri: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_repository#timeouts Cloudbuildv2Repository#timeouts}
    */
    readonly timeouts?: Cloudbuildv2RepositoryTimeouts;
}
export interface Cloudbuildv2RepositoryTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_repository#create Cloudbuildv2Repository#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_repository#delete Cloudbuildv2Repository#delete}
    */
    readonly delete?: string;
}
export declare function cloudbuildv2RepositoryTimeoutsToTerraform(struct?: Cloudbuildv2RepositoryTimeouts | cdktn.IResolvable): any;
export declare function cloudbuildv2RepositoryTimeoutsToHclTerraform(struct?: Cloudbuildv2RepositoryTimeouts | cdktn.IResolvable): any;
export declare class Cloudbuildv2RepositoryTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Cloudbuildv2RepositoryTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: Cloudbuildv2RepositoryTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_repository google_cloudbuildv2_repository}
*/
export declare class Cloudbuildv2Repository extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_cloudbuildv2_repository";
    /**
    * Generates CDKTN code for importing a Cloudbuildv2Repository resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Cloudbuildv2Repository to import
    * @param importFromId The id of the existing Cloudbuildv2Repository that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_repository#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Cloudbuildv2Repository to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudbuildv2_repository google_cloudbuildv2_repository} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options Cloudbuildv2RepositoryConfig
    */
    constructor(scope: Construct, id: string, config: Cloudbuildv2RepositoryConfig);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _effectiveAnnotations;
    get effectiveAnnotations(): cdktn.StringMap;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parentConnection?;
    get parentConnection(): string;
    set parentConnection(value: string);
    get parentConnectionInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _remoteUri?;
    get remoteUri(): string;
    set remoteUri(value: string);
    get remoteUriInput(): string | undefined;
    get updateTime(): string;
    private _timeouts;
    get timeouts(): Cloudbuildv2RepositoryTimeoutsOutputReference;
    putTimeouts(value: Cloudbuildv2RepositoryTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | Cloudbuildv2RepositoryTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
