/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BigtableGcPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the column family.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_gc_policy#column_family BigtableGcPolicy#column_family}
    */
    readonly columnFamily: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_gc_policy#deletion_policy BigtableGcPolicy#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Serialized JSON string for garbage collection policy. Conflicts with "mode", "max_age" and "max_version".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_gc_policy#gc_rules BigtableGcPolicy#gc_rules}
    */
    readonly gcRules?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_gc_policy#id BigtableGcPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Allows ignoring warnings when updating the GC policy. This can be used
    * 				to increase the gc policy on replicated clusters. Doing this may make clusters be
    * 				inconsistent for a longer period of time, before using this make sure you understand
    * 				the risks listed at https://cloud.google.com/bigtable/docs/garbage-collection#increasing
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_gc_policy#ignore_warnings BigtableGcPolicy#ignore_warnings}
    */
    readonly ignoreWarnings?: boolean | cdktn.IResolvable;
    /**
    * The name of the Bigtable instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_gc_policy#instance_name BigtableGcPolicy#instance_name}
    */
    readonly instanceName: string;
    /**
    * NOTE: 'gc_rules' is more flexible, and should be preferred over this field for new resources. This field may be deprecated in the future. If multiple policies are set, you should choose between UNION OR INTERSECTION.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_gc_policy#mode BigtableGcPolicy#mode}
    */
    readonly mode?: string;
    /**
    * The ID of the project in which the resource belongs. If it is not provided, the provider project is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_gc_policy#project BigtableGcPolicy#project}
    */
    readonly project?: string;
    /**
    * The name of the table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_gc_policy#table BigtableGcPolicy#table}
    */
    readonly table: string;
    /**
    * max_age block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_gc_policy#max_age BigtableGcPolicy#max_age}
    */
    readonly maxAge?: BigtableGcPolicyMaxAge;
    /**
    * max_version block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_gc_policy#max_version BigtableGcPolicy#max_version}
    */
    readonly maxVersion?: BigtableGcPolicyMaxVersion[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_gc_policy#timeouts BigtableGcPolicy#timeouts}
    */
    readonly timeouts?: BigtableGcPolicyTimeouts;
}
export interface BigtableGcPolicyMaxAge {
    /**
    * Number of days before applying GC policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_gc_policy#days BigtableGcPolicy#days}
    */
    readonly days?: number;
    /**
    * Duration before applying GC policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_gc_policy#duration BigtableGcPolicy#duration}
    */
    readonly duration?: string;
}
export declare function bigtableGcPolicyMaxAgeToTerraform(struct?: BigtableGcPolicyMaxAgeOutputReference | BigtableGcPolicyMaxAge): any;
export declare function bigtableGcPolicyMaxAgeToHclTerraform(struct?: BigtableGcPolicyMaxAgeOutputReference | BigtableGcPolicyMaxAge): any;
export declare class BigtableGcPolicyMaxAgeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigtableGcPolicyMaxAge | undefined;
    set internalValue(value: BigtableGcPolicyMaxAge | undefined);
    private _days?;
    get days(): number;
    set days(value: number);
    resetDays(): void;
    get daysInput(): number | undefined;
    private _duration?;
    get duration(): string;
    set duration(value: string);
    resetDuration(): void;
    get durationInput(): string | undefined;
}
export interface BigtableGcPolicyMaxVersion {
    /**
    * Number of version before applying the GC policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_gc_policy#number BigtableGcPolicy#number}
    */
    readonly number: number;
}
export declare function bigtableGcPolicyMaxVersionToTerraform(struct?: BigtableGcPolicyMaxVersion | cdktn.IResolvable): any;
export declare function bigtableGcPolicyMaxVersionToHclTerraform(struct?: BigtableGcPolicyMaxVersion | cdktn.IResolvable): any;
export declare class BigtableGcPolicyMaxVersionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BigtableGcPolicyMaxVersion | cdktn.IResolvable | undefined;
    set internalValue(value: BigtableGcPolicyMaxVersion | cdktn.IResolvable | undefined);
    private _number?;
    get number(): number;
    set number(value: number);
    get numberInput(): number | undefined;
}
export declare class BigtableGcPolicyMaxVersionList extends cdktn.ComplexList {
    internalValue?: BigtableGcPolicyMaxVersion[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BigtableGcPolicyMaxVersionOutputReference;
}
export interface BigtableGcPolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_gc_policy#create BigtableGcPolicy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_gc_policy#delete BigtableGcPolicy#delete}
    */
    readonly delete?: string;
}
export declare function bigtableGcPolicyTimeoutsToTerraform(struct?: BigtableGcPolicyTimeouts | cdktn.IResolvable): any;
export declare function bigtableGcPolicyTimeoutsToHclTerraform(struct?: BigtableGcPolicyTimeouts | cdktn.IResolvable): any;
export declare class BigtableGcPolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigtableGcPolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BigtableGcPolicyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_gc_policy google_bigtable_gc_policy}
*/
export declare class BigtableGcPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_bigtable_gc_policy";
    /**
    * Generates CDKTN code for importing a BigtableGcPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BigtableGcPolicy to import
    * @param importFromId The id of the existing BigtableGcPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_gc_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BigtableGcPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigtable_gc_policy google_bigtable_gc_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BigtableGcPolicyConfig
    */
    constructor(scope: Construct, id: string, config: BigtableGcPolicyConfig);
    private _columnFamily?;
    get columnFamily(): string;
    set columnFamily(value: string);
    get columnFamilyInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _gcRules?;
    get gcRules(): string;
    set gcRules(value: string);
    resetGcRules(): void;
    get gcRulesInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ignoreWarnings?;
    get ignoreWarnings(): boolean | cdktn.IResolvable;
    set ignoreWarnings(value: boolean | cdktn.IResolvable);
    resetIgnoreWarnings(): void;
    get ignoreWarningsInput(): boolean | cdktn.IResolvable | undefined;
    private _instanceName?;
    get instanceName(): string;
    set instanceName(value: string);
    get instanceNameInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _table?;
    get table(): string;
    set table(value: string);
    get tableInput(): string | undefined;
    private _maxAge;
    get maxAge(): BigtableGcPolicyMaxAgeOutputReference;
    putMaxAge(value: BigtableGcPolicyMaxAge): void;
    resetMaxAge(): void;
    get maxAgeInput(): BigtableGcPolicyMaxAge | undefined;
    private _maxVersion;
    get maxVersion(): BigtableGcPolicyMaxVersionList;
    putMaxVersion(value: BigtableGcPolicyMaxVersion[] | cdktn.IResolvable): void;
    resetMaxVersion(): void;
    get maxVersionInput(): cdktn.IResolvable | BigtableGcPolicyMaxVersion[] | undefined;
    private _timeouts;
    get timeouts(): BigtableGcPolicyTimeoutsOutputReference;
    putTimeouts(value: BigtableGcPolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BigtableGcPolicyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
