/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CesAgentConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID to use for the agent, which will become the final component of
    * the agent's resource name. If not provided, a unique ID will be
    * automatically assigned for the agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#agent_id CesAgent#agent_id}
    */
    readonly agentId?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#app CesAgent#app}
    */
    readonly app: string;
    /**
    * List of child agents in the agent tree.
    * Format: 'projects/{project}/locations/{location}/apps/{app}/agents/{agent}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#child_agents CesAgent#child_agents}
    */
    readonly childAgents?: string[];
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#deletion_policy CesAgent#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Human-readable description of the agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#description CesAgent#description}
    */
    readonly description?: string;
    /**
    * Display name of the agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#display_name CesAgent#display_name}
    */
    readonly displayName: string;
    /**
    * List of guardrails for the agent.
    * Format:
    * 'projects/{project}/locations/{location}/apps/{app}/guardrails/{guardrail}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#guardrails CesAgent#guardrails}
    */
    readonly guardrails?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#id CesAgent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Instructions for the LLM model to guide the agent's behavior.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#instruction CesAgent#instruction}
    */
    readonly instruction?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#location CesAgent#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#project CesAgent#project}
    */
    readonly project?: string;
    /**
    * List of available tools for the agent.
    * Format: 'projects/{project}/locations/{location}/apps/{app}/tools/{tool}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#tools CesAgent#tools}
    */
    readonly tools?: string[];
    /**
    * after_agent_callbacks block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#after_agent_callbacks CesAgent#after_agent_callbacks}
    */
    readonly afterAgentCallbacks?: CesAgentAfterAgentCallbacks[] | cdktn.IResolvable;
    /**
    * after_model_callbacks block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#after_model_callbacks CesAgent#after_model_callbacks}
    */
    readonly afterModelCallbacks?: CesAgentAfterModelCallbacks[] | cdktn.IResolvable;
    /**
    * after_tool_callbacks block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#after_tool_callbacks CesAgent#after_tool_callbacks}
    */
    readonly afterToolCallbacks?: CesAgentAfterToolCallbacks[] | cdktn.IResolvable;
    /**
    * before_agent_callbacks block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#before_agent_callbacks CesAgent#before_agent_callbacks}
    */
    readonly beforeAgentCallbacks?: CesAgentBeforeAgentCallbacks[] | cdktn.IResolvable;
    /**
    * before_model_callbacks block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#before_model_callbacks CesAgent#before_model_callbacks}
    */
    readonly beforeModelCallbacks?: CesAgentBeforeModelCallbacks[] | cdktn.IResolvable;
    /**
    * before_tool_callbacks block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#before_tool_callbacks CesAgent#before_tool_callbacks}
    */
    readonly beforeToolCallbacks?: CesAgentBeforeToolCallbacks[] | cdktn.IResolvable;
    /**
    * llm_agent block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#llm_agent CesAgent#llm_agent}
    */
    readonly llmAgent?: CesAgentLlmAgent;
    /**
    * model_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#model_settings CesAgent#model_settings}
    */
    readonly modelSettings?: CesAgentModelSettings;
    /**
    * remote_a2a_agent block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#remote_a2a_agent CesAgent#remote_a2a_agent}
    */
    readonly remoteA2AAgent?: CesAgentRemoteA2AAgent;
    /**
    * remote_dialogflow_agent block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#remote_dialogflow_agent CesAgent#remote_dialogflow_agent}
    */
    readonly remoteDialogflowAgent?: CesAgentRemoteDialogflowAgent;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#timeouts CesAgent#timeouts}
    */
    readonly timeouts?: CesAgentTimeouts;
    /**
    * toolsets block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#toolsets CesAgent#toolsets}
    */
    readonly toolsets?: CesAgentToolsets[] | cdktn.IResolvable;
    /**
    * transfer_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#transfer_rules CesAgent#transfer_rules}
    */
    readonly transferRules?: CesAgentTransferRules[] | cdktn.IResolvable;
}
export interface CesAgentAfterAgentCallbacks {
    /**
    * Human-readable description of the callback.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#description CesAgent#description}
    */
    readonly description?: string;
    /**
    * Whether the callback is disabled. Disabled callbacks are ignored by the
    * agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#disabled CesAgent#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * If enabled, the callback will also be executed on intermediate model
    * outputs. This setting only affects after model callback.
    * **ENABLE WITH CAUTION**. Typically after model callback only needs to be
    * executed after receiving all model responses. Enabling proactive execution
    * may have negative implication on the execution cost and latency, and
    * should only be enabled in rare situations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#proactive_execution_enabled CesAgent#proactive_execution_enabled}
    */
    readonly proactiveExecutionEnabled?: boolean | cdktn.IResolvable;
    /**
    * The python code to execute for the callback.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#python_code CesAgent#python_code}
    */
    readonly pythonCode: string;
}
export declare function cesAgentAfterAgentCallbacksToTerraform(struct?: CesAgentAfterAgentCallbacks | cdktn.IResolvable): any;
export declare function cesAgentAfterAgentCallbacksToHclTerraform(struct?: CesAgentAfterAgentCallbacks | cdktn.IResolvable): any;
export declare class CesAgentAfterAgentCallbacksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesAgentAfterAgentCallbacks | cdktn.IResolvable | undefined;
    set internalValue(value: CesAgentAfterAgentCallbacks | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _proactiveExecutionEnabled?;
    get proactiveExecutionEnabled(): boolean | cdktn.IResolvable;
    set proactiveExecutionEnabled(value: boolean | cdktn.IResolvable);
    resetProactiveExecutionEnabled(): void;
    get proactiveExecutionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _pythonCode?;
    get pythonCode(): string;
    set pythonCode(value: string);
    get pythonCodeInput(): string | undefined;
}
export declare class CesAgentAfterAgentCallbacksList extends cdktn.ComplexList {
    internalValue?: CesAgentAfterAgentCallbacks[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesAgentAfterAgentCallbacksOutputReference;
}
export interface CesAgentAfterModelCallbacks {
    /**
    * Human-readable description of the callback.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#description CesAgent#description}
    */
    readonly description?: string;
    /**
    * Whether the callback is disabled. Disabled callbacks are ignored by the
    * agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#disabled CesAgent#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * If enabled, the callback will also be executed on intermediate model
    * outputs. This setting only affects after model callback.
    * **ENABLE WITH CAUTION**. Typically after model callback only needs to be
    * executed after receiving all model responses. Enabling proactive execution
    * may have negative implication on the execution cost and latency, and
    * should only be enabled in rare situations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#proactive_execution_enabled CesAgent#proactive_execution_enabled}
    */
    readonly proactiveExecutionEnabled?: boolean | cdktn.IResolvable;
    /**
    * The python code to execute for the callback.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#python_code CesAgent#python_code}
    */
    readonly pythonCode: string;
}
export declare function cesAgentAfterModelCallbacksToTerraform(struct?: CesAgentAfterModelCallbacks | cdktn.IResolvable): any;
export declare function cesAgentAfterModelCallbacksToHclTerraform(struct?: CesAgentAfterModelCallbacks | cdktn.IResolvable): any;
export declare class CesAgentAfterModelCallbacksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesAgentAfterModelCallbacks | cdktn.IResolvable | undefined;
    set internalValue(value: CesAgentAfterModelCallbacks | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _proactiveExecutionEnabled?;
    get proactiveExecutionEnabled(): boolean | cdktn.IResolvable;
    set proactiveExecutionEnabled(value: boolean | cdktn.IResolvable);
    resetProactiveExecutionEnabled(): void;
    get proactiveExecutionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _pythonCode?;
    get pythonCode(): string;
    set pythonCode(value: string);
    get pythonCodeInput(): string | undefined;
}
export declare class CesAgentAfterModelCallbacksList extends cdktn.ComplexList {
    internalValue?: CesAgentAfterModelCallbacks[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesAgentAfterModelCallbacksOutputReference;
}
export interface CesAgentAfterToolCallbacks {
    /**
    * Human-readable description of the callback.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#description CesAgent#description}
    */
    readonly description?: string;
    /**
    * Whether the callback is disabled. Disabled callbacks are ignored by the
    * agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#disabled CesAgent#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * If enabled, the callback will also be executed on intermediate model
    * outputs. This setting only affects after model callback.
    * **ENABLE WITH CAUTION**. Typically after model callback only needs to be
    * executed after receiving all model responses. Enabling proactive execution
    * may have negative implication on the execution cost and latency, and
    * should only be enabled in rare situations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#proactive_execution_enabled CesAgent#proactive_execution_enabled}
    */
    readonly proactiveExecutionEnabled?: boolean | cdktn.IResolvable;
    /**
    * The python code to execute for the callback.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#python_code CesAgent#python_code}
    */
    readonly pythonCode: string;
}
export declare function cesAgentAfterToolCallbacksToTerraform(struct?: CesAgentAfterToolCallbacks | cdktn.IResolvable): any;
export declare function cesAgentAfterToolCallbacksToHclTerraform(struct?: CesAgentAfterToolCallbacks | cdktn.IResolvable): any;
export declare class CesAgentAfterToolCallbacksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesAgentAfterToolCallbacks | cdktn.IResolvable | undefined;
    set internalValue(value: CesAgentAfterToolCallbacks | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _proactiveExecutionEnabled?;
    get proactiveExecutionEnabled(): boolean | cdktn.IResolvable;
    set proactiveExecutionEnabled(value: boolean | cdktn.IResolvable);
    resetProactiveExecutionEnabled(): void;
    get proactiveExecutionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _pythonCode?;
    get pythonCode(): string;
    set pythonCode(value: string);
    get pythonCodeInput(): string | undefined;
}
export declare class CesAgentAfterToolCallbacksList extends cdktn.ComplexList {
    internalValue?: CesAgentAfterToolCallbacks[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesAgentAfterToolCallbacksOutputReference;
}
export interface CesAgentBeforeAgentCallbacks {
    /**
    * Human-readable description of the callback.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#description CesAgent#description}
    */
    readonly description?: string;
    /**
    * Whether the callback is disabled. Disabled callbacks are ignored by the
    * agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#disabled CesAgent#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * If enabled, the callback will also be executed on intermediate model
    * outputs. This setting only affects after model callback.
    * **ENABLE WITH CAUTION**. Typically after model callback only needs to be
    * executed after receiving all model responses. Enabling proactive execution
    * may have negative implication on the execution cost and latency, and
    * should only be enabled in rare situations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#proactive_execution_enabled CesAgent#proactive_execution_enabled}
    */
    readonly proactiveExecutionEnabled?: boolean | cdktn.IResolvable;
    /**
    * The python code to execute for the callback.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#python_code CesAgent#python_code}
    */
    readonly pythonCode: string;
}
export declare function cesAgentBeforeAgentCallbacksToTerraform(struct?: CesAgentBeforeAgentCallbacks | cdktn.IResolvable): any;
export declare function cesAgentBeforeAgentCallbacksToHclTerraform(struct?: CesAgentBeforeAgentCallbacks | cdktn.IResolvable): any;
export declare class CesAgentBeforeAgentCallbacksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesAgentBeforeAgentCallbacks | cdktn.IResolvable | undefined;
    set internalValue(value: CesAgentBeforeAgentCallbacks | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _proactiveExecutionEnabled?;
    get proactiveExecutionEnabled(): boolean | cdktn.IResolvable;
    set proactiveExecutionEnabled(value: boolean | cdktn.IResolvable);
    resetProactiveExecutionEnabled(): void;
    get proactiveExecutionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _pythonCode?;
    get pythonCode(): string;
    set pythonCode(value: string);
    get pythonCodeInput(): string | undefined;
}
export declare class CesAgentBeforeAgentCallbacksList extends cdktn.ComplexList {
    internalValue?: CesAgentBeforeAgentCallbacks[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesAgentBeforeAgentCallbacksOutputReference;
}
export interface CesAgentBeforeModelCallbacks {
    /**
    * Human-readable description of the callback.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#description CesAgent#description}
    */
    readonly description?: string;
    /**
    * Whether the callback is disabled. Disabled callbacks are ignored by the
    * agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#disabled CesAgent#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * If enabled, the callback will also be executed on intermediate model
    * outputs. This setting only affects after model callback.
    * **ENABLE WITH CAUTION**. Typically after model callback only needs to be
    * executed after receiving all model responses. Enabling proactive execution
    * may have negative implication on the execution cost and latency, and
    * should only be enabled in rare situations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#proactive_execution_enabled CesAgent#proactive_execution_enabled}
    */
    readonly proactiveExecutionEnabled?: boolean | cdktn.IResolvable;
    /**
    * The python code to execute for the callback.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#python_code CesAgent#python_code}
    */
    readonly pythonCode: string;
}
export declare function cesAgentBeforeModelCallbacksToTerraform(struct?: CesAgentBeforeModelCallbacks | cdktn.IResolvable): any;
export declare function cesAgentBeforeModelCallbacksToHclTerraform(struct?: CesAgentBeforeModelCallbacks | cdktn.IResolvable): any;
export declare class CesAgentBeforeModelCallbacksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesAgentBeforeModelCallbacks | cdktn.IResolvable | undefined;
    set internalValue(value: CesAgentBeforeModelCallbacks | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _proactiveExecutionEnabled?;
    get proactiveExecutionEnabled(): boolean | cdktn.IResolvable;
    set proactiveExecutionEnabled(value: boolean | cdktn.IResolvable);
    resetProactiveExecutionEnabled(): void;
    get proactiveExecutionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _pythonCode?;
    get pythonCode(): string;
    set pythonCode(value: string);
    get pythonCodeInput(): string | undefined;
}
export declare class CesAgentBeforeModelCallbacksList extends cdktn.ComplexList {
    internalValue?: CesAgentBeforeModelCallbacks[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesAgentBeforeModelCallbacksOutputReference;
}
export interface CesAgentBeforeToolCallbacks {
    /**
    * Human-readable description of the callback.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#description CesAgent#description}
    */
    readonly description?: string;
    /**
    * Whether the callback is disabled. Disabled callbacks are ignored by the
    * agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#disabled CesAgent#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * If enabled, the callback will also be executed on intermediate model
    * outputs. This setting only affects after model callback.
    * **ENABLE WITH CAUTION**. Typically after model callback only needs to be
    * executed after receiving all model responses. Enabling proactive execution
    * may have negative implication on the execution cost and latency, and
    * should only be enabled in rare situations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#proactive_execution_enabled CesAgent#proactive_execution_enabled}
    */
    readonly proactiveExecutionEnabled?: boolean | cdktn.IResolvable;
    /**
    * The python code to execute for the callback.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#python_code CesAgent#python_code}
    */
    readonly pythonCode: string;
}
export declare function cesAgentBeforeToolCallbacksToTerraform(struct?: CesAgentBeforeToolCallbacks | cdktn.IResolvable): any;
export declare function cesAgentBeforeToolCallbacksToHclTerraform(struct?: CesAgentBeforeToolCallbacks | cdktn.IResolvable): any;
export declare class CesAgentBeforeToolCallbacksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesAgentBeforeToolCallbacks | cdktn.IResolvable | undefined;
    set internalValue(value: CesAgentBeforeToolCallbacks | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _proactiveExecutionEnabled?;
    get proactiveExecutionEnabled(): boolean | cdktn.IResolvable;
    set proactiveExecutionEnabled(value: boolean | cdktn.IResolvable);
    resetProactiveExecutionEnabled(): void;
    get proactiveExecutionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _pythonCode?;
    get pythonCode(): string;
    set pythonCode(value: string);
    get pythonCodeInput(): string | undefined;
}
export declare class CesAgentBeforeToolCallbacksList extends cdktn.ComplexList {
    internalValue?: CesAgentBeforeToolCallbacks[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesAgentBeforeToolCallbacksOutputReference;
}
export interface CesAgentLlmAgent {
}
export declare function cesAgentLlmAgentToTerraform(struct?: CesAgentLlmAgentOutputReference | CesAgentLlmAgent): any;
export declare function cesAgentLlmAgentToHclTerraform(struct?: CesAgentLlmAgentOutputReference | CesAgentLlmAgent): any;
export declare class CesAgentLlmAgentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAgentLlmAgent | undefined;
    set internalValue(value: CesAgentLlmAgent | undefined);
}
export interface CesAgentModelSettings {
    /**
    * The LLM model that the agent should use.
    * If not set, the agent will inherit the model from its parent agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#model CesAgent#model}
    */
    readonly model?: string;
    /**
    * If set, this temperature will be used for the LLM model. Temperature
    * controls the randomness of the model's responses. Lower temperatures
    * produce responses that are more predictable. Higher temperatures produce
    * responses that are more creative.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#temperature CesAgent#temperature}
    */
    readonly temperature?: number;
    /**
    * The thinking level of the model. Possible values: ["DEFAULT", "LOW", "MEDIUM", "HIGH"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#thinking_level CesAgent#thinking_level}
    */
    readonly thinkingLevel?: string;
}
export declare function cesAgentModelSettingsToTerraform(struct?: CesAgentModelSettingsOutputReference | CesAgentModelSettings): any;
export declare function cesAgentModelSettingsToHclTerraform(struct?: CesAgentModelSettingsOutputReference | CesAgentModelSettings): any;
export declare class CesAgentModelSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAgentModelSettings | undefined;
    set internalValue(value: CesAgentModelSettings | undefined);
    private _model?;
    get model(): string;
    set model(value: string);
    resetModel(): void;
    get modelInput(): string | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _thinkingLevel?;
    get thinkingLevel(): string;
    set thinkingLevel(value: string);
    resetThinkingLevel(): void;
    get thinkingLevelInput(): string | undefined;
}
export interface CesAgentRemoteA2AAgentA2AConfigAgentCardSkills {
    /**
    * A detailed description of the skill.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#description CesAgent#description}
    */
    readonly description: string;
    /**
    * Example prompts or scenarios that this skill can handle.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#examples CesAgent#examples}
    */
    readonly examples?: string[];
    /**
    * A unique identifier for the agent's skill.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#id CesAgent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * The set of supported input media types for this skill, overriding the
    * agent's defaults.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#input_modes CesAgent#input_modes}
    */
    readonly inputModes?: string[];
    /**
    * A human-readable name for the skill.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#name CesAgent#name}
    */
    readonly name: string;
    /**
    * The set of supported output media types for this skill, overriding the
    * agent's defaults.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#output_modes CesAgent#output_modes}
    */
    readonly outputModes?: string[];
    /**
    * A set of keywords describing the skill's capabilities.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#tags CesAgent#tags}
    */
    readonly tags: string[];
}
export declare function cesAgentRemoteA2AAgentA2AConfigAgentCardSkillsToTerraform(struct?: CesAgentRemoteA2AAgentA2AConfigAgentCardSkills | cdktn.IResolvable): any;
export declare function cesAgentRemoteA2AAgentA2AConfigAgentCardSkillsToHclTerraform(struct?: CesAgentRemoteA2AAgentA2AConfigAgentCardSkills | cdktn.IResolvable): any;
export declare class CesAgentRemoteA2AAgentA2AConfigAgentCardSkillsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesAgentRemoteA2AAgentA2AConfigAgentCardSkills | cdktn.IResolvable | undefined;
    set internalValue(value: CesAgentRemoteA2AAgentA2AConfigAgentCardSkills | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _examples?;
    get examples(): string[];
    set examples(value: string[]);
    resetExamples(): void;
    get examplesInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _inputModes?;
    get inputModes(): string[];
    set inputModes(value: string[]);
    resetInputModes(): void;
    get inputModesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _outputModes?;
    get outputModes(): string[];
    set outputModes(value: string[]);
    resetOutputModes(): void;
    get outputModesInput(): string[] | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    get tagsInput(): string[] | undefined;
}
export declare class CesAgentRemoteA2AAgentA2AConfigAgentCardSkillsList extends cdktn.ComplexList {
    internalValue?: CesAgentRemoteA2AAgentA2AConfigAgentCardSkills[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesAgentRemoteA2AAgentA2AConfigAgentCardSkillsOutputReference;
}
export interface CesAgentRemoteA2AAgentA2AConfigAgentCardSupportedInterfaces {
    /**
    * The protocol binding supported at this URL. The core ones officially
    * supported are JSONRPC, GRPC and HTTP+JSON.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#protocol_binding CesAgent#protocol_binding}
    */
    readonly protocolBinding: string;
    /**
    * The version of the A2A protocol this interface exposes.
    * Examples: "0.3", "1.0"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#protocol_version CesAgent#protocol_version}
    */
    readonly protocolVersion: string;
    /**
    * Tenant ID to be used in the request when calling the agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#tenant CesAgent#tenant}
    */
    readonly tenant?: string;
    /**
    * The URL where this interface is available. Must be a valid absolute HTTPS
    * URL in production.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#url CesAgent#url}
    */
    readonly url: string;
}
export declare function cesAgentRemoteA2AAgentA2AConfigAgentCardSupportedInterfacesToTerraform(struct?: CesAgentRemoteA2AAgentA2AConfigAgentCardSupportedInterfaces | cdktn.IResolvable): any;
export declare function cesAgentRemoteA2AAgentA2AConfigAgentCardSupportedInterfacesToHclTerraform(struct?: CesAgentRemoteA2AAgentA2AConfigAgentCardSupportedInterfaces | cdktn.IResolvable): any;
export declare class CesAgentRemoteA2AAgentA2AConfigAgentCardSupportedInterfacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesAgentRemoteA2AAgentA2AConfigAgentCardSupportedInterfaces | cdktn.IResolvable | undefined;
    set internalValue(value: CesAgentRemoteA2AAgentA2AConfigAgentCardSupportedInterfaces | cdktn.IResolvable | undefined);
    private _protocolBinding?;
    get protocolBinding(): string;
    set protocolBinding(value: string);
    get protocolBindingInput(): string | undefined;
    private _protocolVersion?;
    get protocolVersion(): string;
    set protocolVersion(value: string);
    get protocolVersionInput(): string | undefined;
    private _tenant?;
    get tenant(): string;
    set tenant(value: string);
    resetTenant(): void;
    get tenantInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export declare class CesAgentRemoteA2AAgentA2AConfigAgentCardSupportedInterfacesList extends cdktn.ComplexList {
    internalValue?: CesAgentRemoteA2AAgentA2AConfigAgentCardSupportedInterfaces[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesAgentRemoteA2AAgentA2AConfigAgentCardSupportedInterfacesOutputReference;
}
export interface CesAgentRemoteA2AAgentA2AConfigAgentCard {
    /**
    * A description of the agent's domain of action/solution space.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#description CesAgent#description}
    */
    readonly description: string;
    /**
    * A human-readable name for the agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#name CesAgent#name}
    */
    readonly name: string;
    /**
    * The version of the agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#version CesAgent#version}
    */
    readonly version: string;
    /**
    * skills block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#skills CesAgent#skills}
    */
    readonly skills: CesAgentRemoteA2AAgentA2AConfigAgentCardSkills[] | cdktn.IResolvable;
    /**
    * supported_interfaces block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#supported_interfaces CesAgent#supported_interfaces}
    */
    readonly supportedInterfaces: CesAgentRemoteA2AAgentA2AConfigAgentCardSupportedInterfaces[] | cdktn.IResolvable;
}
export declare function cesAgentRemoteA2AAgentA2AConfigAgentCardToTerraform(struct?: CesAgentRemoteA2AAgentA2AConfigAgentCardOutputReference | CesAgentRemoteA2AAgentA2AConfigAgentCard): any;
export declare function cesAgentRemoteA2AAgentA2AConfigAgentCardToHclTerraform(struct?: CesAgentRemoteA2AAgentA2AConfigAgentCardOutputReference | CesAgentRemoteA2AAgentA2AConfigAgentCard): any;
export declare class CesAgentRemoteA2AAgentA2AConfigAgentCardOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAgentRemoteA2AAgentA2AConfigAgentCard | undefined;
    set internalValue(value: CesAgentRemoteA2AAgentA2AConfigAgentCard | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
    private _skills;
    get skills(): CesAgentRemoteA2AAgentA2AConfigAgentCardSkillsList;
    putSkills(value: CesAgentRemoteA2AAgentA2AConfigAgentCardSkills[] | cdktn.IResolvable): void;
    get skillsInput(): cdktn.IResolvable | CesAgentRemoteA2AAgentA2AConfigAgentCardSkills[] | undefined;
    private _supportedInterfaces;
    get supportedInterfaces(): CesAgentRemoteA2AAgentA2AConfigAgentCardSupportedInterfacesList;
    putSupportedInterfaces(value: CesAgentRemoteA2AAgentA2AConfigAgentCardSupportedInterfaces[] | cdktn.IResolvable): void;
    get supportedInterfacesInput(): cdktn.IResolvable | CesAgentRemoteA2AAgentA2AConfigAgentCardSupportedInterfaces[] | undefined;
}
export interface CesAgentRemoteA2AAgentA2AConfigApiAuthenticationApiKeyConfig {
    /**
    * The name of the SecretManager secret version resource storing the API key.
    * Format: 'projects/{project}/secrets/{secret}/versions/{version}'
    * Note: You should grant 'roles/secretmanager.secretAccessor' role to the CES
    * service agent
    * 'service-@gcp-sa-ces.iam.gserviceaccount.com'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#api_key_secret_version CesAgent#api_key_secret_version}
    */
    readonly apiKeySecretVersion: string;
    /**
    * The parameter name or the header name of the API key.
    * E.g., If the API request is "https://example.com/act?X-Api-Key=", "X-Api-Key" would be the parameter name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#key_name CesAgent#key_name}
    */
    readonly keyName: string;
    /**
    * Key location in the request.
    * Possible values:
    * HEADER
    * QUERY_STRING
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#request_location CesAgent#request_location}
    */
    readonly requestLocation: string;
}
export declare function cesAgentRemoteA2AAgentA2AConfigApiAuthenticationApiKeyConfigToTerraform(struct?: CesAgentRemoteA2AAgentA2AConfigApiAuthenticationApiKeyConfigOutputReference | CesAgentRemoteA2AAgentA2AConfigApiAuthenticationApiKeyConfig): any;
export declare function cesAgentRemoteA2AAgentA2AConfigApiAuthenticationApiKeyConfigToHclTerraform(struct?: CesAgentRemoteA2AAgentA2AConfigApiAuthenticationApiKeyConfigOutputReference | CesAgentRemoteA2AAgentA2AConfigApiAuthenticationApiKeyConfig): any;
export declare class CesAgentRemoteA2AAgentA2AConfigApiAuthenticationApiKeyConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAgentRemoteA2AAgentA2AConfigApiAuthenticationApiKeyConfig | undefined;
    set internalValue(value: CesAgentRemoteA2AAgentA2AConfigApiAuthenticationApiKeyConfig | undefined);
    private _apiKeySecretVersion?;
    get apiKeySecretVersion(): string;
    set apiKeySecretVersion(value: string);
    get apiKeySecretVersionInput(): string | undefined;
    private _keyName?;
    get keyName(): string;
    set keyName(value: string);
    get keyNameInput(): string | undefined;
    private _requestLocation?;
    get requestLocation(): string;
    set requestLocation(value: string);
    get requestLocationInput(): string | undefined;
}
export interface CesAgentRemoteA2AAgentA2AConfigApiAuthenticationBearerTokenConfig {
    /**
    * The bearer token.
    * Must be in the format '$context.variables.<name_of_variable>'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#token CesAgent#token}
    */
    readonly token: string;
}
export declare function cesAgentRemoteA2AAgentA2AConfigApiAuthenticationBearerTokenConfigToTerraform(struct?: CesAgentRemoteA2AAgentA2AConfigApiAuthenticationBearerTokenConfigOutputReference | CesAgentRemoteA2AAgentA2AConfigApiAuthenticationBearerTokenConfig): any;
export declare function cesAgentRemoteA2AAgentA2AConfigApiAuthenticationBearerTokenConfigToHclTerraform(struct?: CesAgentRemoteA2AAgentA2AConfigApiAuthenticationBearerTokenConfigOutputReference | CesAgentRemoteA2AAgentA2AConfigApiAuthenticationBearerTokenConfig): any;
export declare class CesAgentRemoteA2AAgentA2AConfigApiAuthenticationBearerTokenConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAgentRemoteA2AAgentA2AConfigApiAuthenticationBearerTokenConfig | undefined;
    set internalValue(value: CesAgentRemoteA2AAgentA2AConfigApiAuthenticationBearerTokenConfig | undefined);
    private _token?;
    get token(): string;
    set token(value: string);
    get tokenInput(): string | undefined;
}
export interface CesAgentRemoteA2AAgentA2AConfigApiAuthenticationOauthConfig {
    /**
    * The client ID from the OAuth provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#client_id CesAgent#client_id}
    */
    readonly clientId: string;
    /**
    * The name of the SecretManager secret version resource storing the
    * client secret.
    * Format: 'projects/{project}/secrets/{secret}/versions/{version}'
    *
    * Note: You should grant 'roles/secretmanager.secretAccessor' role to the CES
    * service agent
    * 'service-@gcp-sa-ces.iam.gserviceaccount.com'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#client_secret_version CesAgent#client_secret_version}
    */
    readonly clientSecretVersion: string;
    /**
    * OAuth grant types.
    * Possible values:
    * CLIENT_CREDENTIAL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#oauth_grant_type CesAgent#oauth_grant_type}
    */
    readonly oauthGrantType: string;
    /**
    * The OAuth scopes to grant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#scopes CesAgent#scopes}
    */
    readonly scopes?: string[];
    /**
    * The token endpoint in the OAuth provider to exchange for an access token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#token_endpoint CesAgent#token_endpoint}
    */
    readonly tokenEndpoint: string;
}
export declare function cesAgentRemoteA2AAgentA2AConfigApiAuthenticationOauthConfigToTerraform(struct?: CesAgentRemoteA2AAgentA2AConfigApiAuthenticationOauthConfigOutputReference | CesAgentRemoteA2AAgentA2AConfigApiAuthenticationOauthConfig): any;
export declare function cesAgentRemoteA2AAgentA2AConfigApiAuthenticationOauthConfigToHclTerraform(struct?: CesAgentRemoteA2AAgentA2AConfigApiAuthenticationOauthConfigOutputReference | CesAgentRemoteA2AAgentA2AConfigApiAuthenticationOauthConfig): any;
export declare class CesAgentRemoteA2AAgentA2AConfigApiAuthenticationOauthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAgentRemoteA2AAgentA2AConfigApiAuthenticationOauthConfig | undefined;
    set internalValue(value: CesAgentRemoteA2AAgentA2AConfigApiAuthenticationOauthConfig | undefined);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    get clientIdInput(): string | undefined;
    private _clientSecretVersion?;
    get clientSecretVersion(): string;
    set clientSecretVersion(value: string);
    get clientSecretVersionInput(): string | undefined;
    private _oauthGrantType?;
    get oauthGrantType(): string;
    set oauthGrantType(value: string);
    get oauthGrantTypeInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
    private _tokenEndpoint?;
    get tokenEndpoint(): string;
    set tokenEndpoint(value: string);
    get tokenEndpointInput(): string | undefined;
}
export interface CesAgentRemoteA2AAgentA2AConfigApiAuthenticationServiceAccountAuthConfig {
    /**
    * The OAuth scopes to grant. If not specified, the default scope
    * 'https://www.googleapis.com/auth/cloud-platform' is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#scopes CesAgent#scopes}
    */
    readonly scopes?: string[];
    /**
    * The email address of the service account used for authenticatation. CES
    * uses this service account to exchange an access token and the access token
    * is then sent in the 'Authorization' header of the request.
    *
    * The service account must have the
    * 'roles/iam.serviceAccountTokenCreator' role granted to the
    * CES service agent
    * 'service-@gcp-sa-ces.iam.gserviceaccount.com'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#service_account CesAgent#service_account}
    */
    readonly serviceAccount: string;
}
export declare function cesAgentRemoteA2AAgentA2AConfigApiAuthenticationServiceAccountAuthConfigToTerraform(struct?: CesAgentRemoteA2AAgentA2AConfigApiAuthenticationServiceAccountAuthConfigOutputReference | CesAgentRemoteA2AAgentA2AConfigApiAuthenticationServiceAccountAuthConfig): any;
export declare function cesAgentRemoteA2AAgentA2AConfigApiAuthenticationServiceAccountAuthConfigToHclTerraform(struct?: CesAgentRemoteA2AAgentA2AConfigApiAuthenticationServiceAccountAuthConfigOutputReference | CesAgentRemoteA2AAgentA2AConfigApiAuthenticationServiceAccountAuthConfig): any;
export declare class CesAgentRemoteA2AAgentA2AConfigApiAuthenticationServiceAccountAuthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAgentRemoteA2AAgentA2AConfigApiAuthenticationServiceAccountAuthConfig | undefined;
    set internalValue(value: CesAgentRemoteA2AAgentA2AConfigApiAuthenticationServiceAccountAuthConfig | undefined);
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
    private _serviceAccount?;
    get serviceAccount(): string;
    set serviceAccount(value: string);
    get serviceAccountInput(): string | undefined;
}
export interface CesAgentRemoteA2AAgentA2AConfigApiAuthentication {
    /**
    * api_key_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#api_key_config CesAgent#api_key_config}
    */
    readonly apiKeyConfig?: CesAgentRemoteA2AAgentA2AConfigApiAuthenticationApiKeyConfig;
    /**
    * bearer_token_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#bearer_token_config CesAgent#bearer_token_config}
    */
    readonly bearerTokenConfig?: CesAgentRemoteA2AAgentA2AConfigApiAuthenticationBearerTokenConfig;
    /**
    * oauth_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#oauth_config CesAgent#oauth_config}
    */
    readonly oauthConfig?: CesAgentRemoteA2AAgentA2AConfigApiAuthenticationOauthConfig;
    /**
    * service_account_auth_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#service_account_auth_config CesAgent#service_account_auth_config}
    */
    readonly serviceAccountAuthConfig?: CesAgentRemoteA2AAgentA2AConfigApiAuthenticationServiceAccountAuthConfig;
}
export declare function cesAgentRemoteA2AAgentA2AConfigApiAuthenticationToTerraform(struct?: CesAgentRemoteA2AAgentA2AConfigApiAuthenticationOutputReference | CesAgentRemoteA2AAgentA2AConfigApiAuthentication): any;
export declare function cesAgentRemoteA2AAgentA2AConfigApiAuthenticationToHclTerraform(struct?: CesAgentRemoteA2AAgentA2AConfigApiAuthenticationOutputReference | CesAgentRemoteA2AAgentA2AConfigApiAuthentication): any;
export declare class CesAgentRemoteA2AAgentA2AConfigApiAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAgentRemoteA2AAgentA2AConfigApiAuthentication | undefined;
    set internalValue(value: CesAgentRemoteA2AAgentA2AConfigApiAuthentication | undefined);
    private _apiKeyConfig;
    get apiKeyConfig(): CesAgentRemoteA2AAgentA2AConfigApiAuthenticationApiKeyConfigOutputReference;
    putApiKeyConfig(value: CesAgentRemoteA2AAgentA2AConfigApiAuthenticationApiKeyConfig): void;
    resetApiKeyConfig(): void;
    get apiKeyConfigInput(): CesAgentRemoteA2AAgentA2AConfigApiAuthenticationApiKeyConfig | undefined;
    private _bearerTokenConfig;
    get bearerTokenConfig(): CesAgentRemoteA2AAgentA2AConfigApiAuthenticationBearerTokenConfigOutputReference;
    putBearerTokenConfig(value: CesAgentRemoteA2AAgentA2AConfigApiAuthenticationBearerTokenConfig): void;
    resetBearerTokenConfig(): void;
    get bearerTokenConfigInput(): CesAgentRemoteA2AAgentA2AConfigApiAuthenticationBearerTokenConfig | undefined;
    private _oauthConfig;
    get oauthConfig(): CesAgentRemoteA2AAgentA2AConfigApiAuthenticationOauthConfigOutputReference;
    putOauthConfig(value: CesAgentRemoteA2AAgentA2AConfigApiAuthenticationOauthConfig): void;
    resetOauthConfig(): void;
    get oauthConfigInput(): CesAgentRemoteA2AAgentA2AConfigApiAuthenticationOauthConfig | undefined;
    private _serviceAccountAuthConfig;
    get serviceAccountAuthConfig(): CesAgentRemoteA2AAgentA2AConfigApiAuthenticationServiceAccountAuthConfigOutputReference;
    putServiceAccountAuthConfig(value: CesAgentRemoteA2AAgentA2AConfigApiAuthenticationServiceAccountAuthConfig): void;
    resetServiceAccountAuthConfig(): void;
    get serviceAccountAuthConfigInput(): CesAgentRemoteA2AAgentA2AConfigApiAuthenticationServiceAccountAuthConfig | undefined;
}
export interface CesAgentRemoteA2AAgentA2AConfig {
    /**
    * Reference to the agent in the Agent Registry.
    * Format: 'projects/{project}/locations/{location}/agents/{agent}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#agent_registry CesAgent#agent_registry}
    */
    readonly agentRegistry?: string;
    /**
    * If not empty, interactions with the remote A2A agent will use this context
    * ID. This context_id field can refer to a session variable like
    * '$context.variables.order_agent_session_id'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#context_id CesAgent#context_id}
    */
    readonly contextId?: string;
    /**
    * Mapping of input variable names of remote agent to GECX variable names.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#input_variable_mapping CesAgent#input_variable_mapping}
    */
    readonly inputVariableMapping?: {
        [key: string]: string;
    };
    /**
    * Mapping of output variable names of remote agent to GECX variable names.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#output_variable_mapping CesAgent#output_variable_mapping}
    */
    readonly outputVariableMapping?: {
        [key: string]: string;
    };
    /**
    * Whether streaming is enabled for the remote agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#streaming_enabled CesAgent#streaming_enabled}
    */
    readonly streamingEnabled?: boolean | cdktn.IResolvable;
    /**
    * agent_card block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#agent_card CesAgent#agent_card}
    */
    readonly agentCard?: CesAgentRemoteA2AAgentA2AConfigAgentCard;
    /**
    * api_authentication block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#api_authentication CesAgent#api_authentication}
    */
    readonly apiAuthentication?: CesAgentRemoteA2AAgentA2AConfigApiAuthentication;
}
export declare function cesAgentRemoteA2AAgentA2AConfigToTerraform(struct?: CesAgentRemoteA2AAgentA2AConfigOutputReference | CesAgentRemoteA2AAgentA2AConfig): any;
export declare function cesAgentRemoteA2AAgentA2AConfigToHclTerraform(struct?: CesAgentRemoteA2AAgentA2AConfigOutputReference | CesAgentRemoteA2AAgentA2AConfig): any;
export declare class CesAgentRemoteA2AAgentA2AConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAgentRemoteA2AAgentA2AConfig | undefined;
    set internalValue(value: CesAgentRemoteA2AAgentA2AConfig | undefined);
    private _agentRegistry?;
    get agentRegistry(): string;
    set agentRegistry(value: string);
    resetAgentRegistry(): void;
    get agentRegistryInput(): string | undefined;
    private _contextId?;
    get contextId(): string;
    set contextId(value: string);
    resetContextId(): void;
    get contextIdInput(): string | undefined;
    private _inputVariableMapping?;
    get inputVariableMapping(): {
        [key: string]: string;
    };
    set inputVariableMapping(value: {
        [key: string]: string;
    });
    resetInputVariableMapping(): void;
    get inputVariableMappingInput(): {
        [key: string]: string;
    } | undefined;
    private _outputVariableMapping?;
    get outputVariableMapping(): {
        [key: string]: string;
    };
    set outputVariableMapping(value: {
        [key: string]: string;
    });
    resetOutputVariableMapping(): void;
    get outputVariableMappingInput(): {
        [key: string]: string;
    } | undefined;
    private _streamingEnabled?;
    get streamingEnabled(): boolean | cdktn.IResolvable;
    set streamingEnabled(value: boolean | cdktn.IResolvable);
    resetStreamingEnabled(): void;
    get streamingEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _agentCard;
    get agentCard(): CesAgentRemoteA2AAgentA2AConfigAgentCardOutputReference;
    putAgentCard(value: CesAgentRemoteA2AAgentA2AConfigAgentCard): void;
    resetAgentCard(): void;
    get agentCardInput(): CesAgentRemoteA2AAgentA2AConfigAgentCard | undefined;
    private _apiAuthentication;
    get apiAuthentication(): CesAgentRemoteA2AAgentA2AConfigApiAuthenticationOutputReference;
    putApiAuthentication(value: CesAgentRemoteA2AAgentA2AConfigApiAuthentication): void;
    resetApiAuthentication(): void;
    get apiAuthenticationInput(): CesAgentRemoteA2AAgentA2AConfigApiAuthentication | undefined;
}
export interface CesAgentRemoteA2AAgent {
    /**
    * a2a_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#a2a_config CesAgent#a2a_config}
    */
    readonly a2AConfig: CesAgentRemoteA2AAgentA2AConfig;
}
export declare function cesAgentRemoteA2AAgentToTerraform(struct?: CesAgentRemoteA2AAgentOutputReference | CesAgentRemoteA2AAgent): any;
export declare function cesAgentRemoteA2AAgentToHclTerraform(struct?: CesAgentRemoteA2AAgentOutputReference | CesAgentRemoteA2AAgent): any;
export declare class CesAgentRemoteA2AAgentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAgentRemoteA2AAgent | undefined;
    set internalValue(value: CesAgentRemoteA2AAgent | undefined);
    private _a2AConfig;
    get a2AConfig(): CesAgentRemoteA2AAgentA2AConfigOutputReference;
    putA2AConfig(value: CesAgentRemoteA2AAgentA2AConfig): void;
    get a2AConfigInput(): CesAgentRemoteA2AAgentA2AConfig | undefined;
}
export interface CesAgentRemoteDialogflowAgent {
    /**
    * The
    * [Dialogflow](https://cloud.google.com/dialogflow/cx/docs/concept/console-conversational-agents
    * agent resource name.
    * Format: 'projects/{project}/locations/{location}/agents/{agent}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#agent CesAgent#agent}
    */
    readonly agent: string;
    /**
    * The environment ID of the Dialogflow agent be used for the agent
    * execution. If not specified, the draft environment will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#environment_id CesAgent#environment_id}
    */
    readonly environmentId?: string;
    /**
    * The flow ID of the flow in the Dialogflow agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#flow_id CesAgent#flow_id}
    */
    readonly flowId: string;
    /**
    * The mapping of the app variables names to the Dialogflow session
    * parameters names to be sent to the Dialogflow agent as input.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#input_variable_mapping CesAgent#input_variable_mapping}
    */
    readonly inputVariableMapping?: {
        [key: string]: string;
    };
    /**
    * The name of the variable that contains the language code to be used for
    * the Dialogflow session. If unspecified, the default language code of the
    * Dialogflow agent will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#language_code_variable CesAgent#language_code_variable}
    */
    readonly languageCodeVariable?: string;
    /**
    * The mapping of the Dialogflow session parameters names to the app
    * variables names to be sent back to the CES agent after the Dialogflow
    * agent execution ends.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#output_variable_mapping CesAgent#output_variable_mapping}
    */
    readonly outputVariableMapping?: {
        [key: string]: string;
    };
    /**
    * Indicates whether to respect the message-level interruption settings configured in the Dialogflow agent. * If false: all response messages from the Dialogflow agent follow the app-level barge-in settings. * If true: only response messages with ['allow_playback_interruption'](https://docs.cloud.google.com/dialogflow/cx/docs/reference/rpc/google.cloud.dialogflow.cx.v3#text) set to true will be interruptable, all other messages follow the app-level barge-in settings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#respect_response_interruption_settings CesAgent#respect_response_interruption_settings}
    */
    readonly respectResponseInterruptionSettings?: boolean | cdktn.IResolvable;
}
export declare function cesAgentRemoteDialogflowAgentToTerraform(struct?: CesAgentRemoteDialogflowAgentOutputReference | CesAgentRemoteDialogflowAgent): any;
export declare function cesAgentRemoteDialogflowAgentToHclTerraform(struct?: CesAgentRemoteDialogflowAgentOutputReference | CesAgentRemoteDialogflowAgent): any;
export declare class CesAgentRemoteDialogflowAgentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAgentRemoteDialogflowAgent | undefined;
    set internalValue(value: CesAgentRemoteDialogflowAgent | undefined);
    private _agent?;
    get agent(): string;
    set agent(value: string);
    get agentInput(): string | undefined;
    private _environmentId?;
    get environmentId(): string;
    set environmentId(value: string);
    resetEnvironmentId(): void;
    get environmentIdInput(): string | undefined;
    private _flowId?;
    get flowId(): string;
    set flowId(value: string);
    get flowIdInput(): string | undefined;
    private _inputVariableMapping?;
    get inputVariableMapping(): {
        [key: string]: string;
    };
    set inputVariableMapping(value: {
        [key: string]: string;
    });
    resetInputVariableMapping(): void;
    get inputVariableMappingInput(): {
        [key: string]: string;
    } | undefined;
    private _languageCodeVariable?;
    get languageCodeVariable(): string;
    set languageCodeVariable(value: string);
    resetLanguageCodeVariable(): void;
    get languageCodeVariableInput(): string | undefined;
    private _outputVariableMapping?;
    get outputVariableMapping(): {
        [key: string]: string;
    };
    set outputVariableMapping(value: {
        [key: string]: string;
    });
    resetOutputVariableMapping(): void;
    get outputVariableMappingInput(): {
        [key: string]: string;
    } | undefined;
    private _respectResponseInterruptionSettings?;
    get respectResponseInterruptionSettings(): boolean | cdktn.IResolvable;
    set respectResponseInterruptionSettings(value: boolean | cdktn.IResolvable);
    resetRespectResponseInterruptionSettings(): void;
    get respectResponseInterruptionSettingsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CesAgentTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#create CesAgent#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#delete CesAgent#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#update CesAgent#update}
    */
    readonly update?: string;
}
export declare function cesAgentTimeoutsToTerraform(struct?: CesAgentTimeouts | cdktn.IResolvable): any;
export declare function cesAgentTimeoutsToHclTerraform(struct?: CesAgentTimeouts | cdktn.IResolvable): any;
export declare class CesAgentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAgentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CesAgentTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface CesAgentToolsets {
    /**
    * The tools IDs to filter the toolset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#tool_ids CesAgent#tool_ids}
    */
    readonly toolIds?: string[];
    /**
    * The resource name of the toolset.
    * Format:
    * 'projects/{project}/locations/{location}/apps/{app}/toolsets/{toolset}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#toolset CesAgent#toolset}
    */
    readonly toolset: string;
}
export declare function cesAgentToolsetsToTerraform(struct?: CesAgentToolsets | cdktn.IResolvable): any;
export declare function cesAgentToolsetsToHclTerraform(struct?: CesAgentToolsets | cdktn.IResolvable): any;
export declare class CesAgentToolsetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesAgentToolsets | cdktn.IResolvable | undefined;
    set internalValue(value: CesAgentToolsets | cdktn.IResolvable | undefined);
    private _toolIds?;
    get toolIds(): string[];
    set toolIds(value: string[]);
    resetToolIds(): void;
    get toolIdsInput(): string[] | undefined;
    private _toolset?;
    get toolset(): string;
    set toolset(value: string);
    get toolsetInput(): string | undefined;
}
export declare class CesAgentToolsetsList extends cdktn.ComplexList {
    internalValue?: CesAgentToolsets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesAgentToolsetsOutputReference;
}
export interface CesAgentTransferRulesDeterministicTransferExpressionCondition {
    /**
    * The string representation of cloud.api.Expression condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#expression CesAgent#expression}
    */
    readonly expression: string;
}
export declare function cesAgentTransferRulesDeterministicTransferExpressionConditionToTerraform(struct?: CesAgentTransferRulesDeterministicTransferExpressionConditionOutputReference | CesAgentTransferRulesDeterministicTransferExpressionCondition): any;
export declare function cesAgentTransferRulesDeterministicTransferExpressionConditionToHclTerraform(struct?: CesAgentTransferRulesDeterministicTransferExpressionConditionOutputReference | CesAgentTransferRulesDeterministicTransferExpressionCondition): any;
export declare class CesAgentTransferRulesDeterministicTransferExpressionConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAgentTransferRulesDeterministicTransferExpressionCondition | undefined;
    set internalValue(value: CesAgentTransferRulesDeterministicTransferExpressionCondition | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
}
export interface CesAgentTransferRulesDeterministicTransferPythonCodeCondition {
    /**
    * The python code to execute. The function must be named
    * 'should_trigger_transfer_callback'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#python_code CesAgent#python_code}
    */
    readonly pythonCode: string;
}
export declare function cesAgentTransferRulesDeterministicTransferPythonCodeConditionToTerraform(struct?: CesAgentTransferRulesDeterministicTransferPythonCodeConditionOutputReference | CesAgentTransferRulesDeterministicTransferPythonCodeCondition): any;
export declare function cesAgentTransferRulesDeterministicTransferPythonCodeConditionToHclTerraform(struct?: CesAgentTransferRulesDeterministicTransferPythonCodeConditionOutputReference | CesAgentTransferRulesDeterministicTransferPythonCodeCondition): any;
export declare class CesAgentTransferRulesDeterministicTransferPythonCodeConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAgentTransferRulesDeterministicTransferPythonCodeCondition | undefined;
    set internalValue(value: CesAgentTransferRulesDeterministicTransferPythonCodeCondition | undefined);
    private _pythonCode?;
    get pythonCode(): string;
    set pythonCode(value: string);
    get pythonCodeInput(): string | undefined;
}
export interface CesAgentTransferRulesDeterministicTransfer {
    /**
    * expression_condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#expression_condition CesAgent#expression_condition}
    */
    readonly expressionCondition?: CesAgentTransferRulesDeterministicTransferExpressionCondition;
    /**
    * python_code_condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#python_code_condition CesAgent#python_code_condition}
    */
    readonly pythonCodeCondition?: CesAgentTransferRulesDeterministicTransferPythonCodeCondition;
}
export declare function cesAgentTransferRulesDeterministicTransferToTerraform(struct?: CesAgentTransferRulesDeterministicTransferOutputReference | CesAgentTransferRulesDeterministicTransfer): any;
export declare function cesAgentTransferRulesDeterministicTransferToHclTerraform(struct?: CesAgentTransferRulesDeterministicTransferOutputReference | CesAgentTransferRulesDeterministicTransfer): any;
export declare class CesAgentTransferRulesDeterministicTransferOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAgentTransferRulesDeterministicTransfer | undefined;
    set internalValue(value: CesAgentTransferRulesDeterministicTransfer | undefined);
    private _expressionCondition;
    get expressionCondition(): CesAgentTransferRulesDeterministicTransferExpressionConditionOutputReference;
    putExpressionCondition(value: CesAgentTransferRulesDeterministicTransferExpressionCondition): void;
    resetExpressionCondition(): void;
    get expressionConditionInput(): CesAgentTransferRulesDeterministicTransferExpressionCondition | undefined;
    private _pythonCodeCondition;
    get pythonCodeCondition(): CesAgentTransferRulesDeterministicTransferPythonCodeConditionOutputReference;
    putPythonCodeCondition(value: CesAgentTransferRulesDeterministicTransferPythonCodeCondition): void;
    resetPythonCodeCondition(): void;
    get pythonCodeConditionInput(): CesAgentTransferRulesDeterministicTransferPythonCodeCondition | undefined;
}
export interface CesAgentTransferRulesDisablePlannerTransferExpressionCondition {
    /**
    * The string representation of cloud.api.Expression condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#expression CesAgent#expression}
    */
    readonly expression: string;
}
export declare function cesAgentTransferRulesDisablePlannerTransferExpressionConditionToTerraform(struct?: CesAgentTransferRulesDisablePlannerTransferExpressionConditionOutputReference | CesAgentTransferRulesDisablePlannerTransferExpressionCondition): any;
export declare function cesAgentTransferRulesDisablePlannerTransferExpressionConditionToHclTerraform(struct?: CesAgentTransferRulesDisablePlannerTransferExpressionConditionOutputReference | CesAgentTransferRulesDisablePlannerTransferExpressionCondition): any;
export declare class CesAgentTransferRulesDisablePlannerTransferExpressionConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAgentTransferRulesDisablePlannerTransferExpressionCondition | undefined;
    set internalValue(value: CesAgentTransferRulesDisablePlannerTransferExpressionCondition | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
}
export interface CesAgentTransferRulesDisablePlannerTransfer {
    /**
    * expression_condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#expression_condition CesAgent#expression_condition}
    */
    readonly expressionCondition: CesAgentTransferRulesDisablePlannerTransferExpressionCondition;
}
export declare function cesAgentTransferRulesDisablePlannerTransferToTerraform(struct?: CesAgentTransferRulesDisablePlannerTransferOutputReference | CesAgentTransferRulesDisablePlannerTransfer): any;
export declare function cesAgentTransferRulesDisablePlannerTransferToHclTerraform(struct?: CesAgentTransferRulesDisablePlannerTransferOutputReference | CesAgentTransferRulesDisablePlannerTransfer): any;
export declare class CesAgentTransferRulesDisablePlannerTransferOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAgentTransferRulesDisablePlannerTransfer | undefined;
    set internalValue(value: CesAgentTransferRulesDisablePlannerTransfer | undefined);
    private _expressionCondition;
    get expressionCondition(): CesAgentTransferRulesDisablePlannerTransferExpressionConditionOutputReference;
    putExpressionCondition(value: CesAgentTransferRulesDisablePlannerTransferExpressionCondition): void;
    get expressionConditionInput(): CesAgentTransferRulesDisablePlannerTransferExpressionCondition | undefined;
}
export interface CesAgentTransferRules {
    /**
    * The resource name of the child agent the rule applies to.
    * Format: 'projects/{project}/locations/{location}/apps/{app}/agents/{agent}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#child_agent CesAgent#child_agent}
    */
    readonly childAgent: string;
    /**
    * The direction of the transfer. Possible values: ["PARENT_TO_CHILD", "CHILD_TO_PARENT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#direction CesAgent#direction}
    */
    readonly direction: string;
    /**
    * deterministic_transfer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#deterministic_transfer CesAgent#deterministic_transfer}
    */
    readonly deterministicTransfer?: CesAgentTransferRulesDeterministicTransfer;
    /**
    * disable_planner_transfer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#disable_planner_transfer CesAgent#disable_planner_transfer}
    */
    readonly disablePlannerTransfer?: CesAgentTransferRulesDisablePlannerTransfer;
}
export declare function cesAgentTransferRulesToTerraform(struct?: CesAgentTransferRules | cdktn.IResolvable): any;
export declare function cesAgentTransferRulesToHclTerraform(struct?: CesAgentTransferRules | cdktn.IResolvable): any;
export declare class CesAgentTransferRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesAgentTransferRules | cdktn.IResolvable | undefined;
    set internalValue(value: CesAgentTransferRules | cdktn.IResolvable | undefined);
    private _childAgent?;
    get childAgent(): string;
    set childAgent(value: string);
    get childAgentInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    get directionInput(): string | undefined;
    private _deterministicTransfer;
    get deterministicTransfer(): CesAgentTransferRulesDeterministicTransferOutputReference;
    putDeterministicTransfer(value: CesAgentTransferRulesDeterministicTransfer): void;
    resetDeterministicTransfer(): void;
    get deterministicTransferInput(): CesAgentTransferRulesDeterministicTransfer | undefined;
    private _disablePlannerTransfer;
    get disablePlannerTransfer(): CesAgentTransferRulesDisablePlannerTransferOutputReference;
    putDisablePlannerTransfer(value: CesAgentTransferRulesDisablePlannerTransfer): void;
    resetDisablePlannerTransfer(): void;
    get disablePlannerTransferInput(): CesAgentTransferRulesDisablePlannerTransfer | undefined;
}
export declare class CesAgentTransferRulesList extends cdktn.ComplexList {
    internalValue?: CesAgentTransferRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesAgentTransferRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent google_ces_agent}
*/
export declare class CesAgent extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_ces_agent";
    /**
    * Generates CDKTN code for importing a CesAgent resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CesAgent to import
    * @param importFromId The id of the existing CesAgent that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CesAgent to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_agent google_ces_agent} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CesAgentConfig
    */
    constructor(scope: Construct, id: string, config: CesAgentConfig);
    private _agentId?;
    get agentId(): string;
    set agentId(value: string);
    resetAgentId(): void;
    get agentIdInput(): string | undefined;
    private _app?;
    get app(): string;
    set app(value: string);
    get appInput(): string | undefined;
    private _childAgents?;
    get childAgents(): string[];
    set childAgents(value: string[]);
    resetChildAgents(): void;
    get childAgentsInput(): string[] | undefined;
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get etag(): string;
    get generatedSummary(): string;
    private _guardrails?;
    get guardrails(): string[];
    set guardrails(value: string[]);
    resetGuardrails(): void;
    get guardrailsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instruction?;
    get instruction(): string;
    set instruction(value: string);
    resetInstruction(): void;
    get instructionInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _tools?;
    get tools(): string[];
    set tools(value: string[]);
    resetTools(): void;
    get toolsInput(): string[] | undefined;
    get updateTime(): string;
    private _afterAgentCallbacks;
    get afterAgentCallbacks(): CesAgentAfterAgentCallbacksList;
    putAfterAgentCallbacks(value: CesAgentAfterAgentCallbacks[] | cdktn.IResolvable): void;
    resetAfterAgentCallbacks(): void;
    get afterAgentCallbacksInput(): cdktn.IResolvable | CesAgentAfterAgentCallbacks[] | undefined;
    private _afterModelCallbacks;
    get afterModelCallbacks(): CesAgentAfterModelCallbacksList;
    putAfterModelCallbacks(value: CesAgentAfterModelCallbacks[] | cdktn.IResolvable): void;
    resetAfterModelCallbacks(): void;
    get afterModelCallbacksInput(): cdktn.IResolvable | CesAgentAfterModelCallbacks[] | undefined;
    private _afterToolCallbacks;
    get afterToolCallbacks(): CesAgentAfterToolCallbacksList;
    putAfterToolCallbacks(value: CesAgentAfterToolCallbacks[] | cdktn.IResolvable): void;
    resetAfterToolCallbacks(): void;
    get afterToolCallbacksInput(): cdktn.IResolvable | CesAgentAfterToolCallbacks[] | undefined;
    private _beforeAgentCallbacks;
    get beforeAgentCallbacks(): CesAgentBeforeAgentCallbacksList;
    putBeforeAgentCallbacks(value: CesAgentBeforeAgentCallbacks[] | cdktn.IResolvable): void;
    resetBeforeAgentCallbacks(): void;
    get beforeAgentCallbacksInput(): cdktn.IResolvable | CesAgentBeforeAgentCallbacks[] | undefined;
    private _beforeModelCallbacks;
    get beforeModelCallbacks(): CesAgentBeforeModelCallbacksList;
    putBeforeModelCallbacks(value: CesAgentBeforeModelCallbacks[] | cdktn.IResolvable): void;
    resetBeforeModelCallbacks(): void;
    get beforeModelCallbacksInput(): cdktn.IResolvable | CesAgentBeforeModelCallbacks[] | undefined;
    private _beforeToolCallbacks;
    get beforeToolCallbacks(): CesAgentBeforeToolCallbacksList;
    putBeforeToolCallbacks(value: CesAgentBeforeToolCallbacks[] | cdktn.IResolvable): void;
    resetBeforeToolCallbacks(): void;
    get beforeToolCallbacksInput(): cdktn.IResolvable | CesAgentBeforeToolCallbacks[] | undefined;
    private _llmAgent;
    get llmAgent(): CesAgentLlmAgentOutputReference;
    putLlmAgent(value: CesAgentLlmAgent): void;
    resetLlmAgent(): void;
    get llmAgentInput(): CesAgentLlmAgent | undefined;
    private _modelSettings;
    get modelSettings(): CesAgentModelSettingsOutputReference;
    putModelSettings(value: CesAgentModelSettings): void;
    resetModelSettings(): void;
    get modelSettingsInput(): CesAgentModelSettings | undefined;
    private _remoteA2AAgent;
    get remoteA2AAgent(): CesAgentRemoteA2AAgentOutputReference;
    putRemoteA2AAgent(value: CesAgentRemoteA2AAgent): void;
    resetRemoteA2AAgent(): void;
    get remoteA2AAgentInput(): CesAgentRemoteA2AAgent | undefined;
    private _remoteDialogflowAgent;
    get remoteDialogflowAgent(): CesAgentRemoteDialogflowAgentOutputReference;
    putRemoteDialogflowAgent(value: CesAgentRemoteDialogflowAgent): void;
    resetRemoteDialogflowAgent(): void;
    get remoteDialogflowAgentInput(): CesAgentRemoteDialogflowAgent | undefined;
    private _timeouts;
    get timeouts(): CesAgentTimeoutsOutputReference;
    putTimeouts(value: CesAgentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CesAgentTimeouts | undefined;
    private _toolsets;
    get toolsets(): CesAgentToolsetsList;
    putToolsets(value: CesAgentToolsets[] | cdktn.IResolvable): void;
    resetToolsets(): void;
    get toolsetsInput(): cdktn.IResolvable | CesAgentToolsets[] | undefined;
    private _transferRules;
    get transferRules(): CesAgentTransferRulesList;
    putTransferRules(value: CesAgentTransferRules[] | cdktn.IResolvable): void;
    resetTransferRules(): void;
    get transferRulesInput(): cdktn.IResolvable | CesAgentTransferRules[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
