/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputePreviewFeatureConfig extends cdktn.TerraformMetaArguments {
    /**
    * The activation status of the preview feature. Possible values: ["ENABLED", "ACTIVATION_STATE_UNSPECIFIED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_preview_feature#activation_status ComputePreviewFeature#activation_status}
    */
    readonly activationStatus: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_preview_feature#id ComputePreviewFeature#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the preview feature.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_preview_feature#name ComputePreviewFeature#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_preview_feature#project ComputePreviewFeature#project}
    */
    readonly project?: string;
    /**
    * rollout_operation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_preview_feature#rollout_operation ComputePreviewFeature#rollout_operation}
    */
    readonly rolloutOperation?: ComputePreviewFeatureRolloutOperation;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_preview_feature#timeouts ComputePreviewFeature#timeouts}
    */
    readonly timeouts?: ComputePreviewFeatureTimeouts;
}
export interface ComputePreviewFeatureRolloutOperationRolloutInput {
    /**
    * Predefined rollout plans. Possible values: ["ROLLOUT_PLAN_FAST_ROLLOUT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_preview_feature#predefined_rollout_plan ComputePreviewFeature#predefined_rollout_plan}
    */
    readonly predefinedRolloutPlan: string;
}
export declare function computePreviewFeatureRolloutOperationRolloutInputToTerraform(struct?: ComputePreviewFeatureRolloutOperationRolloutInputOutputReference | ComputePreviewFeatureRolloutOperationRolloutInput): any;
export declare function computePreviewFeatureRolloutOperationRolloutInputToHclTerraform(struct?: ComputePreviewFeatureRolloutOperationRolloutInputOutputReference | ComputePreviewFeatureRolloutOperationRolloutInput): any;
export declare class ComputePreviewFeatureRolloutOperationRolloutInputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputePreviewFeatureRolloutOperationRolloutInput | undefined;
    set internalValue(value: ComputePreviewFeatureRolloutOperationRolloutInput | undefined);
    private _predefinedRolloutPlan?;
    get predefinedRolloutPlan(): string;
    set predefinedRolloutPlan(value: string);
    get predefinedRolloutPlanInput(): string | undefined;
}
export interface ComputePreviewFeatureRolloutOperation {
    /**
    * rollout_input block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_preview_feature#rollout_input ComputePreviewFeature#rollout_input}
    */
    readonly rolloutInput?: ComputePreviewFeatureRolloutOperationRolloutInput;
}
export declare function computePreviewFeatureRolloutOperationToTerraform(struct?: ComputePreviewFeatureRolloutOperationOutputReference | ComputePreviewFeatureRolloutOperation): any;
export declare function computePreviewFeatureRolloutOperationToHclTerraform(struct?: ComputePreviewFeatureRolloutOperationOutputReference | ComputePreviewFeatureRolloutOperation): any;
export declare class ComputePreviewFeatureRolloutOperationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputePreviewFeatureRolloutOperation | undefined;
    set internalValue(value: ComputePreviewFeatureRolloutOperation | undefined);
    private _rolloutInput;
    get rolloutInput(): ComputePreviewFeatureRolloutOperationRolloutInputOutputReference;
    putRolloutInput(value: ComputePreviewFeatureRolloutOperationRolloutInput): void;
    resetRolloutInput(): void;
    get rolloutInputInput(): ComputePreviewFeatureRolloutOperationRolloutInput | undefined;
}
export interface ComputePreviewFeatureTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_preview_feature#create ComputePreviewFeature#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_preview_feature#delete ComputePreviewFeature#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_preview_feature#update ComputePreviewFeature#update}
    */
    readonly update?: string;
}
export declare function computePreviewFeatureTimeoutsToTerraform(struct?: ComputePreviewFeatureTimeouts | cdktn.IResolvable): any;
export declare function computePreviewFeatureTimeoutsToHclTerraform(struct?: ComputePreviewFeatureTimeouts | cdktn.IResolvable): any;
export declare class ComputePreviewFeatureTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputePreviewFeatureTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputePreviewFeatureTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_preview_feature google_compute_preview_feature}
*/
export declare class ComputePreviewFeature extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_preview_feature";
    /**
    * Generates CDKTN code for importing a ComputePreviewFeature resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputePreviewFeature to import
    * @param importFromId The id of the existing ComputePreviewFeature that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_preview_feature#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputePreviewFeature to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_preview_feature google_compute_preview_feature} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputePreviewFeatureConfig
    */
    constructor(scope: Construct, id: string, config: ComputePreviewFeatureConfig);
    private _activationStatus?;
    get activationStatus(): string;
    set activationStatus(value: string);
    get activationStatusInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _rolloutOperation;
    get rolloutOperation(): ComputePreviewFeatureRolloutOperationOutputReference;
    putRolloutOperation(value: ComputePreviewFeatureRolloutOperation): void;
    resetRolloutOperation(): void;
    get rolloutOperationInput(): ComputePreviewFeatureRolloutOperation | undefined;
    private _timeouts;
    get timeouts(): ComputePreviewFeatureTimeoutsOutputReference;
    putTimeouts(value: ComputePreviewFeatureTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputePreviewFeatureTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
