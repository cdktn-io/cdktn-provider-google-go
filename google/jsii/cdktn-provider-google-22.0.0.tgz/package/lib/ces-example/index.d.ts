/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CesExampleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Resource ID segment making up resource 'name', defining the app the example belongs to. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#app CesExample#app}
    */
    readonly app: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#deletion_policy CesExample#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Human-readable description of the example.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#description CesExample#description}
    */
    readonly description?: string;
    /**
    * Display name of the example.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#display_name CesExample#display_name}
    */
    readonly displayName: string;
    /**
    * The agent that initially handles the conversation. If not specified, the
    * example represents a conversation that is handled by the root agent.
    * Format: 'projects/{project}/locations/{location}/apps/{app}/agents/{agent}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#entry_agent CesExample#entry_agent}
    */
    readonly entryAgent?: string;
    /**
    * The ID to use for the example, which will become the final component of
    * the example's resource name. In Terraform, this field is required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#example_id CesExample#example_id}
    */
    readonly exampleId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#id CesExample#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name', defining what region the parent app is in. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#location CesExample#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#project CesExample#project}
    */
    readonly project?: string;
    /**
    * messages block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#messages CesExample#messages}
    */
    readonly messages?: CesExampleMessages[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#timeouts CesExample#timeouts}
    */
    readonly timeouts?: CesExampleTimeouts;
}
export interface CesExampleMessagesChunksAgentTransfer {
    /**
    * The agent to which the conversation is being transferred. The agent will
    * handle the conversation from this point forward.
    * Format: 'projects/{project}/locations/{location}/apps/{app}/agents/{agent}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#target_agent CesExample#target_agent}
    */
    readonly targetAgent: string;
}
export declare function cesExampleMessagesChunksAgentTransferToTerraform(struct?: CesExampleMessagesChunksAgentTransferOutputReference | CesExampleMessagesChunksAgentTransfer): any;
export declare function cesExampleMessagesChunksAgentTransferToHclTerraform(struct?: CesExampleMessagesChunksAgentTransferOutputReference | CesExampleMessagesChunksAgentTransfer): any;
export declare class CesExampleMessagesChunksAgentTransferOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesExampleMessagesChunksAgentTransfer | undefined;
    set internalValue(value: CesExampleMessagesChunksAgentTransfer | undefined);
    get displayName(): string;
    private _targetAgent?;
    get targetAgent(): string;
    set targetAgent(value: string);
    get targetAgentInput(): string | undefined;
}
export interface CesExampleMessagesChunksBlob {
    /**
    * Raw bytes of the blob.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#data CesExample#data}
    */
    readonly data: string;
    /**
    * The IANA standard MIME type of the source data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#mime_type CesExample#mime_type}
    */
    readonly mimeType: string;
}
export declare function cesExampleMessagesChunksBlobToTerraform(struct?: CesExampleMessagesChunksBlobOutputReference | CesExampleMessagesChunksBlob): any;
export declare function cesExampleMessagesChunksBlobToHclTerraform(struct?: CesExampleMessagesChunksBlobOutputReference | CesExampleMessagesChunksBlob): any;
export declare class CesExampleMessagesChunksBlobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesExampleMessagesChunksBlob | undefined;
    set internalValue(value: CesExampleMessagesChunksBlob | undefined);
    private _data?;
    get data(): string;
    set data(value: string);
    get dataInput(): string | undefined;
    private _mimeType?;
    get mimeType(): string;
    set mimeType(value: string);
    get mimeTypeInput(): string | undefined;
}
export interface CesExampleMessagesChunksImage {
    /**
    * The alternative text for the image.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#alt_text CesExample#alt_text}
    */
    readonly altText?: string;
    /**
    * Raw bytes of the image.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#data CesExample#data}
    */
    readonly data: string;
    /**
    * The IANA standard MIME type of the source data.
    * Supported image types includes:
    * * image/png
    * * image/jpeg
    * * image/webp
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#mime_type CesExample#mime_type}
    */
    readonly mimeType: string;
}
export declare function cesExampleMessagesChunksImageToTerraform(struct?: CesExampleMessagesChunksImageOutputReference | CesExampleMessagesChunksImage): any;
export declare function cesExampleMessagesChunksImageToHclTerraform(struct?: CesExampleMessagesChunksImageOutputReference | CesExampleMessagesChunksImage): any;
export declare class CesExampleMessagesChunksImageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesExampleMessagesChunksImage | undefined;
    set internalValue(value: CesExampleMessagesChunksImage | undefined);
    private _altText?;
    get altText(): string;
    set altText(value: string);
    resetAltText(): void;
    get altTextInput(): string | undefined;
    private _data?;
    get data(): string;
    set data(value: string);
    get dataInput(): string | undefined;
    private _mimeType?;
    get mimeType(): string;
    set mimeType(value: string);
    get mimeTypeInput(): string | undefined;
}
export interface CesExampleMessagesChunksToolCallToolsetTool {
    /**
    * The tool ID to filter the tools to retrieve the schema for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#tool_id CesExample#tool_id}
    */
    readonly toolId?: string;
    /**
    * The resource name of the Toolset from which this tool is derived.
    * Format:
    * 'projects/{project}/locations/{location}/apps/{app}/toolsets/{toolset}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#toolset CesExample#toolset}
    */
    readonly toolset: string;
}
export declare function cesExampleMessagesChunksToolCallToolsetToolToTerraform(struct?: CesExampleMessagesChunksToolCallToolsetToolOutputReference | CesExampleMessagesChunksToolCallToolsetTool): any;
export declare function cesExampleMessagesChunksToolCallToolsetToolToHclTerraform(struct?: CesExampleMessagesChunksToolCallToolsetToolOutputReference | CesExampleMessagesChunksToolCallToolsetTool): any;
export declare class CesExampleMessagesChunksToolCallToolsetToolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesExampleMessagesChunksToolCallToolsetTool | undefined;
    set internalValue(value: CesExampleMessagesChunksToolCallToolsetTool | undefined);
    private _toolId?;
    get toolId(): string;
    set toolId(value: string);
    resetToolId(): void;
    get toolIdInput(): string | undefined;
    private _toolset?;
    get toolset(): string;
    set toolset(value: string);
    get toolsetInput(): string | undefined;
}
export interface CesExampleMessagesChunksToolCall {
    /**
    * The input parameters and values for the tool in JSON object format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#args CesExample#args}
    */
    readonly args?: string;
    /**
    * The unique identifier of the tool call. If populated, the client should
    * return the execution result with the matching ID in
    * ToolResponse.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#id CesExample#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the tool to execute.
    * Format: 'projects/{project}/locations/{location}/apps/{app}/tools/{tool}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#tool CesExample#tool}
    */
    readonly tool?: string;
    /**
    * toolset_tool block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#toolset_tool CesExample#toolset_tool}
    */
    readonly toolsetTool?: CesExampleMessagesChunksToolCallToolsetTool;
}
export declare function cesExampleMessagesChunksToolCallToTerraform(struct?: CesExampleMessagesChunksToolCallOutputReference | CesExampleMessagesChunksToolCall): any;
export declare function cesExampleMessagesChunksToolCallToHclTerraform(struct?: CesExampleMessagesChunksToolCallOutputReference | CesExampleMessagesChunksToolCall): any;
export declare class CesExampleMessagesChunksToolCallOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesExampleMessagesChunksToolCall | undefined;
    set internalValue(value: CesExampleMessagesChunksToolCall | undefined);
    private _args?;
    get args(): string;
    set args(value: string);
    resetArgs(): void;
    get argsInput(): string | undefined;
    get displayName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _tool?;
    get tool(): string;
    set tool(value: string);
    resetTool(): void;
    get toolInput(): string | undefined;
    private _toolsetTool;
    get toolsetTool(): CesExampleMessagesChunksToolCallToolsetToolOutputReference;
    putToolsetTool(value: CesExampleMessagesChunksToolCallToolsetTool): void;
    resetToolsetTool(): void;
    get toolsetToolInput(): CesExampleMessagesChunksToolCallToolsetTool | undefined;
}
export interface CesExampleMessagesChunksToolResponseToolsetTool {
    /**
    * The tool ID to filter the tools to retrieve the schema for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#tool_id CesExample#tool_id}
    */
    readonly toolId?: string;
    /**
    * The resource name of the Toolset from which this tool is derived.
    * Format:
    * 'projects/{project}/locations/{location}/apps/{app}/toolsets/{toolset}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#toolset CesExample#toolset}
    */
    readonly toolset: string;
}
export declare function cesExampleMessagesChunksToolResponseToolsetToolToTerraform(struct?: CesExampleMessagesChunksToolResponseToolsetToolOutputReference | CesExampleMessagesChunksToolResponseToolsetTool): any;
export declare function cesExampleMessagesChunksToolResponseToolsetToolToHclTerraform(struct?: CesExampleMessagesChunksToolResponseToolsetToolOutputReference | CesExampleMessagesChunksToolResponseToolsetTool): any;
export declare class CesExampleMessagesChunksToolResponseToolsetToolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesExampleMessagesChunksToolResponseToolsetTool | undefined;
    set internalValue(value: CesExampleMessagesChunksToolResponseToolsetTool | undefined);
    private _toolId?;
    get toolId(): string;
    set toolId(value: string);
    resetToolId(): void;
    get toolIdInput(): string | undefined;
    private _toolset?;
    get toolset(): string;
    set toolset(value: string);
    get toolsetInput(): string | undefined;
}
export interface CesExampleMessagesChunksToolResponse {
    /**
    * The matching ID of the tool call the response is for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#id CesExample#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The tool execution result in JSON object format.
    * Use "output" key to specify tool response and "error" key to specify
    * error details (if any). If "output" and "error" keys are not specified,
    * then whole "response" is treated as tool execution result.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#response CesExample#response}
    */
    readonly response: string;
    /**
    * The name of the tool to execute.
    * Format: 'projects/{project}/locations/{location}/apps/{app}/tools/{tool}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#tool CesExample#tool}
    */
    readonly tool?: string;
    /**
    * toolset_tool block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#toolset_tool CesExample#toolset_tool}
    */
    readonly toolsetTool?: CesExampleMessagesChunksToolResponseToolsetTool;
}
export declare function cesExampleMessagesChunksToolResponseToTerraform(struct?: CesExampleMessagesChunksToolResponseOutputReference | CesExampleMessagesChunksToolResponse): any;
export declare function cesExampleMessagesChunksToolResponseToHclTerraform(struct?: CesExampleMessagesChunksToolResponseOutputReference | CesExampleMessagesChunksToolResponse): any;
export declare class CesExampleMessagesChunksToolResponseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesExampleMessagesChunksToolResponse | undefined;
    set internalValue(value: CesExampleMessagesChunksToolResponse | undefined);
    get displayName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _response?;
    get response(): string;
    set response(value: string);
    get responseInput(): string | undefined;
    private _tool?;
    get tool(): string;
    set tool(value: string);
    resetTool(): void;
    get toolInput(): string | undefined;
    private _toolsetTool;
    get toolsetTool(): CesExampleMessagesChunksToolResponseToolsetToolOutputReference;
    putToolsetTool(value: CesExampleMessagesChunksToolResponseToolsetTool): void;
    resetToolsetTool(): void;
    get toolsetToolInput(): CesExampleMessagesChunksToolResponseToolsetTool | undefined;
}
export interface CesExampleMessagesChunks {
    /**
    * Text data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#text CesExample#text}
    */
    readonly text?: string;
    /**
    * A struct represents variables that were updated in the conversation,
    * keyed by variable names.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#updated_variables CesExample#updated_variables}
    */
    readonly updatedVariables?: string;
    /**
    * agent_transfer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#agent_transfer CesExample#agent_transfer}
    */
    readonly agentTransfer?: CesExampleMessagesChunksAgentTransfer;
    /**
    * blob block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#blob CesExample#blob}
    */
    readonly blob?: CesExampleMessagesChunksBlob;
    /**
    * image block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#image CesExample#image}
    */
    readonly image?: CesExampleMessagesChunksImage;
    /**
    * tool_call block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#tool_call CesExample#tool_call}
    */
    readonly toolCall?: CesExampleMessagesChunksToolCall;
    /**
    * tool_response block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#tool_response CesExample#tool_response}
    */
    readonly toolResponse?: CesExampleMessagesChunksToolResponse;
}
export declare function cesExampleMessagesChunksToTerraform(struct?: CesExampleMessagesChunks | cdktn.IResolvable): any;
export declare function cesExampleMessagesChunksToHclTerraform(struct?: CesExampleMessagesChunks | cdktn.IResolvable): any;
export declare class CesExampleMessagesChunksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesExampleMessagesChunks | cdktn.IResolvable | undefined;
    set internalValue(value: CesExampleMessagesChunks | cdktn.IResolvable | undefined);
    private _text?;
    get text(): string;
    set text(value: string);
    resetText(): void;
    get textInput(): string | undefined;
    private _updatedVariables?;
    get updatedVariables(): string;
    set updatedVariables(value: string);
    resetUpdatedVariables(): void;
    get updatedVariablesInput(): string | undefined;
    private _agentTransfer;
    get agentTransfer(): CesExampleMessagesChunksAgentTransferOutputReference;
    putAgentTransfer(value: CesExampleMessagesChunksAgentTransfer): void;
    resetAgentTransfer(): void;
    get agentTransferInput(): CesExampleMessagesChunksAgentTransfer | undefined;
    private _blob;
    get blob(): CesExampleMessagesChunksBlobOutputReference;
    putBlob(value: CesExampleMessagesChunksBlob): void;
    resetBlob(): void;
    get blobInput(): CesExampleMessagesChunksBlob | undefined;
    private _image;
    get image(): CesExampleMessagesChunksImageOutputReference;
    putImage(value: CesExampleMessagesChunksImage): void;
    resetImage(): void;
    get imageInput(): CesExampleMessagesChunksImage | undefined;
    private _toolCall;
    get toolCall(): CesExampleMessagesChunksToolCallOutputReference;
    putToolCall(value: CesExampleMessagesChunksToolCall): void;
    resetToolCall(): void;
    get toolCallInput(): CesExampleMessagesChunksToolCall | undefined;
    private _toolResponse;
    get toolResponse(): CesExampleMessagesChunksToolResponseOutputReference;
    putToolResponse(value: CesExampleMessagesChunksToolResponse): void;
    resetToolResponse(): void;
    get toolResponseInput(): CesExampleMessagesChunksToolResponse | undefined;
}
export declare class CesExampleMessagesChunksList extends cdktn.ComplexList {
    internalValue?: CesExampleMessagesChunks[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesExampleMessagesChunksOutputReference;
}
export interface CesExampleMessages {
    /**
    * The role within the conversation, e.g., user, agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#role CesExample#role}
    */
    readonly role?: string;
    /**
    * chunks block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#chunks CesExample#chunks}
    */
    readonly chunks?: CesExampleMessagesChunks[] | cdktn.IResolvable;
}
export declare function cesExampleMessagesToTerraform(struct?: CesExampleMessages | cdktn.IResolvable): any;
export declare function cesExampleMessagesToHclTerraform(struct?: CesExampleMessages | cdktn.IResolvable): any;
export declare class CesExampleMessagesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesExampleMessages | cdktn.IResolvable | undefined;
    set internalValue(value: CesExampleMessages | cdktn.IResolvable | undefined);
    private _role?;
    get role(): string;
    set role(value: string);
    resetRole(): void;
    get roleInput(): string | undefined;
    private _chunks;
    get chunks(): CesExampleMessagesChunksList;
    putChunks(value: CesExampleMessagesChunks[] | cdktn.IResolvable): void;
    resetChunks(): void;
    get chunksInput(): cdktn.IResolvable | CesExampleMessagesChunks[] | undefined;
}
export declare class CesExampleMessagesList extends cdktn.ComplexList {
    internalValue?: CesExampleMessages[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesExampleMessagesOutputReference;
}
export interface CesExampleTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#create CesExample#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#delete CesExample#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#update CesExample#update}
    */
    readonly update?: string;
}
export declare function cesExampleTimeoutsToTerraform(struct?: CesExampleTimeouts | cdktn.IResolvable): any;
export declare function cesExampleTimeoutsToHclTerraform(struct?: CesExampleTimeouts | cdktn.IResolvable): any;
export declare class CesExampleTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesExampleTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CesExampleTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example google_ces_example}
*/
export declare class CesExample extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_ces_example";
    /**
    * Generates CDKTN code for importing a CesExample resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CesExample to import
    * @param importFromId The id of the existing CesExample that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CesExample to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/ces_example google_ces_example} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CesExampleConfig
    */
    constructor(scope: Construct, id: string, config: CesExampleConfig);
    private _app?;
    get app(): string;
    set app(value: string);
    get appInput(): string | undefined;
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _entryAgent?;
    get entryAgent(): string;
    set entryAgent(value: string);
    resetEntryAgent(): void;
    get entryAgentInput(): string | undefined;
    get etag(): string;
    private _exampleId?;
    get exampleId(): string;
    set exampleId(value: string);
    get exampleIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get invalid(): cdktn.IResolvable;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get updateTime(): string;
    private _messages;
    get messages(): CesExampleMessagesList;
    putMessages(value: CesExampleMessages[] | cdktn.IResolvable): void;
    resetMessages(): void;
    get messagesInput(): cdktn.IResolvable | CesExampleMessages[] | undefined;
    private _timeouts;
    get timeouts(): CesExampleTimeoutsOutputReference;
    putTimeouts(value: CesExampleTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CesExampleTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
