/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BackupDrManagementServerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_management_server#deletion_policy BackupDrManagementServer#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_management_server#id BackupDrManagementServer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location for the management server (management console)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_management_server#location BackupDrManagementServer#location}
    */
    readonly location: string;
    /**
    * The name of management server (management console)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_management_server#name BackupDrManagementServer#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_management_server#project BackupDrManagementServer#project}
    */
    readonly project?: string;
    /**
    * The type of management server (management console). Default value: "BACKUP_RESTORE" Possible values: ["BACKUP_RESTORE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_management_server#type BackupDrManagementServer#type}
    */
    readonly type?: string;
    /**
    * networks block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_management_server#networks BackupDrManagementServer#networks}
    */
    readonly networks?: BackupDrManagementServerNetworks[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_management_server#timeouts BackupDrManagementServer#timeouts}
    */
    readonly timeouts?: BackupDrManagementServerTimeouts;
}
export interface BackupDrManagementServerManagementUri {
}
export declare function backupDrManagementServerManagementUriToTerraform(struct?: BackupDrManagementServerManagementUri): any;
export declare function backupDrManagementServerManagementUriToHclTerraform(struct?: BackupDrManagementServerManagementUri): any;
export declare class BackupDrManagementServerManagementUriOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupDrManagementServerManagementUri | undefined;
    set internalValue(value: BackupDrManagementServerManagementUri | undefined);
    get api(): string;
    get webUi(): string;
}
export declare class BackupDrManagementServerManagementUriList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupDrManagementServerManagementUriOutputReference;
}
export interface BackupDrManagementServerNetworks {
    /**
    * Network with format 'projects/{{project_id}}/global/networks/{{network_id}}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_management_server#network BackupDrManagementServer#network}
    */
    readonly network: string;
    /**
    * Type of Network peeringMode Default value: "PRIVATE_SERVICE_ACCESS" Possible values: ["PRIVATE_SERVICE_ACCESS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_management_server#peering_mode BackupDrManagementServer#peering_mode}
    */
    readonly peeringMode?: string;
}
export declare function backupDrManagementServerNetworksToTerraform(struct?: BackupDrManagementServerNetworks | cdktn.IResolvable): any;
export declare function backupDrManagementServerNetworksToHclTerraform(struct?: BackupDrManagementServerNetworks | cdktn.IResolvable): any;
export declare class BackupDrManagementServerNetworksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupDrManagementServerNetworks | cdktn.IResolvable | undefined;
    set internalValue(value: BackupDrManagementServerNetworks | cdktn.IResolvable | undefined);
    private _network?;
    get network(): string;
    set network(value: string);
    get networkInput(): string | undefined;
    private _peeringMode?;
    get peeringMode(): string;
    set peeringMode(value: string);
    resetPeeringMode(): void;
    get peeringModeInput(): string | undefined;
}
export declare class BackupDrManagementServerNetworksList extends cdktn.ComplexList {
    internalValue?: BackupDrManagementServerNetworks[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupDrManagementServerNetworksOutputReference;
}
export interface BackupDrManagementServerTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_management_server#create BackupDrManagementServer#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_management_server#delete BackupDrManagementServer#delete}
    */
    readonly delete?: string;
}
export declare function backupDrManagementServerTimeoutsToTerraform(struct?: BackupDrManagementServerTimeouts | cdktn.IResolvable): any;
export declare function backupDrManagementServerTimeoutsToHclTerraform(struct?: BackupDrManagementServerTimeouts | cdktn.IResolvable): any;
export declare class BackupDrManagementServerTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrManagementServerTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BackupDrManagementServerTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_management_server google_backup_dr_management_server}
*/
export declare class BackupDrManagementServer extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_backup_dr_management_server";
    /**
    * Generates CDKTN code for importing a BackupDrManagementServer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BackupDrManagementServer to import
    * @param importFromId The id of the existing BackupDrManagementServer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_management_server#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BackupDrManagementServer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_management_server google_backup_dr_management_server} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BackupDrManagementServerConfig
    */
    constructor(scope: Construct, id: string, config: BackupDrManagementServerConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _managementUri;
    get managementUri(): BackupDrManagementServerManagementUriList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get oauth2ClientId(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _networks;
    get networks(): BackupDrManagementServerNetworksList;
    putNetworks(value: BackupDrManagementServerNetworks[] | cdktn.IResolvable): void;
    resetNetworks(): void;
    get networksInput(): cdktn.IResolvable | BackupDrManagementServerNetworks[] | undefined;
    private _timeouts;
    get timeouts(): BackupDrManagementServerTimeoutsOutputReference;
    putTimeouts(value: BackupDrManagementServerTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BackupDrManagementServerTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
