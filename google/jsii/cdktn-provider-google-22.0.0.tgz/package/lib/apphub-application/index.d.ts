/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApphubApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Required. The Application identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#application_id ApphubApplication#application_id}
    */
    readonly applicationId: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#deletion_policy ApphubApplication#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Optional. User-defined description of an Application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#description ApphubApplication#description}
    */
    readonly description?: string;
    /**
    * Optional. User-defined name for the Application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#display_name ApphubApplication#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#id ApphubApplication#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Part of 'parent'. See documentation of 'projectsId'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#location ApphubApplication#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#project ApphubApplication#project}
    */
    readonly project?: string;
    /**
    * attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#attributes ApphubApplication#attributes}
    */
    readonly attributes?: ApphubApplicationAttributes;
    /**
    * scope block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#scope ApphubApplication#scope}
    */
    readonly scope: ApphubApplicationScope;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#timeouts ApphubApplication#timeouts}
    */
    readonly timeouts?: ApphubApplicationTimeouts;
}
export interface ApphubApplicationAttributesBusinessOwners {
    /**
    * Optional. Contact's name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#display_name ApphubApplication#display_name}
    */
    readonly displayName?: string;
    /**
    * Required. Email address of the contacts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#email ApphubApplication#email}
    */
    readonly email: string;
}
export declare function apphubApplicationAttributesBusinessOwnersToTerraform(struct?: ApphubApplicationAttributesBusinessOwners | cdktn.IResolvable): any;
export declare function apphubApplicationAttributesBusinessOwnersToHclTerraform(struct?: ApphubApplicationAttributesBusinessOwners | cdktn.IResolvable): any;
export declare class ApphubApplicationAttributesBusinessOwnersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApphubApplicationAttributesBusinessOwners | cdktn.IResolvable | undefined;
    set internalValue(value: ApphubApplicationAttributesBusinessOwners | cdktn.IResolvable | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    get emailInput(): string | undefined;
}
export declare class ApphubApplicationAttributesBusinessOwnersList extends cdktn.ComplexList {
    internalValue?: ApphubApplicationAttributesBusinessOwners[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApphubApplicationAttributesBusinessOwnersOutputReference;
}
export interface ApphubApplicationAttributesCriticality {
    /**
    * Criticality type. Possible values: ["MISSION_CRITICAL", "HIGH", "MEDIUM", "LOW"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#type ApphubApplication#type}
    */
    readonly type: string;
}
export declare function apphubApplicationAttributesCriticalityToTerraform(struct?: ApphubApplicationAttributesCriticalityOutputReference | ApphubApplicationAttributesCriticality): any;
export declare function apphubApplicationAttributesCriticalityToHclTerraform(struct?: ApphubApplicationAttributesCriticalityOutputReference | ApphubApplicationAttributesCriticality): any;
export declare class ApphubApplicationAttributesCriticalityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApphubApplicationAttributesCriticality | undefined;
    set internalValue(value: ApphubApplicationAttributesCriticality | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface ApphubApplicationAttributesDeveloperOwners {
    /**
    * Optional. Contact's name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#display_name ApphubApplication#display_name}
    */
    readonly displayName?: string;
    /**
    * Required. Email address of the contacts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#email ApphubApplication#email}
    */
    readonly email: string;
}
export declare function apphubApplicationAttributesDeveloperOwnersToTerraform(struct?: ApphubApplicationAttributesDeveloperOwners | cdktn.IResolvable): any;
export declare function apphubApplicationAttributesDeveloperOwnersToHclTerraform(struct?: ApphubApplicationAttributesDeveloperOwners | cdktn.IResolvable): any;
export declare class ApphubApplicationAttributesDeveloperOwnersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApphubApplicationAttributesDeveloperOwners | cdktn.IResolvable | undefined;
    set internalValue(value: ApphubApplicationAttributesDeveloperOwners | cdktn.IResolvable | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    get emailInput(): string | undefined;
}
export declare class ApphubApplicationAttributesDeveloperOwnersList extends cdktn.ComplexList {
    internalValue?: ApphubApplicationAttributesDeveloperOwners[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApphubApplicationAttributesDeveloperOwnersOutputReference;
}
export interface ApphubApplicationAttributesEnvironment {
    /**
    * Environment type. Possible values: ["PRODUCTION", "STAGING", "TEST", "DEVELOPMENT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#type ApphubApplication#type}
    */
    readonly type: string;
}
export declare function apphubApplicationAttributesEnvironmentToTerraform(struct?: ApphubApplicationAttributesEnvironmentOutputReference | ApphubApplicationAttributesEnvironment): any;
export declare function apphubApplicationAttributesEnvironmentToHclTerraform(struct?: ApphubApplicationAttributesEnvironmentOutputReference | ApphubApplicationAttributesEnvironment): any;
export declare class ApphubApplicationAttributesEnvironmentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApphubApplicationAttributesEnvironment | undefined;
    set internalValue(value: ApphubApplicationAttributesEnvironment | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface ApphubApplicationAttributesOperatorOwners {
    /**
    * Optional. Contact's name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#display_name ApphubApplication#display_name}
    */
    readonly displayName?: string;
    /**
    * Required. Email address of the contacts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#email ApphubApplication#email}
    */
    readonly email: string;
}
export declare function apphubApplicationAttributesOperatorOwnersToTerraform(struct?: ApphubApplicationAttributesOperatorOwners | cdktn.IResolvable): any;
export declare function apphubApplicationAttributesOperatorOwnersToHclTerraform(struct?: ApphubApplicationAttributesOperatorOwners | cdktn.IResolvable): any;
export declare class ApphubApplicationAttributesOperatorOwnersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApphubApplicationAttributesOperatorOwners | cdktn.IResolvable | undefined;
    set internalValue(value: ApphubApplicationAttributesOperatorOwners | cdktn.IResolvable | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    get emailInput(): string | undefined;
}
export declare class ApphubApplicationAttributesOperatorOwnersList extends cdktn.ComplexList {
    internalValue?: ApphubApplicationAttributesOperatorOwners[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApphubApplicationAttributesOperatorOwnersOutputReference;
}
export interface ApphubApplicationAttributes {
    /**
    * business_owners block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#business_owners ApphubApplication#business_owners}
    */
    readonly businessOwners?: ApphubApplicationAttributesBusinessOwners[] | cdktn.IResolvable;
    /**
    * criticality block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#criticality ApphubApplication#criticality}
    */
    readonly criticality?: ApphubApplicationAttributesCriticality;
    /**
    * developer_owners block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#developer_owners ApphubApplication#developer_owners}
    */
    readonly developerOwners?: ApphubApplicationAttributesDeveloperOwners[] | cdktn.IResolvable;
    /**
    * environment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#environment ApphubApplication#environment}
    */
    readonly environment?: ApphubApplicationAttributesEnvironment;
    /**
    * operator_owners block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#operator_owners ApphubApplication#operator_owners}
    */
    readonly operatorOwners?: ApphubApplicationAttributesOperatorOwners[] | cdktn.IResolvable;
}
export declare function apphubApplicationAttributesToTerraform(struct?: ApphubApplicationAttributesOutputReference | ApphubApplicationAttributes): any;
export declare function apphubApplicationAttributesToHclTerraform(struct?: ApphubApplicationAttributesOutputReference | ApphubApplicationAttributes): any;
export declare class ApphubApplicationAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApphubApplicationAttributes | undefined;
    set internalValue(value: ApphubApplicationAttributes | undefined);
    private _businessOwners;
    get businessOwners(): ApphubApplicationAttributesBusinessOwnersList;
    putBusinessOwners(value: ApphubApplicationAttributesBusinessOwners[] | cdktn.IResolvable): void;
    resetBusinessOwners(): void;
    get businessOwnersInput(): cdktn.IResolvable | ApphubApplicationAttributesBusinessOwners[] | undefined;
    private _criticality;
    get criticality(): ApphubApplicationAttributesCriticalityOutputReference;
    putCriticality(value: ApphubApplicationAttributesCriticality): void;
    resetCriticality(): void;
    get criticalityInput(): ApphubApplicationAttributesCriticality | undefined;
    private _developerOwners;
    get developerOwners(): ApphubApplicationAttributesDeveloperOwnersList;
    putDeveloperOwners(value: ApphubApplicationAttributesDeveloperOwners[] | cdktn.IResolvable): void;
    resetDeveloperOwners(): void;
    get developerOwnersInput(): cdktn.IResolvable | ApphubApplicationAttributesDeveloperOwners[] | undefined;
    private _environment;
    get environment(): ApphubApplicationAttributesEnvironmentOutputReference;
    putEnvironment(value: ApphubApplicationAttributesEnvironment): void;
    resetEnvironment(): void;
    get environmentInput(): ApphubApplicationAttributesEnvironment | undefined;
    private _operatorOwners;
    get operatorOwners(): ApphubApplicationAttributesOperatorOwnersList;
    putOperatorOwners(value: ApphubApplicationAttributesOperatorOwners[] | cdktn.IResolvable): void;
    resetOperatorOwners(): void;
    get operatorOwnersInput(): cdktn.IResolvable | ApphubApplicationAttributesOperatorOwners[] | undefined;
}
export interface ApphubApplicationScope {
    /**
    * Required. Scope Type.
    *  Possible values:
    * REGIONAL
    * GLOBAL Possible values: ["REGIONAL", "GLOBAL"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#type ApphubApplication#type}
    */
    readonly type: string;
}
export declare function apphubApplicationScopeToTerraform(struct?: ApphubApplicationScopeOutputReference | ApphubApplicationScope): any;
export declare function apphubApplicationScopeToHclTerraform(struct?: ApphubApplicationScopeOutputReference | ApphubApplicationScope): any;
export declare class ApphubApplicationScopeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApphubApplicationScope | undefined;
    set internalValue(value: ApphubApplicationScope | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface ApphubApplicationTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#create ApphubApplication#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#delete ApphubApplication#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#update ApphubApplication#update}
    */
    readonly update?: string;
}
export declare function apphubApplicationTimeoutsToTerraform(struct?: ApphubApplicationTimeouts | cdktn.IResolvable): any;
export declare function apphubApplicationTimeoutsToHclTerraform(struct?: ApphubApplicationTimeouts | cdktn.IResolvable): any;
export declare class ApphubApplicationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApphubApplicationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApphubApplicationTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application google_apphub_application}
*/
export declare class ApphubApplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apphub_application";
    /**
    * Generates CDKTN code for importing a ApphubApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApphubApplication to import
    * @param importFromId The id of the existing ApphubApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApphubApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_application google_apphub_application} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApphubApplicationConfig
    */
    constructor(scope: Construct, id: string, config: ApphubApplicationConfig);
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get state(): string;
    get uid(): string;
    get updateTime(): string;
    private _attributes;
    get attributes(): ApphubApplicationAttributesOutputReference;
    putAttributes(value: ApphubApplicationAttributes): void;
    resetAttributes(): void;
    get attributesInput(): ApphubApplicationAttributes | undefined;
    private _scope;
    get scope(): ApphubApplicationScopeOutputReference;
    putScope(value: ApphubApplicationScope): void;
    get scopeInput(): ApphubApplicationScope | undefined;
    private _timeouts;
    get timeouts(): ApphubApplicationTimeoutsOutputReference;
    putTimeouts(value: ApphubApplicationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApphubApplicationTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
