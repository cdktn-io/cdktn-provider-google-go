/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigeeEnvironmentDebugmaskConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Apigee environment group associated with the Apigee environment, in the format organizations/{{org_name}}/environments/{{env_name}}.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment_debugmask#env_id ApigeeEnvironmentDebugmask#env_id}
    */
    readonly envId: string;
    /**
    * List of XPath expressions that specify the XML elements or attributes that the debug mask applies to for fault messages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment_debugmask#fault_x_paths ApigeeEnvironmentDebugmask#fault_x_paths}
    */
    readonly faultXPaths?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment_debugmask#id ApigeeEnvironmentDebugmask#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Map of namespaces to URIs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment_debugmask#namespaces ApigeeEnvironmentDebugmask#namespaces}
    */
    readonly namespaces?: {
        [key: string]: string;
    };
    /**
    * List of JSONPath expressions that specify the JSON elements or attributes that the debug mask applies to for request messages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment_debugmask#request_json_paths ApigeeEnvironmentDebugmask#request_json_paths}
    */
    readonly requestJsonPaths?: string[];
    /**
    * List of XPath expressions that specify the XML elements or attributes that the debug mask applies to for request messages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment_debugmask#request_x_paths ApigeeEnvironmentDebugmask#request_x_paths}
    */
    readonly requestXPaths?: string[];
    /**
    * List of JSONPath expressions that specify the JSON elements or attributes that the debug mask applies to for response messages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment_debugmask#response_json_paths ApigeeEnvironmentDebugmask#response_json_paths}
    */
    readonly responseJsonPaths?: string[];
    /**
    * List of XPath expressions that specify the XML elements or attributes that the debug mask applies to for response messages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment_debugmask#response_x_paths ApigeeEnvironmentDebugmask#response_x_paths}
    */
    readonly responseXPaths?: string[];
    /**
    * List of variables that the debug mask applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment_debugmask#variables ApigeeEnvironmentDebugmask#variables}
    */
    readonly variables?: string[];
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment_debugmask#timeouts ApigeeEnvironmentDebugmask#timeouts}
    */
    readonly timeouts?: ApigeeEnvironmentDebugmaskTimeouts;
}
export interface ApigeeEnvironmentDebugmaskTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment_debugmask#create ApigeeEnvironmentDebugmask#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment_debugmask#delete ApigeeEnvironmentDebugmask#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment_debugmask#update ApigeeEnvironmentDebugmask#update}
    */
    readonly update?: string;
}
export declare function apigeeEnvironmentDebugmaskTimeoutsToTerraform(struct?: ApigeeEnvironmentDebugmaskTimeouts | cdktn.IResolvable): any;
export declare function apigeeEnvironmentDebugmaskTimeoutsToHclTerraform(struct?: ApigeeEnvironmentDebugmaskTimeouts | cdktn.IResolvable): any;
export declare class ApigeeEnvironmentDebugmaskTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeEnvironmentDebugmaskTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeEnvironmentDebugmaskTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment_debugmask google_apigee_environment_debugmask}
*/
export declare class ApigeeEnvironmentDebugmask extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apigee_environment_debugmask";
    /**
    * Generates CDKTN code for importing a ApigeeEnvironmentDebugmask resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigeeEnvironmentDebugmask to import
    * @param importFromId The id of the existing ApigeeEnvironmentDebugmask that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment_debugmask#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigeeEnvironmentDebugmask to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment_debugmask google_apigee_environment_debugmask} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigeeEnvironmentDebugmaskConfig
    */
    constructor(scope: Construct, id: string, config: ApigeeEnvironmentDebugmaskConfig);
    private _envId?;
    get envId(): string;
    set envId(value: string);
    get envIdInput(): string | undefined;
    private _faultXPaths?;
    get faultXPaths(): string[];
    set faultXPaths(value: string[]);
    resetFaultXPaths(): void;
    get faultXPathsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _namespaces?;
    get namespaces(): {
        [key: string]: string;
    };
    set namespaces(value: {
        [key: string]: string;
    });
    resetNamespaces(): void;
    get namespacesInput(): {
        [key: string]: string;
    } | undefined;
    private _requestJsonPaths?;
    get requestJsonPaths(): string[];
    set requestJsonPaths(value: string[]);
    resetRequestJsonPaths(): void;
    get requestJsonPathsInput(): string[] | undefined;
    private _requestXPaths?;
    get requestXPaths(): string[];
    set requestXPaths(value: string[]);
    resetRequestXPaths(): void;
    get requestXPathsInput(): string[] | undefined;
    private _responseJsonPaths?;
    get responseJsonPaths(): string[];
    set responseJsonPaths(value: string[]);
    resetResponseJsonPaths(): void;
    get responseJsonPathsInput(): string[] | undefined;
    private _responseXPaths?;
    get responseXPaths(): string[];
    set responseXPaths(value: string[]);
    resetResponseXPaths(): void;
    get responseXPathsInput(): string[] | undefined;
    private _variables?;
    get variables(): string[];
    set variables(value: string[]);
    resetVariables(): void;
    get variablesInput(): string[] | undefined;
    private _timeouts;
    get timeouts(): ApigeeEnvironmentDebugmaskTimeoutsOutputReference;
    putTimeouts(value: ApigeeEnvironmentDebugmaskTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApigeeEnvironmentDebugmaskTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
