/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeTargetHttpsProxyConfig extends cdktn.TerraformMetaArguments {
    /**
    * URLs to certificate manager certificate resources that are used to authenticate connections between users and the load balancer.
    * Certificate manager certificates only apply when the load balancing scheme is set to INTERNAL_MANAGED.
    * For EXTERNAL and EXTERNAL_MANAGED, use certificate_map instead.
    * sslCertificates and certificateManagerCertificates fields can not be defined together.
    * Accepted format is '//certificatemanager.googleapis.com/projects/{project}/locations/{location}/certificates/{resourceName}' or just the self_link 'projects/{project}/locations/{location}/certificates/{resourceName}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_target_https_proxy#certificate_manager_certificates ComputeTargetHttpsProxy#certificate_manager_certificates}
    */
    readonly certificateManagerCertificates?: string[];
    /**
    * A reference to the CertificateMap resource uri that identifies a certificate map
    * associated with the given target proxy. This field is only supported for EXTERNAL and EXTERNAL_MANAGED load balancing schemes.
    * For INTERNAL_MANAGED, use certificate_manager_certificates instead.
    * Accepted format is '//certificatemanager.googleapis.com/projects/{project}/locations/{location}/certificateMaps/{resourceName}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_target_https_proxy#certificate_map ComputeTargetHttpsProxy#certificate_map}
    */
    readonly certificateMap?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_target_https_proxy#deletion_policy ComputeTargetHttpsProxy#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_target_https_proxy#description ComputeTargetHttpsProxy#description}
    */
    readonly description?: string;
    /**
    * Specifies how long to keep a connection open, after completing a response,
    * while there is no matching traffic (in seconds). If an HTTP keepalive is
    * not specified, a default value will be used. For Global
    * external HTTP(S) load balancer, the default value is 610 seconds, the
    * minimum allowed value is 5 seconds and the maximum allowed value is 1200
    * seconds. For cross-region internal HTTP(S) load balancer, the default
    * value is 600 seconds, the minimum allowed value is 5 seconds, and the
    * maximum allowed value is 600 seconds. For Global external HTTP(S) load
    * balancer (classic), this option is not available publicly.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_target_https_proxy#http_keep_alive_timeout_sec ComputeTargetHttpsProxy#http_keep_alive_timeout_sec}
    */
    readonly httpKeepAliveTimeoutSec?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_target_https_proxy#id ComputeTargetHttpsProxy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the resource. Provided by the client when the resource is
    * created. The name must be 1-63 characters long, and comply with
    * RFC1035. Specifically, the name must be 1-63 characters long and match
    * the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the
    * first character must be a lowercase letter, and all following
    * characters must be a dash, lowercase letter, or digit, except the last
    * character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_target_https_proxy#name ComputeTargetHttpsProxy#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_target_https_proxy#project ComputeTargetHttpsProxy#project}
    */
    readonly project?: string;
    /**
    * This field only applies when the forwarding rule that references
    * this target proxy has a loadBalancingScheme set to INTERNAL_SELF_MANAGED.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_target_https_proxy#proxy_bind ComputeTargetHttpsProxy#proxy_bind}
    */
    readonly proxyBind?: boolean | cdktn.IResolvable;
    /**
    * Specifies the QUIC override policy for this resource. This determines
    * whether the load balancer will attempt to negotiate QUIC with clients
    * or not. Can specify one of NONE, ENABLE, or DISABLE. If NONE is
    * specified, Google manages whether QUIC is used. Default value: "NONE" Possible values: ["NONE", "ENABLE", "DISABLE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_target_https_proxy#quic_override ComputeTargetHttpsProxy#quic_override}
    */
    readonly quicOverride?: string;
    /**
    * A URL referring to a networksecurity.ServerTlsPolicy
    * resource that describes how the proxy should authenticate inbound
    * traffic. serverTlsPolicy only applies to a global TargetHttpsProxy
    * attached to globalForwardingRules with the loadBalancingScheme
    * set to INTERNAL_SELF_MANAGED or EXTERNAL or EXTERNAL_MANAGED.
    * For details which ServerTlsPolicy resources are accepted with
    * INTERNAL_SELF_MANAGED and which with EXTERNAL, EXTERNAL_MANAGED
    * loadBalancingScheme consult ServerTlsPolicy documentation.
    * If left blank, communications are not encrypted.
    *
    * If you remove this field from your configuration at the same time as
    * deleting or recreating a referenced ServerTlsPolicy resource, you will
    * receive a resourceInUseByAnotherResource error. Use lifecycle.create_before_destroy
    * within the ServerTlsPolicy resource to avoid this.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_target_https_proxy#server_tls_policy ComputeTargetHttpsProxy#server_tls_policy}
    */
    readonly serverTlsPolicy?: string;
    /**
    * URLs to SslCertificate resources that are used to authenticate connections between users and the load balancer.
    * Currently, you may specify up to 15 SSL certificates. sslCertificates do not apply when the load balancing scheme is set to INTERNAL_SELF_MANAGED.
    * sslCertificates and certificateManagerCertificates can not be defined together.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_target_https_proxy#ssl_certificates ComputeTargetHttpsProxy#ssl_certificates}
    */
    readonly sslCertificates?: string[];
    /**
    * A reference to the SslPolicy resource that will be associated with
    * the TargetHttpsProxy resource. If not set, the TargetHttpsProxy
    * resource will not have any SSL policy configured.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_target_https_proxy#ssl_policy ComputeTargetHttpsProxy#ssl_policy}
    */
    readonly sslPolicy?: string;
    /**
    * Specifies whether TLS 1.3 0-RTT Data (“Early Data”) should be accepted for this service.
    * Early Data allows a TLS resumption handshake to include the initial application payload
    * (a HTTP request) alongside the handshake, reducing the effective round trips to “zero”.
    * This applies to TLS 1.3 connections over TCP (HTTP/2) as well as over UDP (QUIC/h3). Possible values: ["STRICT", "PERMISSIVE", "UNRESTRICTED", "DISABLED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_target_https_proxy#tls_early_data ComputeTargetHttpsProxy#tls_early_data}
    */
    readonly tlsEarlyData?: string;
    /**
    * A reference to the UrlMap resource that defines the mapping from URL
    * to the BackendService.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_target_https_proxy#url_map ComputeTargetHttpsProxy#url_map}
    */
    readonly urlMap: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_target_https_proxy#timeouts ComputeTargetHttpsProxy#timeouts}
    */
    readonly timeouts?: ComputeTargetHttpsProxyTimeouts;
}
export interface ComputeTargetHttpsProxyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_target_https_proxy#create ComputeTargetHttpsProxy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_target_https_proxy#delete ComputeTargetHttpsProxy#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_target_https_proxy#update ComputeTargetHttpsProxy#update}
    */
    readonly update?: string;
}
export declare function computeTargetHttpsProxyTimeoutsToTerraform(struct?: ComputeTargetHttpsProxyTimeouts | cdktn.IResolvable): any;
export declare function computeTargetHttpsProxyTimeoutsToHclTerraform(struct?: ComputeTargetHttpsProxyTimeouts | cdktn.IResolvable): any;
export declare class ComputeTargetHttpsProxyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeTargetHttpsProxyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeTargetHttpsProxyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_target_https_proxy google_compute_target_https_proxy}
*/
export declare class ComputeTargetHttpsProxy extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_target_https_proxy";
    /**
    * Generates CDKTN code for importing a ComputeTargetHttpsProxy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeTargetHttpsProxy to import
    * @param importFromId The id of the existing ComputeTargetHttpsProxy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_target_https_proxy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeTargetHttpsProxy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_target_https_proxy google_compute_target_https_proxy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeTargetHttpsProxyConfig
    */
    constructor(scope: Construct, id: string, config: ComputeTargetHttpsProxyConfig);
    private _certificateManagerCertificates?;
    get certificateManagerCertificates(): string[];
    set certificateManagerCertificates(value: string[]);
    resetCertificateManagerCertificates(): void;
    get certificateManagerCertificatesInput(): string[] | undefined;
    private _certificateMap?;
    get certificateMap(): string;
    set certificateMap(value: string);
    resetCertificateMap(): void;
    get certificateMapInput(): string | undefined;
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get fingerprint(): string;
    private _httpKeepAliveTimeoutSec?;
    get httpKeepAliveTimeoutSec(): number;
    set httpKeepAliveTimeoutSec(value: number);
    resetHttpKeepAliveTimeoutSec(): void;
    get httpKeepAliveTimeoutSecInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _proxyBind?;
    get proxyBind(): boolean | cdktn.IResolvable;
    set proxyBind(value: boolean | cdktn.IResolvable);
    resetProxyBind(): void;
    get proxyBindInput(): boolean | cdktn.IResolvable | undefined;
    get proxyId(): number;
    private _quicOverride?;
    get quicOverride(): string;
    set quicOverride(value: string);
    resetQuicOverride(): void;
    get quicOverrideInput(): string | undefined;
    get selfLink(): string;
    private _serverTlsPolicy?;
    get serverTlsPolicy(): string;
    set serverTlsPolicy(value: string);
    resetServerTlsPolicy(): void;
    get serverTlsPolicyInput(): string | undefined;
    private _sslCertificates?;
    get sslCertificates(): string[];
    set sslCertificates(value: string[]);
    resetSslCertificates(): void;
    get sslCertificatesInput(): string[] | undefined;
    private _sslPolicy?;
    get sslPolicy(): string;
    set sslPolicy(value: string);
    resetSslPolicy(): void;
    get sslPolicyInput(): string | undefined;
    private _tlsEarlyData?;
    get tlsEarlyData(): string;
    set tlsEarlyData(value: string);
    resetTlsEarlyData(): void;
    get tlsEarlyDataInput(): string | undefined;
    private _urlMap?;
    get urlMap(): string;
    set urlMap(value: string);
    get urlMapInput(): string | undefined;
    private _timeouts;
    get timeouts(): ComputeTargetHttpsProxyTimeoutsOutputReference;
    putTimeouts(value: ComputeTargetHttpsProxyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeTargetHttpsProxyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
