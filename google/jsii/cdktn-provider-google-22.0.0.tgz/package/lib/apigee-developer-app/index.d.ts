/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigeeDeveloperAppConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of API products associated with the developer app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_developer_app#api_products ApigeeDeveloperApp#api_products}
    */
    readonly apiProducts?: string[];
    /**
    * Developer app family.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_developer_app#app_family ApigeeDeveloperApp#app_family}
    */
    readonly appFamily?: string;
    /**
    * Callback URL used by OAuth 2.0 authorization servers to communicate
    * authorization codes back to developer apps.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_developer_app#callback_url ApigeeDeveloperApp#callback_url}
    */
    readonly callbackUrl: string;
    /**
    * Optionally specify a static consumer key for the developer app's credential.
    * If not set, the API auto-generates a key. The consumer key must be unique
    * across all developer apps in an organization. Changing this field forces the
    * resource to be recreated.
    *
    * This is a write-only input used at create time: the provider creates the
    * credential with this key via the keys API and removes the auto-generated
    * one. The effective key is exposed in the 'credentials' output.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_developer_app#consumer_key ApigeeDeveloperApp#consumer_key}
    */
    readonly consumerKey?: string;
    /**
    * Optionally specify a static consumer secret for the developer app's
    * credential. Required if 'consumer_key' is specified. If not set, the API
    * auto-generates a secret. Changing this field forces the resource to be
    * recreated.
    *
    * This is a write-only input used at create time; the effective secret is
    * exposed in the 'credentials' output.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_developer_app#consumer_secret ApigeeDeveloperApp#consumer_secret}
    */
    readonly consumerSecret?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_developer_app#deletion_policy ApigeeDeveloperApp#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Email address of the developer.
    * This value is used to uniquely identify the developer in Apigee hybrid.
    * Note that the email address has to be in lowercase only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_developer_app#developer_email ApigeeDeveloperApp#developer_email}
    */
    readonly developerEmail: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_developer_app#id ApigeeDeveloperApp#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Expiration time, in milliseconds, for the consumer key that is generated
    * for the developer app. If not set or left to the default value of -1,
    * the API key never expires. The expiration time can't be updated after it is set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_developer_app#key_expires_in ApigeeDeveloperApp#key_expires_in}
    */
    readonly keyExpiresIn?: string;
    /**
    * Name of the developer app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_developer_app#name ApigeeDeveloperApp#name}
    */
    readonly name: string;
    /**
    * The Apigee Organization associated with the Apigee instance,
    * in the format 'organizations/{{org_name}}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_developer_app#org_id ApigeeDeveloperApp#org_id}
    */
    readonly orgId: string;
    /**
    * Scopes to apply to the developer app.
    * The specified scopes must already exist for the API product that
    * you associate with the developer app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_developer_app#scopes ApigeeDeveloperApp#scopes}
    */
    readonly scopes?: string[];
    /**
    * Status of the credential. Valid values include approved or revoked.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_developer_app#status ApigeeDeveloperApp#status}
    */
    readonly status?: string;
    /**
    * attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_developer_app#attributes ApigeeDeveloperApp#attributes}
    */
    readonly attributes?: ApigeeDeveloperAppAttributes[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_developer_app#timeouts ApigeeDeveloperApp#timeouts}
    */
    readonly timeouts?: ApigeeDeveloperAppTimeouts;
}
export interface ApigeeDeveloperAppCredentialsApiProducts {
}
export declare function apigeeDeveloperAppCredentialsApiProductsToTerraform(struct?: ApigeeDeveloperAppCredentialsApiProducts): any;
export declare function apigeeDeveloperAppCredentialsApiProductsToHclTerraform(struct?: ApigeeDeveloperAppCredentialsApiProducts): any;
export declare class ApigeeDeveloperAppCredentialsApiProductsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigeeDeveloperAppCredentialsApiProducts | undefined;
    set internalValue(value: ApigeeDeveloperAppCredentialsApiProducts | undefined);
    get apiproduct(): string;
    get status(): string;
}
export declare class ApigeeDeveloperAppCredentialsApiProductsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigeeDeveloperAppCredentialsApiProductsOutputReference;
}
export interface ApigeeDeveloperAppCredentialsAttributes {
}
export declare function apigeeDeveloperAppCredentialsAttributesToTerraform(struct?: ApigeeDeveloperAppCredentialsAttributes): any;
export declare function apigeeDeveloperAppCredentialsAttributesToHclTerraform(struct?: ApigeeDeveloperAppCredentialsAttributes): any;
export declare class ApigeeDeveloperAppCredentialsAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigeeDeveloperAppCredentialsAttributes | undefined;
    set internalValue(value: ApigeeDeveloperAppCredentialsAttributes | undefined);
    get name(): string;
    get value(): string;
}
export declare class ApigeeDeveloperAppCredentialsAttributesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigeeDeveloperAppCredentialsAttributesOutputReference;
}
export interface ApigeeDeveloperAppCredentials {
}
export declare function apigeeDeveloperAppCredentialsToTerraform(struct?: ApigeeDeveloperAppCredentials): any;
export declare function apigeeDeveloperAppCredentialsToHclTerraform(struct?: ApigeeDeveloperAppCredentials): any;
export declare class ApigeeDeveloperAppCredentialsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigeeDeveloperAppCredentials | undefined;
    set internalValue(value: ApigeeDeveloperAppCredentials | undefined);
    private _apiProducts;
    get apiProducts(): ApigeeDeveloperAppCredentialsApiProductsList;
    private _attributes;
    get attributes(): ApigeeDeveloperAppCredentialsAttributesList;
    get consumerKey(): string;
    get consumerSecret(): string;
    get expiresAt(): string;
    get issuedAt(): string;
    get scopes(): string[];
    get status(): string;
}
export declare class ApigeeDeveloperAppCredentialsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigeeDeveloperAppCredentialsOutputReference;
}
export interface ApigeeDeveloperAppAttributes {
    /**
    * Key of the attribute
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_developer_app#name ApigeeDeveloperApp#name}
    */
    readonly name?: string;
    /**
    * Value of the attribute
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_developer_app#value ApigeeDeveloperApp#value}
    */
    readonly value?: string;
}
export declare function apigeeDeveloperAppAttributesToTerraform(struct?: ApigeeDeveloperAppAttributes | cdktn.IResolvable): any;
export declare function apigeeDeveloperAppAttributesToHclTerraform(struct?: ApigeeDeveloperAppAttributes | cdktn.IResolvable): any;
export declare class ApigeeDeveloperAppAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigeeDeveloperAppAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeDeveloperAppAttributes | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApigeeDeveloperAppAttributesList extends cdktn.ComplexList {
    internalValue?: ApigeeDeveloperAppAttributes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigeeDeveloperAppAttributesOutputReference;
}
export interface ApigeeDeveloperAppTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_developer_app#create ApigeeDeveloperApp#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_developer_app#delete ApigeeDeveloperApp#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_developer_app#update ApigeeDeveloperApp#update}
    */
    readonly update?: string;
}
export declare function apigeeDeveloperAppTimeoutsToTerraform(struct?: ApigeeDeveloperAppTimeouts | cdktn.IResolvable): any;
export declare function apigeeDeveloperAppTimeoutsToHclTerraform(struct?: ApigeeDeveloperAppTimeouts | cdktn.IResolvable): any;
export declare class ApigeeDeveloperAppTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeDeveloperAppTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeDeveloperAppTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_developer_app google_apigee_developer_app}
*/
export declare class ApigeeDeveloperApp extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apigee_developer_app";
    /**
    * Generates CDKTN code for importing a ApigeeDeveloperApp resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigeeDeveloperApp to import
    * @param importFromId The id of the existing ApigeeDeveloperApp that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_developer_app#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigeeDeveloperApp to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_developer_app google_apigee_developer_app} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigeeDeveloperAppConfig
    */
    constructor(scope: Construct, id: string, config: ApigeeDeveloperAppConfig);
    private _apiProducts?;
    get apiProducts(): string[];
    set apiProducts(value: string[]);
    resetApiProducts(): void;
    get apiProductsInput(): string[] | undefined;
    private _appFamily?;
    get appFamily(): string;
    set appFamily(value: string);
    resetAppFamily(): void;
    get appFamilyInput(): string | undefined;
    get appId(): string;
    private _callbackUrl?;
    get callbackUrl(): string;
    set callbackUrl(value: string);
    get callbackUrlInput(): string | undefined;
    private _consumerKey?;
    get consumerKey(): string;
    set consumerKey(value: string);
    resetConsumerKey(): void;
    get consumerKeyInput(): string | undefined;
    private _consumerSecret?;
    get consumerSecret(): string;
    set consumerSecret(value: string);
    resetConsumerSecret(): void;
    get consumerSecretInput(): string | undefined;
    get createdAt(): string;
    private _credentials;
    get credentials(): ApigeeDeveloperAppCredentialsList;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _developerEmail?;
    get developerEmail(): string;
    set developerEmail(value: string);
    get developerEmailInput(): string | undefined;
    get developerId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keyExpiresIn?;
    get keyExpiresIn(): string;
    set keyExpiresIn(value: string);
    resetKeyExpiresIn(): void;
    get keyExpiresInInput(): string | undefined;
    get lastModifiedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _orgId?;
    get orgId(): string;
    set orgId(value: string);
    get orgIdInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _attributes;
    get attributes(): ApigeeDeveloperAppAttributesList;
    putAttributes(value: ApigeeDeveloperAppAttributes[] | cdktn.IResolvable): void;
    resetAttributes(): void;
    get attributesInput(): cdktn.IResolvable | ApigeeDeveloperAppAttributes[] | undefined;
    private _timeouts;
    get timeouts(): ApigeeDeveloperAppTimeoutsOutputReference;
    putTimeouts(value: ApigeeDeveloperAppTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApigeeDeveloperAppTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
