/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeNetworkEndpointsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_endpoints#deletion_policy ComputeNetworkEndpoints#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_endpoints#id ComputeNetworkEndpoints#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The network endpoint group these endpoints are part of.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_endpoints#network_endpoint_group ComputeNetworkEndpoints#network_endpoint_group}
    */
    readonly networkEndpointGroup: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_endpoints#project ComputeNetworkEndpoints#project}
    */
    readonly project?: string;
    /**
    * Zone where the containing network endpoint group is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_endpoints#zone ComputeNetworkEndpoints#zone}
    */
    readonly zone?: string;
    /**
    * network_endpoints block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_endpoints#network_endpoints ComputeNetworkEndpoints#network_endpoints}
    */
    readonly networkEndpoints?: ComputeNetworkEndpointsNetworkEndpoints[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_endpoints#timeouts ComputeNetworkEndpoints#timeouts}
    */
    readonly timeouts?: ComputeNetworkEndpointsTimeouts;
}
export interface ComputeNetworkEndpointsNetworkEndpoints {
    /**
    * The name for a specific VM instance that the IP address belongs to.
    * This is required for network endpoints of type GCE_VM_IP_PORT.
    * The instance must be in the same zone as the network endpoint group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_endpoints#instance ComputeNetworkEndpoints#instance}
    */
    readonly instance?: string;
    /**
    * IPv4 address of network endpoint. The IP address must belong
    * to a VM in GCE (either the primary IP or as part of an aliased IP
    * range).
    * **Note** 'ip_address' is required unless the Network Endpoint Group is created with the type of 'GCE_VM_IP_DEDICATED_BACKEND'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_endpoints#ip_address ComputeNetworkEndpoints#ip_address}
    */
    readonly ipAddress?: string;
    /**
    * IPv6 address of network endpoint. The result of parsing the endpoint config,
    * or empty if IPv6 is not used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_endpoints#ipv6_address ComputeNetworkEndpoints#ipv6_address}
    */
    readonly ipv6Address?: string;
    /**
    * Port number of network endpoint.
    * **Note** 'port' is required unless the Network Endpoint Group is created
    * with the type of 'GCE_VM_IP'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_endpoints#port ComputeNetworkEndpoints#port}
    */
    readonly port?: number;
}
export declare function computeNetworkEndpointsNetworkEndpointsToTerraform(struct?: ComputeNetworkEndpointsNetworkEndpoints | cdktn.IResolvable): any;
export declare function computeNetworkEndpointsNetworkEndpointsToHclTerraform(struct?: ComputeNetworkEndpointsNetworkEndpoints | cdktn.IResolvable): any;
export declare class ComputeNetworkEndpointsNetworkEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeNetworkEndpointsNetworkEndpoints | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeNetworkEndpointsNetworkEndpoints | cdktn.IResolvable | undefined);
    private _instance?;
    get instance(): string;
    set instance(value: string);
    resetInstance(): void;
    get instanceInput(): string | undefined;
    private _ipAddress?;
    get ipAddress(): string;
    set ipAddress(value: string);
    resetIpAddress(): void;
    get ipAddressInput(): string | undefined;
    private _ipv6Address?;
    get ipv6Address(): string;
    set ipv6Address(value: string);
    resetIpv6Address(): void;
    get ipv6AddressInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
}
export declare class ComputeNetworkEndpointsNetworkEndpointsList extends cdktn.ComplexList {
    internalValue?: ComputeNetworkEndpointsNetworkEndpoints[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeNetworkEndpointsNetworkEndpointsOutputReference;
}
export interface ComputeNetworkEndpointsTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_endpoints#create ComputeNetworkEndpoints#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_endpoints#delete ComputeNetworkEndpoints#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_endpoints#update ComputeNetworkEndpoints#update}
    */
    readonly update?: string;
}
export declare function computeNetworkEndpointsTimeoutsToTerraform(struct?: ComputeNetworkEndpointsTimeouts | cdktn.IResolvable): any;
export declare function computeNetworkEndpointsTimeoutsToHclTerraform(struct?: ComputeNetworkEndpointsTimeouts | cdktn.IResolvable): any;
export declare class ComputeNetworkEndpointsTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeNetworkEndpointsTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeNetworkEndpointsTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_endpoints google_compute_network_endpoints}
*/
export declare class ComputeNetworkEndpoints extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_network_endpoints";
    /**
    * Generates CDKTN code for importing a ComputeNetworkEndpoints resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeNetworkEndpoints to import
    * @param importFromId The id of the existing ComputeNetworkEndpoints that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_endpoints#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeNetworkEndpoints to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_endpoints google_compute_network_endpoints} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeNetworkEndpointsConfig
    */
    constructor(scope: Construct, id: string, config: ComputeNetworkEndpointsConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _networkEndpointGroup?;
    get networkEndpointGroup(): string;
    set networkEndpointGroup(value: string);
    get networkEndpointGroupInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    resetZone(): void;
    get zoneInput(): string | undefined;
    private _networkEndpoints;
    get networkEndpoints(): ComputeNetworkEndpointsNetworkEndpointsList;
    putNetworkEndpoints(value: ComputeNetworkEndpointsNetworkEndpoints[] | cdktn.IResolvable): void;
    resetNetworkEndpoints(): void;
    get networkEndpointsInput(): cdktn.IResolvable | ComputeNetworkEndpointsNetworkEndpoints[] | undefined;
    private _timeouts;
    get timeouts(): ComputeNetworkEndpointsTimeoutsOutputReference;
    putTimeouts(value: ComputeNetworkEndpointsTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeNetworkEndpointsTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
