/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComposerUserWorkloadsConfigMapConfig extends cdktn.TerraformMetaArguments {
    /**
    * The "data" field of Kubernetes ConfigMap, organized in key-value pairs.
    * For details see: https://kubernetes.io/docs/concepts/configuration/configmap/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/composer_user_workloads_config_map#data ComposerUserWorkloadsConfigMap#data}
    */
    readonly data?: {
        [key: string]: string;
    };
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/composer_user_workloads_config_map#deletion_policy ComposerUserWorkloadsConfigMap#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Environment where the Kubernetes ConfigMap will be stored and used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/composer_user_workloads_config_map#environment ComposerUserWorkloadsConfigMap#environment}
    */
    readonly environment: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/composer_user_workloads_config_map#id ComposerUserWorkloadsConfigMap#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the Kubernetes ConfigMap.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/composer_user_workloads_config_map#name ComposerUserWorkloadsConfigMap#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/composer_user_workloads_config_map#project ComposerUserWorkloadsConfigMap#project}
    */
    readonly project?: string;
    /**
    * The location or Compute Engine region for the environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/composer_user_workloads_config_map#region ComposerUserWorkloadsConfigMap#region}
    */
    readonly region?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/composer_user_workloads_config_map#timeouts ComposerUserWorkloadsConfigMap#timeouts}
    */
    readonly timeouts?: ComposerUserWorkloadsConfigMapTimeouts;
}
export interface ComposerUserWorkloadsConfigMapTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/composer_user_workloads_config_map#create ComposerUserWorkloadsConfigMap#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/composer_user_workloads_config_map#delete ComposerUserWorkloadsConfigMap#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/composer_user_workloads_config_map#update ComposerUserWorkloadsConfigMap#update}
    */
    readonly update?: string;
}
export declare function composerUserWorkloadsConfigMapTimeoutsToTerraform(struct?: ComposerUserWorkloadsConfigMapTimeouts | cdktn.IResolvable): any;
export declare function composerUserWorkloadsConfigMapTimeoutsToHclTerraform(struct?: ComposerUserWorkloadsConfigMapTimeouts | cdktn.IResolvable): any;
export declare class ComposerUserWorkloadsConfigMapTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComposerUserWorkloadsConfigMapTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComposerUserWorkloadsConfigMapTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/composer_user_workloads_config_map google_composer_user_workloads_config_map}
*/
export declare class ComposerUserWorkloadsConfigMap extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_composer_user_workloads_config_map";
    /**
    * Generates CDKTN code for importing a ComposerUserWorkloadsConfigMap resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComposerUserWorkloadsConfigMap to import
    * @param importFromId The id of the existing ComposerUserWorkloadsConfigMap that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/composer_user_workloads_config_map#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComposerUserWorkloadsConfigMap to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/composer_user_workloads_config_map google_composer_user_workloads_config_map} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComposerUserWorkloadsConfigMapConfig
    */
    constructor(scope: Construct, id: string, config: ComposerUserWorkloadsConfigMapConfig);
    private _data?;
    get data(): {
        [key: string]: string;
    };
    set data(value: {
        [key: string]: string;
    });
    resetData(): void;
    get dataInput(): {
        [key: string]: string;
    } | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _environment?;
    get environment(): string;
    set environment(value: string);
    get environmentInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _timeouts;
    get timeouts(): ComposerUserWorkloadsConfigMapTimeoutsOutputReference;
    putTimeouts(value: ComposerUserWorkloadsConfigMapTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComposerUserWorkloadsConfigMapTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
