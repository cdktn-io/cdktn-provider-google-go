/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeRouterPeerConfig extends cdktn.TerraformMetaArguments {
    /**
    * User-specified flag to indicate which mode to use for advertisement.
    * Valid values of this enum field are: 'DEFAULT', 'CUSTOM' Default value: "DEFAULT" Possible values: ["DEFAULT", "CUSTOM"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#advertise_mode ComputeRouterPeer#advertise_mode}
    */
    readonly advertiseMode?: string;
    /**
    * User-specified list of prefix groups to advertise in custom
    * mode, which currently supports the following option:
    *
    * * 'ALL_SUBNETS': Advertises all of the router's own VPC subnets.
    * This excludes any routes learned for subnets that use VPC Network
    * Peering.
    *
    *
    * Note that this field can only be populated if advertiseMode is 'CUSTOM'
    * and overrides the list defined for the router (in the "bgp" message).
    * These groups are advertised in addition to any specified prefixes.
    * Leave this field blank to advertise no custom groups.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#advertised_groups ComputeRouterPeer#advertised_groups}
    */
    readonly advertisedGroups?: string[];
    /**
    * The priority of routes advertised to this BGP peer.
    * Where there is more than one matching route of maximum
    * length, the routes with the lowest priority value win.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#advertised_route_priority ComputeRouterPeer#advertised_route_priority}
    */
    readonly advertisedRoutePriority?: number;
    /**
    * The user-defined custom learned route priority for a BGP session.
    * This value is applied to all custom learned route ranges for the session. You can choose a value
    * from 0 to 65335. If you don't provide a value, Google Cloud assigns a priority of 100 to the ranges.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#custom_learned_route_priority ComputeRouterPeer#custom_learned_route_priority}
    */
    readonly customLearnedRoutePriority?: number;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#deletion_policy ComputeRouterPeer#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The status of the BGP peer connection. If set to false, any active session
    * with the peer is terminated and all associated routing information is removed.
    * If set to true, the peer connection can be established with routing information.
    * The default is true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#enable ComputeRouterPeer#enable}
    */
    readonly enable?: boolean | cdktn.IResolvable;
    /**
    * Enable IPv4 traffic over BGP Peer. It is enabled by default if the peerIpAddress is version 4.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#enable_ipv4 ComputeRouterPeer#enable_ipv4}
    */
    readonly enableIpv4?: boolean | cdktn.IResolvable;
    /**
    * Enable IPv6 traffic over BGP Peer. If not specified, it is disabled by default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#enable_ipv6 ComputeRouterPeer#enable_ipv6}
    */
    readonly enableIpv6?: boolean | cdktn.IResolvable;
    /**
    * routers.list of export policies applied to this peer, in the order they must be evaluated.
    * The name must correspond to an existing policy that has ROUTE_POLICY_TYPE_EXPORT type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#export_policies ComputeRouterPeer#export_policies}
    */
    readonly exportPolicies?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#id ComputeRouterPeer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * routers.list of import policies applied to this peer, in the order they must be evaluated.
    * The name must correspond to an existing policy that has ROUTE_POLICY_TYPE_IMPORT type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#import_policies ComputeRouterPeer#import_policies}
    */
    readonly importPolicies?: string[];
    /**
    * Name of the interface the BGP peer is associated with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#interface ComputeRouterPeer#interface}
    */
    readonly interface: string;
    /**
    * IP address of the interface inside Google Cloud Platform.
    * Only IPv4 is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#ip_address ComputeRouterPeer#ip_address}
    */
    readonly ipAddress?: string;
    /**
    * IPv4 address of the interface inside Google Cloud Platform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#ipv4_nexthop_address ComputeRouterPeer#ipv4_nexthop_address}
    */
    readonly ipv4NexthopAddress?: string;
    /**
    * IPv6 address of the interface inside Google Cloud Platform.
    * The address must be in the range 2600:2d00:0:2::/64 or 2600:2d00:0:3::/64.
    * If you do not specify the next hop addresses, Google Cloud automatically
    * assigns unused addresses from the 2600:2d00:0:2::/64 or 2600:2d00:0:3::/64 range for you.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#ipv6_nexthop_address ComputeRouterPeer#ipv6_nexthop_address}
    */
    readonly ipv6NexthopAddress?: string;
    /**
    * Name of this BGP peer. The name must be 1-63 characters long,
    * and comply with RFC1035. Specifically, the name must be 1-63 characters
    * long and match the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which
    * means the first character must be a lowercase letter, and all
    * following characters must be a dash, lowercase letter, or digit,
    * except the last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#name ComputeRouterPeer#name}
    */
    readonly name: string;
    /**
    * Peer BGP Autonomous System Number (ASN).
    * Each BGP interface may use a different value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#peer_asn ComputeRouterPeer#peer_asn}
    */
    readonly peerAsn: number;
    /**
    * IP address of the BGP interface outside Google Cloud Platform.
    * Only IPv4 is supported. Required if 'ip_address' is set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#peer_ip_address ComputeRouterPeer#peer_ip_address}
    */
    readonly peerIpAddress?: string;
    /**
    * IPv4 address of the BGP interface outside Google Cloud Platform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#peer_ipv4_nexthop_address ComputeRouterPeer#peer_ipv4_nexthop_address}
    */
    readonly peerIpv4NexthopAddress?: string;
    /**
    * IPv6 address of the BGP interface outside Google Cloud Platform.
    * The address must be in the range 2600:2d00:0:2::/64 or 2600:2d00:0:3::/64.
    * If you do not specify the next hop addresses, Google Cloud automatically
    * assigns unused addresses from the 2600:2d00:0:2::/64 or 2600:2d00:0:3::/64 range for you.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#peer_ipv6_nexthop_address ComputeRouterPeer#peer_ipv6_nexthop_address}
    */
    readonly peerIpv6NexthopAddress?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#project ComputeRouterPeer#project}
    */
    readonly project?: string;
    /**
    * Region where the router and BgpPeer reside.
    * If it is not provided, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#region ComputeRouterPeer#region}
    */
    readonly region?: string;
    /**
    * The name of the Cloud Router in which this BgpPeer will be configured.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#router ComputeRouterPeer#router}
    */
    readonly router: string;
    /**
    * The URI of the VM instance that is used as third-party router appliances
    * such as Next Gen Firewalls, Virtual Routers, or Router Appliances.
    * The VM instance must be located in zones contained in the same region as
    * this Cloud Router. The VM instance is the peer side of the BGP session.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#router_appliance_instance ComputeRouterPeer#router_appliance_instance}
    */
    readonly routerApplianceInstance?: string;
    /**
    * Force the advertised_route_priority to be 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#zero_advertised_route_priority ComputeRouterPeer#zero_advertised_route_priority}
    */
    readonly zeroAdvertisedRoutePriority?: boolean | cdktn.IResolvable;
    /**
    * Force the custom_learned_route_priority to be 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#zero_custom_learned_route_priority ComputeRouterPeer#zero_custom_learned_route_priority}
    */
    readonly zeroCustomLearnedRoutePriority?: boolean | cdktn.IResolvable;
    /**
    * advertised_ip_ranges block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#advertised_ip_ranges ComputeRouterPeer#advertised_ip_ranges}
    */
    readonly advertisedIpRanges?: ComputeRouterPeerAdvertisedIpRanges[] | cdktn.IResolvable;
    /**
    * bfd block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#bfd ComputeRouterPeer#bfd}
    */
    readonly bfd?: ComputeRouterPeerBfd;
    /**
    * custom_learned_ip_ranges block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#custom_learned_ip_ranges ComputeRouterPeer#custom_learned_ip_ranges}
    */
    readonly customLearnedIpRanges?: ComputeRouterPeerCustomLearnedIpRanges[] | cdktn.IResolvable;
    /**
    * md5_authentication_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#md5_authentication_key ComputeRouterPeer#md5_authentication_key}
    */
    readonly md5AuthenticationKey?: ComputeRouterPeerMd5AuthenticationKey;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#timeouts ComputeRouterPeer#timeouts}
    */
    readonly timeouts?: ComputeRouterPeerTimeouts;
}
export interface ComputeRouterPeerAdvertisedIpRanges {
    /**
    * User-specified description for the IP range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#description ComputeRouterPeer#description}
    */
    readonly description?: string;
    /**
    * The IP range to advertise. The value must be a
    * CIDR-formatted string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#range ComputeRouterPeer#range}
    */
    readonly range: string;
}
export declare function computeRouterPeerAdvertisedIpRangesToTerraform(struct?: ComputeRouterPeerAdvertisedIpRanges | cdktn.IResolvable): any;
export declare function computeRouterPeerAdvertisedIpRangesToHclTerraform(struct?: ComputeRouterPeerAdvertisedIpRanges | cdktn.IResolvable): any;
export declare class ComputeRouterPeerAdvertisedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRouterPeerAdvertisedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRouterPeerAdvertisedIpRanges | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _range?;
    get range(): string;
    set range(value: string);
    get rangeInput(): string | undefined;
}
export declare class ComputeRouterPeerAdvertisedIpRangesList extends cdktn.ComplexList {
    internalValue?: ComputeRouterPeerAdvertisedIpRanges[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRouterPeerAdvertisedIpRangesOutputReference;
}
export interface ComputeRouterPeerBfd {
    /**
    * The minimum interval, in milliseconds, between BFD control packets
    * received from the peer router. The actual value is negotiated
    * between the two routers and is equal to the greater of this value
    * and the transmit interval of the other router. If set, this value
    * must be between 1000 and 30000.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#min_receive_interval ComputeRouterPeer#min_receive_interval}
    */
    readonly minReceiveInterval?: number;
    /**
    * The minimum interval, in milliseconds, between BFD control packets
    * transmitted to the peer router. The actual value is negotiated
    * between the two routers and is equal to the greater of this value
    * and the corresponding receive interval of the other router. If set,
    * this value must be between 1000 and 30000.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#min_transmit_interval ComputeRouterPeer#min_transmit_interval}
    */
    readonly minTransmitInterval?: number;
    /**
    * The number of consecutive BFD packets that must be missed before
    * BFD declares that a peer is unavailable. If set, the value must
    * be a value between 5 and 16.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#multiplier ComputeRouterPeer#multiplier}
    */
    readonly multiplier?: number;
    /**
    * The BFD session initialization mode for this BGP peer.
    * If set to 'ACTIVE', the Cloud Router will initiate the BFD session
    * for this BGP peer. If set to 'PASSIVE', the Cloud Router will wait
    * for the peer router to initiate the BFD session for this BGP peer.
    * If set to 'DISABLED', BFD is disabled for this BGP peer. Possible values: ["ACTIVE", "DISABLED", "PASSIVE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#session_initialization_mode ComputeRouterPeer#session_initialization_mode}
    */
    readonly sessionInitializationMode: string;
}
export declare function computeRouterPeerBfdToTerraform(struct?: ComputeRouterPeerBfdOutputReference | ComputeRouterPeerBfd): any;
export declare function computeRouterPeerBfdToHclTerraform(struct?: ComputeRouterPeerBfdOutputReference | ComputeRouterPeerBfd): any;
export declare class ComputeRouterPeerBfdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRouterPeerBfd | undefined;
    set internalValue(value: ComputeRouterPeerBfd | undefined);
    private _minReceiveInterval?;
    get minReceiveInterval(): number;
    set minReceiveInterval(value: number);
    resetMinReceiveInterval(): void;
    get minReceiveIntervalInput(): number | undefined;
    private _minTransmitInterval?;
    get minTransmitInterval(): number;
    set minTransmitInterval(value: number);
    resetMinTransmitInterval(): void;
    get minTransmitIntervalInput(): number | undefined;
    private _multiplier?;
    get multiplier(): number;
    set multiplier(value: number);
    resetMultiplier(): void;
    get multiplierInput(): number | undefined;
    private _sessionInitializationMode?;
    get sessionInitializationMode(): string;
    set sessionInitializationMode(value: string);
    get sessionInitializationModeInput(): string | undefined;
}
export interface ComputeRouterPeerCustomLearnedIpRanges {
    /**
    * The IP range to learn. The value must be a
    * CIDR-formatted string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#range ComputeRouterPeer#range}
    */
    readonly range: string;
}
export declare function computeRouterPeerCustomLearnedIpRangesToTerraform(struct?: ComputeRouterPeerCustomLearnedIpRanges | cdktn.IResolvable): any;
export declare function computeRouterPeerCustomLearnedIpRangesToHclTerraform(struct?: ComputeRouterPeerCustomLearnedIpRanges | cdktn.IResolvable): any;
export declare class ComputeRouterPeerCustomLearnedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRouterPeerCustomLearnedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRouterPeerCustomLearnedIpRanges | cdktn.IResolvable | undefined);
    private _range?;
    get range(): string;
    set range(value: string);
    get rangeInput(): string | undefined;
}
export declare class ComputeRouterPeerCustomLearnedIpRangesList extends cdktn.ComplexList {
    internalValue?: ComputeRouterPeerCustomLearnedIpRanges[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRouterPeerCustomLearnedIpRangesOutputReference;
}
export interface ComputeRouterPeerMd5AuthenticationKey {
    /**
    * Value of the key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#key ComputeRouterPeer#key}
    */
    readonly key: string;
    /**
    * [REQUIRED] Name used to identify the key.
    * Must be unique within a router. Must be referenced by exactly one bgpPeer. Must comply with RFC1035.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#name ComputeRouterPeer#name}
    */
    readonly name: string;
}
export declare function computeRouterPeerMd5AuthenticationKeyToTerraform(struct?: ComputeRouterPeerMd5AuthenticationKeyOutputReference | ComputeRouterPeerMd5AuthenticationKey): any;
export declare function computeRouterPeerMd5AuthenticationKeyToHclTerraform(struct?: ComputeRouterPeerMd5AuthenticationKeyOutputReference | ComputeRouterPeerMd5AuthenticationKey): any;
export declare class ComputeRouterPeerMd5AuthenticationKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRouterPeerMd5AuthenticationKey | undefined;
    set internalValue(value: ComputeRouterPeerMd5AuthenticationKey | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface ComputeRouterPeerTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#create ComputeRouterPeer#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#delete ComputeRouterPeer#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#update ComputeRouterPeer#update}
    */
    readonly update?: string;
}
export declare function computeRouterPeerTimeoutsToTerraform(struct?: ComputeRouterPeerTimeouts | cdktn.IResolvable): any;
export declare function computeRouterPeerTimeoutsToHclTerraform(struct?: ComputeRouterPeerTimeouts | cdktn.IResolvable): any;
export declare class ComputeRouterPeerTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRouterPeerTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRouterPeerTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer google_compute_router_peer}
*/
export declare class ComputeRouterPeer extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_router_peer";
    /**
    * Generates CDKTN code for importing a ComputeRouterPeer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeRouterPeer to import
    * @param importFromId The id of the existing ComputeRouterPeer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeRouterPeer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_peer google_compute_router_peer} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeRouterPeerConfig
    */
    constructor(scope: Construct, id: string, config: ComputeRouterPeerConfig);
    private _advertiseMode?;
    get advertiseMode(): string;
    set advertiseMode(value: string);
    resetAdvertiseMode(): void;
    get advertiseModeInput(): string | undefined;
    private _advertisedGroups?;
    get advertisedGroups(): string[];
    set advertisedGroups(value: string[]);
    resetAdvertisedGroups(): void;
    get advertisedGroupsInput(): string[] | undefined;
    private _advertisedRoutePriority?;
    get advertisedRoutePriority(): number;
    set advertisedRoutePriority(value: number);
    resetAdvertisedRoutePriority(): void;
    get advertisedRoutePriorityInput(): number | undefined;
    private _customLearnedRoutePriority?;
    get customLearnedRoutePriority(): number;
    set customLearnedRoutePriority(value: number);
    resetCustomLearnedRoutePriority(): void;
    get customLearnedRoutePriorityInput(): number | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _enable?;
    get enable(): boolean | cdktn.IResolvable;
    set enable(value: boolean | cdktn.IResolvable);
    resetEnable(): void;
    get enableInput(): boolean | cdktn.IResolvable | undefined;
    private _enableIpv4?;
    get enableIpv4(): boolean | cdktn.IResolvable;
    set enableIpv4(value: boolean | cdktn.IResolvable);
    resetEnableIpv4(): void;
    get enableIpv4Input(): boolean | cdktn.IResolvable | undefined;
    private _enableIpv6?;
    get enableIpv6(): boolean | cdktn.IResolvable;
    set enableIpv6(value: boolean | cdktn.IResolvable);
    resetEnableIpv6(): void;
    get enableIpv6Input(): boolean | cdktn.IResolvable | undefined;
    private _exportPolicies?;
    get exportPolicies(): string[];
    set exportPolicies(value: string[]);
    resetExportPolicies(): void;
    get exportPoliciesInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _importPolicies?;
    get importPolicies(): string[];
    set importPolicies(value: string[]);
    resetImportPolicies(): void;
    get importPoliciesInput(): string[] | undefined;
    private _interface?;
    get interface(): string;
    set interface(value: string);
    get interfaceInput(): string | undefined;
    private _ipAddress?;
    get ipAddress(): string;
    set ipAddress(value: string);
    resetIpAddress(): void;
    get ipAddressInput(): string | undefined;
    private _ipv4NexthopAddress?;
    get ipv4NexthopAddress(): string;
    set ipv4NexthopAddress(value: string);
    resetIpv4NexthopAddress(): void;
    get ipv4NexthopAddressInput(): string | undefined;
    private _ipv6NexthopAddress?;
    get ipv6NexthopAddress(): string;
    set ipv6NexthopAddress(value: string);
    resetIpv6NexthopAddress(): void;
    get ipv6NexthopAddressInput(): string | undefined;
    get isAdvertisedRoutePrioritySet(): cdktn.IResolvable;
    get isCustomLearnedPrioritySet(): cdktn.IResolvable;
    get managementType(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _peerAsn?;
    get peerAsn(): number;
    set peerAsn(value: number);
    get peerAsnInput(): number | undefined;
    private _peerIpAddress?;
    get peerIpAddress(): string;
    set peerIpAddress(value: string);
    resetPeerIpAddress(): void;
    get peerIpAddressInput(): string | undefined;
    private _peerIpv4NexthopAddress?;
    get peerIpv4NexthopAddress(): string;
    set peerIpv4NexthopAddress(value: string);
    resetPeerIpv4NexthopAddress(): void;
    get peerIpv4NexthopAddressInput(): string | undefined;
    private _peerIpv6NexthopAddress?;
    get peerIpv6NexthopAddress(): string;
    set peerIpv6NexthopAddress(value: string);
    resetPeerIpv6NexthopAddress(): void;
    get peerIpv6NexthopAddressInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _router?;
    get router(): string;
    set router(value: string);
    get routerInput(): string | undefined;
    private _routerApplianceInstance?;
    get routerApplianceInstance(): string;
    set routerApplianceInstance(value: string);
    resetRouterApplianceInstance(): void;
    get routerApplianceInstanceInput(): string | undefined;
    private _zeroAdvertisedRoutePriority?;
    get zeroAdvertisedRoutePriority(): boolean | cdktn.IResolvable;
    set zeroAdvertisedRoutePriority(value: boolean | cdktn.IResolvable);
    resetZeroAdvertisedRoutePriority(): void;
    get zeroAdvertisedRoutePriorityInput(): boolean | cdktn.IResolvable | undefined;
    private _zeroCustomLearnedRoutePriority?;
    get zeroCustomLearnedRoutePriority(): boolean | cdktn.IResolvable;
    set zeroCustomLearnedRoutePriority(value: boolean | cdktn.IResolvable);
    resetZeroCustomLearnedRoutePriority(): void;
    get zeroCustomLearnedRoutePriorityInput(): boolean | cdktn.IResolvable | undefined;
    private _advertisedIpRanges;
    get advertisedIpRanges(): ComputeRouterPeerAdvertisedIpRangesList;
    putAdvertisedIpRanges(value: ComputeRouterPeerAdvertisedIpRanges[] | cdktn.IResolvable): void;
    resetAdvertisedIpRanges(): void;
    get advertisedIpRangesInput(): cdktn.IResolvable | ComputeRouterPeerAdvertisedIpRanges[] | undefined;
    private _bfd;
    get bfd(): ComputeRouterPeerBfdOutputReference;
    putBfd(value: ComputeRouterPeerBfd): void;
    resetBfd(): void;
    get bfdInput(): ComputeRouterPeerBfd | undefined;
    private _customLearnedIpRanges;
    get customLearnedIpRanges(): ComputeRouterPeerCustomLearnedIpRangesList;
    putCustomLearnedIpRanges(value: ComputeRouterPeerCustomLearnedIpRanges[] | cdktn.IResolvable): void;
    resetCustomLearnedIpRanges(): void;
    get customLearnedIpRangesInput(): cdktn.IResolvable | ComputeRouterPeerCustomLearnedIpRanges[] | undefined;
    private _md5AuthenticationKey;
    get md5AuthenticationKey(): ComputeRouterPeerMd5AuthenticationKeyOutputReference;
    putMd5AuthenticationKey(value: ComputeRouterPeerMd5AuthenticationKey): void;
    resetMd5AuthenticationKey(): void;
    get md5AuthenticationKeyInput(): ComputeRouterPeerMd5AuthenticationKey | undefined;
    private _timeouts;
    get timeouts(): ComputeRouterPeerTimeoutsOutputReference;
    putTimeouts(value: ComputeRouterPeerTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeRouterPeerTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
