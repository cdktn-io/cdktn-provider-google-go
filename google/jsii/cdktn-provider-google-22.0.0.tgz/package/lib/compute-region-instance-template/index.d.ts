/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeRegionInstanceTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether to allow sending and receiving of packets with non-matching source or destination IPs. This defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#can_ip_forward ComputeRegionInstanceTemplate#can_ip_forward}
    */
    readonly canIpForward?: boolean | cdktn.IResolvable;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#deletion_policy ComputeRegionInstanceTemplate#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * A brief description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#description ComputeRegionInstanceTemplate#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#id ComputeRegionInstanceTemplate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A description of the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#instance_description ComputeRegionInstanceTemplate#instance_description}
    */
    readonly instanceDescription?: string;
    /**
    * Action to be taken when a customer's encryption key is revoked. Supports "STOP" and "NONE", with "NONE" being the default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#key_revocation_action_type ComputeRegionInstanceTemplate#key_revocation_action_type}
    */
    readonly keyRevocationActionType?: string;
    /**
    * A set of key/value label pairs to assign to instances created from this template,
    *
    * 				**Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * 				Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#labels ComputeRegionInstanceTemplate#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The machine type to create. To create a machine with a custom type (such as extended memory), format the value like custom-VCPUS-MEM_IN_MB like custom-6-20480 for 6 vCPU and 20GB of RAM.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#machine_type ComputeRegionInstanceTemplate#machine_type}
    */
    readonly machineType: string;
    /**
    * Metadata key/value pairs to make available from within instances created from this template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#metadata ComputeRegionInstanceTemplate#metadata}
    */
    readonly metadata?: {
        [key: string]: string;
    };
    /**
    * An alternative to using the startup-script metadata key, mostly to match the compute_instance resource. This replaces the startup-script metadata key on the created instance and thus the two mechanisms are not allowed to be used simultaneously.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#metadata_startup_script ComputeRegionInstanceTemplate#metadata_startup_script}
    */
    readonly metadataStartupScript?: string;
    /**
    * Specifies a minimum CPU platform. Applicable values are the friendly names of CPU platforms, such as Intel Haswell or Intel Skylake.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#min_cpu_platform ComputeRegionInstanceTemplate#min_cpu_platform}
    */
    readonly minCpuPlatform?: string;
    /**
    * The name of the instance template. If you leave this blank, Terraform will auto-generate a unique name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#name ComputeRegionInstanceTemplate#name}
    */
    readonly name?: string;
    /**
    * Creates a unique name beginning with the specified prefix. Conflicts with name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#name_prefix ComputeRegionInstanceTemplate#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * The ID of the project in which the resource belongs. If it is not provided, the provider project is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#project ComputeRegionInstanceTemplate#project}
    */
    readonly project?: string;
    /**
    * The region in which the instance template is located. If it is not provided, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#region ComputeRegionInstanceTemplate#region}
    */
    readonly region?: string;
    /**
    * A map of resource manager tags.
    * 				Resource manager tag keys and values have the same definition as resource manager tags. Keys must be in the format tagKeys/{tag_key_id}, and values are in the format tagValues/456. The field is ignored (both PUT & PATCH) when empty.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#resource_manager_tags ComputeRegionInstanceTemplate#resource_manager_tags}
    */
    readonly resourceManagerTags?: {
        [key: string]: string;
    };
    /**
    * A list of self_links of resource policies to attach to the instance. Currently a max of 1 resource policy is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#resource_policies ComputeRegionInstanceTemplate#resource_policies}
    */
    readonly resourcePolicies?: string[];
    /**
    * Tags to attach to the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#tags ComputeRegionInstanceTemplate#tags}
    */
    readonly tags?: string[];
    /**
    * advanced_machine_features block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#advanced_machine_features ComputeRegionInstanceTemplate#advanced_machine_features}
    */
    readonly advancedMachineFeatures?: ComputeRegionInstanceTemplateAdvancedMachineFeatures;
    /**
    * confidential_instance_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#confidential_instance_config ComputeRegionInstanceTemplate#confidential_instance_config}
    */
    readonly confidentialInstanceConfig?: ComputeRegionInstanceTemplateConfidentialInstanceConfig;
    /**
    * disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#disk ComputeRegionInstanceTemplate#disk}
    */
    readonly disk: ComputeRegionInstanceTemplateDisk[] | cdktn.IResolvable;
    /**
    * guest_accelerator block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#guest_accelerator ComputeRegionInstanceTemplate#guest_accelerator}
    */
    readonly guestAccelerator?: ComputeRegionInstanceTemplateGuestAccelerator[] | cdktn.IResolvable;
    /**
    * network_interface block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#network_interface ComputeRegionInstanceTemplate#network_interface}
    */
    readonly networkInterface?: ComputeRegionInstanceTemplateNetworkInterface[] | cdktn.IResolvable;
    /**
    * network_performance_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#network_performance_config ComputeRegionInstanceTemplate#network_performance_config}
    */
    readonly networkPerformanceConfig?: ComputeRegionInstanceTemplateNetworkPerformanceConfig;
    /**
    * reservation_affinity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#reservation_affinity ComputeRegionInstanceTemplate#reservation_affinity}
    */
    readonly reservationAffinity?: ComputeRegionInstanceTemplateReservationAffinity;
    /**
    * scheduling block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#scheduling ComputeRegionInstanceTemplate#scheduling}
    */
    readonly scheduling?: ComputeRegionInstanceTemplateScheduling;
    /**
    * service_account block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#service_account ComputeRegionInstanceTemplate#service_account}
    */
    readonly serviceAccount?: ComputeRegionInstanceTemplateServiceAccount;
    /**
    * shielded_instance_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#shielded_instance_config ComputeRegionInstanceTemplate#shielded_instance_config}
    */
    readonly shieldedInstanceConfig?: ComputeRegionInstanceTemplateShieldedInstanceConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#timeouts ComputeRegionInstanceTemplate#timeouts}
    */
    readonly timeouts?: ComputeRegionInstanceTemplateTimeouts;
    /**
    * workload_identity_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#workload_identity_config ComputeRegionInstanceTemplate#workload_identity_config}
    */
    readonly workloadIdentityConfig?: ComputeRegionInstanceTemplateWorkloadIdentityConfig;
}
export interface ComputeRegionInstanceTemplateAdvancedMachineFeatures {
    /**
    * Whether to enable nested virtualization or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#enable_nested_virtualization ComputeRegionInstanceTemplate#enable_nested_virtualization}
    */
    readonly enableNestedVirtualization?: boolean | cdktn.IResolvable;
    /**
    * Whether to enable UEFI networking or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#enable_uefi_networking ComputeRegionInstanceTemplate#enable_uefi_networking}
    */
    readonly enableUefiNetworking?: boolean | cdktn.IResolvable;
    /**
    * The PMU is a hardware component within the CPU core that monitors how the processor runs code. Valid values for the level of PMU are "STANDARD", "ENHANCED", and "ARCHITECTURAL".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#performance_monitoring_unit ComputeRegionInstanceTemplate#performance_monitoring_unit}
    */
    readonly performanceMonitoringUnit?: string;
    /**
    * The number of threads per physical core. To disable simultaneous multithreading (SMT) set this to 1. If unset, the maximum number of threads supported per core by the underlying processor is assumed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#threads_per_core ComputeRegionInstanceTemplate#threads_per_core}
    */
    readonly threadsPerCore?: number;
    /**
    * Turbo frequency mode to use for the instance. Currently supported modes is "ALL_CORE_MAX".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#turbo_mode ComputeRegionInstanceTemplate#turbo_mode}
    */
    readonly turboMode?: string;
    /**
    * The number of physical cores to expose to an instance. Multiply by the number of threads per core to compute the total number of virtual CPUs to expose to the instance. If unset, the number of cores is inferred from the instance\'s nominal CPU count and the underlying platform\'s SMT width.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#visible_core_count ComputeRegionInstanceTemplate#visible_core_count}
    */
    readonly visibleCoreCount?: number;
}
export declare function computeRegionInstanceTemplateAdvancedMachineFeaturesToTerraform(struct?: ComputeRegionInstanceTemplateAdvancedMachineFeaturesOutputReference | ComputeRegionInstanceTemplateAdvancedMachineFeatures): any;
export declare function computeRegionInstanceTemplateAdvancedMachineFeaturesToHclTerraform(struct?: ComputeRegionInstanceTemplateAdvancedMachineFeaturesOutputReference | ComputeRegionInstanceTemplateAdvancedMachineFeatures): any;
export declare class ComputeRegionInstanceTemplateAdvancedMachineFeaturesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceTemplateAdvancedMachineFeatures | undefined;
    set internalValue(value: ComputeRegionInstanceTemplateAdvancedMachineFeatures | undefined);
    private _enableNestedVirtualization?;
    get enableNestedVirtualization(): boolean | cdktn.IResolvable;
    set enableNestedVirtualization(value: boolean | cdktn.IResolvable);
    resetEnableNestedVirtualization(): void;
    get enableNestedVirtualizationInput(): boolean | cdktn.IResolvable | undefined;
    private _enableUefiNetworking?;
    get enableUefiNetworking(): boolean | cdktn.IResolvable;
    set enableUefiNetworking(value: boolean | cdktn.IResolvable);
    resetEnableUefiNetworking(): void;
    get enableUefiNetworkingInput(): boolean | cdktn.IResolvable | undefined;
    private _performanceMonitoringUnit?;
    get performanceMonitoringUnit(): string;
    set performanceMonitoringUnit(value: string);
    resetPerformanceMonitoringUnit(): void;
    get performanceMonitoringUnitInput(): string | undefined;
    private _threadsPerCore?;
    get threadsPerCore(): number;
    set threadsPerCore(value: number);
    resetThreadsPerCore(): void;
    get threadsPerCoreInput(): number | undefined;
    private _turboMode?;
    get turboMode(): string;
    set turboMode(value: string);
    resetTurboMode(): void;
    get turboModeInput(): string | undefined;
    private _visibleCoreCount?;
    get visibleCoreCount(): number;
    set visibleCoreCount(value: number);
    resetVisibleCoreCount(): void;
    get visibleCoreCountInput(): number | undefined;
}
export interface ComputeRegionInstanceTemplateConfidentialInstanceConfig {
    /**
    *
    * 								The confidential computing technology the instance uses.
    * 								SEV is an AMD feature. TDX is an Intel feature. One of the following
    * 								values is required: SEV, SEV_SNP, TDX. If SEV_SNP, min_cpu_platform =
    * 								"AMD Milan" is currently required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#confidential_instance_type ComputeRegionInstanceTemplate#confidential_instance_type}
    */
    readonly confidentialInstanceType?: string;
    /**
    * Defines whether the instance should have confidential compute enabled. Field will be deprecated in a future release.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#enable_confidential_compute ComputeRegionInstanceTemplate#enable_confidential_compute}
    */
    readonly enableConfidentialCompute?: boolean | cdktn.IResolvable;
}
export declare function computeRegionInstanceTemplateConfidentialInstanceConfigToTerraform(struct?: ComputeRegionInstanceTemplateConfidentialInstanceConfigOutputReference | ComputeRegionInstanceTemplateConfidentialInstanceConfig): any;
export declare function computeRegionInstanceTemplateConfidentialInstanceConfigToHclTerraform(struct?: ComputeRegionInstanceTemplateConfidentialInstanceConfigOutputReference | ComputeRegionInstanceTemplateConfidentialInstanceConfig): any;
export declare class ComputeRegionInstanceTemplateConfidentialInstanceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceTemplateConfidentialInstanceConfig | undefined;
    set internalValue(value: ComputeRegionInstanceTemplateConfidentialInstanceConfig | undefined);
    private _confidentialInstanceType?;
    get confidentialInstanceType(): string;
    set confidentialInstanceType(value: string);
    resetConfidentialInstanceType(): void;
    get confidentialInstanceTypeInput(): string | undefined;
    private _enableConfidentialCompute?;
    get enableConfidentialCompute(): boolean | cdktn.IResolvable;
    set enableConfidentialCompute(value: boolean | cdktn.IResolvable);
    resetEnableConfidentialCompute(): void;
    get enableConfidentialComputeInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ComputeRegionInstanceTemplateDiskDiskEncryptionKey {
    /**
    * The self link of the encryption key that is stored in Google Cloud KMS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#kms_key_self_link ComputeRegionInstanceTemplate#kms_key_self_link}
    */
    readonly kmsKeySelfLink?: string;
    /**
    * The service account being used for the encryption request for the given KMS key. If absent, the Compute Engine default service account is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#kms_key_service_account ComputeRegionInstanceTemplate#kms_key_service_account}
    */
    readonly kmsKeyServiceAccount?: string;
}
export declare function computeRegionInstanceTemplateDiskDiskEncryptionKeyToTerraform(struct?: ComputeRegionInstanceTemplateDiskDiskEncryptionKeyOutputReference | ComputeRegionInstanceTemplateDiskDiskEncryptionKey): any;
export declare function computeRegionInstanceTemplateDiskDiskEncryptionKeyToHclTerraform(struct?: ComputeRegionInstanceTemplateDiskDiskEncryptionKeyOutputReference | ComputeRegionInstanceTemplateDiskDiskEncryptionKey): any;
export declare class ComputeRegionInstanceTemplateDiskDiskEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceTemplateDiskDiskEncryptionKey | undefined;
    set internalValue(value: ComputeRegionInstanceTemplateDiskDiskEncryptionKey | undefined);
    private _kmsKeySelfLink?;
    get kmsKeySelfLink(): string;
    set kmsKeySelfLink(value: string);
    resetKmsKeySelfLink(): void;
    get kmsKeySelfLinkInput(): string | undefined;
    private _kmsKeyServiceAccount?;
    get kmsKeyServiceAccount(): string;
    set kmsKeyServiceAccount(value: string);
    resetKmsKeyServiceAccount(): void;
    get kmsKeyServiceAccountInput(): string | undefined;
}
export interface ComputeRegionInstanceTemplateDiskSourceImageEncryptionKey {
    /**
    * The self link of the encryption key that is stored in
    * Google Cloud KMS. Only one of kms_key_self_link, rsa_encrypted_key and raw_key may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#kms_key_self_link ComputeRegionInstanceTemplate#kms_key_self_link}
    */
    readonly kmsKeySelfLink?: string;
    /**
    * The service account being used for the encryption
    * request for the given KMS key. If absent, the Compute
    * Engine default service account is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#kms_key_service_account ComputeRegionInstanceTemplate#kms_key_service_account}
    */
    readonly kmsKeyServiceAccount?: string;
    /**
    * Specifies a 256-bit customer-supplied encryption key, encoded in RFC 4648 base64 to either encrypt or decrypt this resource.  Only one of kms_key_self_link, rsa_encrypted_key and raw_key may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#raw_key ComputeRegionInstanceTemplate#raw_key}
    */
    readonly rawKey?: string;
    /**
    * Specifies an RFC 4648 base64 encoded, RSA-wrapped 2048-bit customer-supplied encryption key to either encrypt or decrypt this resource.  Only one of kms_key_self_link, rsa_encrypted_key and raw_key may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#rsa_encrypted_key ComputeRegionInstanceTemplate#rsa_encrypted_key}
    */
    readonly rsaEncryptedKey?: string;
}
export declare function computeRegionInstanceTemplateDiskSourceImageEncryptionKeyToTerraform(struct?: ComputeRegionInstanceTemplateDiskSourceImageEncryptionKeyOutputReference | ComputeRegionInstanceTemplateDiskSourceImageEncryptionKey): any;
export declare function computeRegionInstanceTemplateDiskSourceImageEncryptionKeyToHclTerraform(struct?: ComputeRegionInstanceTemplateDiskSourceImageEncryptionKeyOutputReference | ComputeRegionInstanceTemplateDiskSourceImageEncryptionKey): any;
export declare class ComputeRegionInstanceTemplateDiskSourceImageEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceTemplateDiskSourceImageEncryptionKey | undefined;
    set internalValue(value: ComputeRegionInstanceTemplateDiskSourceImageEncryptionKey | undefined);
    private _kmsKeySelfLink?;
    get kmsKeySelfLink(): string;
    set kmsKeySelfLink(value: string);
    resetKmsKeySelfLink(): void;
    get kmsKeySelfLinkInput(): string | undefined;
    private _kmsKeyServiceAccount?;
    get kmsKeyServiceAccount(): string;
    set kmsKeyServiceAccount(value: string);
    resetKmsKeyServiceAccount(): void;
    get kmsKeyServiceAccountInput(): string | undefined;
    private _rawKey?;
    get rawKey(): string;
    set rawKey(value: string);
    resetRawKey(): void;
    get rawKeyInput(): string | undefined;
    private _rsaEncryptedKey?;
    get rsaEncryptedKey(): string;
    set rsaEncryptedKey(value: string);
    resetRsaEncryptedKey(): void;
    get rsaEncryptedKeyInput(): string | undefined;
}
export interface ComputeRegionInstanceTemplateDiskSourceSnapshotEncryptionKey {
    /**
    * The self link of the encryption key that is stored in
    * Google Cloud KMS. Only one of kms_key_self_link, rsa_encrypted_key and raw_key may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#kms_key_self_link ComputeRegionInstanceTemplate#kms_key_self_link}
    */
    readonly kmsKeySelfLink?: string;
    /**
    * The service account being used for the encryption
    * request for the given KMS key. If absent, the Compute
    * Engine default service account is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#kms_key_service_account ComputeRegionInstanceTemplate#kms_key_service_account}
    */
    readonly kmsKeyServiceAccount?: string;
    /**
    * Specifies a 256-bit customer-supplied encryption key, encoded in RFC 4648 base64 to either encrypt or decrypt this resource. Only one of kms_key_self_link, rsa_encrypted_key and raw_key may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#raw_key ComputeRegionInstanceTemplate#raw_key}
    */
    readonly rawKey?: string;
    /**
    * Specifies an RFC 4648 base64 encoded, RSA-wrapped 2048-bit customer-supplied encryption key to either encrypt or decrypt this resource.  Only one of kms_key_self_link, rsa_encrypted_key and raw_key may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#rsa_encrypted_key ComputeRegionInstanceTemplate#rsa_encrypted_key}
    */
    readonly rsaEncryptedKey?: string;
}
export declare function computeRegionInstanceTemplateDiskSourceSnapshotEncryptionKeyToTerraform(struct?: ComputeRegionInstanceTemplateDiskSourceSnapshotEncryptionKeyOutputReference | ComputeRegionInstanceTemplateDiskSourceSnapshotEncryptionKey): any;
export declare function computeRegionInstanceTemplateDiskSourceSnapshotEncryptionKeyToHclTerraform(struct?: ComputeRegionInstanceTemplateDiskSourceSnapshotEncryptionKeyOutputReference | ComputeRegionInstanceTemplateDiskSourceSnapshotEncryptionKey): any;
export declare class ComputeRegionInstanceTemplateDiskSourceSnapshotEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceTemplateDiskSourceSnapshotEncryptionKey | undefined;
    set internalValue(value: ComputeRegionInstanceTemplateDiskSourceSnapshotEncryptionKey | undefined);
    private _kmsKeySelfLink?;
    get kmsKeySelfLink(): string;
    set kmsKeySelfLink(value: string);
    resetKmsKeySelfLink(): void;
    get kmsKeySelfLinkInput(): string | undefined;
    private _kmsKeyServiceAccount?;
    get kmsKeyServiceAccount(): string;
    set kmsKeyServiceAccount(value: string);
    resetKmsKeyServiceAccount(): void;
    get kmsKeyServiceAccountInput(): string | undefined;
    private _rawKey?;
    get rawKey(): string;
    set rawKey(value: string);
    resetRawKey(): void;
    get rawKeyInput(): string | undefined;
    private _rsaEncryptedKey?;
    get rsaEncryptedKey(): string;
    set rsaEncryptedKey(value: string);
    resetRsaEncryptedKey(): void;
    get rsaEncryptedKeyInput(): string | undefined;
}
export interface ComputeRegionInstanceTemplateDisk {
    /**
    * The architecture of the image. Allowed values are ARM64 or X86_64.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#architecture ComputeRegionInstanceTemplate#architecture}
    */
    readonly architecture?: string;
    /**
    * Whether or not the disk should be auto-deleted. This defaults to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#auto_delete ComputeRegionInstanceTemplate#auto_delete}
    */
    readonly autoDelete?: boolean | cdktn.IResolvable;
    /**
    * Indicates that this is a boot disk.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#boot ComputeRegionInstanceTemplate#boot}
    */
    readonly boot?: boolean | cdktn.IResolvable;
    /**
    * A unique device name that is reflected into the /dev/ tree of a Linux operating system running within the instance. If not specified, the server chooses a default device name to apply to this disk.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#device_name ComputeRegionInstanceTemplate#device_name}
    */
    readonly deviceName?: string;
    /**
    * Name of the disk. When not provided, this defaults to the name of the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#disk_name ComputeRegionInstanceTemplate#disk_name}
    */
    readonly diskName?: string;
    /**
    * The size of the image in gigabytes. If not specified, it will inherit the size of its base image. For SCRATCH disks, the size must be one of 375, 3000, 3500, 7000 or 14000 GB, with a default of 375 GB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#disk_size_gb ComputeRegionInstanceTemplate#disk_size_gb}
    */
    readonly diskSizeGb?: number;
    /**
    * The Google Compute Engine disk type. Such as "pd-ssd", "local-ssd", "pd-balanced" or "pd-standard".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#disk_type ComputeRegionInstanceTemplate#disk_type}
    */
    readonly diskType?: string;
    /**
    * A list of features to enable on the guest operating system. Applicable only for bootable images.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#guest_os_features ComputeRegionInstanceTemplate#guest_os_features}
    */
    readonly guestOsFeatures?: string[];
    /**
    * Specifies the disk interface to use for attaching this disk.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#interface ComputeRegionInstanceTemplate#interface}
    */
    readonly interface?: string;
    /**
    * A set of key/value label pairs to assign to disks,
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#labels ComputeRegionInstanceTemplate#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The mode in which to attach this disk, either READ_WRITE or READ_ONLY. If you are attaching or creating a boot disk, this must read-write mode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#mode ComputeRegionInstanceTemplate#mode}
    */
    readonly mode?: string;
    /**
    * Indicates how many IOPS to provision for the disk. This sets the number of I/O operations per second that the disk can handle. For more details, see the [Extreme persistent disk documentation](https://cloud.google.com/compute/docs/disks/extreme-persistent-disk) or the [Hyperdisk documentation](https://cloud.google.com/compute/docs/disks/hyperdisks) depending on the selected disk_type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#provisioned_iops ComputeRegionInstanceTemplate#provisioned_iops}
    */
    readonly provisionedIops?: number;
    /**
    * Indicates how much throughput to provision for the disk, in MB/s. This sets the amount of data that can be read or written from the disk per second. Values must greater than or equal to 1. For more details, see the [Hyperdisk documentation](https://cloud.google.com/compute/docs/disks/hyperdisks).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#provisioned_throughput ComputeRegionInstanceTemplate#provisioned_throughput}
    */
    readonly provisionedThroughput?: number;
    /**
    * A map of resource manager tags. Resource manager tag keys and values have the same definition as resource manager tags. Keys must be in the format tagKeys/{tag_key_id}, and values are in the format tagValues/456. The field is ignored (both PUT & PATCH) when empty.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#resource_manager_tags ComputeRegionInstanceTemplate#resource_manager_tags}
    */
    readonly resourceManagerTags?: {
        [key: string]: string;
    };
    /**
    * A list (short name or id) of resource policies to attach to this disk. Currently a max of 1 resource policy is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#resource_policies ComputeRegionInstanceTemplate#resource_policies}
    */
    readonly resourcePolicies?: string[];
    /**
    * The name (not self_link) of the disk (such as those managed by google_compute_disk) to attach. ~> Note: Either source or source_image is required when creating a new instance except for when creating a local SSD.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#source ComputeRegionInstanceTemplate#source}
    */
    readonly source?: string;
    /**
    * The image from which to initialize this disk. This can be one of: the image's self_link, projects/{project}/global/images/{image}, projects/{project}/global/images/family/{family}, global/images/{image}, global/images/family/{family}, family/{family}, {project}/{family}, {project}/{image}, {family}, or {image}. ~> Note: Either source or source_image is required when creating a new instance except for when creating a local SSD.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#source_image ComputeRegionInstanceTemplate#source_image}
    */
    readonly sourceImage?: string;
    /**
    * The source snapshot to create this disk. When creating
    * a new instance, one of initializeParams.sourceSnapshot,
    * initializeParams.sourceImage, or disks.source is
    * required except for local SSD.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#source_snapshot ComputeRegionInstanceTemplate#source_snapshot}
    */
    readonly sourceSnapshot?: string;
    /**
    * The self_link or ID of the Storage Pool to create this disk in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#storage_pool ComputeRegionInstanceTemplate#storage_pool}
    */
    readonly storagePool?: string;
    /**
    * The type of Google Compute Engine disk, can be either "SCRATCH" or "PERSISTENT".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#type ComputeRegionInstanceTemplate#type}
    */
    readonly type?: string;
    /**
    * disk_encryption_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#disk_encryption_key ComputeRegionInstanceTemplate#disk_encryption_key}
    */
    readonly diskEncryptionKey?: ComputeRegionInstanceTemplateDiskDiskEncryptionKey;
    /**
    * source_image_encryption_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#source_image_encryption_key ComputeRegionInstanceTemplate#source_image_encryption_key}
    */
    readonly sourceImageEncryptionKey?: ComputeRegionInstanceTemplateDiskSourceImageEncryptionKey;
    /**
    * source_snapshot_encryption_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#source_snapshot_encryption_key ComputeRegionInstanceTemplate#source_snapshot_encryption_key}
    */
    readonly sourceSnapshotEncryptionKey?: ComputeRegionInstanceTemplateDiskSourceSnapshotEncryptionKey;
}
export declare function computeRegionInstanceTemplateDiskToTerraform(struct?: ComputeRegionInstanceTemplateDisk | cdktn.IResolvable): any;
export declare function computeRegionInstanceTemplateDiskToHclTerraform(struct?: ComputeRegionInstanceTemplateDisk | cdktn.IResolvable): any;
export declare class ComputeRegionInstanceTemplateDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionInstanceTemplateDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionInstanceTemplateDisk | cdktn.IResolvable | undefined);
    private _architecture?;
    get architecture(): string;
    set architecture(value: string);
    resetArchitecture(): void;
    get architectureInput(): string | undefined;
    private _autoDelete?;
    get autoDelete(): boolean | cdktn.IResolvable;
    set autoDelete(value: boolean | cdktn.IResolvable);
    resetAutoDelete(): void;
    get autoDeleteInput(): boolean | cdktn.IResolvable | undefined;
    private _boot?;
    get boot(): boolean | cdktn.IResolvable;
    set boot(value: boolean | cdktn.IResolvable);
    resetBoot(): void;
    get bootInput(): boolean | cdktn.IResolvable | undefined;
    private _deviceName?;
    get deviceName(): string;
    set deviceName(value: string);
    resetDeviceName(): void;
    get deviceNameInput(): string | undefined;
    private _diskName?;
    get diskName(): string;
    set diskName(value: string);
    resetDiskName(): void;
    get diskNameInput(): string | undefined;
    private _diskSizeGb?;
    get diskSizeGb(): number;
    set diskSizeGb(value: number);
    resetDiskSizeGb(): void;
    get diskSizeGbInput(): number | undefined;
    private _diskType?;
    get diskType(): string;
    set diskType(value: string);
    resetDiskType(): void;
    get diskTypeInput(): string | undefined;
    private _guestOsFeatures?;
    get guestOsFeatures(): string[];
    set guestOsFeatures(value: string[]);
    resetGuestOsFeatures(): void;
    get guestOsFeaturesInput(): string[] | undefined;
    private _interface?;
    get interface(): string;
    set interface(value: string);
    resetInterface(): void;
    get interfaceInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _provisionedIops?;
    get provisionedIops(): number;
    set provisionedIops(value: number);
    resetProvisionedIops(): void;
    get provisionedIopsInput(): number | undefined;
    private _provisionedThroughput?;
    get provisionedThroughput(): number;
    set provisionedThroughput(value: number);
    resetProvisionedThroughput(): void;
    get provisionedThroughputInput(): number | undefined;
    private _resourceManagerTags?;
    get resourceManagerTags(): {
        [key: string]: string;
    };
    set resourceManagerTags(value: {
        [key: string]: string;
    });
    resetResourceManagerTags(): void;
    get resourceManagerTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _resourcePolicies?;
    get resourcePolicies(): string[];
    set resourcePolicies(value: string[]);
    resetResourcePolicies(): void;
    get resourcePoliciesInput(): string[] | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _sourceImage?;
    get sourceImage(): string;
    set sourceImage(value: string);
    resetSourceImage(): void;
    get sourceImageInput(): string | undefined;
    private _sourceSnapshot?;
    get sourceSnapshot(): string;
    set sourceSnapshot(value: string);
    resetSourceSnapshot(): void;
    get sourceSnapshotInput(): string | undefined;
    private _storagePool?;
    get storagePool(): string;
    set storagePool(value: string);
    resetStoragePool(): void;
    get storagePoolInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _diskEncryptionKey;
    get diskEncryptionKey(): ComputeRegionInstanceTemplateDiskDiskEncryptionKeyOutputReference;
    putDiskEncryptionKey(value: ComputeRegionInstanceTemplateDiskDiskEncryptionKey): void;
    resetDiskEncryptionKey(): void;
    get diskEncryptionKeyInput(): ComputeRegionInstanceTemplateDiskDiskEncryptionKey | undefined;
    private _sourceImageEncryptionKey;
    get sourceImageEncryptionKey(): ComputeRegionInstanceTemplateDiskSourceImageEncryptionKeyOutputReference;
    putSourceImageEncryptionKey(value: ComputeRegionInstanceTemplateDiskSourceImageEncryptionKey): void;
    resetSourceImageEncryptionKey(): void;
    get sourceImageEncryptionKeyInput(): ComputeRegionInstanceTemplateDiskSourceImageEncryptionKey | undefined;
    private _sourceSnapshotEncryptionKey;
    get sourceSnapshotEncryptionKey(): ComputeRegionInstanceTemplateDiskSourceSnapshotEncryptionKeyOutputReference;
    putSourceSnapshotEncryptionKey(value: ComputeRegionInstanceTemplateDiskSourceSnapshotEncryptionKey): void;
    resetSourceSnapshotEncryptionKey(): void;
    get sourceSnapshotEncryptionKeyInput(): ComputeRegionInstanceTemplateDiskSourceSnapshotEncryptionKey | undefined;
}
export declare class ComputeRegionInstanceTemplateDiskList extends cdktn.ComplexList {
    internalValue?: ComputeRegionInstanceTemplateDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionInstanceTemplateDiskOutputReference;
}
export interface ComputeRegionInstanceTemplateGuestAccelerator {
    /**
    * The number of the guest accelerator cards exposed to this instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#count ComputeRegionInstanceTemplate#count}
    */
    readonly count: number;
    /**
    * The accelerator type resource to expose to this instance. E.g. nvidia-tesla-k80.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#type ComputeRegionInstanceTemplate#type}
    */
    readonly type: string;
}
export declare function computeRegionInstanceTemplateGuestAcceleratorToTerraform(struct?: ComputeRegionInstanceTemplateGuestAccelerator | cdktn.IResolvable): any;
export declare function computeRegionInstanceTemplateGuestAcceleratorToHclTerraform(struct?: ComputeRegionInstanceTemplateGuestAccelerator | cdktn.IResolvable): any;
export declare class ComputeRegionInstanceTemplateGuestAcceleratorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionInstanceTemplateGuestAccelerator | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionInstanceTemplateGuestAccelerator | cdktn.IResolvable | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    get countInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class ComputeRegionInstanceTemplateGuestAcceleratorList extends cdktn.ComplexList {
    internalValue?: ComputeRegionInstanceTemplateGuestAccelerator[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionInstanceTemplateGuestAcceleratorOutputReference;
}
export interface ComputeRegionInstanceTemplateNetworkInterfaceAccessConfig {
    /**
    * The IP address that will be 1:1 mapped to the instance's network ip. If not given, one will be generated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#nat_ip ComputeRegionInstanceTemplate#nat_ip}
    */
    readonly natIp?: string;
    /**
    * The networking tier used for configuring this instance template. This field can take the following values: PREMIUM, STANDARD, FIXED_STANDARD. If this field is not specified, it is assumed to be PREMIUM.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#network_tier ComputeRegionInstanceTemplate#network_tier}
    */
    readonly networkTier?: string;
}
export declare function computeRegionInstanceTemplateNetworkInterfaceAccessConfigToTerraform(struct?: ComputeRegionInstanceTemplateNetworkInterfaceAccessConfig | cdktn.IResolvable): any;
export declare function computeRegionInstanceTemplateNetworkInterfaceAccessConfigToHclTerraform(struct?: ComputeRegionInstanceTemplateNetworkInterfaceAccessConfig | cdktn.IResolvable): any;
export declare class ComputeRegionInstanceTemplateNetworkInterfaceAccessConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionInstanceTemplateNetworkInterfaceAccessConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionInstanceTemplateNetworkInterfaceAccessConfig | cdktn.IResolvable | undefined);
    private _natIp?;
    get natIp(): string;
    set natIp(value: string);
    resetNatIp(): void;
    get natIpInput(): string | undefined;
    private _networkTier?;
    get networkTier(): string;
    set networkTier(value: string);
    resetNetworkTier(): void;
    get networkTierInput(): string | undefined;
    get publicPtrDomainName(): string;
}
export declare class ComputeRegionInstanceTemplateNetworkInterfaceAccessConfigList extends cdktn.ComplexList {
    internalValue?: ComputeRegionInstanceTemplateNetworkInterfaceAccessConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionInstanceTemplateNetworkInterfaceAccessConfigOutputReference;
}
export interface ComputeRegionInstanceTemplateNetworkInterfaceAliasIpRange {
    /**
    * The IP CIDR range represented by this alias IP range. This IP CIDR range must belong to the specified subnetwork and cannot contain IP addresses reserved by system or used by other network interfaces. At the time of writing only a netmask (e.g. /24) may be supplied, with a CIDR format resulting in an API error.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#ip_cidr_range ComputeRegionInstanceTemplate#ip_cidr_range}
    */
    readonly ipCidrRange: string;
    /**
    * The subnetwork secondary range name specifying the secondary range from which to allocate the IP CIDR range for this alias IP range. If left unspecified, the primary range of the subnetwork will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#subnetwork_range_name ComputeRegionInstanceTemplate#subnetwork_range_name}
    */
    readonly subnetworkRangeName?: string;
}
export declare function computeRegionInstanceTemplateNetworkInterfaceAliasIpRangeToTerraform(struct?: ComputeRegionInstanceTemplateNetworkInterfaceAliasIpRange | cdktn.IResolvable): any;
export declare function computeRegionInstanceTemplateNetworkInterfaceAliasIpRangeToHclTerraform(struct?: ComputeRegionInstanceTemplateNetworkInterfaceAliasIpRange | cdktn.IResolvable): any;
export declare class ComputeRegionInstanceTemplateNetworkInterfaceAliasIpRangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionInstanceTemplateNetworkInterfaceAliasIpRange | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionInstanceTemplateNetworkInterfaceAliasIpRange | cdktn.IResolvable | undefined);
    private _ipCidrRange?;
    get ipCidrRange(): string;
    set ipCidrRange(value: string);
    get ipCidrRangeInput(): string | undefined;
    private _subnetworkRangeName?;
    get subnetworkRangeName(): string;
    set subnetworkRangeName(value: string);
    resetSubnetworkRangeName(): void;
    get subnetworkRangeNameInput(): string | undefined;
}
export declare class ComputeRegionInstanceTemplateNetworkInterfaceAliasIpRangeList extends cdktn.ComplexList {
    internalValue?: ComputeRegionInstanceTemplateNetworkInterfaceAliasIpRange[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionInstanceTemplateNetworkInterfaceAliasIpRangeOutputReference;
}
export interface ComputeRegionInstanceTemplateNetworkInterfaceIpv6AccessConfig {
    /**
    * The service-level to be provided for IPv6 traffic when the subnet has an external subnet. Only PREMIUM tier is valid for IPv6
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#network_tier ComputeRegionInstanceTemplate#network_tier}
    */
    readonly networkTier: string;
}
export declare function computeRegionInstanceTemplateNetworkInterfaceIpv6AccessConfigToTerraform(struct?: ComputeRegionInstanceTemplateNetworkInterfaceIpv6AccessConfig | cdktn.IResolvable): any;
export declare function computeRegionInstanceTemplateNetworkInterfaceIpv6AccessConfigToHclTerraform(struct?: ComputeRegionInstanceTemplateNetworkInterfaceIpv6AccessConfig | cdktn.IResolvable): any;
export declare class ComputeRegionInstanceTemplateNetworkInterfaceIpv6AccessConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionInstanceTemplateNetworkInterfaceIpv6AccessConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionInstanceTemplateNetworkInterfaceIpv6AccessConfig | cdktn.IResolvable | undefined);
    get externalIpv6(): string;
    get externalIpv6PrefixLength(): string;
    get name(): string;
    private _networkTier?;
    get networkTier(): string;
    set networkTier(value: string);
    get networkTierInput(): string | undefined;
    get publicPtrDomainName(): string;
}
export declare class ComputeRegionInstanceTemplateNetworkInterfaceIpv6AccessConfigList extends cdktn.ComplexList {
    internalValue?: ComputeRegionInstanceTemplateNetworkInterfaceIpv6AccessConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionInstanceTemplateNetworkInterfaceIpv6AccessConfigOutputReference;
}
export interface ComputeRegionInstanceTemplateNetworkInterface {
    /**
    * If true, DNS resolution will be enabled over this interface. Only valid with network_attachment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#enable_vpc_scoped_dns ComputeRegionInstanceTemplate#enable_vpc_scoped_dns}
    */
    readonly enableVpcScopedDns?: boolean | cdktn.IResolvable;
    /**
    * Indicates whether igmp query is enabled on the network interface or not. If enabled, also indicates the version of IGMP supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#igmp_query ComputeRegionInstanceTemplate#igmp_query}
    */
    readonly igmpQuery?: string;
    /**
    * The prefix length of the primary internal IPv6 range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#internal_ipv6_prefix_length ComputeRegionInstanceTemplate#internal_ipv6_prefix_length}
    */
    readonly internalIpv6PrefixLength?: number;
    /**
    * An IPv6 internal network address for this network interface. If not specified, Google Cloud will automatically assign an internal IPv6 address from the instance's subnetwork.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#ipv6_address ComputeRegionInstanceTemplate#ipv6_address}
    */
    readonly ipv6Address?: string;
    /**
    * The name or self_link of the network to attach this interface to. Use network attribute for Legacy or Auto subnetted networks and subnetwork for custom subnetted networks.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#network ComputeRegionInstanceTemplate#network}
    */
    readonly network?: string;
    /**
    * The URL of the network attachment that this interface should connect to in the following format: projects/{projectNumber}/regions/{region_name}/networkAttachments/{network_attachment_name}.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#network_attachment ComputeRegionInstanceTemplate#network_attachment}
    */
    readonly networkAttachment?: string;
    /**
    * The private IP address to assign to the instance. If empty, the address will be automatically assigned.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#network_ip ComputeRegionInstanceTemplate#network_ip}
    */
    readonly networkIp?: string;
    /**
    * The type of vNIC to be used on this interface. Possible values:GVNIC, VIRTIO_NET, MRDMA, IRDMA and IDPF
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#nic_type ComputeRegionInstanceTemplate#nic_type}
    */
    readonly nicType?: string;
    /**
    * The networking queue count that's specified by users for the network interface. Both Rx and Tx queues will be set to this number. It will be empty if not specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#queue_count ComputeRegionInstanceTemplate#queue_count}
    */
    readonly queueCount?: number;
    /**
    * Producer Service's Service class Id for the region of this network interface. Can only be used with network_attachment. It is not possible to use on its own; however, network_attachment can be used without service_class_id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#service_class_id ComputeRegionInstanceTemplate#service_class_id}
    */
    readonly serviceClassId?: string;
    /**
    * The stack type for this network interface to identify whether the IPv6 feature is enabled or not. If not specified, IPV4_ONLY will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#stack_type ComputeRegionInstanceTemplate#stack_type}
    */
    readonly stackType?: string;
    /**
    * The name of the subnetwork to attach this interface to. The subnetwork must exist in the same region this instance will be created in. Either network or subnetwork must be provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#subnetwork ComputeRegionInstanceTemplate#subnetwork}
    */
    readonly subnetwork?: string;
    /**
    * The ID of the project in which the subnetwork belongs. If it is not provided, the provider project is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#subnetwork_project ComputeRegionInstanceTemplate#subnetwork_project}
    */
    readonly subnetworkProject?: string;
    /**
    * VLAN tag of a dynamic network interface, must be an integer in the range from 2 to 255 inclusively.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#vlan ComputeRegionInstanceTemplate#vlan}
    */
    readonly vlan?: number;
    /**
    * access_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#access_config ComputeRegionInstanceTemplate#access_config}
    */
    readonly accessConfig?: ComputeRegionInstanceTemplateNetworkInterfaceAccessConfig[] | cdktn.IResolvable;
    /**
    * alias_ip_range block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#alias_ip_range ComputeRegionInstanceTemplate#alias_ip_range}
    */
    readonly aliasIpRange?: ComputeRegionInstanceTemplateNetworkInterfaceAliasIpRange[] | cdktn.IResolvable;
    /**
    * ipv6_access_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#ipv6_access_config ComputeRegionInstanceTemplate#ipv6_access_config}
    */
    readonly ipv6AccessConfig?: ComputeRegionInstanceTemplateNetworkInterfaceIpv6AccessConfig[] | cdktn.IResolvable;
}
export declare function computeRegionInstanceTemplateNetworkInterfaceToTerraform(struct?: ComputeRegionInstanceTemplateNetworkInterface | cdktn.IResolvable): any;
export declare function computeRegionInstanceTemplateNetworkInterfaceToHclTerraform(struct?: ComputeRegionInstanceTemplateNetworkInterface | cdktn.IResolvable): any;
export declare class ComputeRegionInstanceTemplateNetworkInterfaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionInstanceTemplateNetworkInterface | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionInstanceTemplateNetworkInterface | cdktn.IResolvable | undefined);
    private _enableVpcScopedDns?;
    get enableVpcScopedDns(): boolean | cdktn.IResolvable;
    set enableVpcScopedDns(value: boolean | cdktn.IResolvable);
    resetEnableVpcScopedDns(): void;
    get enableVpcScopedDnsInput(): boolean | cdktn.IResolvable | undefined;
    private _igmpQuery?;
    get igmpQuery(): string;
    set igmpQuery(value: string);
    resetIgmpQuery(): void;
    get igmpQueryInput(): string | undefined;
    private _internalIpv6PrefixLength?;
    get internalIpv6PrefixLength(): number;
    set internalIpv6PrefixLength(value: number);
    resetInternalIpv6PrefixLength(): void;
    get internalIpv6PrefixLengthInput(): number | undefined;
    get ipv6AccessType(): string;
    private _ipv6Address?;
    get ipv6Address(): string;
    set ipv6Address(value: string);
    resetIpv6Address(): void;
    get ipv6AddressInput(): string | undefined;
    get name(): string;
    private _network?;
    get network(): string;
    set network(value: string);
    resetNetwork(): void;
    get networkInput(): string | undefined;
    private _networkAttachment?;
    get networkAttachment(): string;
    set networkAttachment(value: string);
    resetNetworkAttachment(): void;
    get networkAttachmentInput(): string | undefined;
    private _networkIp?;
    get networkIp(): string;
    set networkIp(value: string);
    resetNetworkIp(): void;
    get networkIpInput(): string | undefined;
    private _nicType?;
    get nicType(): string;
    set nicType(value: string);
    resetNicType(): void;
    get nicTypeInput(): string | undefined;
    get parentNicName(): string;
    private _queueCount?;
    get queueCount(): number;
    set queueCount(value: number);
    resetQueueCount(): void;
    get queueCountInput(): number | undefined;
    private _serviceClassId?;
    get serviceClassId(): string;
    set serviceClassId(value: string);
    resetServiceClassId(): void;
    get serviceClassIdInput(): string | undefined;
    private _stackType?;
    get stackType(): string;
    set stackType(value: string);
    resetStackType(): void;
    get stackTypeInput(): string | undefined;
    private _subnetwork?;
    get subnetwork(): string;
    set subnetwork(value: string);
    resetSubnetwork(): void;
    get subnetworkInput(): string | undefined;
    private _subnetworkProject?;
    get subnetworkProject(): string;
    set subnetworkProject(value: string);
    resetSubnetworkProject(): void;
    get subnetworkProjectInput(): string | undefined;
    private _vlan?;
    get vlan(): number;
    set vlan(value: number);
    resetVlan(): void;
    get vlanInput(): number | undefined;
    private _accessConfig;
    get accessConfig(): ComputeRegionInstanceTemplateNetworkInterfaceAccessConfigList;
    putAccessConfig(value: ComputeRegionInstanceTemplateNetworkInterfaceAccessConfig[] | cdktn.IResolvable): void;
    resetAccessConfig(): void;
    get accessConfigInput(): cdktn.IResolvable | ComputeRegionInstanceTemplateNetworkInterfaceAccessConfig[] | undefined;
    private _aliasIpRange;
    get aliasIpRange(): ComputeRegionInstanceTemplateNetworkInterfaceAliasIpRangeList;
    putAliasIpRange(value: ComputeRegionInstanceTemplateNetworkInterfaceAliasIpRange[] | cdktn.IResolvable): void;
    resetAliasIpRange(): void;
    get aliasIpRangeInput(): cdktn.IResolvable | ComputeRegionInstanceTemplateNetworkInterfaceAliasIpRange[] | undefined;
    private _ipv6AccessConfig;
    get ipv6AccessConfig(): ComputeRegionInstanceTemplateNetworkInterfaceIpv6AccessConfigList;
    putIpv6AccessConfig(value: ComputeRegionInstanceTemplateNetworkInterfaceIpv6AccessConfig[] | cdktn.IResolvable): void;
    resetIpv6AccessConfig(): void;
    get ipv6AccessConfigInput(): cdktn.IResolvable | ComputeRegionInstanceTemplateNetworkInterfaceIpv6AccessConfig[] | undefined;
}
export declare class ComputeRegionInstanceTemplateNetworkInterfaceList extends cdktn.ComplexList {
    internalValue?: ComputeRegionInstanceTemplateNetworkInterface[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionInstanceTemplateNetworkInterfaceOutputReference;
}
export interface ComputeRegionInstanceTemplateNetworkPerformanceConfig {
    /**
    * The egress bandwidth tier to enable. Possible values:TIER_1, DEFAULT
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#total_egress_bandwidth_tier ComputeRegionInstanceTemplate#total_egress_bandwidth_tier}
    */
    readonly totalEgressBandwidthTier: string;
}
export declare function computeRegionInstanceTemplateNetworkPerformanceConfigToTerraform(struct?: ComputeRegionInstanceTemplateNetworkPerformanceConfigOutputReference | ComputeRegionInstanceTemplateNetworkPerformanceConfig): any;
export declare function computeRegionInstanceTemplateNetworkPerformanceConfigToHclTerraform(struct?: ComputeRegionInstanceTemplateNetworkPerformanceConfigOutputReference | ComputeRegionInstanceTemplateNetworkPerformanceConfig): any;
export declare class ComputeRegionInstanceTemplateNetworkPerformanceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceTemplateNetworkPerformanceConfig | undefined;
    set internalValue(value: ComputeRegionInstanceTemplateNetworkPerformanceConfig | undefined);
    private _totalEgressBandwidthTier?;
    get totalEgressBandwidthTier(): string;
    set totalEgressBandwidthTier(value: string);
    get totalEgressBandwidthTierInput(): string | undefined;
}
export interface ComputeRegionInstanceTemplateReservationAffinitySpecificReservation {
    /**
    * Corresponds to the label key of a reservation resource. To target a SPECIFIC_RESERVATION by name, specify compute.googleapis.com/reservation-name as the key and specify the name of your reservation as the only value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#key ComputeRegionInstanceTemplate#key}
    */
    readonly key: string;
    /**
    * Corresponds to the label values of a reservation resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#values ComputeRegionInstanceTemplate#values}
    */
    readonly values: string[];
}
export declare function computeRegionInstanceTemplateReservationAffinitySpecificReservationToTerraform(struct?: ComputeRegionInstanceTemplateReservationAffinitySpecificReservationOutputReference | ComputeRegionInstanceTemplateReservationAffinitySpecificReservation): any;
export declare function computeRegionInstanceTemplateReservationAffinitySpecificReservationToHclTerraform(struct?: ComputeRegionInstanceTemplateReservationAffinitySpecificReservationOutputReference | ComputeRegionInstanceTemplateReservationAffinitySpecificReservation): any;
export declare class ComputeRegionInstanceTemplateReservationAffinitySpecificReservationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceTemplateReservationAffinitySpecificReservation | undefined;
    set internalValue(value: ComputeRegionInstanceTemplateReservationAffinitySpecificReservation | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export interface ComputeRegionInstanceTemplateReservationAffinity {
    /**
    * The type of reservation from which this instance can consume resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#type ComputeRegionInstanceTemplate#type}
    */
    readonly type: string;
    /**
    * specific_reservation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#specific_reservation ComputeRegionInstanceTemplate#specific_reservation}
    */
    readonly specificReservation?: ComputeRegionInstanceTemplateReservationAffinitySpecificReservation;
}
export declare function computeRegionInstanceTemplateReservationAffinityToTerraform(struct?: ComputeRegionInstanceTemplateReservationAffinityOutputReference | ComputeRegionInstanceTemplateReservationAffinity): any;
export declare function computeRegionInstanceTemplateReservationAffinityToHclTerraform(struct?: ComputeRegionInstanceTemplateReservationAffinityOutputReference | ComputeRegionInstanceTemplateReservationAffinity): any;
export declare class ComputeRegionInstanceTemplateReservationAffinityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceTemplateReservationAffinity | undefined;
    set internalValue(value: ComputeRegionInstanceTemplateReservationAffinity | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _specificReservation;
    get specificReservation(): ComputeRegionInstanceTemplateReservationAffinitySpecificReservationOutputReference;
    putSpecificReservation(value: ComputeRegionInstanceTemplateReservationAffinitySpecificReservation): void;
    resetSpecificReservation(): void;
    get specificReservationInput(): ComputeRegionInstanceTemplateReservationAffinitySpecificReservation | undefined;
}
export interface ComputeRegionInstanceTemplateSchedulingLocalSsdRecoveryTimeout {
    /**
    * Span of time that's a fraction of a second at nanosecond
    * resolution. Durations less than one second are represented
    * with a 0 seconds field and a positive nanos field. Must
    * be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#nanos ComputeRegionInstanceTemplate#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second.
    * Must be from 0 to 315,576,000,000 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#seconds ComputeRegionInstanceTemplate#seconds}
    */
    readonly seconds: number;
}
export declare function computeRegionInstanceTemplateSchedulingLocalSsdRecoveryTimeoutToTerraform(struct?: ComputeRegionInstanceTemplateSchedulingLocalSsdRecoveryTimeout | cdktn.IResolvable): any;
export declare function computeRegionInstanceTemplateSchedulingLocalSsdRecoveryTimeoutToHclTerraform(struct?: ComputeRegionInstanceTemplateSchedulingLocalSsdRecoveryTimeout | cdktn.IResolvable): any;
export declare class ComputeRegionInstanceTemplateSchedulingLocalSsdRecoveryTimeoutOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionInstanceTemplateSchedulingLocalSsdRecoveryTimeout | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionInstanceTemplateSchedulingLocalSsdRecoveryTimeout | cdktn.IResolvable | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): number;
    set seconds(value: number);
    get secondsInput(): number | undefined;
}
export declare class ComputeRegionInstanceTemplateSchedulingLocalSsdRecoveryTimeoutList extends cdktn.ComplexList {
    internalValue?: ComputeRegionInstanceTemplateSchedulingLocalSsdRecoveryTimeout[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionInstanceTemplateSchedulingLocalSsdRecoveryTimeoutOutputReference;
}
export interface ComputeRegionInstanceTemplateSchedulingMaxRunDuration {
    /**
    * Span of time that's a fraction of a second at nanosecond
    * resolution. Durations less than one second are represented
    * with a 0 seconds field and a positive nanos field. Must
    * be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#nanos ComputeRegionInstanceTemplate#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second.
    * Must be from 0 to 315,576,000,000 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#seconds ComputeRegionInstanceTemplate#seconds}
    */
    readonly seconds: number;
}
export declare function computeRegionInstanceTemplateSchedulingMaxRunDurationToTerraform(struct?: ComputeRegionInstanceTemplateSchedulingMaxRunDurationOutputReference | ComputeRegionInstanceTemplateSchedulingMaxRunDuration): any;
export declare function computeRegionInstanceTemplateSchedulingMaxRunDurationToHclTerraform(struct?: ComputeRegionInstanceTemplateSchedulingMaxRunDurationOutputReference | ComputeRegionInstanceTemplateSchedulingMaxRunDuration): any;
export declare class ComputeRegionInstanceTemplateSchedulingMaxRunDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceTemplateSchedulingMaxRunDuration | undefined;
    set internalValue(value: ComputeRegionInstanceTemplateSchedulingMaxRunDuration | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): number;
    set seconds(value: number);
    get secondsInput(): number | undefined;
}
export interface ComputeRegionInstanceTemplateSchedulingNodeAffinities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#key ComputeRegionInstanceTemplate#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#operator ComputeRegionInstanceTemplate#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#values ComputeRegionInstanceTemplate#values}
    */
    readonly values: string[];
}
export declare function computeRegionInstanceTemplateSchedulingNodeAffinitiesToTerraform(struct?: ComputeRegionInstanceTemplateSchedulingNodeAffinities | cdktn.IResolvable): any;
export declare function computeRegionInstanceTemplateSchedulingNodeAffinitiesToHclTerraform(struct?: ComputeRegionInstanceTemplateSchedulingNodeAffinities | cdktn.IResolvable): any;
export declare class ComputeRegionInstanceTemplateSchedulingNodeAffinitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionInstanceTemplateSchedulingNodeAffinities | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionInstanceTemplateSchedulingNodeAffinities | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class ComputeRegionInstanceTemplateSchedulingNodeAffinitiesList extends cdktn.ComplexList {
    internalValue?: ComputeRegionInstanceTemplateSchedulingNodeAffinities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionInstanceTemplateSchedulingNodeAffinitiesOutputReference;
}
export interface ComputeRegionInstanceTemplateSchedulingOnInstanceStopAction {
    /**
    * If true, the contents of any attached Local SSD disks will be discarded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#discard_local_ssd ComputeRegionInstanceTemplate#discard_local_ssd}
    */
    readonly discardLocalSsd?: boolean | cdktn.IResolvable;
}
export declare function computeRegionInstanceTemplateSchedulingOnInstanceStopActionToTerraform(struct?: ComputeRegionInstanceTemplateSchedulingOnInstanceStopActionOutputReference | ComputeRegionInstanceTemplateSchedulingOnInstanceStopAction): any;
export declare function computeRegionInstanceTemplateSchedulingOnInstanceStopActionToHclTerraform(struct?: ComputeRegionInstanceTemplateSchedulingOnInstanceStopActionOutputReference | ComputeRegionInstanceTemplateSchedulingOnInstanceStopAction): any;
export declare class ComputeRegionInstanceTemplateSchedulingOnInstanceStopActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceTemplateSchedulingOnInstanceStopAction | undefined;
    set internalValue(value: ComputeRegionInstanceTemplateSchedulingOnInstanceStopAction | undefined);
    private _discardLocalSsd?;
    get discardLocalSsd(): boolean | cdktn.IResolvable;
    set discardLocalSsd(value: boolean | cdktn.IResolvable);
    resetDiscardLocalSsd(): void;
    get discardLocalSsdInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ComputeRegionInstanceTemplateSchedulingPreemptionNoticeDuration {
    /**
    * Span of time that's a fraction of a second at nanosecond resolution. Durations less than one second are represented with a 0 seconds field and a positive nanos field. Must be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#nanos ComputeRegionInstanceTemplate#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second. Must be from 0 to 315,576,000,000 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#seconds ComputeRegionInstanceTemplate#seconds}
    */
    readonly seconds: number;
}
export declare function computeRegionInstanceTemplateSchedulingPreemptionNoticeDurationToTerraform(struct?: ComputeRegionInstanceTemplateSchedulingPreemptionNoticeDurationOutputReference | ComputeRegionInstanceTemplateSchedulingPreemptionNoticeDuration): any;
export declare function computeRegionInstanceTemplateSchedulingPreemptionNoticeDurationToHclTerraform(struct?: ComputeRegionInstanceTemplateSchedulingPreemptionNoticeDurationOutputReference | ComputeRegionInstanceTemplateSchedulingPreemptionNoticeDuration): any;
export declare class ComputeRegionInstanceTemplateSchedulingPreemptionNoticeDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceTemplateSchedulingPreemptionNoticeDuration | undefined;
    set internalValue(value: ComputeRegionInstanceTemplateSchedulingPreemptionNoticeDuration | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): number;
    set seconds(value: number);
    get secondsInput(): number | undefined;
}
export interface ComputeRegionInstanceTemplateScheduling {
    /**
    * Specifies whether the instance should be automatically restarted if it is terminated by Compute Engine (not terminated by a user). This defaults to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#automatic_restart ComputeRegionInstanceTemplate#automatic_restart}
    */
    readonly automaticRestart?: boolean | cdktn.IResolvable;
    /**
    * Specifies the availability domain, which this instance should be scheduled on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#availability_domain ComputeRegionInstanceTemplate#availability_domain}
    */
    readonly availabilityDomain?: number;
    /**
    * Specify the time in seconds for host error detection, the value must be within the range of [90, 330] with the increment of 30, if unset, the default behavior of host error recovery will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#host_error_timeout_seconds ComputeRegionInstanceTemplate#host_error_timeout_seconds}
    */
    readonly hostErrorTimeoutSeconds?: number;
    /**
    * Specifies the action GCE should take when SPOT VM is preempted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#instance_termination_action ComputeRegionInstanceTemplate#instance_termination_action}
    */
    readonly instanceTerminationAction?: string;
    /**
    * Minimum number of cpus for the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#min_node_cpus ComputeRegionInstanceTemplate#min_node_cpus}
    */
    readonly minNodeCpus?: number;
    /**
    * Defines the maintenance behavior for this instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#on_host_maintenance ComputeRegionInstanceTemplate#on_host_maintenance}
    */
    readonly onHostMaintenance?: string;
    /**
    * Allows instance to be preempted. This defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#preemptible ComputeRegionInstanceTemplate#preemptible}
    */
    readonly preemptible?: boolean | cdktn.IResolvable;
    /**
    * Describes the desired provisioning model for the instance. Possible values are STANDARD, SPOT, FLEX_START, and RESERVATION_BOUND. For STANDARD, resources are provisioned immediately. For SPOT, resources are offered at a discount compared to standard pricing but may be preempted. For FLEX_START, resources are offered at a discount with flexible start times. For RESERVATION_BOUND, the instance is bound to a specific reservation and will only consume capacity from that reservation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#provisioning_model ComputeRegionInstanceTemplate#provisioning_model}
    */
    readonly provisioningModel?: string;
    /**
    * Specifies the timestamp, when the instance will be terminated,
    * in RFC3339 text format. If specified, the instance termination action
    * will be performed at the termination time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#termination_time ComputeRegionInstanceTemplate#termination_time}
    */
    readonly terminationTime?: string;
    /**
    * local_ssd_recovery_timeout block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#local_ssd_recovery_timeout ComputeRegionInstanceTemplate#local_ssd_recovery_timeout}
    */
    readonly localSsdRecoveryTimeout?: ComputeRegionInstanceTemplateSchedulingLocalSsdRecoveryTimeout[] | cdktn.IResolvable;
    /**
    * max_run_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#max_run_duration ComputeRegionInstanceTemplate#max_run_duration}
    */
    readonly maxRunDuration?: ComputeRegionInstanceTemplateSchedulingMaxRunDuration;
    /**
    * node_affinities block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#node_affinities ComputeRegionInstanceTemplate#node_affinities}
    */
    readonly nodeAffinities?: ComputeRegionInstanceTemplateSchedulingNodeAffinities[] | cdktn.IResolvable;
    /**
    * on_instance_stop_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#on_instance_stop_action ComputeRegionInstanceTemplate#on_instance_stop_action}
    */
    readonly onInstanceStopAction?: ComputeRegionInstanceTemplateSchedulingOnInstanceStopAction;
    /**
    * preemption_notice_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#preemption_notice_duration ComputeRegionInstanceTemplate#preemption_notice_duration}
    */
    readonly preemptionNoticeDuration?: ComputeRegionInstanceTemplateSchedulingPreemptionNoticeDuration;
}
export declare function computeRegionInstanceTemplateSchedulingToTerraform(struct?: ComputeRegionInstanceTemplateSchedulingOutputReference | ComputeRegionInstanceTemplateScheduling): any;
export declare function computeRegionInstanceTemplateSchedulingToHclTerraform(struct?: ComputeRegionInstanceTemplateSchedulingOutputReference | ComputeRegionInstanceTemplateScheduling): any;
export declare class ComputeRegionInstanceTemplateSchedulingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceTemplateScheduling | undefined;
    set internalValue(value: ComputeRegionInstanceTemplateScheduling | undefined);
    private _automaticRestart?;
    get automaticRestart(): boolean | cdktn.IResolvable;
    set automaticRestart(value: boolean | cdktn.IResolvable);
    resetAutomaticRestart(): void;
    get automaticRestartInput(): boolean | cdktn.IResolvable | undefined;
    private _availabilityDomain?;
    get availabilityDomain(): number;
    set availabilityDomain(value: number);
    resetAvailabilityDomain(): void;
    get availabilityDomainInput(): number | undefined;
    private _hostErrorTimeoutSeconds?;
    get hostErrorTimeoutSeconds(): number;
    set hostErrorTimeoutSeconds(value: number);
    resetHostErrorTimeoutSeconds(): void;
    get hostErrorTimeoutSecondsInput(): number | undefined;
    private _instanceTerminationAction?;
    get instanceTerminationAction(): string;
    set instanceTerminationAction(value: string);
    resetInstanceTerminationAction(): void;
    get instanceTerminationActionInput(): string | undefined;
    private _minNodeCpus?;
    get minNodeCpus(): number;
    set minNodeCpus(value: number);
    resetMinNodeCpus(): void;
    get minNodeCpusInput(): number | undefined;
    private _onHostMaintenance?;
    get onHostMaintenance(): string;
    set onHostMaintenance(value: string);
    resetOnHostMaintenance(): void;
    get onHostMaintenanceInput(): string | undefined;
    private _preemptible?;
    get preemptible(): boolean | cdktn.IResolvable;
    set preemptible(value: boolean | cdktn.IResolvable);
    resetPreemptible(): void;
    get preemptibleInput(): boolean | cdktn.IResolvable | undefined;
    private _provisioningModel?;
    get provisioningModel(): string;
    set provisioningModel(value: string);
    resetProvisioningModel(): void;
    get provisioningModelInput(): string | undefined;
    private _terminationTime?;
    get terminationTime(): string;
    set terminationTime(value: string);
    resetTerminationTime(): void;
    get terminationTimeInput(): string | undefined;
    private _localSsdRecoveryTimeout;
    get localSsdRecoveryTimeout(): ComputeRegionInstanceTemplateSchedulingLocalSsdRecoveryTimeoutList;
    putLocalSsdRecoveryTimeout(value: ComputeRegionInstanceTemplateSchedulingLocalSsdRecoveryTimeout[] | cdktn.IResolvable): void;
    resetLocalSsdRecoveryTimeout(): void;
    get localSsdRecoveryTimeoutInput(): cdktn.IResolvable | ComputeRegionInstanceTemplateSchedulingLocalSsdRecoveryTimeout[] | undefined;
    private _maxRunDuration;
    get maxRunDuration(): ComputeRegionInstanceTemplateSchedulingMaxRunDurationOutputReference;
    putMaxRunDuration(value: ComputeRegionInstanceTemplateSchedulingMaxRunDuration): void;
    resetMaxRunDuration(): void;
    get maxRunDurationInput(): ComputeRegionInstanceTemplateSchedulingMaxRunDuration | undefined;
    private _nodeAffinities;
    get nodeAffinities(): ComputeRegionInstanceTemplateSchedulingNodeAffinitiesList;
    putNodeAffinities(value: ComputeRegionInstanceTemplateSchedulingNodeAffinities[] | cdktn.IResolvable): void;
    resetNodeAffinities(): void;
    get nodeAffinitiesInput(): cdktn.IResolvable | ComputeRegionInstanceTemplateSchedulingNodeAffinities[] | undefined;
    private _onInstanceStopAction;
    get onInstanceStopAction(): ComputeRegionInstanceTemplateSchedulingOnInstanceStopActionOutputReference;
    putOnInstanceStopAction(value: ComputeRegionInstanceTemplateSchedulingOnInstanceStopAction): void;
    resetOnInstanceStopAction(): void;
    get onInstanceStopActionInput(): ComputeRegionInstanceTemplateSchedulingOnInstanceStopAction | undefined;
    private _preemptionNoticeDuration;
    get preemptionNoticeDuration(): ComputeRegionInstanceTemplateSchedulingPreemptionNoticeDurationOutputReference;
    putPreemptionNoticeDuration(value: ComputeRegionInstanceTemplateSchedulingPreemptionNoticeDuration): void;
    resetPreemptionNoticeDuration(): void;
    get preemptionNoticeDurationInput(): ComputeRegionInstanceTemplateSchedulingPreemptionNoticeDuration | undefined;
}
export interface ComputeRegionInstanceTemplateServiceAccount {
    /**
    * The service account e-mail address. If not given, the default Google Compute Engine service account is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#email ComputeRegionInstanceTemplate#email}
    */
    readonly email?: string;
    /**
    * A list of service scopes. Both OAuth2 URLs and gcloud short names are supported. To allow full access to all Cloud APIs, use the cloud-platform scope.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#scopes ComputeRegionInstanceTemplate#scopes}
    */
    readonly scopes: string[];
}
export declare function computeRegionInstanceTemplateServiceAccountToTerraform(struct?: ComputeRegionInstanceTemplateServiceAccountOutputReference | ComputeRegionInstanceTemplateServiceAccount): any;
export declare function computeRegionInstanceTemplateServiceAccountToHclTerraform(struct?: ComputeRegionInstanceTemplateServiceAccountOutputReference | ComputeRegionInstanceTemplateServiceAccount): any;
export declare class ComputeRegionInstanceTemplateServiceAccountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceTemplateServiceAccount | undefined;
    set internalValue(value: ComputeRegionInstanceTemplateServiceAccount | undefined);
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    get scopesInput(): string[] | undefined;
}
export interface ComputeRegionInstanceTemplateShieldedInstanceConfig {
    /**
    * Compare the most recent boot measurements to the integrity policy baseline and return a pair of pass/fail results depending on whether they match or not. Defaults to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#enable_integrity_monitoring ComputeRegionInstanceTemplate#enable_integrity_monitoring}
    */
    readonly enableIntegrityMonitoring?: boolean | cdktn.IResolvable;
    /**
    * Verify the digital signature of all boot components, and halt the boot process if signature verification fails. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#enable_secure_boot ComputeRegionInstanceTemplate#enable_secure_boot}
    */
    readonly enableSecureBoot?: boolean | cdktn.IResolvable;
    /**
    * Use a virtualized trusted platform module, which is a specialized computer chip you can use to encrypt objects like keys and certificates. Defaults to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#enable_vtpm ComputeRegionInstanceTemplate#enable_vtpm}
    */
    readonly enableVtpm?: boolean | cdktn.IResolvable;
}
export declare function computeRegionInstanceTemplateShieldedInstanceConfigToTerraform(struct?: ComputeRegionInstanceTemplateShieldedInstanceConfigOutputReference | ComputeRegionInstanceTemplateShieldedInstanceConfig): any;
export declare function computeRegionInstanceTemplateShieldedInstanceConfigToHclTerraform(struct?: ComputeRegionInstanceTemplateShieldedInstanceConfigOutputReference | ComputeRegionInstanceTemplateShieldedInstanceConfig): any;
export declare class ComputeRegionInstanceTemplateShieldedInstanceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceTemplateShieldedInstanceConfig | undefined;
    set internalValue(value: ComputeRegionInstanceTemplateShieldedInstanceConfig | undefined);
    private _enableIntegrityMonitoring?;
    get enableIntegrityMonitoring(): boolean | cdktn.IResolvable;
    set enableIntegrityMonitoring(value: boolean | cdktn.IResolvable);
    resetEnableIntegrityMonitoring(): void;
    get enableIntegrityMonitoringInput(): boolean | cdktn.IResolvable | undefined;
    private _enableSecureBoot?;
    get enableSecureBoot(): boolean | cdktn.IResolvable;
    set enableSecureBoot(value: boolean | cdktn.IResolvable);
    resetEnableSecureBoot(): void;
    get enableSecureBootInput(): boolean | cdktn.IResolvable | undefined;
    private _enableVtpm?;
    get enableVtpm(): boolean | cdktn.IResolvable;
    set enableVtpm(value: boolean | cdktn.IResolvable);
    resetEnableVtpm(): void;
    get enableVtpmInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ComputeRegionInstanceTemplateTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#create ComputeRegionInstanceTemplate#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#delete ComputeRegionInstanceTemplate#delete}
    */
    readonly delete?: string;
}
export declare function computeRegionInstanceTemplateTimeoutsToTerraform(struct?: ComputeRegionInstanceTemplateTimeouts | cdktn.IResolvable): any;
export declare function computeRegionInstanceTemplateTimeoutsToHclTerraform(struct?: ComputeRegionInstanceTemplateTimeouts | cdktn.IResolvable): any;
export declare class ComputeRegionInstanceTemplateTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceTemplateTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionInstanceTemplateTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
export interface ComputeRegionInstanceTemplateWorkloadIdentityConfig {
    /**
    * Identity SPIFFE id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#identity ComputeRegionInstanceTemplate#identity}
    */
    readonly identity?: string;
    /**
    * Specifies whether identity certificates are enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#identity_certificate_enabled ComputeRegionInstanceTemplate#identity_certificate_enabled}
    */
    readonly identityCertificateEnabled?: boolean | cdktn.IResolvable;
}
export declare function computeRegionInstanceTemplateWorkloadIdentityConfigToTerraform(struct?: ComputeRegionInstanceTemplateWorkloadIdentityConfigOutputReference | ComputeRegionInstanceTemplateWorkloadIdentityConfig): any;
export declare function computeRegionInstanceTemplateWorkloadIdentityConfigToHclTerraform(struct?: ComputeRegionInstanceTemplateWorkloadIdentityConfigOutputReference | ComputeRegionInstanceTemplateWorkloadIdentityConfig): any;
export declare class ComputeRegionInstanceTemplateWorkloadIdentityConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceTemplateWorkloadIdentityConfig | undefined;
    set internalValue(value: ComputeRegionInstanceTemplateWorkloadIdentityConfig | undefined);
    private _identity?;
    get identity(): string;
    set identity(value: string);
    resetIdentity(): void;
    get identityInput(): string | undefined;
    private _identityCertificateEnabled?;
    get identityCertificateEnabled(): boolean | cdktn.IResolvable;
    set identityCertificateEnabled(value: boolean | cdktn.IResolvable);
    resetIdentityCertificateEnabled(): void;
    get identityCertificateEnabledInput(): boolean | cdktn.IResolvable | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template google_compute_region_instance_template}
*/
export declare class ComputeRegionInstanceTemplate extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_region_instance_template";
    /**
    * Generates CDKTN code for importing a ComputeRegionInstanceTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeRegionInstanceTemplate to import
    * @param importFromId The id of the existing ComputeRegionInstanceTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeRegionInstanceTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_template google_compute_region_instance_template} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeRegionInstanceTemplateConfig
    */
    constructor(scope: Construct, id: string, config: ComputeRegionInstanceTemplateConfig);
    private _canIpForward?;
    get canIpForward(): boolean | cdktn.IResolvable;
    set canIpForward(value: boolean | cdktn.IResolvable);
    resetCanIpForward(): void;
    get canIpForwardInput(): boolean | cdktn.IResolvable | undefined;
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceDescription?;
    get instanceDescription(): string;
    set instanceDescription(value: string);
    resetInstanceDescription(): void;
    get instanceDescriptionInput(): string | undefined;
    private _keyRevocationActionType?;
    get keyRevocationActionType(): string;
    set keyRevocationActionType(value: string);
    resetKeyRevocationActionType(): void;
    get keyRevocationActionTypeInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _machineType?;
    get machineType(): string;
    set machineType(value: string);
    get machineTypeInput(): string | undefined;
    private _metadata?;
    get metadata(): {
        [key: string]: string;
    };
    set metadata(value: {
        [key: string]: string;
    });
    resetMetadata(): void;
    get metadataInput(): {
        [key: string]: string;
    } | undefined;
    get metadataFingerprint(): string;
    private _metadataStartupScript?;
    get metadataStartupScript(): string;
    set metadataStartupScript(value: string);
    resetMetadataStartupScript(): void;
    get metadataStartupScriptInput(): string | undefined;
    private _minCpuPlatform?;
    get minCpuPlatform(): string;
    set minCpuPlatform(value: string);
    resetMinCpuPlatform(): void;
    get minCpuPlatformInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    get numericId(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceManagerTags?;
    get resourceManagerTags(): {
        [key: string]: string;
    };
    set resourceManagerTags(value: {
        [key: string]: string;
    });
    resetResourceManagerTags(): void;
    get resourceManagerTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _resourcePolicies?;
    get resourcePolicies(): string[];
    set resourcePolicies(value: string[]);
    resetResourcePolicies(): void;
    get resourcePoliciesInput(): string[] | undefined;
    get selfLink(): string;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    get tagsFingerprint(): string;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _advancedMachineFeatures;
    get advancedMachineFeatures(): ComputeRegionInstanceTemplateAdvancedMachineFeaturesOutputReference;
    putAdvancedMachineFeatures(value: ComputeRegionInstanceTemplateAdvancedMachineFeatures): void;
    resetAdvancedMachineFeatures(): void;
    get advancedMachineFeaturesInput(): ComputeRegionInstanceTemplateAdvancedMachineFeatures | undefined;
    private _confidentialInstanceConfig;
    get confidentialInstanceConfig(): ComputeRegionInstanceTemplateConfidentialInstanceConfigOutputReference;
    putConfidentialInstanceConfig(value: ComputeRegionInstanceTemplateConfidentialInstanceConfig): void;
    resetConfidentialInstanceConfig(): void;
    get confidentialInstanceConfigInput(): ComputeRegionInstanceTemplateConfidentialInstanceConfig | undefined;
    private _disk;
    get disk(): ComputeRegionInstanceTemplateDiskList;
    putDisk(value: ComputeRegionInstanceTemplateDisk[] | cdktn.IResolvable): void;
    get diskInput(): cdktn.IResolvable | ComputeRegionInstanceTemplateDisk[] | undefined;
    private _guestAccelerator;
    get guestAccelerator(): ComputeRegionInstanceTemplateGuestAcceleratorList;
    putGuestAccelerator(value: ComputeRegionInstanceTemplateGuestAccelerator[] | cdktn.IResolvable): void;
    resetGuestAccelerator(): void;
    get guestAcceleratorInput(): cdktn.IResolvable | ComputeRegionInstanceTemplateGuestAccelerator[] | undefined;
    private _networkInterface;
    get networkInterface(): ComputeRegionInstanceTemplateNetworkInterfaceList;
    putNetworkInterface(value: ComputeRegionInstanceTemplateNetworkInterface[] | cdktn.IResolvable): void;
    resetNetworkInterface(): void;
    get networkInterfaceInput(): cdktn.IResolvable | ComputeRegionInstanceTemplateNetworkInterface[] | undefined;
    private _networkPerformanceConfig;
    get networkPerformanceConfig(): ComputeRegionInstanceTemplateNetworkPerformanceConfigOutputReference;
    putNetworkPerformanceConfig(value: ComputeRegionInstanceTemplateNetworkPerformanceConfig): void;
    resetNetworkPerformanceConfig(): void;
    get networkPerformanceConfigInput(): ComputeRegionInstanceTemplateNetworkPerformanceConfig | undefined;
    private _reservationAffinity;
    get reservationAffinity(): ComputeRegionInstanceTemplateReservationAffinityOutputReference;
    putReservationAffinity(value: ComputeRegionInstanceTemplateReservationAffinity): void;
    resetReservationAffinity(): void;
    get reservationAffinityInput(): ComputeRegionInstanceTemplateReservationAffinity | undefined;
    private _scheduling;
    get scheduling(): ComputeRegionInstanceTemplateSchedulingOutputReference;
    putScheduling(value: ComputeRegionInstanceTemplateScheduling): void;
    resetScheduling(): void;
    get schedulingInput(): ComputeRegionInstanceTemplateScheduling | undefined;
    private _serviceAccount;
    get serviceAccount(): ComputeRegionInstanceTemplateServiceAccountOutputReference;
    putServiceAccount(value: ComputeRegionInstanceTemplateServiceAccount): void;
    resetServiceAccount(): void;
    get serviceAccountInput(): ComputeRegionInstanceTemplateServiceAccount | undefined;
    private _shieldedInstanceConfig;
    get shieldedInstanceConfig(): ComputeRegionInstanceTemplateShieldedInstanceConfigOutputReference;
    putShieldedInstanceConfig(value: ComputeRegionInstanceTemplateShieldedInstanceConfig): void;
    resetShieldedInstanceConfig(): void;
    get shieldedInstanceConfigInput(): ComputeRegionInstanceTemplateShieldedInstanceConfig | undefined;
    private _timeouts;
    get timeouts(): ComputeRegionInstanceTemplateTimeoutsOutputReference;
    putTimeouts(value: ComputeRegionInstanceTemplateTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeRegionInstanceTemplateTimeouts | undefined;
    private _workloadIdentityConfig;
    get workloadIdentityConfig(): ComputeRegionInstanceTemplateWorkloadIdentityConfigOutputReference;
    putWorkloadIdentityConfig(value: ComputeRegionInstanceTemplateWorkloadIdentityConfig): void;
    resetWorkloadIdentityConfig(): void;
    get workloadIdentityConfigInput(): ComputeRegionInstanceTemplateWorkloadIdentityConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
