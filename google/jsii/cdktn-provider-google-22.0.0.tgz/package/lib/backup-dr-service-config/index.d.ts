/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BackupDrServiceConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_service_config#id BackupDrServiceConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location in which the Service config is to be initialized.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_service_config#location BackupDrServiceConfig#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_service_config#project BackupDrServiceConfig#project}
    */
    readonly project?: string;
    /**
    * The resource type to which the default service config will be applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_service_config#resource_type BackupDrServiceConfig#resource_type}
    */
    readonly resourceType: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_service_config#timeouts BackupDrServiceConfig#timeouts}
    */
    readonly timeouts?: BackupDrServiceConfigTimeouts;
}
export interface BackupDrServiceConfigTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_service_config#create BackupDrServiceConfig#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_service_config#delete BackupDrServiceConfig#delete}
    */
    readonly delete?: string;
}
export declare function backupDrServiceConfigTimeoutsToTerraform(struct?: BackupDrServiceConfigTimeouts | cdktn.IResolvable): any;
export declare function backupDrServiceConfigTimeoutsToHclTerraform(struct?: BackupDrServiceConfigTimeouts | cdktn.IResolvable): any;
export declare class BackupDrServiceConfigTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrServiceConfigTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BackupDrServiceConfigTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_service_config google_backup_dr_service_config}
*/
export declare class BackupDrServiceConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_backup_dr_service_config";
    /**
    * Generates CDKTN code for importing a BackupDrServiceConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BackupDrServiceConfig to import
    * @param importFromId The id of the existing BackupDrServiceConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_service_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BackupDrServiceConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_service_config google_backup_dr_service_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BackupDrServiceConfigConfig
    */
    constructor(scope: Construct, id: string, config: BackupDrServiceConfigConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    get resourceTypeInput(): string | undefined;
    private _timeouts;
    get timeouts(): BackupDrServiceConfigTimeoutsOutputReference;
    putTimeouts(value: BackupDrServiceConfigTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BackupDrServiceConfigTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
