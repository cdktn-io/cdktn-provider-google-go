/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeRegionSecurityPolicyRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Action to perform when the rule is matched. The following are the valid actions:
    *
    * * allow: allow access to target.
    *
    * * deny(STATUS): deny access to target, returns the HTTP response code specified. Valid values for STATUS are 403, 404, and 502.
    *
    * * rate_based_ban: limit client traffic to the configured threshold and ban the client if the traffic exceeds the threshold. Configure parameters for this action in RateLimitOptions. Requires rateLimitOptions to be set.
    *
    * * redirect: redirect to a different target. This can either be an internal reCAPTCHA redirect, or an external URL-based redirect via a 302 response. Parameters for this action can be configured via redirectOptions. This action is only supported in Global Security Policies of type CLOUD_ARMOR.
    *
    * * throttle: limit client traffic to the configured threshold. Configure parameters for this action in rateLimitOptions. Requires rateLimitOptions to be set for this.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#action ComputeRegionSecurityPolicyRule#action}
    */
    readonly action: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#deletion_policy ComputeRegionSecurityPolicyRule#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource. Provide this property when you create the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#description ComputeRegionSecurityPolicyRule#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#id ComputeRegionSecurityPolicyRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * If set to true, the specified action is not enforced.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#preview ComputeRegionSecurityPolicyRule#preview}
    */
    readonly preview?: boolean | cdktn.IResolvable;
    /**
    * An integer indicating the priority of a rule in the list.
    * The priority must be a positive value between 0 and 2147483647.
    * Rules are evaluated from highest to lowest priority where 0 is the highest priority and 2147483647 is the lowest priority.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#priority ComputeRegionSecurityPolicyRule#priority}
    */
    readonly priority: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#project ComputeRegionSecurityPolicyRule#project}
    */
    readonly project?: string;
    /**
    * The Region in which the created Region Security Policy rule should reside.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#region ComputeRegionSecurityPolicyRule#region}
    */
    readonly region: string;
    /**
    * The name of the security policy this rule belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#security_policy ComputeRegionSecurityPolicyRule#security_policy}
    */
    readonly securityPolicy: string;
    /**
    * match block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#match ComputeRegionSecurityPolicyRule#match}
    */
    readonly match?: ComputeRegionSecurityPolicyRuleMatch;
    /**
    * network_match block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#network_match ComputeRegionSecurityPolicyRule#network_match}
    */
    readonly networkMatch?: ComputeRegionSecurityPolicyRuleNetworkMatch;
    /**
    * preconfigured_waf_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#preconfigured_waf_config ComputeRegionSecurityPolicyRule#preconfigured_waf_config}
    */
    readonly preconfiguredWafConfig?: ComputeRegionSecurityPolicyRulePreconfiguredWafConfig;
    /**
    * rate_limit_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#rate_limit_options ComputeRegionSecurityPolicyRule#rate_limit_options}
    */
    readonly rateLimitOptions?: ComputeRegionSecurityPolicyRuleRateLimitOptions;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#timeouts ComputeRegionSecurityPolicyRule#timeouts}
    */
    readonly timeouts?: ComputeRegionSecurityPolicyRuleTimeouts;
}
export interface ComputeRegionSecurityPolicyRuleMatchConfig {
    /**
    * CIDR IP address range. Maximum number of srcIpRanges allowed is 10.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#src_ip_ranges ComputeRegionSecurityPolicyRule#src_ip_ranges}
    */
    readonly srcIpRanges?: string[];
}
export declare function computeRegionSecurityPolicyRuleMatchConfigToTerraform(struct?: ComputeRegionSecurityPolicyRuleMatchConfigOutputReference | ComputeRegionSecurityPolicyRuleMatchConfig): any;
export declare function computeRegionSecurityPolicyRuleMatchConfigToHclTerraform(struct?: ComputeRegionSecurityPolicyRuleMatchConfigOutputReference | ComputeRegionSecurityPolicyRuleMatchConfig): any;
export declare class ComputeRegionSecurityPolicyRuleMatchConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionSecurityPolicyRuleMatchConfig | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRuleMatchConfig | undefined);
    private _srcIpRanges?;
    get srcIpRanges(): string[];
    set srcIpRanges(value: string[]);
    resetSrcIpRanges(): void;
    get srcIpRangesInput(): string[] | undefined;
}
export interface ComputeRegionSecurityPolicyRuleMatchExpr {
    /**
    * Textual representation of an expression in Common Expression Language syntax. The application context of the containing message determines which well-known feature set of CEL is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#expression ComputeRegionSecurityPolicyRule#expression}
    */
    readonly expression: string;
}
export declare function computeRegionSecurityPolicyRuleMatchExprToTerraform(struct?: ComputeRegionSecurityPolicyRuleMatchExprOutputReference | ComputeRegionSecurityPolicyRuleMatchExpr): any;
export declare function computeRegionSecurityPolicyRuleMatchExprToHclTerraform(struct?: ComputeRegionSecurityPolicyRuleMatchExprOutputReference | ComputeRegionSecurityPolicyRuleMatchExpr): any;
export declare class ComputeRegionSecurityPolicyRuleMatchExprOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionSecurityPolicyRuleMatchExpr | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRuleMatchExpr | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
}
export interface ComputeRegionSecurityPolicyRuleMatch {
    /**
    * Preconfigured versioned expression. If this field is specified, config must also be specified.
    * Available preconfigured expressions along with their requirements are: SRC_IPS_V1 - must specify the corresponding srcIpRange field in config. Possible values: ["SRC_IPS_V1"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#versioned_expr ComputeRegionSecurityPolicyRule#versioned_expr}
    */
    readonly versionedExpr?: string;
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#config ComputeRegionSecurityPolicyRule#config}
    */
    readonly config?: ComputeRegionSecurityPolicyRuleMatchConfig;
    /**
    * expr block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#expr ComputeRegionSecurityPolicyRule#expr}
    */
    readonly expr?: ComputeRegionSecurityPolicyRuleMatchExpr;
}
export declare function computeRegionSecurityPolicyRuleMatchToTerraform(struct?: ComputeRegionSecurityPolicyRuleMatchOutputReference | ComputeRegionSecurityPolicyRuleMatch): any;
export declare function computeRegionSecurityPolicyRuleMatchToHclTerraform(struct?: ComputeRegionSecurityPolicyRuleMatchOutputReference | ComputeRegionSecurityPolicyRuleMatch): any;
export declare class ComputeRegionSecurityPolicyRuleMatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionSecurityPolicyRuleMatch | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRuleMatch | undefined);
    private _versionedExpr?;
    get versionedExpr(): string;
    set versionedExpr(value: string);
    resetVersionedExpr(): void;
    get versionedExprInput(): string | undefined;
    private _config;
    get config(): ComputeRegionSecurityPolicyRuleMatchConfigOutputReference;
    putConfig(value: ComputeRegionSecurityPolicyRuleMatchConfig): void;
    resetConfig(): void;
    get configInput(): ComputeRegionSecurityPolicyRuleMatchConfig | undefined;
    private _expr;
    get expr(): ComputeRegionSecurityPolicyRuleMatchExprOutputReference;
    putExpr(value: ComputeRegionSecurityPolicyRuleMatchExpr): void;
    resetExpr(): void;
    get exprInput(): ComputeRegionSecurityPolicyRuleMatchExpr | undefined;
}
export interface ComputeRegionSecurityPolicyRuleNetworkMatchUserDefinedFields {
    /**
    * Name of the user-defined field, as given in the definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#name ComputeRegionSecurityPolicyRule#name}
    */
    readonly name?: string;
    /**
    * Matching values of the field. Each element can be a 32-bit unsigned decimal or hexadecimal (starting with "0x") number (e.g. "64") or range (e.g. "0x400-0x7ff").
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#values ComputeRegionSecurityPolicyRule#values}
    */
    readonly values?: string[];
}
export declare function computeRegionSecurityPolicyRuleNetworkMatchUserDefinedFieldsToTerraform(struct?: ComputeRegionSecurityPolicyRuleNetworkMatchUserDefinedFields | cdktn.IResolvable): any;
export declare function computeRegionSecurityPolicyRuleNetworkMatchUserDefinedFieldsToHclTerraform(struct?: ComputeRegionSecurityPolicyRuleNetworkMatchUserDefinedFields | cdktn.IResolvable): any;
export declare class ComputeRegionSecurityPolicyRuleNetworkMatchUserDefinedFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionSecurityPolicyRuleNetworkMatchUserDefinedFields | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRuleNetworkMatchUserDefinedFields | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class ComputeRegionSecurityPolicyRuleNetworkMatchUserDefinedFieldsList extends cdktn.ComplexList {
    internalValue?: ComputeRegionSecurityPolicyRuleNetworkMatchUserDefinedFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionSecurityPolicyRuleNetworkMatchUserDefinedFieldsOutputReference;
}
export interface ComputeRegionSecurityPolicyRuleNetworkMatch {
    /**
    * Destination IPv4/IPv6 addresses or CIDR prefixes, in standard text format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#dest_ip_ranges ComputeRegionSecurityPolicyRule#dest_ip_ranges}
    */
    readonly destIpRanges?: string[];
    /**
    * Destination port numbers for TCP/UDP/SCTP. Each element can be a 16-bit unsigned decimal number (e.g. "80") or range (e.g. "0-1023").
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#dest_ports ComputeRegionSecurityPolicyRule#dest_ports}
    */
    readonly destPorts?: string[];
    /**
    * IPv4 protocol / IPv6 next header (after extension headers). Each element can be an 8-bit unsigned decimal number (e.g. "6"), range (e.g. "253-254"), or one of the following protocol names: "tcp", "udp", "icmp", "esp", "ah", "ipip", or "sctp".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#ip_protocols ComputeRegionSecurityPolicyRule#ip_protocols}
    */
    readonly ipProtocols?: string[];
    /**
    * BGP Autonomous System Number associated with the source IP address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#src_asns ComputeRegionSecurityPolicyRule#src_asns}
    */
    readonly srcAsns?: number[];
    /**
    * Source IPv4/IPv6 addresses or CIDR prefixes, in standard text format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#src_ip_ranges ComputeRegionSecurityPolicyRule#src_ip_ranges}
    */
    readonly srcIpRanges?: string[];
    /**
    * Source port numbers for TCP/UDP/SCTP. Each element can be a 16-bit unsigned decimal number (e.g. "80") or range (e.g. "0-1023").
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#src_ports ComputeRegionSecurityPolicyRule#src_ports}
    */
    readonly srcPorts?: string[];
    /**
    * Two-letter ISO 3166-1 alpha-2 country code associated with the source IP address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#src_region_codes ComputeRegionSecurityPolicyRule#src_region_codes}
    */
    readonly srcRegionCodes?: string[];
    /**
    * user_defined_fields block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#user_defined_fields ComputeRegionSecurityPolicyRule#user_defined_fields}
    */
    readonly userDefinedFields?: ComputeRegionSecurityPolicyRuleNetworkMatchUserDefinedFields[] | cdktn.IResolvable;
}
export declare function computeRegionSecurityPolicyRuleNetworkMatchToTerraform(struct?: ComputeRegionSecurityPolicyRuleNetworkMatchOutputReference | ComputeRegionSecurityPolicyRuleNetworkMatch): any;
export declare function computeRegionSecurityPolicyRuleNetworkMatchToHclTerraform(struct?: ComputeRegionSecurityPolicyRuleNetworkMatchOutputReference | ComputeRegionSecurityPolicyRuleNetworkMatch): any;
export declare class ComputeRegionSecurityPolicyRuleNetworkMatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionSecurityPolicyRuleNetworkMatch | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRuleNetworkMatch | undefined);
    private _destIpRanges?;
    get destIpRanges(): string[];
    set destIpRanges(value: string[]);
    resetDestIpRanges(): void;
    get destIpRangesInput(): string[] | undefined;
    private _destPorts?;
    get destPorts(): string[];
    set destPorts(value: string[]);
    resetDestPorts(): void;
    get destPortsInput(): string[] | undefined;
    private _ipProtocols?;
    get ipProtocols(): string[];
    set ipProtocols(value: string[]);
    resetIpProtocols(): void;
    get ipProtocolsInput(): string[] | undefined;
    private _srcAsns?;
    get srcAsns(): number[];
    set srcAsns(value: number[]);
    resetSrcAsns(): void;
    get srcAsnsInput(): number[] | undefined;
    private _srcIpRanges?;
    get srcIpRanges(): string[];
    set srcIpRanges(value: string[]);
    resetSrcIpRanges(): void;
    get srcIpRangesInput(): string[] | undefined;
    private _srcPorts?;
    get srcPorts(): string[];
    set srcPorts(value: string[]);
    resetSrcPorts(): void;
    get srcPortsInput(): string[] | undefined;
    private _srcRegionCodes?;
    get srcRegionCodes(): string[];
    set srcRegionCodes(value: string[]);
    resetSrcRegionCodes(): void;
    get srcRegionCodesInput(): string[] | undefined;
    private _userDefinedFields;
    get userDefinedFields(): ComputeRegionSecurityPolicyRuleNetworkMatchUserDefinedFieldsList;
    putUserDefinedFields(value: ComputeRegionSecurityPolicyRuleNetworkMatchUserDefinedFields[] | cdktn.IResolvable): void;
    resetUserDefinedFields(): void;
    get userDefinedFieldsInput(): cdktn.IResolvable | ComputeRegionSecurityPolicyRuleNetworkMatchUserDefinedFields[] | undefined;
}
export interface ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestBody {
    /**
    * You can specify an exact match or a partial match by using a field operator and a field value.
    * Available options:
    * EQUALS: The operator matches if the field value equals the specified value.
    * STARTS_WITH: The operator matches if the field value starts with the specified value.
    * ENDS_WITH: The operator matches if the field value ends with the specified value.
    * CONTAINS: The operator matches if the field value contains the specified value.
    * EQUALS_ANY: The operator matches if the field value is any value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#operator ComputeRegionSecurityPolicyRule#operator}
    */
    readonly operator: string;
    /**
    * A request field matching the specified value will be excluded from inspection during preconfigured WAF evaluation.
    * The field value must be given if the field operator is not EQUALS_ANY, and cannot be given if the field operator is EQUALS_ANY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#value ComputeRegionSecurityPolicyRule#value}
    */
    readonly value?: string;
}
export declare function computeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestBodyToTerraform(struct?: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestBody | cdktn.IResolvable): any;
export declare function computeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestBodyToHclTerraform(struct?: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestBody | cdktn.IResolvable): any;
export declare class ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestBodyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestBody | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestBody | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestBodyList extends cdktn.ComplexList {
    internalValue?: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestBody[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestBodyOutputReference;
}
export interface ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie {
    /**
    * You can specify an exact match or a partial match by using a field operator and a field value.
    * Available options:
    * EQUALS: The operator matches if the field value equals the specified value.
    * STARTS_WITH: The operator matches if the field value starts with the specified value.
    * ENDS_WITH: The operator matches if the field value ends with the specified value.
    * CONTAINS: The operator matches if the field value contains the specified value.
    * EQUALS_ANY: The operator matches if the field value is any value. Possible values: ["CONTAINS", "ENDS_WITH", "EQUALS", "EQUALS_ANY", "STARTS_WITH"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#operator ComputeRegionSecurityPolicyRule#operator}
    */
    readonly operator: string;
    /**
    * A request field matching the specified value will be excluded from inspection during preconfigured WAF evaluation.
    * The field value must be given if the field operator is not EQUALS_ANY, and cannot be given if the field operator is EQUALS_ANY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#value ComputeRegionSecurityPolicyRule#value}
    */
    readonly value?: string;
}
export declare function computeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieToTerraform(struct?: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie | cdktn.IResolvable): any;
export declare function computeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieToHclTerraform(struct?: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie | cdktn.IResolvable): any;
export declare class ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieList extends cdktn.ComplexList {
    internalValue?: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieOutputReference;
}
export interface ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader {
    /**
    * You can specify an exact match or a partial match by using a field operator and a field value.
    * Available options:
    * EQUALS: The operator matches if the field value equals the specified value.
    * STARTS_WITH: The operator matches if the field value starts with the specified value.
    * ENDS_WITH: The operator matches if the field value ends with the specified value.
    * CONTAINS: The operator matches if the field value contains the specified value.
    * EQUALS_ANY: The operator matches if the field value is any value. Possible values: ["CONTAINS", "ENDS_WITH", "EQUALS", "EQUALS_ANY", "STARTS_WITH"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#operator ComputeRegionSecurityPolicyRule#operator}
    */
    readonly operator: string;
    /**
    * A request field matching the specified value will be excluded from inspection during preconfigured WAF evaluation.
    * The field value must be given if the field operator is not EQUALS_ANY, and cannot be given if the field operator is EQUALS_ANY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#value ComputeRegionSecurityPolicyRule#value}
    */
    readonly value?: string;
}
export declare function computeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderToTerraform(struct?: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader | cdktn.IResolvable): any;
export declare function computeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderToHclTerraform(struct?: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader | cdktn.IResolvable): any;
export declare class ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderList extends cdktn.ComplexList {
    internalValue?: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderOutputReference;
}
export interface ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam {
    /**
    * You can specify an exact match or a partial match by using a field operator and a field value.
    * Available options:
    * EQUALS: The operator matches if the field value equals the specified value.
    * STARTS_WITH: The operator matches if the field value starts with the specified value.
    * ENDS_WITH: The operator matches if the field value ends with the specified value.
    * CONTAINS: The operator matches if the field value contains the specified value.
    * EQUALS_ANY: The operator matches if the field value is any value. Possible values: ["CONTAINS", "ENDS_WITH", "EQUALS", "EQUALS_ANY", "STARTS_WITH"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#operator ComputeRegionSecurityPolicyRule#operator}
    */
    readonly operator: string;
    /**
    * A request field matching the specified value will be excluded from inspection during preconfigured WAF evaluation.
    * The field value must be given if the field operator is not EQUALS_ANY, and cannot be given if the field operator is EQUALS_ANY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#value ComputeRegionSecurityPolicyRule#value}
    */
    readonly value?: string;
}
export declare function computeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamToTerraform(struct?: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam | cdktn.IResolvable): any;
export declare function computeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamToHclTerraform(struct?: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam | cdktn.IResolvable): any;
export declare class ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamList extends cdktn.ComplexList {
    internalValue?: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamOutputReference;
}
export interface ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri {
    /**
    * You can specify an exact match or a partial match by using a field operator and a field value.
    * Available options:
    * EQUALS: The operator matches if the field value equals the specified value.
    * STARTS_WITH: The operator matches if the field value starts with the specified value.
    * ENDS_WITH: The operator matches if the field value ends with the specified value.
    * CONTAINS: The operator matches if the field value contains the specified value.
    * EQUALS_ANY: The operator matches if the field value is any value. Possible values: ["CONTAINS", "ENDS_WITH", "EQUALS", "EQUALS_ANY", "STARTS_WITH"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#operator ComputeRegionSecurityPolicyRule#operator}
    */
    readonly operator: string;
    /**
    * A request field matching the specified value will be excluded from inspection during preconfigured WAF evaluation.
    * The field value must be given if the field operator is not EQUALS_ANY, and cannot be given if the field operator is EQUALS_ANY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#value ComputeRegionSecurityPolicyRule#value}
    */
    readonly value?: string;
}
export declare function computeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriToTerraform(struct?: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri | cdktn.IResolvable): any;
export declare function computeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriToHclTerraform(struct?: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri | cdktn.IResolvable): any;
export declare class ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriList extends cdktn.ComplexList {
    internalValue?: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriOutputReference;
}
export interface ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusion {
    /**
    * A list of target rule IDs under the WAF rule set to apply the preconfigured WAF exclusion.
    * If omitted, it refers to all the rule IDs under the WAF rule set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#target_rule_ids ComputeRegionSecurityPolicyRule#target_rule_ids}
    */
    readonly targetRuleIds?: string[];
    /**
    * Target WAF rule set to apply the preconfigured WAF exclusion.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#target_rule_set ComputeRegionSecurityPolicyRule#target_rule_set}
    */
    readonly targetRuleSet: string;
    /**
    * request_body block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#request_body ComputeRegionSecurityPolicyRule#request_body}
    */
    readonly requestBody?: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestBody[] | cdktn.IResolvable;
    /**
    * request_cookie block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#request_cookie ComputeRegionSecurityPolicyRule#request_cookie}
    */
    readonly requestCookie?: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie[] | cdktn.IResolvable;
    /**
    * request_header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#request_header ComputeRegionSecurityPolicyRule#request_header}
    */
    readonly requestHeader?: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader[] | cdktn.IResolvable;
    /**
    * request_query_param block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#request_query_param ComputeRegionSecurityPolicyRule#request_query_param}
    */
    readonly requestQueryParam?: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam[] | cdktn.IResolvable;
    /**
    * request_uri block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#request_uri ComputeRegionSecurityPolicyRule#request_uri}
    */
    readonly requestUri?: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri[] | cdktn.IResolvable;
}
export declare function computeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionToTerraform(struct?: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusion | cdktn.IResolvable): any;
export declare function computeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionToHclTerraform(struct?: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusion | cdktn.IResolvable): any;
export declare class ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusion | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusion | cdktn.IResolvable | undefined);
    private _targetRuleIds?;
    get targetRuleIds(): string[];
    set targetRuleIds(value: string[]);
    resetTargetRuleIds(): void;
    get targetRuleIdsInput(): string[] | undefined;
    private _targetRuleSet?;
    get targetRuleSet(): string;
    set targetRuleSet(value: string);
    get targetRuleSetInput(): string | undefined;
    private _requestBody;
    get requestBody(): ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestBodyList;
    putRequestBody(value: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestBody[] | cdktn.IResolvable): void;
    resetRequestBody(): void;
    get requestBodyInput(): cdktn.IResolvable | ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestBody[] | undefined;
    private _requestCookie;
    get requestCookie(): ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieList;
    putRequestCookie(value: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie[] | cdktn.IResolvable): void;
    resetRequestCookie(): void;
    get requestCookieInput(): cdktn.IResolvable | ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie[] | undefined;
    private _requestHeader;
    get requestHeader(): ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderList;
    putRequestHeader(value: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader[] | cdktn.IResolvable): void;
    resetRequestHeader(): void;
    get requestHeaderInput(): cdktn.IResolvable | ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader[] | undefined;
    private _requestQueryParam;
    get requestQueryParam(): ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamList;
    putRequestQueryParam(value: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam[] | cdktn.IResolvable): void;
    resetRequestQueryParam(): void;
    get requestQueryParamInput(): cdktn.IResolvable | ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam[] | undefined;
    private _requestUri;
    get requestUri(): ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriList;
    putRequestUri(value: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri[] | cdktn.IResolvable): void;
    resetRequestUri(): void;
    get requestUriInput(): cdktn.IResolvable | ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri[] | undefined;
}
export declare class ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionList extends cdktn.ComplexList {
    internalValue?: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusion[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionOutputReference;
}
export interface ComputeRegionSecurityPolicyRulePreconfiguredWafConfig {
    /**
    * exclusion block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#exclusion ComputeRegionSecurityPolicyRule#exclusion}
    */
    readonly exclusion?: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusion[] | cdktn.IResolvable;
}
export declare function computeRegionSecurityPolicyRulePreconfiguredWafConfigToTerraform(struct?: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigOutputReference | ComputeRegionSecurityPolicyRulePreconfiguredWafConfig): any;
export declare function computeRegionSecurityPolicyRulePreconfiguredWafConfigToHclTerraform(struct?: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigOutputReference | ComputeRegionSecurityPolicyRulePreconfiguredWafConfig): any;
export declare class ComputeRegionSecurityPolicyRulePreconfiguredWafConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionSecurityPolicyRulePreconfiguredWafConfig | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRulePreconfiguredWafConfig | undefined);
    private _exclusion;
    get exclusion(): ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusionList;
    putExclusion(value: ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusion[] | cdktn.IResolvable): void;
    resetExclusion(): void;
    get exclusionInput(): cdktn.IResolvable | ComputeRegionSecurityPolicyRulePreconfiguredWafConfigExclusion[] | undefined;
}
export interface ComputeRegionSecurityPolicyRuleRateLimitOptionsBanThreshold {
    /**
    * Number of HTTP(S) requests for calculating the threshold.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#count ComputeRegionSecurityPolicyRule#count}
    */
    readonly count?: number;
    /**
    * Interval over which the threshold is computed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#interval_sec ComputeRegionSecurityPolicyRule#interval_sec}
    */
    readonly intervalSec?: number;
}
export declare function computeRegionSecurityPolicyRuleRateLimitOptionsBanThresholdToTerraform(struct?: ComputeRegionSecurityPolicyRuleRateLimitOptionsBanThresholdOutputReference | ComputeRegionSecurityPolicyRuleRateLimitOptionsBanThreshold): any;
export declare function computeRegionSecurityPolicyRuleRateLimitOptionsBanThresholdToHclTerraform(struct?: ComputeRegionSecurityPolicyRuleRateLimitOptionsBanThresholdOutputReference | ComputeRegionSecurityPolicyRuleRateLimitOptionsBanThreshold): any;
export declare class ComputeRegionSecurityPolicyRuleRateLimitOptionsBanThresholdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionSecurityPolicyRuleRateLimitOptionsBanThreshold | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRuleRateLimitOptionsBanThreshold | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    resetCount(): void;
    get countInput(): number | undefined;
    private _intervalSec?;
    get intervalSec(): number;
    set intervalSec(value: number);
    resetIntervalSec(): void;
    get intervalSecInput(): number | undefined;
}
export interface ComputeRegionSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigs {
    /**
    * Rate limit key name applicable only for the following key types:
    * HTTP_HEADER -- Name of the HTTP header whose value is taken as the key value.
    * HTTP_COOKIE -- Name of the HTTP cookie whose value is taken as the key value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#enforce_on_key_name ComputeRegionSecurityPolicyRule#enforce_on_key_name}
    */
    readonly enforceOnKeyName?: string;
    /**
    * Determines the key to enforce the rateLimitThreshold on. Possible values are:
    * * ALL: A single rate limit threshold is applied to all the requests matching this rule. This is the default value if "enforceOnKeyConfigs" is not configured.
    * * IP: The source IP address of the request is the key. Each IP has this limit enforced separately.
    * * HTTP_HEADER: The value of the HTTP header whose name is configured under "enforceOnKeyName". The key value is truncated to the first 128 bytes of the header value. If no such header is present in the request, the key type defaults to ALL.
    * * XFF_IP: The first IP address (i.e. the originating client IP address) specified in the list of IPs under X-Forwarded-For HTTP header. If no such header is present or the value is not a valid IP, the key defaults to the source IP address of the request i.e. key type IP.
    * * HTTP_COOKIE: The value of the HTTP cookie whose name is configured under "enforceOnKeyName". The key value is truncated to the first 128 bytes of the cookie value. If no such cookie is present in the request, the key type defaults to ALL.
    * * HTTP_PATH: The URL path of the HTTP request. The key value is truncated to the first 128 bytes.
    * * SNI: Server name indication in the TLS session of the HTTPS request. The key value is truncated to the first 128 bytes. The key type defaults to ALL on a HTTP session.
    * * REGION_CODE: The country/region from which the request originates.
    * * TLS_JA3_FINGERPRINT: JA3 TLS/SSL fingerprint if the client connects using HTTPS, HTTP/2 or HTTP/3. If not available, the key type defaults to ALL.
    * * TLS_JA4_FINGERPRINT: JA4 TLS/SSL fingerprint if the client connects using HTTPS, HTTP/2 or HTTP/3. If not available, the key type defaults to ALL.
    * * USER_IP: The IP address of the originating client, which is resolved based on "userIpRequestHeaders" configured with the security policy. If there is no "userIpRequestHeaders" configuration or an IP address cannot be resolved from it, the key type defaults to IP. Possible values: ["ALL", "IP", "HTTP_HEADER", "XFF_IP", "HTTP_COOKIE", "HTTP_PATH", "SNI", "REGION_CODE", "TLS_JA3_FINGERPRINT", "TLS_JA4_FINGERPRINT", "USER_IP"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#enforce_on_key_type ComputeRegionSecurityPolicyRule#enforce_on_key_type}
    */
    readonly enforceOnKeyType?: string;
}
export declare function computeRegionSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsToTerraform(struct?: ComputeRegionSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigs | cdktn.IResolvable): any;
export declare function computeRegionSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsToHclTerraform(struct?: ComputeRegionSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigs | cdktn.IResolvable): any;
export declare class ComputeRegionSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigs | cdktn.IResolvable | undefined);
    private _enforceOnKeyName?;
    get enforceOnKeyName(): string;
    set enforceOnKeyName(value: string);
    resetEnforceOnKeyName(): void;
    get enforceOnKeyNameInput(): string | undefined;
    private _enforceOnKeyType?;
    get enforceOnKeyType(): string;
    set enforceOnKeyType(value: string);
    resetEnforceOnKeyType(): void;
    get enforceOnKeyTypeInput(): string | undefined;
}
export declare class ComputeRegionSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsList extends cdktn.ComplexList {
    internalValue?: ComputeRegionSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsOutputReference;
}
export interface ComputeRegionSecurityPolicyRuleRateLimitOptionsRateLimitThreshold {
    /**
    * Number of HTTP(S) requests for calculating the threshold.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#count ComputeRegionSecurityPolicyRule#count}
    */
    readonly count?: number;
    /**
    * Interval over which the threshold is computed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#interval_sec ComputeRegionSecurityPolicyRule#interval_sec}
    */
    readonly intervalSec?: number;
}
export declare function computeRegionSecurityPolicyRuleRateLimitOptionsRateLimitThresholdToTerraform(struct?: ComputeRegionSecurityPolicyRuleRateLimitOptionsRateLimitThresholdOutputReference | ComputeRegionSecurityPolicyRuleRateLimitOptionsRateLimitThreshold): any;
export declare function computeRegionSecurityPolicyRuleRateLimitOptionsRateLimitThresholdToHclTerraform(struct?: ComputeRegionSecurityPolicyRuleRateLimitOptionsRateLimitThresholdOutputReference | ComputeRegionSecurityPolicyRuleRateLimitOptionsRateLimitThreshold): any;
export declare class ComputeRegionSecurityPolicyRuleRateLimitOptionsRateLimitThresholdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionSecurityPolicyRuleRateLimitOptionsRateLimitThreshold | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRuleRateLimitOptionsRateLimitThreshold | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    resetCount(): void;
    get countInput(): number | undefined;
    private _intervalSec?;
    get intervalSec(): number;
    set intervalSec(value: number);
    resetIntervalSec(): void;
    get intervalSecInput(): number | undefined;
}
export interface ComputeRegionSecurityPolicyRuleRateLimitOptions {
    /**
    * Can only be specified if the action for the rule is "rate_based_ban".
    * If specified, determines the time (in seconds) the traffic will continue to be banned by the rate limit after the rate falls below the threshold.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#ban_duration_sec ComputeRegionSecurityPolicyRule#ban_duration_sec}
    */
    readonly banDurationSec?: number;
    /**
    * Action to take for requests that are under the configured rate limit threshold.
    * Valid option is "allow" only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#conform_action ComputeRegionSecurityPolicyRule#conform_action}
    */
    readonly conformAction?: string;
    /**
    * Determines the key to enforce the rateLimitThreshold on. Possible values are:
    * * ALL: A single rate limit threshold is applied to all the requests matching this rule. This is the default value if "enforceOnKey" is not configured.
    * * IP: The source IP address of the request is the key. Each IP has this limit enforced separately.
    * * HTTP_HEADER: The value of the HTTP header whose name is configured under "enforceOnKeyName". The key value is truncated to the first 128 bytes of the header value. If no such header is present in the request, the key type defaults to ALL.
    * * XFF_IP: The first IP address (i.e. the originating client IP address) specified in the list of IPs under X-Forwarded-For HTTP header. If no such header is present or the value is not a valid IP, the key defaults to the source IP address of the request i.e. key type IP.
    * * HTTP_COOKIE: The value of the HTTP cookie whose name is configured under "enforceOnKeyName". The key value is truncated to the first 128 bytes of the cookie value. If no such cookie is present in the request, the key type defaults to ALL.
    * * HTTP_PATH: The URL path of the HTTP request. The key value is truncated to the first 128 bytes.
    * * SNI: Server name indication in the TLS session of the HTTPS request. The key value is truncated to the first 128 bytes. The key type defaults to ALL on a HTTP session.
    * * REGION_CODE: The country/region from which the request originates.
    * * TLS_JA3_FINGERPRINT: JA3 TLS/SSL fingerprint if the client connects using HTTPS, HTTP/2 or HTTP/3. If not available, the key type defaults to ALL.
    * * TLS_JA4_FINGERPRINT: JA4 TLS/SSL fingerprint if the client connects using HTTPS, HTTP/2 or HTTP/3. If not available, the key type defaults to ALL.
    * * USER_IP: The IP address of the originating client, which is resolved based on "userIpRequestHeaders" configured with the security policy. If there is no "userIpRequestHeaders" configuration or an IP address cannot be resolved from it, the key type defaults to IP. Possible values: ["ALL", "IP", "HTTP_HEADER", "XFF_IP", "HTTP_COOKIE", "HTTP_PATH", "SNI", "REGION_CODE", "TLS_JA3_FINGERPRINT", "TLS_JA4_FINGERPRINT", "USER_IP"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#enforce_on_key ComputeRegionSecurityPolicyRule#enforce_on_key}
    */
    readonly enforceOnKey?: string;
    /**
    * Rate limit key name applicable only for the following key types:
    * HTTP_HEADER -- Name of the HTTP header whose value is taken as the key value.
    * HTTP_COOKIE -- Name of the HTTP cookie whose value is taken as the key value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#enforce_on_key_name ComputeRegionSecurityPolicyRule#enforce_on_key_name}
    */
    readonly enforceOnKeyName?: string;
    /**
    * Action to take for requests that are above the configured rate limit threshold, to deny with a specified HTTP response code.
    * Valid options are deny(STATUS), where valid values for STATUS are 403, 404, 429, and 502.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#exceed_action ComputeRegionSecurityPolicyRule#exceed_action}
    */
    readonly exceedAction?: string;
    /**
    * ban_threshold block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#ban_threshold ComputeRegionSecurityPolicyRule#ban_threshold}
    */
    readonly banThreshold?: ComputeRegionSecurityPolicyRuleRateLimitOptionsBanThreshold;
    /**
    * enforce_on_key_configs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#enforce_on_key_configs ComputeRegionSecurityPolicyRule#enforce_on_key_configs}
    */
    readonly enforceOnKeyConfigs?: ComputeRegionSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigs[] | cdktn.IResolvable;
    /**
    * rate_limit_threshold block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#rate_limit_threshold ComputeRegionSecurityPolicyRule#rate_limit_threshold}
    */
    readonly rateLimitThreshold?: ComputeRegionSecurityPolicyRuleRateLimitOptionsRateLimitThreshold;
}
export declare function computeRegionSecurityPolicyRuleRateLimitOptionsToTerraform(struct?: ComputeRegionSecurityPolicyRuleRateLimitOptionsOutputReference | ComputeRegionSecurityPolicyRuleRateLimitOptions): any;
export declare function computeRegionSecurityPolicyRuleRateLimitOptionsToHclTerraform(struct?: ComputeRegionSecurityPolicyRuleRateLimitOptionsOutputReference | ComputeRegionSecurityPolicyRuleRateLimitOptions): any;
export declare class ComputeRegionSecurityPolicyRuleRateLimitOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionSecurityPolicyRuleRateLimitOptions | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRuleRateLimitOptions | undefined);
    private _banDurationSec?;
    get banDurationSec(): number;
    set banDurationSec(value: number);
    resetBanDurationSec(): void;
    get banDurationSecInput(): number | undefined;
    private _conformAction?;
    get conformAction(): string;
    set conformAction(value: string);
    resetConformAction(): void;
    get conformActionInput(): string | undefined;
    private _enforceOnKey?;
    get enforceOnKey(): string;
    set enforceOnKey(value: string);
    resetEnforceOnKey(): void;
    get enforceOnKeyInput(): string | undefined;
    private _enforceOnKeyName?;
    get enforceOnKeyName(): string;
    set enforceOnKeyName(value: string);
    resetEnforceOnKeyName(): void;
    get enforceOnKeyNameInput(): string | undefined;
    private _exceedAction?;
    get exceedAction(): string;
    set exceedAction(value: string);
    resetExceedAction(): void;
    get exceedActionInput(): string | undefined;
    private _banThreshold;
    get banThreshold(): ComputeRegionSecurityPolicyRuleRateLimitOptionsBanThresholdOutputReference;
    putBanThreshold(value: ComputeRegionSecurityPolicyRuleRateLimitOptionsBanThreshold): void;
    resetBanThreshold(): void;
    get banThresholdInput(): ComputeRegionSecurityPolicyRuleRateLimitOptionsBanThreshold | undefined;
    private _enforceOnKeyConfigs;
    get enforceOnKeyConfigs(): ComputeRegionSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsList;
    putEnforceOnKeyConfigs(value: ComputeRegionSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigs[] | cdktn.IResolvable): void;
    resetEnforceOnKeyConfigs(): void;
    get enforceOnKeyConfigsInput(): cdktn.IResolvable | ComputeRegionSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigs[] | undefined;
    private _rateLimitThreshold;
    get rateLimitThreshold(): ComputeRegionSecurityPolicyRuleRateLimitOptionsRateLimitThresholdOutputReference;
    putRateLimitThreshold(value: ComputeRegionSecurityPolicyRuleRateLimitOptionsRateLimitThreshold): void;
    resetRateLimitThreshold(): void;
    get rateLimitThresholdInput(): ComputeRegionSecurityPolicyRuleRateLimitOptionsRateLimitThreshold | undefined;
}
export interface ComputeRegionSecurityPolicyRuleTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#create ComputeRegionSecurityPolicyRule#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#delete ComputeRegionSecurityPolicyRule#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#update ComputeRegionSecurityPolicyRule#update}
    */
    readonly update?: string;
}
export declare function computeRegionSecurityPolicyRuleTimeoutsToTerraform(struct?: ComputeRegionSecurityPolicyRuleTimeouts | cdktn.IResolvable): any;
export declare function computeRegionSecurityPolicyRuleTimeoutsToHclTerraform(struct?: ComputeRegionSecurityPolicyRuleTimeouts | cdktn.IResolvable): any;
export declare class ComputeRegionSecurityPolicyRuleTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionSecurityPolicyRuleTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRuleTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule google_compute_region_security_policy_rule}
*/
export declare class ComputeRegionSecurityPolicyRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_region_security_policy_rule";
    /**
    * Generates CDKTN code for importing a ComputeRegionSecurityPolicyRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeRegionSecurityPolicyRule to import
    * @param importFromId The id of the existing ComputeRegionSecurityPolicyRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeRegionSecurityPolicyRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy_rule google_compute_region_security_policy_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeRegionSecurityPolicyRuleConfig
    */
    constructor(scope: Construct, id: string, config: ComputeRegionSecurityPolicyRuleConfig);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _preview?;
    get preview(): boolean | cdktn.IResolvable;
    set preview(value: boolean | cdktn.IResolvable);
    resetPreview(): void;
    get previewInput(): boolean | cdktn.IResolvable | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _securityPolicy?;
    get securityPolicy(): string;
    set securityPolicy(value: string);
    get securityPolicyInput(): string | undefined;
    private _match;
    get match(): ComputeRegionSecurityPolicyRuleMatchOutputReference;
    putMatch(value: ComputeRegionSecurityPolicyRuleMatch): void;
    resetMatch(): void;
    get matchInput(): ComputeRegionSecurityPolicyRuleMatch | undefined;
    private _networkMatch;
    get networkMatch(): ComputeRegionSecurityPolicyRuleNetworkMatchOutputReference;
    putNetworkMatch(value: ComputeRegionSecurityPolicyRuleNetworkMatch): void;
    resetNetworkMatch(): void;
    get networkMatchInput(): ComputeRegionSecurityPolicyRuleNetworkMatch | undefined;
    private _preconfiguredWafConfig;
    get preconfiguredWafConfig(): ComputeRegionSecurityPolicyRulePreconfiguredWafConfigOutputReference;
    putPreconfiguredWafConfig(value: ComputeRegionSecurityPolicyRulePreconfiguredWafConfig): void;
    resetPreconfiguredWafConfig(): void;
    get preconfiguredWafConfigInput(): ComputeRegionSecurityPolicyRulePreconfiguredWafConfig | undefined;
    private _rateLimitOptions;
    get rateLimitOptions(): ComputeRegionSecurityPolicyRuleRateLimitOptionsOutputReference;
    putRateLimitOptions(value: ComputeRegionSecurityPolicyRuleRateLimitOptions): void;
    resetRateLimitOptions(): void;
    get rateLimitOptionsInput(): ComputeRegionSecurityPolicyRuleRateLimitOptions | undefined;
    private _timeouts;
    get timeouts(): ComputeRegionSecurityPolicyRuleTimeoutsOutputReference;
    putTimeouts(value: ComputeRegionSecurityPolicyRuleTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeRegionSecurityPolicyRuleTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
