/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface Cloudfunctions2FunctionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#deletion_policy Cloudfunctions2Function#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * User-provided description of a function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#description Cloudfunctions2Function#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#id Cloudfunctions2Function#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource name of a KMS crypto key (managed by the user) used to encrypt/decrypt function resources.
    * It must match the pattern projects/{project}/locations/{location}/keyRings/{key_ring}/cryptoKeys/{crypto_key}.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#kms_key_name Cloudfunctions2Function#kms_key_name}
    */
    readonly kmsKeyName?: string;
    /**
    * A set of key/value label pairs associated with this Cloud Function.
    *
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#labels Cloudfunctions2Function#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The location of this cloud function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#location Cloudfunctions2Function#location}
    */
    readonly location: string;
    /**
    * A user-defined name of the function. Function names must
    * be unique globally and match pattern 'projects/* /locations/* /functions/*'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#name Cloudfunctions2Function#name}
     *
    * Note: The above comment contained a comment block ending sequence (* followed by /). We have introduced a space between to prevent syntax errors. Please ignore the space.
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#project Cloudfunctions2Function#project}
    */
    readonly project?: string;
    /**
    * build_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#build_config Cloudfunctions2Function#build_config}
    */
    readonly buildConfig?: Cloudfunctions2FunctionBuildConfig;
    /**
    * event_trigger block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#event_trigger Cloudfunctions2Function#event_trigger}
    */
    readonly eventTrigger?: Cloudfunctions2FunctionEventTrigger;
    /**
    * service_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#service_config Cloudfunctions2Function#service_config}
    */
    readonly serviceConfig?: Cloudfunctions2FunctionServiceConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#timeouts Cloudfunctions2Function#timeouts}
    */
    readonly timeouts?: Cloudfunctions2FunctionTimeouts;
}
export interface Cloudfunctions2FunctionBuildConfigAutomaticUpdatePolicy {
}
export declare function cloudfunctions2FunctionBuildConfigAutomaticUpdatePolicyToTerraform(struct?: Cloudfunctions2FunctionBuildConfigAutomaticUpdatePolicyOutputReference | Cloudfunctions2FunctionBuildConfigAutomaticUpdatePolicy): any;
export declare function cloudfunctions2FunctionBuildConfigAutomaticUpdatePolicyToHclTerraform(struct?: Cloudfunctions2FunctionBuildConfigAutomaticUpdatePolicyOutputReference | Cloudfunctions2FunctionBuildConfigAutomaticUpdatePolicy): any;
export declare class Cloudfunctions2FunctionBuildConfigAutomaticUpdatePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Cloudfunctions2FunctionBuildConfigAutomaticUpdatePolicy | undefined;
    set internalValue(value: Cloudfunctions2FunctionBuildConfigAutomaticUpdatePolicy | undefined);
}
export interface Cloudfunctions2FunctionBuildConfigOnDeployUpdatePolicy {
}
export declare function cloudfunctions2FunctionBuildConfigOnDeployUpdatePolicyToTerraform(struct?: Cloudfunctions2FunctionBuildConfigOnDeployUpdatePolicyOutputReference | Cloudfunctions2FunctionBuildConfigOnDeployUpdatePolicy): any;
export declare function cloudfunctions2FunctionBuildConfigOnDeployUpdatePolicyToHclTerraform(struct?: Cloudfunctions2FunctionBuildConfigOnDeployUpdatePolicyOutputReference | Cloudfunctions2FunctionBuildConfigOnDeployUpdatePolicy): any;
export declare class Cloudfunctions2FunctionBuildConfigOnDeployUpdatePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Cloudfunctions2FunctionBuildConfigOnDeployUpdatePolicy | undefined;
    set internalValue(value: Cloudfunctions2FunctionBuildConfigOnDeployUpdatePolicy | undefined);
    get runtimeVersion(): string;
}
export interface Cloudfunctions2FunctionBuildConfigSourceRepoSource {
    /**
    * Regex matching branches to build.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#branch_name Cloudfunctions2Function#branch_name}
    */
    readonly branchName?: string;
    /**
    * Regex matching tags to build.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#commit_sha Cloudfunctions2Function#commit_sha}
    */
    readonly commitSha?: string;
    /**
    * Directory, relative to the source root, in which to run the build.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#dir Cloudfunctions2Function#dir}
    */
    readonly dir?: string;
    /**
    * Only trigger a build if the revision regex does
    * NOT match the revision regex.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#invert_regex Cloudfunctions2Function#invert_regex}
    */
    readonly invertRegex?: boolean | cdktn.IResolvable;
    /**
    * ID of the project that owns the Cloud Source Repository. If omitted, the
    * project ID requesting the build is assumed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#project_id Cloudfunctions2Function#project_id}
    */
    readonly projectId?: string;
    /**
    * Name of the Cloud Source Repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#repo_name Cloudfunctions2Function#repo_name}
    */
    readonly repoName?: string;
    /**
    * Regex matching tags to build.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#tag_name Cloudfunctions2Function#tag_name}
    */
    readonly tagName?: string;
}
export declare function cloudfunctions2FunctionBuildConfigSourceRepoSourceToTerraform(struct?: Cloudfunctions2FunctionBuildConfigSourceRepoSourceOutputReference | Cloudfunctions2FunctionBuildConfigSourceRepoSource): any;
export declare function cloudfunctions2FunctionBuildConfigSourceRepoSourceToHclTerraform(struct?: Cloudfunctions2FunctionBuildConfigSourceRepoSourceOutputReference | Cloudfunctions2FunctionBuildConfigSourceRepoSource): any;
export declare class Cloudfunctions2FunctionBuildConfigSourceRepoSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Cloudfunctions2FunctionBuildConfigSourceRepoSource | undefined;
    set internalValue(value: Cloudfunctions2FunctionBuildConfigSourceRepoSource | undefined);
    private _branchName?;
    get branchName(): string;
    set branchName(value: string);
    resetBranchName(): void;
    get branchNameInput(): string | undefined;
    private _commitSha?;
    get commitSha(): string;
    set commitSha(value: string);
    resetCommitSha(): void;
    get commitShaInput(): string | undefined;
    private _dir?;
    get dir(): string;
    set dir(value: string);
    resetDir(): void;
    get dirInput(): string | undefined;
    private _invertRegex?;
    get invertRegex(): boolean | cdktn.IResolvable;
    set invertRegex(value: boolean | cdktn.IResolvable);
    resetInvertRegex(): void;
    get invertRegexInput(): boolean | cdktn.IResolvable | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _repoName?;
    get repoName(): string;
    set repoName(value: string);
    resetRepoName(): void;
    get repoNameInput(): string | undefined;
    private _tagName?;
    get tagName(): string;
    set tagName(value: string);
    resetTagName(): void;
    get tagNameInput(): string | undefined;
}
export interface Cloudfunctions2FunctionBuildConfigSourceStorageSource {
    /**
    * Google Cloud Storage bucket containing the source
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#bucket Cloudfunctions2Function#bucket}
    */
    readonly bucket?: string;
    /**
    * Google Cloud Storage generation for the object. If the generation
    * is omitted, the latest generation will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#generation Cloudfunctions2Function#generation}
    */
    readonly generation?: number;
    /**
    * Google Cloud Storage object containing the source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#object Cloudfunctions2Function#object}
    */
    readonly object?: string;
}
export declare function cloudfunctions2FunctionBuildConfigSourceStorageSourceToTerraform(struct?: Cloudfunctions2FunctionBuildConfigSourceStorageSourceOutputReference | Cloudfunctions2FunctionBuildConfigSourceStorageSource): any;
export declare function cloudfunctions2FunctionBuildConfigSourceStorageSourceToHclTerraform(struct?: Cloudfunctions2FunctionBuildConfigSourceStorageSourceOutputReference | Cloudfunctions2FunctionBuildConfigSourceStorageSource): any;
export declare class Cloudfunctions2FunctionBuildConfigSourceStorageSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Cloudfunctions2FunctionBuildConfigSourceStorageSource | undefined;
    set internalValue(value: Cloudfunctions2FunctionBuildConfigSourceStorageSource | undefined);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    resetBucket(): void;
    get bucketInput(): string | undefined;
    private _generation?;
    get generation(): number;
    set generation(value: number);
    resetGeneration(): void;
    get generationInput(): number | undefined;
    private _object?;
    get object(): string;
    set object(value: string);
    resetObject(): void;
    get objectInput(): string | undefined;
}
export interface Cloudfunctions2FunctionBuildConfigSource {
    /**
    * repo_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#repo_source Cloudfunctions2Function#repo_source}
    */
    readonly repoSource?: Cloudfunctions2FunctionBuildConfigSourceRepoSource;
    /**
    * storage_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#storage_source Cloudfunctions2Function#storage_source}
    */
    readonly storageSource?: Cloudfunctions2FunctionBuildConfigSourceStorageSource;
}
export declare function cloudfunctions2FunctionBuildConfigSourceToTerraform(struct?: Cloudfunctions2FunctionBuildConfigSourceOutputReference | Cloudfunctions2FunctionBuildConfigSource): any;
export declare function cloudfunctions2FunctionBuildConfigSourceToHclTerraform(struct?: Cloudfunctions2FunctionBuildConfigSourceOutputReference | Cloudfunctions2FunctionBuildConfigSource): any;
export declare class Cloudfunctions2FunctionBuildConfigSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Cloudfunctions2FunctionBuildConfigSource | undefined;
    set internalValue(value: Cloudfunctions2FunctionBuildConfigSource | undefined);
    private _repoSource;
    get repoSource(): Cloudfunctions2FunctionBuildConfigSourceRepoSourceOutputReference;
    putRepoSource(value: Cloudfunctions2FunctionBuildConfigSourceRepoSource): void;
    resetRepoSource(): void;
    get repoSourceInput(): Cloudfunctions2FunctionBuildConfigSourceRepoSource | undefined;
    private _storageSource;
    get storageSource(): Cloudfunctions2FunctionBuildConfigSourceStorageSourceOutputReference;
    putStorageSource(value: Cloudfunctions2FunctionBuildConfigSourceStorageSource): void;
    resetStorageSource(): void;
    get storageSourceInput(): Cloudfunctions2FunctionBuildConfigSourceStorageSource | undefined;
}
export interface Cloudfunctions2FunctionBuildConfig {
    /**
    * User managed repository created in Artifact Registry optionally with a customer managed encryption key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#docker_repository Cloudfunctions2Function#docker_repository}
    */
    readonly dockerRepository?: string;
    /**
    * The name of the function (as defined in source code) that will be executed.
    * Defaults to the resource name suffix, if not specified. For backward
    * compatibility, if function with given name is not found, then the system
    * will try to use function named "function". For Node.js this is name of a
    * function exported by the module specified in source_location.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#entry_point Cloudfunctions2Function#entry_point}
    */
    readonly entryPoint?: string;
    /**
    * User-provided build-time environment variables for the function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#environment_variables Cloudfunctions2Function#environment_variables}
    */
    readonly environmentVariables?: {
        [key: string]: string;
    };
    /**
    * The runtime in which to run the function. Required when deploying a new
    * function, optional when updating an existing function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#runtime Cloudfunctions2Function#runtime}
    */
    readonly runtime?: string;
    /**
    * The fully-qualified name of the service account to be used for building the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#service_account Cloudfunctions2Function#service_account}
    */
    readonly serviceAccount?: string;
    /**
    * Name of the Cloud Build Custom Worker Pool that should be used to build the function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#worker_pool Cloudfunctions2Function#worker_pool}
    */
    readonly workerPool?: string;
    /**
    * automatic_update_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#automatic_update_policy Cloudfunctions2Function#automatic_update_policy}
    */
    readonly automaticUpdatePolicy?: Cloudfunctions2FunctionBuildConfigAutomaticUpdatePolicy;
    /**
    * on_deploy_update_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#on_deploy_update_policy Cloudfunctions2Function#on_deploy_update_policy}
    */
    readonly onDeployUpdatePolicy?: Cloudfunctions2FunctionBuildConfigOnDeployUpdatePolicy;
    /**
    * source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#source Cloudfunctions2Function#source}
    */
    readonly source?: Cloudfunctions2FunctionBuildConfigSource;
}
export declare function cloudfunctions2FunctionBuildConfigToTerraform(struct?: Cloudfunctions2FunctionBuildConfigOutputReference | Cloudfunctions2FunctionBuildConfig): any;
export declare function cloudfunctions2FunctionBuildConfigToHclTerraform(struct?: Cloudfunctions2FunctionBuildConfigOutputReference | Cloudfunctions2FunctionBuildConfig): any;
export declare class Cloudfunctions2FunctionBuildConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Cloudfunctions2FunctionBuildConfig | undefined;
    set internalValue(value: Cloudfunctions2FunctionBuildConfig | undefined);
    get buildAttribute(): string;
    private _dockerRepository?;
    get dockerRepository(): string;
    set dockerRepository(value: string);
    resetDockerRepository(): void;
    get dockerRepositoryInput(): string | undefined;
    private _entryPoint?;
    get entryPoint(): string;
    set entryPoint(value: string);
    resetEntryPoint(): void;
    get entryPointInput(): string | undefined;
    private _environmentVariables?;
    get environmentVariables(): {
        [key: string]: string;
    };
    set environmentVariables(value: {
        [key: string]: string;
    });
    resetEnvironmentVariables(): void;
    get environmentVariablesInput(): {
        [key: string]: string;
    } | undefined;
    private _runtime?;
    get runtime(): string;
    set runtime(value: string);
    resetRuntime(): void;
    get runtimeInput(): string | undefined;
    private _serviceAccount?;
    get serviceAccount(): string;
    set serviceAccount(value: string);
    resetServiceAccount(): void;
    get serviceAccountInput(): string | undefined;
    private _workerPool?;
    get workerPool(): string;
    set workerPool(value: string);
    resetWorkerPool(): void;
    get workerPoolInput(): string | undefined;
    private _automaticUpdatePolicy;
    get automaticUpdatePolicy(): Cloudfunctions2FunctionBuildConfigAutomaticUpdatePolicyOutputReference;
    putAutomaticUpdatePolicy(value: Cloudfunctions2FunctionBuildConfigAutomaticUpdatePolicy): void;
    resetAutomaticUpdatePolicy(): void;
    get automaticUpdatePolicyInput(): Cloudfunctions2FunctionBuildConfigAutomaticUpdatePolicy | undefined;
    private _onDeployUpdatePolicy;
    get onDeployUpdatePolicy(): Cloudfunctions2FunctionBuildConfigOnDeployUpdatePolicyOutputReference;
    putOnDeployUpdatePolicy(value: Cloudfunctions2FunctionBuildConfigOnDeployUpdatePolicy): void;
    resetOnDeployUpdatePolicy(): void;
    get onDeployUpdatePolicyInput(): Cloudfunctions2FunctionBuildConfigOnDeployUpdatePolicy | undefined;
    private _source;
    get source(): Cloudfunctions2FunctionBuildConfigSourceOutputReference;
    putSource(value: Cloudfunctions2FunctionBuildConfigSource): void;
    resetSource(): void;
    get sourceInput(): Cloudfunctions2FunctionBuildConfigSource | undefined;
}
export interface Cloudfunctions2FunctionEventTriggerEventFilters {
    /**
    * 'Required. The name of a CloudEvents attribute.
    * Currently, only a subset of attributes are supported for filtering. Use the 'gcloud eventarc providers describe' command to learn more about events and their attributes.
    * Do not filter for the 'type' attribute here, as this is already achieved by the resource's 'event_type' attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#attribute Cloudfunctions2Function#attribute}
    */
    readonly attribute: string;
    /**
    * Optional. The operator used for matching the events with the value of
    * the filter. If not specified, only events that have an exact key-value
    * pair specified in the filter are matched.
    * The only allowed value is 'match-path-pattern'.
    * [See documentation on path patterns here](https://cloud.google.com/eventarc/docs/path-patterns)'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#operator Cloudfunctions2Function#operator}
    */
    readonly operator?: string;
    /**
    * Required. The value for the attribute.
    * If the operator field is set as 'match-path-pattern', this value can be a path pattern instead of an exact value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#value Cloudfunctions2Function#value}
    */
    readonly value: string;
}
export declare function cloudfunctions2FunctionEventTriggerEventFiltersToTerraform(struct?: Cloudfunctions2FunctionEventTriggerEventFilters | cdktn.IResolvable): any;
export declare function cloudfunctions2FunctionEventTriggerEventFiltersToHclTerraform(struct?: Cloudfunctions2FunctionEventTriggerEventFilters | cdktn.IResolvable): any;
export declare class Cloudfunctions2FunctionEventTriggerEventFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Cloudfunctions2FunctionEventTriggerEventFilters | cdktn.IResolvable | undefined;
    set internalValue(value: Cloudfunctions2FunctionEventTriggerEventFilters | cdktn.IResolvable | undefined);
    private _attribute?;
    get attribute(): string;
    set attribute(value: string);
    get attributeInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class Cloudfunctions2FunctionEventTriggerEventFiltersList extends cdktn.ComplexList {
    internalValue?: Cloudfunctions2FunctionEventTriggerEventFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Cloudfunctions2FunctionEventTriggerEventFiltersOutputReference;
}
export interface Cloudfunctions2FunctionEventTrigger {
    /**
    * Required. The type of event to observe.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#event_type Cloudfunctions2Function#event_type}
    */
    readonly eventType: string;
    /**
    * The name of a Pub/Sub topic in the same project that will be used
    * as the transport topic for the event delivery.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#pubsub_topic Cloudfunctions2Function#pubsub_topic}
    */
    readonly pubsubTopic?: string;
    /**
    * Describes the retry policy in case of function's execution failure.
    * Retried execution is charged as any other execution. Possible values: ["RETRY_POLICY_UNSPECIFIED", "RETRY_POLICY_DO_NOT_RETRY", "RETRY_POLICY_RETRY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#retry_policy Cloudfunctions2Function#retry_policy}
    */
    readonly retryPolicy?: string;
    /**
    * Optional. The email of the trigger's service account. The service account
    * must have permission to invoke Cloud Run services. If empty, defaults to the
    * Compute Engine default service account: {project_number}-compute@developer.gserviceaccount.com.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#service_account_email Cloudfunctions2Function#service_account_email}
    */
    readonly serviceAccountEmail?: string;
    /**
    * The region that the trigger will be in. The trigger will only receive
    * events originating in this region. It can be the same
    * region as the function, a different region or multi-region, or the global
    * region. If not provided, defaults to the same region as the function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#trigger_region Cloudfunctions2Function#trigger_region}
    */
    readonly triggerRegion?: string;
    /**
    * event_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#event_filters Cloudfunctions2Function#event_filters}
    */
    readonly eventFilters?: Cloudfunctions2FunctionEventTriggerEventFilters[] | cdktn.IResolvable;
}
export declare function cloudfunctions2FunctionEventTriggerToTerraform(struct?: Cloudfunctions2FunctionEventTriggerOutputReference | Cloudfunctions2FunctionEventTrigger): any;
export declare function cloudfunctions2FunctionEventTriggerToHclTerraform(struct?: Cloudfunctions2FunctionEventTriggerOutputReference | Cloudfunctions2FunctionEventTrigger): any;
export declare class Cloudfunctions2FunctionEventTriggerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Cloudfunctions2FunctionEventTrigger | undefined;
    set internalValue(value: Cloudfunctions2FunctionEventTrigger | undefined);
    private _eventType?;
    get eventType(): string;
    set eventType(value: string);
    get eventTypeInput(): string | undefined;
    private _pubsubTopic?;
    get pubsubTopic(): string;
    set pubsubTopic(value: string);
    resetPubsubTopic(): void;
    get pubsubTopicInput(): string | undefined;
    private _retryPolicy?;
    get retryPolicy(): string;
    set retryPolicy(value: string);
    resetRetryPolicy(): void;
    get retryPolicyInput(): string | undefined;
    private _serviceAccountEmail?;
    get serviceAccountEmail(): string;
    set serviceAccountEmail(value: string);
    resetServiceAccountEmail(): void;
    get serviceAccountEmailInput(): string | undefined;
    get trigger(): string;
    private _triggerRegion?;
    get triggerRegion(): string;
    set triggerRegion(value: string);
    resetTriggerRegion(): void;
    get triggerRegionInput(): string | undefined;
    private _eventFilters;
    get eventFilters(): Cloudfunctions2FunctionEventTriggerEventFiltersList;
    putEventFilters(value: Cloudfunctions2FunctionEventTriggerEventFilters[] | cdktn.IResolvable): void;
    resetEventFilters(): void;
    get eventFiltersInput(): cdktn.IResolvable | Cloudfunctions2FunctionEventTriggerEventFilters[] | undefined;
}
export interface Cloudfunctions2FunctionServiceConfigDirectVpcNetworkInterface {
    /**
    * The name of the VPC network to which the function will be connected. Specify either a VPC network or a subnet, or both. If you specify only a network, the subnet uses the same name as the network.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#network Cloudfunctions2Function#network}
    */
    readonly network?: string;
    /**
    * The name of the VPC subnetwork that the Cloud Function resource will get IPs from. Specify either a VPC network or a subnet, or both. If both network and subnetwork are specified, the given VPC subnetwork must belong to the given VPC network. If subnetwork is not specified, the subnetwork with the same name with the network will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#subnetwork Cloudfunctions2Function#subnetwork}
    */
    readonly subnetwork?: string;
    /**
    * Network tags applied to this Cloud Function resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#tags Cloudfunctions2Function#tags}
    */
    readonly tags?: string[];
}
export declare function cloudfunctions2FunctionServiceConfigDirectVpcNetworkInterfaceToTerraform(struct?: Cloudfunctions2FunctionServiceConfigDirectVpcNetworkInterface | cdktn.IResolvable): any;
export declare function cloudfunctions2FunctionServiceConfigDirectVpcNetworkInterfaceToHclTerraform(struct?: Cloudfunctions2FunctionServiceConfigDirectVpcNetworkInterface | cdktn.IResolvable): any;
export declare class Cloudfunctions2FunctionServiceConfigDirectVpcNetworkInterfaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Cloudfunctions2FunctionServiceConfigDirectVpcNetworkInterface | cdktn.IResolvable | undefined;
    set internalValue(value: Cloudfunctions2FunctionServiceConfigDirectVpcNetworkInterface | cdktn.IResolvable | undefined);
    private _network?;
    get network(): string;
    set network(value: string);
    resetNetwork(): void;
    get networkInput(): string | undefined;
    private _subnetwork?;
    get subnetwork(): string;
    set subnetwork(value: string);
    resetSubnetwork(): void;
    get subnetworkInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
}
export declare class Cloudfunctions2FunctionServiceConfigDirectVpcNetworkInterfaceList extends cdktn.ComplexList {
    internalValue?: Cloudfunctions2FunctionServiceConfigDirectVpcNetworkInterface[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Cloudfunctions2FunctionServiceConfigDirectVpcNetworkInterfaceOutputReference;
}
export interface Cloudfunctions2FunctionServiceConfigSecretEnvironmentVariables {
    /**
    * Name of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#key Cloudfunctions2Function#key}
    */
    readonly key: string;
    /**
    * Project identifier (preferably project number but can also be the project ID) of the project that contains the secret. If not set, it will be populated with the function's project assuming that the secret exists in the same project as of the function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#project_id Cloudfunctions2Function#project_id}
    */
    readonly projectId: string;
    /**
    * Name of the secret in secret manager (not the full resource name).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#secret Cloudfunctions2Function#secret}
    */
    readonly secret: string;
    /**
    * Version of the secret (version number or the string 'latest'). It is recommended to use a numeric version for secret environment variables as any updates to the secret value is not reflected until new instances start.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#version Cloudfunctions2Function#version}
    */
    readonly version: string;
}
export declare function cloudfunctions2FunctionServiceConfigSecretEnvironmentVariablesToTerraform(struct?: Cloudfunctions2FunctionServiceConfigSecretEnvironmentVariables | cdktn.IResolvable): any;
export declare function cloudfunctions2FunctionServiceConfigSecretEnvironmentVariablesToHclTerraform(struct?: Cloudfunctions2FunctionServiceConfigSecretEnvironmentVariables | cdktn.IResolvable): any;
export declare class Cloudfunctions2FunctionServiceConfigSecretEnvironmentVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Cloudfunctions2FunctionServiceConfigSecretEnvironmentVariables | cdktn.IResolvable | undefined;
    set internalValue(value: Cloudfunctions2FunctionServiceConfigSecretEnvironmentVariables | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _secret?;
    get secret(): string;
    set secret(value: string);
    get secretInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
}
export declare class Cloudfunctions2FunctionServiceConfigSecretEnvironmentVariablesList extends cdktn.ComplexList {
    internalValue?: Cloudfunctions2FunctionServiceConfigSecretEnvironmentVariables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Cloudfunctions2FunctionServiceConfigSecretEnvironmentVariablesOutputReference;
}
export interface Cloudfunctions2FunctionServiceConfigSecretVolumesVersions {
    /**
    * Relative path of the file under the mount path where the secret value for this version will be fetched and made available. For example, setting the mountPath as '/etc/secrets' and path as secret_foo would mount the secret value file at /etc/secrets/secret_foo.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#path Cloudfunctions2Function#path}
    */
    readonly path: string;
    /**
    * Version of the secret (version number or the string 'latest'). It is preferable to use latest version with secret volumes as secret value changes are reflected immediately.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#version Cloudfunctions2Function#version}
    */
    readonly version: string;
}
export declare function cloudfunctions2FunctionServiceConfigSecretVolumesVersionsToTerraform(struct?: Cloudfunctions2FunctionServiceConfigSecretVolumesVersions | cdktn.IResolvable): any;
export declare function cloudfunctions2FunctionServiceConfigSecretVolumesVersionsToHclTerraform(struct?: Cloudfunctions2FunctionServiceConfigSecretVolumesVersions | cdktn.IResolvable): any;
export declare class Cloudfunctions2FunctionServiceConfigSecretVolumesVersionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Cloudfunctions2FunctionServiceConfigSecretVolumesVersions | cdktn.IResolvable | undefined;
    set internalValue(value: Cloudfunctions2FunctionServiceConfigSecretVolumesVersions | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
}
export declare class Cloudfunctions2FunctionServiceConfigSecretVolumesVersionsList extends cdktn.ComplexList {
    internalValue?: Cloudfunctions2FunctionServiceConfigSecretVolumesVersions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Cloudfunctions2FunctionServiceConfigSecretVolumesVersionsOutputReference;
}
export interface Cloudfunctions2FunctionServiceConfigSecretVolumes {
    /**
    * The path within the container to mount the secret volume. For example, setting the mountPath as /etc/secrets would mount the secret value files under the /etc/secrets directory. This directory will also be completely shadowed and unavailable to mount any other secrets. Recommended mount path: /etc/secrets
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#mount_path Cloudfunctions2Function#mount_path}
    */
    readonly mountPath: string;
    /**
    * Project identifier (preferably project number but can also be the project ID) of the project that contains the secret. If not set, it will be populated with the function's project assuming that the secret exists in the same project as of the function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#project_id Cloudfunctions2Function#project_id}
    */
    readonly projectId: string;
    /**
    * Name of the secret in secret manager (not the full resource name).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#secret Cloudfunctions2Function#secret}
    */
    readonly secret: string;
    /**
    * versions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#versions Cloudfunctions2Function#versions}
    */
    readonly versions?: Cloudfunctions2FunctionServiceConfigSecretVolumesVersions[] | cdktn.IResolvable;
}
export declare function cloudfunctions2FunctionServiceConfigSecretVolumesToTerraform(struct?: Cloudfunctions2FunctionServiceConfigSecretVolumes | cdktn.IResolvable): any;
export declare function cloudfunctions2FunctionServiceConfigSecretVolumesToHclTerraform(struct?: Cloudfunctions2FunctionServiceConfigSecretVolumes | cdktn.IResolvable): any;
export declare class Cloudfunctions2FunctionServiceConfigSecretVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Cloudfunctions2FunctionServiceConfigSecretVolumes | cdktn.IResolvable | undefined;
    set internalValue(value: Cloudfunctions2FunctionServiceConfigSecretVolumes | cdktn.IResolvable | undefined);
    private _mountPath?;
    get mountPath(): string;
    set mountPath(value: string);
    get mountPathInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _secret?;
    get secret(): string;
    set secret(value: string);
    get secretInput(): string | undefined;
    private _versions;
    get versions(): Cloudfunctions2FunctionServiceConfigSecretVolumesVersionsList;
    putVersions(value: Cloudfunctions2FunctionServiceConfigSecretVolumesVersions[] | cdktn.IResolvable): void;
    resetVersions(): void;
    get versionsInput(): cdktn.IResolvable | Cloudfunctions2FunctionServiceConfigSecretVolumesVersions[] | undefined;
}
export declare class Cloudfunctions2FunctionServiceConfigSecretVolumesList extends cdktn.ComplexList {
    internalValue?: Cloudfunctions2FunctionServiceConfigSecretVolumes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Cloudfunctions2FunctionServiceConfigSecretVolumesOutputReference;
}
export interface Cloudfunctions2FunctionServiceConfig {
    /**
    * Whether 100% of traffic is routed to the latest revision. Defaults to true. When false, GCF honors the existing traffic configuration of the underlying Cloud Run service. If that configuration is set to route to LATEST (the default), the new deployment will become LATEST and intercept the traffic. To prevent traffic from shifting, you must manually pin the existing service to a specific revision name in Cloud Run before deploying.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#all_traffic_on_latest_revision Cloudfunctions2Function#all_traffic_on_latest_revision}
    */
    readonly allTrafficOnLatestRevision?: boolean | cdktn.IResolvable;
    /**
    * The number of CPUs used in a single container instance. Default value is calculated from available memory.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#available_cpu Cloudfunctions2Function#available_cpu}
    */
    readonly availableCpu?: string;
    /**
    * The amount of memory available for a function.
    * Defaults to 256M. Supported units are k, M, G, Mi, Gi. If no unit is
    * supplied the value is interpreted as bytes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#available_memory Cloudfunctions2Function#available_memory}
    */
    readonly availableMemory?: string;
    /**
    * The binary authorization policy to be checked when deploying the Cloud Run service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#binary_authorization_policy Cloudfunctions2Function#binary_authorization_policy}
    */
    readonly binaryAuthorizationPolicy?: string;
    /**
    * Egress settings for direct VPC. If not provided, it defaults to VPC_EGRESS_PRIVATE_RANGES_ONLY. Possible values: ["VPC_EGRESS_ALL_TRAFFIC", "VPC_EGRESS_PRIVATE_RANGES_ONLY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#direct_vpc_egress Cloudfunctions2Function#direct_vpc_egress}
    */
    readonly directVpcEgress?: string;
    /**
    * Environment variables that shall be available during function execution.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#environment_variables Cloudfunctions2Function#environment_variables}
    */
    readonly environmentVariables?: {
        [key: string]: string;
    };
    /**
    * Available ingress settings. Defaults to "ALLOW_ALL" if unspecified. Default value: "ALLOW_ALL" Possible values: ["ALLOW_ALL", "ALLOW_INTERNAL_ONLY", "ALLOW_INTERNAL_AND_GCLB"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#ingress_settings Cloudfunctions2Function#ingress_settings}
    */
    readonly ingressSettings?: string;
    /**
    * The limit on the maximum number of function instances that may coexist at a
    * given time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#max_instance_count Cloudfunctions2Function#max_instance_count}
    */
    readonly maxInstanceCount?: number;
    /**
    * Sets the maximum number of concurrent requests that each instance can receive. Defaults to 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#max_instance_request_concurrency Cloudfunctions2Function#max_instance_request_concurrency}
    */
    readonly maxInstanceRequestConcurrency?: number;
    /**
    * The limit on the minimum number of function instances that may coexist at a
    * given time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#min_instance_count Cloudfunctions2Function#min_instance_count}
    */
    readonly minInstanceCount?: number;
    /**
    * The email of the service account for this function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#service_account_email Cloudfunctions2Function#service_account_email}
    */
    readonly serviceAccountEmail?: string;
    /**
    * The function execution timeout. Execution is considered failed and
    * can be terminated if the function is not completed at the end of the
    * timeout period. Defaults to 60 seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#timeout_seconds Cloudfunctions2Function#timeout_seconds}
    */
    readonly timeoutSeconds?: number;
    /**
    * The Serverless VPC Access connector that this cloud function can connect to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#vpc_connector Cloudfunctions2Function#vpc_connector}
    */
    readonly vpcConnector?: string;
    /**
    * Available egress settings. Possible values: ["VPC_CONNECTOR_EGRESS_SETTINGS_UNSPECIFIED", "PRIVATE_RANGES_ONLY", "ALL_TRAFFIC"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#vpc_connector_egress_settings Cloudfunctions2Function#vpc_connector_egress_settings}
    */
    readonly vpcConnectorEgressSettings?: string;
    /**
    * direct_vpc_network_interface block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#direct_vpc_network_interface Cloudfunctions2Function#direct_vpc_network_interface}
    */
    readonly directVpcNetworkInterface?: Cloudfunctions2FunctionServiceConfigDirectVpcNetworkInterface[] | cdktn.IResolvable;
    /**
    * secret_environment_variables block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#secret_environment_variables Cloudfunctions2Function#secret_environment_variables}
    */
    readonly secretEnvironmentVariables?: Cloudfunctions2FunctionServiceConfigSecretEnvironmentVariables[] | cdktn.IResolvable;
    /**
    * secret_volumes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#secret_volumes Cloudfunctions2Function#secret_volumes}
    */
    readonly secretVolumes?: Cloudfunctions2FunctionServiceConfigSecretVolumes[] | cdktn.IResolvable;
}
export declare function cloudfunctions2FunctionServiceConfigToTerraform(struct?: Cloudfunctions2FunctionServiceConfigOutputReference | Cloudfunctions2FunctionServiceConfig): any;
export declare function cloudfunctions2FunctionServiceConfigToHclTerraform(struct?: Cloudfunctions2FunctionServiceConfigOutputReference | Cloudfunctions2FunctionServiceConfig): any;
export declare class Cloudfunctions2FunctionServiceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Cloudfunctions2FunctionServiceConfig | undefined;
    set internalValue(value: Cloudfunctions2FunctionServiceConfig | undefined);
    private _allTrafficOnLatestRevision?;
    get allTrafficOnLatestRevision(): boolean | cdktn.IResolvable;
    set allTrafficOnLatestRevision(value: boolean | cdktn.IResolvable);
    resetAllTrafficOnLatestRevision(): void;
    get allTrafficOnLatestRevisionInput(): boolean | cdktn.IResolvable | undefined;
    private _availableCpu?;
    get availableCpu(): string;
    set availableCpu(value: string);
    resetAvailableCpu(): void;
    get availableCpuInput(): string | undefined;
    private _availableMemory?;
    get availableMemory(): string;
    set availableMemory(value: string);
    resetAvailableMemory(): void;
    get availableMemoryInput(): string | undefined;
    private _binaryAuthorizationPolicy?;
    get binaryAuthorizationPolicy(): string;
    set binaryAuthorizationPolicy(value: string);
    resetBinaryAuthorizationPolicy(): void;
    get binaryAuthorizationPolicyInput(): string | undefined;
    private _directVpcEgress?;
    get directVpcEgress(): string;
    set directVpcEgress(value: string);
    resetDirectVpcEgress(): void;
    get directVpcEgressInput(): string | undefined;
    private _environmentVariables?;
    get environmentVariables(): {
        [key: string]: string;
    };
    set environmentVariables(value: {
        [key: string]: string;
    });
    resetEnvironmentVariables(): void;
    get environmentVariablesInput(): {
        [key: string]: string;
    } | undefined;
    get gcfUri(): string;
    private _ingressSettings?;
    get ingressSettings(): string;
    set ingressSettings(value: string);
    resetIngressSettings(): void;
    get ingressSettingsInput(): string | undefined;
    private _maxInstanceCount?;
    get maxInstanceCount(): number;
    set maxInstanceCount(value: number);
    resetMaxInstanceCount(): void;
    get maxInstanceCountInput(): number | undefined;
    private _maxInstanceRequestConcurrency?;
    get maxInstanceRequestConcurrency(): number;
    set maxInstanceRequestConcurrency(value: number);
    resetMaxInstanceRequestConcurrency(): void;
    get maxInstanceRequestConcurrencyInput(): number | undefined;
    private _minInstanceCount?;
    get minInstanceCount(): number;
    set minInstanceCount(value: number);
    resetMinInstanceCount(): void;
    get minInstanceCountInput(): number | undefined;
    get service(): string;
    private _serviceAccountEmail?;
    get serviceAccountEmail(): string;
    set serviceAccountEmail(value: string);
    resetServiceAccountEmail(): void;
    get serviceAccountEmailInput(): string | undefined;
    private _timeoutSeconds?;
    get timeoutSeconds(): number;
    set timeoutSeconds(value: number);
    resetTimeoutSeconds(): void;
    get timeoutSecondsInput(): number | undefined;
    get uri(): string;
    private _vpcConnector?;
    get vpcConnector(): string;
    set vpcConnector(value: string);
    resetVpcConnector(): void;
    get vpcConnectorInput(): string | undefined;
    private _vpcConnectorEgressSettings?;
    get vpcConnectorEgressSettings(): string;
    set vpcConnectorEgressSettings(value: string);
    resetVpcConnectorEgressSettings(): void;
    get vpcConnectorEgressSettingsInput(): string | undefined;
    private _directVpcNetworkInterface;
    get directVpcNetworkInterface(): Cloudfunctions2FunctionServiceConfigDirectVpcNetworkInterfaceList;
    putDirectVpcNetworkInterface(value: Cloudfunctions2FunctionServiceConfigDirectVpcNetworkInterface[] | cdktn.IResolvable): void;
    resetDirectVpcNetworkInterface(): void;
    get directVpcNetworkInterfaceInput(): cdktn.IResolvable | Cloudfunctions2FunctionServiceConfigDirectVpcNetworkInterface[] | undefined;
    private _secretEnvironmentVariables;
    get secretEnvironmentVariables(): Cloudfunctions2FunctionServiceConfigSecretEnvironmentVariablesList;
    putSecretEnvironmentVariables(value: Cloudfunctions2FunctionServiceConfigSecretEnvironmentVariables[] | cdktn.IResolvable): void;
    resetSecretEnvironmentVariables(): void;
    get secretEnvironmentVariablesInput(): cdktn.IResolvable | Cloudfunctions2FunctionServiceConfigSecretEnvironmentVariables[] | undefined;
    private _secretVolumes;
    get secretVolumes(): Cloudfunctions2FunctionServiceConfigSecretVolumesList;
    putSecretVolumes(value: Cloudfunctions2FunctionServiceConfigSecretVolumes[] | cdktn.IResolvable): void;
    resetSecretVolumes(): void;
    get secretVolumesInput(): cdktn.IResolvable | Cloudfunctions2FunctionServiceConfigSecretVolumes[] | undefined;
}
export interface Cloudfunctions2FunctionTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#create Cloudfunctions2Function#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#delete Cloudfunctions2Function#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#update Cloudfunctions2Function#update}
    */
    readonly update?: string;
}
export declare function cloudfunctions2FunctionTimeoutsToTerraform(struct?: Cloudfunctions2FunctionTimeouts | cdktn.IResolvable): any;
export declare function cloudfunctions2FunctionTimeoutsToHclTerraform(struct?: Cloudfunctions2FunctionTimeouts | cdktn.IResolvable): any;
export declare class Cloudfunctions2FunctionTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Cloudfunctions2FunctionTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: Cloudfunctions2FunctionTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function google_cloudfunctions2_function}
*/
export declare class Cloudfunctions2Function extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_cloudfunctions2_function";
    /**
    * Generates CDKTN code for importing a Cloudfunctions2Function resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Cloudfunctions2Function to import
    * @param importFromId The id of the existing Cloudfunctions2Function that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Cloudfunctions2Function to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloudfunctions2_function google_cloudfunctions2_function} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options Cloudfunctions2FunctionConfig
    */
    constructor(scope: Construct, id: string, config: Cloudfunctions2FunctionConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get environment(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsKeyName?;
    get kmsKeyName(): string;
    set kmsKeyName(value: string);
    resetKmsKeyName(): void;
    get kmsKeyNameInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get state(): string;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get updateTime(): string;
    get url(): string;
    private _buildConfig;
    get buildConfig(): Cloudfunctions2FunctionBuildConfigOutputReference;
    putBuildConfig(value: Cloudfunctions2FunctionBuildConfig): void;
    resetBuildConfig(): void;
    get buildConfigInput(): Cloudfunctions2FunctionBuildConfig | undefined;
    private _eventTrigger;
    get eventTrigger(): Cloudfunctions2FunctionEventTriggerOutputReference;
    putEventTrigger(value: Cloudfunctions2FunctionEventTrigger): void;
    resetEventTrigger(): void;
    get eventTriggerInput(): Cloudfunctions2FunctionEventTrigger | undefined;
    private _serviceConfig;
    get serviceConfig(): Cloudfunctions2FunctionServiceConfigOutputReference;
    putServiceConfig(value: Cloudfunctions2FunctionServiceConfig): void;
    resetServiceConfig(): void;
    get serviceConfigInput(): Cloudfunctions2FunctionServiceConfig | undefined;
    private _timeouts;
    get timeouts(): Cloudfunctions2FunctionTimeoutsOutputReference;
    putTimeouts(value: Cloudfunctions2FunctionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | Cloudfunctions2FunctionTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
