/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeNetworkAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * The connection preference of service attachment. The value can be set to ACCEPT_AUTOMATIC. An ACCEPT_AUTOMATIC service attachment is one that always accepts the connection from consumer forwarding rules. Possible values: ["ACCEPT_AUTOMATIC", "ACCEPT_MANUAL", "INVALID"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_attachment#connection_preference ComputeNetworkAttachment#connection_preference}
    */
    readonly connectionPreference: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_attachment#deletion_policy ComputeNetworkAttachment#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource. Provide this property when you create the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_attachment#description ComputeNetworkAttachment#description}
    */
    readonly description?: string;
    /**
    * Name of the resource. Provided by the client when the resource is created. The name must be 1-63 characters long, and comply with RFC1035. Specifically, the name must be 1-63 characters long and match the regular expression [a-z]([-a-z0-9]*[a-z0-9])? which means the first character must be a lowercase letter, and all following characters must be a dash, lowercase letter, or digit, except the last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_attachment#name ComputeNetworkAttachment#name}
    */
    readonly name: string;
    /**
    * Projects that are allowed to connect to this network attachment. The project can be specified using its id or number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_attachment#producer_accept_lists ComputeNetworkAttachment#producer_accept_lists}
    */
    readonly producerAcceptLists?: string[];
    /**
    * Projects that are not allowed to connect to this network attachment. The project can be specified using its id or number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_attachment#producer_reject_lists ComputeNetworkAttachment#producer_reject_lists}
    */
    readonly producerRejectLists?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_attachment#project ComputeNetworkAttachment#project}
    */
    readonly project?: string;
    /**
    * URL of the region where the network attachment resides. This field applies only to the region resource. You must specify this field as part of the HTTP request URL. It is not settable as a field in the request body.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_attachment#region ComputeNetworkAttachment#region}
    */
    readonly region?: string;
    /**
    * An array of URLs where each entry is the URL of a subnet provided by the service consumer to use for endpoints in the producers that connect to this network attachment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_attachment#subnetworks ComputeNetworkAttachment#subnetworks}
    */
    readonly subnetworks: string[];
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_attachment#timeouts ComputeNetworkAttachment#timeouts}
    */
    readonly timeouts?: ComputeNetworkAttachmentTimeouts;
}
export interface ComputeNetworkAttachmentConnectionEndpoints {
}
export declare function computeNetworkAttachmentConnectionEndpointsToTerraform(struct?: ComputeNetworkAttachmentConnectionEndpoints): any;
export declare function computeNetworkAttachmentConnectionEndpointsToHclTerraform(struct?: ComputeNetworkAttachmentConnectionEndpoints): any;
export declare class ComputeNetworkAttachmentConnectionEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeNetworkAttachmentConnectionEndpoints | undefined;
    set internalValue(value: ComputeNetworkAttachmentConnectionEndpoints | undefined);
    get ipAddress(): string;
    get projectIdOrNum(): string;
    get secondaryIpCidrRanges(): string;
    get status(): string;
    get subnetwork(): string;
}
export declare class ComputeNetworkAttachmentConnectionEndpointsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeNetworkAttachmentConnectionEndpointsOutputReference;
}
export interface ComputeNetworkAttachmentTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_attachment#create ComputeNetworkAttachment#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_attachment#delete ComputeNetworkAttachment#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_attachment#update ComputeNetworkAttachment#update}
    */
    readonly update?: string;
}
export declare function computeNetworkAttachmentTimeoutsToTerraform(struct?: ComputeNetworkAttachmentTimeouts | cdktn.IResolvable): any;
export declare function computeNetworkAttachmentTimeoutsToHclTerraform(struct?: ComputeNetworkAttachmentTimeouts | cdktn.IResolvable): any;
export declare class ComputeNetworkAttachmentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeNetworkAttachmentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeNetworkAttachmentTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_attachment google_compute_network_attachment}
*/
export declare class ComputeNetworkAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_network_attachment";
    /**
    * Generates CDKTN code for importing a ComputeNetworkAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeNetworkAttachment to import
    * @param importFromId The id of the existing ComputeNetworkAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeNetworkAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_attachment google_compute_network_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeNetworkAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: ComputeNetworkAttachmentConfig);
    private _connectionEndpoints;
    get connectionEndpoints(): ComputeNetworkAttachmentConnectionEndpointsList;
    private _connectionPreference?;
    get connectionPreference(): string;
    set connectionPreference(value: string);
    get connectionPreferenceInput(): string | undefined;
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get fingerprint(): string;
    get id(): string;
    get kind(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get network(): string;
    private _producerAcceptLists?;
    get producerAcceptLists(): string[];
    set producerAcceptLists(value: string[]);
    resetProducerAcceptLists(): void;
    get producerAcceptListsInput(): string[] | undefined;
    private _producerRejectLists?;
    get producerRejectLists(): string[];
    set producerRejectLists(value: string[]);
    resetProducerRejectLists(): void;
    get producerRejectListsInput(): string[] | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get selfLink(): string;
    get selfLinkWithId(): string;
    private _subnetworks?;
    get subnetworks(): string[];
    set subnetworks(value: string[]);
    get subnetworksInput(): string[] | undefined;
    private _timeouts;
    get timeouts(): ComputeNetworkAttachmentTimeoutsOutputReference;
    putTimeouts(value: ComputeNetworkAttachmentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeNetworkAttachmentTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
