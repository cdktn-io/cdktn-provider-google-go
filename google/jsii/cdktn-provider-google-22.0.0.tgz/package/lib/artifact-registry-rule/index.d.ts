/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ArtifactRegistryRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The action this rule takes. Possible values: ["ACTION_UNSPECIFIED", "ALLOW", "DENY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_rule#action ArtifactRegistryRule#action}
    */
    readonly action?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_rule#deletion_policy ArtifactRegistryRule#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_rule#id ArtifactRegistryRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the repository's location. In addition to specific regions,
    * special values for multi-region locations are 'asia', 'europe', and 'us'.
    * See [here](https://cloud.google.com/artifact-registry/docs/repositories/repo-locations),
    * or use the
    * [google_artifact_registry_locations](https://registry.terraform.io/providers/hashicorp/google/latest/docs/data-sources/artifact_registry_locations)
    * data source for possible values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_rule#location ArtifactRegistryRule#location}
    */
    readonly location?: string;
    /**
    * The operation the rule applies to. Possible values: ["OPERATION_UNSPECIFIED", "DOWNLOAD"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_rule#operation ArtifactRegistryRule#operation}
    */
    readonly operation?: string;
    /**
    * The package ID the rule applies to. If empty, this rule applies to all
    * packages inside the repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_rule#package_id ArtifactRegistryRule#package_id}
    */
    readonly packageId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_rule#project ArtifactRegistryRule#project}
    */
    readonly project?: string;
    /**
    * The last part of the repository name, for example:
    * "repo1"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_rule#repository_id ArtifactRegistryRule#repository_id}
    */
    readonly repositoryId: string;
    /**
    * The rule id to use for this repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_rule#rule_id ArtifactRegistryRule#rule_id}
    */
    readonly ruleId: string;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_rule#condition ArtifactRegistryRule#condition}
    */
    readonly condition?: ArtifactRegistryRuleCondition;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_rule#timeouts ArtifactRegistryRule#timeouts}
    */
    readonly timeouts?: ArtifactRegistryRuleTimeouts;
}
export interface ArtifactRegistryRuleCondition {
    /**
    * Optional. Description of the expression. This is a longer text which
    * describes the expression, e.g. when hovered over it in a UI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_rule#description ArtifactRegistryRule#description}
    */
    readonly description?: string;
    /**
    * Textual representation of an expression in Common Expression Language syntax.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_rule#expression ArtifactRegistryRule#expression}
    */
    readonly expression: string;
    /**
    * Optional. String indicating the location of the expression for error
    * reporting, e.g. a file name and a position in the file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_rule#location ArtifactRegistryRule#location}
    */
    readonly location?: string;
    /**
    * Optional. Title for the expression, i.e. a short string describing its purpose.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_rule#title ArtifactRegistryRule#title}
    */
    readonly title?: string;
}
export declare function artifactRegistryRuleConditionToTerraform(struct?: ArtifactRegistryRuleConditionOutputReference | ArtifactRegistryRuleCondition): any;
export declare function artifactRegistryRuleConditionToHclTerraform(struct?: ArtifactRegistryRuleConditionOutputReference | ArtifactRegistryRuleCondition): any;
export declare class ArtifactRegistryRuleConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryRuleCondition | undefined;
    set internalValue(value: ArtifactRegistryRuleCondition | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
}
export interface ArtifactRegistryRuleTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_rule#create ArtifactRegistryRule#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_rule#delete ArtifactRegistryRule#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_rule#update ArtifactRegistryRule#update}
    */
    readonly update?: string;
}
export declare function artifactRegistryRuleTimeoutsToTerraform(struct?: ArtifactRegistryRuleTimeouts | cdktn.IResolvable): any;
export declare function artifactRegistryRuleTimeoutsToHclTerraform(struct?: ArtifactRegistryRuleTimeouts | cdktn.IResolvable): any;
export declare class ArtifactRegistryRuleTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryRuleTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ArtifactRegistryRuleTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_rule google_artifact_registry_rule}
*/
export declare class ArtifactRegistryRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_artifact_registry_rule";
    /**
    * Generates CDKTN code for importing a ArtifactRegistryRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ArtifactRegistryRule to import
    * @param importFromId The id of the existing ArtifactRegistryRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ArtifactRegistryRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_rule google_artifact_registry_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ArtifactRegistryRuleConfig
    */
    constructor(scope: Construct, id: string, config: ArtifactRegistryRuleConfig);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    get name(): string;
    private _operation?;
    get operation(): string;
    set operation(value: string);
    resetOperation(): void;
    get operationInput(): string | undefined;
    private _packageId?;
    get packageId(): string;
    set packageId(value: string);
    resetPackageId(): void;
    get packageIdInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _repositoryId?;
    get repositoryId(): string;
    set repositoryId(value: string);
    get repositoryIdInput(): string | undefined;
    private _ruleId?;
    get ruleId(): string;
    set ruleId(value: string);
    get ruleIdInput(): string | undefined;
    private _condition;
    get condition(): ArtifactRegistryRuleConditionOutputReference;
    putCondition(value: ArtifactRegistryRuleCondition): void;
    resetCondition(): void;
    get conditionInput(): ArtifactRegistryRuleCondition | undefined;
    private _timeouts;
    get timeouts(): ArtifactRegistryRuleTimeoutsOutputReference;
    putTimeouts(value: ArtifactRegistryRuleTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ArtifactRegistryRuleTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
