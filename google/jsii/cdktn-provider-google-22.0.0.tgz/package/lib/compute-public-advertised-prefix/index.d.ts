/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputePublicAdvertisedPrefixConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_public_advertised_prefix#deletion_policy ComputePublicAdvertisedPrefix#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_public_advertised_prefix#description ComputePublicAdvertisedPrefix#description}
    */
    readonly description?: string;
    /**
    * The IPv4 address to be used for reverse DNS verification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_public_advertised_prefix#dns_verification_ip ComputePublicAdvertisedPrefix#dns_verification_ip}
    */
    readonly dnsVerificationIp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_public_advertised_prefix#id ComputePublicAdvertisedPrefix#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The address range, in CIDR format, represented by this public advertised prefix.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_public_advertised_prefix#ip_cidr_range ComputePublicAdvertisedPrefix#ip_cidr_range}
    */
    readonly ipCidrRange: string;
    /**
    * The internet access type for IPv6 Public Advertised Prefixes. It can be
    * set to one of following:
    *   * EXTERNAL: Default access type. The prefix will be announced to the
    *   internet. All children PDPs will have access type as EXTERNAL.
    *   * INTERNAL: The prefix won’t be announced to the internet. Prefix will
    *   be used privately within Google Cloud. All children PDPs will have
    *   access type as INTERNAL. Possible values: ["EXTERNAL", "INTERNAL"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_public_advertised_prefix#ipv6_access_type ComputePublicAdvertisedPrefix#ipv6_access_type}
    */
    readonly ipv6AccessType?: string;
    /**
    * Name of the resource. The name must be 1-63 characters long, and
    * comply with RFC1035. Specifically, the name must be 1-63 characters
    * long and match the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?'
    * which means the first character must be a lowercase letter, and all
    * following characters must be a dash, lowercase letter, or digit,
    * except the last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_public_advertised_prefix#name ComputePublicAdvertisedPrefix#name}
    */
    readonly name: string;
    /**
    * Specifies how child public delegated prefix will be scoped. pdpScope
    * must be one of: GLOBAL, REGIONAL
    * * REGIONAL: The public delegated prefix is regional only. The
    * provisioning will take a few minutes.
    * * GLOBAL: The public delegated prefix is global only. The provisioning
    * will take ~4 weeks. Possible values: ["GLOBAL", "REGIONAL"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_public_advertised_prefix#pdp_scope ComputePublicAdvertisedPrefix#pdp_scope}
    */
    readonly pdpScope?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_public_advertised_prefix#project ComputePublicAdvertisedPrefix#project}
    */
    readonly project?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_public_advertised_prefix#timeouts ComputePublicAdvertisedPrefix#timeouts}
    */
    readonly timeouts?: ComputePublicAdvertisedPrefixTimeouts;
}
export interface ComputePublicAdvertisedPrefixTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_public_advertised_prefix#create ComputePublicAdvertisedPrefix#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_public_advertised_prefix#delete ComputePublicAdvertisedPrefix#delete}
    */
    readonly delete?: string;
}
export declare function computePublicAdvertisedPrefixTimeoutsToTerraform(struct?: ComputePublicAdvertisedPrefixTimeouts | cdktn.IResolvable): any;
export declare function computePublicAdvertisedPrefixTimeoutsToHclTerraform(struct?: ComputePublicAdvertisedPrefixTimeouts | cdktn.IResolvable): any;
export declare class ComputePublicAdvertisedPrefixTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputePublicAdvertisedPrefixTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputePublicAdvertisedPrefixTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_public_advertised_prefix google_compute_public_advertised_prefix}
*/
export declare class ComputePublicAdvertisedPrefix extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_public_advertised_prefix";
    /**
    * Generates CDKTN code for importing a ComputePublicAdvertisedPrefix resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputePublicAdvertisedPrefix to import
    * @param importFromId The id of the existing ComputePublicAdvertisedPrefix that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_public_advertised_prefix#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputePublicAdvertisedPrefix to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_public_advertised_prefix google_compute_public_advertised_prefix} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputePublicAdvertisedPrefixConfig
    */
    constructor(scope: Construct, id: string, config: ComputePublicAdvertisedPrefixConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _dnsVerificationIp?;
    get dnsVerificationIp(): string;
    set dnsVerificationIp(value: string);
    resetDnsVerificationIp(): void;
    get dnsVerificationIpInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipCidrRange?;
    get ipCidrRange(): string;
    set ipCidrRange(value: string);
    get ipCidrRangeInput(): string | undefined;
    private _ipv6AccessType?;
    get ipv6AccessType(): string;
    set ipv6AccessType(value: string);
    resetIpv6AccessType(): void;
    get ipv6AccessTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _pdpScope?;
    get pdpScope(): string;
    set pdpScope(value: string);
    resetPdpScope(): void;
    get pdpScopeInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get selfLink(): string;
    get sharedSecret(): string;
    private _timeouts;
    get timeouts(): ComputePublicAdvertisedPrefixTimeoutsOutputReference;
    putTimeouts(value: ComputePublicAdvertisedPrefixTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputePublicAdvertisedPrefixTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
