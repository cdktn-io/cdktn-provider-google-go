/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeFirewallPolicyRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Action to perform when the client connection triggers the rule. Valid actions are "allow", "deny", "goto_next" and "apply_security_profile_group".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#action ComputeFirewallPolicyRule#action}
    */
    readonly action: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#deletion_policy ComputeFirewallPolicyRule#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description for this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#description ComputeFirewallPolicyRule#description}
    */
    readonly description?: string;
    /**
    * The direction in which this rule applies. Possible values: ["INGRESS", "EGRESS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#direction ComputeFirewallPolicyRule#direction}
    */
    readonly direction: string;
    /**
    * Denotes whether the firewall policy rule is disabled.
    * When set to true, the firewall policy rule is not enforced and traffic behaves as if it did not exist.
    * If this is unspecified, the firewall policy rule will be enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#disabled ComputeFirewallPolicyRule#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Denotes whether to enable logging for a particular rule.
    * If logging is enabled, logs will be exported to the configured export destination in Stackdriver.
    * Logs may be exported to BigQuery or Pub/Sub.
    * Note: you cannot enable logging on "goto_next" rules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#enable_logging ComputeFirewallPolicyRule#enable_logging}
    */
    readonly enableLogging?: boolean | cdktn.IResolvable;
    /**
    * The firewall policy of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#firewall_policy ComputeFirewallPolicyRule#firewall_policy}
    */
    readonly firewallPolicy: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#id ComputeFirewallPolicyRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * An integer indicating the priority of a rule in the list.
    * The priority must be a positive value between 0 and 2147483647.
    * Rules are evaluated from highest to lowest priority where 0 is the highest priority and 2147483647 is the lowest prority.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#priority ComputeFirewallPolicyRule#priority}
    */
    readonly priority: number;
    /**
    * A fully-qualified URL of a SecurityProfile resource instance.
    * Example: https://networksecurity.googleapis.com/v1/projects/{project}/locations/{location}/securityProfileGroups/my-security-profile-group
    * Must be specified if action = 'apply_security_profile_group' and cannot be specified for other actions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#security_profile_group ComputeFirewallPolicyRule#security_profile_group}
    */
    readonly securityProfileGroup?: string;
    /**
    * A list of network resource URLs to which this rule applies.
    * This field allows you to control which network's VMs get this rule.
    * If this field is left blank, all VMs within the organization will receive the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#target_resources ComputeFirewallPolicyRule#target_resources}
    */
    readonly targetResources?: string[];
    /**
    * A list of service accounts indicating the sets of instances that are applied with this rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#target_service_accounts ComputeFirewallPolicyRule#target_service_accounts}
    */
    readonly targetServiceAccounts?: string[];
    /**
    * Boolean flag indicating if the traffic should be TLS decrypted.
    * Can be set only if action = 'apply_security_profile_group' and cannot be set for other actions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#tls_inspect ComputeFirewallPolicyRule#tls_inspect}
    */
    readonly tlsInspect?: boolean | cdktn.IResolvable;
    /**
    * match block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#match ComputeFirewallPolicyRule#match}
    */
    readonly match: ComputeFirewallPolicyRuleMatch;
    /**
    * target_secure_tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#target_secure_tags ComputeFirewallPolicyRule#target_secure_tags}
    */
    readonly targetSecureTags?: ComputeFirewallPolicyRuleTargetSecureTags[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#timeouts ComputeFirewallPolicyRule#timeouts}
    */
    readonly timeouts?: ComputeFirewallPolicyRuleTimeouts;
}
export interface ComputeFirewallPolicyRuleMatchLayer4Configs {
    /**
    * The IP protocol to which this rule applies. The protocol type is required when creating a firewall rule.
    * This value can either be one of the following well known protocol strings (tcp, udp, icmp, esp, ah, ipip, sctp), or the IP protocol number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#ip_protocol ComputeFirewallPolicyRule#ip_protocol}
    */
    readonly ipProtocol: string;
    /**
    * An optional list of ports to which this rule applies. This field is only applicable for UDP or TCP protocol. Each entry must be either an integer or a range. If not specified, this rule applies to connections through any port.
    * Example inputs include: ["22"], ["80","443"], and ["12345-12349"].
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#ports ComputeFirewallPolicyRule#ports}
    */
    readonly ports?: string[];
}
export declare function computeFirewallPolicyRuleMatchLayer4ConfigsToTerraform(struct?: ComputeFirewallPolicyRuleMatchLayer4Configs | cdktn.IResolvable): any;
export declare function computeFirewallPolicyRuleMatchLayer4ConfigsToHclTerraform(struct?: ComputeFirewallPolicyRuleMatchLayer4Configs | cdktn.IResolvable): any;
export declare class ComputeFirewallPolicyRuleMatchLayer4ConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeFirewallPolicyRuleMatchLayer4Configs | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeFirewallPolicyRuleMatchLayer4Configs | cdktn.IResolvable | undefined);
    private _ipProtocol?;
    get ipProtocol(): string;
    set ipProtocol(value: string);
    get ipProtocolInput(): string | undefined;
    private _ports?;
    get ports(): string[];
    set ports(value: string[]);
    resetPorts(): void;
    get portsInput(): string[] | undefined;
}
export declare class ComputeFirewallPolicyRuleMatchLayer4ConfigsList extends cdktn.ComplexList {
    internalValue?: ComputeFirewallPolicyRuleMatchLayer4Configs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeFirewallPolicyRuleMatchLayer4ConfigsOutputReference;
}
export interface ComputeFirewallPolicyRuleMatchSrcSecureTags {
    /**
    * Name of the secure tag, created with TagManager's TagValue API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#name ComputeFirewallPolicyRule#name}
    */
    readonly name?: string;
}
export declare function computeFirewallPolicyRuleMatchSrcSecureTagsToTerraform(struct?: ComputeFirewallPolicyRuleMatchSrcSecureTags | cdktn.IResolvable): any;
export declare function computeFirewallPolicyRuleMatchSrcSecureTagsToHclTerraform(struct?: ComputeFirewallPolicyRuleMatchSrcSecureTags | cdktn.IResolvable): any;
export declare class ComputeFirewallPolicyRuleMatchSrcSecureTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeFirewallPolicyRuleMatchSrcSecureTags | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeFirewallPolicyRuleMatchSrcSecureTags | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get state(): string;
}
export declare class ComputeFirewallPolicyRuleMatchSrcSecureTagsList extends cdktn.ComplexList {
    internalValue?: ComputeFirewallPolicyRuleMatchSrcSecureTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeFirewallPolicyRuleMatchSrcSecureTagsOutputReference;
}
export interface ComputeFirewallPolicyRuleMatch {
    /**
    * Address groups which should be matched against the traffic destination. Maximum number of destination address groups is 10.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#dest_address_groups ComputeFirewallPolicyRule#dest_address_groups}
    */
    readonly destAddressGroups?: string[];
    /**
    * Fully Qualified Domain Name (FQDN) which should be matched against traffic destination. Maximum number of destination fqdn allowed is 100.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#dest_fqdns ComputeFirewallPolicyRule#dest_fqdns}
    */
    readonly destFqdns?: string[];
    /**
    * CIDR IP address range. Maximum number of destination CIDR IP ranges allowed is 5000.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#dest_ip_ranges ComputeFirewallPolicyRule#dest_ip_ranges}
    */
    readonly destIpRanges?: string[];
    /**
    * Network context of the traffic destination. Possible values: ["UNSPECIFIED", "INTERNET", "INTRA_VPC", "NON_INTERNET", "VPC_NETWORKS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#dest_network_context ComputeFirewallPolicyRule#dest_network_context}
    */
    readonly destNetworkContext?: string;
    /**
    * Region codes whose IP addresses will be used to match for destination of traffic. Should be specified as 2 letter country code defined as per ISO 3166 alpha-2 country codes. ex."US" Maximum number of dest region codes allowed is 5000.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#dest_region_codes ComputeFirewallPolicyRule#dest_region_codes}
    */
    readonly destRegionCodes?: string[];
    /**
    * Names of Network Threat Intelligence lists. The IPs in these lists will be matched against traffic destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#dest_threat_intelligences ComputeFirewallPolicyRule#dest_threat_intelligences}
    */
    readonly destThreatIntelligences?: string[];
    /**
    * Address groups which should be matched against the traffic source. Maximum number of source address groups is 10.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#src_address_groups ComputeFirewallPolicyRule#src_address_groups}
    */
    readonly srcAddressGroups?: string[];
    /**
    * Fully Qualified Domain Name (FQDN) which should be matched against traffic source. Maximum number of source fqdn allowed is 100.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#src_fqdns ComputeFirewallPolicyRule#src_fqdns}
    */
    readonly srcFqdns?: string[];
    /**
    * CIDR IP address range. Maximum number of source CIDR IP ranges allowed is 5000.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#src_ip_ranges ComputeFirewallPolicyRule#src_ip_ranges}
    */
    readonly srcIpRanges?: string[];
    /**
    * Network context of the traffic source. Possible values: ["UNSPECIFIED", "INTERNET", "INTRA_VPC", "NON_INTERNET", "VPC_NETWORKS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#src_network_context ComputeFirewallPolicyRule#src_network_context}
    */
    readonly srcNetworkContext?: string;
    /**
    * Networks of the traffic source. It can be either a full or partial url.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#src_networks ComputeFirewallPolicyRule#src_networks}
    */
    readonly srcNetworks?: string[];
    /**
    * Region codes whose IP addresses will be used to match for source of traffic. Should be specified as 2 letter country code defined as per ISO 3166 alpha-2 country codes. ex."US" Maximum number of source region codes allowed is 5000.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#src_region_codes ComputeFirewallPolicyRule#src_region_codes}
    */
    readonly srcRegionCodes?: string[];
    /**
    * Names of Network Threat Intelligence lists. The IPs in these lists will be matched against traffic source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#src_threat_intelligences ComputeFirewallPolicyRule#src_threat_intelligences}
    */
    readonly srcThreatIntelligences?: string[];
    /**
    * layer4_configs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#layer4_configs ComputeFirewallPolicyRule#layer4_configs}
    */
    readonly layer4Configs: ComputeFirewallPolicyRuleMatchLayer4Configs[] | cdktn.IResolvable;
    /**
    * src_secure_tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#src_secure_tags ComputeFirewallPolicyRule#src_secure_tags}
    */
    readonly srcSecureTags?: ComputeFirewallPolicyRuleMatchSrcSecureTags[] | cdktn.IResolvable;
}
export declare function computeFirewallPolicyRuleMatchToTerraform(struct?: ComputeFirewallPolicyRuleMatchOutputReference | ComputeFirewallPolicyRuleMatch): any;
export declare function computeFirewallPolicyRuleMatchToHclTerraform(struct?: ComputeFirewallPolicyRuleMatchOutputReference | ComputeFirewallPolicyRuleMatch): any;
export declare class ComputeFirewallPolicyRuleMatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeFirewallPolicyRuleMatch | undefined;
    set internalValue(value: ComputeFirewallPolicyRuleMatch | undefined);
    private _destAddressGroups?;
    get destAddressGroups(): string[];
    set destAddressGroups(value: string[]);
    resetDestAddressGroups(): void;
    get destAddressGroupsInput(): string[] | undefined;
    private _destFqdns?;
    get destFqdns(): string[];
    set destFqdns(value: string[]);
    resetDestFqdns(): void;
    get destFqdnsInput(): string[] | undefined;
    private _destIpRanges?;
    get destIpRanges(): string[];
    set destIpRanges(value: string[]);
    resetDestIpRanges(): void;
    get destIpRangesInput(): string[] | undefined;
    private _destNetworkContext?;
    get destNetworkContext(): string;
    set destNetworkContext(value: string);
    resetDestNetworkContext(): void;
    get destNetworkContextInput(): string | undefined;
    private _destRegionCodes?;
    get destRegionCodes(): string[];
    set destRegionCodes(value: string[]);
    resetDestRegionCodes(): void;
    get destRegionCodesInput(): string[] | undefined;
    private _destThreatIntelligences?;
    get destThreatIntelligences(): string[];
    set destThreatIntelligences(value: string[]);
    resetDestThreatIntelligences(): void;
    get destThreatIntelligencesInput(): string[] | undefined;
    private _srcAddressGroups?;
    get srcAddressGroups(): string[];
    set srcAddressGroups(value: string[]);
    resetSrcAddressGroups(): void;
    get srcAddressGroupsInput(): string[] | undefined;
    private _srcFqdns?;
    get srcFqdns(): string[];
    set srcFqdns(value: string[]);
    resetSrcFqdns(): void;
    get srcFqdnsInput(): string[] | undefined;
    private _srcIpRanges?;
    get srcIpRanges(): string[];
    set srcIpRanges(value: string[]);
    resetSrcIpRanges(): void;
    get srcIpRangesInput(): string[] | undefined;
    private _srcNetworkContext?;
    get srcNetworkContext(): string;
    set srcNetworkContext(value: string);
    resetSrcNetworkContext(): void;
    get srcNetworkContextInput(): string | undefined;
    private _srcNetworks?;
    get srcNetworks(): string[];
    set srcNetworks(value: string[]);
    resetSrcNetworks(): void;
    get srcNetworksInput(): string[] | undefined;
    private _srcRegionCodes?;
    get srcRegionCodes(): string[];
    set srcRegionCodes(value: string[]);
    resetSrcRegionCodes(): void;
    get srcRegionCodesInput(): string[] | undefined;
    private _srcThreatIntelligences?;
    get srcThreatIntelligences(): string[];
    set srcThreatIntelligences(value: string[]);
    resetSrcThreatIntelligences(): void;
    get srcThreatIntelligencesInput(): string[] | undefined;
    private _layer4Configs;
    get layer4Configs(): ComputeFirewallPolicyRuleMatchLayer4ConfigsList;
    putLayer4Configs(value: ComputeFirewallPolicyRuleMatchLayer4Configs[] | cdktn.IResolvable): void;
    get layer4ConfigsInput(): cdktn.IResolvable | ComputeFirewallPolicyRuleMatchLayer4Configs[] | undefined;
    private _srcSecureTags;
    get srcSecureTags(): ComputeFirewallPolicyRuleMatchSrcSecureTagsList;
    putSrcSecureTags(value: ComputeFirewallPolicyRuleMatchSrcSecureTags[] | cdktn.IResolvable): void;
    resetSrcSecureTags(): void;
    get srcSecureTagsInput(): cdktn.IResolvable | ComputeFirewallPolicyRuleMatchSrcSecureTags[] | undefined;
}
export interface ComputeFirewallPolicyRuleTargetSecureTags {
    /**
    * Name of the secure tag, created with TagManager's TagValue API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#name ComputeFirewallPolicyRule#name}
    */
    readonly name?: string;
}
export declare function computeFirewallPolicyRuleTargetSecureTagsToTerraform(struct?: ComputeFirewallPolicyRuleTargetSecureTags | cdktn.IResolvable): any;
export declare function computeFirewallPolicyRuleTargetSecureTagsToHclTerraform(struct?: ComputeFirewallPolicyRuleTargetSecureTags | cdktn.IResolvable): any;
export declare class ComputeFirewallPolicyRuleTargetSecureTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeFirewallPolicyRuleTargetSecureTags | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeFirewallPolicyRuleTargetSecureTags | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get state(): string;
}
export declare class ComputeFirewallPolicyRuleTargetSecureTagsList extends cdktn.ComplexList {
    internalValue?: ComputeFirewallPolicyRuleTargetSecureTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeFirewallPolicyRuleTargetSecureTagsOutputReference;
}
export interface ComputeFirewallPolicyRuleTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#create ComputeFirewallPolicyRule#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#delete ComputeFirewallPolicyRule#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#update ComputeFirewallPolicyRule#update}
    */
    readonly update?: string;
}
export declare function computeFirewallPolicyRuleTimeoutsToTerraform(struct?: ComputeFirewallPolicyRuleTimeouts | cdktn.IResolvable): any;
export declare function computeFirewallPolicyRuleTimeoutsToHclTerraform(struct?: ComputeFirewallPolicyRuleTimeouts | cdktn.IResolvable): any;
export declare class ComputeFirewallPolicyRuleTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeFirewallPolicyRuleTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeFirewallPolicyRuleTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule google_compute_firewall_policy_rule}
*/
export declare class ComputeFirewallPolicyRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_firewall_policy_rule";
    /**
    * Generates CDKTN code for importing a ComputeFirewallPolicyRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeFirewallPolicyRule to import
    * @param importFromId The id of the existing ComputeFirewallPolicyRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeFirewallPolicyRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_firewall_policy_rule google_compute_firewall_policy_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeFirewallPolicyRuleConfig
    */
    constructor(scope: Construct, id: string, config: ComputeFirewallPolicyRuleConfig);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    get directionInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _enableLogging?;
    get enableLogging(): boolean | cdktn.IResolvable;
    set enableLogging(value: boolean | cdktn.IResolvable);
    resetEnableLogging(): void;
    get enableLoggingInput(): boolean | cdktn.IResolvable | undefined;
    private _firewallPolicy?;
    get firewallPolicy(): string;
    set firewallPolicy(value: string);
    get firewallPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get kind(): string;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
    get ruleTupleCount(): number;
    private _securityProfileGroup?;
    get securityProfileGroup(): string;
    set securityProfileGroup(value: string);
    resetSecurityProfileGroup(): void;
    get securityProfileGroupInput(): string | undefined;
    private _targetResources?;
    get targetResources(): string[];
    set targetResources(value: string[]);
    resetTargetResources(): void;
    get targetResourcesInput(): string[] | undefined;
    private _targetServiceAccounts?;
    get targetServiceAccounts(): string[];
    set targetServiceAccounts(value: string[]);
    resetTargetServiceAccounts(): void;
    get targetServiceAccountsInput(): string[] | undefined;
    private _tlsInspect?;
    get tlsInspect(): boolean | cdktn.IResolvable;
    set tlsInspect(value: boolean | cdktn.IResolvable);
    resetTlsInspect(): void;
    get tlsInspectInput(): boolean | cdktn.IResolvable | undefined;
    private _match;
    get match(): ComputeFirewallPolicyRuleMatchOutputReference;
    putMatch(value: ComputeFirewallPolicyRuleMatch): void;
    get matchInput(): ComputeFirewallPolicyRuleMatch | undefined;
    private _targetSecureTags;
    get targetSecureTags(): ComputeFirewallPolicyRuleTargetSecureTagsList;
    putTargetSecureTags(value: ComputeFirewallPolicyRuleTargetSecureTags[] | cdktn.IResolvable): void;
    resetTargetSecureTags(): void;
    get targetSecureTagsInput(): cdktn.IResolvable | ComputeFirewallPolicyRuleTargetSecureTags[] | undefined;
    private _timeouts;
    get timeouts(): ComputeFirewallPolicyRuleTimeoutsOutputReference;
    putTimeouts(value: ComputeFirewallPolicyRuleTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeFirewallPolicyRuleTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
