/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChronicleRuleDeploymentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether detections resulting from this deployment should be considered
    * alerts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_rule_deployment#alerting ChronicleRuleDeployment#alerting}
    */
    readonly alerting?: boolean | cdktn.IResolvable;
    /**
    * The archive state of the rule deployment.
    * Cannot be set to true unless enabled is set to false i.e.
    * archiving requires a two-step process: first, disable the rule by
    * setting 'enabled' to false, then set 'archive' to true.
    * If set to true, alerting will automatically be set to false.
    * If currently set to true, enabled, alerting, and run_frequency cannot be
    * updated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_rule_deployment#archived ChronicleRuleDeployment#archived}
    */
    readonly archived?: boolean | cdktn.IResolvable;
    /**
    * Whether the rule is currently deployed continuously against incoming data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_rule_deployment#enabled ChronicleRuleDeployment#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_rule_deployment#id ChronicleRuleDeployment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The unique identifier for the Chronicle instance, which is the same as the customer ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_rule_deployment#instance ChronicleRuleDeployment#instance}
    */
    readonly instance: string;
    /**
    * The location of the resource. This is the geographical region where the Chronicle instance resides, such as "us" or "europe-west2".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_rule_deployment#location ChronicleRuleDeployment#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_rule_deployment#project ChronicleRuleDeployment#project}
    */
    readonly project?: string;
    /**
    * The Rule ID of the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_rule_deployment#rule ChronicleRuleDeployment#rule}
    */
    readonly rule: string;
    /**
    * The run frequency of the rule deployment.
    * Possible values:
    * LIVE
    * HOURLY
    * DAILY
    * LIVE_CUSTOMIZABLE
    * HOURLY_CUSTOMIZABLE
    *
    * Note: Certain legacy run frequencies are deprecated. For multi-event rules, use LIVE_CUSTOMIZABLE or HOURLY_CUSTOMIZABLE (for match windows <=2d), or DAILY (for match windows >2d).
    * Legacy values LIVE and HOURLY are mapped to their customizable counterparts on the backend. DAILY for <=2d match window multi-event rules will be happed to HOURLY_CUSTOMIZABLE.
    * For single-event rules, HOURLY and DAILY are deprecated and mapped to LIVE. If you continue to use deprecated values in your Terraform configuration, Terraform will silently
    * suppress the diff and ignore the changes to prevent infinite update loops.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_rule_deployment#run_frequency ChronicleRuleDeployment#run_frequency}
    */
    readonly runFrequency?: string;
    /**
    * schedule_customizations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_rule_deployment#schedule_customizations ChronicleRuleDeployment#schedule_customizations}
    */
    readonly scheduleCustomizations?: ChronicleRuleDeploymentScheduleCustomizations;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_rule_deployment#timeouts ChronicleRuleDeployment#timeouts}
    */
    readonly timeouts?: ChronicleRuleDeploymentTimeouts;
}
export interface ChronicleRuleDeploymentScheduleCustomizations {
    /**
    * Indicates whether to add additional delays and runs to rules to ensure
    * enrichment completeness, with the trade-off of more late-arriving detections.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_rule_deployment#ensure_enrichment_completeness ChronicleRuleDeployment#ensure_enrichment_completeness}
    */
    readonly ensureEnrichmentCompleteness?: boolean | cdktn.IResolvable;
    /**
    * Delay the first rule execution run to account for late-arriving data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_rule_deployment#late_arriving_data_adjustment ChronicleRuleDeployment#late_arriving_data_adjustment}
    */
    readonly lateArrivingDataAdjustment?: string;
}
export declare function chronicleRuleDeploymentScheduleCustomizationsToTerraform(struct?: ChronicleRuleDeploymentScheduleCustomizationsOutputReference | ChronicleRuleDeploymentScheduleCustomizations): any;
export declare function chronicleRuleDeploymentScheduleCustomizationsToHclTerraform(struct?: ChronicleRuleDeploymentScheduleCustomizationsOutputReference | ChronicleRuleDeploymentScheduleCustomizations): any;
export declare class ChronicleRuleDeploymentScheduleCustomizationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleRuleDeploymentScheduleCustomizations | undefined;
    set internalValue(value: ChronicleRuleDeploymentScheduleCustomizations | undefined);
    private _ensureEnrichmentCompleteness?;
    get ensureEnrichmentCompleteness(): boolean | cdktn.IResolvable;
    set ensureEnrichmentCompleteness(value: boolean | cdktn.IResolvable);
    resetEnsureEnrichmentCompleteness(): void;
    get ensureEnrichmentCompletenessInput(): boolean | cdktn.IResolvable | undefined;
    private _lateArrivingDataAdjustment?;
    get lateArrivingDataAdjustment(): string;
    set lateArrivingDataAdjustment(value: string);
    resetLateArrivingDataAdjustment(): void;
    get lateArrivingDataAdjustmentInput(): string | undefined;
}
export interface ChronicleRuleDeploymentTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_rule_deployment#create ChronicleRuleDeployment#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_rule_deployment#delete ChronicleRuleDeployment#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_rule_deployment#update ChronicleRuleDeployment#update}
    */
    readonly update?: string;
}
export declare function chronicleRuleDeploymentTimeoutsToTerraform(struct?: ChronicleRuleDeploymentTimeouts | cdktn.IResolvable): any;
export declare function chronicleRuleDeploymentTimeoutsToHclTerraform(struct?: ChronicleRuleDeploymentTimeouts | cdktn.IResolvable): any;
export declare class ChronicleRuleDeploymentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleRuleDeploymentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleRuleDeploymentTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_rule_deployment google_chronicle_rule_deployment}
*/
export declare class ChronicleRuleDeployment extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_chronicle_rule_deployment";
    /**
    * Generates CDKTN code for importing a ChronicleRuleDeployment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChronicleRuleDeployment to import
    * @param importFromId The id of the existing ChronicleRuleDeployment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_rule_deployment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChronicleRuleDeployment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_rule_deployment google_chronicle_rule_deployment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChronicleRuleDeploymentConfig
    */
    constructor(scope: Construct, id: string, config: ChronicleRuleDeploymentConfig);
    private _alerting?;
    get alerting(): boolean | cdktn.IResolvable;
    set alerting(value: boolean | cdktn.IResolvable);
    resetAlerting(): void;
    get alertingInput(): boolean | cdktn.IResolvable | undefined;
    get archiveTime(): string;
    private _archived?;
    get archived(): boolean | cdktn.IResolvable;
    set archived(value: boolean | cdktn.IResolvable);
    resetArchived(): void;
    get archivedInput(): boolean | cdktn.IResolvable | undefined;
    get consumerRules(): string[];
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get executionState(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instance?;
    get instance(): string;
    set instance(value: string);
    get instanceInput(): string | undefined;
    get lastAlertStatusChangeTime(): string;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    get producerRules(): string[];
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _rule?;
    get rule(): string;
    set rule(value: string);
    get ruleInput(): string | undefined;
    private _runFrequency?;
    get runFrequency(): string;
    set runFrequency(value: string);
    resetRunFrequency(): void;
    get runFrequencyInput(): string | undefined;
    private _scheduleCustomizations;
    get scheduleCustomizations(): ChronicleRuleDeploymentScheduleCustomizationsOutputReference;
    putScheduleCustomizations(value: ChronicleRuleDeploymentScheduleCustomizations): void;
    resetScheduleCustomizations(): void;
    get scheduleCustomizationsInput(): ChronicleRuleDeploymentScheduleCustomizations | undefined;
    private _timeouts;
    get timeouts(): ChronicleRuleDeploymentTimeoutsOutputReference;
    putTimeouts(value: ChronicleRuleDeploymentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ChronicleRuleDeploymentTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
