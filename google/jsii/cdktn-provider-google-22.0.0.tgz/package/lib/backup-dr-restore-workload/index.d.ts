/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BackupDrRestoreWorkloadConfig extends cdktn.TerraformMetaArguments {
    /**
    * Required. The ID of the backup to restore from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#backup_id BackupDrRestoreWorkload#backup_id}
    */
    readonly backupId: string;
    /**
    * Required. The ID of the backup vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#backup_vault_id BackupDrRestoreWorkload#backup_vault_id}
    */
    readonly backupVaultId: string;
    /**
    * Optional. A field mask used to clear server-side default values during restore.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#clear_overrides_field_mask BackupDrRestoreWorkload#clear_overrides_field_mask}
    */
    readonly clearOverridesFieldMask?: string;
    /**
    * Required. The ID of the data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#data_source_id BackupDrRestoreWorkload#data_source_id}
    */
    readonly dataSourceId: string;
    /**
    * Optional. If true (default), running terraform destroy will delete the live resource in GCP.
    * If false, only the restore record is removed from the state, leaving the resource active.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#delete_restored_instance BackupDrRestoreWorkload#delete_restored_instance}
    */
    readonly deleteRestoredInstance?: boolean | cdktn.IResolvable;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#deletion_policy BackupDrRestoreWorkload#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#id BackupDrRestoreWorkload#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Required. The location for the backup vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#location BackupDrRestoreWorkload#location}
    */
    readonly location: string;
    /**
    * The resource name of the backup instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#name BackupDrRestoreWorkload#name}
    */
    readonly name?: string;
    /**
    * Optional. An optional request ID to identify requests. Specify a unique request ID
    * so that if you must retry your request, the server will know to ignore
    * the request if it has already been completed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#request_id BackupDrRestoreWorkload#request_id}
    */
    readonly requestId?: string;
    /**
    * compute_instance_restore_properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#compute_instance_restore_properties BackupDrRestoreWorkload#compute_instance_restore_properties}
    */
    readonly computeInstanceRestoreProperties?: BackupDrRestoreWorkloadComputeInstanceRestoreProperties;
    /**
    * compute_instance_target_environment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#compute_instance_target_environment BackupDrRestoreWorkload#compute_instance_target_environment}
    */
    readonly computeInstanceTargetEnvironment?: BackupDrRestoreWorkloadComputeInstanceTargetEnvironment;
    /**
    * disk_restore_properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#disk_restore_properties BackupDrRestoreWorkload#disk_restore_properties}
    */
    readonly diskRestoreProperties?: BackupDrRestoreWorkloadDiskRestoreProperties;
    /**
    * disk_target_environment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#disk_target_environment BackupDrRestoreWorkload#disk_target_environment}
    */
    readonly diskTargetEnvironment?: BackupDrRestoreWorkloadDiskTargetEnvironment;
    /**
    * region_disk_target_environment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#region_disk_target_environment BackupDrRestoreWorkload#region_disk_target_environment}
    */
    readonly regionDiskTargetEnvironment?: BackupDrRestoreWorkloadRegionDiskTargetEnvironment;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#timeouts BackupDrRestoreWorkload#timeouts}
    */
    readonly timeouts?: BackupDrRestoreWorkloadTimeouts;
}
export interface BackupDrRestoreWorkloadTargetResourceGcpResource {
}
export declare function backupDrRestoreWorkloadTargetResourceGcpResourceToTerraform(struct?: BackupDrRestoreWorkloadTargetResourceGcpResource): any;
export declare function backupDrRestoreWorkloadTargetResourceGcpResourceToHclTerraform(struct?: BackupDrRestoreWorkloadTargetResourceGcpResource): any;
export declare class BackupDrRestoreWorkloadTargetResourceGcpResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupDrRestoreWorkloadTargetResourceGcpResource | undefined;
    set internalValue(value: BackupDrRestoreWorkloadTargetResourceGcpResource | undefined);
    get gcpResourcename(): string;
    get location(): string;
    get type(): string;
}
export declare class BackupDrRestoreWorkloadTargetResourceGcpResourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupDrRestoreWorkloadTargetResourceGcpResourceOutputReference;
}
export interface BackupDrRestoreWorkloadTargetResource {
}
export declare function backupDrRestoreWorkloadTargetResourceToTerraform(struct?: BackupDrRestoreWorkloadTargetResource): any;
export declare function backupDrRestoreWorkloadTargetResourceToHclTerraform(struct?: BackupDrRestoreWorkloadTargetResource): any;
export declare class BackupDrRestoreWorkloadTargetResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupDrRestoreWorkloadTargetResource | undefined;
    set internalValue(value: BackupDrRestoreWorkloadTargetResource | undefined);
    private _gcpResource;
    get gcpResource(): BackupDrRestoreWorkloadTargetResourceGcpResourceList;
}
export declare class BackupDrRestoreWorkloadTargetResourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupDrRestoreWorkloadTargetResourceOutputReference;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestorePropertiesAdvancedMachineFeatures {
    /**
    * Optional. Whether to enable nested virtualization or not (default is false).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#enable_nested_virtualization BackupDrRestoreWorkload#enable_nested_virtualization}
    */
    readonly enableNestedVirtualization?: boolean | cdktn.IResolvable;
    /**
    * Optional. Whether to enable UEFI networking for instance creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#enable_uefi_networking BackupDrRestoreWorkload#enable_uefi_networking}
    */
    readonly enableUefiNetworking?: boolean | cdktn.IResolvable;
    /**
    * Optional. The number of threads per physical core.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#threads_per_core BackupDrRestoreWorkload#threads_per_core}
    */
    readonly threadsPerCore?: number;
    /**
    * Optional. The number of physical cores to expose to an instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#visible_core_count BackupDrRestoreWorkload#visible_core_count}
    */
    readonly visibleCoreCount?: number;
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesAdvancedMachineFeaturesToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesAdvancedMachineFeaturesOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesAdvancedMachineFeatures): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesAdvancedMachineFeaturesToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesAdvancedMachineFeaturesOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesAdvancedMachineFeatures): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesAdvancedMachineFeaturesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesAdvancedMachineFeatures | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesAdvancedMachineFeatures | undefined);
    private _enableNestedVirtualization?;
    get enableNestedVirtualization(): boolean | cdktn.IResolvable;
    set enableNestedVirtualization(value: boolean | cdktn.IResolvable);
    resetEnableNestedVirtualization(): void;
    get enableNestedVirtualizationInput(): boolean | cdktn.IResolvable | undefined;
    private _enableUefiNetworking?;
    get enableUefiNetworking(): boolean | cdktn.IResolvable;
    set enableUefiNetworking(value: boolean | cdktn.IResolvable);
    resetEnableUefiNetworking(): void;
    get enableUefiNetworkingInput(): boolean | cdktn.IResolvable | undefined;
    private _threadsPerCore?;
    get threadsPerCore(): number;
    set threadsPerCore(value: number);
    resetThreadsPerCore(): void;
    get threadsPerCoreInput(): number | undefined;
    private _visibleCoreCount?;
    get visibleCoreCount(): number;
    set visibleCoreCount(value: number);
    resetVisibleCoreCount(): void;
    get visibleCoreCountInput(): number | undefined;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestorePropertiesAllocationAffinity {
    /**
    *  Possible values: ["TYPE_UNSPECIFIED", "NO_RESERVATION", "ANY_RESERVATION", "SPECIFIC_RESERVATION"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#consume_allocation_type BackupDrRestoreWorkload#consume_allocation_type}
    */
    readonly consumeAllocationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#key BackupDrRestoreWorkload#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#values BackupDrRestoreWorkload#values}
    */
    readonly values?: string[];
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesAllocationAffinityToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesAllocationAffinityOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesAllocationAffinity): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesAllocationAffinityToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesAllocationAffinityOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesAllocationAffinity): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesAllocationAffinityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesAllocationAffinity | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesAllocationAffinity | undefined);
    private _consumeAllocationType?;
    get consumeAllocationType(): string;
    set consumeAllocationType(value: string);
    resetConsumeAllocationType(): void;
    get consumeAllocationTypeInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestorePropertiesConfidentialInstanceConfig {
    /**
    * Optional. Defines whether the instance should have confidential compute enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#enable_confidential_compute BackupDrRestoreWorkload#enable_confidential_compute}
    */
    readonly enableConfidentialCompute?: boolean | cdktn.IResolvable;
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesConfidentialInstanceConfigToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesConfidentialInstanceConfigOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesConfidentialInstanceConfig): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesConfidentialInstanceConfigToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesConfidentialInstanceConfigOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesConfidentialInstanceConfig): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesConfidentialInstanceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesConfidentialInstanceConfig | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesConfidentialInstanceConfig | undefined);
    private _enableConfidentialCompute?;
    get enableConfidentialCompute(): boolean | cdktn.IResolvable;
    set enableConfidentialCompute(value: boolean | cdktn.IResolvable);
    resetEnableConfidentialCompute(): void;
    get enableConfidentialComputeInput(): boolean | cdktn.IResolvable | undefined;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksDiskEncryptionKey {
    /**
    * Optional. The name of the encryption key that is stored in Google Cloud KMS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#kms_key_name BackupDrRestoreWorkload#kms_key_name}
    */
    readonly kmsKeyName?: string;
    /**
    * Optional. The service account being used for the encryption request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#kms_key_service_account BackupDrRestoreWorkload#kms_key_service_account}
    */
    readonly kmsKeyServiceAccount?: string;
    /**
    * Optional. Specifies a 256-bit customer-supplied encryption key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#raw_key BackupDrRestoreWorkload#raw_key}
    */
    readonly rawKey?: string;
    /**
    * Optional. RSA-wrapped 2048-bit customer-supplied encryption key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#rsa_encrypted_key BackupDrRestoreWorkload#rsa_encrypted_key}
    */
    readonly rsaEncryptedKey?: string;
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksDiskEncryptionKeyToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksDiskEncryptionKeyOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksDiskEncryptionKey): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksDiskEncryptionKeyToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksDiskEncryptionKeyOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksDiskEncryptionKey): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksDiskEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksDiskEncryptionKey | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksDiskEncryptionKey | undefined);
    private _kmsKeyName?;
    get kmsKeyName(): string;
    set kmsKeyName(value: string);
    resetKmsKeyName(): void;
    get kmsKeyNameInput(): string | undefined;
    private _kmsKeyServiceAccount?;
    get kmsKeyServiceAccount(): string;
    set kmsKeyServiceAccount(value: string);
    resetKmsKeyServiceAccount(): void;
    get kmsKeyServiceAccountInput(): string | undefined;
    private _rawKey?;
    get rawKey(): string;
    set rawKey(value: string);
    resetRawKey(): void;
    get rawKeyInput(): string | undefined;
    private _rsaEncryptedKey?;
    get rsaEncryptedKey(): string;
    set rsaEncryptedKey(value: string);
    resetRsaEncryptedKey(): void;
    get rsaEncryptedKeyInput(): string | undefined;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksGuestOsFeature {
    /**
    * Optional. The ID of a supported feature. Possible values: ["FEATURE_TYPE_UNSPECIFIED", "VIRTIO_SCSI_MULTIQUEUE", "WINDOWS", "MULTI_IP_SUBNET", "UEFI_COMPATIBLE", "SECURE_BOOT", "GVNIC", "SEV_CAPABLE", "BARE_METAL_LINUX_COMPATIBLE", "SUSPEND_RESUME_COMPATIBLE", "SEV_LIVE_MIGRATABLE", "SEV_SNP_CAPABLE", "TDX_CAPABLE", "IDPF", "SEV_LIVE_MIGRATABLE_V2"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#type BackupDrRestoreWorkload#type}
    */
    readonly type?: string;
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksGuestOsFeatureToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksGuestOsFeature | cdktn.IResolvable): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksGuestOsFeatureToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksGuestOsFeature | cdktn.IResolvable): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksGuestOsFeatureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksGuestOsFeature | cdktn.IResolvable | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksGuestOsFeature | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksGuestOsFeatureList extends cdktn.ComplexList {
    internalValue?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksGuestOsFeature[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksGuestOsFeatureOutputReference;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksInitializeParams {
    /**
    * Optional. Specifies the disk name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#disk_name BackupDrRestoreWorkload#disk_name}
    */
    readonly diskName?: string;
    /**
    * Optional. URL of the zone where the disk should be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#replica_zones BackupDrRestoreWorkload#replica_zones}
    */
    readonly replicaZones?: string[];
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksInitializeParamsToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksInitializeParamsOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksInitializeParams): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksInitializeParamsToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksInitializeParamsOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksInitializeParams): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksInitializeParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksInitializeParams | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksInitializeParams | undefined);
    private _diskName?;
    get diskName(): string;
    set diskName(value: string);
    resetDiskName(): void;
    get diskNameInput(): string | undefined;
    private _replicaZones?;
    get replicaZones(): string[];
    set replicaZones(value: string[]);
    resetReplicaZones(): void;
    get replicaZonesInput(): string[] | undefined;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisks {
    /**
    * Optional. Specifies whether the disk will be auto-deleted when the instance is deleted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#auto_delete BackupDrRestoreWorkload#auto_delete}
    */
    readonly autoDelete?: boolean | cdktn.IResolvable;
    /**
    * Optional. Indicates that this is a boot disk.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#boot BackupDrRestoreWorkload#boot}
    */
    readonly boot?: boolean | cdktn.IResolvable;
    /**
    * Optional. This is used as an identifier for the disks.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#device_name BackupDrRestoreWorkload#device_name}
    */
    readonly deviceName?: string;
    /**
    * Optional. Specifies the disk interface to use for attaching this disk. Possible values: ["DISK_INTERFACE_UNSPECIFIED", "SCSI", "NVME", "NVDIMM", "ISCSI"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#disk_interface BackupDrRestoreWorkload#disk_interface}
    */
    readonly diskInterface?: string;
    /**
    * Optional. The size of the disk in GB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#disk_size_gb BackupDrRestoreWorkload#disk_size_gb}
    */
    readonly diskSizeGb?: number;
    /**
    * Output only. The URI of the disk type resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#disk_type BackupDrRestoreWorkload#disk_type}
    */
    readonly diskType?: string;
    /**
    * Optional. A zero-based index to this disk, where 0 is reserved for the boot disk.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#index BackupDrRestoreWorkload#index}
    */
    readonly index?: number;
    /**
    * Optional. Type of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#kind BackupDrRestoreWorkload#kind}
    */
    readonly kind?: string;
    /**
    * Optional. Any valid publicly visible licenses.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#license BackupDrRestoreWorkload#license}
    */
    readonly license?: string[];
    /**
    * Optional. The mode in which to attach this disk. Possible values: ["DISK_MODE_UNSPECIFIED", "READ_WRITE", "READ_ONLY", "LOCKED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#mode BackupDrRestoreWorkload#mode}
    */
    readonly mode?: string;
    /**
    * Optional. Specifies the saved state of the disk. Possible values: ["DISK_SAVED_STATE_UNSPECIFIED", "PRESERVED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#saved_state BackupDrRestoreWorkload#saved_state}
    */
    readonly savedState?: string;
    /**
    * Optional. Specifies a valid partial or full URL to an existing Persistent Disk resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#source BackupDrRestoreWorkload#source}
    */
    readonly source?: string;
    /**
    * Optional. Specifies the type of the disk. Possible values: ["DISK_TYPE_UNSPECIFIED", "SCRATCH", "PERSISTENT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#type BackupDrRestoreWorkload#type}
    */
    readonly type?: string;
    /**
    * disk_encryption_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#disk_encryption_key BackupDrRestoreWorkload#disk_encryption_key}
    */
    readonly diskEncryptionKey?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksDiskEncryptionKey;
    /**
    * guest_os_feature block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#guest_os_feature BackupDrRestoreWorkload#guest_os_feature}
    */
    readonly guestOsFeature?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksGuestOsFeature[] | cdktn.IResolvable;
    /**
    * initialize_params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#initialize_params BackupDrRestoreWorkload#initialize_params}
    */
    readonly initializeParams?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksInitializeParams;
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisks | cdktn.IResolvable): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisks | cdktn.IResolvable): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisks | cdktn.IResolvable | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisks | cdktn.IResolvable | undefined);
    private _autoDelete?;
    get autoDelete(): boolean | cdktn.IResolvable;
    set autoDelete(value: boolean | cdktn.IResolvable);
    resetAutoDelete(): void;
    get autoDeleteInput(): boolean | cdktn.IResolvable | undefined;
    private _boot?;
    get boot(): boolean | cdktn.IResolvable;
    set boot(value: boolean | cdktn.IResolvable);
    resetBoot(): void;
    get bootInput(): boolean | cdktn.IResolvable | undefined;
    private _deviceName?;
    get deviceName(): string;
    set deviceName(value: string);
    resetDeviceName(): void;
    get deviceNameInput(): string | undefined;
    private _diskInterface?;
    get diskInterface(): string;
    set diskInterface(value: string);
    resetDiskInterface(): void;
    get diskInterfaceInput(): string | undefined;
    private _diskSizeGb?;
    get diskSizeGb(): number;
    set diskSizeGb(value: number);
    resetDiskSizeGb(): void;
    get diskSizeGbInput(): number | undefined;
    private _diskType?;
    get diskType(): string;
    set diskType(value: string);
    resetDiskType(): void;
    get diskTypeInput(): string | undefined;
    private _index?;
    get index(): number;
    set index(value: number);
    resetIndex(): void;
    get indexInput(): number | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _license?;
    get license(): string[];
    set license(value: string[]);
    resetLicense(): void;
    get licenseInput(): string[] | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _savedState?;
    get savedState(): string;
    set savedState(value: string);
    resetSavedState(): void;
    get savedStateInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _diskEncryptionKey;
    get diskEncryptionKey(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksDiskEncryptionKeyOutputReference;
    putDiskEncryptionKey(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksDiskEncryptionKey): void;
    resetDiskEncryptionKey(): void;
    get diskEncryptionKeyInput(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksDiskEncryptionKey | undefined;
    private _guestOsFeature;
    get guestOsFeature(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksGuestOsFeatureList;
    putGuestOsFeature(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksGuestOsFeature[] | cdktn.IResolvable): void;
    resetGuestOsFeature(): void;
    get guestOsFeatureInput(): cdktn.IResolvable | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksGuestOsFeature[] | undefined;
    private _initializeParams;
    get initializeParams(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksInitializeParamsOutputReference;
    putInitializeParams(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksInitializeParams): void;
    resetInitializeParams(): void;
    get initializeParamsInput(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksInitializeParams | undefined;
}
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksList extends cdktn.ComplexList {
    internalValue?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisks[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksOutputReference;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisplayDevice {
    /**
    * Optional. Enables display for the Compute Engine VM.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#enable_display BackupDrRestoreWorkload#enable_display}
    */
    readonly enableDisplay?: boolean | cdktn.IResolvable;
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesDisplayDeviceToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisplayDeviceOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisplayDevice): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesDisplayDeviceToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisplayDeviceOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisplayDevice): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisplayDeviceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisplayDevice | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisplayDevice | undefined);
    private _enableDisplay?;
    get enableDisplay(): boolean | cdktn.IResolvable;
    set enableDisplay(value: boolean | cdktn.IResolvable);
    resetEnableDisplay(): void;
    get enableDisplayInput(): boolean | cdktn.IResolvable | undefined;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestorePropertiesGuestAccelerators {
    /**
    * Optional. The number of the guest accelerator cards exposed to this instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#accelerator_count BackupDrRestoreWorkload#accelerator_count}
    */
    readonly acceleratorCount?: number;
    /**
    * Optional. Full or partial URL of the accelerator type resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#accelerator_type BackupDrRestoreWorkload#accelerator_type}
    */
    readonly acceleratorType?: string;
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesGuestAcceleratorsToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesGuestAccelerators | cdktn.IResolvable): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesGuestAcceleratorsToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesGuestAccelerators | cdktn.IResolvable): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesGuestAcceleratorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesGuestAccelerators | cdktn.IResolvable | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesGuestAccelerators | cdktn.IResolvable | undefined);
    private _acceleratorCount?;
    get acceleratorCount(): number;
    set acceleratorCount(value: number);
    resetAcceleratorCount(): void;
    get acceleratorCountInput(): number | undefined;
    private _acceleratorType?;
    get acceleratorType(): string;
    set acceleratorType(value: string);
    resetAcceleratorType(): void;
    get acceleratorTypeInput(): string | undefined;
}
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesGuestAcceleratorsList extends cdktn.ComplexList {
    internalValue?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesGuestAccelerators[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesGuestAcceleratorsOutputReference;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestorePropertiesInstanceEncryptionKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#kms_key_name BackupDrRestoreWorkload#kms_key_name}
    */
    readonly kmsKeyName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#kms_key_service_account BackupDrRestoreWorkload#kms_key_service_account}
    */
    readonly kmsKeyServiceAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#raw_key BackupDrRestoreWorkload#raw_key}
    */
    readonly rawKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#rsa_encrypted_key BackupDrRestoreWorkload#rsa_encrypted_key}
    */
    readonly rsaEncryptedKey?: string;
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesInstanceEncryptionKeyToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesInstanceEncryptionKeyOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesInstanceEncryptionKey): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesInstanceEncryptionKeyToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesInstanceEncryptionKeyOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesInstanceEncryptionKey): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesInstanceEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesInstanceEncryptionKey | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesInstanceEncryptionKey | undefined);
    private _kmsKeyName?;
    get kmsKeyName(): string;
    set kmsKeyName(value: string);
    resetKmsKeyName(): void;
    get kmsKeyNameInput(): string | undefined;
    private _kmsKeyServiceAccount?;
    get kmsKeyServiceAccount(): string;
    set kmsKeyServiceAccount(value: string);
    resetKmsKeyServiceAccount(): void;
    get kmsKeyServiceAccountInput(): string | undefined;
    private _rawKey?;
    get rawKey(): string;
    set rawKey(value: string);
    resetRawKey(): void;
    get rawKeyInput(): string | undefined;
    private _rsaEncryptedKey?;
    get rsaEncryptedKey(): string;
    set rsaEncryptedKey(value: string);
    resetRsaEncryptedKey(): void;
    get rsaEncryptedKeyInput(): string | undefined;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestorePropertiesLabels {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#key BackupDrRestoreWorkload#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#value BackupDrRestoreWorkload#value}
    */
    readonly value?: string;
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesLabelsToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesLabels | cdktn.IResolvable): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesLabelsToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesLabels | cdktn.IResolvable): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesLabelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesLabels | cdktn.IResolvable | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesLabels | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesLabelsList extends cdktn.ComplexList {
    internalValue?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesLabels[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesLabelsOutputReference;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadataItems {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#key BackupDrRestoreWorkload#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#value BackupDrRestoreWorkload#value}
    */
    readonly value?: string;
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadataItemsToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadataItems | cdktn.IResolvable): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadataItemsToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadataItems | cdktn.IResolvable): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadataItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadataItems | cdktn.IResolvable | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadataItems | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadataItemsList extends cdktn.ComplexList {
    internalValue?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadataItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadataItemsOutputReference;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadata {
    /**
    * items block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#items BackupDrRestoreWorkload#items}
    */
    readonly items?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadataItems[] | cdktn.IResolvable;
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadataToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadataOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadata): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadataToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadataOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadata): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadata | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadata | undefined);
    private _items;
    get items(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadataItemsList;
    putItems(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadataItems[] | cdktn.IResolvable): void;
    resetItems(): void;
    get itemsInput(): cdktn.IResolvable | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadataItems[] | undefined;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAccessConfigs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#external_ip BackupDrRestoreWorkload#external_ip}
    */
    readonly externalIp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#external_ipv6 BackupDrRestoreWorkload#external_ipv6}
    */
    readonly externalIpv6?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#external_ipv6_prefix_length BackupDrRestoreWorkload#external_ipv6_prefix_length}
    */
    readonly externalIpv6PrefixLength?: number;
    /**
    * Optional. The name of this access configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#name BackupDrRestoreWorkload#name}
    */
    readonly name?: string;
    /**
    *  Possible values: ["NETWORK_TIER_UNSPECIFIED", "PREMIUM", "STANDARD"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#network_tier BackupDrRestoreWorkload#network_tier}
    */
    readonly networkTier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#public_ptr_domain_name BackupDrRestoreWorkload#public_ptr_domain_name}
    */
    readonly publicPtrDomainName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#set_public_ptr BackupDrRestoreWorkload#set_public_ptr}
    */
    readonly setPublicPtr?: boolean | cdktn.IResolvable;
    /**
    * Optional. The type of configuration. Possible values: ["ACCESS_TYPE_UNSPECIFIED", "ONE_TO_ONE_NAT", "DIRECT_IPV6"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#type BackupDrRestoreWorkload#type}
    */
    readonly type?: string;
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAccessConfigsToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAccessConfigs | cdktn.IResolvable): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAccessConfigsToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAccessConfigs | cdktn.IResolvable): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAccessConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAccessConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAccessConfigs | cdktn.IResolvable | undefined);
    private _externalIp?;
    get externalIp(): string;
    set externalIp(value: string);
    resetExternalIp(): void;
    get externalIpInput(): string | undefined;
    private _externalIpv6?;
    get externalIpv6(): string;
    set externalIpv6(value: string);
    resetExternalIpv6(): void;
    get externalIpv6Input(): string | undefined;
    private _externalIpv6PrefixLength?;
    get externalIpv6PrefixLength(): number;
    set externalIpv6PrefixLength(value: number);
    resetExternalIpv6PrefixLength(): void;
    get externalIpv6PrefixLengthInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _networkTier?;
    get networkTier(): string;
    set networkTier(value: string);
    resetNetworkTier(): void;
    get networkTierInput(): string | undefined;
    private _publicPtrDomainName?;
    get publicPtrDomainName(): string;
    set publicPtrDomainName(value: string);
    resetPublicPtrDomainName(): void;
    get publicPtrDomainNameInput(): string | undefined;
    private _setPublicPtr?;
    get setPublicPtr(): boolean | cdktn.IResolvable;
    set setPublicPtr(value: boolean | cdktn.IResolvable);
    resetSetPublicPtr(): void;
    get setPublicPtrInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAccessConfigsList extends cdktn.ComplexList {
    internalValue?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAccessConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAccessConfigsOutputReference;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAliasIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#ip_cidr_range BackupDrRestoreWorkload#ip_cidr_range}
    */
    readonly ipCidrRange?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#subnetwork_range_name BackupDrRestoreWorkload#subnetwork_range_name}
    */
    readonly subnetworkRangeName?: string;
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAliasIpRangesToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAliasIpRanges | cdktn.IResolvable): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAliasIpRangesToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAliasIpRanges | cdktn.IResolvable): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAliasIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAliasIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAliasIpRanges | cdktn.IResolvable | undefined);
    private _ipCidrRange?;
    get ipCidrRange(): string;
    set ipCidrRange(value: string);
    resetIpCidrRange(): void;
    get ipCidrRangeInput(): string | undefined;
    private _subnetworkRangeName?;
    get subnetworkRangeName(): string;
    set subnetworkRangeName(value: string);
    resetSubnetworkRangeName(): void;
    get subnetworkRangeNameInput(): string | undefined;
}
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAliasIpRangesList extends cdktn.ComplexList {
    internalValue?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAliasIpRanges[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAliasIpRangesOutputReference;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesIpv6AccessConfigs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#external_ip BackupDrRestoreWorkload#external_ip}
    */
    readonly externalIp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#external_ipv6 BackupDrRestoreWorkload#external_ipv6}
    */
    readonly externalIpv6?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#external_ipv6_prefix_length BackupDrRestoreWorkload#external_ipv6_prefix_length}
    */
    readonly externalIpv6PrefixLength?: number;
    /**
    * Optional. The name of this access configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#name BackupDrRestoreWorkload#name}
    */
    readonly name?: string;
    /**
    *  Possible values: ["NETWORK_TIER_UNSPECIFIED", "PREMIUM", "STANDARD"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#network_tier BackupDrRestoreWorkload#network_tier}
    */
    readonly networkTier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#public_ptr_domain_name BackupDrRestoreWorkload#public_ptr_domain_name}
    */
    readonly publicPtrDomainName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#set_public_ptr BackupDrRestoreWorkload#set_public_ptr}
    */
    readonly setPublicPtr?: boolean | cdktn.IResolvable;
    /**
    * Optional. The type of configuration. Possible values: ["ACCESS_TYPE_UNSPECIFIED", "ONE_TO_ONE_NAT", "DIRECT_IPV6"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#type BackupDrRestoreWorkload#type}
    */
    readonly type?: string;
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesIpv6AccessConfigsToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesIpv6AccessConfigs | cdktn.IResolvable): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesIpv6AccessConfigsToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesIpv6AccessConfigs | cdktn.IResolvable): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesIpv6AccessConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesIpv6AccessConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesIpv6AccessConfigs | cdktn.IResolvable | undefined);
    private _externalIp?;
    get externalIp(): string;
    set externalIp(value: string);
    resetExternalIp(): void;
    get externalIpInput(): string | undefined;
    private _externalIpv6?;
    get externalIpv6(): string;
    set externalIpv6(value: string);
    resetExternalIpv6(): void;
    get externalIpv6Input(): string | undefined;
    private _externalIpv6PrefixLength?;
    get externalIpv6PrefixLength(): number;
    set externalIpv6PrefixLength(value: number);
    resetExternalIpv6PrefixLength(): void;
    get externalIpv6PrefixLengthInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _networkTier?;
    get networkTier(): string;
    set networkTier(value: string);
    resetNetworkTier(): void;
    get networkTierInput(): string | undefined;
    private _publicPtrDomainName?;
    get publicPtrDomainName(): string;
    set publicPtrDomainName(value: string);
    resetPublicPtrDomainName(): void;
    get publicPtrDomainNameInput(): string | undefined;
    private _setPublicPtr?;
    get setPublicPtr(): boolean | cdktn.IResolvable;
    set setPublicPtr(value: boolean | cdktn.IResolvable);
    resetSetPublicPtr(): void;
    get setPublicPtrInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesIpv6AccessConfigsList extends cdktn.ComplexList {
    internalValue?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesIpv6AccessConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesIpv6AccessConfigsOutputReference;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfaces {
    /**
    * Optional. The prefix length of the primary internal IPv6 range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#internal_ipv6_prefix_length BackupDrRestoreWorkload#internal_ipv6_prefix_length}
    */
    readonly internalIpv6PrefixLength?: number;
    /**
    * Optional. An IPv4 internal IP address to assign to the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#ip_address BackupDrRestoreWorkload#ip_address}
    */
    readonly ipAddress?: string;
    /**
    *  Possible values: ["UNSPECIFIED_IPV6_ACCESS_TYPE", "INTERNAL", "EXTERNAL"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#ipv6_access_type BackupDrRestoreWorkload#ipv6_access_type}
    */
    readonly ipv6AccessType?: string;
    /**
    * Optional. An IPv6 internal network address for this network interface.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#ipv6_address BackupDrRestoreWorkload#ipv6_address}
    */
    readonly ipv6Address?: string;
    /**
    * Optional. URL of the VPC network resource for this instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#network BackupDrRestoreWorkload#network}
    */
    readonly network?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#network_attachment BackupDrRestoreWorkload#network_attachment}
    */
    readonly networkAttachment?: string;
    /**
    *  Possible values: ["NIC_TYPE_UNSPECIFIED", "VIRTIO_NET", "GVNIC"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#nic_type BackupDrRestoreWorkload#nic_type}
    */
    readonly nicType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#queue_count BackupDrRestoreWorkload#queue_count}
    */
    readonly queueCount?: number;
    /**
    *  Possible values: ["STACK_TYPE_UNSPECIFIED", "IPV4_ONLY", "IPV4_IPV6"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#stack_type BackupDrRestoreWorkload#stack_type}
    */
    readonly stackType?: string;
    /**
    * Optional. The URL of the Subnetwork resource for this instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#subnetwork BackupDrRestoreWorkload#subnetwork}
    */
    readonly subnetwork?: string;
    /**
    * access_configs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#access_configs BackupDrRestoreWorkload#access_configs}
    */
    readonly accessConfigs?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAccessConfigs[] | cdktn.IResolvable;
    /**
    * alias_ip_ranges block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#alias_ip_ranges BackupDrRestoreWorkload#alias_ip_ranges}
    */
    readonly aliasIpRanges?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAliasIpRanges[] | cdktn.IResolvable;
    /**
    * ipv6_access_configs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#ipv6_access_configs BackupDrRestoreWorkload#ipv6_access_configs}
    */
    readonly ipv6AccessConfigs?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesIpv6AccessConfigs[] | cdktn.IResolvable;
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfaces | cdktn.IResolvable): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfaces | cdktn.IResolvable): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfaces | cdktn.IResolvable | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfaces | cdktn.IResolvable | undefined);
    private _internalIpv6PrefixLength?;
    get internalIpv6PrefixLength(): number;
    set internalIpv6PrefixLength(value: number);
    resetInternalIpv6PrefixLength(): void;
    get internalIpv6PrefixLengthInput(): number | undefined;
    private _ipAddress?;
    get ipAddress(): string;
    set ipAddress(value: string);
    resetIpAddress(): void;
    get ipAddressInput(): string | undefined;
    private _ipv6AccessType?;
    get ipv6AccessType(): string;
    set ipv6AccessType(value: string);
    resetIpv6AccessType(): void;
    get ipv6AccessTypeInput(): string | undefined;
    private _ipv6Address?;
    get ipv6Address(): string;
    set ipv6Address(value: string);
    resetIpv6Address(): void;
    get ipv6AddressInput(): string | undefined;
    private _network?;
    get network(): string;
    set network(value: string);
    resetNetwork(): void;
    get networkInput(): string | undefined;
    private _networkAttachment?;
    get networkAttachment(): string;
    set networkAttachment(value: string);
    resetNetworkAttachment(): void;
    get networkAttachmentInput(): string | undefined;
    private _nicType?;
    get nicType(): string;
    set nicType(value: string);
    resetNicType(): void;
    get nicTypeInput(): string | undefined;
    private _queueCount?;
    get queueCount(): number;
    set queueCount(value: number);
    resetQueueCount(): void;
    get queueCountInput(): number | undefined;
    private _stackType?;
    get stackType(): string;
    set stackType(value: string);
    resetStackType(): void;
    get stackTypeInput(): string | undefined;
    private _subnetwork?;
    get subnetwork(): string;
    set subnetwork(value: string);
    resetSubnetwork(): void;
    get subnetworkInput(): string | undefined;
    private _accessConfigs;
    get accessConfigs(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAccessConfigsList;
    putAccessConfigs(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAccessConfigs[] | cdktn.IResolvable): void;
    resetAccessConfigs(): void;
    get accessConfigsInput(): cdktn.IResolvable | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAccessConfigs[] | undefined;
    private _aliasIpRanges;
    get aliasIpRanges(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAliasIpRangesList;
    putAliasIpRanges(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAliasIpRanges[] | cdktn.IResolvable): void;
    resetAliasIpRanges(): void;
    get aliasIpRangesInput(): cdktn.IResolvable | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesAliasIpRanges[] | undefined;
    private _ipv6AccessConfigs;
    get ipv6AccessConfigs(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesIpv6AccessConfigsList;
    putIpv6AccessConfigs(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesIpv6AccessConfigs[] | cdktn.IResolvable): void;
    resetIpv6AccessConfigs(): void;
    get ipv6AccessConfigsInput(): cdktn.IResolvable | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesIpv6AccessConfigs[] | undefined;
}
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesList extends cdktn.ComplexList {
    internalValue?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfaces[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesOutputReference;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkPerformanceConfig {
    /**
    *  Possible values: ["TIER_UNSPECIFIED", "DEFAULT", "TIER_1"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#total_egress_bandwidth_tier BackupDrRestoreWorkload#total_egress_bandwidth_tier}
    */
    readonly totalEgressBandwidthTier?: string;
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkPerformanceConfigToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkPerformanceConfigOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkPerformanceConfig): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkPerformanceConfigToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkPerformanceConfigOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkPerformanceConfig): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkPerformanceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkPerformanceConfig | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkPerformanceConfig | undefined);
    private _totalEgressBandwidthTier?;
    get totalEgressBandwidthTier(): string;
    set totalEgressBandwidthTier(value: string);
    resetTotalEgressBandwidthTier(): void;
    get totalEgressBandwidthTierInput(): string | undefined;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestorePropertiesParamsResourceManagerTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#key BackupDrRestoreWorkload#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#value BackupDrRestoreWorkload#value}
    */
    readonly value?: string;
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesParamsResourceManagerTagsToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesParamsResourceManagerTags | cdktn.IResolvable): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesParamsResourceManagerTagsToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesParamsResourceManagerTags | cdktn.IResolvable): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesParamsResourceManagerTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesParamsResourceManagerTags | cdktn.IResolvable | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesParamsResourceManagerTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesParamsResourceManagerTagsList extends cdktn.ComplexList {
    internalValue?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesParamsResourceManagerTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesParamsResourceManagerTagsOutputReference;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestorePropertiesParams {
    /**
    * resource_manager_tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#resource_manager_tags BackupDrRestoreWorkload#resource_manager_tags}
    */
    readonly resourceManagerTags?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesParamsResourceManagerTags[] | cdktn.IResolvable;
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesParamsToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesParamsOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesParams): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesParamsToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesParamsOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesParams): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesParams | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesParams | undefined);
    private _resourceManagerTags;
    get resourceManagerTags(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesParamsResourceManagerTagsList;
    putResourceManagerTags(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesParamsResourceManagerTags[] | cdktn.IResolvable): void;
    resetResourceManagerTags(): void;
    get resourceManagerTagsInput(): cdktn.IResolvable | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesParamsResourceManagerTags[] | undefined;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingLocalSsdRecoveryTimeout {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#nanos BackupDrRestoreWorkload#nanos}
    */
    readonly nanos?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#seconds BackupDrRestoreWorkload#seconds}
    */
    readonly seconds?: number;
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingLocalSsdRecoveryTimeoutToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingLocalSsdRecoveryTimeoutOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingLocalSsdRecoveryTimeout): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingLocalSsdRecoveryTimeoutToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingLocalSsdRecoveryTimeoutOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingLocalSsdRecoveryTimeout): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingLocalSsdRecoveryTimeoutOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingLocalSsdRecoveryTimeout | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingLocalSsdRecoveryTimeout | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): number;
    set seconds(value: number);
    resetSeconds(): void;
    get secondsInput(): number | undefined;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingMaxRunDuration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#nanos BackupDrRestoreWorkload#nanos}
    */
    readonly nanos?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#seconds BackupDrRestoreWorkload#seconds}
    */
    readonly seconds?: number;
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingMaxRunDurationToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingMaxRunDurationOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingMaxRunDuration): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingMaxRunDurationToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingMaxRunDurationOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingMaxRunDuration): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingMaxRunDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingMaxRunDuration | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingMaxRunDuration | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): number;
    set seconds(value: number);
    resetSeconds(): void;
    get secondsInput(): number | undefined;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingNodeAffinities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#key BackupDrRestoreWorkload#key}
    */
    readonly key?: string;
    /**
    *  Possible values: ["OPERATOR_UNSPECIFIED", "IN", "NOT_IN"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#operator BackupDrRestoreWorkload#operator}
    */
    readonly operator?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#values BackupDrRestoreWorkload#values}
    */
    readonly values?: string[];
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingNodeAffinitiesToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingNodeAffinities | cdktn.IResolvable): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingNodeAffinitiesToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingNodeAffinities | cdktn.IResolvable): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingNodeAffinitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingNodeAffinities | cdktn.IResolvable | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingNodeAffinities | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingNodeAffinitiesList extends cdktn.ComplexList {
    internalValue?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingNodeAffinities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingNodeAffinitiesOutputReference;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestorePropertiesScheduling {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#automatic_restart BackupDrRestoreWorkload#automatic_restart}
    */
    readonly automaticRestart?: boolean | cdktn.IResolvable;
    /**
    *  Possible values: ["INSTANCE_TERMINATION_ACTION_UNSPECIFIED", "DELETE", "STOP"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#instance_termination_action BackupDrRestoreWorkload#instance_termination_action}
    */
    readonly instanceTerminationAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#min_node_cpus BackupDrRestoreWorkload#min_node_cpus}
    */
    readonly minNodeCpus?: number;
    /**
    *  Possible values: ["ON_HOST_MAINTENANCE_UNSPECIFIED", "TERMINATE", "MIGRATE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#on_host_maintenance BackupDrRestoreWorkload#on_host_maintenance}
    */
    readonly onHostMaintenance?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#preemptible BackupDrRestoreWorkload#preemptible}
    */
    readonly preemptible?: boolean | cdktn.IResolvable;
    /**
    *  Possible values: ["PROVISIONING_MODEL_UNSPECIFIED", "STANDARD", "SPOT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#provisioning_model BackupDrRestoreWorkload#provisioning_model}
    */
    readonly provisioningModel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#termination_time BackupDrRestoreWorkload#termination_time}
    */
    readonly terminationTime?: string;
    /**
    * local_ssd_recovery_timeout block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#local_ssd_recovery_timeout BackupDrRestoreWorkload#local_ssd_recovery_timeout}
    */
    readonly localSsdRecoveryTimeout?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingLocalSsdRecoveryTimeout;
    /**
    * max_run_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#max_run_duration BackupDrRestoreWorkload#max_run_duration}
    */
    readonly maxRunDuration?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingMaxRunDuration;
    /**
    * node_affinities block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#node_affinities BackupDrRestoreWorkload#node_affinities}
    */
    readonly nodeAffinities?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingNodeAffinities[] | cdktn.IResolvable;
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesScheduling): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesScheduling): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesScheduling | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesScheduling | undefined);
    private _automaticRestart?;
    get automaticRestart(): boolean | cdktn.IResolvable;
    set automaticRestart(value: boolean | cdktn.IResolvable);
    resetAutomaticRestart(): void;
    get automaticRestartInput(): boolean | cdktn.IResolvable | undefined;
    private _instanceTerminationAction?;
    get instanceTerminationAction(): string;
    set instanceTerminationAction(value: string);
    resetInstanceTerminationAction(): void;
    get instanceTerminationActionInput(): string | undefined;
    private _minNodeCpus?;
    get minNodeCpus(): number;
    set minNodeCpus(value: number);
    resetMinNodeCpus(): void;
    get minNodeCpusInput(): number | undefined;
    private _onHostMaintenance?;
    get onHostMaintenance(): string;
    set onHostMaintenance(value: string);
    resetOnHostMaintenance(): void;
    get onHostMaintenanceInput(): string | undefined;
    private _preemptible?;
    get preemptible(): boolean | cdktn.IResolvable;
    set preemptible(value: boolean | cdktn.IResolvable);
    resetPreemptible(): void;
    get preemptibleInput(): boolean | cdktn.IResolvable | undefined;
    private _provisioningModel?;
    get provisioningModel(): string;
    set provisioningModel(value: string);
    resetProvisioningModel(): void;
    get provisioningModelInput(): string | undefined;
    private _terminationTime?;
    get terminationTime(): string;
    set terminationTime(value: string);
    resetTerminationTime(): void;
    get terminationTimeInput(): string | undefined;
    private _localSsdRecoveryTimeout;
    get localSsdRecoveryTimeout(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingLocalSsdRecoveryTimeoutOutputReference;
    putLocalSsdRecoveryTimeout(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingLocalSsdRecoveryTimeout): void;
    resetLocalSsdRecoveryTimeout(): void;
    get localSsdRecoveryTimeoutInput(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingLocalSsdRecoveryTimeout | undefined;
    private _maxRunDuration;
    get maxRunDuration(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingMaxRunDurationOutputReference;
    putMaxRunDuration(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingMaxRunDuration): void;
    resetMaxRunDuration(): void;
    get maxRunDurationInput(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingMaxRunDuration | undefined;
    private _nodeAffinities;
    get nodeAffinities(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingNodeAffinitiesList;
    putNodeAffinities(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingNodeAffinities[] | cdktn.IResolvable): void;
    resetNodeAffinities(): void;
    get nodeAffinitiesInput(): cdktn.IResolvable | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingNodeAffinities[] | undefined;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestorePropertiesServiceAccounts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#email BackupDrRestoreWorkload#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#scopes BackupDrRestoreWorkload#scopes}
    */
    readonly scopes?: string[];
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesServiceAccountsToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesServiceAccounts | cdktn.IResolvable): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesServiceAccountsToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesServiceAccounts | cdktn.IResolvable): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesServiceAccountsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesServiceAccounts | cdktn.IResolvable | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesServiceAccounts | cdktn.IResolvable | undefined);
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesServiceAccountsList extends cdktn.ComplexList {
    internalValue?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesServiceAccounts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesServiceAccountsOutputReference;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestorePropertiesShieldedInstanceConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#enable_integrity_monitoring BackupDrRestoreWorkload#enable_integrity_monitoring}
    */
    readonly enableIntegrityMonitoring?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#enable_secure_boot BackupDrRestoreWorkload#enable_secure_boot}
    */
    readonly enableSecureBoot?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#enable_vtpm BackupDrRestoreWorkload#enable_vtpm}
    */
    readonly enableVtpm?: boolean | cdktn.IResolvable;
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesShieldedInstanceConfigToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesShieldedInstanceConfigOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesShieldedInstanceConfig): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesShieldedInstanceConfigToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesShieldedInstanceConfigOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesShieldedInstanceConfig): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesShieldedInstanceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesShieldedInstanceConfig | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesShieldedInstanceConfig | undefined);
    private _enableIntegrityMonitoring?;
    get enableIntegrityMonitoring(): boolean | cdktn.IResolvable;
    set enableIntegrityMonitoring(value: boolean | cdktn.IResolvable);
    resetEnableIntegrityMonitoring(): void;
    get enableIntegrityMonitoringInput(): boolean | cdktn.IResolvable | undefined;
    private _enableSecureBoot?;
    get enableSecureBoot(): boolean | cdktn.IResolvable;
    set enableSecureBoot(value: boolean | cdktn.IResolvable);
    resetEnableSecureBoot(): void;
    get enableSecureBootInput(): boolean | cdktn.IResolvable | undefined;
    private _enableVtpm?;
    get enableVtpm(): boolean | cdktn.IResolvable;
    set enableVtpm(value: boolean | cdktn.IResolvable);
    resetEnableVtpm(): void;
    get enableVtpmInput(): boolean | cdktn.IResolvable | undefined;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestorePropertiesTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#items BackupDrRestoreWorkload#items}
    */
    readonly items?: string[];
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesTagsToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesTagsOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesTags): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesTagsToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesTagsOutputReference | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesTags): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesTags | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesTags | undefined);
    private _items?;
    get items(): string[];
    set items(value: string[]);
    resetItems(): void;
    get itemsInput(): string[] | undefined;
}
export interface BackupDrRestoreWorkloadComputeInstanceRestoreProperties {
    /**
    * Optional. Allows this instance to send and receive packets with non-matching destination or source IPs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#can_ip_forward BackupDrRestoreWorkload#can_ip_forward}
    */
    readonly canIpForward?: boolean | cdktn.IResolvable;
    /**
    * Optional. Whether the resource should be protected against deletion.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#deletion_protection BackupDrRestoreWorkload#deletion_protection}
    */
    readonly deletionProtection?: boolean | cdktn.IResolvable;
    /**
    * Optional. An optional description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#description BackupDrRestoreWorkload#description}
    */
    readonly description?: string;
    /**
    * Optional. Specifies the hostname of the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#hostname BackupDrRestoreWorkload#hostname}
    */
    readonly hostname?: string;
    /**
    * Optional. KeyRevocationActionType of the instance. Possible values: ["KEY_REVOCATION_ACTION_TYPE_UNSPECIFIED", "NONE", "STOP"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#key_revocation_action_type BackupDrRestoreWorkload#key_revocation_action_type}
    */
    readonly keyRevocationActionType?: string;
    /**
    * Optional. Full or partial URL of the machine type resource to use for this instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#machine_type BackupDrRestoreWorkload#machine_type}
    */
    readonly machineType?: string;
    /**
    * Optional. Minimum CPU platform to use for this instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#min_cpu_platform BackupDrRestoreWorkload#min_cpu_platform}
    */
    readonly minCpuPlatform?: string;
    /**
    * Required. Name of the compute instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#name BackupDrRestoreWorkload#name}
    */
    readonly name: string;
    /**
    * Optional. The private IPv6 google access type for the VM. Possible values: ["INSTANCE_PRIVATE_IPV6_GOOGLE_ACCESS_UNSPECIFIED", "INHERIT_FROM_SUBNETWORK", "ENABLE_OUTBOUND_VM_ACCESS_TO_GOOGLE", "ENABLE_BIDIRECTIONAL_ACCESS_TO_GOOGLE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#private_ipv6_google_access BackupDrRestoreWorkload#private_ipv6_google_access}
    */
    readonly privateIpv6GoogleAccess?: string;
    /**
    * Optional. Resource policies applied to this instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#resource_policies BackupDrRestoreWorkload#resource_policies}
    */
    readonly resourcePolicies?: string[];
    /**
    * advanced_machine_features block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#advanced_machine_features BackupDrRestoreWorkload#advanced_machine_features}
    */
    readonly advancedMachineFeatures?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesAdvancedMachineFeatures;
    /**
    * allocation_affinity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#allocation_affinity BackupDrRestoreWorkload#allocation_affinity}
    */
    readonly allocationAffinity?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesAllocationAffinity;
    /**
    * confidential_instance_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#confidential_instance_config BackupDrRestoreWorkload#confidential_instance_config}
    */
    readonly confidentialInstanceConfig?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesConfidentialInstanceConfig;
    /**
    * disks block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#disks BackupDrRestoreWorkload#disks}
    */
    readonly disks?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisks[] | cdktn.IResolvable;
    /**
    * display_device block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#display_device BackupDrRestoreWorkload#display_device}
    */
    readonly displayDevice?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisplayDevice;
    /**
    * guest_accelerators block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#guest_accelerators BackupDrRestoreWorkload#guest_accelerators}
    */
    readonly guestAccelerators?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesGuestAccelerators[] | cdktn.IResolvable;
    /**
    * instance_encryption_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#instance_encryption_key BackupDrRestoreWorkload#instance_encryption_key}
    */
    readonly instanceEncryptionKey?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesInstanceEncryptionKey;
    /**
    * labels block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#labels BackupDrRestoreWorkload#labels}
    */
    readonly labels?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesLabels[] | cdktn.IResolvable;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#metadata BackupDrRestoreWorkload#metadata}
    */
    readonly metadata?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadata;
    /**
    * network_interfaces block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#network_interfaces BackupDrRestoreWorkload#network_interfaces}
    */
    readonly networkInterfaces?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfaces[] | cdktn.IResolvable;
    /**
    * network_performance_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#network_performance_config BackupDrRestoreWorkload#network_performance_config}
    */
    readonly networkPerformanceConfig?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkPerformanceConfig;
    /**
    * params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#params BackupDrRestoreWorkload#params}
    */
    readonly params?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesParams;
    /**
    * scheduling block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#scheduling BackupDrRestoreWorkload#scheduling}
    */
    readonly scheduling?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesScheduling;
    /**
    * service_accounts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#service_accounts BackupDrRestoreWorkload#service_accounts}
    */
    readonly serviceAccounts?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesServiceAccounts[] | cdktn.IResolvable;
    /**
    * shielded_instance_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#shielded_instance_config BackupDrRestoreWorkload#shielded_instance_config}
    */
    readonly shieldedInstanceConfig?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesShieldedInstanceConfig;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#tags BackupDrRestoreWorkload#tags}
    */
    readonly tags?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesTags;
}
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesOutputReference | BackupDrRestoreWorkloadComputeInstanceRestoreProperties): any;
export declare function backupDrRestoreWorkloadComputeInstanceRestorePropertiesToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesOutputReference | BackupDrRestoreWorkloadComputeInstanceRestoreProperties): any;
export declare class BackupDrRestoreWorkloadComputeInstanceRestorePropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceRestoreProperties | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceRestoreProperties | undefined);
    private _canIpForward?;
    get canIpForward(): boolean | cdktn.IResolvable;
    set canIpForward(value: boolean | cdktn.IResolvable);
    resetCanIpForward(): void;
    get canIpForwardInput(): boolean | cdktn.IResolvable | undefined;
    private _deletionProtection?;
    get deletionProtection(): boolean | cdktn.IResolvable;
    set deletionProtection(value: boolean | cdktn.IResolvable);
    resetDeletionProtection(): void;
    get deletionProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _hostname?;
    get hostname(): string;
    set hostname(value: string);
    resetHostname(): void;
    get hostnameInput(): string | undefined;
    private _keyRevocationActionType?;
    get keyRevocationActionType(): string;
    set keyRevocationActionType(value: string);
    resetKeyRevocationActionType(): void;
    get keyRevocationActionTypeInput(): string | undefined;
    private _machineType?;
    get machineType(): string;
    set machineType(value: string);
    resetMachineType(): void;
    get machineTypeInput(): string | undefined;
    private _minCpuPlatform?;
    get minCpuPlatform(): string;
    set minCpuPlatform(value: string);
    resetMinCpuPlatform(): void;
    get minCpuPlatformInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _privateIpv6GoogleAccess?;
    get privateIpv6GoogleAccess(): string;
    set privateIpv6GoogleAccess(value: string);
    resetPrivateIpv6GoogleAccess(): void;
    get privateIpv6GoogleAccessInput(): string | undefined;
    private _resourcePolicies?;
    get resourcePolicies(): string[];
    set resourcePolicies(value: string[]);
    resetResourcePolicies(): void;
    get resourcePoliciesInput(): string[] | undefined;
    private _advancedMachineFeatures;
    get advancedMachineFeatures(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesAdvancedMachineFeaturesOutputReference;
    putAdvancedMachineFeatures(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesAdvancedMachineFeatures): void;
    resetAdvancedMachineFeatures(): void;
    get advancedMachineFeaturesInput(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesAdvancedMachineFeatures | undefined;
    private _allocationAffinity;
    get allocationAffinity(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesAllocationAffinityOutputReference;
    putAllocationAffinity(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesAllocationAffinity): void;
    resetAllocationAffinity(): void;
    get allocationAffinityInput(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesAllocationAffinity | undefined;
    private _confidentialInstanceConfig;
    get confidentialInstanceConfig(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesConfidentialInstanceConfigOutputReference;
    putConfidentialInstanceConfig(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesConfidentialInstanceConfig): void;
    resetConfidentialInstanceConfig(): void;
    get confidentialInstanceConfigInput(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesConfidentialInstanceConfig | undefined;
    private _disks;
    get disks(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisksList;
    putDisks(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisks[] | cdktn.IResolvable): void;
    resetDisks(): void;
    get disksInput(): cdktn.IResolvable | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisks[] | undefined;
    private _displayDevice;
    get displayDevice(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisplayDeviceOutputReference;
    putDisplayDevice(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisplayDevice): void;
    resetDisplayDevice(): void;
    get displayDeviceInput(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesDisplayDevice | undefined;
    private _guestAccelerators;
    get guestAccelerators(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesGuestAcceleratorsList;
    putGuestAccelerators(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesGuestAccelerators[] | cdktn.IResolvable): void;
    resetGuestAccelerators(): void;
    get guestAcceleratorsInput(): cdktn.IResolvable | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesGuestAccelerators[] | undefined;
    private _instanceEncryptionKey;
    get instanceEncryptionKey(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesInstanceEncryptionKeyOutputReference;
    putInstanceEncryptionKey(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesInstanceEncryptionKey): void;
    resetInstanceEncryptionKey(): void;
    get instanceEncryptionKeyInput(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesInstanceEncryptionKey | undefined;
    private _labels;
    get labels(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesLabelsList;
    putLabels(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesLabels[] | cdktn.IResolvable): void;
    resetLabels(): void;
    get labelsInput(): cdktn.IResolvable | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesLabels[] | undefined;
    private _metadata;
    get metadata(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadataOutputReference;
    putMetadata(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadata): void;
    resetMetadata(): void;
    get metadataInput(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesMetadata | undefined;
    private _networkInterfaces;
    get networkInterfaces(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfacesList;
    putNetworkInterfaces(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfaces[] | cdktn.IResolvable): void;
    resetNetworkInterfaces(): void;
    get networkInterfacesInput(): cdktn.IResolvable | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkInterfaces[] | undefined;
    private _networkPerformanceConfig;
    get networkPerformanceConfig(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkPerformanceConfigOutputReference;
    putNetworkPerformanceConfig(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkPerformanceConfig): void;
    resetNetworkPerformanceConfig(): void;
    get networkPerformanceConfigInput(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesNetworkPerformanceConfig | undefined;
    private _params;
    get params(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesParamsOutputReference;
    putParams(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesParams): void;
    resetParams(): void;
    get paramsInput(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesParams | undefined;
    private _scheduling;
    get scheduling(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesSchedulingOutputReference;
    putScheduling(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesScheduling): void;
    resetScheduling(): void;
    get schedulingInput(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesScheduling | undefined;
    private _serviceAccounts;
    get serviceAccounts(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesServiceAccountsList;
    putServiceAccounts(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesServiceAccounts[] | cdktn.IResolvable): void;
    resetServiceAccounts(): void;
    get serviceAccountsInput(): cdktn.IResolvable | BackupDrRestoreWorkloadComputeInstanceRestorePropertiesServiceAccounts[] | undefined;
    private _shieldedInstanceConfig;
    get shieldedInstanceConfig(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesShieldedInstanceConfigOutputReference;
    putShieldedInstanceConfig(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesShieldedInstanceConfig): void;
    resetShieldedInstanceConfig(): void;
    get shieldedInstanceConfigInput(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesShieldedInstanceConfig | undefined;
    private _tags;
    get tags(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesTagsOutputReference;
    putTags(value: BackupDrRestoreWorkloadComputeInstanceRestorePropertiesTags): void;
    resetTags(): void;
    get tagsInput(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesTags | undefined;
}
export interface BackupDrRestoreWorkloadComputeInstanceTargetEnvironment {
    /**
    * Required. Target project for the Compute Engine instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#project BackupDrRestoreWorkload#project}
    */
    readonly project: string;
    /**
    * If true, use the BackupDR P4SA credentials for same-project restores. Default is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#use_project_service_account BackupDrRestoreWorkload#use_project_service_account}
    */
    readonly useProjectServiceAccount?: boolean | cdktn.IResolvable;
    /**
    * Required. The zone of the Compute Engine instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#zone BackupDrRestoreWorkload#zone}
    */
    readonly zone: string;
}
export declare function backupDrRestoreWorkloadComputeInstanceTargetEnvironmentToTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceTargetEnvironmentOutputReference | BackupDrRestoreWorkloadComputeInstanceTargetEnvironment): any;
export declare function backupDrRestoreWorkloadComputeInstanceTargetEnvironmentToHclTerraform(struct?: BackupDrRestoreWorkloadComputeInstanceTargetEnvironmentOutputReference | BackupDrRestoreWorkloadComputeInstanceTargetEnvironment): any;
export declare class BackupDrRestoreWorkloadComputeInstanceTargetEnvironmentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrRestoreWorkloadComputeInstanceTargetEnvironment | undefined;
    set internalValue(value: BackupDrRestoreWorkloadComputeInstanceTargetEnvironment | undefined);
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _useProjectServiceAccount?;
    get useProjectServiceAccount(): boolean | cdktn.IResolvable;
    set useProjectServiceAccount(value: boolean | cdktn.IResolvable);
    resetUseProjectServiceAccount(): void;
    get useProjectServiceAccountInput(): boolean | cdktn.IResolvable | undefined;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    get zoneInput(): string | undefined;
}
export interface BackupDrRestoreWorkloadDiskRestorePropertiesDiskEncryptionKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#kms_key_name BackupDrRestoreWorkload#kms_key_name}
    */
    readonly kmsKeyName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#kms_key_service_account BackupDrRestoreWorkload#kms_key_service_account}
    */
    readonly kmsKeyServiceAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#raw_key BackupDrRestoreWorkload#raw_key}
    */
    readonly rawKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#rsa_encrypted_key BackupDrRestoreWorkload#rsa_encrypted_key}
    */
    readonly rsaEncryptedKey?: string;
}
export declare function backupDrRestoreWorkloadDiskRestorePropertiesDiskEncryptionKeyToTerraform(struct?: BackupDrRestoreWorkloadDiskRestorePropertiesDiskEncryptionKeyOutputReference | BackupDrRestoreWorkloadDiskRestorePropertiesDiskEncryptionKey): any;
export declare function backupDrRestoreWorkloadDiskRestorePropertiesDiskEncryptionKeyToHclTerraform(struct?: BackupDrRestoreWorkloadDiskRestorePropertiesDiskEncryptionKeyOutputReference | BackupDrRestoreWorkloadDiskRestorePropertiesDiskEncryptionKey): any;
export declare class BackupDrRestoreWorkloadDiskRestorePropertiesDiskEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrRestoreWorkloadDiskRestorePropertiesDiskEncryptionKey | undefined;
    set internalValue(value: BackupDrRestoreWorkloadDiskRestorePropertiesDiskEncryptionKey | undefined);
    private _kmsKeyName?;
    get kmsKeyName(): string;
    set kmsKeyName(value: string);
    resetKmsKeyName(): void;
    get kmsKeyNameInput(): string | undefined;
    private _kmsKeyServiceAccount?;
    get kmsKeyServiceAccount(): string;
    set kmsKeyServiceAccount(value: string);
    resetKmsKeyServiceAccount(): void;
    get kmsKeyServiceAccountInput(): string | undefined;
    private _rawKey?;
    get rawKey(): string;
    set rawKey(value: string);
    resetRawKey(): void;
    get rawKeyInput(): string | undefined;
    private _rsaEncryptedKey?;
    get rsaEncryptedKey(): string;
    set rsaEncryptedKey(value: string);
    resetRsaEncryptedKey(): void;
    get rsaEncryptedKeyInput(): string | undefined;
}
export interface BackupDrRestoreWorkloadDiskRestorePropertiesGuestOsFeature {
    /**
    *  Possible values: ["FEATURE_TYPE_UNSPECIFIED", "VIRTIO_SCSI_MULTIQUEUE", "WINDOWS", "MULTI_IP_SUBNET", "UEFI_COMPATIBLE", "SECURE_BOOT", "GVNIC", "SEV_CAPABLE", "BARE_METAL_LINUX_COMPATIBLE", "SUSPEND_RESUME_COMPATIBLE", "SEV_LIVE_MIGRATABLE", "SEV_SNP_CAPABLE", "TDX_CAPABLE", "IDPF", "SEV_LIVE_MIGRATABLE_V2"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#type BackupDrRestoreWorkload#type}
    */
    readonly type?: string;
}
export declare function backupDrRestoreWorkloadDiskRestorePropertiesGuestOsFeatureToTerraform(struct?: BackupDrRestoreWorkloadDiskRestorePropertiesGuestOsFeature | cdktn.IResolvable): any;
export declare function backupDrRestoreWorkloadDiskRestorePropertiesGuestOsFeatureToHclTerraform(struct?: BackupDrRestoreWorkloadDiskRestorePropertiesGuestOsFeature | cdktn.IResolvable): any;
export declare class BackupDrRestoreWorkloadDiskRestorePropertiesGuestOsFeatureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupDrRestoreWorkloadDiskRestorePropertiesGuestOsFeature | cdktn.IResolvable | undefined;
    set internalValue(value: BackupDrRestoreWorkloadDiskRestorePropertiesGuestOsFeature | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class BackupDrRestoreWorkloadDiskRestorePropertiesGuestOsFeatureList extends cdktn.ComplexList {
    internalValue?: BackupDrRestoreWorkloadDiskRestorePropertiesGuestOsFeature[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupDrRestoreWorkloadDiskRestorePropertiesGuestOsFeatureOutputReference;
}
export interface BackupDrRestoreWorkloadDiskRestorePropertiesLabels {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#key BackupDrRestoreWorkload#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#value BackupDrRestoreWorkload#value}
    */
    readonly value?: string;
}
export declare function backupDrRestoreWorkloadDiskRestorePropertiesLabelsToTerraform(struct?: BackupDrRestoreWorkloadDiskRestorePropertiesLabels | cdktn.IResolvable): any;
export declare function backupDrRestoreWorkloadDiskRestorePropertiesLabelsToHclTerraform(struct?: BackupDrRestoreWorkloadDiskRestorePropertiesLabels | cdktn.IResolvable): any;
export declare class BackupDrRestoreWorkloadDiskRestorePropertiesLabelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupDrRestoreWorkloadDiskRestorePropertiesLabels | cdktn.IResolvable | undefined;
    set internalValue(value: BackupDrRestoreWorkloadDiskRestorePropertiesLabels | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BackupDrRestoreWorkloadDiskRestorePropertiesLabelsList extends cdktn.ComplexList {
    internalValue?: BackupDrRestoreWorkloadDiskRestorePropertiesLabels[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupDrRestoreWorkloadDiskRestorePropertiesLabelsOutputReference;
}
export interface BackupDrRestoreWorkloadDiskRestorePropertiesResourceManagerTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#key BackupDrRestoreWorkload#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#value BackupDrRestoreWorkload#value}
    */
    readonly value?: string;
}
export declare function backupDrRestoreWorkloadDiskRestorePropertiesResourceManagerTagsToTerraform(struct?: BackupDrRestoreWorkloadDiskRestorePropertiesResourceManagerTags | cdktn.IResolvable): any;
export declare function backupDrRestoreWorkloadDiskRestorePropertiesResourceManagerTagsToHclTerraform(struct?: BackupDrRestoreWorkloadDiskRestorePropertiesResourceManagerTags | cdktn.IResolvable): any;
export declare class BackupDrRestoreWorkloadDiskRestorePropertiesResourceManagerTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupDrRestoreWorkloadDiskRestorePropertiesResourceManagerTags | cdktn.IResolvable | undefined;
    set internalValue(value: BackupDrRestoreWorkloadDiskRestorePropertiesResourceManagerTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BackupDrRestoreWorkloadDiskRestorePropertiesResourceManagerTagsList extends cdktn.ComplexList {
    internalValue?: BackupDrRestoreWorkloadDiskRestorePropertiesResourceManagerTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupDrRestoreWorkloadDiskRestorePropertiesResourceManagerTagsOutputReference;
}
export interface BackupDrRestoreWorkloadDiskRestoreProperties {
    /**
    * Optional. The access mode of the disk. Possible values: ["READ_WRITE_SINGLE", "READ_WRITE_MANY", "READ_ONLY_MANY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#access_mode BackupDrRestoreWorkload#access_mode}
    */
    readonly accessMode?: string;
    /**
    * Optional. The architecture of the source disk. Possible values: ["ARCHITECTURE_UNSPECIFIED", "X86_64", "ARM64"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#architecture BackupDrRestoreWorkload#architecture}
    */
    readonly architecture?: string;
    /**
    * Optional. An optional description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#description BackupDrRestoreWorkload#description}
    */
    readonly description?: string;
    /**
    * Optional. Indicates whether this disk is using confidential compute mode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#enable_confidential_compute BackupDrRestoreWorkload#enable_confidential_compute}
    */
    readonly enableConfidentialCompute?: boolean | cdktn.IResolvable;
    /**
    * Optional. A list of publicly available licenses that are applicable to this backup.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#licenses BackupDrRestoreWorkload#licenses}
    */
    readonly licenses?: string[];
    /**
    * Required. Name of the disk.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#name BackupDrRestoreWorkload#name}
    */
    readonly name: string;
    /**
    * Optional. Physical block size of the persistent disk, in bytes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#physical_block_size_bytes BackupDrRestoreWorkload#physical_block_size_bytes}
    */
    readonly physicalBlockSizeBytes?: number;
    /**
    * Optional. Indicates how many IOPS to provision for the disk.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#provisioned_iops BackupDrRestoreWorkload#provisioned_iops}
    */
    readonly provisionedIops?: number;
    /**
    * Optional. Indicates how much throughput to provision for the disk.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#provisioned_throughput BackupDrRestoreWorkload#provisioned_throughput}
    */
    readonly provisionedThroughput?: number;
    /**
    * Optional. Resource policies applied to this disk.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#resource_policy BackupDrRestoreWorkload#resource_policy}
    */
    readonly resourcePolicy?: string[];
    /**
    * Required. The size of the disk in GB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#size_gb BackupDrRestoreWorkload#size_gb}
    */
    readonly sizeGb: number;
    /**
    * Optional. The storage pool in which the new disk is created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#storage_pool BackupDrRestoreWorkload#storage_pool}
    */
    readonly storagePool?: string;
    /**
    * Required. URL of the disk type resource describing which disk type to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#type BackupDrRestoreWorkload#type}
    */
    readonly type: string;
    /**
    * disk_encryption_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#disk_encryption_key BackupDrRestoreWorkload#disk_encryption_key}
    */
    readonly diskEncryptionKey?: BackupDrRestoreWorkloadDiskRestorePropertiesDiskEncryptionKey;
    /**
    * guest_os_feature block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#guest_os_feature BackupDrRestoreWorkload#guest_os_feature}
    */
    readonly guestOsFeature?: BackupDrRestoreWorkloadDiskRestorePropertiesGuestOsFeature[] | cdktn.IResolvable;
    /**
    * labels block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#labels BackupDrRestoreWorkload#labels}
    */
    readonly labels?: BackupDrRestoreWorkloadDiskRestorePropertiesLabels[] | cdktn.IResolvable;
    /**
    * resource_manager_tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#resource_manager_tags BackupDrRestoreWorkload#resource_manager_tags}
    */
    readonly resourceManagerTags?: BackupDrRestoreWorkloadDiskRestorePropertiesResourceManagerTags[] | cdktn.IResolvable;
}
export declare function backupDrRestoreWorkloadDiskRestorePropertiesToTerraform(struct?: BackupDrRestoreWorkloadDiskRestorePropertiesOutputReference | BackupDrRestoreWorkloadDiskRestoreProperties): any;
export declare function backupDrRestoreWorkloadDiskRestorePropertiesToHclTerraform(struct?: BackupDrRestoreWorkloadDiskRestorePropertiesOutputReference | BackupDrRestoreWorkloadDiskRestoreProperties): any;
export declare class BackupDrRestoreWorkloadDiskRestorePropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrRestoreWorkloadDiskRestoreProperties | undefined;
    set internalValue(value: BackupDrRestoreWorkloadDiskRestoreProperties | undefined);
    private _accessMode?;
    get accessMode(): string;
    set accessMode(value: string);
    resetAccessMode(): void;
    get accessModeInput(): string | undefined;
    private _architecture?;
    get architecture(): string;
    set architecture(value: string);
    resetArchitecture(): void;
    get architectureInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enableConfidentialCompute?;
    get enableConfidentialCompute(): boolean | cdktn.IResolvable;
    set enableConfidentialCompute(value: boolean | cdktn.IResolvable);
    resetEnableConfidentialCompute(): void;
    get enableConfidentialComputeInput(): boolean | cdktn.IResolvable | undefined;
    private _licenses?;
    get licenses(): string[];
    set licenses(value: string[]);
    resetLicenses(): void;
    get licensesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _physicalBlockSizeBytes?;
    get physicalBlockSizeBytes(): number;
    set physicalBlockSizeBytes(value: number);
    resetPhysicalBlockSizeBytes(): void;
    get physicalBlockSizeBytesInput(): number | undefined;
    private _provisionedIops?;
    get provisionedIops(): number;
    set provisionedIops(value: number);
    resetProvisionedIops(): void;
    get provisionedIopsInput(): number | undefined;
    private _provisionedThroughput?;
    get provisionedThroughput(): number;
    set provisionedThroughput(value: number);
    resetProvisionedThroughput(): void;
    get provisionedThroughputInput(): number | undefined;
    private _resourcePolicy?;
    get resourcePolicy(): string[];
    set resourcePolicy(value: string[]);
    resetResourcePolicy(): void;
    get resourcePolicyInput(): string[] | undefined;
    private _sizeGb?;
    get sizeGb(): number;
    set sizeGb(value: number);
    get sizeGbInput(): number | undefined;
    private _storagePool?;
    get storagePool(): string;
    set storagePool(value: string);
    resetStoragePool(): void;
    get storagePoolInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _diskEncryptionKey;
    get diskEncryptionKey(): BackupDrRestoreWorkloadDiskRestorePropertiesDiskEncryptionKeyOutputReference;
    putDiskEncryptionKey(value: BackupDrRestoreWorkloadDiskRestorePropertiesDiskEncryptionKey): void;
    resetDiskEncryptionKey(): void;
    get diskEncryptionKeyInput(): BackupDrRestoreWorkloadDiskRestorePropertiesDiskEncryptionKey | undefined;
    private _guestOsFeature;
    get guestOsFeature(): BackupDrRestoreWorkloadDiskRestorePropertiesGuestOsFeatureList;
    putGuestOsFeature(value: BackupDrRestoreWorkloadDiskRestorePropertiesGuestOsFeature[] | cdktn.IResolvable): void;
    resetGuestOsFeature(): void;
    get guestOsFeatureInput(): cdktn.IResolvable | BackupDrRestoreWorkloadDiskRestorePropertiesGuestOsFeature[] | undefined;
    private _labels;
    get labels(): BackupDrRestoreWorkloadDiskRestorePropertiesLabelsList;
    putLabels(value: BackupDrRestoreWorkloadDiskRestorePropertiesLabels[] | cdktn.IResolvable): void;
    resetLabels(): void;
    get labelsInput(): cdktn.IResolvable | BackupDrRestoreWorkloadDiskRestorePropertiesLabels[] | undefined;
    private _resourceManagerTags;
    get resourceManagerTags(): BackupDrRestoreWorkloadDiskRestorePropertiesResourceManagerTagsList;
    putResourceManagerTags(value: BackupDrRestoreWorkloadDiskRestorePropertiesResourceManagerTags[] | cdktn.IResolvable): void;
    resetResourceManagerTags(): void;
    get resourceManagerTagsInput(): cdktn.IResolvable | BackupDrRestoreWorkloadDiskRestorePropertiesResourceManagerTags[] | undefined;
}
export interface BackupDrRestoreWorkloadDiskTargetEnvironment {
    /**
    * Required. Target project for the disk.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#project BackupDrRestoreWorkload#project}
    */
    readonly project: string;
    /**
    * If true, use the BackupDR P4SA credentials for same-project restores. Default is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#use_project_service_account BackupDrRestoreWorkload#use_project_service_account}
    */
    readonly useProjectServiceAccount?: boolean | cdktn.IResolvable;
    /**
    * Required. Target zone for the disk.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#zone BackupDrRestoreWorkload#zone}
    */
    readonly zone: string;
}
export declare function backupDrRestoreWorkloadDiskTargetEnvironmentToTerraform(struct?: BackupDrRestoreWorkloadDiskTargetEnvironmentOutputReference | BackupDrRestoreWorkloadDiskTargetEnvironment): any;
export declare function backupDrRestoreWorkloadDiskTargetEnvironmentToHclTerraform(struct?: BackupDrRestoreWorkloadDiskTargetEnvironmentOutputReference | BackupDrRestoreWorkloadDiskTargetEnvironment): any;
export declare class BackupDrRestoreWorkloadDiskTargetEnvironmentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrRestoreWorkloadDiskTargetEnvironment | undefined;
    set internalValue(value: BackupDrRestoreWorkloadDiskTargetEnvironment | undefined);
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _useProjectServiceAccount?;
    get useProjectServiceAccount(): boolean | cdktn.IResolvable;
    set useProjectServiceAccount(value: boolean | cdktn.IResolvable);
    resetUseProjectServiceAccount(): void;
    get useProjectServiceAccountInput(): boolean | cdktn.IResolvable | undefined;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    get zoneInput(): string | undefined;
}
export interface BackupDrRestoreWorkloadRegionDiskTargetEnvironment {
    /**
    * Required. Target project for the disk.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#project BackupDrRestoreWorkload#project}
    */
    readonly project: string;
    /**
    * Required. Target region for the disk.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#region BackupDrRestoreWorkload#region}
    */
    readonly region: string;
    /**
    * Required. Target URLs of the replica zones for the disk.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#replica_zones BackupDrRestoreWorkload#replica_zones}
    */
    readonly replicaZones: string[];
    /**
    * If true, use the BackupDR P4SA credentials for same-project restores. Default is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#use_project_service_account BackupDrRestoreWorkload#use_project_service_account}
    */
    readonly useProjectServiceAccount?: boolean | cdktn.IResolvable;
}
export declare function backupDrRestoreWorkloadRegionDiskTargetEnvironmentToTerraform(struct?: BackupDrRestoreWorkloadRegionDiskTargetEnvironmentOutputReference | BackupDrRestoreWorkloadRegionDiskTargetEnvironment): any;
export declare function backupDrRestoreWorkloadRegionDiskTargetEnvironmentToHclTerraform(struct?: BackupDrRestoreWorkloadRegionDiskTargetEnvironmentOutputReference | BackupDrRestoreWorkloadRegionDiskTargetEnvironment): any;
export declare class BackupDrRestoreWorkloadRegionDiskTargetEnvironmentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrRestoreWorkloadRegionDiskTargetEnvironment | undefined;
    set internalValue(value: BackupDrRestoreWorkloadRegionDiskTargetEnvironment | undefined);
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _replicaZones?;
    get replicaZones(): string[];
    set replicaZones(value: string[]);
    get replicaZonesInput(): string[] | undefined;
    private _useProjectServiceAccount?;
    get useProjectServiceAccount(): boolean | cdktn.IResolvable;
    set useProjectServiceAccount(value: boolean | cdktn.IResolvable);
    resetUseProjectServiceAccount(): void;
    get useProjectServiceAccountInput(): boolean | cdktn.IResolvable | undefined;
}
export interface BackupDrRestoreWorkloadTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#create BackupDrRestoreWorkload#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#delete BackupDrRestoreWorkload#delete}
    */
    readonly delete?: string;
}
export declare function backupDrRestoreWorkloadTimeoutsToTerraform(struct?: BackupDrRestoreWorkloadTimeouts | cdktn.IResolvable): any;
export declare function backupDrRestoreWorkloadTimeoutsToHclTerraform(struct?: BackupDrRestoreWorkloadTimeouts | cdktn.IResolvable): any;
export declare class BackupDrRestoreWorkloadTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrRestoreWorkloadTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BackupDrRestoreWorkloadTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload google_backup_dr_restore_workload}
*/
export declare class BackupDrRestoreWorkload extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_backup_dr_restore_workload";
    /**
    * Generates CDKTN code for importing a BackupDrRestoreWorkload resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BackupDrRestoreWorkload to import
    * @param importFromId The id of the existing BackupDrRestoreWorkload that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BackupDrRestoreWorkload to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/backup_dr_restore_workload google_backup_dr_restore_workload} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BackupDrRestoreWorkloadConfig
    */
    constructor(scope: Construct, id: string, config: BackupDrRestoreWorkloadConfig);
    private _backupId?;
    get backupId(): string;
    set backupId(value: string);
    get backupIdInput(): string | undefined;
    private _backupVaultId?;
    get backupVaultId(): string;
    set backupVaultId(value: string);
    get backupVaultIdInput(): string | undefined;
    private _clearOverridesFieldMask?;
    get clearOverridesFieldMask(): string;
    set clearOverridesFieldMask(value: string);
    resetClearOverridesFieldMask(): void;
    get clearOverridesFieldMaskInput(): string | undefined;
    private _dataSourceId?;
    get dataSourceId(): string;
    set dataSourceId(value: string);
    get dataSourceIdInput(): string | undefined;
    private _deleteRestoredInstance?;
    get deleteRestoredInstance(): boolean | cdktn.IResolvable;
    set deleteRestoredInstance(value: boolean | cdktn.IResolvable);
    resetDeleteRestoredInstance(): void;
    get deleteRestoredInstanceInput(): boolean | cdktn.IResolvable | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _requestId?;
    get requestId(): string;
    set requestId(value: string);
    resetRequestId(): void;
    get requestIdInput(): string | undefined;
    private _targetResource;
    get targetResource(): BackupDrRestoreWorkloadTargetResourceList;
    private _computeInstanceRestoreProperties;
    get computeInstanceRestoreProperties(): BackupDrRestoreWorkloadComputeInstanceRestorePropertiesOutputReference;
    putComputeInstanceRestoreProperties(value: BackupDrRestoreWorkloadComputeInstanceRestoreProperties): void;
    resetComputeInstanceRestoreProperties(): void;
    get computeInstanceRestorePropertiesInput(): BackupDrRestoreWorkloadComputeInstanceRestoreProperties | undefined;
    private _computeInstanceTargetEnvironment;
    get computeInstanceTargetEnvironment(): BackupDrRestoreWorkloadComputeInstanceTargetEnvironmentOutputReference;
    putComputeInstanceTargetEnvironment(value: BackupDrRestoreWorkloadComputeInstanceTargetEnvironment): void;
    resetComputeInstanceTargetEnvironment(): void;
    get computeInstanceTargetEnvironmentInput(): BackupDrRestoreWorkloadComputeInstanceTargetEnvironment | undefined;
    private _diskRestoreProperties;
    get diskRestoreProperties(): BackupDrRestoreWorkloadDiskRestorePropertiesOutputReference;
    putDiskRestoreProperties(value: BackupDrRestoreWorkloadDiskRestoreProperties): void;
    resetDiskRestoreProperties(): void;
    get diskRestorePropertiesInput(): BackupDrRestoreWorkloadDiskRestoreProperties | undefined;
    private _diskTargetEnvironment;
    get diskTargetEnvironment(): BackupDrRestoreWorkloadDiskTargetEnvironmentOutputReference;
    putDiskTargetEnvironment(value: BackupDrRestoreWorkloadDiskTargetEnvironment): void;
    resetDiskTargetEnvironment(): void;
    get diskTargetEnvironmentInput(): BackupDrRestoreWorkloadDiskTargetEnvironment | undefined;
    private _regionDiskTargetEnvironment;
    get regionDiskTargetEnvironment(): BackupDrRestoreWorkloadRegionDiskTargetEnvironmentOutputReference;
    putRegionDiskTargetEnvironment(value: BackupDrRestoreWorkloadRegionDiskTargetEnvironment): void;
    resetRegionDiskTargetEnvironment(): void;
    get regionDiskTargetEnvironmentInput(): BackupDrRestoreWorkloadRegionDiskTargetEnvironment | undefined;
    private _timeouts;
    get timeouts(): BackupDrRestoreWorkloadTimeoutsOutputReference;
    putTimeouts(value: BackupDrRestoreWorkloadTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BackupDrRestoreWorkloadTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
