/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigeeEnvgroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_envgroup#deletion_policy ApigeeEnvgroup#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Hostnames of the environment group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_envgroup#hostnames ApigeeEnvgroup#hostnames}
    */
    readonly hostnames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_envgroup#id ApigeeEnvgroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The resource ID of the environment group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_envgroup#name ApigeeEnvgroup#name}
    */
    readonly name: string;
    /**
    * The Apigee Organization associated with the Apigee environment group,
    * in the format 'organizations/{{org_name}}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_envgroup#org_id ApigeeEnvgroup#org_id}
    */
    readonly orgId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_envgroup#timeouts ApigeeEnvgroup#timeouts}
    */
    readonly timeouts?: ApigeeEnvgroupTimeouts;
}
export interface ApigeeEnvgroupTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_envgroup#create ApigeeEnvgroup#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_envgroup#delete ApigeeEnvgroup#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_envgroup#update ApigeeEnvgroup#update}
    */
    readonly update?: string;
}
export declare function apigeeEnvgroupTimeoutsToTerraform(struct?: ApigeeEnvgroupTimeouts | cdktn.IResolvable): any;
export declare function apigeeEnvgroupTimeoutsToHclTerraform(struct?: ApigeeEnvgroupTimeouts | cdktn.IResolvable): any;
export declare class ApigeeEnvgroupTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeEnvgroupTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeEnvgroupTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_envgroup google_apigee_envgroup}
*/
export declare class ApigeeEnvgroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apigee_envgroup";
    /**
    * Generates CDKTN code for importing a ApigeeEnvgroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigeeEnvgroup to import
    * @param importFromId The id of the existing ApigeeEnvgroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_envgroup#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigeeEnvgroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_envgroup google_apigee_envgroup} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigeeEnvgroupConfig
    */
    constructor(scope: Construct, id: string, config: ApigeeEnvgroupConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _hostnames?;
    get hostnames(): string[];
    set hostnames(value: string[]);
    resetHostnames(): void;
    get hostnamesInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _orgId?;
    get orgId(): string;
    set orgId(value: string);
    get orgIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): ApigeeEnvgroupTimeoutsOutputReference;
    putTimeouts(value: ApigeeEnvgroupTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApigeeEnvgroupTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
