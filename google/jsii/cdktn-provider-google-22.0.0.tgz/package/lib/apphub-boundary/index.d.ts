/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApphubBoundaryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Optional. The resource name of the CRM node being attached to the
    * boundary.
    * Format: 'projects/{project-number}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_boundary#crm_node ApphubBoundary#crm_node}
    */
    readonly crmNode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_boundary#id ApphubBoundary#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location for the Boundary resource. Must be global.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_boundary#location ApphubBoundary#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_boundary#project ApphubBoundary#project}
    */
    readonly project?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_boundary#timeouts ApphubBoundary#timeouts}
    */
    readonly timeouts?: ApphubBoundaryTimeouts;
}
export interface ApphubBoundaryTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_boundary#create ApphubBoundary#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_boundary#delete ApphubBoundary#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_boundary#update ApphubBoundary#update}
    */
    readonly update?: string;
}
export declare function apphubBoundaryTimeoutsToTerraform(struct?: ApphubBoundaryTimeouts | cdktn.IResolvable): any;
export declare function apphubBoundaryTimeoutsToHclTerraform(struct?: ApphubBoundaryTimeouts | cdktn.IResolvable): any;
export declare class ApphubBoundaryTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApphubBoundaryTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApphubBoundaryTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_boundary google_apphub_boundary}
*/
export declare class ApphubBoundary extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apphub_boundary";
    /**
    * Generates CDKTN code for importing a ApphubBoundary resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApphubBoundary to import
    * @param importFromId The id of the existing ApphubBoundary that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_boundary#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApphubBoundary to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apphub_boundary google_apphub_boundary} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApphubBoundaryConfig
    */
    constructor(scope: Construct, id: string, config: ApphubBoundaryConfig);
    get createTime(): string;
    private _crmNode?;
    get crmNode(): string;
    set crmNode(value: string);
    resetCrmNode(): void;
    get crmNodeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get type(): string;
    get updateTime(): string;
    private _timeouts;
    get timeouts(): ApphubBoundaryTimeoutsOutputReference;
    putTimeouts(value: ApphubBoundaryTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApphubBoundaryTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
