/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChronicleCaseCloseDefinitionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specify why the case was closed. Possible values: ["MALICIOUS", "NOT_MALICIOUS", "MAINTENANCE", "INCONCLUSIVE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_case_close_definition#close_reason ChronicleCaseCloseDefinition#close_reason}
    */
    readonly closeReason: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_case_close_definition#deletion_policy ChronicleCaseCloseDefinition#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_case_close_definition#id ChronicleCaseCloseDefinition#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The unique identifier for the Chronicle instance, which is the same as the customer ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_case_close_definition#instance ChronicleCaseCloseDefinition#instance}
    */
    readonly instance: string;
    /**
    * The location of the resource. This is the geographical region where the Chronicle instance resides, such as "us" or "europe-west2".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_case_close_definition#location ChronicleCaseCloseDefinition#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_case_close_definition#project ChronicleCaseCloseDefinition#project}
    */
    readonly project?: string;
    /**
    * Provides detailed description about the specific root cause option.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_case_close_definition#root_cause ChronicleCaseCloseDefinition#root_cause}
    */
    readonly rootCause: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_case_close_definition#timeouts ChronicleCaseCloseDefinition#timeouts}
    */
    readonly timeouts?: ChronicleCaseCloseDefinitionTimeouts;
}
export interface ChronicleCaseCloseDefinitionTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_case_close_definition#create ChronicleCaseCloseDefinition#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_case_close_definition#delete ChronicleCaseCloseDefinition#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_case_close_definition#update ChronicleCaseCloseDefinition#update}
    */
    readonly update?: string;
}
export declare function chronicleCaseCloseDefinitionTimeoutsToTerraform(struct?: ChronicleCaseCloseDefinitionTimeouts | cdktn.IResolvable): any;
export declare function chronicleCaseCloseDefinitionTimeoutsToHclTerraform(struct?: ChronicleCaseCloseDefinitionTimeouts | cdktn.IResolvable): any;
export declare class ChronicleCaseCloseDefinitionTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleCaseCloseDefinitionTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleCaseCloseDefinitionTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_case_close_definition google_chronicle_case_close_definition}
*/
export declare class ChronicleCaseCloseDefinition extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_chronicle_case_close_definition";
    /**
    * Generates CDKTN code for importing a ChronicleCaseCloseDefinition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChronicleCaseCloseDefinition to import
    * @param importFromId The id of the existing ChronicleCaseCloseDefinition that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_case_close_definition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChronicleCaseCloseDefinition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_case_close_definition google_chronicle_case_close_definition} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChronicleCaseCloseDefinitionConfig
    */
    constructor(scope: Construct, id: string, config: ChronicleCaseCloseDefinitionConfig);
    get caseCloseDefinitionId(): string;
    private _closeReason?;
    get closeReason(): string;
    set closeReason(value: string);
    get closeReasonInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instance?;
    get instance(): string;
    set instance(value: string);
    get instanceInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _rootCause?;
    get rootCause(): string;
    set rootCause(value: string);
    get rootCauseInput(): string | undefined;
    private _timeouts;
    get timeouts(): ChronicleCaseCloseDefinitionTimeoutsOutputReference;
    putTimeouts(value: ChronicleCaseCloseDefinitionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ChronicleCaseCloseDefinitionTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
