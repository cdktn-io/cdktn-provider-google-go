/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeRegionInstanceGroupManagerConfig extends cdktn.TerraformMetaArguments {
    /**
    * The base instance name to use for instances in this group. The value must be a valid RFC1035 name. Supported characters are lowercase letters, numbers, and hyphens (-). Instances are named by appending a hyphen and a random four-character string to the base instance name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#base_instance_name ComputeRegionInstanceGroupManager#base_instance_name}
    */
    readonly baseInstanceName: string;
    /**
    * Whether Terraform will be prevented from destroying the resource. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed. If graceful shutdown is configured, the MIG deletion waits for all instances to shut down gracefully before deletion.
    * When set to "FORCE", deleting the resource is allowed, and graceful shutdown is skipped for instance deletion even if it's configured for the instances.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#deletion_policy ComputeRegionInstanceGroupManager#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional textual description of the instance group manager.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#description ComputeRegionInstanceGroupManager#description}
    */
    readonly description?: string;
    /**
    * The shape to which the group converges either proactively or on resize events (depending on the value set in updatePolicy.instanceRedistributionType).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#distribution_policy_target_shape ComputeRegionInstanceGroupManager#distribution_policy_target_shape}
    */
    readonly distributionPolicyTargetShape?: string;
    /**
    * The distribution policy for this managed instance group. You can specify one or more values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#distribution_policy_zones ComputeRegionInstanceGroupManager#distribution_policy_zones}
    */
    readonly distributionPolicyZones?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#id ComputeRegionInstanceGroupManager#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Pagination behavior of the listManagedInstances API method for this managed instance group. Valid values are: "PAGELESS", "PAGINATED". If PAGELESS (default), Pagination is disabled for the group's listManagedInstances API method. maxResults and pageToken query parameters are ignored and all instances are returned in a single response. If PAGINATED, pagination is enabled, maxResults and pageToken query parameters are respected.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#list_managed_instances_results ComputeRegionInstanceGroupManager#list_managed_instances_results}
    */
    readonly listManagedInstancesResults?: string;
    /**
    * The name of the instance group manager. Must be 1-63 characters long and comply with RFC1035. Supported characters include lowercase letters, numbers, and hyphens.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#name ComputeRegionInstanceGroupManager#name}
    */
    readonly name: string;
    /**
    * The ID of the project in which the resource belongs. If it is not provided, the provider project is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#project ComputeRegionInstanceGroupManager#project}
    */
    readonly project?: string;
    /**
    * The region where the managed instance group resides.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#region ComputeRegionInstanceGroupManager#region}
    */
    readonly region?: string;
    /**
    * The full URL of all target pools to which new instances in the group are added. Updating the target pools attribute does not affect existing instances.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#target_pools ComputeRegionInstanceGroupManager#target_pools}
    */
    readonly targetPools?: string[];
    /**
    * The target number of running instances for this managed instance group. This value should always be explicitly set unless this resource is attached to an autoscaler, in which case it should never be set. Defaults to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#target_size ComputeRegionInstanceGroupManager#target_size}
    */
    readonly targetSize?: number;
    /**
    * The target number of stopped instances for this managed instance group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#target_stopped_size ComputeRegionInstanceGroupManager#target_stopped_size}
    */
    readonly targetStoppedSize?: number;
    /**
    * The target number of suspended instances for this managed instance group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#target_suspended_size ComputeRegionInstanceGroupManager#target_suspended_size}
    */
    readonly targetSuspendedSize?: number;
    /**
    * Whether to wait for all instances to be created/updated before returning. Note that if this is set to true and the operation does not succeed, Terraform will continue trying until it times out.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#wait_for_instances ComputeRegionInstanceGroupManager#wait_for_instances}
    */
    readonly waitForInstances?: boolean | cdktn.IResolvable;
    /**
    * When used with wait_for_instances specifies the status to wait for. When STABLE is specified this resource will wait until the instances are stable before returning. When UPDATED is set, it will wait for the version target to be reached and any per instance configs to be effective and all instances configs to be effective as well as all instances to be stable before returning.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#wait_for_instances_status ComputeRegionInstanceGroupManager#wait_for_instances_status}
    */
    readonly waitForInstancesStatus?: string;
    /**
    * all_instances_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#all_instances_config ComputeRegionInstanceGroupManager#all_instances_config}
    */
    readonly allInstancesConfig?: ComputeRegionInstanceGroupManagerAllInstancesConfig;
    /**
    * auto_healing_policies block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#auto_healing_policies ComputeRegionInstanceGroupManager#auto_healing_policies}
    */
    readonly autoHealingPolicies?: ComputeRegionInstanceGroupManagerAutoHealingPolicies;
    /**
    * instance_flexibility_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#instance_flexibility_policy ComputeRegionInstanceGroupManager#instance_flexibility_policy}
    */
    readonly instanceFlexibilityPolicy?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicy;
    /**
    * instance_lifecycle_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#instance_lifecycle_policy ComputeRegionInstanceGroupManager#instance_lifecycle_policy}
    */
    readonly instanceLifecyclePolicy?: ComputeRegionInstanceGroupManagerInstanceLifecyclePolicy;
    /**
    * named_port block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#named_port ComputeRegionInstanceGroupManager#named_port}
    */
    readonly namedPort?: ComputeRegionInstanceGroupManagerNamedPort[] | cdktn.IResolvable;
    /**
    * resource_policies block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#resource_policies ComputeRegionInstanceGroupManager#resource_policies}
    */
    readonly resourcePolicies?: ComputeRegionInstanceGroupManagerResourcePolicies;
    /**
    * standby_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#standby_policy ComputeRegionInstanceGroupManager#standby_policy}
    */
    readonly standbyPolicy?: ComputeRegionInstanceGroupManagerStandbyPolicy;
    /**
    * stateful_disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#stateful_disk ComputeRegionInstanceGroupManager#stateful_disk}
    */
    readonly statefulDisk?: ComputeRegionInstanceGroupManagerStatefulDisk[] | cdktn.IResolvable;
    /**
    * stateful_external_ip block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#stateful_external_ip ComputeRegionInstanceGroupManager#stateful_external_ip}
    */
    readonly statefulExternalIp?: ComputeRegionInstanceGroupManagerStatefulExternalIp[] | cdktn.IResolvable;
    /**
    * stateful_internal_ip block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#stateful_internal_ip ComputeRegionInstanceGroupManager#stateful_internal_ip}
    */
    readonly statefulInternalIp?: ComputeRegionInstanceGroupManagerStatefulInternalIp[] | cdktn.IResolvable;
    /**
    * target_size_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#target_size_policy ComputeRegionInstanceGroupManager#target_size_policy}
    */
    readonly targetSizePolicy?: ComputeRegionInstanceGroupManagerTargetSizePolicy[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#timeouts ComputeRegionInstanceGroupManager#timeouts}
    */
    readonly timeouts?: ComputeRegionInstanceGroupManagerTimeouts;
    /**
    * update_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#update_policy ComputeRegionInstanceGroupManager#update_policy}
    */
    readonly updatePolicy?: ComputeRegionInstanceGroupManagerUpdatePolicy;
    /**
    * version block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#version ComputeRegionInstanceGroupManager#version}
    */
    readonly version: ComputeRegionInstanceGroupManagerVersion[] | cdktn.IResolvable;
}
export interface ComputeRegionInstanceGroupManagerStatusAllInstancesConfig {
}
export declare function computeRegionInstanceGroupManagerStatusAllInstancesConfigToTerraform(struct?: ComputeRegionInstanceGroupManagerStatusAllInstancesConfig): any;
export declare function computeRegionInstanceGroupManagerStatusAllInstancesConfigToHclTerraform(struct?: ComputeRegionInstanceGroupManagerStatusAllInstancesConfig): any;
export declare class ComputeRegionInstanceGroupManagerStatusAllInstancesConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionInstanceGroupManagerStatusAllInstancesConfig | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerStatusAllInstancesConfig | undefined);
    get currentRevision(): string;
    get effective(): cdktn.IResolvable;
}
export declare class ComputeRegionInstanceGroupManagerStatusAllInstancesConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionInstanceGroupManagerStatusAllInstancesConfigOutputReference;
}
export interface ComputeRegionInstanceGroupManagerStatusStatefulPerInstanceConfigs {
}
export declare function computeRegionInstanceGroupManagerStatusStatefulPerInstanceConfigsToTerraform(struct?: ComputeRegionInstanceGroupManagerStatusStatefulPerInstanceConfigs): any;
export declare function computeRegionInstanceGroupManagerStatusStatefulPerInstanceConfigsToHclTerraform(struct?: ComputeRegionInstanceGroupManagerStatusStatefulPerInstanceConfigs): any;
export declare class ComputeRegionInstanceGroupManagerStatusStatefulPerInstanceConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionInstanceGroupManagerStatusStatefulPerInstanceConfigs | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerStatusStatefulPerInstanceConfigs | undefined);
    get allEffective(): cdktn.IResolvable;
}
export declare class ComputeRegionInstanceGroupManagerStatusStatefulPerInstanceConfigsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionInstanceGroupManagerStatusStatefulPerInstanceConfigsOutputReference;
}
export interface ComputeRegionInstanceGroupManagerStatusStateful {
}
export declare function computeRegionInstanceGroupManagerStatusStatefulToTerraform(struct?: ComputeRegionInstanceGroupManagerStatusStateful): any;
export declare function computeRegionInstanceGroupManagerStatusStatefulToHclTerraform(struct?: ComputeRegionInstanceGroupManagerStatusStateful): any;
export declare class ComputeRegionInstanceGroupManagerStatusStatefulOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionInstanceGroupManagerStatusStateful | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerStatusStateful | undefined);
    get hasStatefulConfig(): cdktn.IResolvable;
    private _perInstanceConfigs;
    get perInstanceConfigs(): ComputeRegionInstanceGroupManagerStatusStatefulPerInstanceConfigsList;
}
export declare class ComputeRegionInstanceGroupManagerStatusStatefulList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionInstanceGroupManagerStatusStatefulOutputReference;
}
export interface ComputeRegionInstanceGroupManagerStatusVersionTarget {
}
export declare function computeRegionInstanceGroupManagerStatusVersionTargetToTerraform(struct?: ComputeRegionInstanceGroupManagerStatusVersionTarget): any;
export declare function computeRegionInstanceGroupManagerStatusVersionTargetToHclTerraform(struct?: ComputeRegionInstanceGroupManagerStatusVersionTarget): any;
export declare class ComputeRegionInstanceGroupManagerStatusVersionTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionInstanceGroupManagerStatusVersionTarget | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerStatusVersionTarget | undefined);
    get isReached(): cdktn.IResolvable;
}
export declare class ComputeRegionInstanceGroupManagerStatusVersionTargetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionInstanceGroupManagerStatusVersionTargetOutputReference;
}
export interface ComputeRegionInstanceGroupManagerStatus {
}
export declare function computeRegionInstanceGroupManagerStatusToTerraform(struct?: ComputeRegionInstanceGroupManagerStatus): any;
export declare function computeRegionInstanceGroupManagerStatusToHclTerraform(struct?: ComputeRegionInstanceGroupManagerStatus): any;
export declare class ComputeRegionInstanceGroupManagerStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionInstanceGroupManagerStatus | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerStatus | undefined);
    private _allInstancesConfig;
    get allInstancesConfig(): ComputeRegionInstanceGroupManagerStatusAllInstancesConfigList;
    get isStable(): cdktn.IResolvable;
    private _stateful;
    get stateful(): ComputeRegionInstanceGroupManagerStatusStatefulList;
    private _versionTarget;
    get versionTarget(): ComputeRegionInstanceGroupManagerStatusVersionTargetList;
}
export declare class ComputeRegionInstanceGroupManagerStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionInstanceGroupManagerStatusOutputReference;
}
export interface ComputeRegionInstanceGroupManagerAllInstancesConfig {
    /**
    * The label key-value pairs that you want to patch onto the instance,
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#labels ComputeRegionInstanceGroupManager#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The metadata key-value pairs that you want to patch onto the instance. For more information, see Project and instance metadata,
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#metadata ComputeRegionInstanceGroupManager#metadata}
    */
    readonly metadata?: {
        [key: string]: string;
    };
}
export declare function computeRegionInstanceGroupManagerAllInstancesConfigToTerraform(struct?: ComputeRegionInstanceGroupManagerAllInstancesConfigOutputReference | ComputeRegionInstanceGroupManagerAllInstancesConfig): any;
export declare function computeRegionInstanceGroupManagerAllInstancesConfigToHclTerraform(struct?: ComputeRegionInstanceGroupManagerAllInstancesConfigOutputReference | ComputeRegionInstanceGroupManagerAllInstancesConfig): any;
export declare class ComputeRegionInstanceGroupManagerAllInstancesConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceGroupManagerAllInstancesConfig | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerAllInstancesConfig | undefined);
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _metadata?;
    get metadata(): {
        [key: string]: string;
    };
    set metadata(value: {
        [key: string]: string;
    });
    resetMetadata(): void;
    get metadataInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ComputeRegionInstanceGroupManagerAutoHealingPolicies {
    /**
    * The health check resource that signals autohealing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#health_check ComputeRegionInstanceGroupManager#health_check}
    */
    readonly healthCheck: string;
    /**
    * The number of seconds that the managed instance group waits before it applies autohealing policies to new instances or recently recreated instances. Between 0 and 3600.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#initial_delay_sec ComputeRegionInstanceGroupManager#initial_delay_sec}
    */
    readonly initialDelaySec: number;
}
export declare function computeRegionInstanceGroupManagerAutoHealingPoliciesToTerraform(struct?: ComputeRegionInstanceGroupManagerAutoHealingPoliciesOutputReference | ComputeRegionInstanceGroupManagerAutoHealingPolicies): any;
export declare function computeRegionInstanceGroupManagerAutoHealingPoliciesToHclTerraform(struct?: ComputeRegionInstanceGroupManagerAutoHealingPoliciesOutputReference | ComputeRegionInstanceGroupManagerAutoHealingPolicies): any;
export declare class ComputeRegionInstanceGroupManagerAutoHealingPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceGroupManagerAutoHealingPolicies | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerAutoHealingPolicies | undefined);
    private _healthCheck?;
    get healthCheck(): string;
    set healthCheck(value: string);
    get healthCheckInput(): string | undefined;
    private _initialDelaySec?;
    get initialDelaySec(): number;
    set initialDelaySec(value: number);
    get initialDelaySecInput(): number | undefined;
}
export interface ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksDiskEncryptionKey {
    /**
    * The self link of the encryption key that is stored in Google Cloud KMS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#kms_key_self_link ComputeRegionInstanceGroupManager#kms_key_self_link}
    */
    readonly kmsKeySelfLink?: string;
    /**
    * The service account being used for the encryption request for the given KMS key. If absent, the Compute Engine default service account is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#kms_key_service_account ComputeRegionInstanceGroupManager#kms_key_service_account}
    */
    readonly kmsKeyServiceAccount?: string;
    /**
    * Specifies a 256-bit customer-supplied encryption key, encoded in RFC 4648 base64 to either encrypt or decrypt this resource. Only one of kms_key_self_link, rsa_encrypted_key and raw_key may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#raw_key ComputeRegionInstanceGroupManager#raw_key}
    */
    readonly rawKey?: string;
    /**
    * Specifies an RFC 4648 base64 encoded, RSA-wrapped 2048-bit customer-supplied encryption key to either encrypt or decrypt this resource. Only one of kms_key_self_link, rsa_encrypted_key and raw_key may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#rsa_encrypted_key ComputeRegionInstanceGroupManager#rsa_encrypted_key}
    */
    readonly rsaEncryptedKey?: string;
}
export declare function computeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksDiskEncryptionKeyToTerraform(struct?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksDiskEncryptionKeyOutputReference | ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksDiskEncryptionKey): any;
export declare function computeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksDiskEncryptionKeyToHclTerraform(struct?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksDiskEncryptionKeyOutputReference | ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksDiskEncryptionKey): any;
export declare class ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksDiskEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksDiskEncryptionKey | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksDiskEncryptionKey | undefined);
    private _kmsKeySelfLink?;
    get kmsKeySelfLink(): string;
    set kmsKeySelfLink(value: string);
    resetKmsKeySelfLink(): void;
    get kmsKeySelfLinkInput(): string | undefined;
    private _kmsKeyServiceAccount?;
    get kmsKeyServiceAccount(): string;
    set kmsKeyServiceAccount(value: string);
    resetKmsKeyServiceAccount(): void;
    get kmsKeyServiceAccountInput(): string | undefined;
    private _rawKey?;
    get rawKey(): string;
    set rawKey(value: string);
    resetRawKey(): void;
    get rawKeyInput(): string | undefined;
    private _rsaEncryptedKey?;
    get rsaEncryptedKey(): string;
    set rsaEncryptedKey(value: string);
    resetRsaEncryptedKey(): void;
    get rsaEncryptedKeyInput(): string | undefined;
}
export interface ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksLabels {
    /**
    * The unique key of the label to assign to disks.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#key ComputeRegionInstanceGroupManager#key}
    */
    readonly key: string;
    /**
    * The value of the label to assign to disks.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#value ComputeRegionInstanceGroupManager#value}
    */
    readonly value: string;
}
export declare function computeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksLabelsToTerraform(struct?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksLabels | cdktn.IResolvable): any;
export declare function computeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksLabelsToHclTerraform(struct?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksLabels | cdktn.IResolvable): any;
export declare class ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksLabelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksLabels | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksLabels | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksLabelsList extends cdktn.ComplexList {
    internalValue?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksLabels[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksLabelsOutputReference;
}
export interface ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksResourceManagerTags {
    /**
    * The unique key of the resource manager tag to assign to disks. Keys must be in the format tagKeys/{tag_key_id}.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#key ComputeRegionInstanceGroupManager#key}
    */
    readonly key: string;
    /**
    * The value of the resource manager tag to assign to disks. Values must be in the format tagValues/456.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#value ComputeRegionInstanceGroupManager#value}
    */
    readonly value: string;
}
export declare function computeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksResourceManagerTagsToTerraform(struct?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksResourceManagerTags | cdktn.IResolvable): any;
export declare function computeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksResourceManagerTagsToHclTerraform(struct?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksResourceManagerTags | cdktn.IResolvable): any;
export declare class ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksResourceManagerTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksResourceManagerTags | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksResourceManagerTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksResourceManagerTagsList extends cdktn.ComplexList {
    internalValue?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksResourceManagerTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksResourceManagerTagsOutputReference;
}
export interface ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceImageEncryptionKey {
    /**
    * The self link of the encryption key that is stored in Google Cloud KMS. Only one of kms_key_self_link, rsa_encrypted_key and raw_key may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#kms_key_self_link ComputeRegionInstanceGroupManager#kms_key_self_link}
    */
    readonly kmsKeySelfLink?: string;
    /**
    * The service account being used for the encryption request for the given KMS key. If absent, the Compute Engine default service account is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#kms_key_service_account ComputeRegionInstanceGroupManager#kms_key_service_account}
    */
    readonly kmsKeyServiceAccount?: string;
    /**
    * Specifies a 256-bit customer-supplied encryption key, encoded in RFC 4648 base64 to either encrypt or decrypt this resource. Only one of kms_key_self_link, rsa_encrypted_key and raw_key may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#raw_key ComputeRegionInstanceGroupManager#raw_key}
    */
    readonly rawKey?: string;
    /**
    * Specifies an RFC 4648 base64 encoded, RSA-wrapped 2048-bit customer-supplied encryption key to either encrypt or decrypt this resource. Only one of kms_key_self_link, rsa_encrypted_key and raw_key may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#rsa_encrypted_key ComputeRegionInstanceGroupManager#rsa_encrypted_key}
    */
    readonly rsaEncryptedKey?: string;
}
export declare function computeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceImageEncryptionKeyToTerraform(struct?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceImageEncryptionKeyOutputReference | ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceImageEncryptionKey): any;
export declare function computeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceImageEncryptionKeyToHclTerraform(struct?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceImageEncryptionKeyOutputReference | ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceImageEncryptionKey): any;
export declare class ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceImageEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceImageEncryptionKey | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceImageEncryptionKey | undefined);
    private _kmsKeySelfLink?;
    get kmsKeySelfLink(): string;
    set kmsKeySelfLink(value: string);
    resetKmsKeySelfLink(): void;
    get kmsKeySelfLinkInput(): string | undefined;
    private _kmsKeyServiceAccount?;
    get kmsKeyServiceAccount(): string;
    set kmsKeyServiceAccount(value: string);
    resetKmsKeyServiceAccount(): void;
    get kmsKeyServiceAccountInput(): string | undefined;
    private _rawKey?;
    get rawKey(): string;
    set rawKey(value: string);
    resetRawKey(): void;
    get rawKeyInput(): string | undefined;
    private _rsaEncryptedKey?;
    get rsaEncryptedKey(): string;
    set rsaEncryptedKey(value: string);
    resetRsaEncryptedKey(): void;
    get rsaEncryptedKeyInput(): string | undefined;
}
export interface ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceSnapshotEncryptionKey {
    /**
    * The self link of the encryption key that is stored in Google Cloud KMS. Only one of kms_key_self_link, rsa_encrypted_key and raw_key may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#kms_key_self_link ComputeRegionInstanceGroupManager#kms_key_self_link}
    */
    readonly kmsKeySelfLink?: string;
    /**
    * The service account being used for the encryption request for the given KMS key. If absent, the Compute Engine default service account is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#kms_key_service_account ComputeRegionInstanceGroupManager#kms_key_service_account}
    */
    readonly kmsKeyServiceAccount?: string;
    /**
    * Specifies a 256-bit customer-supplied encryption key, encoded in RFC 4648 base64 to either encrypt or decrypt this resource. Only one of kms_key_self_link, rsa_encrypted_key and raw_key may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#raw_key ComputeRegionInstanceGroupManager#raw_key}
    */
    readonly rawKey?: string;
    /**
    * Specifies an RFC 4648 base64 encoded, RSA-wrapped 2048-bit customer-supplied encryption key to either encrypt or decrypt this resource. Only one of kms_key_self_link, rsa_encrypted_key and raw_key may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#rsa_encrypted_key ComputeRegionInstanceGroupManager#rsa_encrypted_key}
    */
    readonly rsaEncryptedKey?: string;
}
export declare function computeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceSnapshotEncryptionKeyToTerraform(struct?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceSnapshotEncryptionKeyOutputReference | ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceSnapshotEncryptionKey): any;
export declare function computeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceSnapshotEncryptionKeyToHclTerraform(struct?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceSnapshotEncryptionKeyOutputReference | ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceSnapshotEncryptionKey): any;
export declare class ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceSnapshotEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceSnapshotEncryptionKey | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceSnapshotEncryptionKey | undefined);
    private _kmsKeySelfLink?;
    get kmsKeySelfLink(): string;
    set kmsKeySelfLink(value: string);
    resetKmsKeySelfLink(): void;
    get kmsKeySelfLinkInput(): string | undefined;
    private _kmsKeyServiceAccount?;
    get kmsKeyServiceAccount(): string;
    set kmsKeyServiceAccount(value: string);
    resetKmsKeyServiceAccount(): void;
    get kmsKeyServiceAccountInput(): string | undefined;
    private _rawKey?;
    get rawKey(): string;
    set rawKey(value: string);
    resetRawKey(): void;
    get rawKeyInput(): string | undefined;
    private _rsaEncryptedKey?;
    get rsaEncryptedKey(): string;
    set rsaEncryptedKey(value: string);
    resetRsaEncryptedKey(): void;
    get rsaEncryptedKeyInput(): string | undefined;
}
export interface ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisks {
    /**
    * The architecture of the image. Allowed values are ARM64 or X86_64.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#architecture ComputeRegionInstanceGroupManager#architecture}
    */
    readonly architecture?: string;
    /**
    * Whether or not the disk should be auto-deleted. This defaults to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#auto_delete ComputeRegionInstanceGroupManager#auto_delete}
    */
    readonly autoDelete?: boolean | cdktn.IResolvable;
    /**
    * Indicates that this is a boot disk. This defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#boot ComputeRegionInstanceGroupManager#boot}
    */
    readonly boot?: boolean | cdktn.IResolvable;
    /**
    * A unique device name that is reflected into the /dev/ tree of a Linux operating system running within the instance. If not specified, the server chooses a default device name to apply to this disk.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#device_name ComputeRegionInstanceGroupManager#device_name}
    */
    readonly deviceName?: string;
    /**
    * Name of the disk. When not provided, this defaults to the name of the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#disk_name ComputeRegionInstanceGroupManager#disk_name}
    */
    readonly diskName?: string;
    /**
    * The size of the image in gigabytes. If not specified, it will inherit the size of its base image. For SCRATCH disks, the size must be one of 375 or 3000 GB, with a default of 375 GB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#disk_size_gb ComputeRegionInstanceGroupManager#disk_size_gb}
    */
    readonly diskSizeGb?: number;
    /**
    * The Google Compute Engine disk type. Such as "pd-ssd", "local-ssd", "pd-balanced" or "pd-standard".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#disk_type ComputeRegionInstanceGroupManager#disk_type}
    */
    readonly diskType?: string;
    /**
    * A list of features to enable on the guest operating system. Applicable only for bootable images.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#guest_os_features ComputeRegionInstanceGroupManager#guest_os_features}
    */
    readonly guestOsFeatures?: string[];
    /**
    * Specifies the disk interface to use for attaching this disk.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#interface ComputeRegionInstanceGroupManager#interface}
    */
    readonly interface?: string;
    /**
    * The mode in which to attach this disk, either READ_WRITE or READ_ONLY. If you are attaching or creating a boot disk, this must read-write mode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#mode ComputeRegionInstanceGroupManager#mode}
    */
    readonly mode?: string;
    /**
    * Indicates how many IOPS to provision for the disk. This sets the number of I/O operations per second that the disk can handle. For more details, see the [Extreme persistent disk documentation](https://cloud.google.com/compute/docs/disks/extreme-persistent-disk) or the [Hyperdisk documentation](https://cloud.google.com/compute/docs/disks/hyperdisks) depending on the selected disk_type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#provisioned_iops ComputeRegionInstanceGroupManager#provisioned_iops}
    */
    readonly provisionedIops?: number;
    /**
    * Indicates how much throughput to provision for the disk, in MB/s. This sets the amount of data that can be read or written from the disk per second. Values must greater than or equal to 1. For more details, see the [Hyperdisk documentation](https://cloud.google.com/compute/docs/disks/hyperdisks).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#provisioned_throughput ComputeRegionInstanceGroupManager#provisioned_throughput}
    */
    readonly provisionedThroughput?: number;
    /**
    * A list (short name or id) of resource policies to attach to this disk. Currently a max of 1 resource policy is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#resource_policies ComputeRegionInstanceGroupManager#resource_policies}
    */
    readonly resourcePolicies?: string[];
    /**
    * The name (not self_link) of the disk (such as those managed by google_compute_disk) to attach. ~> Note: Either source or source_image is required when creating a new instance except for when creating a local SSD.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#source ComputeRegionInstanceGroupManager#source}
    */
    readonly source?: string;
    /**
    * The image from which to initialize this disk. This can be one of: the image's self_link, projects/{project}/global/images/{image}, projects/{project}/global/images/family/{family}, global/images/{image}, global/images/family/{family}, family/{family}, {project}/{family}, {project}/{image}, {family}, or {image}. ~> Note: Either source or source_image is required when creating a new instance except for when creating a local SSD.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#source_image ComputeRegionInstanceGroupManager#source_image}
    */
    readonly sourceImage?: string;
    /**
    * The source snapshot to create this disk. When creating a new instance, one of initializeParams.sourceSnapshot, initializeParams.sourceImage, or disks.source is required except for local SSD.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#source_snapshot ComputeRegionInstanceGroupManager#source_snapshot}
    */
    readonly sourceSnapshot?: string;
    /**
    * The type of Google Compute Engine disk, can be either "SCRATCH" or "PERSISTENT".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#type ComputeRegionInstanceGroupManager#type}
    */
    readonly type?: string;
    /**
    * disk_encryption_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#disk_encryption_key ComputeRegionInstanceGroupManager#disk_encryption_key}
    */
    readonly diskEncryptionKey?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksDiskEncryptionKey;
    /**
    * labels block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#labels ComputeRegionInstanceGroupManager#labels}
    */
    readonly labels?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksLabels[] | cdktn.IResolvable;
    /**
    * resource_manager_tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#resource_manager_tags ComputeRegionInstanceGroupManager#resource_manager_tags}
    */
    readonly resourceManagerTags?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksResourceManagerTags[] | cdktn.IResolvable;
    /**
    * source_image_encryption_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#source_image_encryption_key ComputeRegionInstanceGroupManager#source_image_encryption_key}
    */
    readonly sourceImageEncryptionKey?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceImageEncryptionKey;
    /**
    * source_snapshot_encryption_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#source_snapshot_encryption_key ComputeRegionInstanceGroupManager#source_snapshot_encryption_key}
    */
    readonly sourceSnapshotEncryptionKey?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceSnapshotEncryptionKey;
}
export declare function computeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksToTerraform(struct?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisks | cdktn.IResolvable): any;
export declare function computeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksToHclTerraform(struct?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisks | cdktn.IResolvable): any;
export declare class ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisks | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisks | cdktn.IResolvable | undefined);
    private _architecture?;
    get architecture(): string;
    set architecture(value: string);
    resetArchitecture(): void;
    get architectureInput(): string | undefined;
    private _autoDelete?;
    get autoDelete(): boolean | cdktn.IResolvable;
    set autoDelete(value: boolean | cdktn.IResolvable);
    resetAutoDelete(): void;
    get autoDeleteInput(): boolean | cdktn.IResolvable | undefined;
    private _boot?;
    get boot(): boolean | cdktn.IResolvable;
    set boot(value: boolean | cdktn.IResolvable);
    resetBoot(): void;
    get bootInput(): boolean | cdktn.IResolvable | undefined;
    private _deviceName?;
    get deviceName(): string;
    set deviceName(value: string);
    resetDeviceName(): void;
    get deviceNameInput(): string | undefined;
    private _diskName?;
    get diskName(): string;
    set diskName(value: string);
    resetDiskName(): void;
    get diskNameInput(): string | undefined;
    private _diskSizeGb?;
    get diskSizeGb(): number;
    set diskSizeGb(value: number);
    resetDiskSizeGb(): void;
    get diskSizeGbInput(): number | undefined;
    private _diskType?;
    get diskType(): string;
    set diskType(value: string);
    resetDiskType(): void;
    get diskTypeInput(): string | undefined;
    private _guestOsFeatures?;
    get guestOsFeatures(): string[];
    set guestOsFeatures(value: string[]);
    resetGuestOsFeatures(): void;
    get guestOsFeaturesInput(): string[] | undefined;
    private _interface?;
    get interface(): string;
    set interface(value: string);
    resetInterface(): void;
    get interfaceInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _provisionedIops?;
    get provisionedIops(): number;
    set provisionedIops(value: number);
    resetProvisionedIops(): void;
    get provisionedIopsInput(): number | undefined;
    private _provisionedThroughput?;
    get provisionedThroughput(): number;
    set provisionedThroughput(value: number);
    resetProvisionedThroughput(): void;
    get provisionedThroughputInput(): number | undefined;
    private _resourcePolicies?;
    get resourcePolicies(): string[];
    set resourcePolicies(value: string[]);
    resetResourcePolicies(): void;
    get resourcePoliciesInput(): string[] | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _sourceImage?;
    get sourceImage(): string;
    set sourceImage(value: string);
    resetSourceImage(): void;
    get sourceImageInput(): string | undefined;
    private _sourceSnapshot?;
    get sourceSnapshot(): string;
    set sourceSnapshot(value: string);
    resetSourceSnapshot(): void;
    get sourceSnapshotInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _diskEncryptionKey;
    get diskEncryptionKey(): ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksDiskEncryptionKeyOutputReference;
    putDiskEncryptionKey(value: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksDiskEncryptionKey): void;
    resetDiskEncryptionKey(): void;
    get diskEncryptionKeyInput(): ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksDiskEncryptionKey | undefined;
    private _labels;
    get labels(): ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksLabelsList;
    putLabels(value: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksLabels[] | cdktn.IResolvable): void;
    resetLabels(): void;
    get labelsInput(): cdktn.IResolvable | ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksLabels[] | undefined;
    private _resourceManagerTags;
    get resourceManagerTags(): ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksResourceManagerTagsList;
    putResourceManagerTags(value: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksResourceManagerTags[] | cdktn.IResolvable): void;
    resetResourceManagerTags(): void;
    get resourceManagerTagsInput(): cdktn.IResolvable | ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksResourceManagerTags[] | undefined;
    private _sourceImageEncryptionKey;
    get sourceImageEncryptionKey(): ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceImageEncryptionKeyOutputReference;
    putSourceImageEncryptionKey(value: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceImageEncryptionKey): void;
    resetSourceImageEncryptionKey(): void;
    get sourceImageEncryptionKeyInput(): ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceImageEncryptionKey | undefined;
    private _sourceSnapshotEncryptionKey;
    get sourceSnapshotEncryptionKey(): ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceSnapshotEncryptionKeyOutputReference;
    putSourceSnapshotEncryptionKey(value: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceSnapshotEncryptionKey): void;
    resetSourceSnapshotEncryptionKey(): void;
    get sourceSnapshotEncryptionKeyInput(): ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceSnapshotEncryptionKey | undefined;
}
export declare class ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksList extends cdktn.ComplexList {
    internalValue?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisks[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksOutputReference;
}
export interface ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelections {
    /**
    * Full machine-type names, e.g. "n1-standard-16"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#machine_types ComputeRegionInstanceGroupManager#machine_types}
    */
    readonly machineTypes: string[];
    /**
    * Name of the minimum CPU platform to be used by this instance selection. e.g. 'Intel Ice Lake'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#min_cpu_platform ComputeRegionInstanceGroupManager#min_cpu_platform}
    */
    readonly minCpuPlatform?: string;
    /**
    * Instance selection name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#name ComputeRegionInstanceGroupManager#name}
    */
    readonly name: string;
    /**
    * Preference of this instance selection. Lower number means higher preference. MIG will first try to create a VM based on the machine-type with lowest rank and fallback to next rank based on availability. Machine types and instance selections with the same rank have the same preference.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#rank ComputeRegionInstanceGroupManager#rank}
    */
    readonly rank?: number;
    /**
    * disks block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#disks ComputeRegionInstanceGroupManager#disks}
    */
    readonly disks?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisks[] | cdktn.IResolvable;
}
export declare function computeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsToTerraform(struct?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelections | cdktn.IResolvable): any;
export declare function computeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsToHclTerraform(struct?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelections | cdktn.IResolvable): any;
export declare class ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelections | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelections | cdktn.IResolvable | undefined);
    private _machineTypes?;
    get machineTypes(): string[];
    set machineTypes(value: string[]);
    get machineTypesInput(): string[] | undefined;
    private _minCpuPlatform?;
    get minCpuPlatform(): string;
    set minCpuPlatform(value: string);
    resetMinCpuPlatform(): void;
    get minCpuPlatformInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _rank?;
    get rank(): number;
    set rank(value: number);
    resetRank(): void;
    get rankInput(): number | undefined;
    private _disks;
    get disks(): ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksList;
    putDisks(value: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisks[] | cdktn.IResolvable): void;
    resetDisks(): void;
    get disksInput(): cdktn.IResolvable | ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisks[] | undefined;
}
export declare class ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsList extends cdktn.ComplexList {
    internalValue?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelections[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsOutputReference;
}
export interface ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicy {
    /**
    * instance_selections block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#instance_selections ComputeRegionInstanceGroupManager#instance_selections}
    */
    readonly instanceSelections?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelections[] | cdktn.IResolvable;
}
export declare function computeRegionInstanceGroupManagerInstanceFlexibilityPolicyToTerraform(struct?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyOutputReference | ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicy): any;
export declare function computeRegionInstanceGroupManagerInstanceFlexibilityPolicyToHclTerraform(struct?: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyOutputReference | ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicy): any;
export declare class ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicy | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicy | undefined);
    private _instanceSelections;
    get instanceSelections(): ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsList;
    putInstanceSelections(value: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelections[] | cdktn.IResolvable): void;
    resetInstanceSelections(): void;
    get instanceSelectionsInput(): cdktn.IResolvable | ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelections[] | undefined;
}
export interface ComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOnRepair {
    /**
    * Specifies whether the MIG can change a VM's zone during a repair. If "YES", MIG can select a different zone for the VM during a repair. Else if "NO", MIG cannot change a VM's zone during a repair. The default value of allow_changing_zone is "NO".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#allow_changing_zone ComputeRegionInstanceGroupManager#allow_changing_zone}
    */
    readonly allowChangingZone?: string;
}
export declare function computeRegionInstanceGroupManagerInstanceLifecyclePolicyOnRepairToTerraform(struct?: ComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOnRepairOutputReference | ComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOnRepair): any;
export declare function computeRegionInstanceGroupManagerInstanceLifecyclePolicyOnRepairToHclTerraform(struct?: ComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOnRepairOutputReference | ComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOnRepair): any;
export declare class ComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOnRepairOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOnRepair | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOnRepair | undefined);
    private _allowChangingZone?;
    get allowChangingZone(): string;
    set allowChangingZone(value: string);
    resetAllowChangingZone(): void;
    get allowChangingZoneInput(): string | undefined;
}
export interface ComputeRegionInstanceGroupManagerInstanceLifecyclePolicy {
    /**
    * Specifies the action that a MIG performs on a failed VM. If the value of the "on_failed_health_check" field is DEFAULT_ACTION, then the same action also applies to the VMs on which your application fails a health check. Valid values are: REPAIR, DO_NOTHING. If REPAIR (default), then MIG automatically repairs a failed VM by recreating it. For more information, see about repairing VMs in a MIG. If DO_NOTHING, then MIG does not repair a failed VM.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#default_action_on_failure ComputeRegionInstanceGroupManager#default_action_on_failure}
    */
    readonly defaultActionOnFailure?: string;
    /**
    * Specifies whether to apply the group's latest configuration when repairing a VM. Valid options are: YES, NO. If YES and you updated the group's instance template or per-instance configurations after the VM was created, then these changes are applied when VM is repaired. If NO (default), then updates are applied in accordance with the group's update policy type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#force_update_on_repair ComputeRegionInstanceGroupManager#force_update_on_repair}
    */
    readonly forceUpdateOnRepair?: string;
    /**
    * Specifies the action that a MIG performs on an unhealthy VM. A VM is marked as unhealthy when the application running on that VM fails a health check. Valid values are: DEFAULT_ACTION, DO_NOTHING, REPAIR. If DEFAULT_ACTION (default), then MIG uses the same action configured for the  "default_action_on_failure" field. If DO_NOTHING, then MIG does not repair unhealthy VM. If REPAIR, then MIG automatically repairs an unhealthy VM by recreating it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#on_failed_health_check ComputeRegionInstanceGroupManager#on_failed_health_check}
    */
    readonly onFailedHealthCheck?: string;
    /**
    * on_repair block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#on_repair ComputeRegionInstanceGroupManager#on_repair}
    */
    readonly onRepair?: ComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOnRepair;
}
export declare function computeRegionInstanceGroupManagerInstanceLifecyclePolicyToTerraform(struct?: ComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOutputReference | ComputeRegionInstanceGroupManagerInstanceLifecyclePolicy): any;
export declare function computeRegionInstanceGroupManagerInstanceLifecyclePolicyToHclTerraform(struct?: ComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOutputReference | ComputeRegionInstanceGroupManagerInstanceLifecyclePolicy): any;
export declare class ComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceGroupManagerInstanceLifecyclePolicy | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerInstanceLifecyclePolicy | undefined);
    private _defaultActionOnFailure?;
    get defaultActionOnFailure(): string;
    set defaultActionOnFailure(value: string);
    resetDefaultActionOnFailure(): void;
    get defaultActionOnFailureInput(): string | undefined;
    private _forceUpdateOnRepair?;
    get forceUpdateOnRepair(): string;
    set forceUpdateOnRepair(value: string);
    resetForceUpdateOnRepair(): void;
    get forceUpdateOnRepairInput(): string | undefined;
    private _onFailedHealthCheck?;
    get onFailedHealthCheck(): string;
    set onFailedHealthCheck(value: string);
    resetOnFailedHealthCheck(): void;
    get onFailedHealthCheckInput(): string | undefined;
    private _onRepair;
    get onRepair(): ComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOnRepairOutputReference;
    putOnRepair(value: ComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOnRepair): void;
    resetOnRepair(): void;
    get onRepairInput(): ComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOnRepair | undefined;
}
export interface ComputeRegionInstanceGroupManagerNamedPort {
    /**
    * The name of the port.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#name ComputeRegionInstanceGroupManager#name}
    */
    readonly name: string;
    /**
    * The port number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#port ComputeRegionInstanceGroupManager#port}
    */
    readonly port: number;
}
export declare function computeRegionInstanceGroupManagerNamedPortToTerraform(struct?: ComputeRegionInstanceGroupManagerNamedPort | cdktn.IResolvable): any;
export declare function computeRegionInstanceGroupManagerNamedPortToHclTerraform(struct?: ComputeRegionInstanceGroupManagerNamedPort | cdktn.IResolvable): any;
export declare class ComputeRegionInstanceGroupManagerNamedPortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionInstanceGroupManagerNamedPort | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerNamedPort | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
}
export declare class ComputeRegionInstanceGroupManagerNamedPortList extends cdktn.ComplexList {
    internalValue?: ComputeRegionInstanceGroupManagerNamedPort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionInstanceGroupManagerNamedPortOutputReference;
}
export interface ComputeRegionInstanceGroupManagerResourcePolicies {
    /**
    * The URL of the workload policy that is specified for this managed instance group. It can be a full or partial URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#workload_policy ComputeRegionInstanceGroupManager#workload_policy}
    */
    readonly workloadPolicy?: string;
}
export declare function computeRegionInstanceGroupManagerResourcePoliciesToTerraform(struct?: ComputeRegionInstanceGroupManagerResourcePoliciesOutputReference | ComputeRegionInstanceGroupManagerResourcePolicies): any;
export declare function computeRegionInstanceGroupManagerResourcePoliciesToHclTerraform(struct?: ComputeRegionInstanceGroupManagerResourcePoliciesOutputReference | ComputeRegionInstanceGroupManagerResourcePolicies): any;
export declare class ComputeRegionInstanceGroupManagerResourcePoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceGroupManagerResourcePolicies | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerResourcePolicies | undefined);
    private _workloadPolicy?;
    get workloadPolicy(): string;
    set workloadPolicy(value: string);
    resetWorkloadPolicy(): void;
    get workloadPolicyInput(): string | undefined;
}
export interface ComputeRegionInstanceGroupManagerStandbyPolicy {
    /**
    * Specifies the number of seconds that the MIG should wait to suspend or stop a VM after that VM was created. The initial delay gives the initialization script the time to prepare your VM for a quick scale out. The value of initial delay must be between 0 and 3600 seconds. The default value is 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#initial_delay_sec ComputeRegionInstanceGroupManager#initial_delay_sec}
    */
    readonly initialDelaySec?: number;
    /**
    * Defines how a MIG resumes or starts VMs from a standby pool when the group scales out. The default mode is "MANUAL".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#mode ComputeRegionInstanceGroupManager#mode}
    */
    readonly mode?: string;
}
export declare function computeRegionInstanceGroupManagerStandbyPolicyToTerraform(struct?: ComputeRegionInstanceGroupManagerStandbyPolicyOutputReference | ComputeRegionInstanceGroupManagerStandbyPolicy): any;
export declare function computeRegionInstanceGroupManagerStandbyPolicyToHclTerraform(struct?: ComputeRegionInstanceGroupManagerStandbyPolicyOutputReference | ComputeRegionInstanceGroupManagerStandbyPolicy): any;
export declare class ComputeRegionInstanceGroupManagerStandbyPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceGroupManagerStandbyPolicy | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerStandbyPolicy | undefined);
    private _initialDelaySec?;
    get initialDelaySec(): number;
    set initialDelaySec(value: number);
    resetInitialDelaySec(): void;
    get initialDelaySecInput(): number | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
}
export interface ComputeRegionInstanceGroupManagerStatefulDisk {
    /**
    * A value that prescribes what should happen to the stateful disk when the VM instance is deleted. The available options are NEVER and ON_PERMANENT_INSTANCE_DELETION. NEVER - detach the disk when the VM is deleted, but do not delete the disk. ON_PERMANENT_INSTANCE_DELETION will delete the stateful disk when the VM is permanently deleted from the instance group. The default is NEVER.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#delete_rule ComputeRegionInstanceGroupManager#delete_rule}
    */
    readonly deleteRule?: string;
    /**
    * The device name of the disk to be attached.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#device_name ComputeRegionInstanceGroupManager#device_name}
    */
    readonly deviceName: string;
}
export declare function computeRegionInstanceGroupManagerStatefulDiskToTerraform(struct?: ComputeRegionInstanceGroupManagerStatefulDisk | cdktn.IResolvable): any;
export declare function computeRegionInstanceGroupManagerStatefulDiskToHclTerraform(struct?: ComputeRegionInstanceGroupManagerStatefulDisk | cdktn.IResolvable): any;
export declare class ComputeRegionInstanceGroupManagerStatefulDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionInstanceGroupManagerStatefulDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerStatefulDisk | cdktn.IResolvable | undefined);
    private _deleteRule?;
    get deleteRule(): string;
    set deleteRule(value: string);
    resetDeleteRule(): void;
    get deleteRuleInput(): string | undefined;
    private _deviceName?;
    get deviceName(): string;
    set deviceName(value: string);
    get deviceNameInput(): string | undefined;
}
export declare class ComputeRegionInstanceGroupManagerStatefulDiskList extends cdktn.ComplexList {
    internalValue?: ComputeRegionInstanceGroupManagerStatefulDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionInstanceGroupManagerStatefulDiskOutputReference;
}
export interface ComputeRegionInstanceGroupManagerStatefulExternalIp {
    /**
    * A value that prescribes what should happen to an associated static Address resource when a VM instance is permanently deleted. The available options are NEVER and ON_PERMANENT_INSTANCE_DELETION. NEVER - detach the IP when the VM is deleted, but do not delete the address resource. ON_PERMANENT_INSTANCE_DELETION will delete the stateful address when the VM is permanently deleted from the instance group. The default is NEVER.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#delete_rule ComputeRegionInstanceGroupManager#delete_rule}
    */
    readonly deleteRule?: string;
    /**
    * The network interface name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#interface_name ComputeRegionInstanceGroupManager#interface_name}
    */
    readonly interfaceName?: string;
}
export declare function computeRegionInstanceGroupManagerStatefulExternalIpToTerraform(struct?: ComputeRegionInstanceGroupManagerStatefulExternalIp | cdktn.IResolvable): any;
export declare function computeRegionInstanceGroupManagerStatefulExternalIpToHclTerraform(struct?: ComputeRegionInstanceGroupManagerStatefulExternalIp | cdktn.IResolvable): any;
export declare class ComputeRegionInstanceGroupManagerStatefulExternalIpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionInstanceGroupManagerStatefulExternalIp | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerStatefulExternalIp | cdktn.IResolvable | undefined);
    private _deleteRule?;
    get deleteRule(): string;
    set deleteRule(value: string);
    resetDeleteRule(): void;
    get deleteRuleInput(): string | undefined;
    private _interfaceName?;
    get interfaceName(): string;
    set interfaceName(value: string);
    resetInterfaceName(): void;
    get interfaceNameInput(): string | undefined;
}
export declare class ComputeRegionInstanceGroupManagerStatefulExternalIpList extends cdktn.ComplexList {
    internalValue?: ComputeRegionInstanceGroupManagerStatefulExternalIp[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionInstanceGroupManagerStatefulExternalIpOutputReference;
}
export interface ComputeRegionInstanceGroupManagerStatefulInternalIp {
    /**
    * A value that prescribes what should happen to an associated static Address resource when a VM instance is permanently deleted. The available options are NEVER and ON_PERMANENT_INSTANCE_DELETION. NEVER - detach the IP when the VM is deleted, but do not delete the address resource. ON_PERMANENT_INSTANCE_DELETION will delete the stateful address when the VM is permanently deleted from the instance group. The default is NEVER.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#delete_rule ComputeRegionInstanceGroupManager#delete_rule}
    */
    readonly deleteRule?: string;
    /**
    * The network interface name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#interface_name ComputeRegionInstanceGroupManager#interface_name}
    */
    readonly interfaceName?: string;
}
export declare function computeRegionInstanceGroupManagerStatefulInternalIpToTerraform(struct?: ComputeRegionInstanceGroupManagerStatefulInternalIp | cdktn.IResolvable): any;
export declare function computeRegionInstanceGroupManagerStatefulInternalIpToHclTerraform(struct?: ComputeRegionInstanceGroupManagerStatefulInternalIp | cdktn.IResolvable): any;
export declare class ComputeRegionInstanceGroupManagerStatefulInternalIpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionInstanceGroupManagerStatefulInternalIp | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerStatefulInternalIp | cdktn.IResolvable | undefined);
    private _deleteRule?;
    get deleteRule(): string;
    set deleteRule(value: string);
    resetDeleteRule(): void;
    get deleteRuleInput(): string | undefined;
    private _interfaceName?;
    get interfaceName(): string;
    set interfaceName(value: string);
    resetInterfaceName(): void;
    get interfaceNameInput(): string | undefined;
}
export declare class ComputeRegionInstanceGroupManagerStatefulInternalIpList extends cdktn.ComplexList {
    internalValue?: ComputeRegionInstanceGroupManagerStatefulInternalIp[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionInstanceGroupManagerStatefulInternalIpOutputReference;
}
export interface ComputeRegionInstanceGroupManagerTargetSizePolicy {
    /**
    * The mode of target size policy based on which the MIG creates its VMs individually or all at once.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#mode ComputeRegionInstanceGroupManager#mode}
    */
    readonly mode: string;
}
export declare function computeRegionInstanceGroupManagerTargetSizePolicyToTerraform(struct?: ComputeRegionInstanceGroupManagerTargetSizePolicy | cdktn.IResolvable): any;
export declare function computeRegionInstanceGroupManagerTargetSizePolicyToHclTerraform(struct?: ComputeRegionInstanceGroupManagerTargetSizePolicy | cdktn.IResolvable): any;
export declare class ComputeRegionInstanceGroupManagerTargetSizePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionInstanceGroupManagerTargetSizePolicy | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerTargetSizePolicy | cdktn.IResolvable | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
}
export declare class ComputeRegionInstanceGroupManagerTargetSizePolicyList extends cdktn.ComplexList {
    internalValue?: ComputeRegionInstanceGroupManagerTargetSizePolicy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionInstanceGroupManagerTargetSizePolicyOutputReference;
}
export interface ComputeRegionInstanceGroupManagerTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#create ComputeRegionInstanceGroupManager#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#delete ComputeRegionInstanceGroupManager#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#update ComputeRegionInstanceGroupManager#update}
    */
    readonly update?: string;
}
export declare function computeRegionInstanceGroupManagerTimeoutsToTerraform(struct?: ComputeRegionInstanceGroupManagerTimeouts | cdktn.IResolvable): any;
export declare function computeRegionInstanceGroupManagerTimeoutsToHclTerraform(struct?: ComputeRegionInstanceGroupManagerTimeouts | cdktn.IResolvable): any;
export declare class ComputeRegionInstanceGroupManagerTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceGroupManagerTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface ComputeRegionInstanceGroupManagerUpdatePolicy {
    /**
    * The instance redistribution policy for regional managed instance groups. Valid values are: "PROACTIVE", "NONE". If PROACTIVE (default), the group attempts to maintain an even distribution of VM instances across zones in the region. If NONE, proactive redistribution is disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#instance_redistribution_type ComputeRegionInstanceGroupManager#instance_redistribution_type}
    */
    readonly instanceRedistributionType?: string;
    /**
    * Specifies a fixed number of VM instances. This must be a positive integer. Conflicts with max_surge_percent. Both cannot be 0
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#max_surge_fixed ComputeRegionInstanceGroupManager#max_surge_fixed}
    */
    readonly maxSurgeFixed?: number;
    /**
    * Specifies a percentage of instances between 0 to 100%, inclusive. For example, specify 80 for 80%. Conflicts with max_surge_fixed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#max_surge_percent ComputeRegionInstanceGroupManager#max_surge_percent}
    */
    readonly maxSurgePercent?: number;
    /**
    * Specifies a fixed number of VM instances. This must be a positive integer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#max_unavailable_fixed ComputeRegionInstanceGroupManager#max_unavailable_fixed}
    */
    readonly maxUnavailableFixed?: number;
    /**
    * Specifies a percentage of instances between 0 to 100%, inclusive. For example, specify 80 for 80%.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#max_unavailable_percent ComputeRegionInstanceGroupManager#max_unavailable_percent}
    */
    readonly maxUnavailablePercent?: number;
    /**
    * Minimal action to be taken on an instance. You can specify either NONE to forbid any actions, REFRESH to update without stopping instances, RESTART to restart existing instances or REPLACE to delete and create new instances from the target template. If you specify a REFRESH, the Updater will attempt to perform that action only. However, if the Updater determines that the minimal action you specify is not enough to perform the update, it might perform a more disruptive action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#minimal_action ComputeRegionInstanceGroupManager#minimal_action}
    */
    readonly minimalAction: string;
    /**
    * Most disruptive action that is allowed to be taken on an instance. You can specify either NONE to forbid any actions, REFRESH to allow actions that do not need instance restart, RESTART to allow actions that can be applied without instance replacing or REPLACE to allow all possible actions. If the Updater determines that the minimal update action needed is more disruptive than most disruptive allowed action you specify it will not perform the update at all.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#most_disruptive_allowed_action ComputeRegionInstanceGroupManager#most_disruptive_allowed_action}
    */
    readonly mostDisruptiveAllowedAction?: string;
    /**
    * The instance replacement method for regional managed instance groups. Valid values are: "RECREATE", "SUBSTITUTE". If SUBSTITUTE (default), the group replaces VM instances with new instances that have randomly generated names. If RECREATE, instance names are preserved.  You must also set max_unavailable_fixed or max_unavailable_percent to be greater than 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#replacement_method ComputeRegionInstanceGroupManager#replacement_method}
    */
    readonly replacementMethod?: string;
    /**
    * The type of update process. You can specify either PROACTIVE so that the instance group manager proactively executes actions in order to bring instances to their target versions or OPPORTUNISTIC so that no action is proactively executed but the update will be performed as part of other actions (for example, resizes or recreateInstances calls).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#type ComputeRegionInstanceGroupManager#type}
    */
    readonly type: string;
}
export declare function computeRegionInstanceGroupManagerUpdatePolicyToTerraform(struct?: ComputeRegionInstanceGroupManagerUpdatePolicyOutputReference | ComputeRegionInstanceGroupManagerUpdatePolicy): any;
export declare function computeRegionInstanceGroupManagerUpdatePolicyToHclTerraform(struct?: ComputeRegionInstanceGroupManagerUpdatePolicyOutputReference | ComputeRegionInstanceGroupManagerUpdatePolicy): any;
export declare class ComputeRegionInstanceGroupManagerUpdatePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceGroupManagerUpdatePolicy | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerUpdatePolicy | undefined);
    private _instanceRedistributionType?;
    get instanceRedistributionType(): string;
    set instanceRedistributionType(value: string);
    resetInstanceRedistributionType(): void;
    get instanceRedistributionTypeInput(): string | undefined;
    private _maxSurgeFixed?;
    get maxSurgeFixed(): number;
    set maxSurgeFixed(value: number);
    resetMaxSurgeFixed(): void;
    get maxSurgeFixedInput(): number | undefined;
    private _maxSurgePercent?;
    get maxSurgePercent(): number;
    set maxSurgePercent(value: number);
    resetMaxSurgePercent(): void;
    get maxSurgePercentInput(): number | undefined;
    private _maxUnavailableFixed?;
    get maxUnavailableFixed(): number;
    set maxUnavailableFixed(value: number);
    resetMaxUnavailableFixed(): void;
    get maxUnavailableFixedInput(): number | undefined;
    private _maxUnavailablePercent?;
    get maxUnavailablePercent(): number;
    set maxUnavailablePercent(value: number);
    resetMaxUnavailablePercent(): void;
    get maxUnavailablePercentInput(): number | undefined;
    private _minimalAction?;
    get minimalAction(): string;
    set minimalAction(value: string);
    get minimalActionInput(): string | undefined;
    private _mostDisruptiveAllowedAction?;
    get mostDisruptiveAllowedAction(): string;
    set mostDisruptiveAllowedAction(value: string);
    resetMostDisruptiveAllowedAction(): void;
    get mostDisruptiveAllowedActionInput(): string | undefined;
    private _replacementMethod?;
    get replacementMethod(): string;
    set replacementMethod(value: string);
    resetReplacementMethod(): void;
    get replacementMethodInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface ComputeRegionInstanceGroupManagerVersionTargetSize {
    /**
    * The number of instances which are managed for this version. Conflicts with percent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#fixed ComputeRegionInstanceGroupManager#fixed}
    */
    readonly fixed?: number;
    /**
    * The number of instances (calculated as percentage) which are managed for this version. Conflicts with fixed. Note that when using percent, rounding will be in favor of explicitly set target_size values; a managed instance group with 2 instances and 2 versions, one of which has a target_size.percent of 60 will create 2 instances of that version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#percent ComputeRegionInstanceGroupManager#percent}
    */
    readonly percent?: number;
}
export declare function computeRegionInstanceGroupManagerVersionTargetSizeToTerraform(struct?: ComputeRegionInstanceGroupManagerVersionTargetSizeOutputReference | ComputeRegionInstanceGroupManagerVersionTargetSize): any;
export declare function computeRegionInstanceGroupManagerVersionTargetSizeToHclTerraform(struct?: ComputeRegionInstanceGroupManagerVersionTargetSizeOutputReference | ComputeRegionInstanceGroupManagerVersionTargetSize): any;
export declare class ComputeRegionInstanceGroupManagerVersionTargetSizeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstanceGroupManagerVersionTargetSize | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerVersionTargetSize | undefined);
    private _fixed?;
    get fixed(): number;
    set fixed(value: number);
    resetFixed(): void;
    get fixedInput(): number | undefined;
    private _percent?;
    get percent(): number;
    set percent(value: number);
    resetPercent(): void;
    get percentInput(): number | undefined;
}
export interface ComputeRegionInstanceGroupManagerVersion {
    /**
    * The full URL to an instance template from which all new instances of this version will be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#instance_template ComputeRegionInstanceGroupManager#instance_template}
    */
    readonly instanceTemplate: string;
    /**
    * Version name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#name ComputeRegionInstanceGroupManager#name}
    */
    readonly name?: string;
    /**
    * target_size block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#target_size ComputeRegionInstanceGroupManager#target_size}
    */
    readonly targetSize?: ComputeRegionInstanceGroupManagerVersionTargetSize;
}
export declare function computeRegionInstanceGroupManagerVersionToTerraform(struct?: ComputeRegionInstanceGroupManagerVersion | cdktn.IResolvable): any;
export declare function computeRegionInstanceGroupManagerVersionToHclTerraform(struct?: ComputeRegionInstanceGroupManagerVersion | cdktn.IResolvable): any;
export declare class ComputeRegionInstanceGroupManagerVersionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionInstanceGroupManagerVersion | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionInstanceGroupManagerVersion | cdktn.IResolvable | undefined);
    private _instanceTemplate?;
    get instanceTemplate(): string;
    set instanceTemplate(value: string);
    get instanceTemplateInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _targetSize;
    get targetSize(): ComputeRegionInstanceGroupManagerVersionTargetSizeOutputReference;
    putTargetSize(value: ComputeRegionInstanceGroupManagerVersionTargetSize): void;
    resetTargetSize(): void;
    get targetSizeInput(): ComputeRegionInstanceGroupManagerVersionTargetSize | undefined;
}
export declare class ComputeRegionInstanceGroupManagerVersionList extends cdktn.ComplexList {
    internalValue?: ComputeRegionInstanceGroupManagerVersion[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionInstanceGroupManagerVersionOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager google_compute_region_instance_group_manager}
*/
export declare class ComputeRegionInstanceGroupManager extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_region_instance_group_manager";
    /**
    * Generates CDKTN code for importing a ComputeRegionInstanceGroupManager resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeRegionInstanceGroupManager to import
    * @param importFromId The id of the existing ComputeRegionInstanceGroupManager that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeRegionInstanceGroupManager to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instance_group_manager google_compute_region_instance_group_manager} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeRegionInstanceGroupManagerConfig
    */
    constructor(scope: Construct, id: string, config: ComputeRegionInstanceGroupManagerConfig);
    private _baseInstanceName?;
    get baseInstanceName(): string;
    set baseInstanceName(value: string);
    get baseInstanceNameInput(): string | undefined;
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _distributionPolicyTargetShape?;
    get distributionPolicyTargetShape(): string;
    set distributionPolicyTargetShape(value: string);
    resetDistributionPolicyTargetShape(): void;
    get distributionPolicyTargetShapeInput(): string | undefined;
    private _distributionPolicyZones?;
    get distributionPolicyZones(): string[];
    set distributionPolicyZones(value: string[]);
    resetDistributionPolicyZones(): void;
    get distributionPolicyZonesInput(): string[] | undefined;
    get fingerprint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get instanceGroup(): string;
    get instanceGroupManagerId(): number;
    private _listManagedInstancesResults?;
    get listManagedInstancesResults(): string;
    set listManagedInstancesResults(value: string);
    resetListManagedInstancesResults(): void;
    get listManagedInstancesResultsInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get selfLink(): string;
    private _status;
    get status(): ComputeRegionInstanceGroupManagerStatusList;
    private _targetPools?;
    get targetPools(): string[];
    set targetPools(value: string[]);
    resetTargetPools(): void;
    get targetPoolsInput(): string[] | undefined;
    private _targetSize?;
    get targetSize(): number;
    set targetSize(value: number);
    resetTargetSize(): void;
    get targetSizeInput(): number | undefined;
    private _targetStoppedSize?;
    get targetStoppedSize(): number;
    set targetStoppedSize(value: number);
    resetTargetStoppedSize(): void;
    get targetStoppedSizeInput(): number | undefined;
    private _targetSuspendedSize?;
    get targetSuspendedSize(): number;
    set targetSuspendedSize(value: number);
    resetTargetSuspendedSize(): void;
    get targetSuspendedSizeInput(): number | undefined;
    private _waitForInstances?;
    get waitForInstances(): boolean | cdktn.IResolvable;
    set waitForInstances(value: boolean | cdktn.IResolvable);
    resetWaitForInstances(): void;
    get waitForInstancesInput(): boolean | cdktn.IResolvable | undefined;
    private _waitForInstancesStatus?;
    get waitForInstancesStatus(): string;
    set waitForInstancesStatus(value: string);
    resetWaitForInstancesStatus(): void;
    get waitForInstancesStatusInput(): string | undefined;
    private _allInstancesConfig;
    get allInstancesConfig(): ComputeRegionInstanceGroupManagerAllInstancesConfigOutputReference;
    putAllInstancesConfig(value: ComputeRegionInstanceGroupManagerAllInstancesConfig): void;
    resetAllInstancesConfig(): void;
    get allInstancesConfigInput(): ComputeRegionInstanceGroupManagerAllInstancesConfig | undefined;
    private _autoHealingPolicies;
    get autoHealingPolicies(): ComputeRegionInstanceGroupManagerAutoHealingPoliciesOutputReference;
    putAutoHealingPolicies(value: ComputeRegionInstanceGroupManagerAutoHealingPolicies): void;
    resetAutoHealingPolicies(): void;
    get autoHealingPoliciesInput(): ComputeRegionInstanceGroupManagerAutoHealingPolicies | undefined;
    private _instanceFlexibilityPolicy;
    get instanceFlexibilityPolicy(): ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyOutputReference;
    putInstanceFlexibilityPolicy(value: ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicy): void;
    resetInstanceFlexibilityPolicy(): void;
    get instanceFlexibilityPolicyInput(): ComputeRegionInstanceGroupManagerInstanceFlexibilityPolicy | undefined;
    private _instanceLifecyclePolicy;
    get instanceLifecyclePolicy(): ComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOutputReference;
    putInstanceLifecyclePolicy(value: ComputeRegionInstanceGroupManagerInstanceLifecyclePolicy): void;
    resetInstanceLifecyclePolicy(): void;
    get instanceLifecyclePolicyInput(): ComputeRegionInstanceGroupManagerInstanceLifecyclePolicy | undefined;
    private _namedPort;
    get namedPort(): ComputeRegionInstanceGroupManagerNamedPortList;
    putNamedPort(value: ComputeRegionInstanceGroupManagerNamedPort[] | cdktn.IResolvable): void;
    resetNamedPort(): void;
    get namedPortInput(): cdktn.IResolvable | ComputeRegionInstanceGroupManagerNamedPort[] | undefined;
    private _resourcePolicies;
    get resourcePolicies(): ComputeRegionInstanceGroupManagerResourcePoliciesOutputReference;
    putResourcePolicies(value: ComputeRegionInstanceGroupManagerResourcePolicies): void;
    resetResourcePolicies(): void;
    get resourcePoliciesInput(): ComputeRegionInstanceGroupManagerResourcePolicies | undefined;
    private _standbyPolicy;
    get standbyPolicy(): ComputeRegionInstanceGroupManagerStandbyPolicyOutputReference;
    putStandbyPolicy(value: ComputeRegionInstanceGroupManagerStandbyPolicy): void;
    resetStandbyPolicy(): void;
    get standbyPolicyInput(): ComputeRegionInstanceGroupManagerStandbyPolicy | undefined;
    private _statefulDisk;
    get statefulDisk(): ComputeRegionInstanceGroupManagerStatefulDiskList;
    putStatefulDisk(value: ComputeRegionInstanceGroupManagerStatefulDisk[] | cdktn.IResolvable): void;
    resetStatefulDisk(): void;
    get statefulDiskInput(): cdktn.IResolvable | ComputeRegionInstanceGroupManagerStatefulDisk[] | undefined;
    private _statefulExternalIp;
    get statefulExternalIp(): ComputeRegionInstanceGroupManagerStatefulExternalIpList;
    putStatefulExternalIp(value: ComputeRegionInstanceGroupManagerStatefulExternalIp[] | cdktn.IResolvable): void;
    resetStatefulExternalIp(): void;
    get statefulExternalIpInput(): cdktn.IResolvable | ComputeRegionInstanceGroupManagerStatefulExternalIp[] | undefined;
    private _statefulInternalIp;
    get statefulInternalIp(): ComputeRegionInstanceGroupManagerStatefulInternalIpList;
    putStatefulInternalIp(value: ComputeRegionInstanceGroupManagerStatefulInternalIp[] | cdktn.IResolvable): void;
    resetStatefulInternalIp(): void;
    get statefulInternalIpInput(): cdktn.IResolvable | ComputeRegionInstanceGroupManagerStatefulInternalIp[] | undefined;
    private _targetSizePolicy;
    get targetSizePolicy(): ComputeRegionInstanceGroupManagerTargetSizePolicyList;
    putTargetSizePolicy(value: ComputeRegionInstanceGroupManagerTargetSizePolicy[] | cdktn.IResolvable): void;
    resetTargetSizePolicy(): void;
    get targetSizePolicyInput(): cdktn.IResolvable | ComputeRegionInstanceGroupManagerTargetSizePolicy[] | undefined;
    private _timeouts;
    get timeouts(): ComputeRegionInstanceGroupManagerTimeoutsOutputReference;
    putTimeouts(value: ComputeRegionInstanceGroupManagerTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeRegionInstanceGroupManagerTimeouts | undefined;
    private _updatePolicy;
    get updatePolicy(): ComputeRegionInstanceGroupManagerUpdatePolicyOutputReference;
    putUpdatePolicy(value: ComputeRegionInstanceGroupManagerUpdatePolicy): void;
    resetUpdatePolicy(): void;
    get updatePolicyInput(): ComputeRegionInstanceGroupManagerUpdatePolicy | undefined;
    private _version;
    get version(): ComputeRegionInstanceGroupManagerVersionList;
    putVersion(value: ComputeRegionInstanceGroupManagerVersion[] | cdktn.IResolvable): void;
    get versionInput(): cdktn.IResolvable | ComputeRegionInstanceGroupManagerVersion[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
