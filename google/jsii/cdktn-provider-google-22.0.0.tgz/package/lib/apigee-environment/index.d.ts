/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigeeEnvironmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Optional. API Proxy type supported by the environment. The type can be set when creating
    * the Environment and cannot be changed. Possible values: ["API_PROXY_TYPE_UNSPECIFIED", "PROGRAMMABLE", "CONFIGURABLE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment#api_proxy_type ApigeeEnvironment#api_proxy_type}
    */
    readonly apiProxyType?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment#deletion_policy ApigeeEnvironment#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Optional. Deployment type supported by the environment. The deployment type can be
    * set when creating the environment and cannot be changed. When you enable archive
    * deployment, you will be prevented from performing a subset of actions within the
    * environment, including:
    * Managing the deployment of API proxy or shared flow revisions;
    * Creating, updating, or deleting resource files;
    * Creating, updating, or deleting target servers. Possible values: ["DEPLOYMENT_TYPE_UNSPECIFIED", "PROXY", "ARCHIVE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment#deployment_type ApigeeEnvironment#deployment_type}
    */
    readonly deploymentType?: string;
    /**
    * Description of the environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment#description ApigeeEnvironment#description}
    */
    readonly description?: string;
    /**
    * Display name of the environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment#display_name ApigeeEnvironment#display_name}
    */
    readonly displayName?: string;
    /**
    * Optional. URI of the forward proxy to be applied to the runtime instances in this environment. Must be in the format of {scheme}://{hostname}:{port}. Note that the scheme must be one of "http" or "https", and the port must be supplied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment#forward_proxy_uri ApigeeEnvironment#forward_proxy_uri}
    */
    readonly forwardProxyUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment#id ApigeeEnvironment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The resource ID of the environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment#name ApigeeEnvironment#name}
    */
    readonly name: string;
    /**
    * The Apigee Organization associated with the Apigee environment,
    * in the format 'organizations/{{org_name}}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment#org_id ApigeeEnvironment#org_id}
    */
    readonly orgId: string;
    /**
    * Types that can be selected for an Environment. Each of the types are
    * limited by capability and capacity. Refer to Apigee's public documentation
    * to understand about each of these types in details.
    * An Apigee org can support heterogeneous Environments. Possible values: ["ENVIRONMENT_TYPE_UNSPECIFIED", "BASE", "INTERMEDIATE", "COMPREHENSIVE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment#type ApigeeEnvironment#type}
    */
    readonly type?: string;
    /**
    * client_ip_resolution_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment#client_ip_resolution_config ApigeeEnvironment#client_ip_resolution_config}
    */
    readonly clientIpResolutionConfig?: ApigeeEnvironmentClientIpResolutionConfig;
    /**
    * node_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment#node_config ApigeeEnvironment#node_config}
    */
    readonly nodeConfig?: ApigeeEnvironmentNodeConfig;
    /**
    * properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment#properties ApigeeEnvironment#properties}
    */
    readonly properties?: ApigeeEnvironmentProperties;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment#timeouts ApigeeEnvironment#timeouts}
    */
    readonly timeouts?: ApigeeEnvironmentTimeouts;
}
export interface ApigeeEnvironmentClientIpResolutionConfigHeaderIndexAlgorithm {
    /**
    * The index of the ip in the header. Positive indices 0, 1, 2, 3 chooses indices from the left (first ips). Negative indices -1, -2, -3 chooses indices from the right (last ips).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment#ip_header_index ApigeeEnvironment#ip_header_index}
    */
    readonly ipHeaderIndex: number;
    /**
    * The name of the header to extract the client ip from. We are currently only supporting the X-Forwarded-For header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment#ip_header_name ApigeeEnvironment#ip_header_name}
    */
    readonly ipHeaderName: string;
}
export declare function apigeeEnvironmentClientIpResolutionConfigHeaderIndexAlgorithmToTerraform(struct?: ApigeeEnvironmentClientIpResolutionConfigHeaderIndexAlgorithmOutputReference | ApigeeEnvironmentClientIpResolutionConfigHeaderIndexAlgorithm): any;
export declare function apigeeEnvironmentClientIpResolutionConfigHeaderIndexAlgorithmToHclTerraform(struct?: ApigeeEnvironmentClientIpResolutionConfigHeaderIndexAlgorithmOutputReference | ApigeeEnvironmentClientIpResolutionConfigHeaderIndexAlgorithm): any;
export declare class ApigeeEnvironmentClientIpResolutionConfigHeaderIndexAlgorithmOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeEnvironmentClientIpResolutionConfigHeaderIndexAlgorithm | undefined;
    set internalValue(value: ApigeeEnvironmentClientIpResolutionConfigHeaderIndexAlgorithm | undefined);
    private _ipHeaderIndex?;
    get ipHeaderIndex(): number;
    set ipHeaderIndex(value: number);
    get ipHeaderIndexInput(): number | undefined;
    private _ipHeaderName?;
    get ipHeaderName(): string;
    set ipHeaderName(value: string);
    get ipHeaderNameInput(): string | undefined;
}
export interface ApigeeEnvironmentClientIpResolutionConfig {
    /**
    * header_index_algorithm block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment#header_index_algorithm ApigeeEnvironment#header_index_algorithm}
    */
    readonly headerIndexAlgorithm?: ApigeeEnvironmentClientIpResolutionConfigHeaderIndexAlgorithm;
}
export declare function apigeeEnvironmentClientIpResolutionConfigToTerraform(struct?: ApigeeEnvironmentClientIpResolutionConfigOutputReference | ApigeeEnvironmentClientIpResolutionConfig): any;
export declare function apigeeEnvironmentClientIpResolutionConfigToHclTerraform(struct?: ApigeeEnvironmentClientIpResolutionConfigOutputReference | ApigeeEnvironmentClientIpResolutionConfig): any;
export declare class ApigeeEnvironmentClientIpResolutionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeEnvironmentClientIpResolutionConfig | undefined;
    set internalValue(value: ApigeeEnvironmentClientIpResolutionConfig | undefined);
    private _headerIndexAlgorithm;
    get headerIndexAlgorithm(): ApigeeEnvironmentClientIpResolutionConfigHeaderIndexAlgorithmOutputReference;
    putHeaderIndexAlgorithm(value: ApigeeEnvironmentClientIpResolutionConfigHeaderIndexAlgorithm): void;
    resetHeaderIndexAlgorithm(): void;
    get headerIndexAlgorithmInput(): ApigeeEnvironmentClientIpResolutionConfigHeaderIndexAlgorithm | undefined;
}
export interface ApigeeEnvironmentNodeConfig {
    /**
    * The maximum total number of gateway nodes that the is reserved for all instances that
    * has the specified environment. If not specified, the default is determined by the
    * recommended maximum number of nodes for that gateway.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment#max_node_count ApigeeEnvironment#max_node_count}
    */
    readonly maxNodeCount?: string;
    /**
    * The minimum total number of gateway nodes that the is reserved for all instances that
    * has the specified environment. If not specified, the default is determined by the
    * recommended minimum number of nodes for that gateway.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment#min_node_count ApigeeEnvironment#min_node_count}
    */
    readonly minNodeCount?: string;
}
export declare function apigeeEnvironmentNodeConfigToTerraform(struct?: ApigeeEnvironmentNodeConfigOutputReference | ApigeeEnvironmentNodeConfig): any;
export declare function apigeeEnvironmentNodeConfigToHclTerraform(struct?: ApigeeEnvironmentNodeConfigOutputReference | ApigeeEnvironmentNodeConfig): any;
export declare class ApigeeEnvironmentNodeConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeEnvironmentNodeConfig | undefined;
    set internalValue(value: ApigeeEnvironmentNodeConfig | undefined);
    get currentAggregateNodeCount(): string;
    private _maxNodeCount?;
    get maxNodeCount(): string;
    set maxNodeCount(value: string);
    resetMaxNodeCount(): void;
    get maxNodeCountInput(): string | undefined;
    private _minNodeCount?;
    get minNodeCount(): string;
    set minNodeCount(value: string);
    resetMinNodeCount(): void;
    get minNodeCountInput(): string | undefined;
}
export interface ApigeeEnvironmentPropertiesProperty {
    /**
    * The property key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment#name ApigeeEnvironment#name}
    */
    readonly name?: string;
    /**
    * The property value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment#value ApigeeEnvironment#value}
    */
    readonly value?: string;
}
export declare function apigeeEnvironmentPropertiesPropertyToTerraform(struct?: ApigeeEnvironmentPropertiesProperty | cdktn.IResolvable): any;
export declare function apigeeEnvironmentPropertiesPropertyToHclTerraform(struct?: ApigeeEnvironmentPropertiesProperty | cdktn.IResolvable): any;
export declare class ApigeeEnvironmentPropertiesPropertyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigeeEnvironmentPropertiesProperty | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeEnvironmentPropertiesProperty | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApigeeEnvironmentPropertiesPropertyList extends cdktn.ComplexList {
    internalValue?: ApigeeEnvironmentPropertiesProperty[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigeeEnvironmentPropertiesPropertyOutputReference;
}
export interface ApigeeEnvironmentProperties {
    /**
    * property block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment#property ApigeeEnvironment#property}
    */
    readonly property?: ApigeeEnvironmentPropertiesProperty[] | cdktn.IResolvable;
}
export declare function apigeeEnvironmentPropertiesToTerraform(struct?: ApigeeEnvironmentPropertiesOutputReference | ApigeeEnvironmentProperties): any;
export declare function apigeeEnvironmentPropertiesToHclTerraform(struct?: ApigeeEnvironmentPropertiesOutputReference | ApigeeEnvironmentProperties): any;
export declare class ApigeeEnvironmentPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeEnvironmentProperties | undefined;
    set internalValue(value: ApigeeEnvironmentProperties | undefined);
    private _property;
    get property(): ApigeeEnvironmentPropertiesPropertyList;
    putProperty(value: ApigeeEnvironmentPropertiesProperty[] | cdktn.IResolvable): void;
    resetProperty(): void;
    get propertyInput(): cdktn.IResolvable | ApigeeEnvironmentPropertiesProperty[] | undefined;
}
export interface ApigeeEnvironmentTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment#create ApigeeEnvironment#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment#delete ApigeeEnvironment#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment#update ApigeeEnvironment#update}
    */
    readonly update?: string;
}
export declare function apigeeEnvironmentTimeoutsToTerraform(struct?: ApigeeEnvironmentTimeouts | cdktn.IResolvable): any;
export declare function apigeeEnvironmentTimeoutsToHclTerraform(struct?: ApigeeEnvironmentTimeouts | cdktn.IResolvable): any;
export declare class ApigeeEnvironmentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeEnvironmentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeEnvironmentTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment google_apigee_environment}
*/
export declare class ApigeeEnvironment extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apigee_environment";
    /**
    * Generates CDKTN code for importing a ApigeeEnvironment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigeeEnvironment to import
    * @param importFromId The id of the existing ApigeeEnvironment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigeeEnvironment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apigee_environment google_apigee_environment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigeeEnvironmentConfig
    */
    constructor(scope: Construct, id: string, config: ApigeeEnvironmentConfig);
    private _apiProxyType?;
    get apiProxyType(): string;
    set apiProxyType(value: string);
    resetApiProxyType(): void;
    get apiProxyTypeInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _deploymentType?;
    get deploymentType(): string;
    set deploymentType(value: string);
    resetDeploymentType(): void;
    get deploymentTypeInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _forwardProxyUri?;
    get forwardProxyUri(): string;
    set forwardProxyUri(value: string);
    resetForwardProxyUri(): void;
    get forwardProxyUriInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _orgId?;
    get orgId(): string;
    set orgId(value: string);
    get orgIdInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _clientIpResolutionConfig;
    get clientIpResolutionConfig(): ApigeeEnvironmentClientIpResolutionConfigOutputReference;
    putClientIpResolutionConfig(value: ApigeeEnvironmentClientIpResolutionConfig): void;
    resetClientIpResolutionConfig(): void;
    get clientIpResolutionConfigInput(): ApigeeEnvironmentClientIpResolutionConfig | undefined;
    private _nodeConfig;
    get nodeConfig(): ApigeeEnvironmentNodeConfigOutputReference;
    putNodeConfig(value: ApigeeEnvironmentNodeConfig): void;
    resetNodeConfig(): void;
    get nodeConfigInput(): ApigeeEnvironmentNodeConfig | undefined;
    private _properties;
    get properties(): ApigeeEnvironmentPropertiesOutputReference;
    putProperties(value: ApigeeEnvironmentProperties): void;
    resetProperties(): void;
    get propertiesInput(): ApigeeEnvironmentProperties | undefined;
    private _timeouts;
    get timeouts(): ApigeeEnvironmentTimeoutsOutputReference;
    putTimeouts(value: ApigeeEnvironmentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApigeeEnvironmentTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
