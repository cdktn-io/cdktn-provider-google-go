/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeRegionSecurityPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#deletion_policy ComputeRegionSecurityPolicy#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource. Provide this property when you create the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#description ComputeRegionSecurityPolicy#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#id ComputeRegionSecurityPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the resource. Provided by the client when the resource is created. The name must be 1-63 characters long, and comply with RFC1035.
    * Specifically, the name must be 1-63 characters long and match the regular expression [a-z]([-a-z0-9]*[a-z0-9])? which means the first character must be a lowercase letter, and all following characters must be a dash, lowercase letter, or digit, except the last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#name ComputeRegionSecurityPolicy#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#project ComputeRegionSecurityPolicy#project}
    */
    readonly project?: string;
    /**
    * The Region in which the created Region Security Policy should reside.
    * If it is not provided, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#region ComputeRegionSecurityPolicy#region}
    */
    readonly region?: string;
    /**
    * The type indicates the intended use of the security policy.
    * - CLOUD_ARMOR: Cloud Armor backend security policies can be configured to filter incoming HTTP requests targeting backend services. They filter requests before they hit the origin servers.
    * - CLOUD_ARMOR_EDGE: Cloud Armor edge security policies can be configured to filter incoming HTTP requests targeting backend services (including Cloud CDN-enabled) as well as backend buckets (Cloud Storage). They filter requests before the request is served from Google's cache.
    * - CLOUD_ARMOR_NETWORK: Cloud Armor network policies can be configured to filter packets targeting network load balancing resources such as backend services, target pools, target instances, and instances with external IPs. They filter requests before the request is served from the application.
    * This field can be set only at resource creation time. Possible values: ["CLOUD_ARMOR", "CLOUD_ARMOR_EDGE", "CLOUD_ARMOR_NETWORK"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#type ComputeRegionSecurityPolicy#type}
    */
    readonly type?: string;
    /**
    * advanced_options_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#advanced_options_config ComputeRegionSecurityPolicy#advanced_options_config}
    */
    readonly advancedOptionsConfig?: ComputeRegionSecurityPolicyAdvancedOptionsConfig;
    /**
    * ddos_protection_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#ddos_protection_config ComputeRegionSecurityPolicy#ddos_protection_config}
    */
    readonly ddosProtectionConfig?: ComputeRegionSecurityPolicyDdosProtectionConfig;
    /**
    * rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#rules ComputeRegionSecurityPolicy#rules}
    */
    readonly rules?: ComputeRegionSecurityPolicyRules[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#timeouts ComputeRegionSecurityPolicy#timeouts}
    */
    readonly timeouts?: ComputeRegionSecurityPolicyTimeouts;
    /**
    * user_defined_fields block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#user_defined_fields ComputeRegionSecurityPolicy#user_defined_fields}
    */
    readonly userDefinedFields?: ComputeRegionSecurityPolicyUserDefinedFields[] | cdktn.IResolvable;
}
export interface ComputeRegionSecurityPolicyAdvancedOptionsConfigJsonCustomConfig {
    /**
    * A list of custom Content-Type header values to apply the JSON parsing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#content_types ComputeRegionSecurityPolicy#content_types}
    */
    readonly contentTypes: string[];
}
export declare function computeRegionSecurityPolicyAdvancedOptionsConfigJsonCustomConfigToTerraform(struct?: ComputeRegionSecurityPolicyAdvancedOptionsConfigJsonCustomConfigOutputReference | ComputeRegionSecurityPolicyAdvancedOptionsConfigJsonCustomConfig): any;
export declare function computeRegionSecurityPolicyAdvancedOptionsConfigJsonCustomConfigToHclTerraform(struct?: ComputeRegionSecurityPolicyAdvancedOptionsConfigJsonCustomConfigOutputReference | ComputeRegionSecurityPolicyAdvancedOptionsConfigJsonCustomConfig): any;
export declare class ComputeRegionSecurityPolicyAdvancedOptionsConfigJsonCustomConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionSecurityPolicyAdvancedOptionsConfigJsonCustomConfig | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyAdvancedOptionsConfigJsonCustomConfig | undefined);
    private _contentTypes?;
    get contentTypes(): string[];
    set contentTypes(value: string[]);
    get contentTypesInput(): string[] | undefined;
}
export interface ComputeRegionSecurityPolicyAdvancedOptionsConfig {
    /**
    * JSON body parsing. Supported values include: "DISABLED", "STANDARD", "STANDARD_WITH_GRAPHQL". Possible values: ["DISABLED", "STANDARD", "STANDARD_WITH_GRAPHQL"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#json_parsing ComputeRegionSecurityPolicy#json_parsing}
    */
    readonly jsonParsing?: string;
    /**
    * Logging level. Supported values include: "NORMAL", "VERBOSE". Possible values: ["NORMAL", "VERBOSE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#log_level ComputeRegionSecurityPolicy#log_level}
    */
    readonly logLevel?: string;
    /**
    * An optional list of case-insensitive request header names to use for resolving the callers client IP address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#user_ip_request_headers ComputeRegionSecurityPolicy#user_ip_request_headers}
    */
    readonly userIpRequestHeaders?: string[];
    /**
    * json_custom_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#json_custom_config ComputeRegionSecurityPolicy#json_custom_config}
    */
    readonly jsonCustomConfig?: ComputeRegionSecurityPolicyAdvancedOptionsConfigJsonCustomConfig;
}
export declare function computeRegionSecurityPolicyAdvancedOptionsConfigToTerraform(struct?: ComputeRegionSecurityPolicyAdvancedOptionsConfigOutputReference | ComputeRegionSecurityPolicyAdvancedOptionsConfig): any;
export declare function computeRegionSecurityPolicyAdvancedOptionsConfigToHclTerraform(struct?: ComputeRegionSecurityPolicyAdvancedOptionsConfigOutputReference | ComputeRegionSecurityPolicyAdvancedOptionsConfig): any;
export declare class ComputeRegionSecurityPolicyAdvancedOptionsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionSecurityPolicyAdvancedOptionsConfig | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyAdvancedOptionsConfig | undefined);
    private _jsonParsing?;
    get jsonParsing(): string;
    set jsonParsing(value: string);
    resetJsonParsing(): void;
    get jsonParsingInput(): string | undefined;
    private _logLevel?;
    get logLevel(): string;
    set logLevel(value: string);
    resetLogLevel(): void;
    get logLevelInput(): string | undefined;
    private _userIpRequestHeaders?;
    get userIpRequestHeaders(): string[];
    set userIpRequestHeaders(value: string[]);
    resetUserIpRequestHeaders(): void;
    get userIpRequestHeadersInput(): string[] | undefined;
    private _jsonCustomConfig;
    get jsonCustomConfig(): ComputeRegionSecurityPolicyAdvancedOptionsConfigJsonCustomConfigOutputReference;
    putJsonCustomConfig(value: ComputeRegionSecurityPolicyAdvancedOptionsConfigJsonCustomConfig): void;
    resetJsonCustomConfig(): void;
    get jsonCustomConfigInput(): ComputeRegionSecurityPolicyAdvancedOptionsConfigJsonCustomConfig | undefined;
}
export interface ComputeRegionSecurityPolicyDdosProtectionConfig {
    /**
    * Google Cloud Armor offers the following options to help protect systems against DDoS attacks:
    * - STANDARD: basic always-on protection for network load balancers, protocol forwarding, or VMs with public IP addresses.
    * - ADVANCED: additional protections for Managed Protection Plus subscribers who use network load balancers, protocol forwarding, or VMs with public IP addresses.
    * - ADVANCED_PREVIEW: flag to enable the security policy in preview mode. Possible values: ["ADVANCED", "ADVANCED_PREVIEW", "STANDARD"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#ddos_protection ComputeRegionSecurityPolicy#ddos_protection}
    */
    readonly ddosProtection: string;
}
export declare function computeRegionSecurityPolicyDdosProtectionConfigToTerraform(struct?: ComputeRegionSecurityPolicyDdosProtectionConfigOutputReference | ComputeRegionSecurityPolicyDdosProtectionConfig): any;
export declare function computeRegionSecurityPolicyDdosProtectionConfigToHclTerraform(struct?: ComputeRegionSecurityPolicyDdosProtectionConfigOutputReference | ComputeRegionSecurityPolicyDdosProtectionConfig): any;
export declare class ComputeRegionSecurityPolicyDdosProtectionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionSecurityPolicyDdosProtectionConfig | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyDdosProtectionConfig | undefined);
    private _ddosProtection?;
    get ddosProtection(): string;
    set ddosProtection(value: string);
    get ddosProtectionInput(): string | undefined;
}
export interface ComputeRegionSecurityPolicyRulesMatchConfig {
    /**
    * CIDR IP address range. Maximum number of srcIpRanges allowed is 10.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#src_ip_ranges ComputeRegionSecurityPolicy#src_ip_ranges}
    */
    readonly srcIpRanges?: string[];
}
export declare function computeRegionSecurityPolicyRulesMatchConfigToTerraform(struct?: ComputeRegionSecurityPolicyRulesMatchConfigOutputReference | ComputeRegionSecurityPolicyRulesMatchConfig): any;
export declare function computeRegionSecurityPolicyRulesMatchConfigToHclTerraform(struct?: ComputeRegionSecurityPolicyRulesMatchConfigOutputReference | ComputeRegionSecurityPolicyRulesMatchConfig): any;
export declare class ComputeRegionSecurityPolicyRulesMatchConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionSecurityPolicyRulesMatchConfig | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRulesMatchConfig | undefined);
    private _srcIpRanges?;
    get srcIpRanges(): string[];
    set srcIpRanges(value: string[]);
    resetSrcIpRanges(): void;
    get srcIpRangesInput(): string[] | undefined;
}
export interface ComputeRegionSecurityPolicyRulesMatchExpr {
    /**
    * Textual representation of an expression in Common Expression Language syntax. The application context of the containing message determines which well-known feature set of CEL is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#expression ComputeRegionSecurityPolicy#expression}
    */
    readonly expression: string;
}
export declare function computeRegionSecurityPolicyRulesMatchExprToTerraform(struct?: ComputeRegionSecurityPolicyRulesMatchExprOutputReference | ComputeRegionSecurityPolicyRulesMatchExpr): any;
export declare function computeRegionSecurityPolicyRulesMatchExprToHclTerraform(struct?: ComputeRegionSecurityPolicyRulesMatchExprOutputReference | ComputeRegionSecurityPolicyRulesMatchExpr): any;
export declare class ComputeRegionSecurityPolicyRulesMatchExprOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionSecurityPolicyRulesMatchExpr | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRulesMatchExpr | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
}
export interface ComputeRegionSecurityPolicyRulesMatch {
    /**
    * Preconfigured versioned expression. If this field is specified, config must also be specified.
    * Available preconfigured expressions along with their requirements are: SRC_IPS_V1 - must specify the corresponding srcIpRange field in config. Possible values: ["SRC_IPS_V1"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#versioned_expr ComputeRegionSecurityPolicy#versioned_expr}
    */
    readonly versionedExpr?: string;
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#config ComputeRegionSecurityPolicy#config}
    */
    readonly config?: ComputeRegionSecurityPolicyRulesMatchConfig;
    /**
    * expr block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#expr ComputeRegionSecurityPolicy#expr}
    */
    readonly expr?: ComputeRegionSecurityPolicyRulesMatchExpr;
}
export declare function computeRegionSecurityPolicyRulesMatchToTerraform(struct?: ComputeRegionSecurityPolicyRulesMatchOutputReference | ComputeRegionSecurityPolicyRulesMatch): any;
export declare function computeRegionSecurityPolicyRulesMatchToHclTerraform(struct?: ComputeRegionSecurityPolicyRulesMatchOutputReference | ComputeRegionSecurityPolicyRulesMatch): any;
export declare class ComputeRegionSecurityPolicyRulesMatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionSecurityPolicyRulesMatch | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRulesMatch | undefined);
    private _versionedExpr?;
    get versionedExpr(): string;
    set versionedExpr(value: string);
    resetVersionedExpr(): void;
    get versionedExprInput(): string | undefined;
    private _config;
    get config(): ComputeRegionSecurityPolicyRulesMatchConfigOutputReference;
    putConfig(value: ComputeRegionSecurityPolicyRulesMatchConfig): void;
    resetConfig(): void;
    get configInput(): ComputeRegionSecurityPolicyRulesMatchConfig | undefined;
    private _expr;
    get expr(): ComputeRegionSecurityPolicyRulesMatchExprOutputReference;
    putExpr(value: ComputeRegionSecurityPolicyRulesMatchExpr): void;
    resetExpr(): void;
    get exprInput(): ComputeRegionSecurityPolicyRulesMatchExpr | undefined;
}
export interface ComputeRegionSecurityPolicyRulesNetworkMatchUserDefinedFields {
    /**
    * Name of the user-defined field, as given in the definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#name ComputeRegionSecurityPolicy#name}
    */
    readonly name?: string;
    /**
    * Matching values of the field. Each element can be a 32-bit unsigned decimal or hexadecimal (starting with "0x") number (e.g. "64") or range (e.g. "0x400-0x7ff").
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#values ComputeRegionSecurityPolicy#values}
    */
    readonly values?: string[];
}
export declare function computeRegionSecurityPolicyRulesNetworkMatchUserDefinedFieldsToTerraform(struct?: ComputeRegionSecurityPolicyRulesNetworkMatchUserDefinedFields | cdktn.IResolvable): any;
export declare function computeRegionSecurityPolicyRulesNetworkMatchUserDefinedFieldsToHclTerraform(struct?: ComputeRegionSecurityPolicyRulesNetworkMatchUserDefinedFields | cdktn.IResolvable): any;
export declare class ComputeRegionSecurityPolicyRulesNetworkMatchUserDefinedFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionSecurityPolicyRulesNetworkMatchUserDefinedFields | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRulesNetworkMatchUserDefinedFields | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class ComputeRegionSecurityPolicyRulesNetworkMatchUserDefinedFieldsList extends cdktn.ComplexList {
    internalValue?: ComputeRegionSecurityPolicyRulesNetworkMatchUserDefinedFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionSecurityPolicyRulesNetworkMatchUserDefinedFieldsOutputReference;
}
export interface ComputeRegionSecurityPolicyRulesNetworkMatch {
    /**
    * Destination IPv4/IPv6 addresses or CIDR prefixes, in standard text format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#dest_ip_ranges ComputeRegionSecurityPolicy#dest_ip_ranges}
    */
    readonly destIpRanges?: string[];
    /**
    * Destination port numbers for TCP/UDP/SCTP. Each element can be a 16-bit unsigned decimal number (e.g. "80") or range (e.g. "0-1023").
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#dest_ports ComputeRegionSecurityPolicy#dest_ports}
    */
    readonly destPorts?: string[];
    /**
    * IPv4 protocol / IPv6 next header (after extension headers). Each element can be an 8-bit unsigned decimal number (e.g. "6"), range (e.g. "253-254"), or one of the following protocol names: "tcp", "udp", "icmp", "esp", "ah", "ipip", or "sctp".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#ip_protocols ComputeRegionSecurityPolicy#ip_protocols}
    */
    readonly ipProtocols?: string[];
    /**
    * BGP Autonomous System Number associated with the source IP address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#src_asns ComputeRegionSecurityPolicy#src_asns}
    */
    readonly srcAsns?: number[];
    /**
    * Source IPv4/IPv6 addresses or CIDR prefixes, in standard text format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#src_ip_ranges ComputeRegionSecurityPolicy#src_ip_ranges}
    */
    readonly srcIpRanges?: string[];
    /**
    * Source port numbers for TCP/UDP/SCTP. Each element can be a 16-bit unsigned decimal number (e.g. "80") or range (e.g. "0-1023").
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#src_ports ComputeRegionSecurityPolicy#src_ports}
    */
    readonly srcPorts?: string[];
    /**
    * Two-letter ISO 3166-1 alpha-2 country code associated with the source IP address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#src_region_codes ComputeRegionSecurityPolicy#src_region_codes}
    */
    readonly srcRegionCodes?: string[];
    /**
    * user_defined_fields block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#user_defined_fields ComputeRegionSecurityPolicy#user_defined_fields}
    */
    readonly userDefinedFields?: ComputeRegionSecurityPolicyRulesNetworkMatchUserDefinedFields[] | cdktn.IResolvable;
}
export declare function computeRegionSecurityPolicyRulesNetworkMatchToTerraform(struct?: ComputeRegionSecurityPolicyRulesNetworkMatchOutputReference | ComputeRegionSecurityPolicyRulesNetworkMatch): any;
export declare function computeRegionSecurityPolicyRulesNetworkMatchToHclTerraform(struct?: ComputeRegionSecurityPolicyRulesNetworkMatchOutputReference | ComputeRegionSecurityPolicyRulesNetworkMatch): any;
export declare class ComputeRegionSecurityPolicyRulesNetworkMatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionSecurityPolicyRulesNetworkMatch | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRulesNetworkMatch | undefined);
    private _destIpRanges?;
    get destIpRanges(): string[];
    set destIpRanges(value: string[]);
    resetDestIpRanges(): void;
    get destIpRangesInput(): string[] | undefined;
    private _destPorts?;
    get destPorts(): string[];
    set destPorts(value: string[]);
    resetDestPorts(): void;
    get destPortsInput(): string[] | undefined;
    private _ipProtocols?;
    get ipProtocols(): string[];
    set ipProtocols(value: string[]);
    resetIpProtocols(): void;
    get ipProtocolsInput(): string[] | undefined;
    private _srcAsns?;
    get srcAsns(): number[];
    set srcAsns(value: number[]);
    resetSrcAsns(): void;
    get srcAsnsInput(): number[] | undefined;
    private _srcIpRanges?;
    get srcIpRanges(): string[];
    set srcIpRanges(value: string[]);
    resetSrcIpRanges(): void;
    get srcIpRangesInput(): string[] | undefined;
    private _srcPorts?;
    get srcPorts(): string[];
    set srcPorts(value: string[]);
    resetSrcPorts(): void;
    get srcPortsInput(): string[] | undefined;
    private _srcRegionCodes?;
    get srcRegionCodes(): string[];
    set srcRegionCodes(value: string[]);
    resetSrcRegionCodes(): void;
    get srcRegionCodesInput(): string[] | undefined;
    private _userDefinedFields;
    get userDefinedFields(): ComputeRegionSecurityPolicyRulesNetworkMatchUserDefinedFieldsList;
    putUserDefinedFields(value: ComputeRegionSecurityPolicyRulesNetworkMatchUserDefinedFields[] | cdktn.IResolvable): void;
    resetUserDefinedFields(): void;
    get userDefinedFieldsInput(): cdktn.IResolvable | ComputeRegionSecurityPolicyRulesNetworkMatchUserDefinedFields[] | undefined;
}
export interface ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestBody {
    /**
    * You can specify an exact match or a partial match by using a field operator and a field value.
    * Available options:
    * EQUALS: The operator matches if the field value equals the specified value.
    * STARTS_WITH: The operator matches if the field value starts with the specified value.
    * ENDS_WITH: The operator matches if the field value ends with the specified value.
    * CONTAINS: The operator matches if the field value contains the specified value.
    * EQUALS_ANY: The operator matches if the field value is any value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#operator ComputeRegionSecurityPolicy#operator}
    */
    readonly operator: string;
    /**
    * A request field matching the specified value will be excluded from inspection during preconfigured WAF evaluation.
    * The field value must be given if the field operator is not EQUALS_ANY, and cannot be given if the field operator is EQUALS_ANY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#value ComputeRegionSecurityPolicy#value}
    */
    readonly value?: string;
}
export declare function computeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestBodyToTerraform(struct?: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestBody | cdktn.IResolvable): any;
export declare function computeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestBodyToHclTerraform(struct?: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestBody | cdktn.IResolvable): any;
export declare class ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestBodyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestBody | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestBody | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestBodyList extends cdktn.ComplexList {
    internalValue?: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestBody[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestBodyOutputReference;
}
export interface ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestCookie {
    /**
    * You can specify an exact match or a partial match by using a field operator and a field value.
    * Available options:
    * EQUALS: The operator matches if the field value equals the specified value.
    * STARTS_WITH: The operator matches if the field value starts with the specified value.
    * ENDS_WITH: The operator matches if the field value ends with the specified value.
    * CONTAINS: The operator matches if the field value contains the specified value.
    * EQUALS_ANY: The operator matches if the field value is any value. Possible values: ["CONTAINS", "ENDS_WITH", "EQUALS", "EQUALS_ANY", "STARTS_WITH"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#operator ComputeRegionSecurityPolicy#operator}
    */
    readonly operator: string;
    /**
    * A request field matching the specified value will be excluded from inspection during preconfigured WAF evaluation.
    * The field value must be given if the field operator is not EQUALS_ANY, and cannot be given if the field operator is EQUALS_ANY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#value ComputeRegionSecurityPolicy#value}
    */
    readonly value?: string;
}
export declare function computeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestCookieToTerraform(struct?: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestCookie | cdktn.IResolvable): any;
export declare function computeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestCookieToHclTerraform(struct?: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestCookie | cdktn.IResolvable): any;
export declare class ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestCookieOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestCookie | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestCookie | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestCookieList extends cdktn.ComplexList {
    internalValue?: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestCookie[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestCookieOutputReference;
}
export interface ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestHeader {
    /**
    * You can specify an exact match or a partial match by using a field operator and a field value.
    * Available options:
    * EQUALS: The operator matches if the field value equals the specified value.
    * STARTS_WITH: The operator matches if the field value starts with the specified value.
    * ENDS_WITH: The operator matches if the field value ends with the specified value.
    * CONTAINS: The operator matches if the field value contains the specified value.
    * EQUALS_ANY: The operator matches if the field value is any value. Possible values: ["CONTAINS", "ENDS_WITH", "EQUALS", "EQUALS_ANY", "STARTS_WITH"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#operator ComputeRegionSecurityPolicy#operator}
    */
    readonly operator: string;
    /**
    * A request field matching the specified value will be excluded from inspection during preconfigured WAF evaluation.
    * The field value must be given if the field operator is not EQUALS_ANY, and cannot be given if the field operator is EQUALS_ANY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#value ComputeRegionSecurityPolicy#value}
    */
    readonly value?: string;
}
export declare function computeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestHeaderToTerraform(struct?: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestHeader | cdktn.IResolvable): any;
export declare function computeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestHeaderToHclTerraform(struct?: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestHeader | cdktn.IResolvable): any;
export declare class ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestHeader | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestHeader | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestHeaderList extends cdktn.ComplexList {
    internalValue?: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestHeaderOutputReference;
}
export interface ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestQueryParam {
    /**
    * You can specify an exact match or a partial match by using a field operator and a field value.
    * Available options:
    * EQUALS: The operator matches if the field value equals the specified value.
    * STARTS_WITH: The operator matches if the field value starts with the specified value.
    * ENDS_WITH: The operator matches if the field value ends with the specified value.
    * CONTAINS: The operator matches if the field value contains the specified value.
    * EQUALS_ANY: The operator matches if the field value is any value. Possible values: ["CONTAINS", "ENDS_WITH", "EQUALS", "EQUALS_ANY", "STARTS_WITH"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#operator ComputeRegionSecurityPolicy#operator}
    */
    readonly operator: string;
    /**
    * A request field matching the specified value will be excluded from inspection during preconfigured WAF evaluation.
    * The field value must be given if the field operator is not EQUALS_ANY, and cannot be given if the field operator is EQUALS_ANY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#value ComputeRegionSecurityPolicy#value}
    */
    readonly value?: string;
}
export declare function computeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestQueryParamToTerraform(struct?: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestQueryParam | cdktn.IResolvable): any;
export declare function computeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestQueryParamToHclTerraform(struct?: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestQueryParam | cdktn.IResolvable): any;
export declare class ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestQueryParamOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestQueryParam | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestQueryParam | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestQueryParamList extends cdktn.ComplexList {
    internalValue?: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestQueryParam[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestQueryParamOutputReference;
}
export interface ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestUri {
    /**
    * You can specify an exact match or a partial match by using a field operator and a field value.
    * Available options:
    * EQUALS: The operator matches if the field value equals the specified value.
    * STARTS_WITH: The operator matches if the field value starts with the specified value.
    * ENDS_WITH: The operator matches if the field value ends with the specified value.
    * CONTAINS: The operator matches if the field value contains the specified value.
    * EQUALS_ANY: The operator matches if the field value is any value. Possible values: ["CONTAINS", "ENDS_WITH", "EQUALS", "EQUALS_ANY", "STARTS_WITH"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#operator ComputeRegionSecurityPolicy#operator}
    */
    readonly operator: string;
    /**
    * A request field matching the specified value will be excluded from inspection during preconfigured WAF evaluation.
    * The field value must be given if the field operator is not EQUALS_ANY, and cannot be given if the field operator is EQUALS_ANY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#value ComputeRegionSecurityPolicy#value}
    */
    readonly value?: string;
}
export declare function computeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestUriToTerraform(struct?: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestUri | cdktn.IResolvable): any;
export declare function computeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestUriToHclTerraform(struct?: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestUri | cdktn.IResolvable): any;
export declare class ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestUriOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestUri | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestUri | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestUriList extends cdktn.ComplexList {
    internalValue?: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestUri[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestUriOutputReference;
}
export interface ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusion {
    /**
    * A list of target rule IDs under the WAF rule set to apply the preconfigured WAF exclusion.
    * If omitted, it refers to all the rule IDs under the WAF rule set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#target_rule_ids ComputeRegionSecurityPolicy#target_rule_ids}
    */
    readonly targetRuleIds?: string[];
    /**
    * Target WAF rule set to apply the preconfigured WAF exclusion.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#target_rule_set ComputeRegionSecurityPolicy#target_rule_set}
    */
    readonly targetRuleSet: string;
    /**
    * request_body block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#request_body ComputeRegionSecurityPolicy#request_body}
    */
    readonly requestBody?: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestBody[] | cdktn.IResolvable;
    /**
    * request_cookie block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#request_cookie ComputeRegionSecurityPolicy#request_cookie}
    */
    readonly requestCookie?: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestCookie[] | cdktn.IResolvable;
    /**
    * request_header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#request_header ComputeRegionSecurityPolicy#request_header}
    */
    readonly requestHeader?: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestHeader[] | cdktn.IResolvable;
    /**
    * request_query_param block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#request_query_param ComputeRegionSecurityPolicy#request_query_param}
    */
    readonly requestQueryParam?: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestQueryParam[] | cdktn.IResolvable;
    /**
    * request_uri block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#request_uri ComputeRegionSecurityPolicy#request_uri}
    */
    readonly requestUri?: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestUri[] | cdktn.IResolvable;
}
export declare function computeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionToTerraform(struct?: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusion | cdktn.IResolvable): any;
export declare function computeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionToHclTerraform(struct?: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusion | cdktn.IResolvable): any;
export declare class ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusion | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusion | cdktn.IResolvable | undefined);
    private _targetRuleIds?;
    get targetRuleIds(): string[];
    set targetRuleIds(value: string[]);
    resetTargetRuleIds(): void;
    get targetRuleIdsInput(): string[] | undefined;
    private _targetRuleSet?;
    get targetRuleSet(): string;
    set targetRuleSet(value: string);
    get targetRuleSetInput(): string | undefined;
    private _requestBody;
    get requestBody(): ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestBodyList;
    putRequestBody(value: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestBody[] | cdktn.IResolvable): void;
    resetRequestBody(): void;
    get requestBodyInput(): cdktn.IResolvable | ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestBody[] | undefined;
    private _requestCookie;
    get requestCookie(): ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestCookieList;
    putRequestCookie(value: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestCookie[] | cdktn.IResolvable): void;
    resetRequestCookie(): void;
    get requestCookieInput(): cdktn.IResolvable | ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestCookie[] | undefined;
    private _requestHeader;
    get requestHeader(): ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestHeaderList;
    putRequestHeader(value: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestHeader[] | cdktn.IResolvable): void;
    resetRequestHeader(): void;
    get requestHeaderInput(): cdktn.IResolvable | ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestHeader[] | undefined;
    private _requestQueryParam;
    get requestQueryParam(): ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestQueryParamList;
    putRequestQueryParam(value: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestQueryParam[] | cdktn.IResolvable): void;
    resetRequestQueryParam(): void;
    get requestQueryParamInput(): cdktn.IResolvable | ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestQueryParam[] | undefined;
    private _requestUri;
    get requestUri(): ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestUriList;
    putRequestUri(value: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestUri[] | cdktn.IResolvable): void;
    resetRequestUri(): void;
    get requestUriInput(): cdktn.IResolvable | ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestUri[] | undefined;
}
export declare class ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionList extends cdktn.ComplexList {
    internalValue?: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusion[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionOutputReference;
}
export interface ComputeRegionSecurityPolicyRulesPreconfiguredWafConfig {
    /**
    * exclusion block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#exclusion ComputeRegionSecurityPolicy#exclusion}
    */
    readonly exclusion?: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusion[] | cdktn.IResolvable;
}
export declare function computeRegionSecurityPolicyRulesPreconfiguredWafConfigToTerraform(struct?: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigOutputReference | ComputeRegionSecurityPolicyRulesPreconfiguredWafConfig): any;
export declare function computeRegionSecurityPolicyRulesPreconfiguredWafConfigToHclTerraform(struct?: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigOutputReference | ComputeRegionSecurityPolicyRulesPreconfiguredWafConfig): any;
export declare class ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionSecurityPolicyRulesPreconfiguredWafConfig | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfig | undefined);
    private _exclusion;
    get exclusion(): ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionList;
    putExclusion(value: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusion[] | cdktn.IResolvable): void;
    resetExclusion(): void;
    get exclusionInput(): cdktn.IResolvable | ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusion[] | undefined;
}
export interface ComputeRegionSecurityPolicyRulesRateLimitOptionsBanThreshold {
    /**
    * Number of HTTP(S) requests for calculating the threshold.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#count ComputeRegionSecurityPolicy#count}
    */
    readonly count?: number;
    /**
    * Interval over which the threshold is computed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#interval_sec ComputeRegionSecurityPolicy#interval_sec}
    */
    readonly intervalSec?: number;
}
export declare function computeRegionSecurityPolicyRulesRateLimitOptionsBanThresholdToTerraform(struct?: ComputeRegionSecurityPolicyRulesRateLimitOptionsBanThresholdOutputReference | ComputeRegionSecurityPolicyRulesRateLimitOptionsBanThreshold): any;
export declare function computeRegionSecurityPolicyRulesRateLimitOptionsBanThresholdToHclTerraform(struct?: ComputeRegionSecurityPolicyRulesRateLimitOptionsBanThresholdOutputReference | ComputeRegionSecurityPolicyRulesRateLimitOptionsBanThreshold): any;
export declare class ComputeRegionSecurityPolicyRulesRateLimitOptionsBanThresholdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionSecurityPolicyRulesRateLimitOptionsBanThreshold | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRulesRateLimitOptionsBanThreshold | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    resetCount(): void;
    get countInput(): number | undefined;
    private _intervalSec?;
    get intervalSec(): number;
    set intervalSec(value: number);
    resetIntervalSec(): void;
    get intervalSecInput(): number | undefined;
}
export interface ComputeRegionSecurityPolicyRulesRateLimitOptionsEnforceOnKeyConfigs {
    /**
    * Rate limit key name applicable only for the following key types:
    * HTTP_HEADER -- Name of the HTTP header whose value is taken as the key value.
    * HTTP_COOKIE -- Name of the HTTP cookie whose value is taken as the key value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#enforce_on_key_name ComputeRegionSecurityPolicy#enforce_on_key_name}
    */
    readonly enforceOnKeyName?: string;
    /**
    * Determines the key to enforce the rateLimitThreshold on. Possible values are:
    * * ALL: A single rate limit threshold is applied to all the requests matching this rule. This is the default value if "enforceOnKeyConfigs" is not configured.
    * * IP: The source IP address of the request is the key. Each IP has this limit enforced separately.
    * * HTTP_HEADER: The value of the HTTP header whose name is configured under "enforceOnKeyName". The key value is truncated to the first 128 bytes of the header value. If no such header is present in the request, the key type defaults to ALL.
    * * XFF_IP: The first IP address (i.e. the originating client IP address) specified in the list of IPs under X-Forwarded-For HTTP header. If no such header is present or the value is not a valid IP, the key defaults to the source IP address of the request i.e. key type IP.
    * * HTTP_COOKIE: The value of the HTTP cookie whose name is configured under "enforceOnKeyName". The key value is truncated to the first 128 bytes of the cookie value. If no such cookie is present in the request, the key type defaults to ALL.
    * * HTTP_PATH: The URL path of the HTTP request. The key value is truncated to the first 128 bytes.
    * * SNI: Server name indication in the TLS session of the HTTPS request. The key value is truncated to the first 128 bytes. The key type defaults to ALL on a HTTP session.
    * * REGION_CODE: The country/region from which the request originates.
    * * TLS_JA3_FINGERPRINT: JA3 TLS/SSL fingerprint if the client connects using HTTPS, HTTP/2 or HTTP/3. If not available, the key type defaults to ALL.
    * * TLS_JA4_FINGERPRINT: JA4 TLS/SSL fingerprint if the client connects using HTTPS, HTTP/2 or HTTP/3. If not available, the key type defaults to ALL.
    * * USER_IP: The IP address of the originating client, which is resolved based on "userIpRequestHeaders" configured with the security policy. If there is no "userIpRequestHeaders" configuration or an IP address cannot be resolved from it, the key type defaults to IP. Possible values: ["ALL", "IP", "HTTP_HEADER", "XFF_IP", "HTTP_COOKIE", "HTTP_PATH", "SNI", "REGION_CODE", "TLS_JA3_FINGERPRINT", "TLS_JA4_FINGERPRINT", "USER_IP"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#enforce_on_key_type ComputeRegionSecurityPolicy#enforce_on_key_type}
    */
    readonly enforceOnKeyType?: string;
}
export declare function computeRegionSecurityPolicyRulesRateLimitOptionsEnforceOnKeyConfigsToTerraform(struct?: ComputeRegionSecurityPolicyRulesRateLimitOptionsEnforceOnKeyConfigs | cdktn.IResolvable): any;
export declare function computeRegionSecurityPolicyRulesRateLimitOptionsEnforceOnKeyConfigsToHclTerraform(struct?: ComputeRegionSecurityPolicyRulesRateLimitOptionsEnforceOnKeyConfigs | cdktn.IResolvable): any;
export declare class ComputeRegionSecurityPolicyRulesRateLimitOptionsEnforceOnKeyConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionSecurityPolicyRulesRateLimitOptionsEnforceOnKeyConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRulesRateLimitOptionsEnforceOnKeyConfigs | cdktn.IResolvable | undefined);
    private _enforceOnKeyName?;
    get enforceOnKeyName(): string;
    set enforceOnKeyName(value: string);
    resetEnforceOnKeyName(): void;
    get enforceOnKeyNameInput(): string | undefined;
    private _enforceOnKeyType?;
    get enforceOnKeyType(): string;
    set enforceOnKeyType(value: string);
    resetEnforceOnKeyType(): void;
    get enforceOnKeyTypeInput(): string | undefined;
}
export declare class ComputeRegionSecurityPolicyRulesRateLimitOptionsEnforceOnKeyConfigsList extends cdktn.ComplexList {
    internalValue?: ComputeRegionSecurityPolicyRulesRateLimitOptionsEnforceOnKeyConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionSecurityPolicyRulesRateLimitOptionsEnforceOnKeyConfigsOutputReference;
}
export interface ComputeRegionSecurityPolicyRulesRateLimitOptionsRateLimitThreshold {
    /**
    * Number of HTTP(S) requests for calculating the threshold.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#count ComputeRegionSecurityPolicy#count}
    */
    readonly count?: number;
    /**
    * Interval over which the threshold is computed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#interval_sec ComputeRegionSecurityPolicy#interval_sec}
    */
    readonly intervalSec?: number;
}
export declare function computeRegionSecurityPolicyRulesRateLimitOptionsRateLimitThresholdToTerraform(struct?: ComputeRegionSecurityPolicyRulesRateLimitOptionsRateLimitThresholdOutputReference | ComputeRegionSecurityPolicyRulesRateLimitOptionsRateLimitThreshold): any;
export declare function computeRegionSecurityPolicyRulesRateLimitOptionsRateLimitThresholdToHclTerraform(struct?: ComputeRegionSecurityPolicyRulesRateLimitOptionsRateLimitThresholdOutputReference | ComputeRegionSecurityPolicyRulesRateLimitOptionsRateLimitThreshold): any;
export declare class ComputeRegionSecurityPolicyRulesRateLimitOptionsRateLimitThresholdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionSecurityPolicyRulesRateLimitOptionsRateLimitThreshold | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRulesRateLimitOptionsRateLimitThreshold | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    resetCount(): void;
    get countInput(): number | undefined;
    private _intervalSec?;
    get intervalSec(): number;
    set intervalSec(value: number);
    resetIntervalSec(): void;
    get intervalSecInput(): number | undefined;
}
export interface ComputeRegionSecurityPolicyRulesRateLimitOptions {
    /**
    * Can only be specified if the action for the rule is "rate_based_ban".
    * If specified, determines the time (in seconds) the traffic will continue to be banned by the rate limit after the rate falls below the threshold.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#ban_duration_sec ComputeRegionSecurityPolicy#ban_duration_sec}
    */
    readonly banDurationSec?: number;
    /**
    * Action to take for requests that are under the configured rate limit threshold.
    * Valid option is "allow" only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#conform_action ComputeRegionSecurityPolicy#conform_action}
    */
    readonly conformAction?: string;
    /**
    * Determines the key to enforce the rateLimitThreshold on. Possible values are:
    * * ALL: A single rate limit threshold is applied to all the requests matching this rule. This is the default value if "enforceOnKey" is not configured.
    * * IP: The source IP address of the request is the key. Each IP has this limit enforced separately.
    * * HTTP_HEADER: The value of the HTTP header whose name is configured under "enforceOnKeyName". The key value is truncated to the first 128 bytes of the header value. If no such header is present in the request, the key type defaults to ALL.
    * * XFF_IP: The first IP address (i.e. the originating client IP address) specified in the list of IPs under X-Forwarded-For HTTP header. If no such header is present or the value is not a valid IP, the key defaults to the source IP address of the request i.e. key type IP.
    * * HTTP_COOKIE: The value of the HTTP cookie whose name is configured under "enforceOnKeyName". The key value is truncated to the first 128 bytes of the cookie value. If no such cookie is present in the request, the key type defaults to ALL.
    * * HTTP_PATH: The URL path of the HTTP request. The key value is truncated to the first 128 bytes.
    * * SNI: Server name indication in the TLS session of the HTTPS request. The key value is truncated to the first 128 bytes. The key type defaults to ALL on a HTTP session.
    * * REGION_CODE: The country/region from which the request originates.
    * * TLS_JA3_FINGERPRINT: JA3 TLS/SSL fingerprint if the client connects using HTTPS, HTTP/2 or HTTP/3. If not available, the key type defaults to ALL.
    * * TLS_JA4_FINGERPRINT: JA4 TLS/SSL fingerprint if the client connects using HTTPS, HTTP/2 or HTTP/3. If not available, the key type defaults to ALL.
    * * USER_IP: The IP address of the originating client, which is resolved based on "userIpRequestHeaders" configured with the security policy. If there is no "userIpRequestHeaders" configuration or an IP address cannot be resolved from it, the key type defaults to IP. Possible values: ["ALL", "IP", "HTTP_HEADER", "XFF_IP", "HTTP_COOKIE", "HTTP_PATH", "SNI", "REGION_CODE", "TLS_JA3_FINGERPRINT", "TLS_JA4_FINGERPRINT", "USER_IP"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#enforce_on_key ComputeRegionSecurityPolicy#enforce_on_key}
    */
    readonly enforceOnKey?: string;
    /**
    * Rate limit key name applicable only for the following key types:
    * HTTP_HEADER -- Name of the HTTP header whose value is taken as the key value.
    * HTTP_COOKIE -- Name of the HTTP cookie whose value is taken as the key value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#enforce_on_key_name ComputeRegionSecurityPolicy#enforce_on_key_name}
    */
    readonly enforceOnKeyName?: string;
    /**
    * Action to take for requests that are above the configured rate limit threshold, to deny with a specified HTTP response code.
    * Valid options are deny(STATUS), where valid values for STATUS are 403, 404, 429, and 502.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#exceed_action ComputeRegionSecurityPolicy#exceed_action}
    */
    readonly exceedAction?: string;
    /**
    * ban_threshold block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#ban_threshold ComputeRegionSecurityPolicy#ban_threshold}
    */
    readonly banThreshold?: ComputeRegionSecurityPolicyRulesRateLimitOptionsBanThreshold;
    /**
    * enforce_on_key_configs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#enforce_on_key_configs ComputeRegionSecurityPolicy#enforce_on_key_configs}
    */
    readonly enforceOnKeyConfigs?: ComputeRegionSecurityPolicyRulesRateLimitOptionsEnforceOnKeyConfigs[] | cdktn.IResolvable;
    /**
    * rate_limit_threshold block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#rate_limit_threshold ComputeRegionSecurityPolicy#rate_limit_threshold}
    */
    readonly rateLimitThreshold?: ComputeRegionSecurityPolicyRulesRateLimitOptionsRateLimitThreshold;
}
export declare function computeRegionSecurityPolicyRulesRateLimitOptionsToTerraform(struct?: ComputeRegionSecurityPolicyRulesRateLimitOptionsOutputReference | ComputeRegionSecurityPolicyRulesRateLimitOptions): any;
export declare function computeRegionSecurityPolicyRulesRateLimitOptionsToHclTerraform(struct?: ComputeRegionSecurityPolicyRulesRateLimitOptionsOutputReference | ComputeRegionSecurityPolicyRulesRateLimitOptions): any;
export declare class ComputeRegionSecurityPolicyRulesRateLimitOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionSecurityPolicyRulesRateLimitOptions | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRulesRateLimitOptions | undefined);
    private _banDurationSec?;
    get banDurationSec(): number;
    set banDurationSec(value: number);
    resetBanDurationSec(): void;
    get banDurationSecInput(): number | undefined;
    private _conformAction?;
    get conformAction(): string;
    set conformAction(value: string);
    resetConformAction(): void;
    get conformActionInput(): string | undefined;
    private _enforceOnKey?;
    get enforceOnKey(): string;
    set enforceOnKey(value: string);
    resetEnforceOnKey(): void;
    get enforceOnKeyInput(): string | undefined;
    private _enforceOnKeyName?;
    get enforceOnKeyName(): string;
    set enforceOnKeyName(value: string);
    resetEnforceOnKeyName(): void;
    get enforceOnKeyNameInput(): string | undefined;
    private _exceedAction?;
    get exceedAction(): string;
    set exceedAction(value: string);
    resetExceedAction(): void;
    get exceedActionInput(): string | undefined;
    private _banThreshold;
    get banThreshold(): ComputeRegionSecurityPolicyRulesRateLimitOptionsBanThresholdOutputReference;
    putBanThreshold(value: ComputeRegionSecurityPolicyRulesRateLimitOptionsBanThreshold): void;
    resetBanThreshold(): void;
    get banThresholdInput(): ComputeRegionSecurityPolicyRulesRateLimitOptionsBanThreshold | undefined;
    private _enforceOnKeyConfigs;
    get enforceOnKeyConfigs(): ComputeRegionSecurityPolicyRulesRateLimitOptionsEnforceOnKeyConfigsList;
    putEnforceOnKeyConfigs(value: ComputeRegionSecurityPolicyRulesRateLimitOptionsEnforceOnKeyConfigs[] | cdktn.IResolvable): void;
    resetEnforceOnKeyConfigs(): void;
    get enforceOnKeyConfigsInput(): cdktn.IResolvable | ComputeRegionSecurityPolicyRulesRateLimitOptionsEnforceOnKeyConfigs[] | undefined;
    private _rateLimitThreshold;
    get rateLimitThreshold(): ComputeRegionSecurityPolicyRulesRateLimitOptionsRateLimitThresholdOutputReference;
    putRateLimitThreshold(value: ComputeRegionSecurityPolicyRulesRateLimitOptionsRateLimitThreshold): void;
    resetRateLimitThreshold(): void;
    get rateLimitThresholdInput(): ComputeRegionSecurityPolicyRulesRateLimitOptionsRateLimitThreshold | undefined;
}
export interface ComputeRegionSecurityPolicyRules {
    /**
    * The Action to perform when the rule is matched. The following are the valid actions:
    *
    * * allow: allow access to target.
    *
    * * deny(STATUS): deny access to target, returns the HTTP response code specified. Valid values for STATUS are 403, 404, and 502.
    *
    * * rate_based_ban: limit client traffic to the configured threshold and ban the client if the traffic exceeds the threshold. Configure parameters for this action in RateLimitOptions. Requires rateLimitOptions to be set.
    *
    * * redirect: redirect to a different target. This can either be an internal reCAPTCHA redirect, or an external URL-based redirect via a 302 response. Parameters for this action can be configured via redirectOptions. This action is only supported in Global Security Policies of type CLOUD_ARMOR.
    *
    * * throttle: limit client traffic to the configured threshold. Configure parameters for this action in rateLimitOptions. Requires rateLimitOptions to be set for this.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#action ComputeRegionSecurityPolicy#action}
    */
    readonly action: string;
    /**
    * An optional description of this resource. Provide this property when you create the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#description ComputeRegionSecurityPolicy#description}
    */
    readonly description?: string;
    /**
    * If set to true, the specified action is not enforced.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#preview ComputeRegionSecurityPolicy#preview}
    */
    readonly preview?: boolean | cdktn.IResolvable;
    /**
    * An integer indicating the priority of a rule in the list.
    * The priority must be a positive value between 0 and 2147483647.
    * Rules are evaluated from highest to lowest priority where 0 is the highest priority and 2147483647 is the lowest priority.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#priority ComputeRegionSecurityPolicy#priority}
    */
    readonly priority: number;
    /**
    * match block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#match ComputeRegionSecurityPolicy#match}
    */
    readonly match?: ComputeRegionSecurityPolicyRulesMatch;
    /**
    * network_match block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#network_match ComputeRegionSecurityPolicy#network_match}
    */
    readonly networkMatch?: ComputeRegionSecurityPolicyRulesNetworkMatch;
    /**
    * preconfigured_waf_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#preconfigured_waf_config ComputeRegionSecurityPolicy#preconfigured_waf_config}
    */
    readonly preconfiguredWafConfig?: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfig;
    /**
    * rate_limit_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#rate_limit_options ComputeRegionSecurityPolicy#rate_limit_options}
    */
    readonly rateLimitOptions?: ComputeRegionSecurityPolicyRulesRateLimitOptions;
}
export declare function computeRegionSecurityPolicyRulesToTerraform(struct?: ComputeRegionSecurityPolicyRules | cdktn.IResolvable): any;
export declare function computeRegionSecurityPolicyRulesToHclTerraform(struct?: ComputeRegionSecurityPolicyRules | cdktn.IResolvable): any;
export declare class ComputeRegionSecurityPolicyRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionSecurityPolicyRules | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyRules | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _preview?;
    get preview(): boolean | cdktn.IResolvable;
    set preview(value: boolean | cdktn.IResolvable);
    resetPreview(): void;
    get previewInput(): boolean | cdktn.IResolvable | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
    private _match;
    get match(): ComputeRegionSecurityPolicyRulesMatchOutputReference;
    putMatch(value: ComputeRegionSecurityPolicyRulesMatch): void;
    resetMatch(): void;
    get matchInput(): ComputeRegionSecurityPolicyRulesMatch | undefined;
    private _networkMatch;
    get networkMatch(): ComputeRegionSecurityPolicyRulesNetworkMatchOutputReference;
    putNetworkMatch(value: ComputeRegionSecurityPolicyRulesNetworkMatch): void;
    resetNetworkMatch(): void;
    get networkMatchInput(): ComputeRegionSecurityPolicyRulesNetworkMatch | undefined;
    private _preconfiguredWafConfig;
    get preconfiguredWafConfig(): ComputeRegionSecurityPolicyRulesPreconfiguredWafConfigOutputReference;
    putPreconfiguredWafConfig(value: ComputeRegionSecurityPolicyRulesPreconfiguredWafConfig): void;
    resetPreconfiguredWafConfig(): void;
    get preconfiguredWafConfigInput(): ComputeRegionSecurityPolicyRulesPreconfiguredWafConfig | undefined;
    private _rateLimitOptions;
    get rateLimitOptions(): ComputeRegionSecurityPolicyRulesRateLimitOptionsOutputReference;
    putRateLimitOptions(value: ComputeRegionSecurityPolicyRulesRateLimitOptions): void;
    resetRateLimitOptions(): void;
    get rateLimitOptionsInput(): ComputeRegionSecurityPolicyRulesRateLimitOptions | undefined;
}
export declare class ComputeRegionSecurityPolicyRulesList extends cdktn.ComplexList {
    internalValue?: ComputeRegionSecurityPolicyRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionSecurityPolicyRulesOutputReference;
}
export interface ComputeRegionSecurityPolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#create ComputeRegionSecurityPolicy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#delete ComputeRegionSecurityPolicy#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#update ComputeRegionSecurityPolicy#update}
    */
    readonly update?: string;
}
export declare function computeRegionSecurityPolicyTimeoutsToTerraform(struct?: ComputeRegionSecurityPolicyTimeouts | cdktn.IResolvable): any;
export declare function computeRegionSecurityPolicyTimeoutsToHclTerraform(struct?: ComputeRegionSecurityPolicyTimeouts | cdktn.IResolvable): any;
export declare class ComputeRegionSecurityPolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionSecurityPolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface ComputeRegionSecurityPolicyUserDefinedFields {
    /**
    * The base relative to which 'offset' is measured. Possible values are:
    * - IPV4: Points to the beginning of the IPv4 header.
    * - IPV6: Points to the beginning of the IPv6 header.
    * - TCP: Points to the beginning of the TCP header, skipping over any IPv4 options or IPv6 extension headers. Not present for non-first fragments.
    * - UDP: Points to the beginning of the UDP header, skipping over any IPv4 options or IPv6 extension headers. Not present for non-first fragments. Possible values: ["IPV4", "IPV6", "TCP", "UDP"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#base ComputeRegionSecurityPolicy#base}
    */
    readonly base: string;
    /**
    * If specified, apply this mask (bitwise AND) to the field to ignore bits before matching.
    * Encoded as a hexadecimal number (starting with "0x").
    * The last byte of the field (in network byte order) corresponds to the least significant byte of the mask.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#mask ComputeRegionSecurityPolicy#mask}
    */
    readonly mask?: string;
    /**
    * The name of this field. Must be unique within the policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#name ComputeRegionSecurityPolicy#name}
    */
    readonly name?: string;
    /**
    * Offset of the first byte of the field (in network byte order) relative to 'base'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#offset ComputeRegionSecurityPolicy#offset}
    */
    readonly offset?: number;
    /**
    * Size of the field in bytes. Valid values: 1-4.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#size ComputeRegionSecurityPolicy#size}
    */
    readonly size?: number;
}
export declare function computeRegionSecurityPolicyUserDefinedFieldsToTerraform(struct?: ComputeRegionSecurityPolicyUserDefinedFields | cdktn.IResolvable): any;
export declare function computeRegionSecurityPolicyUserDefinedFieldsToHclTerraform(struct?: ComputeRegionSecurityPolicyUserDefinedFields | cdktn.IResolvable): any;
export declare class ComputeRegionSecurityPolicyUserDefinedFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionSecurityPolicyUserDefinedFields | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionSecurityPolicyUserDefinedFields | cdktn.IResolvable | undefined);
    private _base?;
    get base(): string;
    set base(value: string);
    get baseInput(): string | undefined;
    private _mask?;
    get mask(): string;
    set mask(value: string);
    resetMask(): void;
    get maskInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _offset?;
    get offset(): number;
    set offset(value: number);
    resetOffset(): void;
    get offsetInput(): number | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    resetSize(): void;
    get sizeInput(): number | undefined;
}
export declare class ComputeRegionSecurityPolicyUserDefinedFieldsList extends cdktn.ComplexList {
    internalValue?: ComputeRegionSecurityPolicyUserDefinedFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionSecurityPolicyUserDefinedFieldsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy google_compute_region_security_policy}
*/
export declare class ComputeRegionSecurityPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_region_security_policy";
    /**
    * Generates CDKTN code for importing a ComputeRegionSecurityPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeRegionSecurityPolicy to import
    * @param importFromId The id of the existing ComputeRegionSecurityPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeRegionSecurityPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_security_policy google_compute_region_security_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeRegionSecurityPolicyConfig
    */
    constructor(scope: Construct, id: string, config: ComputeRegionSecurityPolicyConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get fingerprint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get policyId(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get selfLink(): string;
    get selfLinkWithPolicyId(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _advancedOptionsConfig;
    get advancedOptionsConfig(): ComputeRegionSecurityPolicyAdvancedOptionsConfigOutputReference;
    putAdvancedOptionsConfig(value: ComputeRegionSecurityPolicyAdvancedOptionsConfig): void;
    resetAdvancedOptionsConfig(): void;
    get advancedOptionsConfigInput(): ComputeRegionSecurityPolicyAdvancedOptionsConfig | undefined;
    private _ddosProtectionConfig;
    get ddosProtectionConfig(): ComputeRegionSecurityPolicyDdosProtectionConfigOutputReference;
    putDdosProtectionConfig(value: ComputeRegionSecurityPolicyDdosProtectionConfig): void;
    resetDdosProtectionConfig(): void;
    get ddosProtectionConfigInput(): ComputeRegionSecurityPolicyDdosProtectionConfig | undefined;
    private _rules;
    get rules(): ComputeRegionSecurityPolicyRulesList;
    putRules(value: ComputeRegionSecurityPolicyRules[] | cdktn.IResolvable): void;
    resetRules(): void;
    get rulesInput(): cdktn.IResolvable | ComputeRegionSecurityPolicyRules[] | undefined;
    private _timeouts;
    get timeouts(): ComputeRegionSecurityPolicyTimeoutsOutputReference;
    putTimeouts(value: ComputeRegionSecurityPolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeRegionSecurityPolicyTimeouts | undefined;
    private _userDefinedFields;
    get userDefinedFields(): ComputeRegionSecurityPolicyUserDefinedFieldsList;
    putUserDefinedFields(value: ComputeRegionSecurityPolicyUserDefinedFields[] | cdktn.IResolvable): void;
    resetUserDefinedFields(): void;
    get userDefinedFieldsInput(): cdktn.IResolvable | ComputeRegionSecurityPolicyUserDefinedFields[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
