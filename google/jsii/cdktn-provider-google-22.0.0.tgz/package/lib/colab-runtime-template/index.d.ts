/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ColabRuntimeTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#deletion_policy ColabRuntimeTemplate#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The description of the Runtime Template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#description ColabRuntimeTemplate#description}
    */
    readonly description?: string;
    /**
    * Required. The display name of the Runtime Template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#display_name ColabRuntimeTemplate#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#id ColabRuntimeTemplate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Labels to identify and group the runtime template.
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#labels ColabRuntimeTemplate#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The location for the resource: https://cloud.google.com/colab/docs/locations
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#location ColabRuntimeTemplate#location}
    */
    readonly location: string;
    /**
    * The resource name of the Runtime Template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#name ColabRuntimeTemplate#name}
    */
    readonly name?: string;
    /**
    * Applies the given Compute Engine tags to the runtime.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#network_tags ColabRuntimeTemplate#network_tags}
    */
    readonly networkTags?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#project ColabRuntimeTemplate#project}
    */
    readonly project?: string;
    /**
    * data_persistent_disk_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#data_persistent_disk_spec ColabRuntimeTemplate#data_persistent_disk_spec}
    */
    readonly dataPersistentDiskSpec?: ColabRuntimeTemplateDataPersistentDiskSpec;
    /**
    * encryption_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#encryption_spec ColabRuntimeTemplate#encryption_spec}
    */
    readonly encryptionSpec?: ColabRuntimeTemplateEncryptionSpec;
    /**
    * euc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#euc_config ColabRuntimeTemplate#euc_config}
    */
    readonly eucConfig?: ColabRuntimeTemplateEucConfig;
    /**
    * idle_shutdown_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#idle_shutdown_config ColabRuntimeTemplate#idle_shutdown_config}
    */
    readonly idleShutdownConfig?: ColabRuntimeTemplateIdleShutdownConfig;
    /**
    * machine_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#machine_spec ColabRuntimeTemplate#machine_spec}
    */
    readonly machineSpec?: ColabRuntimeTemplateMachineSpec;
    /**
    * network_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#network_spec ColabRuntimeTemplate#network_spec}
    */
    readonly networkSpec?: ColabRuntimeTemplateNetworkSpec;
    /**
    * shielded_vm_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#shielded_vm_config ColabRuntimeTemplate#shielded_vm_config}
    */
    readonly shieldedVmConfig?: ColabRuntimeTemplateShieldedVmConfig;
    /**
    * software_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#software_config ColabRuntimeTemplate#software_config}
    */
    readonly softwareConfig?: ColabRuntimeTemplateSoftwareConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#timeouts ColabRuntimeTemplate#timeouts}
    */
    readonly timeouts?: ColabRuntimeTemplateTimeouts;
}
export interface ColabRuntimeTemplateDataPersistentDiskSpec {
    /**
    * The disk size of the runtime in GB. If specified, the diskType must also be specified. The minimum size is 10GB and the maximum is 65536GB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#disk_size_gb ColabRuntimeTemplate#disk_size_gb}
    */
    readonly diskSizeGb?: string;
    /**
    * The type of the persistent disk.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#disk_type ColabRuntimeTemplate#disk_type}
    */
    readonly diskType?: string;
}
export declare function colabRuntimeTemplateDataPersistentDiskSpecToTerraform(struct?: ColabRuntimeTemplateDataPersistentDiskSpecOutputReference | ColabRuntimeTemplateDataPersistentDiskSpec): any;
export declare function colabRuntimeTemplateDataPersistentDiskSpecToHclTerraform(struct?: ColabRuntimeTemplateDataPersistentDiskSpecOutputReference | ColabRuntimeTemplateDataPersistentDiskSpec): any;
export declare class ColabRuntimeTemplateDataPersistentDiskSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabRuntimeTemplateDataPersistentDiskSpec | undefined;
    set internalValue(value: ColabRuntimeTemplateDataPersistentDiskSpec | undefined);
    private _diskSizeGb?;
    get diskSizeGb(): string;
    set diskSizeGb(value: string);
    resetDiskSizeGb(): void;
    get diskSizeGbInput(): string | undefined;
    private _diskType?;
    get diskType(): string;
    set diskType(value: string);
    resetDiskType(): void;
    get diskTypeInput(): string | undefined;
}
export interface ColabRuntimeTemplateEncryptionSpec {
    /**
    * The Cloud KMS encryption key (customer-managed encryption key) used to protect the runtime.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#kms_key_name ColabRuntimeTemplate#kms_key_name}
    */
    readonly kmsKeyName?: string;
}
export declare function colabRuntimeTemplateEncryptionSpecToTerraform(struct?: ColabRuntimeTemplateEncryptionSpecOutputReference | ColabRuntimeTemplateEncryptionSpec): any;
export declare function colabRuntimeTemplateEncryptionSpecToHclTerraform(struct?: ColabRuntimeTemplateEncryptionSpecOutputReference | ColabRuntimeTemplateEncryptionSpec): any;
export declare class ColabRuntimeTemplateEncryptionSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabRuntimeTemplateEncryptionSpec | undefined;
    set internalValue(value: ColabRuntimeTemplateEncryptionSpec | undefined);
    private _kmsKeyName?;
    get kmsKeyName(): string;
    set kmsKeyName(value: string);
    resetKmsKeyName(): void;
    get kmsKeyNameInput(): string | undefined;
}
export interface ColabRuntimeTemplateEucConfig {
    /**
    * Disable end user credential access for the runtime.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#euc_disabled ColabRuntimeTemplate#euc_disabled}
    */
    readonly eucDisabled?: boolean | cdktn.IResolvable;
}
export declare function colabRuntimeTemplateEucConfigToTerraform(struct?: ColabRuntimeTemplateEucConfigOutputReference | ColabRuntimeTemplateEucConfig): any;
export declare function colabRuntimeTemplateEucConfigToHclTerraform(struct?: ColabRuntimeTemplateEucConfigOutputReference | ColabRuntimeTemplateEucConfig): any;
export declare class ColabRuntimeTemplateEucConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabRuntimeTemplateEucConfig | undefined;
    set internalValue(value: ColabRuntimeTemplateEucConfig | undefined);
    private _eucDisabled?;
    get eucDisabled(): boolean | cdktn.IResolvable;
    set eucDisabled(value: boolean | cdktn.IResolvable);
    resetEucDisabled(): void;
    get eucDisabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ColabRuntimeTemplateIdleShutdownConfig {
    /**
    * The duration after which the runtime is automatically shut down. An input of 0s disables the idle shutdown feature, and a valid range is [10m, 24h].
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#idle_timeout ColabRuntimeTemplate#idle_timeout}
    */
    readonly idleTimeout?: string;
}
export declare function colabRuntimeTemplateIdleShutdownConfigToTerraform(struct?: ColabRuntimeTemplateIdleShutdownConfigOutputReference | ColabRuntimeTemplateIdleShutdownConfig): any;
export declare function colabRuntimeTemplateIdleShutdownConfigToHclTerraform(struct?: ColabRuntimeTemplateIdleShutdownConfigOutputReference | ColabRuntimeTemplateIdleShutdownConfig): any;
export declare class ColabRuntimeTemplateIdleShutdownConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabRuntimeTemplateIdleShutdownConfig | undefined;
    set internalValue(value: ColabRuntimeTemplateIdleShutdownConfig | undefined);
    private _idleTimeout?;
    get idleTimeout(): string;
    set idleTimeout(value: string);
    resetIdleTimeout(): void;
    get idleTimeoutInput(): string | undefined;
}
export interface ColabRuntimeTemplateMachineSpec {
    /**
    * The number of accelerators used by the runtime.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#accelerator_count ColabRuntimeTemplate#accelerator_count}
    */
    readonly acceleratorCount?: number;
    /**
    * The type of hardware accelerator used by the runtime. If specified, acceleratorCount must also be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#accelerator_type ColabRuntimeTemplate#accelerator_type}
    */
    readonly acceleratorType?: string;
    /**
    * The Compute Engine machine type selected for the runtime.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#machine_type ColabRuntimeTemplate#machine_type}
    */
    readonly machineType?: string;
}
export declare function colabRuntimeTemplateMachineSpecToTerraform(struct?: ColabRuntimeTemplateMachineSpecOutputReference | ColabRuntimeTemplateMachineSpec): any;
export declare function colabRuntimeTemplateMachineSpecToHclTerraform(struct?: ColabRuntimeTemplateMachineSpecOutputReference | ColabRuntimeTemplateMachineSpec): any;
export declare class ColabRuntimeTemplateMachineSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabRuntimeTemplateMachineSpec | undefined;
    set internalValue(value: ColabRuntimeTemplateMachineSpec | undefined);
    private _acceleratorCount?;
    get acceleratorCount(): number;
    set acceleratorCount(value: number);
    resetAcceleratorCount(): void;
    get acceleratorCountInput(): number | undefined;
    private _acceleratorType?;
    get acceleratorType(): string;
    set acceleratorType(value: string);
    resetAcceleratorType(): void;
    get acceleratorTypeInput(): string | undefined;
    private _machineType?;
    get machineType(): string;
    set machineType(value: string);
    resetMachineType(): void;
    get machineTypeInput(): string | undefined;
}
export interface ColabRuntimeTemplateNetworkSpec {
    /**
    * Enable public internet access for the runtime.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#enable_internet_access ColabRuntimeTemplate#enable_internet_access}
    */
    readonly enableInternetAccess?: boolean | cdktn.IResolvable;
    /**
    * The name of the VPC that this runtime is in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#network ColabRuntimeTemplate#network}
    */
    readonly network?: string;
    /**
    * The name of the subnetwork that this runtime is in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#subnetwork ColabRuntimeTemplate#subnetwork}
    */
    readonly subnetwork?: string;
}
export declare function colabRuntimeTemplateNetworkSpecToTerraform(struct?: ColabRuntimeTemplateNetworkSpecOutputReference | ColabRuntimeTemplateNetworkSpec): any;
export declare function colabRuntimeTemplateNetworkSpecToHclTerraform(struct?: ColabRuntimeTemplateNetworkSpecOutputReference | ColabRuntimeTemplateNetworkSpec): any;
export declare class ColabRuntimeTemplateNetworkSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabRuntimeTemplateNetworkSpec | undefined;
    set internalValue(value: ColabRuntimeTemplateNetworkSpec | undefined);
    private _enableInternetAccess?;
    get enableInternetAccess(): boolean | cdktn.IResolvable;
    set enableInternetAccess(value: boolean | cdktn.IResolvable);
    resetEnableInternetAccess(): void;
    get enableInternetAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _network?;
    get network(): string;
    set network(value: string);
    resetNetwork(): void;
    get networkInput(): string | undefined;
    private _subnetwork?;
    get subnetwork(): string;
    set subnetwork(value: string);
    resetSubnetwork(): void;
    get subnetworkInput(): string | undefined;
}
export interface ColabRuntimeTemplateShieldedVmConfig {
    /**
    * Enables secure boot for the runtime.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#enable_secure_boot ColabRuntimeTemplate#enable_secure_boot}
    */
    readonly enableSecureBoot?: boolean | cdktn.IResolvable;
}
export declare function colabRuntimeTemplateShieldedVmConfigToTerraform(struct?: ColabRuntimeTemplateShieldedVmConfigOutputReference | ColabRuntimeTemplateShieldedVmConfig): any;
export declare function colabRuntimeTemplateShieldedVmConfigToHclTerraform(struct?: ColabRuntimeTemplateShieldedVmConfigOutputReference | ColabRuntimeTemplateShieldedVmConfig): any;
export declare class ColabRuntimeTemplateShieldedVmConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabRuntimeTemplateShieldedVmConfig | undefined;
    set internalValue(value: ColabRuntimeTemplateShieldedVmConfig | undefined);
    private _enableSecureBoot?;
    get enableSecureBoot(): boolean | cdktn.IResolvable;
    set enableSecureBoot(value: boolean | cdktn.IResolvable);
    resetEnableSecureBoot(): void;
    get enableSecureBootInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ColabRuntimeTemplateSoftwareConfigColabImage {
    /**
    * The release name of the NotebookRuntime Colab image, e.g. "py310". If not specified, detault to the latest release.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#release_name ColabRuntimeTemplate#release_name}
    */
    readonly releaseName?: string;
}
export declare function colabRuntimeTemplateSoftwareConfigColabImageToTerraform(struct?: ColabRuntimeTemplateSoftwareConfigColabImageOutputReference | ColabRuntimeTemplateSoftwareConfigColabImage): any;
export declare function colabRuntimeTemplateSoftwareConfigColabImageToHclTerraform(struct?: ColabRuntimeTemplateSoftwareConfigColabImageOutputReference | ColabRuntimeTemplateSoftwareConfigColabImage): any;
export declare class ColabRuntimeTemplateSoftwareConfigColabImageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabRuntimeTemplateSoftwareConfigColabImage | undefined;
    set internalValue(value: ColabRuntimeTemplateSoftwareConfigColabImage | undefined);
    private _releaseName?;
    get releaseName(): string;
    set releaseName(value: string);
    resetReleaseName(): void;
    get releaseNameInput(): string | undefined;
}
export interface ColabRuntimeTemplateSoftwareConfigEnv {
    /**
    * Name of the environment variable. Must be a valid C identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#name ColabRuntimeTemplate#name}
    */
    readonly name?: string;
    /**
    * Variables that reference a $(VAR_NAME) are expanded using the previous defined environment variables in the container and any service environment variables. If a variable cannot be resolved, the reference in the input string will be unchanged. The $(VAR_NAME) syntax can be escaped with a double $$, ie: $$(VAR_NAME). Escaped references will never be expanded, regardless of whether the variable exists or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#value ColabRuntimeTemplate#value}
    */
    readonly value?: string;
}
export declare function colabRuntimeTemplateSoftwareConfigEnvToTerraform(struct?: ColabRuntimeTemplateSoftwareConfigEnv | cdktn.IResolvable): any;
export declare function colabRuntimeTemplateSoftwareConfigEnvToHclTerraform(struct?: ColabRuntimeTemplateSoftwareConfigEnv | cdktn.IResolvable): any;
export declare class ColabRuntimeTemplateSoftwareConfigEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ColabRuntimeTemplateSoftwareConfigEnv | cdktn.IResolvable | undefined;
    set internalValue(value: ColabRuntimeTemplateSoftwareConfigEnv | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ColabRuntimeTemplateSoftwareConfigEnvList extends cdktn.ComplexList {
    internalValue?: ColabRuntimeTemplateSoftwareConfigEnv[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ColabRuntimeTemplateSoftwareConfigEnvOutputReference;
}
export interface ColabRuntimeTemplateSoftwareConfigPostStartupScriptConfig {
    /**
    * Post startup script to run after runtime is started.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#post_startup_script ColabRuntimeTemplate#post_startup_script}
    */
    readonly postStartupScript?: string;
    /**
    * Post startup script behavior that defines download and execution behavior. Possible values: ["RUN_ONCE", "RUN_EVERY_START", "DOWNLOAD_AND_RUN_EVERY_START"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#post_startup_script_behavior ColabRuntimeTemplate#post_startup_script_behavior}
    */
    readonly postStartupScriptBehavior?: string;
    /**
    * Post startup script url to download. Example: https://bucket/script.sh.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#post_startup_script_url ColabRuntimeTemplate#post_startup_script_url}
    */
    readonly postStartupScriptUrl?: string;
}
export declare function colabRuntimeTemplateSoftwareConfigPostStartupScriptConfigToTerraform(struct?: ColabRuntimeTemplateSoftwareConfigPostStartupScriptConfigOutputReference | ColabRuntimeTemplateSoftwareConfigPostStartupScriptConfig): any;
export declare function colabRuntimeTemplateSoftwareConfigPostStartupScriptConfigToHclTerraform(struct?: ColabRuntimeTemplateSoftwareConfigPostStartupScriptConfigOutputReference | ColabRuntimeTemplateSoftwareConfigPostStartupScriptConfig): any;
export declare class ColabRuntimeTemplateSoftwareConfigPostStartupScriptConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabRuntimeTemplateSoftwareConfigPostStartupScriptConfig | undefined;
    set internalValue(value: ColabRuntimeTemplateSoftwareConfigPostStartupScriptConfig | undefined);
    private _postStartupScript?;
    get postStartupScript(): string;
    set postStartupScript(value: string);
    resetPostStartupScript(): void;
    get postStartupScriptInput(): string | undefined;
    private _postStartupScriptBehavior?;
    get postStartupScriptBehavior(): string;
    set postStartupScriptBehavior(value: string);
    resetPostStartupScriptBehavior(): void;
    get postStartupScriptBehaviorInput(): string | undefined;
    private _postStartupScriptUrl?;
    get postStartupScriptUrl(): string;
    set postStartupScriptUrl(value: string);
    resetPostStartupScriptUrl(): void;
    get postStartupScriptUrlInput(): string | undefined;
}
export interface ColabRuntimeTemplateSoftwareConfig {
    /**
    * colab_image block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#colab_image ColabRuntimeTemplate#colab_image}
    */
    readonly colabImage?: ColabRuntimeTemplateSoftwareConfigColabImage;
    /**
    * env block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#env ColabRuntimeTemplate#env}
    */
    readonly env?: ColabRuntimeTemplateSoftwareConfigEnv[] | cdktn.IResolvable;
    /**
    * post_startup_script_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#post_startup_script_config ColabRuntimeTemplate#post_startup_script_config}
    */
    readonly postStartupScriptConfig?: ColabRuntimeTemplateSoftwareConfigPostStartupScriptConfig;
}
export declare function colabRuntimeTemplateSoftwareConfigToTerraform(struct?: ColabRuntimeTemplateSoftwareConfigOutputReference | ColabRuntimeTemplateSoftwareConfig): any;
export declare function colabRuntimeTemplateSoftwareConfigToHclTerraform(struct?: ColabRuntimeTemplateSoftwareConfigOutputReference | ColabRuntimeTemplateSoftwareConfig): any;
export declare class ColabRuntimeTemplateSoftwareConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabRuntimeTemplateSoftwareConfig | undefined;
    set internalValue(value: ColabRuntimeTemplateSoftwareConfig | undefined);
    private _colabImage;
    get colabImage(): ColabRuntimeTemplateSoftwareConfigColabImageOutputReference;
    putColabImage(value: ColabRuntimeTemplateSoftwareConfigColabImage): void;
    resetColabImage(): void;
    get colabImageInput(): ColabRuntimeTemplateSoftwareConfigColabImage | undefined;
    private _env;
    get env(): ColabRuntimeTemplateSoftwareConfigEnvList;
    putEnv(value: ColabRuntimeTemplateSoftwareConfigEnv[] | cdktn.IResolvable): void;
    resetEnv(): void;
    get envInput(): cdktn.IResolvable | ColabRuntimeTemplateSoftwareConfigEnv[] | undefined;
    private _postStartupScriptConfig;
    get postStartupScriptConfig(): ColabRuntimeTemplateSoftwareConfigPostStartupScriptConfigOutputReference;
    putPostStartupScriptConfig(value: ColabRuntimeTemplateSoftwareConfigPostStartupScriptConfig): void;
    resetPostStartupScriptConfig(): void;
    get postStartupScriptConfigInput(): ColabRuntimeTemplateSoftwareConfigPostStartupScriptConfig | undefined;
}
export interface ColabRuntimeTemplateTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#create ColabRuntimeTemplate#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#delete ColabRuntimeTemplate#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#update ColabRuntimeTemplate#update}
    */
    readonly update?: string;
}
export declare function colabRuntimeTemplateTimeoutsToTerraform(struct?: ColabRuntimeTemplateTimeouts | cdktn.IResolvable): any;
export declare function colabRuntimeTemplateTimeoutsToHclTerraform(struct?: ColabRuntimeTemplateTimeouts | cdktn.IResolvable): any;
export declare class ColabRuntimeTemplateTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabRuntimeTemplateTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ColabRuntimeTemplateTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template google_colab_runtime_template}
*/
export declare class ColabRuntimeTemplate extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_colab_runtime_template";
    /**
    * Generates CDKTN code for importing a ColabRuntimeTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ColabRuntimeTemplate to import
    * @param importFromId The id of the existing ColabRuntimeTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ColabRuntimeTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/colab_runtime_template google_colab_runtime_template} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ColabRuntimeTemplateConfig
    */
    constructor(scope: Construct, id: string, config: ColabRuntimeTemplateConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _networkTags?;
    get networkTags(): string[];
    set networkTags(value: string[]);
    resetNetworkTags(): void;
    get networkTagsInput(): string[] | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _dataPersistentDiskSpec;
    get dataPersistentDiskSpec(): ColabRuntimeTemplateDataPersistentDiskSpecOutputReference;
    putDataPersistentDiskSpec(value: ColabRuntimeTemplateDataPersistentDiskSpec): void;
    resetDataPersistentDiskSpec(): void;
    get dataPersistentDiskSpecInput(): ColabRuntimeTemplateDataPersistentDiskSpec | undefined;
    private _encryptionSpec;
    get encryptionSpec(): ColabRuntimeTemplateEncryptionSpecOutputReference;
    putEncryptionSpec(value: ColabRuntimeTemplateEncryptionSpec): void;
    resetEncryptionSpec(): void;
    get encryptionSpecInput(): ColabRuntimeTemplateEncryptionSpec | undefined;
    private _eucConfig;
    get eucConfig(): ColabRuntimeTemplateEucConfigOutputReference;
    putEucConfig(value: ColabRuntimeTemplateEucConfig): void;
    resetEucConfig(): void;
    get eucConfigInput(): ColabRuntimeTemplateEucConfig | undefined;
    private _idleShutdownConfig;
    get idleShutdownConfig(): ColabRuntimeTemplateIdleShutdownConfigOutputReference;
    putIdleShutdownConfig(value: ColabRuntimeTemplateIdleShutdownConfig): void;
    resetIdleShutdownConfig(): void;
    get idleShutdownConfigInput(): ColabRuntimeTemplateIdleShutdownConfig | undefined;
    private _machineSpec;
    get machineSpec(): ColabRuntimeTemplateMachineSpecOutputReference;
    putMachineSpec(value: ColabRuntimeTemplateMachineSpec): void;
    resetMachineSpec(): void;
    get machineSpecInput(): ColabRuntimeTemplateMachineSpec | undefined;
    private _networkSpec;
    get networkSpec(): ColabRuntimeTemplateNetworkSpecOutputReference;
    putNetworkSpec(value: ColabRuntimeTemplateNetworkSpec): void;
    resetNetworkSpec(): void;
    get networkSpecInput(): ColabRuntimeTemplateNetworkSpec | undefined;
    private _shieldedVmConfig;
    get shieldedVmConfig(): ColabRuntimeTemplateShieldedVmConfigOutputReference;
    putShieldedVmConfig(value: ColabRuntimeTemplateShieldedVmConfig): void;
    resetShieldedVmConfig(): void;
    get shieldedVmConfigInput(): ColabRuntimeTemplateShieldedVmConfig | undefined;
    private _softwareConfig;
    get softwareConfig(): ColabRuntimeTemplateSoftwareConfigOutputReference;
    putSoftwareConfig(value: ColabRuntimeTemplateSoftwareConfig): void;
    resetSoftwareConfig(): void;
    get softwareConfigInput(): ColabRuntimeTemplateSoftwareConfig | undefined;
    private _timeouts;
    get timeouts(): ColabRuntimeTemplateTimeoutsOutputReference;
    putTimeouts(value: ColabRuntimeTemplateTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ColabRuntimeTemplateTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
