/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BiglakeIcebergNamespaceIamBindingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_namespace_iam_binding#catalog BiglakeIcebergNamespaceIamBinding#catalog}
    */
    readonly catalog: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_namespace_iam_binding#id BiglakeIcebergNamespaceIamBinding#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_namespace_iam_binding#members BiglakeIcebergNamespaceIamBinding#members}
    */
    readonly members: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_namespace_iam_binding#namespace_id BiglakeIcebergNamespaceIamBinding#namespace_id}
    */
    readonly namespaceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_namespace_iam_binding#project BiglakeIcebergNamespaceIamBinding#project}
    */
    readonly project?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_namespace_iam_binding#role BiglakeIcebergNamespaceIamBinding#role}
    */
    readonly role: string;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_namespace_iam_binding#condition BiglakeIcebergNamespaceIamBinding#condition}
    */
    readonly condition?: BiglakeIcebergNamespaceIamBindingCondition;
}
export interface BiglakeIcebergNamespaceIamBindingCondition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_namespace_iam_binding#description BiglakeIcebergNamespaceIamBinding#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_namespace_iam_binding#expression BiglakeIcebergNamespaceIamBinding#expression}
    */
    readonly expression: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_namespace_iam_binding#title BiglakeIcebergNamespaceIamBinding#title}
    */
    readonly title: string;
}
export declare function biglakeIcebergNamespaceIamBindingConditionToTerraform(struct?: BiglakeIcebergNamespaceIamBindingConditionOutputReference | BiglakeIcebergNamespaceIamBindingCondition): any;
export declare function biglakeIcebergNamespaceIamBindingConditionToHclTerraform(struct?: BiglakeIcebergNamespaceIamBindingConditionOutputReference | BiglakeIcebergNamespaceIamBindingCondition): any;
export declare class BiglakeIcebergNamespaceIamBindingConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BiglakeIcebergNamespaceIamBindingCondition | undefined;
    set internalValue(value: BiglakeIcebergNamespaceIamBindingCondition | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_namespace_iam_binding google_biglake_iceberg_namespace_iam_binding}
*/
export declare class BiglakeIcebergNamespaceIamBinding extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_biglake_iceberg_namespace_iam_binding";
    /**
    * Generates CDKTN code for importing a BiglakeIcebergNamespaceIamBinding resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BiglakeIcebergNamespaceIamBinding to import
    * @param importFromId The id of the existing BiglakeIcebergNamespaceIamBinding that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_namespace_iam_binding#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BiglakeIcebergNamespaceIamBinding to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_iceberg_namespace_iam_binding google_biglake_iceberg_namespace_iam_binding} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BiglakeIcebergNamespaceIamBindingConfig
    */
    constructor(scope: Construct, id: string, config: BiglakeIcebergNamespaceIamBindingConfig);
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    get catalogInput(): string | undefined;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _members?;
    get members(): string[];
    set members(value: string[]);
    get membersInput(): string[] | undefined;
    private _namespaceId?;
    get namespaceId(): string;
    set namespaceId(value: string);
    get namespaceIdInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _condition;
    get condition(): BiglakeIcebergNamespaceIamBindingConditionOutputReference;
    putCondition(value: BiglakeIcebergNamespaceIamBindingCondition): void;
    resetCondition(): void;
    get conditionInput(): BiglakeIcebergNamespaceIamBindingCondition | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
