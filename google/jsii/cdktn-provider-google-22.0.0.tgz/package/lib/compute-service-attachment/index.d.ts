/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeServiceAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * The connection preference to use for this service attachment. Valid
    * values include "ACCEPT_AUTOMATIC", "ACCEPT_MANUAL".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment#connection_preference ComputeServiceAttachment#connection_preference}
    */
    readonly connectionPreference: string;
    /**
    * An array of projects that are not allowed to connect to this service
    * attachment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment#consumer_reject_lists ComputeServiceAttachment#consumer_reject_lists}
    */
    readonly consumerRejectLists?: string[];
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment#deletion_policy ComputeServiceAttachment#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment#description ComputeServiceAttachment#description}
    */
    readonly description?: string;
    /**
    * If specified, the domain name will be used during the integration between
    * the PSC connected endpoints and the Cloud DNS. For example, this is a
    * valid domain name: "p.mycompany.com.". Current max number of domain names
    * supported is 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment#domain_names ComputeServiceAttachment#domain_names}
    */
    readonly domainNames?: string[];
    /**
    * If true, enable the proxy protocol which is for supplying client TCP/IP
    * address data in TCP connections that traverse proxies on their way to
    * destination servers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment#enable_proxy_protocol ComputeServiceAttachment#enable_proxy_protocol}
    */
    readonly enableProxyProtocol: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment#id ComputeServiceAttachment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the resource. The name must be 1-63 characters long, and
    * comply with RFC1035. Specifically, the name must be 1-63 characters
    * long and match the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?'
    * which means the first character must be a lowercase letter, and all
    * following characters must be a dash, lowercase letter, or digit,
    * except the last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment#name ComputeServiceAttachment#name}
    */
    readonly name: string;
    /**
    * The number of NAT IPs allocated per connected endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment#nat_ips_per_endpoint ComputeServiceAttachment#nat_ips_per_endpoint}
    */
    readonly natIpsPerEndpoint?: number;
    /**
    * An array of subnets that is provided for NAT in this service attachment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment#nat_subnets ComputeServiceAttachment#nat_subnets}
    */
    readonly natSubnets: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment#project ComputeServiceAttachment#project}
    */
    readonly project?: string;
    /**
    * The number of consumer spokes that connected Private Service Connect endpoints can be propagated to through Network Connectivity Center.
    * This limit lets the service producer limit how many propagated Private Service Connect connections can be established to this service attachment from a single consumer.
    *
    * If the connection preference of the service attachment is ACCEPT_MANUAL, the limit applies to each project or network that is listed in the consumer accept list.
    * If the connection preference of the service attachment is ACCEPT_AUTOMATIC, the limit applies to each project that contains a connected endpoint.
    *
    * If unspecified, the default propagated connection limit is 250. To explicitly send a zero value, set 'send_propagated_connection_limit_if_zero = true'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment#propagated_connection_limit ComputeServiceAttachment#propagated_connection_limit}
    */
    readonly propagatedConnectionLimit?: number;
    /**
    * This flag determines whether a consumer accept/reject list change can reconcile the statuses of existing ACCEPTED or REJECTED PSC endpoints.
    *
    * If false, connection policy update will only affect existing PENDING PSC endpoints. Existing ACCEPTED/REJECTED endpoints will remain untouched regardless how the connection policy is modified .
    * If true, update will affect both PENDING and ACCEPTED/REJECTED PSC endpoints. For example, an ACCEPTED PSC endpoint will be moved to REJECTED if its project is added to the reject list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment#reconcile_connections ComputeServiceAttachment#reconcile_connections}
    */
    readonly reconcileConnections?: boolean | cdktn.IResolvable;
    /**
    * URL of the region where the resource resides.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment#region ComputeServiceAttachment#region}
    */
    readonly region?: string;
    /**
    * Controls the behavior of propagated_connection_limit.
    * When false, setting propagated_connection_limit to zero causes the provider to use to the API's default value.
    * When true, the provider will set propagated_connection_limit to zero.
    * Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment#send_propagated_connection_limit_if_zero ComputeServiceAttachment#send_propagated_connection_limit_if_zero}
    */
    readonly sendPropagatedConnectionLimitIfZero?: boolean | cdktn.IResolvable;
    /**
    * NOTE: This field is temporarily non-functional due to an underlying API issue.
    * Any value provided here will be ignored until the API issue is resolved, expected around 2026-03.
    * [If true, show NAT IPs of all connected endpoints.]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment#show_nat_ips ComputeServiceAttachment#show_nat_ips}
    */
    readonly showNatIps?: boolean | cdktn.IResolvable;
    /**
    * The URL of a service serving the endpoint identified by this service attachment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment#target_service ComputeServiceAttachment#target_service}
    */
    readonly targetService: string;
    /**
    * consumer_accept_lists block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment#consumer_accept_lists ComputeServiceAttachment#consumer_accept_lists}
    */
    readonly consumerAcceptLists?: ComputeServiceAttachmentConsumerAcceptLists[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment#timeouts ComputeServiceAttachment#timeouts}
    */
    readonly timeouts?: ComputeServiceAttachmentTimeouts;
}
export interface ComputeServiceAttachmentConnectedEndpoints {
}
export declare function computeServiceAttachmentConnectedEndpointsToTerraform(struct?: ComputeServiceAttachmentConnectedEndpoints): any;
export declare function computeServiceAttachmentConnectedEndpointsToHclTerraform(struct?: ComputeServiceAttachmentConnectedEndpoints): any;
export declare class ComputeServiceAttachmentConnectedEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeServiceAttachmentConnectedEndpoints | undefined;
    set internalValue(value: ComputeServiceAttachmentConnectedEndpoints | undefined);
    get consumerNetwork(): string;
    get endpoint(): string;
    get natIps(): string[];
    get propagatedConnectionCount(): number;
    get pscConnectionId(): string;
    get status(): string;
}
export declare class ComputeServiceAttachmentConnectedEndpointsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeServiceAttachmentConnectedEndpointsOutputReference;
}
export interface ComputeServiceAttachmentPscServiceAttachmentId {
}
export declare function computeServiceAttachmentPscServiceAttachmentIdToTerraform(struct?: ComputeServiceAttachmentPscServiceAttachmentId): any;
export declare function computeServiceAttachmentPscServiceAttachmentIdToHclTerraform(struct?: ComputeServiceAttachmentPscServiceAttachmentId): any;
export declare class ComputeServiceAttachmentPscServiceAttachmentIdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeServiceAttachmentPscServiceAttachmentId | undefined;
    set internalValue(value: ComputeServiceAttachmentPscServiceAttachmentId | undefined);
    get high(): string;
    get low(): string;
}
export declare class ComputeServiceAttachmentPscServiceAttachmentIdList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeServiceAttachmentPscServiceAttachmentIdOutputReference;
}
export interface ComputeServiceAttachmentConsumerAcceptLists {
    /**
    * The number of consumer forwarding rules the consumer project can
    * create.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment#connection_limit ComputeServiceAttachment#connection_limit}
    */
    readonly connectionLimit: number;
    /**
    * The endpoint that is allowed to connect to this service attachment.
    * Only one of project_id_or_num, network_url and endpoint_url may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment#endpoint_url ComputeServiceAttachment#endpoint_url}
    */
    readonly endpointUrl?: string;
    /**
    * The network that is allowed to connect to this service attachment.
    * Only one of project_id_or_num and network_url may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment#network_url ComputeServiceAttachment#network_url}
    */
    readonly networkUrl?: string;
    /**
    * A project that is allowed to connect to this service attachment.
    * Only one of project_id_or_num and network_url may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment#project_id_or_num ComputeServiceAttachment#project_id_or_num}
    */
    readonly projectIdOrNum?: string;
}
export declare function computeServiceAttachmentConsumerAcceptListsToTerraform(struct?: ComputeServiceAttachmentConsumerAcceptLists | cdktn.IResolvable): any;
export declare function computeServiceAttachmentConsumerAcceptListsToHclTerraform(struct?: ComputeServiceAttachmentConsumerAcceptLists | cdktn.IResolvable): any;
export declare class ComputeServiceAttachmentConsumerAcceptListsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeServiceAttachmentConsumerAcceptLists | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeServiceAttachmentConsumerAcceptLists | cdktn.IResolvable | undefined);
    private _connectionLimit?;
    get connectionLimit(): number;
    set connectionLimit(value: number);
    get connectionLimitInput(): number | undefined;
    private _endpointUrl?;
    get endpointUrl(): string;
    set endpointUrl(value: string);
    resetEndpointUrl(): void;
    get endpointUrlInput(): string | undefined;
    private _networkUrl?;
    get networkUrl(): string;
    set networkUrl(value: string);
    resetNetworkUrl(): void;
    get networkUrlInput(): string | undefined;
    private _projectIdOrNum?;
    get projectIdOrNum(): string;
    set projectIdOrNum(value: string);
    resetProjectIdOrNum(): void;
    get projectIdOrNumInput(): string | undefined;
}
export declare class ComputeServiceAttachmentConsumerAcceptListsList extends cdktn.ComplexList {
    internalValue?: ComputeServiceAttachmentConsumerAcceptLists[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeServiceAttachmentConsumerAcceptListsOutputReference;
}
export interface ComputeServiceAttachmentTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment#create ComputeServiceAttachment#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment#delete ComputeServiceAttachment#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment#update ComputeServiceAttachment#update}
    */
    readonly update?: string;
}
export declare function computeServiceAttachmentTimeoutsToTerraform(struct?: ComputeServiceAttachmentTimeouts | cdktn.IResolvable): any;
export declare function computeServiceAttachmentTimeoutsToHclTerraform(struct?: ComputeServiceAttachmentTimeouts | cdktn.IResolvable): any;
export declare class ComputeServiceAttachmentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeServiceAttachmentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeServiceAttachmentTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment google_compute_service_attachment}
*/
export declare class ComputeServiceAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_service_attachment";
    /**
    * Generates CDKTN code for importing a ComputeServiceAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeServiceAttachment to import
    * @param importFromId The id of the existing ComputeServiceAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeServiceAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_service_attachment google_compute_service_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeServiceAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: ComputeServiceAttachmentConfig);
    private _connectedEndpoints;
    get connectedEndpoints(): ComputeServiceAttachmentConnectedEndpointsList;
    private _connectionPreference?;
    get connectionPreference(): string;
    set connectionPreference(value: string);
    get connectionPreferenceInput(): string | undefined;
    private _consumerRejectLists?;
    get consumerRejectLists(): string[];
    set consumerRejectLists(value: string[]);
    resetConsumerRejectLists(): void;
    get consumerRejectListsInput(): string[] | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _domainNames?;
    get domainNames(): string[];
    set domainNames(value: string[]);
    resetDomainNames(): void;
    get domainNamesInput(): string[] | undefined;
    private _enableProxyProtocol?;
    get enableProxyProtocol(): boolean | cdktn.IResolvable;
    set enableProxyProtocol(value: boolean | cdktn.IResolvable);
    get enableProxyProtocolInput(): boolean | cdktn.IResolvable | undefined;
    get fingerprint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _natIpsPerEndpoint?;
    get natIpsPerEndpoint(): number;
    set natIpsPerEndpoint(value: number);
    resetNatIpsPerEndpoint(): void;
    get natIpsPerEndpointInput(): number | undefined;
    private _natSubnets?;
    get natSubnets(): string[];
    set natSubnets(value: string[]);
    get natSubnetsInput(): string[] | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _propagatedConnectionLimit?;
    get propagatedConnectionLimit(): number;
    set propagatedConnectionLimit(value: number);
    resetPropagatedConnectionLimit(): void;
    get propagatedConnectionLimitInput(): number | undefined;
    private _pscServiceAttachmentId;
    get pscServiceAttachmentId(): ComputeServiceAttachmentPscServiceAttachmentIdList;
    private _reconcileConnections?;
    get reconcileConnections(): boolean | cdktn.IResolvable;
    set reconcileConnections(value: boolean | cdktn.IResolvable);
    resetReconcileConnections(): void;
    get reconcileConnectionsInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get selfLink(): string;
    private _sendPropagatedConnectionLimitIfZero?;
    get sendPropagatedConnectionLimitIfZero(): boolean | cdktn.IResolvable;
    set sendPropagatedConnectionLimitIfZero(value: boolean | cdktn.IResolvable);
    resetSendPropagatedConnectionLimitIfZero(): void;
    get sendPropagatedConnectionLimitIfZeroInput(): boolean | cdktn.IResolvable | undefined;
    get serviceAttachmentId(): number;
    private _showNatIps?;
    get showNatIps(): boolean | cdktn.IResolvable;
    set showNatIps(value: boolean | cdktn.IResolvable);
    resetShowNatIps(): void;
    get showNatIpsInput(): boolean | cdktn.IResolvable | undefined;
    private _targetService?;
    get targetService(): string;
    set targetService(value: string);
    get targetServiceInput(): string | undefined;
    private _consumerAcceptLists;
    get consumerAcceptLists(): ComputeServiceAttachmentConsumerAcceptListsList;
    putConsumerAcceptLists(value: ComputeServiceAttachmentConsumerAcceptLists[] | cdktn.IResolvable): void;
    resetConsumerAcceptLists(): void;
    get consumerAcceptListsInput(): cdktn.IResolvable | ComputeServiceAttachmentConsumerAcceptLists[] | undefined;
    private _timeouts;
    get timeouts(): ComputeServiceAttachmentTimeoutsOutputReference;
    putTimeouts(value: ComputeServiceAttachmentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeServiceAttachmentTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
