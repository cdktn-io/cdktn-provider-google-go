/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeRegionInstantSnapshotConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instant_snapshot#deletion_policy ComputeRegionInstantSnapshot#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instant_snapshot#description ComputeRegionInstantSnapshot#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instant_snapshot#id ComputeRegionInstantSnapshot#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Labels to apply to this InstantSnapshot.
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instant_snapshot#labels ComputeRegionInstantSnapshot#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the resource; provided by the client when the resource is
    * created. The name must be 1-63 characters long, and comply with
    * RFC1035. Specifically, the name must be 1-63 characters long and match
    * the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the
    * first character must be a lowercase letter, and all following
    * characters must be a dash, lowercase letter, or digit, except the last
    * character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instant_snapshot#name ComputeRegionInstantSnapshot#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instant_snapshot#project ComputeRegionInstantSnapshot#project}
    */
    readonly project?: string;
    /**
    * A reference to the region where the disk is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instant_snapshot#region ComputeRegionInstantSnapshot#region}
    */
    readonly region?: string;
    /**
    * The source disk used to create this instant snapshot. You can provide this as a partial or full URL to the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instant_snapshot#source_disk ComputeRegionInstantSnapshot#source_disk}
    */
    readonly sourceDisk: string;
    /**
    * params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instant_snapshot#params ComputeRegionInstantSnapshot#params}
    */
    readonly params?: ComputeRegionInstantSnapshotParams;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instant_snapshot#timeouts ComputeRegionInstantSnapshot#timeouts}
    */
    readonly timeouts?: ComputeRegionInstantSnapshotTimeouts;
}
export interface ComputeRegionInstantSnapshotResourceStatus {
}
export declare function computeRegionInstantSnapshotResourceStatusToTerraform(struct?: ComputeRegionInstantSnapshotResourceStatus): any;
export declare function computeRegionInstantSnapshotResourceStatusToHclTerraform(struct?: ComputeRegionInstantSnapshotResourceStatus): any;
export declare class ComputeRegionInstantSnapshotResourceStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionInstantSnapshotResourceStatus | undefined;
    set internalValue(value: ComputeRegionInstantSnapshotResourceStatus | undefined);
    get storageSizeBytes(): number;
}
export declare class ComputeRegionInstantSnapshotResourceStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionInstantSnapshotResourceStatusOutputReference;
}
export interface ComputeRegionInstantSnapshotParams {
    /**
    * Resource manager tags to be bound to the instant snapshot. Tag keys and values have the
    * same definition as resource manager tags. Keys must be in the format tagKeys/{tag_key_id},
    * and values are in the format tagValues/456.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instant_snapshot#resource_manager_tags ComputeRegionInstantSnapshot#resource_manager_tags}
    */
    readonly resourceManagerTags?: {
        [key: string]: string;
    };
}
export declare function computeRegionInstantSnapshotParamsToTerraform(struct?: ComputeRegionInstantSnapshotParamsOutputReference | ComputeRegionInstantSnapshotParams): any;
export declare function computeRegionInstantSnapshotParamsToHclTerraform(struct?: ComputeRegionInstantSnapshotParamsOutputReference | ComputeRegionInstantSnapshotParams): any;
export declare class ComputeRegionInstantSnapshotParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstantSnapshotParams | undefined;
    set internalValue(value: ComputeRegionInstantSnapshotParams | undefined);
    private _resourceManagerTags?;
    get resourceManagerTags(): {
        [key: string]: string;
    };
    set resourceManagerTags(value: {
        [key: string]: string;
    });
    resetResourceManagerTags(): void;
    get resourceManagerTagsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ComputeRegionInstantSnapshotTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instant_snapshot#create ComputeRegionInstantSnapshot#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instant_snapshot#delete ComputeRegionInstantSnapshot#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instant_snapshot#update ComputeRegionInstantSnapshot#update}
    */
    readonly update?: string;
}
export declare function computeRegionInstantSnapshotTimeoutsToTerraform(struct?: ComputeRegionInstantSnapshotTimeouts | cdktn.IResolvable): any;
export declare function computeRegionInstantSnapshotTimeoutsToHclTerraform(struct?: ComputeRegionInstantSnapshotTimeouts | cdktn.IResolvable): any;
export declare class ComputeRegionInstantSnapshotTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionInstantSnapshotTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionInstantSnapshotTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instant_snapshot google_compute_region_instant_snapshot}
*/
export declare class ComputeRegionInstantSnapshot extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_region_instant_snapshot";
    /**
    * Generates CDKTN code for importing a ComputeRegionInstantSnapshot resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeRegionInstantSnapshot to import
    * @param importFromId The id of the existing ComputeRegionInstantSnapshot that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instant_snapshot#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeRegionInstantSnapshot to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_instant_snapshot google_compute_region_instant_snapshot} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeRegionInstantSnapshotConfig
    */
    constructor(scope: Construct, id: string, config: ComputeRegionInstantSnapshotConfig);
    get architecture(): string;
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get diskSizeGb(): number;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get labelFingerprint(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceStatus;
    get resourceStatus(): ComputeRegionInstantSnapshotResourceStatusList;
    get selfLink(): string;
    private _sourceDisk?;
    get sourceDisk(): string;
    set sourceDisk(value: string);
    get sourceDiskInput(): string | undefined;
    get sourceDiskId(): string;
    get sourceInstantSnapshotGroup(): string;
    get sourceInstantSnapshotGroupId(): string;
    get status(): string;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _params;
    get params(): ComputeRegionInstantSnapshotParamsOutputReference;
    putParams(value: ComputeRegionInstantSnapshotParams): void;
    resetParams(): void;
    get paramsInput(): ComputeRegionInstantSnapshotParams | undefined;
    private _timeouts;
    get timeouts(): ComputeRegionInstantSnapshotTimeoutsOutputReference;
    putTimeouts(value: ComputeRegionInstantSnapshotTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeRegionInstantSnapshotTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
