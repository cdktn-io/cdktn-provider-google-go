/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BigqueryConnectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Optional connection id that should be assigned to the created connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#connection_id BigqueryConnection#connection_id}
    */
    readonly connectionId?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#deletion_policy BigqueryConnection#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * A descriptive description for the connection
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#description BigqueryConnection#description}
    */
    readonly description?: string;
    /**
    * A descriptive name for the connection
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#friendly_name BigqueryConnection#friendly_name}
    */
    readonly friendlyName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#id BigqueryConnection#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Optional. The Cloud KMS key that is used for encryption.
    *
    * Example: projects/[kms_project_id]/locations/[region]/keyRings/[key_region]/cryptoKeys/[key]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#kms_key_name BigqueryConnection#kms_key_name}
    */
    readonly kmsKeyName?: string;
    /**
    * The geographic location where the connection should reside.
    * Cloud SQL instance must be in the same location as the connection
    * with following exceptions: Cloud SQL us-central1 maps to BigQuery US, Cloud SQL europe-west1 maps to BigQuery EU.
    * Examples: US, EU, asia-northeast1, us-central1, europe-west1.
    * Spanner Connections same as spanner region
    * AWS allowed regions are aws-us-east-1
    * Azure allowed regions are azure-eastus2
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#location BigqueryConnection#location}
    */
    readonly location?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#project BigqueryConnection#project}
    */
    readonly project?: string;
    /**
    * aws block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#aws BigqueryConnection#aws}
    */
    readonly aws?: BigqueryConnectionAws;
    /**
    * azure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#azure BigqueryConnection#azure}
    */
    readonly azure?: BigqueryConnectionAzure;
    /**
    * cloud_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#cloud_resource BigqueryConnection#cloud_resource}
    */
    readonly cloudResource?: BigqueryConnectionCloudResource;
    /**
    * cloud_spanner block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#cloud_spanner BigqueryConnection#cloud_spanner}
    */
    readonly cloudSpanner?: BigqueryConnectionCloudSpanner;
    /**
    * cloud_sql block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#cloud_sql BigqueryConnection#cloud_sql}
    */
    readonly cloudSql?: BigqueryConnectionCloudSql;
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#configuration BigqueryConnection#configuration}
    */
    readonly configuration?: BigqueryConnectionConfiguration;
    /**
    * salesforce_data_cloud block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#salesforce_data_cloud BigqueryConnection#salesforce_data_cloud}
    */
    readonly salesforceDataCloud?: BigqueryConnectionSalesforceDataCloud;
    /**
    * spark block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#spark BigqueryConnection#spark}
    */
    readonly spark?: BigqueryConnectionSpark;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#timeouts BigqueryConnection#timeouts}
    */
    readonly timeouts?: BigqueryConnectionTimeouts;
}
export interface BigqueryConnectionAwsAccessRole {
    /**
    * The user’s AWS IAM Role that trusts the Google-owned AWS IAM user Connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#iam_role_id BigqueryConnection#iam_role_id}
    */
    readonly iamRoleId: string;
}
export declare function bigqueryConnectionAwsAccessRoleToTerraform(struct?: BigqueryConnectionAwsAccessRoleOutputReference | BigqueryConnectionAwsAccessRole): any;
export declare function bigqueryConnectionAwsAccessRoleToHclTerraform(struct?: BigqueryConnectionAwsAccessRoleOutputReference | BigqueryConnectionAwsAccessRole): any;
export declare class BigqueryConnectionAwsAccessRoleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryConnectionAwsAccessRole | undefined;
    set internalValue(value: BigqueryConnectionAwsAccessRole | undefined);
    private _iamRoleId?;
    get iamRoleId(): string;
    set iamRoleId(value: string);
    get iamRoleIdInput(): string | undefined;
    get identity(): string;
}
export interface BigqueryConnectionAws {
    /**
    * access_role block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#access_role BigqueryConnection#access_role}
    */
    readonly accessRole: BigqueryConnectionAwsAccessRole;
}
export declare function bigqueryConnectionAwsToTerraform(struct?: BigqueryConnectionAwsOutputReference | BigqueryConnectionAws): any;
export declare function bigqueryConnectionAwsToHclTerraform(struct?: BigqueryConnectionAwsOutputReference | BigqueryConnectionAws): any;
export declare class BigqueryConnectionAwsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryConnectionAws | undefined;
    set internalValue(value: BigqueryConnectionAws | undefined);
    private _accessRole;
    get accessRole(): BigqueryConnectionAwsAccessRoleOutputReference;
    putAccessRole(value: BigqueryConnectionAwsAccessRole): void;
    get accessRoleInput(): BigqueryConnectionAwsAccessRole | undefined;
}
export interface BigqueryConnectionAzure {
    /**
    * The id of customer's directory that host the data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#customer_tenant_id BigqueryConnection#customer_tenant_id}
    */
    readonly customerTenantId: string;
    /**
    * The Azure Application (client) ID where the federated credentials will be hosted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#federated_application_client_id BigqueryConnection#federated_application_client_id}
    */
    readonly federatedApplicationClientId?: string;
}
export declare function bigqueryConnectionAzureToTerraform(struct?: BigqueryConnectionAzureOutputReference | BigqueryConnectionAzure): any;
export declare function bigqueryConnectionAzureToHclTerraform(struct?: BigqueryConnectionAzureOutputReference | BigqueryConnectionAzure): any;
export declare class BigqueryConnectionAzureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryConnectionAzure | undefined;
    set internalValue(value: BigqueryConnectionAzure | undefined);
    get application(): string;
    get clientId(): string;
    private _customerTenantId?;
    get customerTenantId(): string;
    set customerTenantId(value: string);
    get customerTenantIdInput(): string | undefined;
    private _federatedApplicationClientId?;
    get federatedApplicationClientId(): string;
    set federatedApplicationClientId(value: string);
    resetFederatedApplicationClientId(): void;
    get federatedApplicationClientIdInput(): string | undefined;
    get identity(): string;
    get objectId(): string;
    get redirectUri(): string;
}
export interface BigqueryConnectionCloudResource {
}
export declare function bigqueryConnectionCloudResourceToTerraform(struct?: BigqueryConnectionCloudResourceOutputReference | BigqueryConnectionCloudResource): any;
export declare function bigqueryConnectionCloudResourceToHclTerraform(struct?: BigqueryConnectionCloudResourceOutputReference | BigqueryConnectionCloudResource): any;
export declare class BigqueryConnectionCloudResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryConnectionCloudResource | undefined;
    set internalValue(value: BigqueryConnectionCloudResource | undefined);
    get serviceAccountId(): string;
}
export interface BigqueryConnectionCloudSpanner {
    /**
    * Cloud Spanner database in the form 'project/instance/database'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#database BigqueryConnection#database}
    */
    readonly database: string;
    /**
    * Cloud Spanner database role for fine-grained access control. The Cloud Spanner admin should have provisioned the database role with appropriate permissions, such as 'SELECT' and 'INSERT'. Other users should only use roles provided by their Cloud Spanner admins. The database role name must start with a letter, and can only contain letters, numbers, and underscores. For more details, see https://cloud.google.com/spanner/docs/fgac-about.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#database_role BigqueryConnection#database_role}
    */
    readonly databaseRole?: string;
    /**
    * Allows setting max parallelism per query when executing on Spanner independent compute resources. If unspecified, default values of parallelism are chosen that are dependent on the Cloud Spanner instance configuration. 'useParallelism' and 'useDataBoost' must be set when setting max parallelism.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#max_parallelism BigqueryConnection#max_parallelism}
    */
    readonly maxParallelism?: number;
    /**
    * If set, the request will be executed via Spanner independent compute resources. 'use_parallelism' must be set when using data boost.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#use_data_boost BigqueryConnection#use_data_boost}
    */
    readonly useDataBoost?: boolean | cdktn.IResolvable;
    /**
    * If parallelism should be used when reading from Cloud Spanner.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#use_parallelism BigqueryConnection#use_parallelism}
    */
    readonly useParallelism?: boolean | cdktn.IResolvable;
    /**
    * If the serverless analytics service should be used to read data from Cloud Spanner. 'useParallelism' must be set when using serverless analytics.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#use_serverless_analytics BigqueryConnection#use_serverless_analytics}
    */
    readonly useServerlessAnalytics?: boolean | cdktn.IResolvable;
}
export declare function bigqueryConnectionCloudSpannerToTerraform(struct?: BigqueryConnectionCloudSpannerOutputReference | BigqueryConnectionCloudSpanner): any;
export declare function bigqueryConnectionCloudSpannerToHclTerraform(struct?: BigqueryConnectionCloudSpannerOutputReference | BigqueryConnectionCloudSpanner): any;
export declare class BigqueryConnectionCloudSpannerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryConnectionCloudSpanner | undefined;
    set internalValue(value: BigqueryConnectionCloudSpanner | undefined);
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _databaseRole?;
    get databaseRole(): string;
    set databaseRole(value: string);
    resetDatabaseRole(): void;
    get databaseRoleInput(): string | undefined;
    private _maxParallelism?;
    get maxParallelism(): number;
    set maxParallelism(value: number);
    resetMaxParallelism(): void;
    get maxParallelismInput(): number | undefined;
    private _useDataBoost?;
    get useDataBoost(): boolean | cdktn.IResolvable;
    set useDataBoost(value: boolean | cdktn.IResolvable);
    resetUseDataBoost(): void;
    get useDataBoostInput(): boolean | cdktn.IResolvable | undefined;
    private _useParallelism?;
    get useParallelism(): boolean | cdktn.IResolvable;
    set useParallelism(value: boolean | cdktn.IResolvable);
    resetUseParallelism(): void;
    get useParallelismInput(): boolean | cdktn.IResolvable | undefined;
    private _useServerlessAnalytics?;
    get useServerlessAnalytics(): boolean | cdktn.IResolvable;
    set useServerlessAnalytics(value: boolean | cdktn.IResolvable);
    resetUseServerlessAnalytics(): void;
    get useServerlessAnalyticsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface BigqueryConnectionCloudSqlCredential {
    /**
    * Password for database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#password BigqueryConnection#password}
    */
    readonly password?: string;
    /**
    * Password for database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#password_wo BigqueryConnection#password_wo}
    */
    readonly passwordWo?: string;
    /**
    * Triggers update of 'password_wo' write-only. Increment this value when an update to 'password_wo' is needed. For more info see [updating write-only arguments](/docs/providers/google/guides/using_write_only_arguments.html#updating-write-only-arguments)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#password_wo_version BigqueryConnection#password_wo_version}
    */
    readonly passwordWoVersion?: string;
    /**
    * Username for database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#username BigqueryConnection#username}
    */
    readonly username: string;
}
export declare function bigqueryConnectionCloudSqlCredentialToTerraform(struct?: BigqueryConnectionCloudSqlCredentialOutputReference | BigqueryConnectionCloudSqlCredential): any;
export declare function bigqueryConnectionCloudSqlCredentialToHclTerraform(struct?: BigqueryConnectionCloudSqlCredentialOutputReference | BigqueryConnectionCloudSqlCredential): any;
export declare class BigqueryConnectionCloudSqlCredentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryConnectionCloudSqlCredential | undefined;
    set internalValue(value: BigqueryConnectionCloudSqlCredential | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _passwordWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get passwordWo(): string;
    set passwordWo(value: string);
    resetPasswordWo(): void;
    get passwordWoInput(): string | undefined;
    private _passwordWoVersion?;
    get passwordWoVersion(): string;
    set passwordWoVersion(value: string);
    resetPasswordWoVersion(): void;
    get passwordWoVersionInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
}
export interface BigqueryConnectionCloudSql {
    /**
    * Database name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#database BigqueryConnection#database}
    */
    readonly database: string;
    /**
    * Cloud SQL instance ID in the form project:location:instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#instance_id BigqueryConnection#instance_id}
    */
    readonly instanceId: string;
    /**
    * Type of the Cloud SQL database. Possible values: ["DATABASE_TYPE_UNSPECIFIED", "POSTGRES", "MYSQL"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#type BigqueryConnection#type}
    */
    readonly type: string;
    /**
    * credential block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#credential BigqueryConnection#credential}
    */
    readonly credential: BigqueryConnectionCloudSqlCredential;
}
export declare function bigqueryConnectionCloudSqlToTerraform(struct?: BigqueryConnectionCloudSqlOutputReference | BigqueryConnectionCloudSql): any;
export declare function bigqueryConnectionCloudSqlToHclTerraform(struct?: BigqueryConnectionCloudSqlOutputReference | BigqueryConnectionCloudSql): any;
export declare class BigqueryConnectionCloudSqlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryConnectionCloudSql | undefined;
    set internalValue(value: BigqueryConnectionCloudSql | undefined);
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get serviceAccountId(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _credential;
    get credential(): BigqueryConnectionCloudSqlCredentialOutputReference;
    putCredential(value: BigqueryConnectionCloudSqlCredential): void;
    get credentialInput(): BigqueryConnectionCloudSqlCredential | undefined;
}
export interface BigqueryConnectionConfigurationAsset {
    /**
    * The name of the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#database BigqueryConnection#database}
    */
    readonly database?: string;
    /**
    * The full resource name of the Google Cloud resource.
    * For AlloyDB, this is in the format of
    * '//alloydb.googleapis.com/projects/{project}/locations/{region}/clusters/{cluster}/instances/{instance}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#google_cloud_resource BigqueryConnection#google_cloud_resource}
    */
    readonly googleCloudResource?: string;
}
export declare function bigqueryConnectionConfigurationAssetToTerraform(struct?: BigqueryConnectionConfigurationAssetOutputReference | BigqueryConnectionConfigurationAsset): any;
export declare function bigqueryConnectionConfigurationAssetToHclTerraform(struct?: BigqueryConnectionConfigurationAssetOutputReference | BigqueryConnectionConfigurationAsset): any;
export declare class BigqueryConnectionConfigurationAssetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryConnectionConfigurationAsset | undefined;
    set internalValue(value: BigqueryConnectionConfigurationAsset | undefined);
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _googleCloudResource?;
    get googleCloudResource(): string;
    set googleCloudResource(value: string);
    resetGoogleCloudResource(): void;
    get googleCloudResourceInput(): string | undefined;
}
export interface BigqueryConnectionConfigurationAuthenticationUsernamePasswordPassword {
    /**
    * The plaintext password.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#plaintext BigqueryConnection#plaintext}
    */
    readonly plaintext: string;
}
export declare function bigqueryConnectionConfigurationAuthenticationUsernamePasswordPasswordToTerraform(struct?: BigqueryConnectionConfigurationAuthenticationUsernamePasswordPasswordOutputReference | BigqueryConnectionConfigurationAuthenticationUsernamePasswordPassword): any;
export declare function bigqueryConnectionConfigurationAuthenticationUsernamePasswordPasswordToHclTerraform(struct?: BigqueryConnectionConfigurationAuthenticationUsernamePasswordPasswordOutputReference | BigqueryConnectionConfigurationAuthenticationUsernamePasswordPassword): any;
export declare class BigqueryConnectionConfigurationAuthenticationUsernamePasswordPasswordOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryConnectionConfigurationAuthenticationUsernamePasswordPassword | undefined;
    set internalValue(value: BigqueryConnectionConfigurationAuthenticationUsernamePasswordPassword | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    get plaintextInput(): string | undefined;
    get secretType(): string;
}
export interface BigqueryConnectionConfigurationAuthenticationUsernamePassword {
    /**
    * Username for the connector.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#username BigqueryConnection#username}
    */
    readonly username: string;
    /**
    * password block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#password BigqueryConnection#password}
    */
    readonly password: BigqueryConnectionConfigurationAuthenticationUsernamePasswordPassword;
}
export declare function bigqueryConnectionConfigurationAuthenticationUsernamePasswordToTerraform(struct?: BigqueryConnectionConfigurationAuthenticationUsernamePasswordOutputReference | BigqueryConnectionConfigurationAuthenticationUsernamePassword): any;
export declare function bigqueryConnectionConfigurationAuthenticationUsernamePasswordToHclTerraform(struct?: BigqueryConnectionConfigurationAuthenticationUsernamePasswordOutputReference | BigqueryConnectionConfigurationAuthenticationUsernamePassword): any;
export declare class BigqueryConnectionConfigurationAuthenticationUsernamePasswordOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryConnectionConfigurationAuthenticationUsernamePassword | undefined;
    set internalValue(value: BigqueryConnectionConfigurationAuthenticationUsernamePassword | undefined);
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
    private _password;
    get password(): BigqueryConnectionConfigurationAuthenticationUsernamePasswordPasswordOutputReference;
    putPassword(value: BigqueryConnectionConfigurationAuthenticationUsernamePasswordPassword): void;
    get passwordInput(): BigqueryConnectionConfigurationAuthenticationUsernamePasswordPassword | undefined;
}
export interface BigqueryConnectionConfigurationAuthentication {
    /**
    * username_password block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#username_password BigqueryConnection#username_password}
    */
    readonly usernamePassword?: BigqueryConnectionConfigurationAuthenticationUsernamePassword;
}
export declare function bigqueryConnectionConfigurationAuthenticationToTerraform(struct?: BigqueryConnectionConfigurationAuthenticationOutputReference | BigqueryConnectionConfigurationAuthentication): any;
export declare function bigqueryConnectionConfigurationAuthenticationToHclTerraform(struct?: BigqueryConnectionConfigurationAuthenticationOutputReference | BigqueryConnectionConfigurationAuthentication): any;
export declare class BigqueryConnectionConfigurationAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryConnectionConfigurationAuthentication | undefined;
    set internalValue(value: BigqueryConnectionConfigurationAuthentication | undefined);
    get serviceAccount(): string;
    private _usernamePassword;
    get usernamePassword(): BigqueryConnectionConfigurationAuthenticationUsernamePasswordOutputReference;
    putUsernamePassword(value: BigqueryConnectionConfigurationAuthenticationUsernamePassword): void;
    resetUsernamePassword(): void;
    get usernamePasswordInput(): BigqueryConnectionConfigurationAuthenticationUsernamePassword | undefined;
}
export interface BigqueryConnectionConfigurationEndpoint {
    /**
    * Host and port in the format of 'host:port' for the connector endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#host_port BigqueryConnection#host_port}
    */
    readonly hostPort?: string;
}
export declare function bigqueryConnectionConfigurationEndpointToTerraform(struct?: BigqueryConnectionConfigurationEndpointOutputReference | BigqueryConnectionConfigurationEndpoint): any;
export declare function bigqueryConnectionConfigurationEndpointToHclTerraform(struct?: BigqueryConnectionConfigurationEndpointOutputReference | BigqueryConnectionConfigurationEndpoint): any;
export declare class BigqueryConnectionConfigurationEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryConnectionConfigurationEndpoint | undefined;
    set internalValue(value: BigqueryConnectionConfigurationEndpoint | undefined);
    private _hostPort?;
    get hostPort(): string;
    set hostPort(value: string);
    resetHostPort(): void;
    get hostPortInput(): string | undefined;
}
export interface BigqueryConnectionConfigurationNetworkPrivateServiceConnect {
    /**
    * The resource name of a network attachment in the format of
    * 'projects/{project}/regions/{region}/networkAttachments/{networkAttachment}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#network_attachment BigqueryConnection#network_attachment}
    */
    readonly networkAttachment: string;
}
export declare function bigqueryConnectionConfigurationNetworkPrivateServiceConnectToTerraform(struct?: BigqueryConnectionConfigurationNetworkPrivateServiceConnectOutputReference | BigqueryConnectionConfigurationNetworkPrivateServiceConnect): any;
export declare function bigqueryConnectionConfigurationNetworkPrivateServiceConnectToHclTerraform(struct?: BigqueryConnectionConfigurationNetworkPrivateServiceConnectOutputReference | BigqueryConnectionConfigurationNetworkPrivateServiceConnect): any;
export declare class BigqueryConnectionConfigurationNetworkPrivateServiceConnectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryConnectionConfigurationNetworkPrivateServiceConnect | undefined;
    set internalValue(value: BigqueryConnectionConfigurationNetworkPrivateServiceConnect | undefined);
    private _networkAttachment?;
    get networkAttachment(): string;
    set networkAttachment(value: string);
    get networkAttachmentInput(): string | undefined;
}
export interface BigqueryConnectionConfigurationNetwork {
    /**
    * private_service_connect block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#private_service_connect BigqueryConnection#private_service_connect}
    */
    readonly privateServiceConnect?: BigqueryConnectionConfigurationNetworkPrivateServiceConnect;
}
export declare function bigqueryConnectionConfigurationNetworkToTerraform(struct?: BigqueryConnectionConfigurationNetworkOutputReference | BigqueryConnectionConfigurationNetwork): any;
export declare function bigqueryConnectionConfigurationNetworkToHclTerraform(struct?: BigqueryConnectionConfigurationNetworkOutputReference | BigqueryConnectionConfigurationNetwork): any;
export declare class BigqueryConnectionConfigurationNetworkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryConnectionConfigurationNetwork | undefined;
    set internalValue(value: BigqueryConnectionConfigurationNetwork | undefined);
    private _privateServiceConnect;
    get privateServiceConnect(): BigqueryConnectionConfigurationNetworkPrivateServiceConnectOutputReference;
    putPrivateServiceConnect(value: BigqueryConnectionConfigurationNetworkPrivateServiceConnect): void;
    resetPrivateServiceConnect(): void;
    get privateServiceConnectInput(): BigqueryConnectionConfigurationNetworkPrivateServiceConnect | undefined;
}
export interface BigqueryConnectionConfiguration {
    /**
    * The ID of the connector. Possible values include 'google-alloydb', 'google-cloudsql-mysql',
    * 'google-cloudsql-postgres', and other connector IDs supported by the BigQuery Connector framework.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#connector_id BigqueryConnection#connector_id}
    */
    readonly connectorId: string;
    /**
    * asset block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#asset BigqueryConnection#asset}
    */
    readonly asset: BigqueryConnectionConfigurationAsset;
    /**
    * authentication block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#authentication BigqueryConnection#authentication}
    */
    readonly authentication?: BigqueryConnectionConfigurationAuthentication;
    /**
    * endpoint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#endpoint BigqueryConnection#endpoint}
    */
    readonly endpoint?: BigqueryConnectionConfigurationEndpoint;
    /**
    * network block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#network BigqueryConnection#network}
    */
    readonly network?: BigqueryConnectionConfigurationNetwork;
}
export declare function bigqueryConnectionConfigurationToTerraform(struct?: BigqueryConnectionConfigurationOutputReference | BigqueryConnectionConfiguration): any;
export declare function bigqueryConnectionConfigurationToHclTerraform(struct?: BigqueryConnectionConfigurationOutputReference | BigqueryConnectionConfiguration): any;
export declare class BigqueryConnectionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryConnectionConfiguration | undefined;
    set internalValue(value: BigqueryConnectionConfiguration | undefined);
    private _connectorId?;
    get connectorId(): string;
    set connectorId(value: string);
    get connectorIdInput(): string | undefined;
    private _asset;
    get asset(): BigqueryConnectionConfigurationAssetOutputReference;
    putAsset(value: BigqueryConnectionConfigurationAsset): void;
    get assetInput(): BigqueryConnectionConfigurationAsset | undefined;
    private _authentication;
    get authentication(): BigqueryConnectionConfigurationAuthenticationOutputReference;
    putAuthentication(value: BigqueryConnectionConfigurationAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): BigqueryConnectionConfigurationAuthentication | undefined;
    private _endpoint;
    get endpoint(): BigqueryConnectionConfigurationEndpointOutputReference;
    putEndpoint(value: BigqueryConnectionConfigurationEndpoint): void;
    resetEndpoint(): void;
    get endpointInput(): BigqueryConnectionConfigurationEndpoint | undefined;
    private _network;
    get network(): BigqueryConnectionConfigurationNetworkOutputReference;
    putNetwork(value: BigqueryConnectionConfigurationNetwork): void;
    resetNetwork(): void;
    get networkInput(): BigqueryConnectionConfigurationNetwork | undefined;
}
export interface BigqueryConnectionSalesforceDataCloudCrossCloudCacheOptions {
    /**
    * Whether cross-cloud caching is enabled for queries through BigQuery.
    * When enabled, read data and metadata are cached, which can improve performance
    * and reduce network egress costs for cross-cloud queries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#enabled BigqueryConnection#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function bigqueryConnectionSalesforceDataCloudCrossCloudCacheOptionsToTerraform(struct?: BigqueryConnectionSalesforceDataCloudCrossCloudCacheOptionsOutputReference | BigqueryConnectionSalesforceDataCloudCrossCloudCacheOptions): any;
export declare function bigqueryConnectionSalesforceDataCloudCrossCloudCacheOptionsToHclTerraform(struct?: BigqueryConnectionSalesforceDataCloudCrossCloudCacheOptionsOutputReference | BigqueryConnectionSalesforceDataCloudCrossCloudCacheOptions): any;
export declare class BigqueryConnectionSalesforceDataCloudCrossCloudCacheOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryConnectionSalesforceDataCloudCrossCloudCacheOptions | undefined;
    set internalValue(value: BigqueryConnectionSalesforceDataCloudCrossCloudCacheOptions | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface BigqueryConnectionSalesforceDataCloud {
    /**
    * The URL to the user's Salesforce Data Cloud instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#instance_uri BigqueryConnection#instance_uri}
    */
    readonly instanceUri: string;
    /**
    * The ID of the user's Salesforce tenant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#tenant_id BigqueryConnection#tenant_id}
    */
    readonly tenantId: string;
    /**
    * cross_cloud_cache_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#cross_cloud_cache_options BigqueryConnection#cross_cloud_cache_options}
    */
    readonly crossCloudCacheOptions: BigqueryConnectionSalesforceDataCloudCrossCloudCacheOptions;
}
export declare function bigqueryConnectionSalesforceDataCloudToTerraform(struct?: BigqueryConnectionSalesforceDataCloudOutputReference | BigqueryConnectionSalesforceDataCloud): any;
export declare function bigqueryConnectionSalesforceDataCloudToHclTerraform(struct?: BigqueryConnectionSalesforceDataCloudOutputReference | BigqueryConnectionSalesforceDataCloud): any;
export declare class BigqueryConnectionSalesforceDataCloudOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryConnectionSalesforceDataCloud | undefined;
    set internalValue(value: BigqueryConnectionSalesforceDataCloud | undefined);
    get identity(): string;
    private _instanceUri?;
    get instanceUri(): string;
    set instanceUri(value: string);
    get instanceUriInput(): string | undefined;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    get tenantIdInput(): string | undefined;
    private _crossCloudCacheOptions;
    get crossCloudCacheOptions(): BigqueryConnectionSalesforceDataCloudCrossCloudCacheOptionsOutputReference;
    putCrossCloudCacheOptions(value: BigqueryConnectionSalesforceDataCloudCrossCloudCacheOptions): void;
    get crossCloudCacheOptionsInput(): BigqueryConnectionSalesforceDataCloudCrossCloudCacheOptions | undefined;
}
export interface BigqueryConnectionSparkMetastoreServiceConfig {
    /**
    * Resource name of an existing Dataproc Metastore service in the form of projects/[projectId]/locations/[region]/services/[serviceId].
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#metastore_service BigqueryConnection#metastore_service}
    */
    readonly metastoreService?: string;
}
export declare function bigqueryConnectionSparkMetastoreServiceConfigToTerraform(struct?: BigqueryConnectionSparkMetastoreServiceConfigOutputReference | BigqueryConnectionSparkMetastoreServiceConfig): any;
export declare function bigqueryConnectionSparkMetastoreServiceConfigToHclTerraform(struct?: BigqueryConnectionSparkMetastoreServiceConfigOutputReference | BigqueryConnectionSparkMetastoreServiceConfig): any;
export declare class BigqueryConnectionSparkMetastoreServiceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryConnectionSparkMetastoreServiceConfig | undefined;
    set internalValue(value: BigqueryConnectionSparkMetastoreServiceConfig | undefined);
    private _metastoreService?;
    get metastoreService(): string;
    set metastoreService(value: string);
    resetMetastoreService(): void;
    get metastoreServiceInput(): string | undefined;
}
export interface BigqueryConnectionSparkSparkHistoryServerConfig {
    /**
    * Resource name of an existing Dataproc Cluster to act as a Spark History Server for the connection if the form of projects/[projectId]/regions/[region]/clusters/[cluster_name].
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#dataproc_cluster BigqueryConnection#dataproc_cluster}
    */
    readonly dataprocCluster?: string;
}
export declare function bigqueryConnectionSparkSparkHistoryServerConfigToTerraform(struct?: BigqueryConnectionSparkSparkHistoryServerConfigOutputReference | BigqueryConnectionSparkSparkHistoryServerConfig): any;
export declare function bigqueryConnectionSparkSparkHistoryServerConfigToHclTerraform(struct?: BigqueryConnectionSparkSparkHistoryServerConfigOutputReference | BigqueryConnectionSparkSparkHistoryServerConfig): any;
export declare class BigqueryConnectionSparkSparkHistoryServerConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryConnectionSparkSparkHistoryServerConfig | undefined;
    set internalValue(value: BigqueryConnectionSparkSparkHistoryServerConfig | undefined);
    private _dataprocCluster?;
    get dataprocCluster(): string;
    set dataprocCluster(value: string);
    resetDataprocCluster(): void;
    get dataprocClusterInput(): string | undefined;
}
export interface BigqueryConnectionSpark {
    /**
    * metastore_service_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#metastore_service_config BigqueryConnection#metastore_service_config}
    */
    readonly metastoreServiceConfig?: BigqueryConnectionSparkMetastoreServiceConfig;
    /**
    * spark_history_server_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#spark_history_server_config BigqueryConnection#spark_history_server_config}
    */
    readonly sparkHistoryServerConfig?: BigqueryConnectionSparkSparkHistoryServerConfig;
}
export declare function bigqueryConnectionSparkToTerraform(struct?: BigqueryConnectionSparkOutputReference | BigqueryConnectionSpark): any;
export declare function bigqueryConnectionSparkToHclTerraform(struct?: BigqueryConnectionSparkOutputReference | BigqueryConnectionSpark): any;
export declare class BigqueryConnectionSparkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryConnectionSpark | undefined;
    set internalValue(value: BigqueryConnectionSpark | undefined);
    get serviceAccountId(): string;
    private _metastoreServiceConfig;
    get metastoreServiceConfig(): BigqueryConnectionSparkMetastoreServiceConfigOutputReference;
    putMetastoreServiceConfig(value: BigqueryConnectionSparkMetastoreServiceConfig): void;
    resetMetastoreServiceConfig(): void;
    get metastoreServiceConfigInput(): BigqueryConnectionSparkMetastoreServiceConfig | undefined;
    private _sparkHistoryServerConfig;
    get sparkHistoryServerConfig(): BigqueryConnectionSparkSparkHistoryServerConfigOutputReference;
    putSparkHistoryServerConfig(value: BigqueryConnectionSparkSparkHistoryServerConfig): void;
    resetSparkHistoryServerConfig(): void;
    get sparkHistoryServerConfigInput(): BigqueryConnectionSparkSparkHistoryServerConfig | undefined;
}
export interface BigqueryConnectionTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#create BigqueryConnection#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#delete BigqueryConnection#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#update BigqueryConnection#update}
    */
    readonly update?: string;
}
export declare function bigqueryConnectionTimeoutsToTerraform(struct?: BigqueryConnectionTimeouts | cdktn.IResolvable): any;
export declare function bigqueryConnectionTimeoutsToHclTerraform(struct?: BigqueryConnectionTimeouts | cdktn.IResolvable): any;
export declare class BigqueryConnectionTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryConnectionTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BigqueryConnectionTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection google_bigquery_connection}
*/
export declare class BigqueryConnection extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_bigquery_connection";
    /**
    * Generates CDKTN code for importing a BigqueryConnection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BigqueryConnection to import
    * @param importFromId The id of the existing BigqueryConnection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BigqueryConnection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/bigquery_connection google_bigquery_connection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BigqueryConnectionConfig = {}
    */
    constructor(scope: Construct, id: string, config?: BigqueryConnectionConfig);
    private _connectionId?;
    get connectionId(): string;
    set connectionId(value: string);
    resetConnectionId(): void;
    get connectionIdInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _friendlyName?;
    get friendlyName(): string;
    set friendlyName(value: string);
    resetFriendlyName(): void;
    get friendlyNameInput(): string | undefined;
    get hasCredential(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsKeyName?;
    get kmsKeyName(): string;
    set kmsKeyName(value: string);
    resetKmsKeyName(): void;
    get kmsKeyNameInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _aws;
    get aws(): BigqueryConnectionAwsOutputReference;
    putAws(value: BigqueryConnectionAws): void;
    resetAws(): void;
    get awsInput(): BigqueryConnectionAws | undefined;
    private _azure;
    get azure(): BigqueryConnectionAzureOutputReference;
    putAzure(value: BigqueryConnectionAzure): void;
    resetAzure(): void;
    get azureInput(): BigqueryConnectionAzure | undefined;
    private _cloudResource;
    get cloudResource(): BigqueryConnectionCloudResourceOutputReference;
    putCloudResource(value: BigqueryConnectionCloudResource): void;
    resetCloudResource(): void;
    get cloudResourceInput(): BigqueryConnectionCloudResource | undefined;
    private _cloudSpanner;
    get cloudSpanner(): BigqueryConnectionCloudSpannerOutputReference;
    putCloudSpanner(value: BigqueryConnectionCloudSpanner): void;
    resetCloudSpanner(): void;
    get cloudSpannerInput(): BigqueryConnectionCloudSpanner | undefined;
    private _cloudSql;
    get cloudSql(): BigqueryConnectionCloudSqlOutputReference;
    putCloudSql(value: BigqueryConnectionCloudSql): void;
    resetCloudSql(): void;
    get cloudSqlInput(): BigqueryConnectionCloudSql | undefined;
    private _configuration;
    get configuration(): BigqueryConnectionConfigurationOutputReference;
    putConfiguration(value: BigqueryConnectionConfiguration): void;
    resetConfiguration(): void;
    get configurationInput(): BigqueryConnectionConfiguration | undefined;
    private _salesforceDataCloud;
    get salesforceDataCloud(): BigqueryConnectionSalesforceDataCloudOutputReference;
    putSalesforceDataCloud(value: BigqueryConnectionSalesforceDataCloud): void;
    resetSalesforceDataCloud(): void;
    get salesforceDataCloudInput(): BigqueryConnectionSalesforceDataCloud | undefined;
    private _spark;
    get spark(): BigqueryConnectionSparkOutputReference;
    putSpark(value: BigqueryConnectionSpark): void;
    resetSpark(): void;
    get sparkInput(): BigqueryConnectionSpark | undefined;
    private _timeouts;
    get timeouts(): BigqueryConnectionTimeoutsOutputReference;
    putTimeouts(value: BigqueryConnectionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BigqueryConnectionTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
