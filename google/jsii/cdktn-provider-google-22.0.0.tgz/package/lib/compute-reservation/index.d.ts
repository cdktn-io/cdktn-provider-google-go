/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeReservationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Absolute time in future when the reservation will be auto-deleted by Compute Engine. Timestamp is represented in RFC3339 text format.
    * Cannot be used with delete_after_duration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#delete_at_time ComputeReservation#delete_at_time}
    */
    readonly deleteAtTime?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#deletion_policy ComputeReservation#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#description ComputeReservation#description}
    */
    readonly description?: string;
    /**
    * Name of the resource. Provided by the client when the resource is
    * created. The name must be 1-63 characters long, and comply with
    * RFC1035. Specifically, the name must be 1-63 characters long and match
    * the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the
    * first character must be a lowercase letter, and all following
    * characters must be a dash, lowercase letter, or digit, except the last
    * character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#name ComputeReservation#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#project ComputeReservation#project}
    */
    readonly project?: string;
    /**
    * When set to true, only VMs that target this reservation by name can
    * consume this reservation. Otherwise, it can be consumed by VMs with
    * affinity for any reservation. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#specific_reservation_required ComputeReservation#specific_reservation_required}
    */
    readonly specificReservationRequired?: boolean | cdktn.IResolvable;
    /**
    * The zone where the reservation is made.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#zone ComputeReservation#zone}
    */
    readonly zone: string;
    /**
    * delete_after_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#delete_after_duration ComputeReservation#delete_after_duration}
    */
    readonly deleteAfterDuration?: ComputeReservationDeleteAfterDuration;
    /**
    * params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#params ComputeReservation#params}
    */
    readonly params?: ComputeReservationParams;
    /**
    * reservation_sharing_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#reservation_sharing_policy ComputeReservation#reservation_sharing_policy}
    */
    readonly reservationSharingPolicy?: ComputeReservationReservationSharingPolicy;
    /**
    * share_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#share_settings ComputeReservation#share_settings}
    */
    readonly shareSettings?: ComputeReservationShareSettings;
    /**
    * specific_reservation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#specific_reservation ComputeReservation#specific_reservation}
    */
    readonly specificReservation: ComputeReservationSpecificReservation;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#timeouts ComputeReservation#timeouts}
    */
    readonly timeouts?: ComputeReservationTimeouts;
}
export interface ComputeReservationResourceStatusHealthInfo {
}
export declare function computeReservationResourceStatusHealthInfoToTerraform(struct?: ComputeReservationResourceStatusHealthInfo): any;
export declare function computeReservationResourceStatusHealthInfoToHclTerraform(struct?: ComputeReservationResourceStatusHealthInfo): any;
export declare class ComputeReservationResourceStatusHealthInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeReservationResourceStatusHealthInfo | undefined;
    set internalValue(value: ComputeReservationResourceStatusHealthInfo | undefined);
    get degradedBlockCount(): number;
    get healthStatus(): string;
    get healthyBlockCount(): number;
}
export declare class ComputeReservationResourceStatusHealthInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeReservationResourceStatusHealthInfoOutputReference;
}
export interface ComputeReservationResourceStatusReservationMaintenanceUpcomingGroupMaintenance {
}
export declare function computeReservationResourceStatusReservationMaintenanceUpcomingGroupMaintenanceToTerraform(struct?: ComputeReservationResourceStatusReservationMaintenanceUpcomingGroupMaintenance): any;
export declare function computeReservationResourceStatusReservationMaintenanceUpcomingGroupMaintenanceToHclTerraform(struct?: ComputeReservationResourceStatusReservationMaintenanceUpcomingGroupMaintenance): any;
export declare class ComputeReservationResourceStatusReservationMaintenanceUpcomingGroupMaintenanceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeReservationResourceStatusReservationMaintenanceUpcomingGroupMaintenance | undefined;
    set internalValue(value: ComputeReservationResourceStatusReservationMaintenanceUpcomingGroupMaintenance | undefined);
    get canReschedule(): cdktn.IResolvable;
    get latestWindowStartTime(): string;
    get maintenanceOnShutdown(): cdktn.IResolvable;
    get maintenanceReasons(): string[];
    get maintenanceStatus(): string;
    get type(): string;
    get windowEndTime(): string;
    get windowStartTime(): string;
}
export declare class ComputeReservationResourceStatusReservationMaintenanceUpcomingGroupMaintenanceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeReservationResourceStatusReservationMaintenanceUpcomingGroupMaintenanceOutputReference;
}
export interface ComputeReservationResourceStatusReservationMaintenance {
}
export declare function computeReservationResourceStatusReservationMaintenanceToTerraform(struct?: ComputeReservationResourceStatusReservationMaintenance): any;
export declare function computeReservationResourceStatusReservationMaintenanceToHclTerraform(struct?: ComputeReservationResourceStatusReservationMaintenance): any;
export declare class ComputeReservationResourceStatusReservationMaintenanceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeReservationResourceStatusReservationMaintenance | undefined;
    set internalValue(value: ComputeReservationResourceStatusReservationMaintenance | undefined);
    get instanceMaintenanceOngoingCount(): number;
    get instanceMaintenancePendingCount(): number;
    get maintenanceOngoingCount(): number;
    get maintenancePendingCount(): number;
    get schedulingType(): string;
    get subblockInfraMaintenanceOngoingCount(): number;
    get subblockInfraMaintenancePendingCount(): number;
    private _upcomingGroupMaintenance;
    get upcomingGroupMaintenance(): ComputeReservationResourceStatusReservationMaintenanceUpcomingGroupMaintenanceList;
}
export declare class ComputeReservationResourceStatusReservationMaintenanceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeReservationResourceStatusReservationMaintenanceOutputReference;
}
export interface ComputeReservationResourceStatusSpecificSkuAllocation {
}
export declare function computeReservationResourceStatusSpecificSkuAllocationToTerraform(struct?: ComputeReservationResourceStatusSpecificSkuAllocation): any;
export declare function computeReservationResourceStatusSpecificSkuAllocationToHclTerraform(struct?: ComputeReservationResourceStatusSpecificSkuAllocation): any;
export declare class ComputeReservationResourceStatusSpecificSkuAllocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeReservationResourceStatusSpecificSkuAllocation | undefined;
    set internalValue(value: ComputeReservationResourceStatusSpecificSkuAllocation | undefined);
    get sourceInstanceTemplateId(): string;
    private _utilizations;
    get utilizations(): cdktn.StringMap;
}
export declare class ComputeReservationResourceStatusSpecificSkuAllocationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeReservationResourceStatusSpecificSkuAllocationOutputReference;
}
export interface ComputeReservationResourceStatus {
}
export declare function computeReservationResourceStatusToTerraform(struct?: ComputeReservationResourceStatus): any;
export declare function computeReservationResourceStatusToHclTerraform(struct?: ComputeReservationResourceStatus): any;
export declare class ComputeReservationResourceStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeReservationResourceStatus | undefined;
    set internalValue(value: ComputeReservationResourceStatus | undefined);
    private _healthInfo;
    get healthInfo(): ComputeReservationResourceStatusHealthInfoList;
    get reservationBlockCount(): number;
    private _reservationMaintenance;
    get reservationMaintenance(): ComputeReservationResourceStatusReservationMaintenanceList;
    private _specificSkuAllocation;
    get specificSkuAllocation(): ComputeReservationResourceStatusSpecificSkuAllocationList;
}
export declare class ComputeReservationResourceStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeReservationResourceStatusOutputReference;
}
export interface ComputeReservationDeleteAfterDuration {
    /**
    * Number of nanoseconds for the auto-delete duration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#nanos ComputeReservation#nanos}
    */
    readonly nanos?: number;
    /**
    * Number of seconds for the auto-delete duration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#seconds ComputeReservation#seconds}
    */
    readonly seconds?: string;
}
export declare function computeReservationDeleteAfterDurationToTerraform(struct?: ComputeReservationDeleteAfterDurationOutputReference | ComputeReservationDeleteAfterDuration): any;
export declare function computeReservationDeleteAfterDurationToHclTerraform(struct?: ComputeReservationDeleteAfterDurationOutputReference | ComputeReservationDeleteAfterDuration): any;
export declare class ComputeReservationDeleteAfterDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeReservationDeleteAfterDuration | undefined;
    set internalValue(value: ComputeReservationDeleteAfterDuration | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): string;
    set seconds(value: string);
    resetSeconds(): void;
    get secondsInput(): string | undefined;
}
export interface ComputeReservationParams {
    /**
    * Resource manager tags to be bound to the reservation. Tag keys and values have the
    * same definition as resource manager tags. Keys must be in the format tagKeys/{tag_key_id},
    * and values are in the format tagValues/456.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#resource_manager_tags ComputeReservation#resource_manager_tags}
    */
    readonly resourceManagerTags?: {
        [key: string]: string;
    };
}
export declare function computeReservationParamsToTerraform(struct?: ComputeReservationParamsOutputReference | ComputeReservationParams): any;
export declare function computeReservationParamsToHclTerraform(struct?: ComputeReservationParamsOutputReference | ComputeReservationParams): any;
export declare class ComputeReservationParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeReservationParams | undefined;
    set internalValue(value: ComputeReservationParams | undefined);
    private _resourceManagerTags?;
    get resourceManagerTags(): {
        [key: string]: string;
    };
    set resourceManagerTags(value: {
        [key: string]: string;
    });
    resetResourceManagerTags(): void;
    get resourceManagerTagsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ComputeReservationReservationSharingPolicy {
    /**
    * Sharing config for all Google Cloud services. Possible values: ["ALLOW_ALL", "DISALLOW_ALL"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#service_share_type ComputeReservation#service_share_type}
    */
    readonly serviceShareType?: string;
}
export declare function computeReservationReservationSharingPolicyToTerraform(struct?: ComputeReservationReservationSharingPolicyOutputReference | ComputeReservationReservationSharingPolicy): any;
export declare function computeReservationReservationSharingPolicyToHclTerraform(struct?: ComputeReservationReservationSharingPolicyOutputReference | ComputeReservationReservationSharingPolicy): any;
export declare class ComputeReservationReservationSharingPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeReservationReservationSharingPolicy | undefined;
    set internalValue(value: ComputeReservationReservationSharingPolicy | undefined);
    private _serviceShareType?;
    get serviceShareType(): string;
    set serviceShareType(value: string);
    resetServiceShareType(): void;
    get serviceShareTypeInput(): string | undefined;
}
export interface ComputeReservationShareSettingsProjectMap {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#id ComputeReservation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * The project id/number, should be same as the key of this project config in the project map.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#project_id ComputeReservation#project_id}
    */
    readonly projectId?: string;
}
export declare function computeReservationShareSettingsProjectMapToTerraform(struct?: ComputeReservationShareSettingsProjectMap | cdktn.IResolvable): any;
export declare function computeReservationShareSettingsProjectMapToHclTerraform(struct?: ComputeReservationShareSettingsProjectMap | cdktn.IResolvable): any;
export declare class ComputeReservationShareSettingsProjectMapOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeReservationShareSettingsProjectMap | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeReservationShareSettingsProjectMap | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
}
export declare class ComputeReservationShareSettingsProjectMapList extends cdktn.ComplexList {
    internalValue?: ComputeReservationShareSettingsProjectMap[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeReservationShareSettingsProjectMapOutputReference;
}
export interface ComputeReservationShareSettings {
    /**
    * Type of sharing for this shared-reservation Possible values: ["LOCAL", "SPECIFIC_PROJECTS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#share_type ComputeReservation#share_type}
    */
    readonly shareType?: string;
    /**
    * project_map block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#project_map ComputeReservation#project_map}
    */
    readonly projectMap?: ComputeReservationShareSettingsProjectMap[] | cdktn.IResolvable;
}
export declare function computeReservationShareSettingsToTerraform(struct?: ComputeReservationShareSettingsOutputReference | ComputeReservationShareSettings): any;
export declare function computeReservationShareSettingsToHclTerraform(struct?: ComputeReservationShareSettingsOutputReference | ComputeReservationShareSettings): any;
export declare class ComputeReservationShareSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeReservationShareSettings | undefined;
    set internalValue(value: ComputeReservationShareSettings | undefined);
    private _shareType?;
    get shareType(): string;
    set shareType(value: string);
    resetShareType(): void;
    get shareTypeInput(): string | undefined;
    private _projectMap;
    get projectMap(): ComputeReservationShareSettingsProjectMapList;
    putProjectMap(value: ComputeReservationShareSettingsProjectMap[] | cdktn.IResolvable): void;
    resetProjectMap(): void;
    get projectMapInput(): cdktn.IResolvable | ComputeReservationShareSettingsProjectMap[] | undefined;
}
export interface ComputeReservationSpecificReservationInstancePropertiesGuestAccelerators {
    /**
    * The number of the guest accelerator cards exposed to
    * this instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#accelerator_count ComputeReservation#accelerator_count}
    */
    readonly acceleratorCount: number;
    /**
    * The full or partial URL of the accelerator type to
    * attach to this instance. For example:
    * 'projects/my-project/zones/us-central1-c/acceleratorTypes/nvidia-tesla-p100'
    *
    * If you are creating an instance template, specify only the accelerator name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#accelerator_type ComputeReservation#accelerator_type}
    */
    readonly acceleratorType: string;
}
export declare function computeReservationSpecificReservationInstancePropertiesGuestAcceleratorsToTerraform(struct?: ComputeReservationSpecificReservationInstancePropertiesGuestAccelerators | cdktn.IResolvable): any;
export declare function computeReservationSpecificReservationInstancePropertiesGuestAcceleratorsToHclTerraform(struct?: ComputeReservationSpecificReservationInstancePropertiesGuestAccelerators | cdktn.IResolvable): any;
export declare class ComputeReservationSpecificReservationInstancePropertiesGuestAcceleratorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeReservationSpecificReservationInstancePropertiesGuestAccelerators | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeReservationSpecificReservationInstancePropertiesGuestAccelerators | cdktn.IResolvable | undefined);
    private _acceleratorCount?;
    get acceleratorCount(): number;
    set acceleratorCount(value: number);
    get acceleratorCountInput(): number | undefined;
    private _acceleratorType?;
    get acceleratorType(): string;
    set acceleratorType(value: string);
    get acceleratorTypeInput(): string | undefined;
}
export declare class ComputeReservationSpecificReservationInstancePropertiesGuestAcceleratorsList extends cdktn.ComplexList {
    internalValue?: ComputeReservationSpecificReservationInstancePropertiesGuestAccelerators[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeReservationSpecificReservationInstancePropertiesGuestAcceleratorsOutputReference;
}
export interface ComputeReservationSpecificReservationInstancePropertiesLocalSsds {
    /**
    * The size of the disk in base-2 GB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#disk_size_gb ComputeReservation#disk_size_gb}
    */
    readonly diskSizeGb: number;
    /**
    * The disk interface to use for attaching this disk. Default value: "SCSI" Possible values: ["SCSI", "NVME"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#interface ComputeReservation#interface}
    */
    readonly interface?: string;
}
export declare function computeReservationSpecificReservationInstancePropertiesLocalSsdsToTerraform(struct?: ComputeReservationSpecificReservationInstancePropertiesLocalSsds | cdktn.IResolvable): any;
export declare function computeReservationSpecificReservationInstancePropertiesLocalSsdsToHclTerraform(struct?: ComputeReservationSpecificReservationInstancePropertiesLocalSsds | cdktn.IResolvable): any;
export declare class ComputeReservationSpecificReservationInstancePropertiesLocalSsdsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeReservationSpecificReservationInstancePropertiesLocalSsds | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeReservationSpecificReservationInstancePropertiesLocalSsds | cdktn.IResolvable | undefined);
    private _diskSizeGb?;
    get diskSizeGb(): number;
    set diskSizeGb(value: number);
    get diskSizeGbInput(): number | undefined;
    private _interface?;
    get interface(): string;
    set interface(value: string);
    resetInterface(): void;
    get interfaceInput(): string | undefined;
}
export declare class ComputeReservationSpecificReservationInstancePropertiesLocalSsdsList extends cdktn.ComplexList {
    internalValue?: ComputeReservationSpecificReservationInstancePropertiesLocalSsds[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeReservationSpecificReservationInstancePropertiesLocalSsdsOutputReference;
}
export interface ComputeReservationSpecificReservationInstanceProperties {
    /**
    * The name of the machine type to reserve.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#machine_type ComputeReservation#machine_type}
    */
    readonly machineType: string;
    /**
    * The minimum CPU platform for the reservation. For example,
    * '"Intel Skylake"'. See
    * the CPU platform availability reference](https://cloud.google.com/compute/docs/instances/specify-min-cpu-platform#availablezones)
    * for information on available CPU platforms.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#min_cpu_platform ComputeReservation#min_cpu_platform}
    */
    readonly minCpuPlatform?: string;
    /**
    * guest_accelerators block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#guest_accelerators ComputeReservation#guest_accelerators}
    */
    readonly guestAccelerators?: ComputeReservationSpecificReservationInstancePropertiesGuestAccelerators[] | cdktn.IResolvable;
    /**
    * local_ssds block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#local_ssds ComputeReservation#local_ssds}
    */
    readonly localSsds?: ComputeReservationSpecificReservationInstancePropertiesLocalSsds[] | cdktn.IResolvable;
}
export declare function computeReservationSpecificReservationInstancePropertiesToTerraform(struct?: ComputeReservationSpecificReservationInstancePropertiesOutputReference | ComputeReservationSpecificReservationInstanceProperties): any;
export declare function computeReservationSpecificReservationInstancePropertiesToHclTerraform(struct?: ComputeReservationSpecificReservationInstancePropertiesOutputReference | ComputeReservationSpecificReservationInstanceProperties): any;
export declare class ComputeReservationSpecificReservationInstancePropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeReservationSpecificReservationInstanceProperties | undefined;
    set internalValue(value: ComputeReservationSpecificReservationInstanceProperties | undefined);
    get locationHint(): string;
    private _machineType?;
    get machineType(): string;
    set machineType(value: string);
    get machineTypeInput(): string | undefined;
    private _minCpuPlatform?;
    get minCpuPlatform(): string;
    set minCpuPlatform(value: string);
    resetMinCpuPlatform(): void;
    get minCpuPlatformInput(): string | undefined;
    private _guestAccelerators;
    get guestAccelerators(): ComputeReservationSpecificReservationInstancePropertiesGuestAcceleratorsList;
    putGuestAccelerators(value: ComputeReservationSpecificReservationInstancePropertiesGuestAccelerators[] | cdktn.IResolvable): void;
    resetGuestAccelerators(): void;
    get guestAcceleratorsInput(): cdktn.IResolvable | ComputeReservationSpecificReservationInstancePropertiesGuestAccelerators[] | undefined;
    private _localSsds;
    get localSsds(): ComputeReservationSpecificReservationInstancePropertiesLocalSsdsList;
    putLocalSsds(value: ComputeReservationSpecificReservationInstancePropertiesLocalSsds[] | cdktn.IResolvable): void;
    resetLocalSsds(): void;
    get localSsdsInput(): cdktn.IResolvable | ComputeReservationSpecificReservationInstancePropertiesLocalSsds[] | undefined;
}
export interface ComputeReservationSpecificReservation {
    /**
    * The number of resources that are allocated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#count ComputeReservation#count}
    */
    readonly count: number;
    /**
    * Specifies the instance template to create the reservation. If you use this field, you must exclude the
    * instanceProperties field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#source_instance_template ComputeReservation#source_instance_template}
    */
    readonly sourceInstanceTemplate?: string;
    /**
    * instance_properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#instance_properties ComputeReservation#instance_properties}
    */
    readonly instanceProperties?: ComputeReservationSpecificReservationInstanceProperties;
}
export declare function computeReservationSpecificReservationToTerraform(struct?: ComputeReservationSpecificReservationOutputReference | ComputeReservationSpecificReservation): any;
export declare function computeReservationSpecificReservationToHclTerraform(struct?: ComputeReservationSpecificReservationOutputReference | ComputeReservationSpecificReservation): any;
export declare class ComputeReservationSpecificReservationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeReservationSpecificReservation | undefined;
    set internalValue(value: ComputeReservationSpecificReservation | undefined);
    get assuredCount(): number;
    private _count?;
    get count(): number;
    set count(value: number);
    get countInput(): number | undefined;
    get inUseCount(): number;
    private _sourceInstanceTemplate?;
    get sourceInstanceTemplate(): string;
    set sourceInstanceTemplate(value: string);
    resetSourceInstanceTemplate(): void;
    get sourceInstanceTemplateInput(): string | undefined;
    private _instanceProperties;
    get instanceProperties(): ComputeReservationSpecificReservationInstancePropertiesOutputReference;
    putInstanceProperties(value: ComputeReservationSpecificReservationInstanceProperties): void;
    resetInstanceProperties(): void;
    get instancePropertiesInput(): ComputeReservationSpecificReservationInstanceProperties | undefined;
}
export interface ComputeReservationTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#create ComputeReservation#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#delete ComputeReservation#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#update ComputeReservation#update}
    */
    readonly update?: string;
}
export declare function computeReservationTimeoutsToTerraform(struct?: ComputeReservationTimeouts | cdktn.IResolvable): any;
export declare function computeReservationTimeoutsToHclTerraform(struct?: ComputeReservationTimeouts | cdktn.IResolvable): any;
export declare class ComputeReservationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeReservationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeReservationTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation google_compute_reservation}
*/
export declare class ComputeReservation extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_reservation";
    /**
    * Generates CDKTN code for importing a ComputeReservation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeReservation to import
    * @param importFromId The id of the existing ComputeReservation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeReservation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_reservation google_compute_reservation} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeReservationConfig
    */
    constructor(scope: Construct, id: string, config: ComputeReservationConfig);
    get blockNames(): string[];
    get commitment(): string;
    get creationTimestamp(): string;
    private _deleteAtTime?;
    get deleteAtTime(): string;
    set deleteAtTime(value: string);
    resetDeleteAtTime(): void;
    get deleteAtTimeInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get kind(): string;
    get linkedCommitments(): string[];
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _resourceStatus;
    get resourceStatus(): ComputeReservationResourceStatusList;
    get satisfiesPzs(): cdktn.IResolvable;
    get selfLink(): string;
    private _specificReservationRequired?;
    get specificReservationRequired(): boolean | cdktn.IResolvable;
    set specificReservationRequired(value: boolean | cdktn.IResolvable);
    resetSpecificReservationRequired(): void;
    get specificReservationRequiredInput(): boolean | cdktn.IResolvable | undefined;
    get status(): string;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    get zoneInput(): string | undefined;
    private _deleteAfterDuration;
    get deleteAfterDuration(): ComputeReservationDeleteAfterDurationOutputReference;
    putDeleteAfterDuration(value: ComputeReservationDeleteAfterDuration): void;
    resetDeleteAfterDuration(): void;
    get deleteAfterDurationInput(): ComputeReservationDeleteAfterDuration | undefined;
    private _params;
    get params(): ComputeReservationParamsOutputReference;
    putParams(value: ComputeReservationParams): void;
    resetParams(): void;
    get paramsInput(): ComputeReservationParams | undefined;
    private _reservationSharingPolicy;
    get reservationSharingPolicy(): ComputeReservationReservationSharingPolicyOutputReference;
    putReservationSharingPolicy(value: ComputeReservationReservationSharingPolicy): void;
    resetReservationSharingPolicy(): void;
    get reservationSharingPolicyInput(): ComputeReservationReservationSharingPolicy | undefined;
    private _shareSettings;
    get shareSettings(): ComputeReservationShareSettingsOutputReference;
    putShareSettings(value: ComputeReservationShareSettings): void;
    resetShareSettings(): void;
    get shareSettingsInput(): ComputeReservationShareSettings | undefined;
    private _specificReservation;
    get specificReservation(): ComputeReservationSpecificReservationOutputReference;
    putSpecificReservation(value: ComputeReservationSpecificReservation): void;
    get specificReservationInput(): ComputeReservationSpecificReservation | undefined;
    private _timeouts;
    get timeouts(): ComputeReservationTimeoutsOutputReference;
    putTimeouts(value: ComputeReservationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeReservationTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
