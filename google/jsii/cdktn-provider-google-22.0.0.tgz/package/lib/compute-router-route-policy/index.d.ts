/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeRouterRoutePolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_route_policy#deletion_policy ComputeRouterRoutePolicy#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_route_policy#id ComputeRouterRoutePolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the route policy. This policy's name, which must be a resource ID segment and unique within all policies owned by the Router
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_route_policy#name ComputeRouterRoutePolicy#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_route_policy#project ComputeRouterRoutePolicy#project}
    */
    readonly project?: string;
    /**
    * Region where the router and NAT reside.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_route_policy#region ComputeRouterRoutePolicy#region}
    */
    readonly region?: string;
    /**
    * The name of the Cloud Router in which this route policy will be configured.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_route_policy#router ComputeRouterRoutePolicy#router}
    */
    readonly router: string;
    /**
    * This is policy's type, which is one of IMPORT or EXPORT Possible values: ["ROUTE_POLICY_TYPE_IMPORT", "ROUTE_POLICY_TYPE_EXPORT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_route_policy#type ComputeRouterRoutePolicy#type}
    */
    readonly type?: string;
    /**
    * terms block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_route_policy#terms ComputeRouterRoutePolicy#terms}
    */
    readonly terms: ComputeRouterRoutePolicyTerms[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_route_policy#timeouts ComputeRouterRoutePolicy#timeouts}
    */
    readonly timeouts?: ComputeRouterRoutePolicyTimeouts;
}
export interface ComputeRouterRoutePolicyTermsActions {
    /**
    * Description of the expression
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_route_policy#description ComputeRouterRoutePolicy#description}
    */
    readonly description?: string;
    /**
    * Textual representation of an expression in Common Expression
    * Language syntax.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_route_policy#expression ComputeRouterRoutePolicy#expression}
    */
    readonly expression: string;
    /**
    * String indicating the location of the expression for error
    * reporting, e.g. a file name and a position in the file
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_route_policy#location ComputeRouterRoutePolicy#location}
    */
    readonly location?: string;
    /**
    * Title for the expression, i.e. a short string describing its
    * purpose.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_route_policy#title ComputeRouterRoutePolicy#title}
    */
    readonly title?: string;
}
export declare function computeRouterRoutePolicyTermsActionsToTerraform(struct?: ComputeRouterRoutePolicyTermsActions | cdktn.IResolvable): any;
export declare function computeRouterRoutePolicyTermsActionsToHclTerraform(struct?: ComputeRouterRoutePolicyTermsActions | cdktn.IResolvable): any;
export declare class ComputeRouterRoutePolicyTermsActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRouterRoutePolicyTermsActions | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRouterRoutePolicyTermsActions | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
}
export declare class ComputeRouterRoutePolicyTermsActionsList extends cdktn.ComplexList {
    internalValue?: ComputeRouterRoutePolicyTermsActions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRouterRoutePolicyTermsActionsOutputReference;
}
export interface ComputeRouterRoutePolicyTermsMatch {
    /**
    * Description of the expression
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_route_policy#description ComputeRouterRoutePolicy#description}
    */
    readonly description?: string;
    /**
    * Textual representation of an expression in Common Expression Language syntax.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_route_policy#expression ComputeRouterRoutePolicy#expression}
    */
    readonly expression: string;
    /**
    * String indicating the location of the expression for error reporting, e.g. a file name and a position in the file
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_route_policy#location ComputeRouterRoutePolicy#location}
    */
    readonly location?: string;
    /**
    * Title for the expression, i.e. a short string describing its purpose.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_route_policy#title ComputeRouterRoutePolicy#title}
    */
    readonly title?: string;
}
export declare function computeRouterRoutePolicyTermsMatchToTerraform(struct?: ComputeRouterRoutePolicyTermsMatchOutputReference | ComputeRouterRoutePolicyTermsMatch): any;
export declare function computeRouterRoutePolicyTermsMatchToHclTerraform(struct?: ComputeRouterRoutePolicyTermsMatchOutputReference | ComputeRouterRoutePolicyTermsMatch): any;
export declare class ComputeRouterRoutePolicyTermsMatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRouterRoutePolicyTermsMatch | undefined;
    set internalValue(value: ComputeRouterRoutePolicyTermsMatch | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
}
export interface ComputeRouterRoutePolicyTerms {
    /**
    * The evaluation priority for this term, which must be between 0 (inclusive) and 2147483648 (exclusive), and unique within the list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_route_policy#priority ComputeRouterRoutePolicy#priority}
    */
    readonly priority: number;
    /**
    * actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_route_policy#actions ComputeRouterRoutePolicy#actions}
    */
    readonly actions?: ComputeRouterRoutePolicyTermsActions[] | cdktn.IResolvable;
    /**
    * match block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_route_policy#match ComputeRouterRoutePolicy#match}
    */
    readonly match: ComputeRouterRoutePolicyTermsMatch;
}
export declare function computeRouterRoutePolicyTermsToTerraform(struct?: ComputeRouterRoutePolicyTerms | cdktn.IResolvable): any;
export declare function computeRouterRoutePolicyTermsToHclTerraform(struct?: ComputeRouterRoutePolicyTerms | cdktn.IResolvable): any;
export declare class ComputeRouterRoutePolicyTermsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRouterRoutePolicyTerms | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRouterRoutePolicyTerms | cdktn.IResolvable | undefined);
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
    private _actions;
    get actions(): ComputeRouterRoutePolicyTermsActionsList;
    putActions(value: ComputeRouterRoutePolicyTermsActions[] | cdktn.IResolvable): void;
    resetActions(): void;
    get actionsInput(): cdktn.IResolvable | ComputeRouterRoutePolicyTermsActions[] | undefined;
    private _match;
    get match(): ComputeRouterRoutePolicyTermsMatchOutputReference;
    putMatch(value: ComputeRouterRoutePolicyTermsMatch): void;
    get matchInput(): ComputeRouterRoutePolicyTermsMatch | undefined;
}
export declare class ComputeRouterRoutePolicyTermsList extends cdktn.ComplexList {
    internalValue?: ComputeRouterRoutePolicyTerms[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRouterRoutePolicyTermsOutputReference;
}
export interface ComputeRouterRoutePolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_route_policy#create ComputeRouterRoutePolicy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_route_policy#delete ComputeRouterRoutePolicy#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_route_policy#update ComputeRouterRoutePolicy#update}
    */
    readonly update?: string;
}
export declare function computeRouterRoutePolicyTimeoutsToTerraform(struct?: ComputeRouterRoutePolicyTimeouts | cdktn.IResolvable): any;
export declare function computeRouterRoutePolicyTimeoutsToHclTerraform(struct?: ComputeRouterRoutePolicyTimeouts | cdktn.IResolvable): any;
export declare class ComputeRouterRoutePolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRouterRoutePolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRouterRoutePolicyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_route_policy google_compute_router_route_policy}
*/
export declare class ComputeRouterRoutePolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_router_route_policy";
    /**
    * Generates CDKTN code for importing a ComputeRouterRoutePolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeRouterRoutePolicy to import
    * @param importFromId The id of the existing ComputeRouterRoutePolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_route_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeRouterRoutePolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_route_policy google_compute_router_route_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeRouterRoutePolicyConfig
    */
    constructor(scope: Construct, id: string, config: ComputeRouterRoutePolicyConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    get fingerprint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _router?;
    get router(): string;
    set router(value: string);
    get routerInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _terms;
    get terms(): ComputeRouterRoutePolicyTermsList;
    putTerms(value: ComputeRouterRoutePolicyTerms[] | cdktn.IResolvable): void;
    get termsInput(): cdktn.IResolvable | ComputeRouterRoutePolicyTerms[] | undefined;
    private _timeouts;
    get timeouts(): ComputeRouterRoutePolicyTimeoutsOutputReference;
    putTimeouts(value: ComputeRouterRoutePolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeRouterRoutePolicyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
