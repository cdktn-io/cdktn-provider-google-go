/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChronicleWatchlistConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_watchlist#deletion_policy ChronicleWatchlist#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Optional. Description of the watchlist.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_watchlist#description ChronicleWatchlist#description}
    */
    readonly description?: string;
    /**
    * Required. Display name of the watchlist.
    * Note that it must be at least one character and less than 63 characters
    * (https://google.aip.dev/148).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_watchlist#display_name ChronicleWatchlist#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_watchlist#id ChronicleWatchlist#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The unique identifier for the Chronicle instance, which is the same as the customer ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_watchlist#instance ChronicleWatchlist#instance}
    */
    readonly instance: string;
    /**
    * The location of the resource. This is the geographical region where the Chronicle instance resides, such as "us" or "europe-west2".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_watchlist#location ChronicleWatchlist#location}
    */
    readonly location: string;
    /**
    * Optional. Weight applied to the risk score for entities
    * in this watchlist.
    * The default is 1.0 if it is not specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_watchlist#multiplying_factor ChronicleWatchlist#multiplying_factor}
    */
    readonly multiplyingFactor?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_watchlist#project ChronicleWatchlist#project}
    */
    readonly project?: string;
    /**
    * Optional. The ID to use for the watchlist,
    * which will become the final component of the watchlist's resource name.
    * This value should be 4-63 characters, and valid characters
    * are /a-z-/.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_watchlist#watchlist_id ChronicleWatchlist#watchlist_id}
    */
    readonly watchlistId?: string;
    /**
    * entity_population_mechanism block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_watchlist#entity_population_mechanism ChronicleWatchlist#entity_population_mechanism}
    */
    readonly entityPopulationMechanism: ChronicleWatchlistEntityPopulationMechanism;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_watchlist#timeouts ChronicleWatchlist#timeouts}
    */
    readonly timeouts?: ChronicleWatchlistTimeouts;
    /**
    * watchlist_user_preferences block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_watchlist#watchlist_user_preferences ChronicleWatchlist#watchlist_user_preferences}
    */
    readonly watchlistUserPreferences?: ChronicleWatchlistWatchlistUserPreferences;
}
export interface ChronicleWatchlistEntityCount {
}
export declare function chronicleWatchlistEntityCountToTerraform(struct?: ChronicleWatchlistEntityCount): any;
export declare function chronicleWatchlistEntityCountToHclTerraform(struct?: ChronicleWatchlistEntityCount): any;
export declare class ChronicleWatchlistEntityCountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleWatchlistEntityCount | undefined;
    set internalValue(value: ChronicleWatchlistEntityCount | undefined);
    get asset(): number;
    get user(): number;
}
export declare class ChronicleWatchlistEntityCountList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleWatchlistEntityCountOutputReference;
}
export interface ChronicleWatchlistEntityPopulationMechanismManual {
}
export declare function chronicleWatchlistEntityPopulationMechanismManualToTerraform(struct?: ChronicleWatchlistEntityPopulationMechanismManualOutputReference | ChronicleWatchlistEntityPopulationMechanismManual): any;
export declare function chronicleWatchlistEntityPopulationMechanismManualToHclTerraform(struct?: ChronicleWatchlistEntityPopulationMechanismManualOutputReference | ChronicleWatchlistEntityPopulationMechanismManual): any;
export declare class ChronicleWatchlistEntityPopulationMechanismManualOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleWatchlistEntityPopulationMechanismManual | undefined;
    set internalValue(value: ChronicleWatchlistEntityPopulationMechanismManual | undefined);
}
export interface ChronicleWatchlistEntityPopulationMechanism {
    /**
    * manual block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_watchlist#manual ChronicleWatchlist#manual}
    */
    readonly manual?: ChronicleWatchlistEntityPopulationMechanismManual;
}
export declare function chronicleWatchlistEntityPopulationMechanismToTerraform(struct?: ChronicleWatchlistEntityPopulationMechanismOutputReference | ChronicleWatchlistEntityPopulationMechanism): any;
export declare function chronicleWatchlistEntityPopulationMechanismToHclTerraform(struct?: ChronicleWatchlistEntityPopulationMechanismOutputReference | ChronicleWatchlistEntityPopulationMechanism): any;
export declare class ChronicleWatchlistEntityPopulationMechanismOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleWatchlistEntityPopulationMechanism | undefined;
    set internalValue(value: ChronicleWatchlistEntityPopulationMechanism | undefined);
    private _manual;
    get manual(): ChronicleWatchlistEntityPopulationMechanismManualOutputReference;
    putManual(value: ChronicleWatchlistEntityPopulationMechanismManual): void;
    resetManual(): void;
    get manualInput(): ChronicleWatchlistEntityPopulationMechanismManual | undefined;
}
export interface ChronicleWatchlistTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_watchlist#create ChronicleWatchlist#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_watchlist#delete ChronicleWatchlist#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_watchlist#update ChronicleWatchlist#update}
    */
    readonly update?: string;
}
export declare function chronicleWatchlistTimeoutsToTerraform(struct?: ChronicleWatchlistTimeouts | cdktn.IResolvable): any;
export declare function chronicleWatchlistTimeoutsToHclTerraform(struct?: ChronicleWatchlistTimeouts | cdktn.IResolvable): any;
export declare class ChronicleWatchlistTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleWatchlistTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleWatchlistTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface ChronicleWatchlistWatchlistUserPreferences {
    /**
    * Optional. Whether the watchlist is pinned on the dashboard.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_watchlist#pinned ChronicleWatchlist#pinned}
    */
    readonly pinned?: boolean | cdktn.IResolvable;
}
export declare function chronicleWatchlistWatchlistUserPreferencesToTerraform(struct?: ChronicleWatchlistWatchlistUserPreferencesOutputReference | ChronicleWatchlistWatchlistUserPreferences): any;
export declare function chronicleWatchlistWatchlistUserPreferencesToHclTerraform(struct?: ChronicleWatchlistWatchlistUserPreferencesOutputReference | ChronicleWatchlistWatchlistUserPreferences): any;
export declare class ChronicleWatchlistWatchlistUserPreferencesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleWatchlistWatchlistUserPreferences | undefined;
    set internalValue(value: ChronicleWatchlistWatchlistUserPreferences | undefined);
    private _pinned?;
    get pinned(): boolean | cdktn.IResolvable;
    set pinned(value: boolean | cdktn.IResolvable);
    resetPinned(): void;
    get pinnedInput(): boolean | cdktn.IResolvable | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_watchlist google_chronicle_watchlist}
*/
export declare class ChronicleWatchlist extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_chronicle_watchlist";
    /**
    * Generates CDKTN code for importing a ChronicleWatchlist resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChronicleWatchlist to import
    * @param importFromId The id of the existing ChronicleWatchlist that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_watchlist#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChronicleWatchlist to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/chronicle_watchlist google_chronicle_watchlist} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChronicleWatchlistConfig
    */
    constructor(scope: Construct, id: string, config: ChronicleWatchlistConfig);
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _entityCount;
    get entityCount(): ChronicleWatchlistEntityCountList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instance?;
    get instance(): string;
    set instance(value: string);
    get instanceInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _multiplyingFactor?;
    get multiplyingFactor(): number;
    set multiplyingFactor(value: number);
    resetMultiplyingFactor(): void;
    get multiplyingFactorInput(): number | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get updateTime(): string;
    private _watchlistId?;
    get watchlistId(): string;
    set watchlistId(value: string);
    resetWatchlistId(): void;
    get watchlistIdInput(): string | undefined;
    private _entityPopulationMechanism;
    get entityPopulationMechanism(): ChronicleWatchlistEntityPopulationMechanismOutputReference;
    putEntityPopulationMechanism(value: ChronicleWatchlistEntityPopulationMechanism): void;
    get entityPopulationMechanismInput(): ChronicleWatchlistEntityPopulationMechanism | undefined;
    private _timeouts;
    get timeouts(): ChronicleWatchlistTimeoutsOutputReference;
    putTimeouts(value: ChronicleWatchlistTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ChronicleWatchlistTimeouts | undefined;
    private _watchlistUserPreferences;
    get watchlistUserPreferences(): ChronicleWatchlistWatchlistUserPreferencesOutputReference;
    putWatchlistUserPreferences(value: ChronicleWatchlistWatchlistUserPreferences): void;
    resetWatchlistUserPreferences(): void;
    get watchlistUserPreferencesInput(): ChronicleWatchlistWatchlistUserPreferences | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
