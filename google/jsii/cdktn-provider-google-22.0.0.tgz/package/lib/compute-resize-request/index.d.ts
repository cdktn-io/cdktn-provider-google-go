/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeResizeRequestConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_resize_request#deletion_policy ComputeResizeRequest#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resize-request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_resize_request#description ComputeResizeRequest#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_resize_request#id ComputeResizeRequest#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The reference of the instance group manager this ResizeRequest is a part of.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_resize_request#instance_group_manager ComputeResizeRequest#instance_group_manager}
    */
    readonly instanceGroupManager: string;
    /**
    * The name of this resize request. The name must be 1-63 characters long, and comply with RFC1035.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_resize_request#name ComputeResizeRequest#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_resize_request#project ComputeResizeRequest#project}
    */
    readonly project?: string;
    /**
    * The number of instances to be created by this resize request. The group's target size will be increased by this number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_resize_request#resize_by ComputeResizeRequest#resize_by}
    */
    readonly resizeBy: number;
    /**
    * The reference of the compute zone scoping this request. If it is not provided, the provider zone is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_resize_request#zone ComputeResizeRequest#zone}
    */
    readonly zone?: string;
    /**
    * requested_run_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_resize_request#requested_run_duration ComputeResizeRequest#requested_run_duration}
    */
    readonly requestedRunDuration?: ComputeResizeRequestRequestedRunDuration;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_resize_request#timeouts ComputeResizeRequest#timeouts}
    */
    readonly timeouts?: ComputeResizeRequestTimeouts;
}
export interface ComputeResizeRequestStatusErrorErrorsErrorDetailsErrorInfo {
}
export declare function computeResizeRequestStatusErrorErrorsErrorDetailsErrorInfoToTerraform(struct?: ComputeResizeRequestStatusErrorErrorsErrorDetailsErrorInfo): any;
export declare function computeResizeRequestStatusErrorErrorsErrorDetailsErrorInfoToHclTerraform(struct?: ComputeResizeRequestStatusErrorErrorsErrorDetailsErrorInfo): any;
export declare class ComputeResizeRequestStatusErrorErrorsErrorDetailsErrorInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeResizeRequestStatusErrorErrorsErrorDetailsErrorInfo | undefined;
    set internalValue(value: ComputeResizeRequestStatusErrorErrorsErrorDetailsErrorInfo | undefined);
    get domain(): string;
    private _metadatas;
    get metadatas(): cdktn.StringMap;
    get reason(): string;
}
export declare class ComputeResizeRequestStatusErrorErrorsErrorDetailsErrorInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeResizeRequestStatusErrorErrorsErrorDetailsErrorInfoOutputReference;
}
export interface ComputeResizeRequestStatusErrorErrorsErrorDetailsHelpLinks {
}
export declare function computeResizeRequestStatusErrorErrorsErrorDetailsHelpLinksToTerraform(struct?: ComputeResizeRequestStatusErrorErrorsErrorDetailsHelpLinks): any;
export declare function computeResizeRequestStatusErrorErrorsErrorDetailsHelpLinksToHclTerraform(struct?: ComputeResizeRequestStatusErrorErrorsErrorDetailsHelpLinks): any;
export declare class ComputeResizeRequestStatusErrorErrorsErrorDetailsHelpLinksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeResizeRequestStatusErrorErrorsErrorDetailsHelpLinks | undefined;
    set internalValue(value: ComputeResizeRequestStatusErrorErrorsErrorDetailsHelpLinks | undefined);
    get description(): string;
    get url(): string;
}
export declare class ComputeResizeRequestStatusErrorErrorsErrorDetailsHelpLinksList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeResizeRequestStatusErrorErrorsErrorDetailsHelpLinksOutputReference;
}
export interface ComputeResizeRequestStatusErrorErrorsErrorDetailsHelp {
}
export declare function computeResizeRequestStatusErrorErrorsErrorDetailsHelpToTerraform(struct?: ComputeResizeRequestStatusErrorErrorsErrorDetailsHelp): any;
export declare function computeResizeRequestStatusErrorErrorsErrorDetailsHelpToHclTerraform(struct?: ComputeResizeRequestStatusErrorErrorsErrorDetailsHelp): any;
export declare class ComputeResizeRequestStatusErrorErrorsErrorDetailsHelpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeResizeRequestStatusErrorErrorsErrorDetailsHelp | undefined;
    set internalValue(value: ComputeResizeRequestStatusErrorErrorsErrorDetailsHelp | undefined);
    private _links;
    get links(): ComputeResizeRequestStatusErrorErrorsErrorDetailsHelpLinksList;
}
export declare class ComputeResizeRequestStatusErrorErrorsErrorDetailsHelpList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeResizeRequestStatusErrorErrorsErrorDetailsHelpOutputReference;
}
export interface ComputeResizeRequestStatusErrorErrorsErrorDetailsLocalizedMessage {
}
export declare function computeResizeRequestStatusErrorErrorsErrorDetailsLocalizedMessageToTerraform(struct?: ComputeResizeRequestStatusErrorErrorsErrorDetailsLocalizedMessage): any;
export declare function computeResizeRequestStatusErrorErrorsErrorDetailsLocalizedMessageToHclTerraform(struct?: ComputeResizeRequestStatusErrorErrorsErrorDetailsLocalizedMessage): any;
export declare class ComputeResizeRequestStatusErrorErrorsErrorDetailsLocalizedMessageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeResizeRequestStatusErrorErrorsErrorDetailsLocalizedMessage | undefined;
    set internalValue(value: ComputeResizeRequestStatusErrorErrorsErrorDetailsLocalizedMessage | undefined);
    get locale(): string;
    get message(): string;
}
export declare class ComputeResizeRequestStatusErrorErrorsErrorDetailsLocalizedMessageList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeResizeRequestStatusErrorErrorsErrorDetailsLocalizedMessageOutputReference;
}
export interface ComputeResizeRequestStatusErrorErrorsErrorDetailsQuotaInfo {
}
export declare function computeResizeRequestStatusErrorErrorsErrorDetailsQuotaInfoToTerraform(struct?: ComputeResizeRequestStatusErrorErrorsErrorDetailsQuotaInfo): any;
export declare function computeResizeRequestStatusErrorErrorsErrorDetailsQuotaInfoToHclTerraform(struct?: ComputeResizeRequestStatusErrorErrorsErrorDetailsQuotaInfo): any;
export declare class ComputeResizeRequestStatusErrorErrorsErrorDetailsQuotaInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeResizeRequestStatusErrorErrorsErrorDetailsQuotaInfo | undefined;
    set internalValue(value: ComputeResizeRequestStatusErrorErrorsErrorDetailsQuotaInfo | undefined);
    private _dimensions;
    get dimensions(): cdktn.StringMap;
    get futureLimit(): number;
    get limit(): number;
    get limitName(): string;
    get metricName(): string;
    get rolloutStatus(): string;
}
export declare class ComputeResizeRequestStatusErrorErrorsErrorDetailsQuotaInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeResizeRequestStatusErrorErrorsErrorDetailsQuotaInfoOutputReference;
}
export interface ComputeResizeRequestStatusErrorErrorsErrorDetails {
}
export declare function computeResizeRequestStatusErrorErrorsErrorDetailsToTerraform(struct?: ComputeResizeRequestStatusErrorErrorsErrorDetails): any;
export declare function computeResizeRequestStatusErrorErrorsErrorDetailsToHclTerraform(struct?: ComputeResizeRequestStatusErrorErrorsErrorDetails): any;
export declare class ComputeResizeRequestStatusErrorErrorsErrorDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeResizeRequestStatusErrorErrorsErrorDetails | undefined;
    set internalValue(value: ComputeResizeRequestStatusErrorErrorsErrorDetails | undefined);
    private _errorInfo;
    get errorInfo(): ComputeResizeRequestStatusErrorErrorsErrorDetailsErrorInfoList;
    private _help;
    get help(): ComputeResizeRequestStatusErrorErrorsErrorDetailsHelpList;
    private _localizedMessage;
    get localizedMessage(): ComputeResizeRequestStatusErrorErrorsErrorDetailsLocalizedMessageList;
    private _quotaInfo;
    get quotaInfo(): ComputeResizeRequestStatusErrorErrorsErrorDetailsQuotaInfoList;
}
export declare class ComputeResizeRequestStatusErrorErrorsErrorDetailsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeResizeRequestStatusErrorErrorsErrorDetailsOutputReference;
}
export interface ComputeResizeRequestStatusErrorErrors {
}
export declare function computeResizeRequestStatusErrorErrorsToTerraform(struct?: ComputeResizeRequestStatusErrorErrors): any;
export declare function computeResizeRequestStatusErrorErrorsToHclTerraform(struct?: ComputeResizeRequestStatusErrorErrors): any;
export declare class ComputeResizeRequestStatusErrorErrorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeResizeRequestStatusErrorErrors | undefined;
    set internalValue(value: ComputeResizeRequestStatusErrorErrors | undefined);
    get code(): string;
    private _errorDetails;
    get errorDetails(): ComputeResizeRequestStatusErrorErrorsErrorDetailsList;
    get location(): string;
    get message(): string;
}
export declare class ComputeResizeRequestStatusErrorErrorsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeResizeRequestStatusErrorErrorsOutputReference;
}
export interface ComputeResizeRequestStatusError {
}
export declare function computeResizeRequestStatusErrorToTerraform(struct?: ComputeResizeRequestStatusError): any;
export declare function computeResizeRequestStatusErrorToHclTerraform(struct?: ComputeResizeRequestStatusError): any;
export declare class ComputeResizeRequestStatusErrorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeResizeRequestStatusError | undefined;
    set internalValue(value: ComputeResizeRequestStatusError | undefined);
    private _errors;
    get errors(): ComputeResizeRequestStatusErrorErrorsList;
}
export declare class ComputeResizeRequestStatusErrorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeResizeRequestStatusErrorOutputReference;
}
export interface ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsErrorInfo {
}
export declare function computeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsErrorInfoToTerraform(struct?: ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsErrorInfo): any;
export declare function computeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsErrorInfoToHclTerraform(struct?: ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsErrorInfo): any;
export declare class ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsErrorInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsErrorInfo | undefined;
    set internalValue(value: ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsErrorInfo | undefined);
    get domain(): string;
    private _metadatas;
    get metadatas(): cdktn.StringMap;
    get reason(): string;
}
export declare class ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsErrorInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsErrorInfoOutputReference;
}
export interface ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpLinks {
}
export declare function computeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpLinksToTerraform(struct?: ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpLinks): any;
export declare function computeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpLinksToHclTerraform(struct?: ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpLinks): any;
export declare class ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpLinksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpLinks | undefined;
    set internalValue(value: ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpLinks | undefined);
    get description(): string;
    get url(): string;
}
export declare class ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpLinksList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpLinksOutputReference;
}
export interface ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelp {
}
export declare function computeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpToTerraform(struct?: ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelp): any;
export declare function computeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpToHclTerraform(struct?: ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelp): any;
export declare class ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelp | undefined;
    set internalValue(value: ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelp | undefined);
    private _links;
    get links(): ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpLinksList;
}
export declare class ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpOutputReference;
}
export interface ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsLocalizedMessage {
}
export declare function computeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsLocalizedMessageToTerraform(struct?: ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsLocalizedMessage): any;
export declare function computeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsLocalizedMessageToHclTerraform(struct?: ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsLocalizedMessage): any;
export declare class ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsLocalizedMessageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsLocalizedMessage | undefined;
    set internalValue(value: ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsLocalizedMessage | undefined);
    get locale(): string;
    get message(): string;
}
export declare class ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsLocalizedMessageList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsLocalizedMessageOutputReference;
}
export interface ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsQuotaInfo {
}
export declare function computeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsQuotaInfoToTerraform(struct?: ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsQuotaInfo): any;
export declare function computeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsQuotaInfoToHclTerraform(struct?: ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsQuotaInfo): any;
export declare class ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsQuotaInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsQuotaInfo | undefined;
    set internalValue(value: ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsQuotaInfo | undefined);
    private _dimensions;
    get dimensions(): cdktn.StringMap;
    get futureLimit(): number;
    get limit(): number;
    get limitName(): string;
    get metricName(): string;
    get rolloutStatus(): string;
}
export declare class ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsQuotaInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsQuotaInfoOutputReference;
}
export interface ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetails {
}
export declare function computeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsToTerraform(struct?: ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetails): any;
export declare function computeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsToHclTerraform(struct?: ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetails): any;
export declare class ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetails | undefined;
    set internalValue(value: ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetails | undefined);
    private _errorInfo;
    get errorInfo(): ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsErrorInfoList;
    private _help;
    get help(): ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpList;
    private _localizedMessage;
    get localizedMessage(): ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsLocalizedMessageList;
    private _quotaInfo;
    get quotaInfo(): ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsQuotaInfoList;
}
export declare class ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsOutputReference;
}
export interface ComputeResizeRequestStatusLastAttemptErrorErrors {
}
export declare function computeResizeRequestStatusLastAttemptErrorErrorsToTerraform(struct?: ComputeResizeRequestStatusLastAttemptErrorErrors): any;
export declare function computeResizeRequestStatusLastAttemptErrorErrorsToHclTerraform(struct?: ComputeResizeRequestStatusLastAttemptErrorErrors): any;
export declare class ComputeResizeRequestStatusLastAttemptErrorErrorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeResizeRequestStatusLastAttemptErrorErrors | undefined;
    set internalValue(value: ComputeResizeRequestStatusLastAttemptErrorErrors | undefined);
    get code(): string;
    private _errorDetails;
    get errorDetails(): ComputeResizeRequestStatusLastAttemptErrorErrorsErrorDetailsList;
    get location(): string;
    get message(): string;
}
export declare class ComputeResizeRequestStatusLastAttemptErrorErrorsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeResizeRequestStatusLastAttemptErrorErrorsOutputReference;
}
export interface ComputeResizeRequestStatusLastAttemptError {
}
export declare function computeResizeRequestStatusLastAttemptErrorToTerraform(struct?: ComputeResizeRequestStatusLastAttemptError): any;
export declare function computeResizeRequestStatusLastAttemptErrorToHclTerraform(struct?: ComputeResizeRequestStatusLastAttemptError): any;
export declare class ComputeResizeRequestStatusLastAttemptErrorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeResizeRequestStatusLastAttemptError | undefined;
    set internalValue(value: ComputeResizeRequestStatusLastAttemptError | undefined);
    private _errors;
    get errors(): ComputeResizeRequestStatusLastAttemptErrorErrorsList;
}
export declare class ComputeResizeRequestStatusLastAttemptErrorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeResizeRequestStatusLastAttemptErrorOutputReference;
}
export interface ComputeResizeRequestStatusLastAttempt {
}
export declare function computeResizeRequestStatusLastAttemptToTerraform(struct?: ComputeResizeRequestStatusLastAttempt): any;
export declare function computeResizeRequestStatusLastAttemptToHclTerraform(struct?: ComputeResizeRequestStatusLastAttempt): any;
export declare class ComputeResizeRequestStatusLastAttemptOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeResizeRequestStatusLastAttempt | undefined;
    set internalValue(value: ComputeResizeRequestStatusLastAttempt | undefined);
    private _error;
    get error(): ComputeResizeRequestStatusLastAttemptErrorList;
}
export declare class ComputeResizeRequestStatusLastAttemptList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeResizeRequestStatusLastAttemptOutputReference;
}
export interface ComputeResizeRequestStatus {
}
export declare function computeResizeRequestStatusToTerraform(struct?: ComputeResizeRequestStatus): any;
export declare function computeResizeRequestStatusToHclTerraform(struct?: ComputeResizeRequestStatus): any;
export declare class ComputeResizeRequestStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeResizeRequestStatus | undefined;
    set internalValue(value: ComputeResizeRequestStatus | undefined);
    private _error;
    get error(): ComputeResizeRequestStatusErrorList;
    private _lastAttempt;
    get lastAttempt(): ComputeResizeRequestStatusLastAttemptList;
}
export declare class ComputeResizeRequestStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeResizeRequestStatusOutputReference;
}
export interface ComputeResizeRequestRequestedRunDuration {
    /**
    * Span of time that's a fraction of a second at nanosecond resolution. Durations less than one second are represented with a 0 seconds field and a positive nanos field. Must be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_resize_request#nanos ComputeResizeRequest#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second. Must be from 600 to 604800 inclusive. Note: minimum and maximum allowed range for requestedRunDuration is 10 minutes (600 seconds) and 7 days(604800 seconds) correspondingly.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_resize_request#seconds ComputeResizeRequest#seconds}
    */
    readonly seconds: string;
}
export declare function computeResizeRequestRequestedRunDurationToTerraform(struct?: ComputeResizeRequestRequestedRunDurationOutputReference | ComputeResizeRequestRequestedRunDuration): any;
export declare function computeResizeRequestRequestedRunDurationToHclTerraform(struct?: ComputeResizeRequestRequestedRunDurationOutputReference | ComputeResizeRequestRequestedRunDuration): any;
export declare class ComputeResizeRequestRequestedRunDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeResizeRequestRequestedRunDuration | undefined;
    set internalValue(value: ComputeResizeRequestRequestedRunDuration | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): string;
    set seconds(value: string);
    get secondsInput(): string | undefined;
}
export interface ComputeResizeRequestTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_resize_request#create ComputeResizeRequest#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_resize_request#delete ComputeResizeRequest#delete}
    */
    readonly delete?: string;
}
export declare function computeResizeRequestTimeoutsToTerraform(struct?: ComputeResizeRequestTimeouts | cdktn.IResolvable): any;
export declare function computeResizeRequestTimeoutsToHclTerraform(struct?: ComputeResizeRequestTimeouts | cdktn.IResolvable): any;
export declare class ComputeResizeRequestTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeResizeRequestTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeResizeRequestTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_resize_request google_compute_resize_request}
*/
export declare class ComputeResizeRequest extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_resize_request";
    /**
    * Generates CDKTN code for importing a ComputeResizeRequest resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeResizeRequest to import
    * @param importFromId The id of the existing ComputeResizeRequest that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_resize_request#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeResizeRequest to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_resize_request google_compute_resize_request} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeResizeRequestConfig
    */
    constructor(scope: Construct, id: string, config: ComputeResizeRequestConfig);
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceGroupManager?;
    get instanceGroupManager(): string;
    set instanceGroupManager(value: string);
    get instanceGroupManagerInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _resizeBy?;
    get resizeBy(): number;
    set resizeBy(value: number);
    get resizeByInput(): number | undefined;
    get state(): string;
    private _status;
    get status(): ComputeResizeRequestStatusList;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    resetZone(): void;
    get zoneInput(): string | undefined;
    private _requestedRunDuration;
    get requestedRunDuration(): ComputeResizeRequestRequestedRunDurationOutputReference;
    putRequestedRunDuration(value: ComputeResizeRequestRequestedRunDuration): void;
    resetRequestedRunDuration(): void;
    get requestedRunDurationInput(): ComputeResizeRequestRequestedRunDuration | undefined;
    private _timeouts;
    get timeouts(): ComputeResizeRequestTimeoutsOutputReference;
    putTimeouts(value: ComputeResizeRequestTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeResizeRequestTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
