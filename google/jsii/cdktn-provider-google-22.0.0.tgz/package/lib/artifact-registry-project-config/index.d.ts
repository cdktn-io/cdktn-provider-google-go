/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ArtifactRegistryProjectConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_project_config#id ArtifactRegistryProjectConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the location this config is located in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_project_config#location ArtifactRegistryProjectConfig#location}
    */
    readonly location?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_project_config#project ArtifactRegistryProjectConfig#project}
    */
    readonly project?: string;
    /**
    * platform_logs_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_project_config#platform_logs_config ArtifactRegistryProjectConfig#platform_logs_config}
    */
    readonly platformLogsConfig?: ArtifactRegistryProjectConfigPlatformLogsConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_project_config#timeouts ArtifactRegistryProjectConfig#timeouts}
    */
    readonly timeouts?: ArtifactRegistryProjectConfigTimeouts;
}
export interface ArtifactRegistryProjectConfigPlatformLogsConfig {
    /**
    * The state of the platform logs: enabled or disabled. Possible values: ["ENABLED", "DISABLED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_project_config#logging_state ArtifactRegistryProjectConfig#logging_state}
    */
    readonly loggingState?: string;
    /**
    * The severity level for the logs. Logs will be generated if their
    * severity level is >= than the value of the severity level mentioned here. Possible values: ["DEBUG", "INFO", "NOTICE", "WARNING", "ERROR", "CRITICAL", "ALERT", "EMERGENCY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_project_config#severity_level ArtifactRegistryProjectConfig#severity_level}
    */
    readonly severityLevel?: string;
}
export declare function artifactRegistryProjectConfigPlatformLogsConfigToTerraform(struct?: ArtifactRegistryProjectConfigPlatformLogsConfigOutputReference | ArtifactRegistryProjectConfigPlatformLogsConfig): any;
export declare function artifactRegistryProjectConfigPlatformLogsConfigToHclTerraform(struct?: ArtifactRegistryProjectConfigPlatformLogsConfigOutputReference | ArtifactRegistryProjectConfigPlatformLogsConfig): any;
export declare class ArtifactRegistryProjectConfigPlatformLogsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryProjectConfigPlatformLogsConfig | undefined;
    set internalValue(value: ArtifactRegistryProjectConfigPlatformLogsConfig | undefined);
    private _loggingState?;
    get loggingState(): string;
    set loggingState(value: string);
    resetLoggingState(): void;
    get loggingStateInput(): string | undefined;
    private _severityLevel?;
    get severityLevel(): string;
    set severityLevel(value: string);
    resetSeverityLevel(): void;
    get severityLevelInput(): string | undefined;
}
export interface ArtifactRegistryProjectConfigTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_project_config#create ArtifactRegistryProjectConfig#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_project_config#delete ArtifactRegistryProjectConfig#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_project_config#update ArtifactRegistryProjectConfig#update}
    */
    readonly update?: string;
}
export declare function artifactRegistryProjectConfigTimeoutsToTerraform(struct?: ArtifactRegistryProjectConfigTimeouts | cdktn.IResolvable): any;
export declare function artifactRegistryProjectConfigTimeoutsToHclTerraform(struct?: ArtifactRegistryProjectConfigTimeouts | cdktn.IResolvable): any;
export declare class ArtifactRegistryProjectConfigTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryProjectConfigTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ArtifactRegistryProjectConfigTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_project_config google_artifact_registry_project_config}
*/
export declare class ArtifactRegistryProjectConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_artifact_registry_project_config";
    /**
    * Generates CDKTN code for importing a ArtifactRegistryProjectConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ArtifactRegistryProjectConfig to import
    * @param importFromId The id of the existing ArtifactRegistryProjectConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_project_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ArtifactRegistryProjectConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/artifact_registry_project_config google_artifact_registry_project_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ArtifactRegistryProjectConfigConfig = {}
    */
    constructor(scope: Construct, id: string, config?: ArtifactRegistryProjectConfigConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _platformLogsConfig;
    get platformLogsConfig(): ArtifactRegistryProjectConfigPlatformLogsConfigOutputReference;
    putPlatformLogsConfig(value: ArtifactRegistryProjectConfigPlatformLogsConfig): void;
    resetPlatformLogsConfig(): void;
    get platformLogsConfigInput(): ArtifactRegistryProjectConfigPlatformLogsConfig | undefined;
    private _timeouts;
    get timeouts(): ArtifactRegistryProjectConfigTimeoutsOutputReference;
    putTimeouts(value: ArtifactRegistryProjectConfigTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ArtifactRegistryProjectConfigTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
