/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccessContextManagerServicePerimeterDryRunEgressPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy#deletion_policy AccessContextManagerServicePerimeterDryRunEgressPolicy#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy#id AccessContextManagerServicePerimeterDryRunEgressPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the Service Perimeter to add this resource to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy#perimeter AccessContextManagerServicePerimeterDryRunEgressPolicy#perimeter}
    */
    readonly perimeter: string;
    /**
    * Human readable title. Must be unique within the perimeter. Does not affect behavior.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy#title AccessContextManagerServicePerimeterDryRunEgressPolicy#title}
    */
    readonly title?: string;
    /**
    * egress_from block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy#egress_from AccessContextManagerServicePerimeterDryRunEgressPolicy#egress_from}
    */
    readonly egressFrom?: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFrom;
    /**
    * egress_to block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy#egress_to AccessContextManagerServicePerimeterDryRunEgressPolicy#egress_to}
    */
    readonly egressTo?: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressTo;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy#timeouts AccessContextManagerServicePerimeterDryRunEgressPolicy#timeouts}
    */
    readonly timeouts?: AccessContextManagerServicePerimeterDryRunEgressPolicyTimeouts;
}
export interface AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSourcesPscEndpoint {
    /**
    * The full resource name of the global forwarding rule that identifies a Private Service Connect endpoint.
    * Forwarding rule format: '//compute.googleapis.com/projects/{PROJECT_ID}/global/forwardingRules/{FORWARDING_RULE_ID}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy#forwarding_rule AccessContextManagerServicePerimeterDryRunEgressPolicy#forwarding_rule}
    */
    readonly forwardingRule?: string;
}
export declare function accessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSourcesPscEndpointToTerraform(struct?: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSourcesPscEndpointOutputReference | AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSourcesPscEndpoint): any;
export declare function accessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSourcesPscEndpointToHclTerraform(struct?: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSourcesPscEndpointOutputReference | AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSourcesPscEndpoint): any;
export declare class AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSourcesPscEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSourcesPscEndpoint | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSourcesPscEndpoint | undefined);
    private _forwardingRule?;
    get forwardingRule(): string;
    set forwardingRule(value: string);
    resetForwardingRule(): void;
    get forwardingRuleInput(): string | undefined;
}
export interface AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSources {
    /**
    * An AccessLevel resource name that allows resources outside the ServicePerimeter to be accessed from the inside.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy#access_level AccessContextManagerServicePerimeterDryRunEgressPolicy#access_level}
    */
    readonly accessLevel?: string;
    /**
    * A Google Cloud resource that is allowed to egress the perimeter.
    * Requests from these resources are allowed to access data outside the perimeter.
    * Projects, folders, and organizations are allowed.
    * Project format: 'projects/{project_number}'
    * Folder format: 'folders/{folder_number}'
    * Organization format: 'organizations/{organization_number}'
    * The resource may be in any Google Cloud organization, not just the
    * organization that the perimeter is defined in. '*' is not allowed, the
    * case of allowing all Google Cloud resources only is not supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy#resource AccessContextManagerServicePerimeterDryRunEgressPolicy#resource}
    */
    readonly resource?: string;
    /**
    * psc_endpoint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy#psc_endpoint AccessContextManagerServicePerimeterDryRunEgressPolicy#psc_endpoint}
    */
    readonly pscEndpoint?: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSourcesPscEndpoint;
}
export declare function accessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSourcesToTerraform(struct?: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSources | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSourcesToHclTerraform(struct?: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSources | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSources | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSources | cdktn.IResolvable | undefined);
    private _accessLevel?;
    get accessLevel(): string;
    set accessLevel(value: string);
    resetAccessLevel(): void;
    get accessLevelInput(): string | undefined;
    private _resource?;
    get resource(): string;
    set resource(value: string);
    resetResource(): void;
    get resourceInput(): string | undefined;
    private _pscEndpoint;
    get pscEndpoint(): AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSourcesPscEndpointOutputReference;
    putPscEndpoint(value: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSourcesPscEndpoint): void;
    resetPscEndpoint(): void;
    get pscEndpointInput(): AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSourcesPscEndpoint | undefined;
}
export declare class AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSourcesList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSourcesOutputReference;
}
export interface AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFrom {
    /**
    * Identities can be an individual user, service account, Google group,
    * or third-party identity. For third-party identity, only single identities
    * are supported and other identity types are not supported.The v1 identities
    * that have the prefix user, group and serviceAccount in
    * https://cloud.google.com/iam/docs/principal-identifiers#v1 are supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy#identities AccessContextManagerServicePerimeterDryRunEgressPolicy#identities}
    */
    readonly identities?: string[];
    /**
    * Specifies the type of identities that are allowed access to outside the
    * perimeter. If left unspecified, then members of 'identities' field will
    * be allowed access. Possible values: ["ANY_IDENTITY", "ANY_USER_ACCOUNT", "ANY_SERVICE_ACCOUNT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy#identity_type AccessContextManagerServicePerimeterDryRunEgressPolicy#identity_type}
    */
    readonly identityType?: string;
    /**
    * Whether to enforce traffic restrictions based on 'sources' field. If the 'sources' field is non-empty, then this field must be set to 'SOURCE_RESTRICTION_ENABLED'. Possible values: ["SOURCE_RESTRICTION_ENABLED", "SOURCE_RESTRICTION_DISABLED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy#source_restriction AccessContextManagerServicePerimeterDryRunEgressPolicy#source_restriction}
    */
    readonly sourceRestriction?: string;
    /**
    * sources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy#sources AccessContextManagerServicePerimeterDryRunEgressPolicy#sources}
    */
    readonly sources?: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSources[] | cdktn.IResolvable;
}
export declare function accessContextManagerServicePerimeterDryRunEgressPolicyEgressFromToTerraform(struct?: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromOutputReference | AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFrom): any;
export declare function accessContextManagerServicePerimeterDryRunEgressPolicyEgressFromToHclTerraform(struct?: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromOutputReference | AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFrom): any;
export declare class AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFrom | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFrom | undefined);
    private _identities?;
    get identities(): string[];
    set identities(value: string[]);
    resetIdentities(): void;
    get identitiesInput(): string[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
    private _sourceRestriction?;
    get sourceRestriction(): string;
    set sourceRestriction(value: string);
    resetSourceRestriction(): void;
    get sourceRestrictionInput(): string | undefined;
    private _sources;
    get sources(): AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSourcesList;
    putSources(value: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSources[] | cdktn.IResolvable): void;
    resetSources(): void;
    get sourcesInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromSources[] | undefined;
}
export interface AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperationsMethodSelectors {
    /**
    * Value for 'method' should be a valid method name for the corresponding
    * 'serviceName' in 'ApiOperation'. If '*' used as value for method,
    * then ALL methods and permissions are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy#method AccessContextManagerServicePerimeterDryRunEgressPolicy#method}
    */
    readonly method?: string;
    /**
    * Value for permission should be a valid Cloud IAM permission for the
    * corresponding 'serviceName' in 'ApiOperation'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy#permission AccessContextManagerServicePerimeterDryRunEgressPolicy#permission}
    */
    readonly permission?: string;
}
export declare function accessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperationsMethodSelectorsToTerraform(struct?: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperationsMethodSelectors | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperationsMethodSelectorsToHclTerraform(struct?: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperationsMethodSelectors | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperationsMethodSelectorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperationsMethodSelectors | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperationsMethodSelectors | cdktn.IResolvable | undefined);
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    resetPermission(): void;
    get permissionInput(): string | undefined;
}
export declare class AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperationsMethodSelectorsList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperationsMethodSelectors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperationsMethodSelectorsOutputReference;
}
export interface AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperations {
    /**
    * The name of the API whose methods or permissions the 'IngressPolicy' or
    * 'EgressPolicy' want to allow. A single 'ApiOperation' with serviceName
    * field set to '*' will allow all methods AND permissions for all services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy#service_name AccessContextManagerServicePerimeterDryRunEgressPolicy#service_name}
    */
    readonly serviceName?: string;
    /**
    * method_selectors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy#method_selectors AccessContextManagerServicePerimeterDryRunEgressPolicy#method_selectors}
    */
    readonly methodSelectors?: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperationsMethodSelectors[] | cdktn.IResolvable;
}
export declare function accessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperationsToTerraform(struct?: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperations | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperationsToHclTerraform(struct?: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperations | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperations | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperations | cdktn.IResolvable | undefined);
    private _serviceName?;
    get serviceName(): string;
    set serviceName(value: string);
    resetServiceName(): void;
    get serviceNameInput(): string | undefined;
    private _methodSelectors;
    get methodSelectors(): AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperationsMethodSelectorsList;
    putMethodSelectors(value: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperationsMethodSelectors[] | cdktn.IResolvable): void;
    resetMethodSelectors(): void;
    get methodSelectorsInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperationsMethodSelectors[] | undefined;
}
export declare class AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperationsList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperationsOutputReference;
}
export interface AccessContextManagerServicePerimeterDryRunEgressPolicyEgressTo {
    /**
    * A list of external resources that are allowed to be accessed. A request
    * matches if it contains an external resource in this list (Example:
    * s3://bucket/path). Currently '*' is not allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy#external_resources AccessContextManagerServicePerimeterDryRunEgressPolicy#external_resources}
    */
    readonly externalResources?: string[];
    /**
    * A list of resources, in the form 'projects/{project_number}',
    * 'folders/{folder_number}', or 'organizations/{organization_number}',
    * that match this to stanza. A request matches
    * if it contains a resource in this list. If * is specified for resources,
    * then this 'EgressTo' rule will authorize access to all resources outside
    * the perimeter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy#resources AccessContextManagerServicePerimeterDryRunEgressPolicy#resources}
    */
    readonly resources?: string[];
    /**
    * A list of IAM roles that represent the set of operations that the sources
    * specified in the corresponding 'EgressFrom'
    * are allowed to perform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy#roles AccessContextManagerServicePerimeterDryRunEgressPolicy#roles}
    */
    readonly roles?: string[];
    /**
    * operations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy#operations AccessContextManagerServicePerimeterDryRunEgressPolicy#operations}
    */
    readonly operations?: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperations[] | cdktn.IResolvable;
}
export declare function accessContextManagerServicePerimeterDryRunEgressPolicyEgressToToTerraform(struct?: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOutputReference | AccessContextManagerServicePerimeterDryRunEgressPolicyEgressTo): any;
export declare function accessContextManagerServicePerimeterDryRunEgressPolicyEgressToToHclTerraform(struct?: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOutputReference | AccessContextManagerServicePerimeterDryRunEgressPolicyEgressTo): any;
export declare class AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterDryRunEgressPolicyEgressTo | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressTo | undefined);
    private _externalResources?;
    get externalResources(): string[];
    set externalResources(value: string[]);
    resetExternalResources(): void;
    get externalResourcesInput(): string[] | undefined;
    private _resources?;
    get resources(): string[];
    set resources(value: string[]);
    resetResources(): void;
    get resourcesInput(): string[] | undefined;
    private _roles?;
    get roles(): string[];
    set roles(value: string[]);
    resetRoles(): void;
    get rolesInput(): string[] | undefined;
    private _operations;
    get operations(): AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperationsList;
    putOperations(value: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperations[] | cdktn.IResolvable): void;
    resetOperations(): void;
    get operationsInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOperations[] | undefined;
}
export interface AccessContextManagerServicePerimeterDryRunEgressPolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy#create AccessContextManagerServicePerimeterDryRunEgressPolicy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy#delete AccessContextManagerServicePerimeterDryRunEgressPolicy#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy#update AccessContextManagerServicePerimeterDryRunEgressPolicy#update}
    */
    readonly update?: string;
}
export declare function accessContextManagerServicePerimeterDryRunEgressPolicyTimeoutsToTerraform(struct?: AccessContextManagerServicePerimeterDryRunEgressPolicyTimeouts | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterDryRunEgressPolicyTimeoutsToHclTerraform(struct?: AccessContextManagerServicePerimeterDryRunEgressPolicyTimeouts | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterDryRunEgressPolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterDryRunEgressPolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterDryRunEgressPolicyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy google_access_context_manager_service_perimeter_dry_run_egress_policy}
*/
export declare class AccessContextManagerServicePerimeterDryRunEgressPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_access_context_manager_service_perimeter_dry_run_egress_policy";
    /**
    * Generates CDKTN code for importing a AccessContextManagerServicePerimeterDryRunEgressPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessContextManagerServicePerimeterDryRunEgressPolicy to import
    * @param importFromId The id of the existing AccessContextManagerServicePerimeterDryRunEgressPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessContextManagerServicePerimeterDryRunEgressPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_service_perimeter_dry_run_egress_policy google_access_context_manager_service_perimeter_dry_run_egress_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessContextManagerServicePerimeterDryRunEgressPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AccessContextManagerServicePerimeterDryRunEgressPolicyConfig);
    get accessPolicyId(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _perimeter?;
    get perimeter(): string;
    set perimeter(value: string);
    get perimeterInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _egressFrom;
    get egressFrom(): AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFromOutputReference;
    putEgressFrom(value: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFrom): void;
    resetEgressFrom(): void;
    get egressFromInput(): AccessContextManagerServicePerimeterDryRunEgressPolicyEgressFrom | undefined;
    private _egressTo;
    get egressTo(): AccessContextManagerServicePerimeterDryRunEgressPolicyEgressToOutputReference;
    putEgressTo(value: AccessContextManagerServicePerimeterDryRunEgressPolicyEgressTo): void;
    resetEgressTo(): void;
    get egressToInput(): AccessContextManagerServicePerimeterDryRunEgressPolicyEgressTo | undefined;
    private _timeouts;
    get timeouts(): AccessContextManagerServicePerimeterDryRunEgressPolicyTimeoutsOutputReference;
    putTimeouts(value: AccessContextManagerServicePerimeterDryRunEgressPolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterDryRunEgressPolicyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
