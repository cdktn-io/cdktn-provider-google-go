/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeImageConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#deletion_policy ComputeImage#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource. Provide this property when
    * you create the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#description ComputeImage#description}
    */
    readonly description?: string;
    /**
    * Size of the image when restored onto a persistent disk (in GB).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#disk_size_gb ComputeImage#disk_size_gb}
    */
    readonly diskSizeGb?: number;
    /**
    * The name of the image family to which this image belongs. You can
    * create disks by specifying an image family instead of a specific
    * image name. The image family always returns its latest image that is
    * not deprecated. The name of the image family must comply with
    * RFC1035.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#family ComputeImage#family}
    */
    readonly family?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#id ComputeImage#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Labels to apply to this Image.
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#labels ComputeImage#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Any applicable license URI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#licenses ComputeImage#licenses}
    */
    readonly licenses?: string[];
    /**
    * Name of the resource; provided by the client when the resource is
    * created. The name must be 1-63 characters long, and comply with
    * RFC1035. Specifically, the name must be 1-63 characters long and
    * match the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means
    * the first character must be a lowercase letter, and all following
    * characters must be a dash, lowercase letter, or digit, except the
    * last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#name ComputeImage#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#project ComputeImage#project}
    */
    readonly project?: string;
    /**
    * The source disk to create this image based on.
    * You must provide either this property or the
    * rawDisk.source property but not both to create an image.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#source_disk ComputeImage#source_disk}
    */
    readonly sourceDisk?: string;
    /**
    * URL of the source image used to create this image. In order to create an image, you must provide the full or partial
    * URL of one of the following:
    *
    * * The selfLink URL
    * * This property
    * * The rawDisk.source URL
    * * The sourceDisk URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#source_image ComputeImage#source_image}
    */
    readonly sourceImage?: string;
    /**
    * URL of the source snapshot used to create this image.
    *
    * In order to create an image, you must provide the full or partial URL of one of the following:
    *
    * * The selfLink URL
    * * This property
    * * The sourceImage URL
    * * The rawDisk.source URL
    * * The sourceDisk URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#source_snapshot ComputeImage#source_snapshot}
    */
    readonly sourceSnapshot?: string;
    /**
    * Cloud Storage bucket storage location of the image
    * (regional or multi-regional).
    * Reference link: https://cloud.google.com/compute/docs/reference/rest/v1/images
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#storage_locations ComputeImage#storage_locations}
    */
    readonly storageLocations?: string[];
    /**
    * guest_os_features block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#guest_os_features ComputeImage#guest_os_features}
    */
    readonly guestOsFeatures?: ComputeImageGuestOsFeatures[] | cdktn.IResolvable;
    /**
    * image_encryption_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#image_encryption_key ComputeImage#image_encryption_key}
    */
    readonly imageEncryptionKey?: ComputeImageImageEncryptionKey;
    /**
    * params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#params ComputeImage#params}
    */
    readonly params?: ComputeImageParams;
    /**
    * raw_disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#raw_disk ComputeImage#raw_disk}
    */
    readonly rawDisk?: ComputeImageRawDisk;
    /**
    * shielded_instance_initial_state block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#shielded_instance_initial_state ComputeImage#shielded_instance_initial_state}
    */
    readonly shieldedInstanceInitialState?: ComputeImageShieldedInstanceInitialState;
    /**
    * source_disk_encryption_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#source_disk_encryption_key ComputeImage#source_disk_encryption_key}
    */
    readonly sourceDiskEncryptionKey?: ComputeImageSourceDiskEncryptionKey;
    /**
    * source_image_encryption_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#source_image_encryption_key ComputeImage#source_image_encryption_key}
    */
    readonly sourceImageEncryptionKey?: ComputeImageSourceImageEncryptionKey;
    /**
    * source_snapshot_encryption_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#source_snapshot_encryption_key ComputeImage#source_snapshot_encryption_key}
    */
    readonly sourceSnapshotEncryptionKey?: ComputeImageSourceSnapshotEncryptionKey;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#timeouts ComputeImage#timeouts}
    */
    readonly timeouts?: ComputeImageTimeouts;
}
export interface ComputeImageGuestOsFeatures {
    /**
    * The type of supported feature. Read [Enabling guest operating system features](https://cloud.google.com/compute/docs/images/create-delete-deprecate-private-images#guest-os-features) to see a list of available options. Possible values: ["MULTI_IP_SUBNET", "SECURE_BOOT", "SEV_CAPABLE", "UEFI_COMPATIBLE", "VIRTIO_SCSI_MULTIQUEUE", "WINDOWS", "GVNIC", "IDPF", "SEV_LIVE_MIGRATABLE", "SEV_SNP_CAPABLE", "SUSPEND_RESUME_COMPATIBLE", "TDX_CAPABLE", "SEV_LIVE_MIGRATABLE_V2", "SNP_SVSM_CAPABLE", "SUSPEND_SAFE_FPR"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#type ComputeImage#type}
    */
    readonly type: string;
}
export declare function computeImageGuestOsFeaturesToTerraform(struct?: ComputeImageGuestOsFeatures | cdktn.IResolvable): any;
export declare function computeImageGuestOsFeaturesToHclTerraform(struct?: ComputeImageGuestOsFeatures | cdktn.IResolvable): any;
export declare class ComputeImageGuestOsFeaturesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeImageGuestOsFeatures | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeImageGuestOsFeatures | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class ComputeImageGuestOsFeaturesList extends cdktn.ComplexList {
    internalValue?: ComputeImageGuestOsFeatures[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeImageGuestOsFeaturesOutputReference;
}
export interface ComputeImageImageEncryptionKey {
    /**
    * The self link of the encryption key that is stored in Google Cloud
    * KMS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#kms_key_self_link ComputeImage#kms_key_self_link}
    */
    readonly kmsKeySelfLink?: string;
    /**
    * The service account being used for the encryption request for the
    * given KMS key. If absent, the Compute Engine default service
    * account is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#kms_key_service_account ComputeImage#kms_key_service_account}
    */
    readonly kmsKeyServiceAccount?: string;
    /**
    * Specifies a 256-bit customer-supplied encryption key, encoded in
    * RFC 4648 base64 to either encrypt or decrypt this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#raw_key ComputeImage#raw_key}
    */
    readonly rawKey?: string;
    /**
    * Specifies a 256-bit customer-supplied encryption key, encoded in
    * RFC 4648 base64 to either encrypt or decrypt this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#rsa_encrypted_key ComputeImage#rsa_encrypted_key}
    */
    readonly rsaEncryptedKey?: string;
}
export declare function computeImageImageEncryptionKeyToTerraform(struct?: ComputeImageImageEncryptionKeyOutputReference | ComputeImageImageEncryptionKey): any;
export declare function computeImageImageEncryptionKeyToHclTerraform(struct?: ComputeImageImageEncryptionKeyOutputReference | ComputeImageImageEncryptionKey): any;
export declare class ComputeImageImageEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeImageImageEncryptionKey | undefined;
    set internalValue(value: ComputeImageImageEncryptionKey | undefined);
    private _kmsKeySelfLink?;
    get kmsKeySelfLink(): string;
    set kmsKeySelfLink(value: string);
    resetKmsKeySelfLink(): void;
    get kmsKeySelfLinkInput(): string | undefined;
    private _kmsKeyServiceAccount?;
    get kmsKeyServiceAccount(): string;
    set kmsKeyServiceAccount(value: string);
    resetKmsKeyServiceAccount(): void;
    get kmsKeyServiceAccountInput(): string | undefined;
    private _rawKey?;
    get rawKey(): string;
    set rawKey(value: string);
    resetRawKey(): void;
    get rawKeyInput(): string | undefined;
    private _rsaEncryptedKey?;
    get rsaEncryptedKey(): string;
    set rsaEncryptedKey(value: string);
    resetRsaEncryptedKey(): void;
    get rsaEncryptedKeyInput(): string | undefined;
}
export interface ComputeImageParams {
    /**
    * Resource manager tags to be bound to the image. Tag keys and values have the
    * same definition as resource manager tags. Keys and values can be either in numeric format,
    * such as tagKeys/{tag_key_id} and tagValues/{tag_value_id} or in namespaced format such as
    * {org_id|projectId}/{tag_key_short_name} and {tag_value_short_name}. The field is ignored when empty.
    * The field is immutable and causes resource replacement when mutated. This field is only
    * set at create time and modifying this field after creation will trigger recreation.
    * To apply tags to an existing resource, see the google_tags_tag_binding resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#resource_manager_tags ComputeImage#resource_manager_tags}
    */
    readonly resourceManagerTags?: {
        [key: string]: string;
    };
}
export declare function computeImageParamsToTerraform(struct?: ComputeImageParamsOutputReference | ComputeImageParams): any;
export declare function computeImageParamsToHclTerraform(struct?: ComputeImageParamsOutputReference | ComputeImageParams): any;
export declare class ComputeImageParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeImageParams | undefined;
    set internalValue(value: ComputeImageParams | undefined);
    private _resourceManagerTags?;
    get resourceManagerTags(): {
        [key: string]: string;
    };
    set resourceManagerTags(value: {
        [key: string]: string;
    });
    resetResourceManagerTags(): void;
    get resourceManagerTagsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ComputeImageRawDisk {
    /**
    * The format used to encode and transmit the block device, which
    * should be TAR. This is just a container and transmission format
    * and not a runtime format. Provided by the client when the disk
    * image is created. Default value: "TAR" Possible values: ["TAR"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#container_type ComputeImage#container_type}
    */
    readonly containerType?: string;
    /**
    * An optional SHA1 checksum of the disk image before unpackaging.
    * This is provided by the client when the disk image is created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#sha1 ComputeImage#sha1}
    */
    readonly sha1?: string;
    /**
    * The full Google Cloud Storage URL where disk storage is stored
    * You must provide either this property or the sourceDisk property
    * but not both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#source ComputeImage#source}
    */
    readonly source: string;
}
export declare function computeImageRawDiskToTerraform(struct?: ComputeImageRawDiskOutputReference | ComputeImageRawDisk): any;
export declare function computeImageRawDiskToHclTerraform(struct?: ComputeImageRawDiskOutputReference | ComputeImageRawDisk): any;
export declare class ComputeImageRawDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeImageRawDisk | undefined;
    set internalValue(value: ComputeImageRawDisk | undefined);
    private _containerType?;
    get containerType(): string;
    set containerType(value: string);
    resetContainerType(): void;
    get containerTypeInput(): string | undefined;
    private _sha1?;
    get sha1(): string;
    set sha1(value: string);
    resetSha1(): void;
    get sha1Input(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
}
export interface ComputeImageShieldedInstanceInitialStateDbs {
    /**
    * The raw content in the secure keys file.
    *
    * A base64-encoded string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#content ComputeImage#content}
    */
    readonly content: string;
    /**
    * The file type of source file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#file_type ComputeImage#file_type}
    */
    readonly fileType?: string;
}
export declare function computeImageShieldedInstanceInitialStateDbsToTerraform(struct?: ComputeImageShieldedInstanceInitialStateDbs | cdktn.IResolvable): any;
export declare function computeImageShieldedInstanceInitialStateDbsToHclTerraform(struct?: ComputeImageShieldedInstanceInitialStateDbs | cdktn.IResolvable): any;
export declare class ComputeImageShieldedInstanceInitialStateDbsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeImageShieldedInstanceInitialStateDbs | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeImageShieldedInstanceInitialStateDbs | cdktn.IResolvable | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    private _fileType?;
    get fileType(): string;
    set fileType(value: string);
    resetFileType(): void;
    get fileTypeInput(): string | undefined;
}
export declare class ComputeImageShieldedInstanceInitialStateDbsList extends cdktn.ComplexList {
    internalValue?: ComputeImageShieldedInstanceInitialStateDbs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeImageShieldedInstanceInitialStateDbsOutputReference;
}
export interface ComputeImageShieldedInstanceInitialStateDbxs {
    /**
    * The raw content in the secure keys file.
    *
    * A base64-encoded string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#content ComputeImage#content}
    */
    readonly content: string;
    /**
    * The file type of source file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#file_type ComputeImage#file_type}
    */
    readonly fileType?: string;
}
export declare function computeImageShieldedInstanceInitialStateDbxsToTerraform(struct?: ComputeImageShieldedInstanceInitialStateDbxs | cdktn.IResolvable): any;
export declare function computeImageShieldedInstanceInitialStateDbxsToHclTerraform(struct?: ComputeImageShieldedInstanceInitialStateDbxs | cdktn.IResolvable): any;
export declare class ComputeImageShieldedInstanceInitialStateDbxsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeImageShieldedInstanceInitialStateDbxs | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeImageShieldedInstanceInitialStateDbxs | cdktn.IResolvable | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    private _fileType?;
    get fileType(): string;
    set fileType(value: string);
    resetFileType(): void;
    get fileTypeInput(): string | undefined;
}
export declare class ComputeImageShieldedInstanceInitialStateDbxsList extends cdktn.ComplexList {
    internalValue?: ComputeImageShieldedInstanceInitialStateDbxs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeImageShieldedInstanceInitialStateDbxsOutputReference;
}
export interface ComputeImageShieldedInstanceInitialStateKeks {
    /**
    * The raw content in the secure keys file.
    *
    * A base64-encoded string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#content ComputeImage#content}
    */
    readonly content: string;
    /**
    * The file type of source file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#file_type ComputeImage#file_type}
    */
    readonly fileType?: string;
}
export declare function computeImageShieldedInstanceInitialStateKeksToTerraform(struct?: ComputeImageShieldedInstanceInitialStateKeks | cdktn.IResolvable): any;
export declare function computeImageShieldedInstanceInitialStateKeksToHclTerraform(struct?: ComputeImageShieldedInstanceInitialStateKeks | cdktn.IResolvable): any;
export declare class ComputeImageShieldedInstanceInitialStateKeksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeImageShieldedInstanceInitialStateKeks | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeImageShieldedInstanceInitialStateKeks | cdktn.IResolvable | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    private _fileType?;
    get fileType(): string;
    set fileType(value: string);
    resetFileType(): void;
    get fileTypeInput(): string | undefined;
}
export declare class ComputeImageShieldedInstanceInitialStateKeksList extends cdktn.ComplexList {
    internalValue?: ComputeImageShieldedInstanceInitialStateKeks[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeImageShieldedInstanceInitialStateKeksOutputReference;
}
export interface ComputeImageShieldedInstanceInitialStatePk {
    /**
    * The raw content in the secure keys file.
    *
    * A base64-encoded string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#content ComputeImage#content}
    */
    readonly content: string;
    /**
    * The file type of source file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#file_type ComputeImage#file_type}
    */
    readonly fileType?: string;
}
export declare function computeImageShieldedInstanceInitialStatePkToTerraform(struct?: ComputeImageShieldedInstanceInitialStatePkOutputReference | ComputeImageShieldedInstanceInitialStatePk): any;
export declare function computeImageShieldedInstanceInitialStatePkToHclTerraform(struct?: ComputeImageShieldedInstanceInitialStatePkOutputReference | ComputeImageShieldedInstanceInitialStatePk): any;
export declare class ComputeImageShieldedInstanceInitialStatePkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeImageShieldedInstanceInitialStatePk | undefined;
    set internalValue(value: ComputeImageShieldedInstanceInitialStatePk | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    private _fileType?;
    get fileType(): string;
    set fileType(value: string);
    resetFileType(): void;
    get fileTypeInput(): string | undefined;
}
export interface ComputeImageShieldedInstanceInitialState {
    /**
    * dbs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#dbs ComputeImage#dbs}
    */
    readonly dbs?: ComputeImageShieldedInstanceInitialStateDbs[] | cdktn.IResolvable;
    /**
    * dbxs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#dbxs ComputeImage#dbxs}
    */
    readonly dbxs?: ComputeImageShieldedInstanceInitialStateDbxs[] | cdktn.IResolvable;
    /**
    * keks block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#keks ComputeImage#keks}
    */
    readonly keks?: ComputeImageShieldedInstanceInitialStateKeks[] | cdktn.IResolvable;
    /**
    * pk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#pk ComputeImage#pk}
    */
    readonly pk?: ComputeImageShieldedInstanceInitialStatePk;
}
export declare function computeImageShieldedInstanceInitialStateToTerraform(struct?: ComputeImageShieldedInstanceInitialStateOutputReference | ComputeImageShieldedInstanceInitialState): any;
export declare function computeImageShieldedInstanceInitialStateToHclTerraform(struct?: ComputeImageShieldedInstanceInitialStateOutputReference | ComputeImageShieldedInstanceInitialState): any;
export declare class ComputeImageShieldedInstanceInitialStateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeImageShieldedInstanceInitialState | undefined;
    set internalValue(value: ComputeImageShieldedInstanceInitialState | undefined);
    private _dbs;
    get dbs(): ComputeImageShieldedInstanceInitialStateDbsList;
    putDbs(value: ComputeImageShieldedInstanceInitialStateDbs[] | cdktn.IResolvable): void;
    resetDbs(): void;
    get dbsInput(): cdktn.IResolvable | ComputeImageShieldedInstanceInitialStateDbs[] | undefined;
    private _dbxs;
    get dbxs(): ComputeImageShieldedInstanceInitialStateDbxsList;
    putDbxs(value: ComputeImageShieldedInstanceInitialStateDbxs[] | cdktn.IResolvable): void;
    resetDbxs(): void;
    get dbxsInput(): cdktn.IResolvable | ComputeImageShieldedInstanceInitialStateDbxs[] | undefined;
    private _keks;
    get keks(): ComputeImageShieldedInstanceInitialStateKeksList;
    putKeks(value: ComputeImageShieldedInstanceInitialStateKeks[] | cdktn.IResolvable): void;
    resetKeks(): void;
    get keksInput(): cdktn.IResolvable | ComputeImageShieldedInstanceInitialStateKeks[] | undefined;
    private _pk;
    get pk(): ComputeImageShieldedInstanceInitialStatePkOutputReference;
    putPk(value: ComputeImageShieldedInstanceInitialStatePk): void;
    resetPk(): void;
    get pkInput(): ComputeImageShieldedInstanceInitialStatePk | undefined;
}
export interface ComputeImageSourceDiskEncryptionKey {
    /**
    * The self link of the encryption key used to decrypt this resource. Also called KmsKeyName
    * in the cloud console. Your project's Compute Engine System service account
    * ('service-{{PROJECT_NUMBER}}@compute-system.iam.gserviceaccount.com') must have
    * 'roles/cloudkms.cryptoKeyEncrypterDecrypter' to use this feature.
    * See https://cloud.google.com/compute/docs/disks/customer-managed-encryption#encrypt_a_new_persistent_disk_with_your_own_keys
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#kms_key_self_link ComputeImage#kms_key_self_link}
    */
    readonly kmsKeySelfLink?: string;
    /**
    * The service account being used for the encryption request for the
    * given KMS key. If absent, the Compute Engine default service
    * account is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#kms_key_service_account ComputeImage#kms_key_service_account}
    */
    readonly kmsKeyServiceAccount?: string;
    /**
    * Specifies a 256-bit customer-supplied encryption key, encoded in
    * RFC 4648 base64 to either encrypt or decrypt this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#raw_key ComputeImage#raw_key}
    */
    readonly rawKey?: string;
    /**
    * Specifies an RFC 4648 base64 encoded, RSA-wrapped 2048-bit
    * customer-supplied encryption key to either encrypt or decrypt
    * this resource. You can provide either the rawKey or the rsaEncryptedKey.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#rsa_encrypted_key ComputeImage#rsa_encrypted_key}
    */
    readonly rsaEncryptedKey?: string;
}
export declare function computeImageSourceDiskEncryptionKeyToTerraform(struct?: ComputeImageSourceDiskEncryptionKeyOutputReference | ComputeImageSourceDiskEncryptionKey): any;
export declare function computeImageSourceDiskEncryptionKeyToHclTerraform(struct?: ComputeImageSourceDiskEncryptionKeyOutputReference | ComputeImageSourceDiskEncryptionKey): any;
export declare class ComputeImageSourceDiskEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeImageSourceDiskEncryptionKey | undefined;
    set internalValue(value: ComputeImageSourceDiskEncryptionKey | undefined);
    private _kmsKeySelfLink?;
    get kmsKeySelfLink(): string;
    set kmsKeySelfLink(value: string);
    resetKmsKeySelfLink(): void;
    get kmsKeySelfLinkInput(): string | undefined;
    private _kmsKeyServiceAccount?;
    get kmsKeyServiceAccount(): string;
    set kmsKeyServiceAccount(value: string);
    resetKmsKeyServiceAccount(): void;
    get kmsKeyServiceAccountInput(): string | undefined;
    private _rawKey?;
    get rawKey(): string;
    set rawKey(value: string);
    resetRawKey(): void;
    get rawKeyInput(): string | undefined;
    private _rsaEncryptedKey?;
    get rsaEncryptedKey(): string;
    set rsaEncryptedKey(value: string);
    resetRsaEncryptedKey(): void;
    get rsaEncryptedKeyInput(): string | undefined;
}
export interface ComputeImageSourceImageEncryptionKey {
    /**
    * The self link of the encryption key used to decrypt this resource. Also called KmsKeyName
    * in the cloud console. Your project's Compute Engine System service account
    * ('service-{{PROJECT_NUMBER}}@compute-system.iam.gserviceaccount.com') must have
    * 'roles/cloudkms.cryptoKeyEncrypterDecrypter' to use this feature.
    * See https://cloud.google.com/compute/docs/disks/customer-managed-encryption#encrypt_a_new_persistent_disk_with_your_own_keys
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#kms_key_self_link ComputeImage#kms_key_self_link}
    */
    readonly kmsKeySelfLink?: string;
    /**
    * The service account being used for the encryption request for the
    * given KMS key. If absent, the Compute Engine default service
    * account is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#kms_key_service_account ComputeImage#kms_key_service_account}
    */
    readonly kmsKeyServiceAccount?: string;
    /**
    * Specifies a 256-bit customer-supplied encryption key, encoded in
    * RFC 4648 base64 to either encrypt or decrypt this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#raw_key ComputeImage#raw_key}
    */
    readonly rawKey?: string;
    /**
    * Specifies an RFC 4648 base64 encoded, RSA-wrapped 2048-bit
    * customer-supplied encryption key to either encrypt or decrypt
    * this resource. You can provide either the rawKey or the rsaEncryptedKey.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#rsa_encrypted_key ComputeImage#rsa_encrypted_key}
    */
    readonly rsaEncryptedKey?: string;
}
export declare function computeImageSourceImageEncryptionKeyToTerraform(struct?: ComputeImageSourceImageEncryptionKeyOutputReference | ComputeImageSourceImageEncryptionKey): any;
export declare function computeImageSourceImageEncryptionKeyToHclTerraform(struct?: ComputeImageSourceImageEncryptionKeyOutputReference | ComputeImageSourceImageEncryptionKey): any;
export declare class ComputeImageSourceImageEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeImageSourceImageEncryptionKey | undefined;
    set internalValue(value: ComputeImageSourceImageEncryptionKey | undefined);
    private _kmsKeySelfLink?;
    get kmsKeySelfLink(): string;
    set kmsKeySelfLink(value: string);
    resetKmsKeySelfLink(): void;
    get kmsKeySelfLinkInput(): string | undefined;
    private _kmsKeyServiceAccount?;
    get kmsKeyServiceAccount(): string;
    set kmsKeyServiceAccount(value: string);
    resetKmsKeyServiceAccount(): void;
    get kmsKeyServiceAccountInput(): string | undefined;
    private _rawKey?;
    get rawKey(): string;
    set rawKey(value: string);
    resetRawKey(): void;
    get rawKeyInput(): string | undefined;
    private _rsaEncryptedKey?;
    get rsaEncryptedKey(): string;
    set rsaEncryptedKey(value: string);
    resetRsaEncryptedKey(): void;
    get rsaEncryptedKeyInput(): string | undefined;
}
export interface ComputeImageSourceSnapshotEncryptionKey {
    /**
    * The self link of the encryption key used to decrypt this resource. Also called KmsKeyName
    * in the cloud console. Your project's Compute Engine System service account
    * ('service-{{PROJECT_NUMBER}}@compute-system.iam.gserviceaccount.com') must have
    * 'roles/cloudkms.cryptoKeyEncrypterDecrypter' to use this feature.
    * See https://cloud.google.com/compute/docs/disks/customer-managed-encryption#encrypt_a_new_persistent_disk_with_your_own_keys
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#kms_key_self_link ComputeImage#kms_key_self_link}
    */
    readonly kmsKeySelfLink?: string;
    /**
    * The service account being used for the encryption request for the
    * given KMS key. If absent, the Compute Engine default service
    * account is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#kms_key_service_account ComputeImage#kms_key_service_account}
    */
    readonly kmsKeyServiceAccount?: string;
    /**
    * Specifies a 256-bit customer-supplied encryption key, encoded in
    * RFC 4648 base64 to either encrypt or decrypt this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#raw_key ComputeImage#raw_key}
    */
    readonly rawKey?: string;
    /**
    * Specifies an RFC 4648 base64 encoded, RSA-wrapped 2048-bit
    * customer-supplied encryption key to either encrypt or decrypt
    * this resource. You can provide either the rawKey or the rsaEncryptedKey.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#rsa_encrypted_key ComputeImage#rsa_encrypted_key}
    */
    readonly rsaEncryptedKey?: string;
}
export declare function computeImageSourceSnapshotEncryptionKeyToTerraform(struct?: ComputeImageSourceSnapshotEncryptionKeyOutputReference | ComputeImageSourceSnapshotEncryptionKey): any;
export declare function computeImageSourceSnapshotEncryptionKeyToHclTerraform(struct?: ComputeImageSourceSnapshotEncryptionKeyOutputReference | ComputeImageSourceSnapshotEncryptionKey): any;
export declare class ComputeImageSourceSnapshotEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeImageSourceSnapshotEncryptionKey | undefined;
    set internalValue(value: ComputeImageSourceSnapshotEncryptionKey | undefined);
    private _kmsKeySelfLink?;
    get kmsKeySelfLink(): string;
    set kmsKeySelfLink(value: string);
    resetKmsKeySelfLink(): void;
    get kmsKeySelfLinkInput(): string | undefined;
    private _kmsKeyServiceAccount?;
    get kmsKeyServiceAccount(): string;
    set kmsKeyServiceAccount(value: string);
    resetKmsKeyServiceAccount(): void;
    get kmsKeyServiceAccountInput(): string | undefined;
    private _rawKey?;
    get rawKey(): string;
    set rawKey(value: string);
    resetRawKey(): void;
    get rawKeyInput(): string | undefined;
    private _rsaEncryptedKey?;
    get rsaEncryptedKey(): string;
    set rsaEncryptedKey(value: string);
    resetRsaEncryptedKey(): void;
    get rsaEncryptedKeyInput(): string | undefined;
}
export interface ComputeImageTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#create ComputeImage#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#delete ComputeImage#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#update ComputeImage#update}
    */
    readonly update?: string;
}
export declare function computeImageTimeoutsToTerraform(struct?: ComputeImageTimeouts | cdktn.IResolvable): any;
export declare function computeImageTimeoutsToHclTerraform(struct?: ComputeImageTimeouts | cdktn.IResolvable): any;
export declare class ComputeImageTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeImageTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeImageTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image google_compute_image}
*/
export declare class ComputeImage extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_image";
    /**
    * Generates CDKTN code for importing a ComputeImage resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeImage to import
    * @param importFromId The id of the existing ComputeImage that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeImage to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_image google_compute_image} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeImageConfig
    */
    constructor(scope: Construct, id: string, config: ComputeImageConfig);
    get archiveSizeBytes(): number;
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _diskSizeGb?;
    get diskSizeGb(): number;
    set diskSizeGb(value: number);
    resetDiskSizeGb(): void;
    get diskSizeGbInput(): number | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _family?;
    get family(): string;
    set family(value: string);
    resetFamily(): void;
    get familyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get labelFingerprint(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _licenses?;
    get licenses(): string[];
    set licenses(value: string[]);
    resetLicenses(): void;
    get licensesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get selfLink(): string;
    private _sourceDisk?;
    get sourceDisk(): string;
    set sourceDisk(value: string);
    resetSourceDisk(): void;
    get sourceDiskInput(): string | undefined;
    private _sourceImage?;
    get sourceImage(): string;
    set sourceImage(value: string);
    resetSourceImage(): void;
    get sourceImageInput(): string | undefined;
    private _sourceSnapshot?;
    get sourceSnapshot(): string;
    set sourceSnapshot(value: string);
    resetSourceSnapshot(): void;
    get sourceSnapshotInput(): string | undefined;
    private _storageLocations?;
    get storageLocations(): string[];
    set storageLocations(value: string[]);
    resetStorageLocations(): void;
    get storageLocationsInput(): string[] | undefined;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _guestOsFeatures;
    get guestOsFeatures(): ComputeImageGuestOsFeaturesList;
    putGuestOsFeatures(value: ComputeImageGuestOsFeatures[] | cdktn.IResolvable): void;
    resetGuestOsFeatures(): void;
    get guestOsFeaturesInput(): cdktn.IResolvable | ComputeImageGuestOsFeatures[] | undefined;
    private _imageEncryptionKey;
    get imageEncryptionKey(): ComputeImageImageEncryptionKeyOutputReference;
    putImageEncryptionKey(value: ComputeImageImageEncryptionKey): void;
    resetImageEncryptionKey(): void;
    get imageEncryptionKeyInput(): ComputeImageImageEncryptionKey | undefined;
    private _params;
    get params(): ComputeImageParamsOutputReference;
    putParams(value: ComputeImageParams): void;
    resetParams(): void;
    get paramsInput(): ComputeImageParams | undefined;
    private _rawDisk;
    get rawDisk(): ComputeImageRawDiskOutputReference;
    putRawDisk(value: ComputeImageRawDisk): void;
    resetRawDisk(): void;
    get rawDiskInput(): ComputeImageRawDisk | undefined;
    private _shieldedInstanceInitialState;
    get shieldedInstanceInitialState(): ComputeImageShieldedInstanceInitialStateOutputReference;
    putShieldedInstanceInitialState(value: ComputeImageShieldedInstanceInitialState): void;
    resetShieldedInstanceInitialState(): void;
    get shieldedInstanceInitialStateInput(): ComputeImageShieldedInstanceInitialState | undefined;
    private _sourceDiskEncryptionKey;
    get sourceDiskEncryptionKey(): ComputeImageSourceDiskEncryptionKeyOutputReference;
    putSourceDiskEncryptionKey(value: ComputeImageSourceDiskEncryptionKey): void;
    resetSourceDiskEncryptionKey(): void;
    get sourceDiskEncryptionKeyInput(): ComputeImageSourceDiskEncryptionKey | undefined;
    private _sourceImageEncryptionKey;
    get sourceImageEncryptionKey(): ComputeImageSourceImageEncryptionKeyOutputReference;
    putSourceImageEncryptionKey(value: ComputeImageSourceImageEncryptionKey): void;
    resetSourceImageEncryptionKey(): void;
    get sourceImageEncryptionKeyInput(): ComputeImageSourceImageEncryptionKey | undefined;
    private _sourceSnapshotEncryptionKey;
    get sourceSnapshotEncryptionKey(): ComputeImageSourceSnapshotEncryptionKeyOutputReference;
    putSourceSnapshotEncryptionKey(value: ComputeImageSourceSnapshotEncryptionKey): void;
    resetSourceSnapshotEncryptionKey(): void;
    get sourceSnapshotEncryptionKeyInput(): ComputeImageSourceSnapshotEncryptionKey | undefined;
    private _timeouts;
    get timeouts(): ComputeImageTimeoutsOutputReference;
    putTimeouts(value: ComputeImageTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeImageTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
