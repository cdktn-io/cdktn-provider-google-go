/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BiglakeHiveTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Hive catalog where the table is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#catalog BiglakeHiveTable#catalog}
    */
    readonly catalog: string;
    /**
    * The Hive database where the table is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#database BiglakeHiveTable#database}
    */
    readonly database: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#deletion_policy BiglakeHiveTable#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Description of the table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#description BiglakeHiveTable#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#id BiglakeHiveTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#name BiglakeHiveTable#name}
    */
    readonly name: string;
    /**
    * Additional parameters associated with the table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#parameters BiglakeHiveTable#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#project BiglakeHiveTable#project}
    */
    readonly project?: string;
    /**
    * Expanded view text for Hive views. Empty for non-view.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#view_expanded_text BiglakeHiveTable#view_expanded_text}
    */
    readonly viewExpandedText?: string;
    /**
    * Original view text for Hive views. Empty for non-view.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#view_original_text BiglakeHiveTable#view_original_text}
    */
    readonly viewOriginalText?: string;
    /**
    * partition_keys block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#partition_keys BiglakeHiveTable#partition_keys}
    */
    readonly partitionKeys?: BiglakeHiveTablePartitionKeys[] | cdktn.IResolvable;
    /**
    * storage_descriptor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#storage_descriptor BiglakeHiveTable#storage_descriptor}
    */
    readonly storageDescriptor: BiglakeHiveTableStorageDescriptor;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#timeouts BiglakeHiveTable#timeouts}
    */
    readonly timeouts?: BiglakeHiveTableTimeouts;
}
export interface BiglakeHiveTablePartitionKeys {
    /**
    * Comment of the field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#comment BiglakeHiveTable#comment}
    */
    readonly comment?: string;
    /**
    * Name of the field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#name BiglakeHiveTable#name}
    */
    readonly name: string;
    /**
    * Type of the field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#type BiglakeHiveTable#type}
    */
    readonly type: string;
}
export declare function biglakeHiveTablePartitionKeysToTerraform(struct?: BiglakeHiveTablePartitionKeys | cdktn.IResolvable): any;
export declare function biglakeHiveTablePartitionKeysToHclTerraform(struct?: BiglakeHiveTablePartitionKeys | cdktn.IResolvable): any;
export declare class BiglakeHiveTablePartitionKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BiglakeHiveTablePartitionKeys | cdktn.IResolvable | undefined;
    set internalValue(value: BiglakeHiveTablePartitionKeys | cdktn.IResolvable | undefined);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BiglakeHiveTablePartitionKeysList extends cdktn.ComplexList {
    internalValue?: BiglakeHiveTablePartitionKeys[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BiglakeHiveTablePartitionKeysOutputReference;
}
export interface BiglakeHiveTableStorageDescriptorColumns {
    /**
    * Comment of the field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#comment BiglakeHiveTable#comment}
    */
    readonly comment?: string;
    /**
    * Name of the field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#name BiglakeHiveTable#name}
    */
    readonly name: string;
    /**
    * Type of the field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#type BiglakeHiveTable#type}
    */
    readonly type: string;
}
export declare function biglakeHiveTableStorageDescriptorColumnsToTerraform(struct?: BiglakeHiveTableStorageDescriptorColumns | cdktn.IResolvable): any;
export declare function biglakeHiveTableStorageDescriptorColumnsToHclTerraform(struct?: BiglakeHiveTableStorageDescriptorColumns | cdktn.IResolvable): any;
export declare class BiglakeHiveTableStorageDescriptorColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BiglakeHiveTableStorageDescriptorColumns | cdktn.IResolvable | undefined;
    set internalValue(value: BiglakeHiveTableStorageDescriptorColumns | cdktn.IResolvable | undefined);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BiglakeHiveTableStorageDescriptorColumnsList extends cdktn.ComplexList {
    internalValue?: BiglakeHiveTableStorageDescriptorColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BiglakeHiveTableStorageDescriptorColumnsOutputReference;
}
export interface BiglakeHiveTableStorageDescriptorSerdeInfo {
    /**
    * Description of the SerDe.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#description BiglakeHiveTable#description}
    */
    readonly description?: string;
    /**
    * The fully qualified Java class name of the deserializer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#deserializer_class BiglakeHiveTable#deserializer_class}
    */
    readonly deserializerClass?: string;
    /**
    * Name of the SerDe, table name by default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#name BiglakeHiveTable#name}
    */
    readonly name: string;
    /**
    * Parameters of the SerDe.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#parameters BiglakeHiveTable#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * The SerDe type. Possible values: ["SERDE_TYPE_UNSPECIFIED", "HIVE", "SCHEMA_REGISTRY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#serde_type BiglakeHiveTable#serde_type}
    */
    readonly serdeType?: string;
    /**
    * The fully qualified Java class name of the serialization library.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#serialization_lib BiglakeHiveTable#serialization_lib}
    */
    readonly serializationLib: string;
    /**
    * The fully qualified Java class name of the serializer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#serializer_class BiglakeHiveTable#serializer_class}
    */
    readonly serializerClass?: string;
}
export declare function biglakeHiveTableStorageDescriptorSerdeInfoToTerraform(struct?: BiglakeHiveTableStorageDescriptorSerdeInfoOutputReference | BiglakeHiveTableStorageDescriptorSerdeInfo): any;
export declare function biglakeHiveTableStorageDescriptorSerdeInfoToHclTerraform(struct?: BiglakeHiveTableStorageDescriptorSerdeInfoOutputReference | BiglakeHiveTableStorageDescriptorSerdeInfo): any;
export declare class BiglakeHiveTableStorageDescriptorSerdeInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BiglakeHiveTableStorageDescriptorSerdeInfo | undefined;
    set internalValue(value: BiglakeHiveTableStorageDescriptorSerdeInfo | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _deserializerClass?;
    get deserializerClass(): string;
    set deserializerClass(value: string);
    resetDeserializerClass(): void;
    get deserializerClassInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _serdeType?;
    get serdeType(): string;
    set serdeType(value: string);
    resetSerdeType(): void;
    get serdeTypeInput(): string | undefined;
    private _serializationLib?;
    get serializationLib(): string;
    set serializationLib(value: string);
    get serializationLibInput(): string | undefined;
    private _serializerClass?;
    get serializerClass(): string;
    set serializerClass(value: string);
    resetSerializerClass(): void;
    get serializerClassInput(): string | undefined;
}
export interface BiglakeHiveTableStorageDescriptorSkewedInfoSkewedColValues {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#values BiglakeHiveTable#values}
    */
    readonly values: string[];
}
export declare function biglakeHiveTableStorageDescriptorSkewedInfoSkewedColValuesToTerraform(struct?: BiglakeHiveTableStorageDescriptorSkewedInfoSkewedColValues | cdktn.IResolvable): any;
export declare function biglakeHiveTableStorageDescriptorSkewedInfoSkewedColValuesToHclTerraform(struct?: BiglakeHiveTableStorageDescriptorSkewedInfoSkewedColValues | cdktn.IResolvable): any;
export declare class BiglakeHiveTableStorageDescriptorSkewedInfoSkewedColValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BiglakeHiveTableStorageDescriptorSkewedInfoSkewedColValues | cdktn.IResolvable | undefined;
    set internalValue(value: BiglakeHiveTableStorageDescriptorSkewedInfoSkewedColValues | cdktn.IResolvable | undefined);
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class BiglakeHiveTableStorageDescriptorSkewedInfoSkewedColValuesList extends cdktn.ComplexList {
    internalValue?: BiglakeHiveTableStorageDescriptorSkewedInfoSkewedColValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BiglakeHiveTableStorageDescriptorSkewedInfoSkewedColValuesOutputReference;
}
export interface BiglakeHiveTableStorageDescriptorSkewedInfoSkewedKeyValuesLocations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#location BiglakeHiveTable#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#values BiglakeHiveTable#values}
    */
    readonly values: string[];
}
export declare function biglakeHiveTableStorageDescriptorSkewedInfoSkewedKeyValuesLocationsToTerraform(struct?: BiglakeHiveTableStorageDescriptorSkewedInfoSkewedKeyValuesLocations | cdktn.IResolvable): any;
export declare function biglakeHiveTableStorageDescriptorSkewedInfoSkewedKeyValuesLocationsToHclTerraform(struct?: BiglakeHiveTableStorageDescriptorSkewedInfoSkewedKeyValuesLocations | cdktn.IResolvable): any;
export declare class BiglakeHiveTableStorageDescriptorSkewedInfoSkewedKeyValuesLocationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BiglakeHiveTableStorageDescriptorSkewedInfoSkewedKeyValuesLocations | cdktn.IResolvable | undefined;
    set internalValue(value: BiglakeHiveTableStorageDescriptorSkewedInfoSkewedKeyValuesLocations | cdktn.IResolvable | undefined);
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class BiglakeHiveTableStorageDescriptorSkewedInfoSkewedKeyValuesLocationsList extends cdktn.ComplexList {
    internalValue?: BiglakeHiveTableStorageDescriptorSkewedInfoSkewedKeyValuesLocations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BiglakeHiveTableStorageDescriptorSkewedInfoSkewedKeyValuesLocationsOutputReference;
}
export interface BiglakeHiveTableStorageDescriptorSkewedInfo {
    /**
    * The column names that are skewed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#skewed_col_names BiglakeHiveTable#skewed_col_names}
    */
    readonly skewedColNames: string[];
    /**
    * skewed_col_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#skewed_col_values BiglakeHiveTable#skewed_col_values}
    */
    readonly skewedColValues: BiglakeHiveTableStorageDescriptorSkewedInfoSkewedColValues[] | cdktn.IResolvable;
    /**
    * skewed_key_values_locations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#skewed_key_values_locations BiglakeHiveTable#skewed_key_values_locations}
    */
    readonly skewedKeyValuesLocations: BiglakeHiveTableStorageDescriptorSkewedInfoSkewedKeyValuesLocations[] | cdktn.IResolvable;
}
export declare function biglakeHiveTableStorageDescriptorSkewedInfoToTerraform(struct?: BiglakeHiveTableStorageDescriptorSkewedInfoOutputReference | BiglakeHiveTableStorageDescriptorSkewedInfo): any;
export declare function biglakeHiveTableStorageDescriptorSkewedInfoToHclTerraform(struct?: BiglakeHiveTableStorageDescriptorSkewedInfoOutputReference | BiglakeHiveTableStorageDescriptorSkewedInfo): any;
export declare class BiglakeHiveTableStorageDescriptorSkewedInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BiglakeHiveTableStorageDescriptorSkewedInfo | undefined;
    set internalValue(value: BiglakeHiveTableStorageDescriptorSkewedInfo | undefined);
    private _skewedColNames?;
    get skewedColNames(): string[];
    set skewedColNames(value: string[]);
    get skewedColNamesInput(): string[] | undefined;
    private _skewedColValues;
    get skewedColValues(): BiglakeHiveTableStorageDescriptorSkewedInfoSkewedColValuesList;
    putSkewedColValues(value: BiglakeHiveTableStorageDescriptorSkewedInfoSkewedColValues[] | cdktn.IResolvable): void;
    get skewedColValuesInput(): cdktn.IResolvable | BiglakeHiveTableStorageDescriptorSkewedInfoSkewedColValues[] | undefined;
    private _skewedKeyValuesLocations;
    get skewedKeyValuesLocations(): BiglakeHiveTableStorageDescriptorSkewedInfoSkewedKeyValuesLocationsList;
    putSkewedKeyValuesLocations(value: BiglakeHiveTableStorageDescriptorSkewedInfoSkewedKeyValuesLocations[] | cdktn.IResolvable): void;
    get skewedKeyValuesLocationsInput(): cdktn.IResolvable | BiglakeHiveTableStorageDescriptorSkewedInfoSkewedKeyValuesLocations[] | undefined;
}
export interface BiglakeHiveTableStorageDescriptorSortCols {
    /**
    * The column name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#col BiglakeHiveTable#col}
    */
    readonly col: string;
    /**
    * Sort order: 1 for Ascending, 0 for Descending.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#order BiglakeHiveTable#order}
    */
    readonly order: number;
}
export declare function biglakeHiveTableStorageDescriptorSortColsToTerraform(struct?: BiglakeHiveTableStorageDescriptorSortCols | cdktn.IResolvable): any;
export declare function biglakeHiveTableStorageDescriptorSortColsToHclTerraform(struct?: BiglakeHiveTableStorageDescriptorSortCols | cdktn.IResolvable): any;
export declare class BiglakeHiveTableStorageDescriptorSortColsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BiglakeHiveTableStorageDescriptorSortCols | cdktn.IResolvable | undefined;
    set internalValue(value: BiglakeHiveTableStorageDescriptorSortCols | cdktn.IResolvable | undefined);
    private _col?;
    get col(): string;
    set col(value: string);
    get colInput(): string | undefined;
    private _order?;
    get order(): number;
    set order(value: number);
    get orderInput(): number | undefined;
}
export declare class BiglakeHiveTableStorageDescriptorSortColsList extends cdktn.ComplexList {
    internalValue?: BiglakeHiveTableStorageDescriptorSortCols[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BiglakeHiveTableStorageDescriptorSortColsOutputReference;
}
export interface BiglakeHiveTableStorageDescriptor {
    /**
    * Reducer grouping columns, clustering columns, and bucketing columns.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#bucket_cols BiglakeHiveTable#bucket_cols}
    */
    readonly bucketCols?: string[];
    /**
    * Whether the table data is compressed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#compressed BiglakeHiveTable#compressed}
    */
    readonly compressed?: boolean | cdktn.IResolvable;
    /**
    * The fully qualified Java class name of the input format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#input_format BiglakeHiveTable#input_format}
    */
    readonly inputFormat?: string;
    /**
    * The Cloud Storage URI where the table data is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#location_uri BiglakeHiveTable#location_uri}
    */
    readonly locationUri?: string;
    /**
    * The number of buckets in the table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#num_buckets BiglakeHiveTable#num_buckets}
    */
    readonly numBuckets?: number;
    /**
    * The fully qualified Java class name of the output format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#output_format BiglakeHiveTable#output_format}
    */
    readonly outputFormat?: string;
    /**
    * Key-value pairs for the storage descriptor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#parameters BiglakeHiveTable#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Whether the table is stored as sub directories.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#stored_as_sub_dirs BiglakeHiveTable#stored_as_sub_dirs}
    */
    readonly storedAsSubDirs?: boolean | cdktn.IResolvable;
    /**
    * columns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#columns BiglakeHiveTable#columns}
    */
    readonly columns: BiglakeHiveTableStorageDescriptorColumns[] | cdktn.IResolvable;
    /**
    * serde_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#serde_info BiglakeHiveTable#serde_info}
    */
    readonly serdeInfo?: BiglakeHiveTableStorageDescriptorSerdeInfo;
    /**
    * skewed_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#skewed_info BiglakeHiveTable#skewed_info}
    */
    readonly skewedInfo?: BiglakeHiveTableStorageDescriptorSkewedInfo;
    /**
    * sort_cols block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#sort_cols BiglakeHiveTable#sort_cols}
    */
    readonly sortCols?: BiglakeHiveTableStorageDescriptorSortCols[] | cdktn.IResolvable;
}
export declare function biglakeHiveTableStorageDescriptorToTerraform(struct?: BiglakeHiveTableStorageDescriptorOutputReference | BiglakeHiveTableStorageDescriptor): any;
export declare function biglakeHiveTableStorageDescriptorToHclTerraform(struct?: BiglakeHiveTableStorageDescriptorOutputReference | BiglakeHiveTableStorageDescriptor): any;
export declare class BiglakeHiveTableStorageDescriptorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BiglakeHiveTableStorageDescriptor | undefined;
    set internalValue(value: BiglakeHiveTableStorageDescriptor | undefined);
    private _bucketCols?;
    get bucketCols(): string[];
    set bucketCols(value: string[]);
    resetBucketCols(): void;
    get bucketColsInput(): string[] | undefined;
    private _compressed?;
    get compressed(): boolean | cdktn.IResolvable;
    set compressed(value: boolean | cdktn.IResolvable);
    resetCompressed(): void;
    get compressedInput(): boolean | cdktn.IResolvable | undefined;
    private _inputFormat?;
    get inputFormat(): string;
    set inputFormat(value: string);
    resetInputFormat(): void;
    get inputFormatInput(): string | undefined;
    private _locationUri?;
    get locationUri(): string;
    set locationUri(value: string);
    resetLocationUri(): void;
    get locationUriInput(): string | undefined;
    private _numBuckets?;
    get numBuckets(): number;
    set numBuckets(value: number);
    resetNumBuckets(): void;
    get numBucketsInput(): number | undefined;
    private _outputFormat?;
    get outputFormat(): string;
    set outputFormat(value: string);
    resetOutputFormat(): void;
    get outputFormatInput(): string | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _storedAsSubDirs?;
    get storedAsSubDirs(): boolean | cdktn.IResolvable;
    set storedAsSubDirs(value: boolean | cdktn.IResolvable);
    resetStoredAsSubDirs(): void;
    get storedAsSubDirsInput(): boolean | cdktn.IResolvable | undefined;
    private _columns;
    get columns(): BiglakeHiveTableStorageDescriptorColumnsList;
    putColumns(value: BiglakeHiveTableStorageDescriptorColumns[] | cdktn.IResolvable): void;
    get columnsInput(): cdktn.IResolvable | BiglakeHiveTableStorageDescriptorColumns[] | undefined;
    private _serdeInfo;
    get serdeInfo(): BiglakeHiveTableStorageDescriptorSerdeInfoOutputReference;
    putSerdeInfo(value: BiglakeHiveTableStorageDescriptorSerdeInfo): void;
    resetSerdeInfo(): void;
    get serdeInfoInput(): BiglakeHiveTableStorageDescriptorSerdeInfo | undefined;
    private _skewedInfo;
    get skewedInfo(): BiglakeHiveTableStorageDescriptorSkewedInfoOutputReference;
    putSkewedInfo(value: BiglakeHiveTableStorageDescriptorSkewedInfo): void;
    resetSkewedInfo(): void;
    get skewedInfoInput(): BiglakeHiveTableStorageDescriptorSkewedInfo | undefined;
    private _sortCols;
    get sortCols(): BiglakeHiveTableStorageDescriptorSortColsList;
    putSortCols(value: BiglakeHiveTableStorageDescriptorSortCols[] | cdktn.IResolvable): void;
    resetSortCols(): void;
    get sortColsInput(): cdktn.IResolvable | BiglakeHiveTableStorageDescriptorSortCols[] | undefined;
}
export interface BiglakeHiveTableTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#create BiglakeHiveTable#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#delete BiglakeHiveTable#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#update BiglakeHiveTable#update}
    */
    readonly update?: string;
}
export declare function biglakeHiveTableTimeoutsToTerraform(struct?: BiglakeHiveTableTimeouts | cdktn.IResolvable): any;
export declare function biglakeHiveTableTimeoutsToHclTerraform(struct?: BiglakeHiveTableTimeouts | cdktn.IResolvable): any;
export declare class BiglakeHiveTableTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BiglakeHiveTableTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BiglakeHiveTableTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table google_biglake_hive_table}
*/
export declare class BiglakeHiveTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_biglake_hive_table";
    /**
    * Generates CDKTN code for importing a BiglakeHiveTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BiglakeHiveTable to import
    * @param importFromId The id of the existing BiglakeHiveTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BiglakeHiveTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/biglake_hive_table google_biglake_hive_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BiglakeHiveTableConfig
    */
    constructor(scope: Construct, id: string, config: BiglakeHiveTableConfig);
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    get catalogInput(): string | undefined;
    get createTime(): string;
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastAccessTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get tableType(): string;
    get updateTime(): string;
    private _viewExpandedText?;
    get viewExpandedText(): string;
    set viewExpandedText(value: string);
    resetViewExpandedText(): void;
    get viewExpandedTextInput(): string | undefined;
    private _viewOriginalText?;
    get viewOriginalText(): string;
    set viewOriginalText(value: string);
    resetViewOriginalText(): void;
    get viewOriginalTextInput(): string | undefined;
    private _partitionKeys;
    get partitionKeys(): BiglakeHiveTablePartitionKeysList;
    putPartitionKeys(value: BiglakeHiveTablePartitionKeys[] | cdktn.IResolvable): void;
    resetPartitionKeys(): void;
    get partitionKeysInput(): cdktn.IResolvable | BiglakeHiveTablePartitionKeys[] | undefined;
    private _storageDescriptor;
    get storageDescriptor(): BiglakeHiveTableStorageDescriptorOutputReference;
    putStorageDescriptor(value: BiglakeHiveTableStorageDescriptor): void;
    get storageDescriptorInput(): BiglakeHiveTableStorageDescriptor | undefined;
    private _timeouts;
    get timeouts(): BiglakeHiveTableTimeoutsOutputReference;
    putTimeouts(value: BiglakeHiveTableTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BiglakeHiveTableTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
