/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeRegionUrlMapConfig extends cdktn.TerraformMetaArguments {
    /**
    * The full or partial URL of the defaultService resource to which traffic is directed if
    * none of the hostRules match. If defaultRouteAction is additionally specified, advanced
    * routing actions like URL Rewrites, etc. take effect prior to sending the request to the
    * backend. However, if defaultService is specified, defaultRouteAction cannot contain any
    * weightedBackendServices. Conversely, if routeAction specifies any
    * weightedBackendServices, service must not be specified.  Only one of defaultService,
    * defaultUrlRedirect or defaultRouteAction.weightedBackendService must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#default_service ComputeRegionUrlMap#default_service}
    */
    readonly defaultService?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#deletion_policy ComputeRegionUrlMap#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource. Provide this property when
    * you create the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#description ComputeRegionUrlMap#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#id ComputeRegionUrlMap#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the resource. Provided by the client when the resource is
    * created. The name must be 1-63 characters long, and comply with
    * RFC1035. Specifically, the name must be 1-63 characters long and match
    * the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the
    * first character must be a lowercase letter, and all following
    * characters must be a dash, lowercase letter, or digit, except the last
    * character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#name ComputeRegionUrlMap#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#project ComputeRegionUrlMap#project}
    */
    readonly project?: string;
    /**
    * The Region in which the url map should reside.
    * If it is not provided, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#region ComputeRegionUrlMap#region}
    */
    readonly region?: string;
    /**
    * default_route_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#default_route_action ComputeRegionUrlMap#default_route_action}
    */
    readonly defaultRouteAction?: ComputeRegionUrlMapDefaultRouteAction;
    /**
    * default_url_redirect block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#default_url_redirect ComputeRegionUrlMap#default_url_redirect}
    */
    readonly defaultUrlRedirect?: ComputeRegionUrlMapDefaultUrlRedirect;
    /**
    * header_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_action ComputeRegionUrlMap#header_action}
    */
    readonly headerAction?: ComputeRegionUrlMapHeaderAction;
    /**
    * host_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#host_rule ComputeRegionUrlMap#host_rule}
    */
    readonly hostRule?: ComputeRegionUrlMapHostRule[] | cdktn.IResolvable;
    /**
    * path_matcher block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#path_matcher ComputeRegionUrlMap#path_matcher}
    */
    readonly pathMatcher?: ComputeRegionUrlMapPathMatcher[] | cdktn.IResolvable;
    /**
    * test block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#test ComputeRegionUrlMap#test}
    */
    readonly test?: ComputeRegionUrlMapTest[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#timeouts ComputeRegionUrlMap#timeouts}
    */
    readonly timeouts?: ComputeRegionUrlMapTimeouts;
}
export interface ComputeRegionUrlMapDefaultRouteActionCorsPolicy {
    /**
    * In response to a preflight request, setting this to true indicates that the actual request can include user credentials. This field translates to the Access-Control-Allow-Credentials header.
    * Default is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#allow_credentials ComputeRegionUrlMap#allow_credentials}
    */
    readonly allowCredentials?: boolean | cdktn.IResolvable;
    /**
    * Specifies the content for the Access-Control-Allow-Headers header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#allow_headers ComputeRegionUrlMap#allow_headers}
    */
    readonly allowHeaders?: string[];
    /**
    * Specifies the content for the Access-Control-Allow-Methods header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#allow_methods ComputeRegionUrlMap#allow_methods}
    */
    readonly allowMethods?: string[];
    /**
    * Specifies the regualar expression patterns that match allowed origins. For regular expression grammar
    * please see en.cppreference.com/w/cpp/regex/ecmascript
    * An origin is allowed if it matches either an item in allowOrigins or an item in allowOriginRegexes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#allow_origin_regexes ComputeRegionUrlMap#allow_origin_regexes}
    */
    readonly allowOriginRegexes?: string[];
    /**
    * Specifies the list of origins that will be allowed to do CORS requests.
    * An origin is allowed if it matches either an item in allowOrigins or an item in allowOriginRegexes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#allow_origins ComputeRegionUrlMap#allow_origins}
    */
    readonly allowOrigins?: string[];
    /**
    * If true, the setting specifies the CORS policy is disabled. The default value of false, which indicates that the CORS policy is in effect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#disabled ComputeRegionUrlMap#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Specifies the content for the Access-Control-Expose-Headers header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#expose_headers ComputeRegionUrlMap#expose_headers}
    */
    readonly exposeHeaders?: string[];
    /**
    * Specifies how long results of a preflight request can be cached in seconds.
    * This translates to the Access-Control-Max-Age header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#max_age ComputeRegionUrlMap#max_age}
    */
    readonly maxAge?: number;
}
export declare function computeRegionUrlMapDefaultRouteActionCorsPolicyToTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionCorsPolicyOutputReference | ComputeRegionUrlMapDefaultRouteActionCorsPolicy): any;
export declare function computeRegionUrlMapDefaultRouteActionCorsPolicyToHclTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionCorsPolicyOutputReference | ComputeRegionUrlMapDefaultRouteActionCorsPolicy): any;
export declare class ComputeRegionUrlMapDefaultRouteActionCorsPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapDefaultRouteActionCorsPolicy | undefined;
    set internalValue(value: ComputeRegionUrlMapDefaultRouteActionCorsPolicy | undefined);
    private _allowCredentials?;
    get allowCredentials(): boolean | cdktn.IResolvable;
    set allowCredentials(value: boolean | cdktn.IResolvable);
    resetAllowCredentials(): void;
    get allowCredentialsInput(): boolean | cdktn.IResolvable | undefined;
    private _allowHeaders?;
    get allowHeaders(): string[];
    set allowHeaders(value: string[]);
    resetAllowHeaders(): void;
    get allowHeadersInput(): string[] | undefined;
    private _allowMethods?;
    get allowMethods(): string[];
    set allowMethods(value: string[]);
    resetAllowMethods(): void;
    get allowMethodsInput(): string[] | undefined;
    private _allowOriginRegexes?;
    get allowOriginRegexes(): string[];
    set allowOriginRegexes(value: string[]);
    resetAllowOriginRegexes(): void;
    get allowOriginRegexesInput(): string[] | undefined;
    private _allowOrigins?;
    get allowOrigins(): string[];
    set allowOrigins(value: string[]);
    resetAllowOrigins(): void;
    get allowOriginsInput(): string[] | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _exposeHeaders?;
    get exposeHeaders(): string[];
    set exposeHeaders(value: string[]);
    resetExposeHeaders(): void;
    get exposeHeadersInput(): string[] | undefined;
    private _maxAge?;
    get maxAge(): number;
    set maxAge(value: number);
    resetMaxAge(): void;
    get maxAgeInput(): number | undefined;
}
export interface ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyAbort {
    /**
    * The HTTP status code used to abort the request.
    * The value must be between 200 and 599 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#http_status ComputeRegionUrlMap#http_status}
    */
    readonly httpStatus?: number;
    /**
    * The percentage of traffic (connections/operations/requests) which will be aborted as part of fault injection.
    * The value must be between 0.0 and 100.0 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#percentage ComputeRegionUrlMap#percentage}
    */
    readonly percentage?: number;
}
export declare function computeRegionUrlMapDefaultRouteActionFaultInjectionPolicyAbortToTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyAbortOutputReference | ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyAbort): any;
export declare function computeRegionUrlMapDefaultRouteActionFaultInjectionPolicyAbortToHclTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyAbortOutputReference | ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyAbort): any;
export declare class ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyAbortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyAbort | undefined;
    set internalValue(value: ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyAbort | undefined);
    private _httpStatus?;
    get httpStatus(): number;
    set httpStatus(value: number);
    resetHttpStatus(): void;
    get httpStatusInput(): number | undefined;
    private _percentage?;
    get percentage(): number;
    set percentage(value: number);
    resetPercentage(): void;
    get percentageInput(): number | undefined;
}
export interface ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelayFixedDelay {
    /**
    * Span of time that's a fraction of a second at nanosecond resolution. Durations less than one second are
    * represented with a 0 seconds field and a positive nanos field. Must be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#nanos ComputeRegionUrlMap#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second. Must be from 0 to 315,576,000,000 inclusive.
    * Note: these bounds are computed from: 60 sec/min * 60 min/hr * 24 hr/day * 365.25 days/year * 10000 years
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#seconds ComputeRegionUrlMap#seconds}
    */
    readonly seconds?: string;
}
export declare function computeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelayFixedDelayToTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelayFixedDelayOutputReference | ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelayFixedDelay): any;
export declare function computeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelayFixedDelayToHclTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelayFixedDelayOutputReference | ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelayFixedDelay): any;
export declare class ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelayFixedDelayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelayFixedDelay | undefined;
    set internalValue(value: ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelayFixedDelay | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): string;
    set seconds(value: string);
    resetSeconds(): void;
    get secondsInput(): string | undefined;
}
export interface ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelay {
    /**
    * The percentage of traffic (connections/operations/requests) on which delay will be introduced as part of fault injection.
    * The value must be between 0.0 and 100.0 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#percentage ComputeRegionUrlMap#percentage}
    */
    readonly percentage?: number;
    /**
    * fixed_delay block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#fixed_delay ComputeRegionUrlMap#fixed_delay}
    */
    readonly fixedDelay?: ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelayFixedDelay;
}
export declare function computeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelayToTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelayOutputReference | ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelay): any;
export declare function computeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelayToHclTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelayOutputReference | ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelay): any;
export declare class ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelay | undefined;
    set internalValue(value: ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelay | undefined);
    private _percentage?;
    get percentage(): number;
    set percentage(value: number);
    resetPercentage(): void;
    get percentageInput(): number | undefined;
    private _fixedDelay;
    get fixedDelay(): ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelayFixedDelayOutputReference;
    putFixedDelay(value: ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelayFixedDelay): void;
    resetFixedDelay(): void;
    get fixedDelayInput(): ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelayFixedDelay | undefined;
}
export interface ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicy {
    /**
    * abort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#abort ComputeRegionUrlMap#abort}
    */
    readonly abort?: ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyAbort;
    /**
    * delay block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#delay ComputeRegionUrlMap#delay}
    */
    readonly delay?: ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelay;
}
export declare function computeRegionUrlMapDefaultRouteActionFaultInjectionPolicyToTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyOutputReference | ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicy): any;
export declare function computeRegionUrlMapDefaultRouteActionFaultInjectionPolicyToHclTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyOutputReference | ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicy): any;
export declare class ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicy | undefined;
    set internalValue(value: ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicy | undefined);
    private _abort;
    get abort(): ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyAbortOutputReference;
    putAbort(value: ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyAbort): void;
    resetAbort(): void;
    get abortInput(): ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyAbort | undefined;
    private _delay;
    get delay(): ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelayOutputReference;
    putDelay(value: ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelay): void;
    resetDelay(): void;
    get delayInput(): ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyDelay | undefined;
}
export interface ComputeRegionUrlMapDefaultRouteActionRequestMirrorPolicy {
    /**
    * The full or partial URL to the RegionBackendService resource being mirrored to.
    * The backend service configured for a mirroring policy must reference backends that are of the same type as the original backend service matched in the URL map.
    * Serverless NEG backends are not currently supported as a mirrored backend service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#backend_service ComputeRegionUrlMap#backend_service}
    */
    readonly backendService?: string;
    /**
    * The percentage of requests to be mirrored to backendService.
    * The value must be between 0.0 and 100.0 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#mirror_percent ComputeRegionUrlMap#mirror_percent}
    */
    readonly mirrorPercent?: number;
}
export declare function computeRegionUrlMapDefaultRouteActionRequestMirrorPolicyToTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionRequestMirrorPolicyOutputReference | ComputeRegionUrlMapDefaultRouteActionRequestMirrorPolicy): any;
export declare function computeRegionUrlMapDefaultRouteActionRequestMirrorPolicyToHclTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionRequestMirrorPolicyOutputReference | ComputeRegionUrlMapDefaultRouteActionRequestMirrorPolicy): any;
export declare class ComputeRegionUrlMapDefaultRouteActionRequestMirrorPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapDefaultRouteActionRequestMirrorPolicy | undefined;
    set internalValue(value: ComputeRegionUrlMapDefaultRouteActionRequestMirrorPolicy | undefined);
    private _backendService?;
    get backendService(): string;
    set backendService(value: string);
    resetBackendService(): void;
    get backendServiceInput(): string | undefined;
    private _mirrorPercent?;
    get mirrorPercent(): number;
    set mirrorPercent(value: number);
    resetMirrorPercent(): void;
    get mirrorPercentInput(): number | undefined;
}
export interface ComputeRegionUrlMapDefaultRouteActionRetryPolicyPerTryTimeout {
    /**
    * Span of time that's a fraction of a second at nanosecond resolution. Durations less than one second are
    * represented with a 0 seconds field and a positive nanos field. Must be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#nanos ComputeRegionUrlMap#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second. Must be from 0 to 315,576,000,000 inclusive.
    * Note: these bounds are computed from: 60 sec/min * 60 min/hr * 24 hr/day * 365.25 days/year * 10000 years
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#seconds ComputeRegionUrlMap#seconds}
    */
    readonly seconds?: string;
}
export declare function computeRegionUrlMapDefaultRouteActionRetryPolicyPerTryTimeoutToTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionRetryPolicyPerTryTimeoutOutputReference | ComputeRegionUrlMapDefaultRouteActionRetryPolicyPerTryTimeout): any;
export declare function computeRegionUrlMapDefaultRouteActionRetryPolicyPerTryTimeoutToHclTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionRetryPolicyPerTryTimeoutOutputReference | ComputeRegionUrlMapDefaultRouteActionRetryPolicyPerTryTimeout): any;
export declare class ComputeRegionUrlMapDefaultRouteActionRetryPolicyPerTryTimeoutOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapDefaultRouteActionRetryPolicyPerTryTimeout | undefined;
    set internalValue(value: ComputeRegionUrlMapDefaultRouteActionRetryPolicyPerTryTimeout | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): string;
    set seconds(value: string);
    resetSeconds(): void;
    get secondsInput(): string | undefined;
}
export interface ComputeRegionUrlMapDefaultRouteActionRetryPolicy {
    /**
    * Specifies the allowed number retries. This number must be > 0. If not specified, defaults to 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#num_retries ComputeRegionUrlMap#num_retries}
    */
    readonly numRetries?: number;
    /**
    * Specifies one or more conditions when this retry policy applies.
    * Valid values are listed below. Only the following codes are supported when the URL map is bound to target gRPC proxy that has validateForProxyless field set to true: cancelled, deadline-exceeded, internal, resource-exhausted, unavailable.
    *   - 5xx : retry is attempted if the instance or endpoint responds with any 5xx response code, or if the instance or endpoint does not respond at all. For example, disconnects, reset, read timeout, connection failure, and refused streams.
    *   - gateway-error : Similar to 5xx, but only applies to response codes 502, 503 or 504.
    *   - connect-failure : a retry is attempted on failures connecting to the instance or endpoint. For example, connection timeouts.
    *   - retriable-4xx : a retry is attempted if the instance or endpoint responds with a 4xx response code. The only error that you can retry is error code 409.
    *   - refused-stream : a retry is attempted if the instance or endpoint resets the stream with a REFUSED_STREAM error code. This reset type indicates that it is safe to retry.
    *   - cancelled : a retry is attempted if the gRPC status code in the response header is set to cancelled.
    *   - deadline-exceeded : a retry is attempted if the gRPC status code in the response header is set to deadline-exceeded.
    *   - internal :  a retry is attempted if the gRPC status code in the response header is set to internal.
    *   - resource-exhausted : a retry is attempted if the gRPC status code in the response header is set to resource-exhausted.
    *   - unavailable : a retry is attempted if the gRPC status code in the response header is set to unavailable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#retry_conditions ComputeRegionUrlMap#retry_conditions}
    */
    readonly retryConditions?: string[];
    /**
    * per_try_timeout block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#per_try_timeout ComputeRegionUrlMap#per_try_timeout}
    */
    readonly perTryTimeout?: ComputeRegionUrlMapDefaultRouteActionRetryPolicyPerTryTimeout;
}
export declare function computeRegionUrlMapDefaultRouteActionRetryPolicyToTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionRetryPolicyOutputReference | ComputeRegionUrlMapDefaultRouteActionRetryPolicy): any;
export declare function computeRegionUrlMapDefaultRouteActionRetryPolicyToHclTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionRetryPolicyOutputReference | ComputeRegionUrlMapDefaultRouteActionRetryPolicy): any;
export declare class ComputeRegionUrlMapDefaultRouteActionRetryPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapDefaultRouteActionRetryPolicy | undefined;
    set internalValue(value: ComputeRegionUrlMapDefaultRouteActionRetryPolicy | undefined);
    private _numRetries?;
    get numRetries(): number;
    set numRetries(value: number);
    resetNumRetries(): void;
    get numRetriesInput(): number | undefined;
    private _retryConditions?;
    get retryConditions(): string[];
    set retryConditions(value: string[]);
    resetRetryConditions(): void;
    get retryConditionsInput(): string[] | undefined;
    private _perTryTimeout;
    get perTryTimeout(): ComputeRegionUrlMapDefaultRouteActionRetryPolicyPerTryTimeoutOutputReference;
    putPerTryTimeout(value: ComputeRegionUrlMapDefaultRouteActionRetryPolicyPerTryTimeout): void;
    resetPerTryTimeout(): void;
    get perTryTimeoutInput(): ComputeRegionUrlMapDefaultRouteActionRetryPolicyPerTryTimeout | undefined;
}
export interface ComputeRegionUrlMapDefaultRouteActionTimeout {
    /**
    * Span of time that's a fraction of a second at nanosecond resolution. Durations less than one second are represented with a 0 seconds field and a positive nanos field. Must be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#nanos ComputeRegionUrlMap#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second. Must be from 0 to 315,576,000,000 inclusive. Note: these bounds are computed from: 60 sec/min * 60 min/hr * 24 hr/day * 365.25 days/year * 10000 years
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#seconds ComputeRegionUrlMap#seconds}
    */
    readonly seconds?: string;
}
export declare function computeRegionUrlMapDefaultRouteActionTimeoutToTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionTimeoutOutputReference | ComputeRegionUrlMapDefaultRouteActionTimeout): any;
export declare function computeRegionUrlMapDefaultRouteActionTimeoutToHclTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionTimeoutOutputReference | ComputeRegionUrlMapDefaultRouteActionTimeout): any;
export declare class ComputeRegionUrlMapDefaultRouteActionTimeoutOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapDefaultRouteActionTimeout | undefined;
    set internalValue(value: ComputeRegionUrlMapDefaultRouteActionTimeout | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): string;
    set seconds(value: string);
    resetSeconds(): void;
    get secondsInput(): string | undefined;
}
export interface ComputeRegionUrlMapDefaultRouteActionUrlRewrite {
    /**
    * Before forwarding the request to the selected service, the request's host header is replaced with contents of hostRewrite.
    * The value must be from 1 to 255 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#host_rewrite ComputeRegionUrlMap#host_rewrite}
    */
    readonly hostRewrite?: string;
    /**
    * Before forwarding the request to the selected backend service, the matching portion of the request's path is replaced by pathPrefixRewrite.
    * The value must be from 1 to 1024 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#path_prefix_rewrite ComputeRegionUrlMap#path_prefix_rewrite}
    */
    readonly pathPrefixRewrite?: string;
}
export declare function computeRegionUrlMapDefaultRouteActionUrlRewriteToTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionUrlRewriteOutputReference | ComputeRegionUrlMapDefaultRouteActionUrlRewrite): any;
export declare function computeRegionUrlMapDefaultRouteActionUrlRewriteToHclTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionUrlRewriteOutputReference | ComputeRegionUrlMapDefaultRouteActionUrlRewrite): any;
export declare class ComputeRegionUrlMapDefaultRouteActionUrlRewriteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapDefaultRouteActionUrlRewrite | undefined;
    set internalValue(value: ComputeRegionUrlMapDefaultRouteActionUrlRewrite | undefined);
    private _hostRewrite?;
    get hostRewrite(): string;
    set hostRewrite(value: string);
    resetHostRewrite(): void;
    get hostRewriteInput(): string | undefined;
    private _pathPrefixRewrite?;
    get pathPrefixRewrite(): string;
    set pathPrefixRewrite(value: string);
    resetPathPrefixRewrite(): void;
    get pathPrefixRewriteInput(): string | undefined;
}
export interface ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd {
    /**
    * The name of the header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_name ComputeRegionUrlMap#header_name}
    */
    readonly headerName?: string;
    /**
    * The value of the header to add.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_value ComputeRegionUrlMap#header_value}
    */
    readonly headerValue?: string;
    /**
    * If false, headerValue is appended to any values that already exist for the header. If true, headerValue is set for the header, discarding any values that were set for that header.
    * The default value is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#replace ComputeRegionUrlMap#replace}
    */
    readonly replace?: boolean | cdktn.IResolvable;
}
export declare function computeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAddToTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd | cdktn.IResolvable): any;
export declare function computeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAddToHclTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAddOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    resetHeaderName(): void;
    get headerNameInput(): string | undefined;
    private _headerValue?;
    get headerValue(): string;
    set headerValue(value: string);
    resetHeaderValue(): void;
    get headerValueInput(): string | undefined;
    private _replace?;
    get replace(): boolean | cdktn.IResolvable;
    set replace(value: boolean | cdktn.IResolvable);
    resetReplace(): void;
    get replaceInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAddList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAddOutputReference;
}
export interface ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd {
    /**
    * The name of the header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_name ComputeRegionUrlMap#header_name}
    */
    readonly headerName?: string;
    /**
    * The value of the header to add.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_value ComputeRegionUrlMap#header_value}
    */
    readonly headerValue?: string;
    /**
    * If false, headerValue is appended to any values that already exist for the header. If true, headerValue is set for the header, discarding any values that were set for that header.
    * The default value is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#replace ComputeRegionUrlMap#replace}
    */
    readonly replace?: boolean | cdktn.IResolvable;
}
export declare function computeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAddToTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd | cdktn.IResolvable): any;
export declare function computeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAddToHclTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAddOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    resetHeaderName(): void;
    get headerNameInput(): string | undefined;
    private _headerValue?;
    get headerValue(): string;
    set headerValue(value: string);
    resetHeaderValue(): void;
    get headerValueInput(): string | undefined;
    private _replace?;
    get replace(): boolean | cdktn.IResolvable;
    set replace(value: boolean | cdktn.IResolvable);
    resetReplace(): void;
    get replaceInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAddList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAddOutputReference;
}
export interface ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderAction {
    /**
    * A list of header names for headers that need to be removed from the request before forwarding the request to the backendService.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#request_headers_to_remove ComputeRegionUrlMap#request_headers_to_remove}
    */
    readonly requestHeadersToRemove?: string[];
    /**
    * A list of header names for headers that need to be removed from the response before sending the response back to the client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#response_headers_to_remove ComputeRegionUrlMap#response_headers_to_remove}
    */
    readonly responseHeadersToRemove?: string[];
    /**
    * request_headers_to_add block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#request_headers_to_add ComputeRegionUrlMap#request_headers_to_add}
    */
    readonly requestHeadersToAdd?: ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd[] | cdktn.IResolvable;
    /**
    * response_headers_to_add block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#response_headers_to_add ComputeRegionUrlMap#response_headers_to_add}
    */
    readonly responseHeadersToAdd?: ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd[] | cdktn.IResolvable;
}
export declare function computeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionToTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionOutputReference | ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderAction): any;
export declare function computeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionToHclTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionOutputReference | ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderAction): any;
export declare class ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderAction | undefined;
    set internalValue(value: ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderAction | undefined);
    private _requestHeadersToRemove?;
    get requestHeadersToRemove(): string[];
    set requestHeadersToRemove(value: string[]);
    resetRequestHeadersToRemove(): void;
    get requestHeadersToRemoveInput(): string[] | undefined;
    private _responseHeadersToRemove?;
    get responseHeadersToRemove(): string[];
    set responseHeadersToRemove(value: string[]);
    resetResponseHeadersToRemove(): void;
    get responseHeadersToRemoveInput(): string[] | undefined;
    private _requestHeadersToAdd;
    get requestHeadersToAdd(): ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAddList;
    putRequestHeadersToAdd(value: ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd[] | cdktn.IResolvable): void;
    resetRequestHeadersToAdd(): void;
    get requestHeadersToAddInput(): cdktn.IResolvable | ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd[] | undefined;
    private _responseHeadersToAdd;
    get responseHeadersToAdd(): ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAddList;
    putResponseHeadersToAdd(value: ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd[] | cdktn.IResolvable): void;
    resetResponseHeadersToAdd(): void;
    get responseHeadersToAddInput(): cdktn.IResolvable | ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd[] | undefined;
}
export interface ComputeRegionUrlMapDefaultRouteActionWeightedBackendServices {
    /**
    * The full or partial URL to the default BackendService resource. Before forwarding the request to backendService, the load balancer applies any relevant headerActions specified as part of this backendServiceWeight.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#backend_service ComputeRegionUrlMap#backend_service}
    */
    readonly backendService?: string;
    /**
    * Specifies the fraction of traffic sent to a backend service, computed as weight / (sum of all weightedBackendService weights in routeAction) .
    * The selection of a backend service is determined only for new traffic. Once a user's request has been directed to a backend service, subsequent requests are sent to the same backend service as determined by the backend service's session affinity policy.
    * The value must be from 0 to 1000.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#weight ComputeRegionUrlMap#weight}
    */
    readonly weight?: number;
    /**
    * header_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_action ComputeRegionUrlMap#header_action}
    */
    readonly headerAction?: ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderAction;
}
export declare function computeRegionUrlMapDefaultRouteActionWeightedBackendServicesToTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionWeightedBackendServices | cdktn.IResolvable): any;
export declare function computeRegionUrlMapDefaultRouteActionWeightedBackendServicesToHclTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionWeightedBackendServices | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapDefaultRouteActionWeightedBackendServices | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapDefaultRouteActionWeightedBackendServices | cdktn.IResolvable | undefined);
    private _backendService?;
    get backendService(): string;
    set backendService(value: string);
    resetBackendService(): void;
    get backendServiceInput(): string | undefined;
    private _weight?;
    get weight(): number;
    set weight(value: number);
    resetWeight(): void;
    get weightInput(): number | undefined;
    private _headerAction;
    get headerAction(): ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderActionOutputReference;
    putHeaderAction(value: ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderAction): void;
    resetHeaderAction(): void;
    get headerActionInput(): ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesHeaderAction | undefined;
}
export declare class ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapDefaultRouteActionWeightedBackendServices[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesOutputReference;
}
export interface ComputeRegionUrlMapDefaultRouteAction {
    /**
    * cors_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#cors_policy ComputeRegionUrlMap#cors_policy}
    */
    readonly corsPolicy?: ComputeRegionUrlMapDefaultRouteActionCorsPolicy;
    /**
    * fault_injection_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#fault_injection_policy ComputeRegionUrlMap#fault_injection_policy}
    */
    readonly faultInjectionPolicy?: ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicy;
    /**
    * request_mirror_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#request_mirror_policy ComputeRegionUrlMap#request_mirror_policy}
    */
    readonly requestMirrorPolicy?: ComputeRegionUrlMapDefaultRouteActionRequestMirrorPolicy;
    /**
    * retry_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#retry_policy ComputeRegionUrlMap#retry_policy}
    */
    readonly retryPolicy?: ComputeRegionUrlMapDefaultRouteActionRetryPolicy;
    /**
    * timeout block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#timeout ComputeRegionUrlMap#timeout}
    */
    readonly timeout?: ComputeRegionUrlMapDefaultRouteActionTimeout;
    /**
    * url_rewrite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#url_rewrite ComputeRegionUrlMap#url_rewrite}
    */
    readonly urlRewrite?: ComputeRegionUrlMapDefaultRouteActionUrlRewrite;
    /**
    * weighted_backend_services block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#weighted_backend_services ComputeRegionUrlMap#weighted_backend_services}
    */
    readonly weightedBackendServices?: ComputeRegionUrlMapDefaultRouteActionWeightedBackendServices[] | cdktn.IResolvable;
}
export declare function computeRegionUrlMapDefaultRouteActionToTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionOutputReference | ComputeRegionUrlMapDefaultRouteAction): any;
export declare function computeRegionUrlMapDefaultRouteActionToHclTerraform(struct?: ComputeRegionUrlMapDefaultRouteActionOutputReference | ComputeRegionUrlMapDefaultRouteAction): any;
export declare class ComputeRegionUrlMapDefaultRouteActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapDefaultRouteAction | undefined;
    set internalValue(value: ComputeRegionUrlMapDefaultRouteAction | undefined);
    private _corsPolicy;
    get corsPolicy(): ComputeRegionUrlMapDefaultRouteActionCorsPolicyOutputReference;
    putCorsPolicy(value: ComputeRegionUrlMapDefaultRouteActionCorsPolicy): void;
    resetCorsPolicy(): void;
    get corsPolicyInput(): ComputeRegionUrlMapDefaultRouteActionCorsPolicy | undefined;
    private _faultInjectionPolicy;
    get faultInjectionPolicy(): ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicyOutputReference;
    putFaultInjectionPolicy(value: ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicy): void;
    resetFaultInjectionPolicy(): void;
    get faultInjectionPolicyInput(): ComputeRegionUrlMapDefaultRouteActionFaultInjectionPolicy | undefined;
    private _requestMirrorPolicy;
    get requestMirrorPolicy(): ComputeRegionUrlMapDefaultRouteActionRequestMirrorPolicyOutputReference;
    putRequestMirrorPolicy(value: ComputeRegionUrlMapDefaultRouteActionRequestMirrorPolicy): void;
    resetRequestMirrorPolicy(): void;
    get requestMirrorPolicyInput(): ComputeRegionUrlMapDefaultRouteActionRequestMirrorPolicy | undefined;
    private _retryPolicy;
    get retryPolicy(): ComputeRegionUrlMapDefaultRouteActionRetryPolicyOutputReference;
    putRetryPolicy(value: ComputeRegionUrlMapDefaultRouteActionRetryPolicy): void;
    resetRetryPolicy(): void;
    get retryPolicyInput(): ComputeRegionUrlMapDefaultRouteActionRetryPolicy | undefined;
    private _timeout;
    get timeout(): ComputeRegionUrlMapDefaultRouteActionTimeoutOutputReference;
    putTimeout(value: ComputeRegionUrlMapDefaultRouteActionTimeout): void;
    resetTimeout(): void;
    get timeoutInput(): ComputeRegionUrlMapDefaultRouteActionTimeout | undefined;
    private _urlRewrite;
    get urlRewrite(): ComputeRegionUrlMapDefaultRouteActionUrlRewriteOutputReference;
    putUrlRewrite(value: ComputeRegionUrlMapDefaultRouteActionUrlRewrite): void;
    resetUrlRewrite(): void;
    get urlRewriteInput(): ComputeRegionUrlMapDefaultRouteActionUrlRewrite | undefined;
    private _weightedBackendServices;
    get weightedBackendServices(): ComputeRegionUrlMapDefaultRouteActionWeightedBackendServicesList;
    putWeightedBackendServices(value: ComputeRegionUrlMapDefaultRouteActionWeightedBackendServices[] | cdktn.IResolvable): void;
    resetWeightedBackendServices(): void;
    get weightedBackendServicesInput(): cdktn.IResolvable | ComputeRegionUrlMapDefaultRouteActionWeightedBackendServices[] | undefined;
}
export interface ComputeRegionUrlMapDefaultUrlRedirect {
    /**
    * The host that will be used in the redirect response instead of the one that was
    * supplied in the request. The value must be between 1 and 255 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#host_redirect ComputeRegionUrlMap#host_redirect}
    */
    readonly hostRedirect?: string;
    /**
    * If set to true, the URL scheme in the redirected request is set to https. If set to
    * false, the URL scheme of the redirected request will remain the same as that of the
    * request. This must only be set for UrlMaps used in TargetHttpProxys. Setting this
    * true for TargetHttpsProxy is not permitted. The default is set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#https_redirect ComputeRegionUrlMap#https_redirect}
    */
    readonly httpsRedirect?: boolean | cdktn.IResolvable;
    /**
    * The path that will be used in the redirect response instead of the one that was
    * supplied in the request. pathRedirect cannot be supplied together with
    * prefixRedirect. Supply one alone or neither. If neither is supplied, the path of the
    * original request will be used for the redirect. The value must be between 1 and 1024
    * characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#path_redirect ComputeRegionUrlMap#path_redirect}
    */
    readonly pathRedirect?: string;
    /**
    * The prefix that replaces the prefixMatch specified in the HttpRouteRuleMatch,
    * retaining the remaining portion of the URL before redirecting the request.
    * prefixRedirect cannot be supplied together with pathRedirect. Supply one alone or
    * neither. If neither is supplied, the path of the original request will be used for
    * the redirect. The value must be between 1 and 1024 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#prefix_redirect ComputeRegionUrlMap#prefix_redirect}
    */
    readonly prefixRedirect?: string;
    /**
    * The HTTP Status code to use for this RedirectAction. Supported values are:
    *
    * * MOVED_PERMANENTLY_DEFAULT, which is the default value and corresponds to 301.
    *
    * * FOUND, which corresponds to 302.
    *
    * * SEE_OTHER which corresponds to 303.
    *
    * * TEMPORARY_REDIRECT, which corresponds to 307. In this case, the request method
    * will be retained.
    *
    * * PERMANENT_REDIRECT, which corresponds to 308. In this case,
    * the request method will be retained. Possible values: ["FOUND", "MOVED_PERMANENTLY_DEFAULT", "PERMANENT_REDIRECT", "SEE_OTHER", "TEMPORARY_REDIRECT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#redirect_response_code ComputeRegionUrlMap#redirect_response_code}
    */
    readonly redirectResponseCode?: string;
    /**
    * If set to true, any accompanying query portion of the original URL is removed prior
    * to redirecting the request. If set to false, the query portion of the original URL is
    * retained.
    *  This field is required to ensure an empty block is not set. The normal default value is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#strip_query ComputeRegionUrlMap#strip_query}
    */
    readonly stripQuery: boolean | cdktn.IResolvable;
}
export declare function computeRegionUrlMapDefaultUrlRedirectToTerraform(struct?: ComputeRegionUrlMapDefaultUrlRedirectOutputReference | ComputeRegionUrlMapDefaultUrlRedirect): any;
export declare function computeRegionUrlMapDefaultUrlRedirectToHclTerraform(struct?: ComputeRegionUrlMapDefaultUrlRedirectOutputReference | ComputeRegionUrlMapDefaultUrlRedirect): any;
export declare class ComputeRegionUrlMapDefaultUrlRedirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapDefaultUrlRedirect | undefined;
    set internalValue(value: ComputeRegionUrlMapDefaultUrlRedirect | undefined);
    private _hostRedirect?;
    get hostRedirect(): string;
    set hostRedirect(value: string);
    resetHostRedirect(): void;
    get hostRedirectInput(): string | undefined;
    private _httpsRedirect?;
    get httpsRedirect(): boolean | cdktn.IResolvable;
    set httpsRedirect(value: boolean | cdktn.IResolvable);
    resetHttpsRedirect(): void;
    get httpsRedirectInput(): boolean | cdktn.IResolvable | undefined;
    private _pathRedirect?;
    get pathRedirect(): string;
    set pathRedirect(value: string);
    resetPathRedirect(): void;
    get pathRedirectInput(): string | undefined;
    private _prefixRedirect?;
    get prefixRedirect(): string;
    set prefixRedirect(value: string);
    resetPrefixRedirect(): void;
    get prefixRedirectInput(): string | undefined;
    private _redirectResponseCode?;
    get redirectResponseCode(): string;
    set redirectResponseCode(value: string);
    resetRedirectResponseCode(): void;
    get redirectResponseCodeInput(): string | undefined;
    private _stripQuery?;
    get stripQuery(): boolean | cdktn.IResolvable;
    set stripQuery(value: boolean | cdktn.IResolvable);
    get stripQueryInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ComputeRegionUrlMapHeaderActionRequestHeadersToAdd {
    /**
    * The name of the header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_name ComputeRegionUrlMap#header_name}
    */
    readonly headerName?: string;
    /**
    * The value of the header to add.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_value ComputeRegionUrlMap#header_value}
    */
    readonly headerValue?: string;
    /**
    * If false, headerValue is appended to any values that already exist for the header. If true, headerValue is set for the header, discarding any values that were set for that header.
    * The default value is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#replace ComputeRegionUrlMap#replace}
    */
    readonly replace?: boolean | cdktn.IResolvable;
}
export declare function computeRegionUrlMapHeaderActionRequestHeadersToAddToTerraform(struct?: ComputeRegionUrlMapHeaderActionRequestHeadersToAdd | cdktn.IResolvable): any;
export declare function computeRegionUrlMapHeaderActionRequestHeadersToAddToHclTerraform(struct?: ComputeRegionUrlMapHeaderActionRequestHeadersToAdd | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapHeaderActionRequestHeadersToAddOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapHeaderActionRequestHeadersToAdd | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapHeaderActionRequestHeadersToAdd | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    resetHeaderName(): void;
    get headerNameInput(): string | undefined;
    private _headerValue?;
    get headerValue(): string;
    set headerValue(value: string);
    resetHeaderValue(): void;
    get headerValueInput(): string | undefined;
    private _replace?;
    get replace(): boolean | cdktn.IResolvable;
    set replace(value: boolean | cdktn.IResolvable);
    resetReplace(): void;
    get replaceInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class ComputeRegionUrlMapHeaderActionRequestHeadersToAddList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapHeaderActionRequestHeadersToAdd[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapHeaderActionRequestHeadersToAddOutputReference;
}
export interface ComputeRegionUrlMapHeaderActionResponseHeadersToAdd {
    /**
    * The name of the header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_name ComputeRegionUrlMap#header_name}
    */
    readonly headerName?: string;
    /**
    * The value of the header to add.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_value ComputeRegionUrlMap#header_value}
    */
    readonly headerValue?: string;
    /**
    * If false, headerValue is appended to any values that already exist for the header. If true, headerValue is set for the header, discarding any values that were set for that header.
    * The default value is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#replace ComputeRegionUrlMap#replace}
    */
    readonly replace?: boolean | cdktn.IResolvable;
}
export declare function computeRegionUrlMapHeaderActionResponseHeadersToAddToTerraform(struct?: ComputeRegionUrlMapHeaderActionResponseHeadersToAdd | cdktn.IResolvable): any;
export declare function computeRegionUrlMapHeaderActionResponseHeadersToAddToHclTerraform(struct?: ComputeRegionUrlMapHeaderActionResponseHeadersToAdd | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapHeaderActionResponseHeadersToAddOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapHeaderActionResponseHeadersToAdd | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapHeaderActionResponseHeadersToAdd | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    resetHeaderName(): void;
    get headerNameInput(): string | undefined;
    private _headerValue?;
    get headerValue(): string;
    set headerValue(value: string);
    resetHeaderValue(): void;
    get headerValueInput(): string | undefined;
    private _replace?;
    get replace(): boolean | cdktn.IResolvable;
    set replace(value: boolean | cdktn.IResolvable);
    resetReplace(): void;
    get replaceInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class ComputeRegionUrlMapHeaderActionResponseHeadersToAddList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapHeaderActionResponseHeadersToAdd[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapHeaderActionResponseHeadersToAddOutputReference;
}
export interface ComputeRegionUrlMapHeaderAction {
    /**
    * A list of header names for headers that need to be removed from the request before forwarding the request to the backendService.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#request_headers_to_remove ComputeRegionUrlMap#request_headers_to_remove}
    */
    readonly requestHeadersToRemove?: string[];
    /**
    * A list of header names for headers that need to be removed from the response before sending the response back to the client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#response_headers_to_remove ComputeRegionUrlMap#response_headers_to_remove}
    */
    readonly responseHeadersToRemove?: string[];
    /**
    * request_headers_to_add block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#request_headers_to_add ComputeRegionUrlMap#request_headers_to_add}
    */
    readonly requestHeadersToAdd?: ComputeRegionUrlMapHeaderActionRequestHeadersToAdd[] | cdktn.IResolvable;
    /**
    * response_headers_to_add block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#response_headers_to_add ComputeRegionUrlMap#response_headers_to_add}
    */
    readonly responseHeadersToAdd?: ComputeRegionUrlMapHeaderActionResponseHeadersToAdd[] | cdktn.IResolvable;
}
export declare function computeRegionUrlMapHeaderActionToTerraform(struct?: ComputeRegionUrlMapHeaderActionOutputReference | ComputeRegionUrlMapHeaderAction): any;
export declare function computeRegionUrlMapHeaderActionToHclTerraform(struct?: ComputeRegionUrlMapHeaderActionOutputReference | ComputeRegionUrlMapHeaderAction): any;
export declare class ComputeRegionUrlMapHeaderActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapHeaderAction | undefined;
    set internalValue(value: ComputeRegionUrlMapHeaderAction | undefined);
    private _requestHeadersToRemove?;
    get requestHeadersToRemove(): string[];
    set requestHeadersToRemove(value: string[]);
    resetRequestHeadersToRemove(): void;
    get requestHeadersToRemoveInput(): string[] | undefined;
    private _responseHeadersToRemove?;
    get responseHeadersToRemove(): string[];
    set responseHeadersToRemove(value: string[]);
    resetResponseHeadersToRemove(): void;
    get responseHeadersToRemoveInput(): string[] | undefined;
    private _requestHeadersToAdd;
    get requestHeadersToAdd(): ComputeRegionUrlMapHeaderActionRequestHeadersToAddList;
    putRequestHeadersToAdd(value: ComputeRegionUrlMapHeaderActionRequestHeadersToAdd[] | cdktn.IResolvable): void;
    resetRequestHeadersToAdd(): void;
    get requestHeadersToAddInput(): cdktn.IResolvable | ComputeRegionUrlMapHeaderActionRequestHeadersToAdd[] | undefined;
    private _responseHeadersToAdd;
    get responseHeadersToAdd(): ComputeRegionUrlMapHeaderActionResponseHeadersToAddList;
    putResponseHeadersToAdd(value: ComputeRegionUrlMapHeaderActionResponseHeadersToAdd[] | cdktn.IResolvable): void;
    resetResponseHeadersToAdd(): void;
    get responseHeadersToAddInput(): cdktn.IResolvable | ComputeRegionUrlMapHeaderActionResponseHeadersToAdd[] | undefined;
}
export interface ComputeRegionUrlMapHostRule {
    /**
    * An optional description of this HostRule. Provide this property
    * when you create the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#description ComputeRegionUrlMap#description}
    */
    readonly description?: string;
    /**
    * The list of host patterns to match. They must be valid
    * hostnames, except * will match any string of ([a-z0-9-.]*). In
    * that case, * must be the first character and must be followed in
    * the pattern by either - or ..
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#hosts ComputeRegionUrlMap#hosts}
    */
    readonly hosts: string[];
    /**
    * The name of the PathMatcher to use to match the path portion of
    * the URL if the hostRule matches the URL's host portion.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#path_matcher ComputeRegionUrlMap#path_matcher}
    */
    readonly pathMatcher: string;
}
export declare function computeRegionUrlMapHostRuleToTerraform(struct?: ComputeRegionUrlMapHostRule | cdktn.IResolvable): any;
export declare function computeRegionUrlMapHostRuleToHclTerraform(struct?: ComputeRegionUrlMapHostRule | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapHostRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapHostRule | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapHostRule | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _hosts?;
    get hosts(): string[];
    set hosts(value: string[]);
    get hostsInput(): string[] | undefined;
    private _pathMatcher?;
    get pathMatcher(): string;
    set pathMatcher(value: string);
    get pathMatcherInput(): string | undefined;
}
export declare class ComputeRegionUrlMapHostRuleList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapHostRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapHostRuleOutputReference;
}
export interface ComputeRegionUrlMapPathMatcherDefaultRouteActionCorsPolicy {
    /**
    * In response to a preflight request, setting this to true indicates that the actual request can include user credentials.
    * This translates to the Access-Control-Allow-Credentials header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#allow_credentials ComputeRegionUrlMap#allow_credentials}
    */
    readonly allowCredentials?: boolean | cdktn.IResolvable;
    /**
    * Specifies the content for the Access-Control-Allow-Headers header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#allow_headers ComputeRegionUrlMap#allow_headers}
    */
    readonly allowHeaders?: string[];
    /**
    * Specifies the content for the Access-Control-Allow-Methods header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#allow_methods ComputeRegionUrlMap#allow_methods}
    */
    readonly allowMethods?: string[];
    /**
    * Specifies the regular expression patterns that match allowed origins. For regular expression grammar
    * please see en.cppreference.com/w/cpp/regex/ecmascript
    * An origin is allowed if it matches either an item in allowOrigins or an item in allowOriginRegexes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#allow_origin_regexes ComputeRegionUrlMap#allow_origin_regexes}
    */
    readonly allowOriginRegexes?: string[];
    /**
    * Specifies the list of origins that will be allowed to do CORS requests.
    * An origin is allowed if it matches either an item in allowOrigins or an item in allowOriginRegexes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#allow_origins ComputeRegionUrlMap#allow_origins}
    */
    readonly allowOrigins?: string[];
    /**
    * If true, specifies the CORS policy is disabled. The default value is false, which indicates that the CORS policy is in effect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#disabled ComputeRegionUrlMap#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Specifies the content for the Access-Control-Expose-Headers header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#expose_headers ComputeRegionUrlMap#expose_headers}
    */
    readonly exposeHeaders?: string[];
    /**
    * Specifies how long results of a preflight request can be cached in seconds.
    * This translates to the Access-Control-Max-Age header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#max_age ComputeRegionUrlMap#max_age}
    */
    readonly maxAge?: number;
}
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionCorsPolicyToTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionCorsPolicyOutputReference | ComputeRegionUrlMapPathMatcherDefaultRouteActionCorsPolicy): any;
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionCorsPolicyToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionCorsPolicyOutputReference | ComputeRegionUrlMapPathMatcherDefaultRouteActionCorsPolicy): any;
export declare class ComputeRegionUrlMapPathMatcherDefaultRouteActionCorsPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherDefaultRouteActionCorsPolicy | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionCorsPolicy | undefined);
    private _allowCredentials?;
    get allowCredentials(): boolean | cdktn.IResolvable;
    set allowCredentials(value: boolean | cdktn.IResolvable);
    resetAllowCredentials(): void;
    get allowCredentialsInput(): boolean | cdktn.IResolvable | undefined;
    private _allowHeaders?;
    get allowHeaders(): string[];
    set allowHeaders(value: string[]);
    resetAllowHeaders(): void;
    get allowHeadersInput(): string[] | undefined;
    private _allowMethods?;
    get allowMethods(): string[];
    set allowMethods(value: string[]);
    resetAllowMethods(): void;
    get allowMethodsInput(): string[] | undefined;
    private _allowOriginRegexes?;
    get allowOriginRegexes(): string[];
    set allowOriginRegexes(value: string[]);
    resetAllowOriginRegexes(): void;
    get allowOriginRegexesInput(): string[] | undefined;
    private _allowOrigins?;
    get allowOrigins(): string[];
    set allowOrigins(value: string[]);
    resetAllowOrigins(): void;
    get allowOriginsInput(): string[] | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _exposeHeaders?;
    get exposeHeaders(): string[];
    set exposeHeaders(value: string[]);
    resetExposeHeaders(): void;
    get exposeHeadersInput(): string[] | undefined;
    private _maxAge?;
    get maxAge(): number;
    set maxAge(value: number);
    resetMaxAge(): void;
    get maxAgeInput(): number | undefined;
}
export interface ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyAbort {
    /**
    * The HTTP status code used to abort the request.
    * The value must be between 200 and 599 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#http_status ComputeRegionUrlMap#http_status}
    */
    readonly httpStatus?: number;
    /**
    * The percentage of traffic (connections/operations/requests) which will be aborted as part of fault injection.
    * The value must be between 0.0 and 100.0 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#percentage ComputeRegionUrlMap#percentage}
    */
    readonly percentage?: number;
}
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyAbortToTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyAbortOutputReference | ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyAbort): any;
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyAbortToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyAbortOutputReference | ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyAbort): any;
export declare class ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyAbortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyAbort | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyAbort | undefined);
    private _httpStatus?;
    get httpStatus(): number;
    set httpStatus(value: number);
    resetHttpStatus(): void;
    get httpStatusInput(): number | undefined;
    private _percentage?;
    get percentage(): number;
    set percentage(value: number);
    resetPercentage(): void;
    get percentageInput(): number | undefined;
}
export interface ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelayFixedDelay {
    /**
    * Span of time that's a fraction of a second at nanosecond resolution. Durations less than one second are
    * represented with a 0 seconds field and a positive nanos field. Must be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#nanos ComputeRegionUrlMap#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second. Must be from 0 to 315,576,000,000 inclusive.
    * Note: these bounds are computed from: 60 sec/min * 60 min/hr * 24 hr/day * 365.25 days/year * 10000 years
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#seconds ComputeRegionUrlMap#seconds}
    */
    readonly seconds?: string;
}
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelayFixedDelayToTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelayFixedDelayOutputReference | ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelayFixedDelay): any;
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelayFixedDelayToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelayFixedDelayOutputReference | ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelayFixedDelay): any;
export declare class ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelayFixedDelayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelayFixedDelay | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelayFixedDelay | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): string;
    set seconds(value: string);
    resetSeconds(): void;
    get secondsInput(): string | undefined;
}
export interface ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelay {
    /**
    * The percentage of traffic (connections/operations/requests) on which delay will be introduced as part of fault injection.
    * The value must be between 0.0 and 100.0 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#percentage ComputeRegionUrlMap#percentage}
    */
    readonly percentage?: number;
    /**
    * fixed_delay block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#fixed_delay ComputeRegionUrlMap#fixed_delay}
    */
    readonly fixedDelay?: ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelayFixedDelay;
}
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelayToTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelayOutputReference | ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelay): any;
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelayToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelayOutputReference | ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelay): any;
export declare class ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelay | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelay | undefined);
    private _percentage?;
    get percentage(): number;
    set percentage(value: number);
    resetPercentage(): void;
    get percentageInput(): number | undefined;
    private _fixedDelay;
    get fixedDelay(): ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelayFixedDelayOutputReference;
    putFixedDelay(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelayFixedDelay): void;
    resetFixedDelay(): void;
    get fixedDelayInput(): ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelayFixedDelay | undefined;
}
export interface ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicy {
    /**
    * abort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#abort ComputeRegionUrlMap#abort}
    */
    readonly abort?: ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyAbort;
    /**
    * delay block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#delay ComputeRegionUrlMap#delay}
    */
    readonly delay?: ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelay;
}
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyToTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyOutputReference | ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicy): any;
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyOutputReference | ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicy): any;
export declare class ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicy | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicy | undefined);
    private _abort;
    get abort(): ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyAbortOutputReference;
    putAbort(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyAbort): void;
    resetAbort(): void;
    get abortInput(): ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyAbort | undefined;
    private _delay;
    get delay(): ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelayOutputReference;
    putDelay(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelay): void;
    resetDelay(): void;
    get delayInput(): ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyDelay | undefined;
}
export interface ComputeRegionUrlMapPathMatcherDefaultRouteActionMaxStreamDuration {
    /**
    * Span of time that's a fraction of a second at nanosecond resolution. Durations less than one second are represented
    * with a 0 seconds field and a positive nanos field. Must be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#nanos ComputeRegionUrlMap#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second. Must be from 0 to 315,576,000,000 inclusive.
    * Note: these bounds are computed from: 60 sec/min * 60 min/hr * 24 hr/day * 365.25 days/year * 10000 years
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#seconds ComputeRegionUrlMap#seconds}
    */
    readonly seconds: string;
}
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionMaxStreamDurationToTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionMaxStreamDurationOutputReference | ComputeRegionUrlMapPathMatcherDefaultRouteActionMaxStreamDuration): any;
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionMaxStreamDurationToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionMaxStreamDurationOutputReference | ComputeRegionUrlMapPathMatcherDefaultRouteActionMaxStreamDuration): any;
export declare class ComputeRegionUrlMapPathMatcherDefaultRouteActionMaxStreamDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherDefaultRouteActionMaxStreamDuration | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionMaxStreamDuration | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): string;
    set seconds(value: string);
    get secondsInput(): string | undefined;
}
export interface ComputeRegionUrlMapPathMatcherDefaultRouteActionRequestMirrorPolicy {
    /**
    * The full or partial URL to the BackendService resource being mirrored to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#backend_service ComputeRegionUrlMap#backend_service}
    */
    readonly backendService: string;
    /**
    * The percentage of requests to be mirrored to backendService.
    * The value must be between 0.0 and 100.0 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#mirror_percent ComputeRegionUrlMap#mirror_percent}
    */
    readonly mirrorPercent?: number;
}
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionRequestMirrorPolicyToTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionRequestMirrorPolicyOutputReference | ComputeRegionUrlMapPathMatcherDefaultRouteActionRequestMirrorPolicy): any;
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionRequestMirrorPolicyToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionRequestMirrorPolicyOutputReference | ComputeRegionUrlMapPathMatcherDefaultRouteActionRequestMirrorPolicy): any;
export declare class ComputeRegionUrlMapPathMatcherDefaultRouteActionRequestMirrorPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherDefaultRouteActionRequestMirrorPolicy | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionRequestMirrorPolicy | undefined);
    private _backendService?;
    get backendService(): string;
    set backendService(value: string);
    get backendServiceInput(): string | undefined;
    private _mirrorPercent?;
    get mirrorPercent(): number;
    set mirrorPercent(value: number);
    resetMirrorPercent(): void;
    get mirrorPercentInput(): number | undefined;
}
export interface ComputeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicyPerTryTimeout {
    /**
    * Span of time that's a fraction of a second at nanosecond resolution. Durations less than one second are
    * represented with a 0 seconds field and a positive nanos field. Must be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#nanos ComputeRegionUrlMap#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second. Must be from 0 to 315,576,000,000 inclusive.
    * Note: these bounds are computed from: 60 sec/min * 60 min/hr * 24 hr/day * 365.25 days/year * 10000 years
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#seconds ComputeRegionUrlMap#seconds}
    */
    readonly seconds?: string;
}
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicyPerTryTimeoutToTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicyPerTryTimeoutOutputReference | ComputeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicyPerTryTimeout): any;
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicyPerTryTimeoutToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicyPerTryTimeoutOutputReference | ComputeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicyPerTryTimeout): any;
export declare class ComputeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicyPerTryTimeoutOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicyPerTryTimeout | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicyPerTryTimeout | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): string;
    set seconds(value: string);
    resetSeconds(): void;
    get secondsInput(): string | undefined;
}
export interface ComputeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicy {
    /**
    * Specifies the allowed number retries. This number must be > 0. If not specified, defaults to 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#num_retries ComputeRegionUrlMap#num_retries}
    */
    readonly numRetries?: number;
    /**
    * Specfies one or more conditions when this retry rule applies. Valid values are:
    *
    * * 5xx: Loadbalancer will attempt a retry if the backend service responds with any 5xx response code,
    *   or if the backend service does not respond at all, example: disconnects, reset, read timeout,
    * * connection failure, and refused streams.
    * * gateway-error: Similar to 5xx, but only applies to response codes 502, 503 or 504.
    * * connect-failure: Loadbalancer will retry on failures connecting to backend services,
    *   for example due to connection timeouts.
    * * retriable-4xx: Loadbalancer will retry for retriable 4xx response codes.
    *   Currently the only retriable error supported is 409.
    * * refused-stream:Loadbalancer will retry if the backend service resets the stream with a REFUSED_STREAM error code.
    *   This reset type indicates that it is safe to retry.
    * * cancelled: Loadbalancer will retry if the gRPC status code in the response header is set to cancelled
    * * deadline-exceeded: Loadbalancer will retry if the gRPC status code in the response header is set to deadline-exceeded
    * * resource-exhausted: Loadbalancer will retry if the gRPC status code in the response header is set to resource-exhausted
    * * unavailable: Loadbalancer will retry if the gRPC status code in the response header is set to unavailable
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#retry_conditions ComputeRegionUrlMap#retry_conditions}
    */
    readonly retryConditions?: string[];
    /**
    * per_try_timeout block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#per_try_timeout ComputeRegionUrlMap#per_try_timeout}
    */
    readonly perTryTimeout?: ComputeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicyPerTryTimeout;
}
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicyToTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicyOutputReference | ComputeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicy): any;
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicyToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicyOutputReference | ComputeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicy): any;
export declare class ComputeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicy | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicy | undefined);
    private _numRetries?;
    get numRetries(): number;
    set numRetries(value: number);
    resetNumRetries(): void;
    get numRetriesInput(): number | undefined;
    private _retryConditions?;
    get retryConditions(): string[];
    set retryConditions(value: string[]);
    resetRetryConditions(): void;
    get retryConditionsInput(): string[] | undefined;
    private _perTryTimeout;
    get perTryTimeout(): ComputeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicyPerTryTimeoutOutputReference;
    putPerTryTimeout(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicyPerTryTimeout): void;
    resetPerTryTimeout(): void;
    get perTryTimeoutInput(): ComputeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicyPerTryTimeout | undefined;
}
export interface ComputeRegionUrlMapPathMatcherDefaultRouteActionTimeout {
    /**
    * Span of time that's a fraction of a second at nanosecond resolution. Durations less than one second are represented
    * with a 0 seconds field and a positive nanos field. Must be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#nanos ComputeRegionUrlMap#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second. Must be from 0 to 315,576,000,000 inclusive.
    * Note: these bounds are computed from: 60 sec/min * 60 min/hr * 24 hr/day * 365.25 days/year * 10000 years
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#seconds ComputeRegionUrlMap#seconds}
    */
    readonly seconds?: string;
}
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionTimeoutToTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionTimeoutOutputReference | ComputeRegionUrlMapPathMatcherDefaultRouteActionTimeout): any;
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionTimeoutToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionTimeoutOutputReference | ComputeRegionUrlMapPathMatcherDefaultRouteActionTimeout): any;
export declare class ComputeRegionUrlMapPathMatcherDefaultRouteActionTimeoutOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherDefaultRouteActionTimeout | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionTimeout | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): string;
    set seconds(value: string);
    resetSeconds(): void;
    get secondsInput(): string | undefined;
}
export interface ComputeRegionUrlMapPathMatcherDefaultRouteActionUrlRewrite {
    /**
    * Prior to forwarding the request to the selected service, the request's host header is replaced
    * with contents of hostRewrite.
    *
    * The value must be between 1 and 255 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#host_rewrite ComputeRegionUrlMap#host_rewrite}
    */
    readonly hostRewrite?: string;
    /**
    * Prior to forwarding the request to the selected backend service, the matching portion of the
    * request's path is replaced by pathPrefixRewrite.
    *
    * The value must be between 1 and 1024 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#path_prefix_rewrite ComputeRegionUrlMap#path_prefix_rewrite}
    */
    readonly pathPrefixRewrite?: string;
    /**
    * If specified, the pattern rewrites the URL path (based on the :path header) using the HTTP template syntax.
    *
    * A corresponding pathTemplateMatch must be specified. Any template variables must exist in the pathTemplateMatch field.
    *
    * * At least one variable must be specified in the pathTemplateMatch field
    * * You can omit variables from the rewritten URL
    * * The * and ** operators cannot be matched unless they have a corresponding variable name - e.g. {format=*} or {var=**}.
    *
    * For example, a pathTemplateMatch of /static/{format=**} could be rewritten as /static/content/{format} to prefix
    * /content to the URL. Variables can also be re-ordered in a rewrite, so that /{country}/{format}/{suffix=**} can be
    * rewritten as /content/{format}/{country}/{suffix}.
    *
    * At least one non-empty routeRules[].matchRules[].path_template_match is required.
    *
    * Only one of pathPrefixRewrite or pathTemplateRewrite may be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#path_template_rewrite ComputeRegionUrlMap#path_template_rewrite}
    */
    readonly pathTemplateRewrite?: string;
}
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionUrlRewriteToTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionUrlRewriteOutputReference | ComputeRegionUrlMapPathMatcherDefaultRouteActionUrlRewrite): any;
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionUrlRewriteToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionUrlRewriteOutputReference | ComputeRegionUrlMapPathMatcherDefaultRouteActionUrlRewrite): any;
export declare class ComputeRegionUrlMapPathMatcherDefaultRouteActionUrlRewriteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherDefaultRouteActionUrlRewrite | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionUrlRewrite | undefined);
    private _hostRewrite?;
    get hostRewrite(): string;
    set hostRewrite(value: string);
    resetHostRewrite(): void;
    get hostRewriteInput(): string | undefined;
    private _pathPrefixRewrite?;
    get pathPrefixRewrite(): string;
    set pathPrefixRewrite(value: string);
    resetPathPrefixRewrite(): void;
    get pathPrefixRewriteInput(): string | undefined;
    private _pathTemplateRewrite?;
    get pathTemplateRewrite(): string;
    set pathTemplateRewrite(value: string);
    resetPathTemplateRewrite(): void;
    get pathTemplateRewriteInput(): string | undefined;
}
export interface ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd {
    /**
    * The name of the header to add.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_name ComputeRegionUrlMap#header_name}
    */
    readonly headerName?: string;
    /**
    * The value of the header to add.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_value ComputeRegionUrlMap#header_value}
    */
    readonly headerValue?: string;
    /**
    * If false, headerValue is appended to any values that already exist for the header.
    * If true, headerValue is set for the header, discarding any values that were set for that header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#replace ComputeRegionUrlMap#replace}
    */
    readonly replace?: boolean | cdktn.IResolvable;
}
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAddToTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd | cdktn.IResolvable): any;
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAddToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAddOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    resetHeaderName(): void;
    get headerNameInput(): string | undefined;
    private _headerValue?;
    get headerValue(): string;
    set headerValue(value: string);
    resetHeaderValue(): void;
    get headerValueInput(): string | undefined;
    private _replace?;
    get replace(): boolean | cdktn.IResolvable;
    set replace(value: boolean | cdktn.IResolvable);
    resetReplace(): void;
    get replaceInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAddList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAddOutputReference;
}
export interface ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd {
    /**
    * The name of the header to add.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_name ComputeRegionUrlMap#header_name}
    */
    readonly headerName?: string;
    /**
    * The value of the header to add.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_value ComputeRegionUrlMap#header_value}
    */
    readonly headerValue?: string;
    /**
    * If false, headerValue is appended to any values that already exist for the header.
    * If true, headerValue is set for the header, discarding any values that were set for that header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#replace ComputeRegionUrlMap#replace}
    */
    readonly replace?: boolean | cdktn.IResolvable;
}
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAddToTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd | cdktn.IResolvable): any;
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAddToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAddOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    resetHeaderName(): void;
    get headerNameInput(): string | undefined;
    private _headerValue?;
    get headerValue(): string;
    set headerValue(value: string);
    resetHeaderValue(): void;
    get headerValueInput(): string | undefined;
    private _replace?;
    get replace(): boolean | cdktn.IResolvable;
    set replace(value: boolean | cdktn.IResolvable);
    resetReplace(): void;
    get replaceInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAddList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAddOutputReference;
}
export interface ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderAction {
    /**
    * A list of header names for headers that need to be removed from the request prior to
    * forwarding the request to the backendService.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#request_headers_to_remove ComputeRegionUrlMap#request_headers_to_remove}
    */
    readonly requestHeadersToRemove?: string[];
    /**
    * A list of header names for headers that need to be removed from the response prior to sending the
    * response back to the client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#response_headers_to_remove ComputeRegionUrlMap#response_headers_to_remove}
    */
    readonly responseHeadersToRemove?: string[];
    /**
    * request_headers_to_add block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#request_headers_to_add ComputeRegionUrlMap#request_headers_to_add}
    */
    readonly requestHeadersToAdd?: ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd[] | cdktn.IResolvable;
    /**
    * response_headers_to_add block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#response_headers_to_add ComputeRegionUrlMap#response_headers_to_add}
    */
    readonly responseHeadersToAdd?: ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd[] | cdktn.IResolvable;
}
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionToTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionOutputReference | ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderAction): any;
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionOutputReference | ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderAction): any;
export declare class ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderAction | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderAction | undefined);
    private _requestHeadersToRemove?;
    get requestHeadersToRemove(): string[];
    set requestHeadersToRemove(value: string[]);
    resetRequestHeadersToRemove(): void;
    get requestHeadersToRemoveInput(): string[] | undefined;
    private _responseHeadersToRemove?;
    get responseHeadersToRemove(): string[];
    set responseHeadersToRemove(value: string[]);
    resetResponseHeadersToRemove(): void;
    get responseHeadersToRemoveInput(): string[] | undefined;
    private _requestHeadersToAdd;
    get requestHeadersToAdd(): ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAddList;
    putRequestHeadersToAdd(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd[] | cdktn.IResolvable): void;
    resetRequestHeadersToAdd(): void;
    get requestHeadersToAddInput(): cdktn.IResolvable | ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd[] | undefined;
    private _responseHeadersToAdd;
    get responseHeadersToAdd(): ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAddList;
    putResponseHeadersToAdd(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd[] | cdktn.IResolvable): void;
    resetResponseHeadersToAdd(): void;
    get responseHeadersToAddInput(): cdktn.IResolvable | ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd[] | undefined;
}
export interface ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServices {
    /**
    * The full or partial URL to the default BackendService resource. Before forwarding the
    * request to backendService, the loadbalancer applies any relevant headerActions
    * specified as part of this backendServiceWeight.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#backend_service ComputeRegionUrlMap#backend_service}
    */
    readonly backendService?: string;
    /**
    * Specifies the fraction of traffic sent to backendService, computed as
    * weight / (sum of all weightedBackendService weights in routeAction) .
    *
    * The selection of a backend service is determined only for new traffic. Once a user's request
    * has been directed to a backendService, subsequent requests will be sent to the same backendService
    * as determined by the BackendService's session affinity policy.
    *
    * The value must be between 0 and 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#weight ComputeRegionUrlMap#weight}
    */
    readonly weight?: number;
    /**
    * header_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_action ComputeRegionUrlMap#header_action}
    */
    readonly headerAction?: ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderAction;
}
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesToTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServices | cdktn.IResolvable): any;
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServices | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServices | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServices | cdktn.IResolvable | undefined);
    private _backendService?;
    get backendService(): string;
    set backendService(value: string);
    resetBackendService(): void;
    get backendServiceInput(): string | undefined;
    private _weight?;
    get weight(): number;
    set weight(value: number);
    resetWeight(): void;
    get weightInput(): number | undefined;
    private _headerAction;
    get headerAction(): ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderActionOutputReference;
    putHeaderAction(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderAction): void;
    resetHeaderAction(): void;
    get headerActionInput(): ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesHeaderAction | undefined;
}
export declare class ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServices[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesOutputReference;
}
export interface ComputeRegionUrlMapPathMatcherDefaultRouteAction {
    /**
    * cors_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#cors_policy ComputeRegionUrlMap#cors_policy}
    */
    readonly corsPolicy?: ComputeRegionUrlMapPathMatcherDefaultRouteActionCorsPolicy;
    /**
    * fault_injection_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#fault_injection_policy ComputeRegionUrlMap#fault_injection_policy}
    */
    readonly faultInjectionPolicy?: ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicy;
    /**
    * max_stream_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#max_stream_duration ComputeRegionUrlMap#max_stream_duration}
    */
    readonly maxStreamDuration?: ComputeRegionUrlMapPathMatcherDefaultRouteActionMaxStreamDuration;
    /**
    * request_mirror_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#request_mirror_policy ComputeRegionUrlMap#request_mirror_policy}
    */
    readonly requestMirrorPolicy?: ComputeRegionUrlMapPathMatcherDefaultRouteActionRequestMirrorPolicy;
    /**
    * retry_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#retry_policy ComputeRegionUrlMap#retry_policy}
    */
    readonly retryPolicy?: ComputeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicy;
    /**
    * timeout block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#timeout ComputeRegionUrlMap#timeout}
    */
    readonly timeout?: ComputeRegionUrlMapPathMatcherDefaultRouteActionTimeout;
    /**
    * url_rewrite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#url_rewrite ComputeRegionUrlMap#url_rewrite}
    */
    readonly urlRewrite?: ComputeRegionUrlMapPathMatcherDefaultRouteActionUrlRewrite;
    /**
    * weighted_backend_services block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#weighted_backend_services ComputeRegionUrlMap#weighted_backend_services}
    */
    readonly weightedBackendServices?: ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServices[] | cdktn.IResolvable;
}
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionToTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionOutputReference | ComputeRegionUrlMapPathMatcherDefaultRouteAction): any;
export declare function computeRegionUrlMapPathMatcherDefaultRouteActionToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultRouteActionOutputReference | ComputeRegionUrlMapPathMatcherDefaultRouteAction): any;
export declare class ComputeRegionUrlMapPathMatcherDefaultRouteActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherDefaultRouteAction | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherDefaultRouteAction | undefined);
    private _corsPolicy;
    get corsPolicy(): ComputeRegionUrlMapPathMatcherDefaultRouteActionCorsPolicyOutputReference;
    putCorsPolicy(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionCorsPolicy): void;
    resetCorsPolicy(): void;
    get corsPolicyInput(): ComputeRegionUrlMapPathMatcherDefaultRouteActionCorsPolicy | undefined;
    private _faultInjectionPolicy;
    get faultInjectionPolicy(): ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicyOutputReference;
    putFaultInjectionPolicy(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicy): void;
    resetFaultInjectionPolicy(): void;
    get faultInjectionPolicyInput(): ComputeRegionUrlMapPathMatcherDefaultRouteActionFaultInjectionPolicy | undefined;
    private _maxStreamDuration;
    get maxStreamDuration(): ComputeRegionUrlMapPathMatcherDefaultRouteActionMaxStreamDurationOutputReference;
    putMaxStreamDuration(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionMaxStreamDuration): void;
    resetMaxStreamDuration(): void;
    get maxStreamDurationInput(): ComputeRegionUrlMapPathMatcherDefaultRouteActionMaxStreamDuration | undefined;
    private _requestMirrorPolicy;
    get requestMirrorPolicy(): ComputeRegionUrlMapPathMatcherDefaultRouteActionRequestMirrorPolicyOutputReference;
    putRequestMirrorPolicy(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionRequestMirrorPolicy): void;
    resetRequestMirrorPolicy(): void;
    get requestMirrorPolicyInput(): ComputeRegionUrlMapPathMatcherDefaultRouteActionRequestMirrorPolicy | undefined;
    private _retryPolicy;
    get retryPolicy(): ComputeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicyOutputReference;
    putRetryPolicy(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicy): void;
    resetRetryPolicy(): void;
    get retryPolicyInput(): ComputeRegionUrlMapPathMatcherDefaultRouteActionRetryPolicy | undefined;
    private _timeout;
    get timeout(): ComputeRegionUrlMapPathMatcherDefaultRouteActionTimeoutOutputReference;
    putTimeout(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionTimeout): void;
    resetTimeout(): void;
    get timeoutInput(): ComputeRegionUrlMapPathMatcherDefaultRouteActionTimeout | undefined;
    private _urlRewrite;
    get urlRewrite(): ComputeRegionUrlMapPathMatcherDefaultRouteActionUrlRewriteOutputReference;
    putUrlRewrite(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionUrlRewrite): void;
    resetUrlRewrite(): void;
    get urlRewriteInput(): ComputeRegionUrlMapPathMatcherDefaultRouteActionUrlRewrite | undefined;
    private _weightedBackendServices;
    get weightedBackendServices(): ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServicesList;
    putWeightedBackendServices(value: ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServices[] | cdktn.IResolvable): void;
    resetWeightedBackendServices(): void;
    get weightedBackendServicesInput(): cdktn.IResolvable | ComputeRegionUrlMapPathMatcherDefaultRouteActionWeightedBackendServices[] | undefined;
}
export interface ComputeRegionUrlMapPathMatcherDefaultUrlRedirect {
    /**
    * The host that will be used in the redirect response instead of the one that was
    * supplied in the request. The value must be between 1 and 255 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#host_redirect ComputeRegionUrlMap#host_redirect}
    */
    readonly hostRedirect?: string;
    /**
    * If set to true, the URL scheme in the redirected request is set to https. If set to
    * false, the URL scheme of the redirected request will remain the same as that of the
    * request. This must only be set for UrlMaps used in TargetHttpProxys. Setting this
    * true for TargetHttpsProxy is not permitted. The default is set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#https_redirect ComputeRegionUrlMap#https_redirect}
    */
    readonly httpsRedirect?: boolean | cdktn.IResolvable;
    /**
    * The path that will be used in the redirect response instead of the one that was
    * supplied in the request. pathRedirect cannot be supplied together with
    * prefixRedirect. Supply one alone or neither. If neither is supplied, the path of the
    * original request will be used for the redirect. The value must be between 1 and 1024
    * characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#path_redirect ComputeRegionUrlMap#path_redirect}
    */
    readonly pathRedirect?: string;
    /**
    * The prefix that replaces the prefixMatch specified in the HttpRouteRuleMatch,
    * retaining the remaining portion of the URL before redirecting the request.
    * prefixRedirect cannot be supplied together with pathRedirect. Supply one alone or
    * neither. If neither is supplied, the path of the original request will be used for
    * the redirect. The value must be between 1 and 1024 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#prefix_redirect ComputeRegionUrlMap#prefix_redirect}
    */
    readonly prefixRedirect?: string;
    /**
    * The HTTP Status code to use for this RedirectAction. Supported values are:
    *
    * * MOVED_PERMANENTLY_DEFAULT, which is the default value and corresponds to 301.
    *
    * * FOUND, which corresponds to 302.
    *
    * * SEE_OTHER which corresponds to 303.
    *
    * * TEMPORARY_REDIRECT, which corresponds to 307. In this case, the request method
    * will be retained.
    *
    * * PERMANENT_REDIRECT, which corresponds to 308. In this case,
    * the request method will be retained. Possible values: ["FOUND", "MOVED_PERMANENTLY_DEFAULT", "PERMANENT_REDIRECT", "SEE_OTHER", "TEMPORARY_REDIRECT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#redirect_response_code ComputeRegionUrlMap#redirect_response_code}
    */
    readonly redirectResponseCode?: string;
    /**
    * If set to true, any accompanying query portion of the original URL is removed prior
    * to redirecting the request. If set to false, the query portion of the original URL is
    * retained.
    *  This field is required to ensure an empty block is not set. The normal default value is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#strip_query ComputeRegionUrlMap#strip_query}
    */
    readonly stripQuery: boolean | cdktn.IResolvable;
}
export declare function computeRegionUrlMapPathMatcherDefaultUrlRedirectToTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultUrlRedirectOutputReference | ComputeRegionUrlMapPathMatcherDefaultUrlRedirect): any;
export declare function computeRegionUrlMapPathMatcherDefaultUrlRedirectToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherDefaultUrlRedirectOutputReference | ComputeRegionUrlMapPathMatcherDefaultUrlRedirect): any;
export declare class ComputeRegionUrlMapPathMatcherDefaultUrlRedirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherDefaultUrlRedirect | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherDefaultUrlRedirect | undefined);
    private _hostRedirect?;
    get hostRedirect(): string;
    set hostRedirect(value: string);
    resetHostRedirect(): void;
    get hostRedirectInput(): string | undefined;
    private _httpsRedirect?;
    get httpsRedirect(): boolean | cdktn.IResolvable;
    set httpsRedirect(value: boolean | cdktn.IResolvable);
    resetHttpsRedirect(): void;
    get httpsRedirectInput(): boolean | cdktn.IResolvable | undefined;
    private _pathRedirect?;
    get pathRedirect(): string;
    set pathRedirect(value: string);
    resetPathRedirect(): void;
    get pathRedirectInput(): string | undefined;
    private _prefixRedirect?;
    get prefixRedirect(): string;
    set prefixRedirect(value: string);
    resetPrefixRedirect(): void;
    get prefixRedirectInput(): string | undefined;
    private _redirectResponseCode?;
    get redirectResponseCode(): string;
    set redirectResponseCode(value: string);
    resetRedirectResponseCode(): void;
    get redirectResponseCodeInput(): string | undefined;
    private _stripQuery?;
    get stripQuery(): boolean | cdktn.IResolvable;
    set stripQuery(value: boolean | cdktn.IResolvable);
    get stripQueryInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ComputeRegionUrlMapPathMatcherHeaderActionRequestHeadersToAdd {
    /**
    * The name of the header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_name ComputeRegionUrlMap#header_name}
    */
    readonly headerName?: string;
    /**
    * The value of the header to add.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_value ComputeRegionUrlMap#header_value}
    */
    readonly headerValue?: string;
    /**
    * If false, headerValue is appended to any values that already exist for the header. If true, headerValue is set for the header, discarding any values that were set for that header.
    * The default value is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#replace ComputeRegionUrlMap#replace}
    */
    readonly replace?: boolean | cdktn.IResolvable;
}
export declare function computeRegionUrlMapPathMatcherHeaderActionRequestHeadersToAddToTerraform(struct?: ComputeRegionUrlMapPathMatcherHeaderActionRequestHeadersToAdd | cdktn.IResolvable): any;
export declare function computeRegionUrlMapPathMatcherHeaderActionRequestHeadersToAddToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherHeaderActionRequestHeadersToAdd | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapPathMatcherHeaderActionRequestHeadersToAddOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapPathMatcherHeaderActionRequestHeadersToAdd | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherHeaderActionRequestHeadersToAdd | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    resetHeaderName(): void;
    get headerNameInput(): string | undefined;
    private _headerValue?;
    get headerValue(): string;
    set headerValue(value: string);
    resetHeaderValue(): void;
    get headerValueInput(): string | undefined;
    private _replace?;
    get replace(): boolean | cdktn.IResolvable;
    set replace(value: boolean | cdktn.IResolvable);
    resetReplace(): void;
    get replaceInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class ComputeRegionUrlMapPathMatcherHeaderActionRequestHeadersToAddList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapPathMatcherHeaderActionRequestHeadersToAdd[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapPathMatcherHeaderActionRequestHeadersToAddOutputReference;
}
export interface ComputeRegionUrlMapPathMatcherHeaderActionResponseHeadersToAdd {
    /**
    * The name of the header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_name ComputeRegionUrlMap#header_name}
    */
    readonly headerName?: string;
    /**
    * The value of the header to add.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_value ComputeRegionUrlMap#header_value}
    */
    readonly headerValue?: string;
    /**
    * If false, headerValue is appended to any values that already exist for the header. If true, headerValue is set for the header, discarding any values that were set for that header.
    * The default value is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#replace ComputeRegionUrlMap#replace}
    */
    readonly replace?: boolean | cdktn.IResolvable;
}
export declare function computeRegionUrlMapPathMatcherHeaderActionResponseHeadersToAddToTerraform(struct?: ComputeRegionUrlMapPathMatcherHeaderActionResponseHeadersToAdd | cdktn.IResolvable): any;
export declare function computeRegionUrlMapPathMatcherHeaderActionResponseHeadersToAddToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherHeaderActionResponseHeadersToAdd | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapPathMatcherHeaderActionResponseHeadersToAddOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapPathMatcherHeaderActionResponseHeadersToAdd | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherHeaderActionResponseHeadersToAdd | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    resetHeaderName(): void;
    get headerNameInput(): string | undefined;
    private _headerValue?;
    get headerValue(): string;
    set headerValue(value: string);
    resetHeaderValue(): void;
    get headerValueInput(): string | undefined;
    private _replace?;
    get replace(): boolean | cdktn.IResolvable;
    set replace(value: boolean | cdktn.IResolvable);
    resetReplace(): void;
    get replaceInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class ComputeRegionUrlMapPathMatcherHeaderActionResponseHeadersToAddList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapPathMatcherHeaderActionResponseHeadersToAdd[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapPathMatcherHeaderActionResponseHeadersToAddOutputReference;
}
export interface ComputeRegionUrlMapPathMatcherHeaderAction {
    /**
    * A list of header names for headers that need to be removed from the request before forwarding the request to the backendService.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#request_headers_to_remove ComputeRegionUrlMap#request_headers_to_remove}
    */
    readonly requestHeadersToRemove?: string[];
    /**
    * A list of header names for headers that need to be removed from the response before sending the response back to the client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#response_headers_to_remove ComputeRegionUrlMap#response_headers_to_remove}
    */
    readonly responseHeadersToRemove?: string[];
    /**
    * request_headers_to_add block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#request_headers_to_add ComputeRegionUrlMap#request_headers_to_add}
    */
    readonly requestHeadersToAdd?: ComputeRegionUrlMapPathMatcherHeaderActionRequestHeadersToAdd[] | cdktn.IResolvable;
    /**
    * response_headers_to_add block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#response_headers_to_add ComputeRegionUrlMap#response_headers_to_add}
    */
    readonly responseHeadersToAdd?: ComputeRegionUrlMapPathMatcherHeaderActionResponseHeadersToAdd[] | cdktn.IResolvable;
}
export declare function computeRegionUrlMapPathMatcherHeaderActionToTerraform(struct?: ComputeRegionUrlMapPathMatcherHeaderActionOutputReference | ComputeRegionUrlMapPathMatcherHeaderAction): any;
export declare function computeRegionUrlMapPathMatcherHeaderActionToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherHeaderActionOutputReference | ComputeRegionUrlMapPathMatcherHeaderAction): any;
export declare class ComputeRegionUrlMapPathMatcherHeaderActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherHeaderAction | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherHeaderAction | undefined);
    private _requestHeadersToRemove?;
    get requestHeadersToRemove(): string[];
    set requestHeadersToRemove(value: string[]);
    resetRequestHeadersToRemove(): void;
    get requestHeadersToRemoveInput(): string[] | undefined;
    private _responseHeadersToRemove?;
    get responseHeadersToRemove(): string[];
    set responseHeadersToRemove(value: string[]);
    resetResponseHeadersToRemove(): void;
    get responseHeadersToRemoveInput(): string[] | undefined;
    private _requestHeadersToAdd;
    get requestHeadersToAdd(): ComputeRegionUrlMapPathMatcherHeaderActionRequestHeadersToAddList;
    putRequestHeadersToAdd(value: ComputeRegionUrlMapPathMatcherHeaderActionRequestHeadersToAdd[] | cdktn.IResolvable): void;
    resetRequestHeadersToAdd(): void;
    get requestHeadersToAddInput(): cdktn.IResolvable | ComputeRegionUrlMapPathMatcherHeaderActionRequestHeadersToAdd[] | undefined;
    private _responseHeadersToAdd;
    get responseHeadersToAdd(): ComputeRegionUrlMapPathMatcherHeaderActionResponseHeadersToAddList;
    putResponseHeadersToAdd(value: ComputeRegionUrlMapPathMatcherHeaderActionResponseHeadersToAdd[] | cdktn.IResolvable): void;
    resetResponseHeadersToAdd(): void;
    get responseHeadersToAddInput(): cdktn.IResolvable | ComputeRegionUrlMapPathMatcherHeaderActionResponseHeadersToAdd[] | undefined;
}
export interface ComputeRegionUrlMapPathMatcherPathRuleRouteActionCorsPolicy {
    /**
    * In response to a preflight request, setting this to true indicates that the
    * actual request can include user credentials. This translates to the Access-
    * Control-Allow-Credentials header. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#allow_credentials ComputeRegionUrlMap#allow_credentials}
    */
    readonly allowCredentials?: boolean | cdktn.IResolvable;
    /**
    * Specifies the content for the Access-Control-Allow-Headers header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#allow_headers ComputeRegionUrlMap#allow_headers}
    */
    readonly allowHeaders?: string[];
    /**
    * Specifies the content for the Access-Control-Allow-Methods header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#allow_methods ComputeRegionUrlMap#allow_methods}
    */
    readonly allowMethods?: string[];
    /**
    * Specifies the regular expression patterns that match allowed origins. For
    * regular expression grammar please see en.cppreference.com/w/cpp/regex/ecmascript
    * An origin is allowed if it matches either allow_origins or allow_origin_regex.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#allow_origin_regexes ComputeRegionUrlMap#allow_origin_regexes}
    */
    readonly allowOriginRegexes?: string[];
    /**
    * Specifies the list of origins that will be allowed to do CORS requests. An
    * origin is allowed if it matches either allow_origins or allow_origin_regex.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#allow_origins ComputeRegionUrlMap#allow_origins}
    */
    readonly allowOrigins?: string[];
    /**
    * If true, specifies the CORS policy is disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#disabled ComputeRegionUrlMap#disabled}
    */
    readonly disabled: boolean | cdktn.IResolvable;
    /**
    * Specifies the content for the Access-Control-Expose-Headers header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#expose_headers ComputeRegionUrlMap#expose_headers}
    */
    readonly exposeHeaders?: string[];
    /**
    * Specifies how long the results of a preflight request can be cached. This
    * translates to the content for the Access-Control-Max-Age header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#max_age ComputeRegionUrlMap#max_age}
    */
    readonly maxAge?: number;
}
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionCorsPolicyToTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionCorsPolicyOutputReference | ComputeRegionUrlMapPathMatcherPathRuleRouteActionCorsPolicy): any;
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionCorsPolicyToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionCorsPolicyOutputReference | ComputeRegionUrlMapPathMatcherPathRuleRouteActionCorsPolicy): any;
export declare class ComputeRegionUrlMapPathMatcherPathRuleRouteActionCorsPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionCorsPolicy | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionCorsPolicy | undefined);
    private _allowCredentials?;
    get allowCredentials(): boolean | cdktn.IResolvable;
    set allowCredentials(value: boolean | cdktn.IResolvable);
    resetAllowCredentials(): void;
    get allowCredentialsInput(): boolean | cdktn.IResolvable | undefined;
    private _allowHeaders?;
    get allowHeaders(): string[];
    set allowHeaders(value: string[]);
    resetAllowHeaders(): void;
    get allowHeadersInput(): string[] | undefined;
    private _allowMethods?;
    get allowMethods(): string[];
    set allowMethods(value: string[]);
    resetAllowMethods(): void;
    get allowMethodsInput(): string[] | undefined;
    private _allowOriginRegexes?;
    get allowOriginRegexes(): string[];
    set allowOriginRegexes(value: string[]);
    resetAllowOriginRegexes(): void;
    get allowOriginRegexesInput(): string[] | undefined;
    private _allowOrigins?;
    get allowOrigins(): string[];
    set allowOrigins(value: string[]);
    resetAllowOrigins(): void;
    get allowOriginsInput(): string[] | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _exposeHeaders?;
    get exposeHeaders(): string[];
    set exposeHeaders(value: string[]);
    resetExposeHeaders(): void;
    get exposeHeadersInput(): string[] | undefined;
    private _maxAge?;
    get maxAge(): number;
    set maxAge(value: number);
    resetMaxAge(): void;
    get maxAgeInput(): number | undefined;
}
export interface ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyAbort {
    /**
    * The HTTP status code used to abort the request. The value must be between 200
    * and 599 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#http_status ComputeRegionUrlMap#http_status}
    */
    readonly httpStatus: number;
    /**
    * The percentage of traffic (connections/operations/requests) which will be
    * aborted as part of fault injection. The value must be between 0.0 and 100.0
    * inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#percentage ComputeRegionUrlMap#percentage}
    */
    readonly percentage: number;
}
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyAbortToTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyAbortOutputReference | ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyAbort): any;
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyAbortToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyAbortOutputReference | ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyAbort): any;
export declare class ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyAbortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyAbort | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyAbort | undefined);
    private _httpStatus?;
    get httpStatus(): number;
    set httpStatus(value: number);
    get httpStatusInput(): number | undefined;
    private _percentage?;
    get percentage(): number;
    set percentage(value: number);
    get percentageInput(): number | undefined;
}
export interface ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelayFixedDelay {
    /**
    * Span of time that's a fraction of a second at nanosecond resolution. Durations
    * less than one second are represented with a 0 'seconds' field and a positive
    * 'nanos' field. Must be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#nanos ComputeRegionUrlMap#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second. Must be from 0 to 315,576,000,000
    * inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#seconds ComputeRegionUrlMap#seconds}
    */
    readonly seconds: string;
}
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelayFixedDelayToTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelayFixedDelayOutputReference | ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelayFixedDelay): any;
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelayFixedDelayToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelayFixedDelayOutputReference | ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelayFixedDelay): any;
export declare class ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelayFixedDelayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelayFixedDelay | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelayFixedDelay | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): string;
    set seconds(value: string);
    get secondsInput(): string | undefined;
}
export interface ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelay {
    /**
    * The percentage of traffic (connections/operations/requests) on which delay will
    * be introduced as part of fault injection. The value must be between 0.0 and
    * 100.0 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#percentage ComputeRegionUrlMap#percentage}
    */
    readonly percentage: number;
    /**
    * fixed_delay block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#fixed_delay ComputeRegionUrlMap#fixed_delay}
    */
    readonly fixedDelay: ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelayFixedDelay;
}
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelayToTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelayOutputReference | ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelay): any;
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelayToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelayOutputReference | ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelay): any;
export declare class ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelay | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelay | undefined);
    private _percentage?;
    get percentage(): number;
    set percentage(value: number);
    get percentageInput(): number | undefined;
    private _fixedDelay;
    get fixedDelay(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelayFixedDelayOutputReference;
    putFixedDelay(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelayFixedDelay): void;
    get fixedDelayInput(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelayFixedDelay | undefined;
}
export interface ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicy {
    /**
    * abort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#abort ComputeRegionUrlMap#abort}
    */
    readonly abort?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyAbort;
    /**
    * delay block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#delay ComputeRegionUrlMap#delay}
    */
    readonly delay?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelay;
}
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyToTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyOutputReference | ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicy): any;
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyOutputReference | ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicy): any;
export declare class ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicy | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicy | undefined);
    private _abort;
    get abort(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyAbortOutputReference;
    putAbort(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyAbort): void;
    resetAbort(): void;
    get abortInput(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyAbort | undefined;
    private _delay;
    get delay(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelayOutputReference;
    putDelay(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelay): void;
    resetDelay(): void;
    get delayInput(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyDelay | undefined;
}
export interface ComputeRegionUrlMapPathMatcherPathRuleRouteActionRequestMirrorPolicy {
    /**
    * The RegionBackendService resource being mirrored to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#backend_service ComputeRegionUrlMap#backend_service}
    */
    readonly backendService: string;
    /**
    * The percentage of requests to be mirrored to backendService.
    * The value must be between 0.0 and 100.0 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#mirror_percent ComputeRegionUrlMap#mirror_percent}
    */
    readonly mirrorPercent?: number;
}
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionRequestMirrorPolicyToTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionRequestMirrorPolicyOutputReference | ComputeRegionUrlMapPathMatcherPathRuleRouteActionRequestMirrorPolicy): any;
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionRequestMirrorPolicyToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionRequestMirrorPolicyOutputReference | ComputeRegionUrlMapPathMatcherPathRuleRouteActionRequestMirrorPolicy): any;
export declare class ComputeRegionUrlMapPathMatcherPathRuleRouteActionRequestMirrorPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionRequestMirrorPolicy | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionRequestMirrorPolicy | undefined);
    private _backendService?;
    get backendService(): string;
    set backendService(value: string);
    get backendServiceInput(): string | undefined;
    private _mirrorPercent?;
    get mirrorPercent(): number;
    set mirrorPercent(value: number);
    resetMirrorPercent(): void;
    get mirrorPercentInput(): number | undefined;
}
export interface ComputeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicyPerTryTimeout {
    /**
    * Span of time that's a fraction of a second at nanosecond resolution. Durations
    * less than one second are represented with a 0 'seconds' field and a positive
    * 'nanos' field. Must be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#nanos ComputeRegionUrlMap#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second. Must be from 0 to 315,576,000,000
    * inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#seconds ComputeRegionUrlMap#seconds}
    */
    readonly seconds: string;
}
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicyPerTryTimeoutToTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicyPerTryTimeoutOutputReference | ComputeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicyPerTryTimeout): any;
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicyPerTryTimeoutToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicyPerTryTimeoutOutputReference | ComputeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicyPerTryTimeout): any;
export declare class ComputeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicyPerTryTimeoutOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicyPerTryTimeout | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicyPerTryTimeout | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): string;
    set seconds(value: string);
    get secondsInput(): string | undefined;
}
export interface ComputeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicy {
    /**
    * Specifies the allowed number retries. This number must be > 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#num_retries ComputeRegionUrlMap#num_retries}
    */
    readonly numRetries?: number;
    /**
    * Specifies one or more conditions when this retry rule applies. Valid values are:
    *
    * - 5xx: Loadbalancer will attempt a retry if the backend service responds with
    * any 5xx response code, or if the backend service does not respond at all,
    * for example: disconnects, reset, read timeout, connection failure, and refused
    * streams.
    * - gateway-error: Similar to 5xx, but only applies to response codes
    * 502, 503 or 504.
    * - connect-failure: Loadbalancer will retry on failures
    * connecting to backend services, for example due to connection timeouts.
    * - retriable-4xx: Loadbalancer will retry for retriable 4xx response codes.
    * Currently the only retriable error supported is 409.
    * - refused-stream: Loadbalancer will retry if the backend service resets the stream with a
    * REFUSED_STREAM error code. This reset type indicates that it is safe to retry.
    * - cancelled: Loadbalancer will retry if the gRPC status code in the response
    * header is set to cancelled
    * - deadline-exceeded: Loadbalancer will retry if the
    * gRPC status code in the response header is set to deadline-exceeded
    * - resource-exhausted: Loadbalancer will retry if the gRPC status code in the response
    * header is set to resource-exhausted
    * - unavailable: Loadbalancer will retry if
    * the gRPC status code in the response header is set to unavailable
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#retry_conditions ComputeRegionUrlMap#retry_conditions}
    */
    readonly retryConditions?: string[];
    /**
    * per_try_timeout block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#per_try_timeout ComputeRegionUrlMap#per_try_timeout}
    */
    readonly perTryTimeout?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicyPerTryTimeout;
}
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicyToTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicyOutputReference | ComputeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicy): any;
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicyToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicyOutputReference | ComputeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicy): any;
export declare class ComputeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicy | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicy | undefined);
    private _numRetries?;
    get numRetries(): number;
    set numRetries(value: number);
    resetNumRetries(): void;
    get numRetriesInput(): number | undefined;
    private _retryConditions?;
    get retryConditions(): string[];
    set retryConditions(value: string[]);
    resetRetryConditions(): void;
    get retryConditionsInput(): string[] | undefined;
    private _perTryTimeout;
    get perTryTimeout(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicyPerTryTimeoutOutputReference;
    putPerTryTimeout(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicyPerTryTimeout): void;
    resetPerTryTimeout(): void;
    get perTryTimeoutInput(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicyPerTryTimeout | undefined;
}
export interface ComputeRegionUrlMapPathMatcherPathRuleRouteActionTimeout {
    /**
    * Span of time that's a fraction of a second at nanosecond resolution. Durations
    * less than one second are represented with a 0 'seconds' field and a positive
    * 'nanos' field. Must be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#nanos ComputeRegionUrlMap#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second. Must be from 0 to 315,576,000,000
    * inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#seconds ComputeRegionUrlMap#seconds}
    */
    readonly seconds: string;
}
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionTimeoutToTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionTimeoutOutputReference | ComputeRegionUrlMapPathMatcherPathRuleRouteActionTimeout): any;
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionTimeoutToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionTimeoutOutputReference | ComputeRegionUrlMapPathMatcherPathRuleRouteActionTimeout): any;
export declare class ComputeRegionUrlMapPathMatcherPathRuleRouteActionTimeoutOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionTimeout | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionTimeout | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): string;
    set seconds(value: string);
    get secondsInput(): string | undefined;
}
export interface ComputeRegionUrlMapPathMatcherPathRuleRouteActionUrlRewrite {
    /**
    * Prior to forwarding the request to the selected service, the request's host
    * header is replaced with contents of hostRewrite. The value must be between 1 and
    * 255 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#host_rewrite ComputeRegionUrlMap#host_rewrite}
    */
    readonly hostRewrite?: string;
    /**
    * Prior to forwarding the request to the selected backend service, the matching
    * portion of the request's path is replaced by pathPrefixRewrite. The value must
    * be between 1 and 1024 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#path_prefix_rewrite ComputeRegionUrlMap#path_prefix_rewrite}
    */
    readonly pathPrefixRewrite?: string;
}
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionUrlRewriteToTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionUrlRewriteOutputReference | ComputeRegionUrlMapPathMatcherPathRuleRouteActionUrlRewrite): any;
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionUrlRewriteToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionUrlRewriteOutputReference | ComputeRegionUrlMapPathMatcherPathRuleRouteActionUrlRewrite): any;
export declare class ComputeRegionUrlMapPathMatcherPathRuleRouteActionUrlRewriteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionUrlRewrite | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionUrlRewrite | undefined);
    private _hostRewrite?;
    get hostRewrite(): string;
    set hostRewrite(value: string);
    resetHostRewrite(): void;
    get hostRewriteInput(): string | undefined;
    private _pathPrefixRewrite?;
    get pathPrefixRewrite(): string;
    set pathPrefixRewrite(value: string);
    resetPathPrefixRewrite(): void;
    get pathPrefixRewriteInput(): string | undefined;
}
export interface ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd {
    /**
    * The name of the header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_name ComputeRegionUrlMap#header_name}
    */
    readonly headerName: string;
    /**
    * The value of the header to add.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_value ComputeRegionUrlMap#header_value}
    */
    readonly headerValue: string;
    /**
    * If false, headerValue is appended to any values that already exist for the
    * header. If true, headerValue is set for the header, discarding any values that
    * were set for that header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#replace ComputeRegionUrlMap#replace}
    */
    readonly replace: boolean | cdktn.IResolvable;
}
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAddToTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd | cdktn.IResolvable): any;
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAddToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAddOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    get headerNameInput(): string | undefined;
    private _headerValue?;
    get headerValue(): string;
    set headerValue(value: string);
    get headerValueInput(): string | undefined;
    private _replace?;
    get replace(): boolean | cdktn.IResolvable;
    set replace(value: boolean | cdktn.IResolvable);
    get replaceInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAddList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAddOutputReference;
}
export interface ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd {
    /**
    * The name of the header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_name ComputeRegionUrlMap#header_name}
    */
    readonly headerName: string;
    /**
    * The value of the header to add.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_value ComputeRegionUrlMap#header_value}
    */
    readonly headerValue: string;
    /**
    * If false, headerValue is appended to any values that already exist for the
    * header. If true, headerValue is set for the header, discarding any values that
    * were set for that header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#replace ComputeRegionUrlMap#replace}
    */
    readonly replace: boolean | cdktn.IResolvable;
}
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAddToTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd | cdktn.IResolvable): any;
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAddToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAddOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    get headerNameInput(): string | undefined;
    private _headerValue?;
    get headerValue(): string;
    set headerValue(value: string);
    get headerValueInput(): string | undefined;
    private _replace?;
    get replace(): boolean | cdktn.IResolvable;
    set replace(value: boolean | cdktn.IResolvable);
    get replaceInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAddList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAddOutputReference;
}
export interface ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderAction {
    /**
    * A list of header names for headers that need to be removed from the request
    * prior to forwarding the request to the backendService.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#request_headers_to_remove ComputeRegionUrlMap#request_headers_to_remove}
    */
    readonly requestHeadersToRemove?: string[];
    /**
    * A list of header names for headers that need to be removed from the response
    * prior to sending the response back to the client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#response_headers_to_remove ComputeRegionUrlMap#response_headers_to_remove}
    */
    readonly responseHeadersToRemove?: string[];
    /**
    * request_headers_to_add block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#request_headers_to_add ComputeRegionUrlMap#request_headers_to_add}
    */
    readonly requestHeadersToAdd?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd[] | cdktn.IResolvable;
    /**
    * response_headers_to_add block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#response_headers_to_add ComputeRegionUrlMap#response_headers_to_add}
    */
    readonly responseHeadersToAdd?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd[] | cdktn.IResolvable;
}
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionToTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionOutputReference | ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderAction): any;
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionOutputReference | ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderAction): any;
export declare class ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderAction | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderAction | undefined);
    private _requestHeadersToRemove?;
    get requestHeadersToRemove(): string[];
    set requestHeadersToRemove(value: string[]);
    resetRequestHeadersToRemove(): void;
    get requestHeadersToRemoveInput(): string[] | undefined;
    private _responseHeadersToRemove?;
    get responseHeadersToRemove(): string[];
    set responseHeadersToRemove(value: string[]);
    resetResponseHeadersToRemove(): void;
    get responseHeadersToRemoveInput(): string[] | undefined;
    private _requestHeadersToAdd;
    get requestHeadersToAdd(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAddList;
    putRequestHeadersToAdd(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd[] | cdktn.IResolvable): void;
    resetRequestHeadersToAdd(): void;
    get requestHeadersToAddInput(): cdktn.IResolvable | ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd[] | undefined;
    private _responseHeadersToAdd;
    get responseHeadersToAdd(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAddList;
    putResponseHeadersToAdd(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd[] | cdktn.IResolvable): void;
    resetResponseHeadersToAdd(): void;
    get responseHeadersToAddInput(): cdktn.IResolvable | ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd[] | undefined;
}
export interface ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServices {
    /**
    * The default RegionBackendService resource. Before
    * forwarding the request to backendService, the loadbalancer applies any relevant
    * headerActions specified as part of this backendServiceWeight.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#backend_service ComputeRegionUrlMap#backend_service}
    */
    readonly backendService: string;
    /**
    * Specifies the fraction of traffic sent to backendService, computed as weight /
    * (sum of all weightedBackendService weights in routeAction) . The selection of a
    * backend service is determined only for new traffic. Once a user's request has
    * been directed to a backendService, subsequent requests will be sent to the same
    * backendService as determined by the BackendService's session affinity policy.
    * The value must be between 0 and 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#weight ComputeRegionUrlMap#weight}
    */
    readonly weight: number;
    /**
    * header_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_action ComputeRegionUrlMap#header_action}
    */
    readonly headerAction?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderAction;
}
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesToTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServices | cdktn.IResolvable): any;
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServices | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServices | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServices | cdktn.IResolvable | undefined);
    private _backendService?;
    get backendService(): string;
    set backendService(value: string);
    get backendServiceInput(): string | undefined;
    private _weight?;
    get weight(): number;
    set weight(value: number);
    get weightInput(): number | undefined;
    private _headerAction;
    get headerAction(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderActionOutputReference;
    putHeaderAction(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderAction): void;
    resetHeaderAction(): void;
    get headerActionInput(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesHeaderAction | undefined;
}
export declare class ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServices[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesOutputReference;
}
export interface ComputeRegionUrlMapPathMatcherPathRuleRouteAction {
    /**
    * cors_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#cors_policy ComputeRegionUrlMap#cors_policy}
    */
    readonly corsPolicy?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionCorsPolicy;
    /**
    * fault_injection_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#fault_injection_policy ComputeRegionUrlMap#fault_injection_policy}
    */
    readonly faultInjectionPolicy?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicy;
    /**
    * request_mirror_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#request_mirror_policy ComputeRegionUrlMap#request_mirror_policy}
    */
    readonly requestMirrorPolicy?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionRequestMirrorPolicy;
    /**
    * retry_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#retry_policy ComputeRegionUrlMap#retry_policy}
    */
    readonly retryPolicy?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicy;
    /**
    * timeout block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#timeout ComputeRegionUrlMap#timeout}
    */
    readonly timeout?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionTimeout;
    /**
    * url_rewrite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#url_rewrite ComputeRegionUrlMap#url_rewrite}
    */
    readonly urlRewrite?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionUrlRewrite;
    /**
    * weighted_backend_services block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#weighted_backend_services ComputeRegionUrlMap#weighted_backend_services}
    */
    readonly weightedBackendServices?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServices[] | cdktn.IResolvable;
}
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionToTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionOutputReference | ComputeRegionUrlMapPathMatcherPathRuleRouteAction): any;
export declare function computeRegionUrlMapPathMatcherPathRuleRouteActionToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleRouteActionOutputReference | ComputeRegionUrlMapPathMatcherPathRuleRouteAction): any;
export declare class ComputeRegionUrlMapPathMatcherPathRuleRouteActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherPathRuleRouteAction | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherPathRuleRouteAction | undefined);
    private _corsPolicy;
    get corsPolicy(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionCorsPolicyOutputReference;
    putCorsPolicy(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionCorsPolicy): void;
    resetCorsPolicy(): void;
    get corsPolicyInput(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionCorsPolicy | undefined;
    private _faultInjectionPolicy;
    get faultInjectionPolicy(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicyOutputReference;
    putFaultInjectionPolicy(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicy): void;
    resetFaultInjectionPolicy(): void;
    get faultInjectionPolicyInput(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionFaultInjectionPolicy | undefined;
    private _requestMirrorPolicy;
    get requestMirrorPolicy(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionRequestMirrorPolicyOutputReference;
    putRequestMirrorPolicy(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionRequestMirrorPolicy): void;
    resetRequestMirrorPolicy(): void;
    get requestMirrorPolicyInput(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionRequestMirrorPolicy | undefined;
    private _retryPolicy;
    get retryPolicy(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicyOutputReference;
    putRetryPolicy(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicy): void;
    resetRetryPolicy(): void;
    get retryPolicyInput(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionRetryPolicy | undefined;
    private _timeout;
    get timeout(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionTimeoutOutputReference;
    putTimeout(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionTimeout): void;
    resetTimeout(): void;
    get timeoutInput(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionTimeout | undefined;
    private _urlRewrite;
    get urlRewrite(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionUrlRewriteOutputReference;
    putUrlRewrite(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionUrlRewrite): void;
    resetUrlRewrite(): void;
    get urlRewriteInput(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionUrlRewrite | undefined;
    private _weightedBackendServices;
    get weightedBackendServices(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServicesList;
    putWeightedBackendServices(value: ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServices[] | cdktn.IResolvable): void;
    resetWeightedBackendServices(): void;
    get weightedBackendServicesInput(): cdktn.IResolvable | ComputeRegionUrlMapPathMatcherPathRuleRouteActionWeightedBackendServices[] | undefined;
}
export interface ComputeRegionUrlMapPathMatcherPathRuleUrlRedirect {
    /**
    * The host that will be used in the redirect response instead of the one
    * that was supplied in the request. The value must be between 1 and 255
    * characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#host_redirect ComputeRegionUrlMap#host_redirect}
    */
    readonly hostRedirect?: string;
    /**
    * If set to true, the URL scheme in the redirected request is set to https.
    * If set to false, the URL scheme of the redirected request will remain the
    * same as that of the request. This must only be set for UrlMaps used in
    * TargetHttpProxys. Setting this true for TargetHttpsProxy is not
    * permitted. The default is set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#https_redirect ComputeRegionUrlMap#https_redirect}
    */
    readonly httpsRedirect?: boolean | cdktn.IResolvable;
    /**
    * The path that will be used in the redirect response instead of the one
    * that was supplied in the request. pathRedirect cannot be supplied
    * together with prefixRedirect. Supply one alone or neither. If neither is
    * supplied, the path of the original request will be used for the redirect.
    * The value must be between 1 and 1024 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#path_redirect ComputeRegionUrlMap#path_redirect}
    */
    readonly pathRedirect?: string;
    /**
    * The prefix that replaces the prefixMatch specified in the
    * HttpRouteRuleMatch, retaining the remaining portion of the URL before
    * redirecting the request. prefixRedirect cannot be supplied together with
    * pathRedirect. Supply one alone or neither. If neither is supplied, the
    * path of the original request will be used for the redirect. The value
    * must be between 1 and 1024 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#prefix_redirect ComputeRegionUrlMap#prefix_redirect}
    */
    readonly prefixRedirect?: string;
    /**
    * The HTTP Status code to use for this RedirectAction. Supported values are:
    *
    * * MOVED_PERMANENTLY_DEFAULT, which is the default value and corresponds to 301.
    *
    * * FOUND, which corresponds to 302.
    *
    * * SEE_OTHER which corresponds to 303.
    *
    * * TEMPORARY_REDIRECT, which corresponds to 307. In this case, the request method
    * will be retained.
    *
    * * PERMANENT_REDIRECT, which corresponds to 308. In this case,
    * the request method will be retained. Possible values: ["FOUND", "MOVED_PERMANENTLY_DEFAULT", "PERMANENT_REDIRECT", "SEE_OTHER", "TEMPORARY_REDIRECT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#redirect_response_code ComputeRegionUrlMap#redirect_response_code}
    */
    readonly redirectResponseCode?: string;
    /**
    * If set to true, any accompanying query portion of the original URL is removed
    * prior to redirecting the request. If set to false, the query portion of the
    * original URL is retained.
    *  This field is required to ensure an empty block is not set. The normal default value is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#strip_query ComputeRegionUrlMap#strip_query}
    */
    readonly stripQuery: boolean | cdktn.IResolvable;
}
export declare function computeRegionUrlMapPathMatcherPathRuleUrlRedirectToTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleUrlRedirectOutputReference | ComputeRegionUrlMapPathMatcherPathRuleUrlRedirect): any;
export declare function computeRegionUrlMapPathMatcherPathRuleUrlRedirectToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRuleUrlRedirectOutputReference | ComputeRegionUrlMapPathMatcherPathRuleUrlRedirect): any;
export declare class ComputeRegionUrlMapPathMatcherPathRuleUrlRedirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherPathRuleUrlRedirect | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherPathRuleUrlRedirect | undefined);
    private _hostRedirect?;
    get hostRedirect(): string;
    set hostRedirect(value: string);
    resetHostRedirect(): void;
    get hostRedirectInput(): string | undefined;
    private _httpsRedirect?;
    get httpsRedirect(): boolean | cdktn.IResolvable;
    set httpsRedirect(value: boolean | cdktn.IResolvable);
    resetHttpsRedirect(): void;
    get httpsRedirectInput(): boolean | cdktn.IResolvable | undefined;
    private _pathRedirect?;
    get pathRedirect(): string;
    set pathRedirect(value: string);
    resetPathRedirect(): void;
    get pathRedirectInput(): string | undefined;
    private _prefixRedirect?;
    get prefixRedirect(): string;
    set prefixRedirect(value: string);
    resetPrefixRedirect(): void;
    get prefixRedirectInput(): string | undefined;
    private _redirectResponseCode?;
    get redirectResponseCode(): string;
    set redirectResponseCode(value: string);
    resetRedirectResponseCode(): void;
    get redirectResponseCodeInput(): string | undefined;
    private _stripQuery?;
    get stripQuery(): boolean | cdktn.IResolvable;
    set stripQuery(value: boolean | cdktn.IResolvable);
    get stripQueryInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ComputeRegionUrlMapPathMatcherPathRule {
    /**
    * The list of path patterns to match. Each must start with / and the only place a
    * \* is allowed is at the end following a /. The string fed to the path matcher
    * does not include any text after the first ? or #, and those chars are not
    * allowed here.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#paths ComputeRegionUrlMap#paths}
    */
    readonly paths: string[];
    /**
    * The region backend service resource to which traffic is
    * directed if this rule is matched. If routeAction is additionally specified,
    * advanced routing actions like URL Rewrites, etc. take effect prior to sending
    * the request to the backend. However, if service is specified, routeAction cannot
    * contain any weightedBackendService s. Conversely, if routeAction specifies any
    * weightedBackendServices, service must not be specified. Only one of urlRedirect,
    * service or routeAction.weightedBackendService must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#service ComputeRegionUrlMap#service}
    */
    readonly service?: string;
    /**
    * route_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#route_action ComputeRegionUrlMap#route_action}
    */
    readonly routeAction?: ComputeRegionUrlMapPathMatcherPathRuleRouteAction;
    /**
    * url_redirect block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#url_redirect ComputeRegionUrlMap#url_redirect}
    */
    readonly urlRedirect?: ComputeRegionUrlMapPathMatcherPathRuleUrlRedirect;
}
export declare function computeRegionUrlMapPathMatcherPathRuleToTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRule | cdktn.IResolvable): any;
export declare function computeRegionUrlMapPathMatcherPathRuleToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherPathRule | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapPathMatcherPathRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapPathMatcherPathRule | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherPathRule | cdktn.IResolvable | undefined);
    private _paths?;
    get paths(): string[];
    set paths(value: string[]);
    get pathsInput(): string[] | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
    private _routeAction;
    get routeAction(): ComputeRegionUrlMapPathMatcherPathRuleRouteActionOutputReference;
    putRouteAction(value: ComputeRegionUrlMapPathMatcherPathRuleRouteAction): void;
    resetRouteAction(): void;
    get routeActionInput(): ComputeRegionUrlMapPathMatcherPathRuleRouteAction | undefined;
    private _urlRedirect;
    get urlRedirect(): ComputeRegionUrlMapPathMatcherPathRuleUrlRedirectOutputReference;
    putUrlRedirect(value: ComputeRegionUrlMapPathMatcherPathRuleUrlRedirect): void;
    resetUrlRedirect(): void;
    get urlRedirectInput(): ComputeRegionUrlMapPathMatcherPathRuleUrlRedirect | undefined;
}
export declare class ComputeRegionUrlMapPathMatcherPathRuleList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapPathMatcherPathRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapPathMatcherPathRuleOutputReference;
}
export interface ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionRequestHeadersToAdd {
    /**
    * The name of the header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_name ComputeRegionUrlMap#header_name}
    */
    readonly headerName: string;
    /**
    * The value of the header to add.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_value ComputeRegionUrlMap#header_value}
    */
    readonly headerValue: string;
    /**
    * If false, headerValue is appended to any values that already exist for the
    * header. If true, headerValue is set for the header, discarding any values that
    * were set for that header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#replace ComputeRegionUrlMap#replace}
    */
    readonly replace: boolean | cdktn.IResolvable;
}
export declare function computeRegionUrlMapPathMatcherRouteRulesHeaderActionRequestHeadersToAddToTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionRequestHeadersToAdd | cdktn.IResolvable): any;
export declare function computeRegionUrlMapPathMatcherRouteRulesHeaderActionRequestHeadersToAddToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionRequestHeadersToAdd | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionRequestHeadersToAddOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionRequestHeadersToAdd | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionRequestHeadersToAdd | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    get headerNameInput(): string | undefined;
    private _headerValue?;
    get headerValue(): string;
    set headerValue(value: string);
    get headerValueInput(): string | undefined;
    private _replace?;
    get replace(): boolean | cdktn.IResolvable;
    set replace(value: boolean | cdktn.IResolvable);
    get replaceInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionRequestHeadersToAddList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionRequestHeadersToAdd[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionRequestHeadersToAddOutputReference;
}
export interface ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionResponseHeadersToAdd {
    /**
    * The name of the header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_name ComputeRegionUrlMap#header_name}
    */
    readonly headerName: string;
    /**
    * The value of the header to add.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_value ComputeRegionUrlMap#header_value}
    */
    readonly headerValue: string;
    /**
    * If false, headerValue is appended to any values that already exist for the
    * header. If true, headerValue is set for the header, discarding any values that
    * were set for that header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#replace ComputeRegionUrlMap#replace}
    */
    readonly replace: boolean | cdktn.IResolvable;
}
export declare function computeRegionUrlMapPathMatcherRouteRulesHeaderActionResponseHeadersToAddToTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionResponseHeadersToAdd | cdktn.IResolvable): any;
export declare function computeRegionUrlMapPathMatcherRouteRulesHeaderActionResponseHeadersToAddToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionResponseHeadersToAdd | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionResponseHeadersToAddOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionResponseHeadersToAdd | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionResponseHeadersToAdd | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    get headerNameInput(): string | undefined;
    private _headerValue?;
    get headerValue(): string;
    set headerValue(value: string);
    get headerValueInput(): string | undefined;
    private _replace?;
    get replace(): boolean | cdktn.IResolvable;
    set replace(value: boolean | cdktn.IResolvable);
    get replaceInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionResponseHeadersToAddList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionResponseHeadersToAdd[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionResponseHeadersToAddOutputReference;
}
export interface ComputeRegionUrlMapPathMatcherRouteRulesHeaderAction {
    /**
    * A list of header names for headers that need to be removed from the request
    * prior to forwarding the request to the backendService.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#request_headers_to_remove ComputeRegionUrlMap#request_headers_to_remove}
    */
    readonly requestHeadersToRemove?: string[];
    /**
    * A list of header names for headers that need to be removed from the response
    * prior to sending the response back to the client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#response_headers_to_remove ComputeRegionUrlMap#response_headers_to_remove}
    */
    readonly responseHeadersToRemove?: string[];
    /**
    * request_headers_to_add block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#request_headers_to_add ComputeRegionUrlMap#request_headers_to_add}
    */
    readonly requestHeadersToAdd?: ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionRequestHeadersToAdd[] | cdktn.IResolvable;
    /**
    * response_headers_to_add block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#response_headers_to_add ComputeRegionUrlMap#response_headers_to_add}
    */
    readonly responseHeadersToAdd?: ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionResponseHeadersToAdd[] | cdktn.IResolvable;
}
export declare function computeRegionUrlMapPathMatcherRouteRulesHeaderActionToTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesHeaderAction): any;
export declare function computeRegionUrlMapPathMatcherRouteRulesHeaderActionToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesHeaderAction): any;
export declare class ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherRouteRulesHeaderAction | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherRouteRulesHeaderAction | undefined);
    private _requestHeadersToRemove?;
    get requestHeadersToRemove(): string[];
    set requestHeadersToRemove(value: string[]);
    resetRequestHeadersToRemove(): void;
    get requestHeadersToRemoveInput(): string[] | undefined;
    private _responseHeadersToRemove?;
    get responseHeadersToRemove(): string[];
    set responseHeadersToRemove(value: string[]);
    resetResponseHeadersToRemove(): void;
    get responseHeadersToRemoveInput(): string[] | undefined;
    private _requestHeadersToAdd;
    get requestHeadersToAdd(): ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionRequestHeadersToAddList;
    putRequestHeadersToAdd(value: ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionRequestHeadersToAdd[] | cdktn.IResolvable): void;
    resetRequestHeadersToAdd(): void;
    get requestHeadersToAddInput(): cdktn.IResolvable | ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionRequestHeadersToAdd[] | undefined;
    private _responseHeadersToAdd;
    get responseHeadersToAdd(): ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionResponseHeadersToAddList;
    putResponseHeadersToAdd(value: ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionResponseHeadersToAdd[] | cdktn.IResolvable): void;
    resetResponseHeadersToAdd(): void;
    get responseHeadersToAddInput(): cdktn.IResolvable | ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionResponseHeadersToAdd[] | undefined;
}
export interface ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatchesRangeMatch {
    /**
    * The end of the range (exclusive).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#range_end ComputeRegionUrlMap#range_end}
    */
    readonly rangeEnd: number;
    /**
    * The start of the range (inclusive).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#range_start ComputeRegionUrlMap#range_start}
    */
    readonly rangeStart: number;
}
export declare function computeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatchesRangeMatchToTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatchesRangeMatchOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatchesRangeMatch): any;
export declare function computeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatchesRangeMatchToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatchesRangeMatchOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatchesRangeMatch): any;
export declare class ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatchesRangeMatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatchesRangeMatch | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatchesRangeMatch | undefined);
    private _rangeEnd?;
    get rangeEnd(): number;
    set rangeEnd(value: number);
    get rangeEndInput(): number | undefined;
    private _rangeStart?;
    get rangeStart(): number;
    set rangeStart(value: number);
    get rangeStartInput(): number | undefined;
}
export interface ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatches {
    /**
    * The value should exactly match contents of exactMatch. Only one of exactMatch,
    * prefixMatch, suffixMatch, regexMatch, presentMatch or rangeMatch must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#exact_match ComputeRegionUrlMap#exact_match}
    */
    readonly exactMatch?: string;
    /**
    * The name of the HTTP header to match. For matching against the HTTP request's
    * authority, use a headerMatch with the header name ":authority". For matching a
    * request's method, use the headerName ":method".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_name ComputeRegionUrlMap#header_name}
    */
    readonly headerName: string;
    /**
    * If set to false, the headerMatch is considered a match if the match criteria
    * above are met. If set to true, the headerMatch is considered a match if the
    * match criteria above are NOT met. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#invert_match ComputeRegionUrlMap#invert_match}
    */
    readonly invertMatch?: boolean | cdktn.IResolvable;
    /**
    * The value of the header must start with the contents of prefixMatch. Only one of
    * exactMatch, prefixMatch, suffixMatch, regexMatch, presentMatch or rangeMatch
    * must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#prefix_match ComputeRegionUrlMap#prefix_match}
    */
    readonly prefixMatch?: string;
    /**
    * A header with the contents of headerName must exist. The match takes place
    * whether or not the request's header has a value or not. Only one of exactMatch,
    * prefixMatch, suffixMatch, regexMatch, presentMatch or rangeMatch must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#present_match ComputeRegionUrlMap#present_match}
    */
    readonly presentMatch?: boolean | cdktn.IResolvable;
    /**
    * The value of the header must match the regular expression specified in
    * regexMatch. For regular expression grammar, please see:
    * en.cppreference.com/w/cpp/regex/ecmascript  For matching against a port
    * specified in the HTTP request, use a headerMatch with headerName set to PORT and
    * a regular expression that satisfies the RFC2616 Host header's port specifier.
    * Only one of exactMatch, prefixMatch, suffixMatch, regexMatch, presentMatch or
    * rangeMatch must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#regex_match ComputeRegionUrlMap#regex_match}
    */
    readonly regexMatch?: string;
    /**
    * The value of the header must end with the contents of suffixMatch. Only one of
    * exactMatch, prefixMatch, suffixMatch, regexMatch, presentMatch or rangeMatch
    * must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#suffix_match ComputeRegionUrlMap#suffix_match}
    */
    readonly suffixMatch?: string;
    /**
    * range_match block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#range_match ComputeRegionUrlMap#range_match}
    */
    readonly rangeMatch?: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatchesRangeMatch;
}
export declare function computeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatchesToTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatches | cdktn.IResolvable): any;
export declare function computeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatchesToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatches | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatchesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatches | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatches | cdktn.IResolvable | undefined);
    private _exactMatch?;
    get exactMatch(): string;
    set exactMatch(value: string);
    resetExactMatch(): void;
    get exactMatchInput(): string | undefined;
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    get headerNameInput(): string | undefined;
    private _invertMatch?;
    get invertMatch(): boolean | cdktn.IResolvable;
    set invertMatch(value: boolean | cdktn.IResolvable);
    resetInvertMatch(): void;
    get invertMatchInput(): boolean | cdktn.IResolvable | undefined;
    private _prefixMatch?;
    get prefixMatch(): string;
    set prefixMatch(value: string);
    resetPrefixMatch(): void;
    get prefixMatchInput(): string | undefined;
    private _presentMatch?;
    get presentMatch(): boolean | cdktn.IResolvable;
    set presentMatch(value: boolean | cdktn.IResolvable);
    resetPresentMatch(): void;
    get presentMatchInput(): boolean | cdktn.IResolvable | undefined;
    private _regexMatch?;
    get regexMatch(): string;
    set regexMatch(value: string);
    resetRegexMatch(): void;
    get regexMatchInput(): string | undefined;
    private _suffixMatch?;
    get suffixMatch(): string;
    set suffixMatch(value: string);
    resetSuffixMatch(): void;
    get suffixMatchInput(): string | undefined;
    private _rangeMatch;
    get rangeMatch(): ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatchesRangeMatchOutputReference;
    putRangeMatch(value: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatchesRangeMatch): void;
    resetRangeMatch(): void;
    get rangeMatchInput(): ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatchesRangeMatch | undefined;
}
export declare class ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatchesList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatches[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatchesOutputReference;
}
export interface ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFiltersFilterLabels {
    /**
    * Name of metadata label. The name can have a maximum length of 1024 characters
    * and must be at least 1 character long.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#name ComputeRegionUrlMap#name}
    */
    readonly name: string;
    /**
    * The value of the label must match the specified value. value can have a maximum
    * length of 1024 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#value ComputeRegionUrlMap#value}
    */
    readonly value: string;
}
export declare function computeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFiltersFilterLabelsToTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFiltersFilterLabels | cdktn.IResolvable): any;
export declare function computeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFiltersFilterLabelsToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFiltersFilterLabels | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFiltersFilterLabelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFiltersFilterLabels | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFiltersFilterLabels | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFiltersFilterLabelsList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFiltersFilterLabels[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFiltersFilterLabelsOutputReference;
}
export interface ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFilters {
    /**
    * Specifies how individual filterLabel matches within the list of filterLabels
    * contribute towards the overall metadataFilter match. Supported values are:
    *
    * * MATCH_ANY: At least one of the filterLabels must have a matching label in the
    * provided metadata.
    * * MATCH_ALL: All filterLabels must have matching labels in
    * the provided metadata. Possible values: ["MATCH_ALL", "MATCH_ANY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#filter_match_criteria ComputeRegionUrlMap#filter_match_criteria}
    */
    readonly filterMatchCriteria: string;
    /**
    * filter_labels block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#filter_labels ComputeRegionUrlMap#filter_labels}
    */
    readonly filterLabels: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFiltersFilterLabels[] | cdktn.IResolvable;
}
export declare function computeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFiltersToTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFilters | cdktn.IResolvable): any;
export declare function computeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFiltersToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFilters | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFilters | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFilters | cdktn.IResolvable | undefined);
    private _filterMatchCriteria?;
    get filterMatchCriteria(): string;
    set filterMatchCriteria(value: string);
    get filterMatchCriteriaInput(): string | undefined;
    private _filterLabels;
    get filterLabels(): ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFiltersFilterLabelsList;
    putFilterLabels(value: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFiltersFilterLabels[] | cdktn.IResolvable): void;
    get filterLabelsInput(): cdktn.IResolvable | ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFiltersFilterLabels[] | undefined;
}
export declare class ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFiltersList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFiltersOutputReference;
}
export interface ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesQueryParameterMatches {
    /**
    * The queryParameterMatch matches if the value of the parameter exactly matches
    * the contents of exactMatch. Only one of presentMatch, exactMatch and regexMatch
    * must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#exact_match ComputeRegionUrlMap#exact_match}
    */
    readonly exactMatch?: string;
    /**
    * The name of the query parameter to match. The query parameter must exist in the
    * request, in the absence of which the request match fails.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#name ComputeRegionUrlMap#name}
    */
    readonly name: string;
    /**
    * Specifies that the queryParameterMatch matches if the request contains the query
    * parameter, irrespective of whether the parameter has a value or not. Only one of
    * presentMatch, exactMatch and regexMatch must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#present_match ComputeRegionUrlMap#present_match}
    */
    readonly presentMatch?: boolean | cdktn.IResolvable;
    /**
    * The queryParameterMatch matches if the value of the parameter matches the
    * regular expression specified by regexMatch. For the regular expression grammar,
    * please see en.cppreference.com/w/cpp/regex/ecmascript  Only one of presentMatch,
    * exactMatch and regexMatch must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#regex_match ComputeRegionUrlMap#regex_match}
    */
    readonly regexMatch?: string;
}
export declare function computeRegionUrlMapPathMatcherRouteRulesMatchRulesQueryParameterMatchesToTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesQueryParameterMatches | cdktn.IResolvable): any;
export declare function computeRegionUrlMapPathMatcherRouteRulesMatchRulesQueryParameterMatchesToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesQueryParameterMatches | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesQueryParameterMatchesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesQueryParameterMatches | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesQueryParameterMatches | cdktn.IResolvable | undefined);
    private _exactMatch?;
    get exactMatch(): string;
    set exactMatch(value: string);
    resetExactMatch(): void;
    get exactMatchInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _presentMatch?;
    get presentMatch(): boolean | cdktn.IResolvable;
    set presentMatch(value: boolean | cdktn.IResolvable);
    resetPresentMatch(): void;
    get presentMatchInput(): boolean | cdktn.IResolvable | undefined;
    private _regexMatch?;
    get regexMatch(): string;
    set regexMatch(value: string);
    resetRegexMatch(): void;
    get regexMatchInput(): string | undefined;
}
export declare class ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesQueryParameterMatchesList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesQueryParameterMatches[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesQueryParameterMatchesOutputReference;
}
export interface ComputeRegionUrlMapPathMatcherRouteRulesMatchRules {
    /**
    * For satisfying the matchRule condition, the path of the request must exactly
    * match the value specified in fullPathMatch after removing any query parameters
    * and anchor that may be part of the original URL. FullPathMatch must be between 1
    * and 1024 characters. Only one of prefixMatch, fullPathMatch or regexMatch must
    * be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#full_path_match ComputeRegionUrlMap#full_path_match}
    */
    readonly fullPathMatch?: string;
    /**
    * Specifies that prefixMatch and fullPathMatch matches are case sensitive.
    * Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#ignore_case ComputeRegionUrlMap#ignore_case}
    */
    readonly ignoreCase?: boolean | cdktn.IResolvable;
    /**
    * For satisfying the matchRule condition, the path of the request
    * must match the wildcard pattern specified in pathTemplateMatch
    * after removing any query parameters and anchor that may be part
    * of the original URL.
    *
    * pathTemplateMatch must be between 1 and 255 characters
    * (inclusive).  The pattern specified by pathTemplateMatch may
    * have at most 5 wildcard operators and at most 5 variable
    * captures in total.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#path_template_match ComputeRegionUrlMap#path_template_match}
    */
    readonly pathTemplateMatch?: string;
    /**
    * For satisfying the matchRule condition, the request's path must begin with the
    * specified prefixMatch. prefixMatch must begin with a /. The value must be
    * between 1 and 1024 characters. Only one of prefixMatch, fullPathMatch or
    * regexMatch must be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#prefix_match ComputeRegionUrlMap#prefix_match}
    */
    readonly prefixMatch?: string;
    /**
    * For satisfying the matchRule condition, the path of the request must satisfy the
    * regular expression specified in regexMatch after removing any query parameters
    * and anchor supplied with the original URL. For regular expression grammar please
    * see en.cppreference.com/w/cpp/regex/ecmascript  Only one of prefixMatch,
    * fullPathMatch or regexMatch must be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#regex_match ComputeRegionUrlMap#regex_match}
    */
    readonly regexMatch?: string;
    /**
    * header_matches block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_matches ComputeRegionUrlMap#header_matches}
    */
    readonly headerMatches?: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatches[] | cdktn.IResolvable;
    /**
    * metadata_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#metadata_filters ComputeRegionUrlMap#metadata_filters}
    */
    readonly metadataFilters?: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFilters[] | cdktn.IResolvable;
    /**
    * query_parameter_matches block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#query_parameter_matches ComputeRegionUrlMap#query_parameter_matches}
    */
    readonly queryParameterMatches?: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesQueryParameterMatches[] | cdktn.IResolvable;
}
export declare function computeRegionUrlMapPathMatcherRouteRulesMatchRulesToTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesMatchRules | cdktn.IResolvable): any;
export declare function computeRegionUrlMapPathMatcherRouteRulesMatchRulesToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesMatchRules | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapPathMatcherRouteRulesMatchRules | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherRouteRulesMatchRules | cdktn.IResolvable | undefined);
    private _fullPathMatch?;
    get fullPathMatch(): string;
    set fullPathMatch(value: string);
    resetFullPathMatch(): void;
    get fullPathMatchInput(): string | undefined;
    private _ignoreCase?;
    get ignoreCase(): boolean | cdktn.IResolvable;
    set ignoreCase(value: boolean | cdktn.IResolvable);
    resetIgnoreCase(): void;
    get ignoreCaseInput(): boolean | cdktn.IResolvable | undefined;
    private _pathTemplateMatch?;
    get pathTemplateMatch(): string;
    set pathTemplateMatch(value: string);
    resetPathTemplateMatch(): void;
    get pathTemplateMatchInput(): string | undefined;
    private _prefixMatch?;
    get prefixMatch(): string;
    set prefixMatch(value: string);
    resetPrefixMatch(): void;
    get prefixMatchInput(): string | undefined;
    private _regexMatch?;
    get regexMatch(): string;
    set regexMatch(value: string);
    resetRegexMatch(): void;
    get regexMatchInput(): string | undefined;
    private _headerMatches;
    get headerMatches(): ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatchesList;
    putHeaderMatches(value: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatches[] | cdktn.IResolvable): void;
    resetHeaderMatches(): void;
    get headerMatchesInput(): cdktn.IResolvable | ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesHeaderMatches[] | undefined;
    private _metadataFilters;
    get metadataFilters(): ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFiltersList;
    putMetadataFilters(value: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFilters[] | cdktn.IResolvable): void;
    resetMetadataFilters(): void;
    get metadataFiltersInput(): cdktn.IResolvable | ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesMetadataFilters[] | undefined;
    private _queryParameterMatches;
    get queryParameterMatches(): ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesQueryParameterMatchesList;
    putQueryParameterMatches(value: ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesQueryParameterMatches[] | cdktn.IResolvable): void;
    resetQueryParameterMatches(): void;
    get queryParameterMatchesInput(): cdktn.IResolvable | ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesQueryParameterMatches[] | undefined;
}
export declare class ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapPathMatcherRouteRulesMatchRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesOutputReference;
}
export interface ComputeRegionUrlMapPathMatcherRouteRulesRouteActionCorsPolicy {
    /**
    * In response to a preflight request, setting this to true indicates that the
    * actual request can include user credentials. This translates to the Access-
    * Control-Allow-Credentials header. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#allow_credentials ComputeRegionUrlMap#allow_credentials}
    */
    readonly allowCredentials?: boolean | cdktn.IResolvable;
    /**
    * Specifies the content for the Access-Control-Allow-Headers header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#allow_headers ComputeRegionUrlMap#allow_headers}
    */
    readonly allowHeaders?: string[];
    /**
    * Specifies the content for the Access-Control-Allow-Methods header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#allow_methods ComputeRegionUrlMap#allow_methods}
    */
    readonly allowMethods?: string[];
    /**
    * Specifies the regular expression patterns that match allowed origins. For
    * regular expression grammar please see en.cppreference.com/w/cpp/regex/ecmascript
    * An origin is allowed if it matches either allow_origins or allow_origin_regex.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#allow_origin_regexes ComputeRegionUrlMap#allow_origin_regexes}
    */
    readonly allowOriginRegexes?: string[];
    /**
    * Specifies the list of origins that will be allowed to do CORS requests. An
    * origin is allowed if it matches either allow_origins or allow_origin_regex.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#allow_origins ComputeRegionUrlMap#allow_origins}
    */
    readonly allowOrigins?: string[];
    /**
    * If true, specifies the CORS policy is disabled.
    * which indicates that the CORS policy is in effect. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#disabled ComputeRegionUrlMap#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Specifies the content for the Access-Control-Expose-Headers header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#expose_headers ComputeRegionUrlMap#expose_headers}
    */
    readonly exposeHeaders?: string[];
    /**
    * Specifies how long the results of a preflight request can be cached. This
    * translates to the content for the Access-Control-Max-Age header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#max_age ComputeRegionUrlMap#max_age}
    */
    readonly maxAge?: number;
}
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionCorsPolicyToTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionCorsPolicyOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesRouteActionCorsPolicy): any;
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionCorsPolicyToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionCorsPolicyOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesRouteActionCorsPolicy): any;
export declare class ComputeRegionUrlMapPathMatcherRouteRulesRouteActionCorsPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionCorsPolicy | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionCorsPolicy | undefined);
    private _allowCredentials?;
    get allowCredentials(): boolean | cdktn.IResolvable;
    set allowCredentials(value: boolean | cdktn.IResolvable);
    resetAllowCredentials(): void;
    get allowCredentialsInput(): boolean | cdktn.IResolvable | undefined;
    private _allowHeaders?;
    get allowHeaders(): string[];
    set allowHeaders(value: string[]);
    resetAllowHeaders(): void;
    get allowHeadersInput(): string[] | undefined;
    private _allowMethods?;
    get allowMethods(): string[];
    set allowMethods(value: string[]);
    resetAllowMethods(): void;
    get allowMethodsInput(): string[] | undefined;
    private _allowOriginRegexes?;
    get allowOriginRegexes(): string[];
    set allowOriginRegexes(value: string[]);
    resetAllowOriginRegexes(): void;
    get allowOriginRegexesInput(): string[] | undefined;
    private _allowOrigins?;
    get allowOrigins(): string[];
    set allowOrigins(value: string[]);
    resetAllowOrigins(): void;
    get allowOriginsInput(): string[] | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _exposeHeaders?;
    get exposeHeaders(): string[];
    set exposeHeaders(value: string[]);
    resetExposeHeaders(): void;
    get exposeHeadersInput(): string[] | undefined;
    private _maxAge?;
    get maxAge(): number;
    set maxAge(value: number);
    resetMaxAge(): void;
    get maxAgeInput(): number | undefined;
}
export interface ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyAbort {
    /**
    * The HTTP status code used to abort the request. The value must be between 200
    * and 599 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#http_status ComputeRegionUrlMap#http_status}
    */
    readonly httpStatus?: number;
    /**
    * The percentage of traffic (connections/operations/requests) which will be
    * aborted as part of fault injection. The value must be between 0.0 and 100.0
    * inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#percentage ComputeRegionUrlMap#percentage}
    */
    readonly percentage?: number;
}
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyAbortToTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyAbortOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyAbort): any;
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyAbortToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyAbortOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyAbort): any;
export declare class ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyAbortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyAbort | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyAbort | undefined);
    private _httpStatus?;
    get httpStatus(): number;
    set httpStatus(value: number);
    resetHttpStatus(): void;
    get httpStatusInput(): number | undefined;
    private _percentage?;
    get percentage(): number;
    set percentage(value: number);
    resetPercentage(): void;
    get percentageInput(): number | undefined;
}
export interface ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelayFixedDelay {
    /**
    * Span of time that's a fraction of a second at nanosecond resolution. Durations
    * less than one second are represented with a 0 'seconds' field and a positive
    * 'nanos' field. Must be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#nanos ComputeRegionUrlMap#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second. Must be from 0 to 315,576,000,000
    * inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#seconds ComputeRegionUrlMap#seconds}
    */
    readonly seconds: string;
}
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelayFixedDelayToTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelayFixedDelayOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelayFixedDelay): any;
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelayFixedDelayToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelayFixedDelayOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelayFixedDelay): any;
export declare class ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelayFixedDelayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelayFixedDelay | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelayFixedDelay | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): string;
    set seconds(value: string);
    get secondsInput(): string | undefined;
}
export interface ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelay {
    /**
    * The percentage of traffic (connections/operations/requests) on which delay will
    * be introduced as part of fault injection. The value must be between 0.0 and
    * 100.0 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#percentage ComputeRegionUrlMap#percentage}
    */
    readonly percentage?: number;
    /**
    * fixed_delay block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#fixed_delay ComputeRegionUrlMap#fixed_delay}
    */
    readonly fixedDelay?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelayFixedDelay;
}
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelayToTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelayOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelay): any;
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelayToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelayOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelay): any;
export declare class ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelay | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelay | undefined);
    private _percentage?;
    get percentage(): number;
    set percentage(value: number);
    resetPercentage(): void;
    get percentageInput(): number | undefined;
    private _fixedDelay;
    get fixedDelay(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelayFixedDelayOutputReference;
    putFixedDelay(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelayFixedDelay): void;
    resetFixedDelay(): void;
    get fixedDelayInput(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelayFixedDelay | undefined;
}
export interface ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicy {
    /**
    * abort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#abort ComputeRegionUrlMap#abort}
    */
    readonly abort?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyAbort;
    /**
    * delay block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#delay ComputeRegionUrlMap#delay}
    */
    readonly delay?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelay;
}
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyToTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicy): any;
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicy): any;
export declare class ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicy | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicy | undefined);
    private _abort;
    get abort(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyAbortOutputReference;
    putAbort(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyAbort): void;
    resetAbort(): void;
    get abortInput(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyAbort | undefined;
    private _delay;
    get delay(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelayOutputReference;
    putDelay(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelay): void;
    resetDelay(): void;
    get delayInput(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyDelay | undefined;
}
export interface ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRequestMirrorPolicy {
    /**
    * The RegionBackendService resource being mirrored to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#backend_service ComputeRegionUrlMap#backend_service}
    */
    readonly backendService: string;
    /**
    * The percentage of requests to be mirrored to backendService.
    * The value must be between 0.0 and 100.0 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#mirror_percent ComputeRegionUrlMap#mirror_percent}
    */
    readonly mirrorPercent?: number;
}
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionRequestMirrorPolicyToTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRequestMirrorPolicyOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRequestMirrorPolicy): any;
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionRequestMirrorPolicyToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRequestMirrorPolicyOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRequestMirrorPolicy): any;
export declare class ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRequestMirrorPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRequestMirrorPolicy | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRequestMirrorPolicy | undefined);
    private _backendService?;
    get backendService(): string;
    set backendService(value: string);
    get backendServiceInput(): string | undefined;
    private _mirrorPercent?;
    get mirrorPercent(): number;
    set mirrorPercent(value: number);
    resetMirrorPercent(): void;
    get mirrorPercentInput(): number | undefined;
}
export interface ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicyPerTryTimeout {
    /**
    * Span of time that's a fraction of a second at nanosecond resolution. Durations
    * less than one second are represented with a 0 'seconds' field and a positive
    * 'nanos' field. Must be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#nanos ComputeRegionUrlMap#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second. Must be from 0 to 315,576,000,000
    * inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#seconds ComputeRegionUrlMap#seconds}
    */
    readonly seconds: string;
}
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicyPerTryTimeoutToTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicyPerTryTimeoutOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicyPerTryTimeout): any;
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicyPerTryTimeoutToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicyPerTryTimeoutOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicyPerTryTimeout): any;
export declare class ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicyPerTryTimeoutOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicyPerTryTimeout | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicyPerTryTimeout | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): string;
    set seconds(value: string);
    get secondsInput(): string | undefined;
}
export interface ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicy {
    /**
    * Specifies the allowed number retries. This number must be > 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#num_retries ComputeRegionUrlMap#num_retries}
    */
    readonly numRetries: number;
    /**
    * Specifies one or more conditions when this retry rule applies. Valid values are:
    *
    * * 5xx: Loadbalancer will attempt a retry if the backend service responds with
    *   any 5xx response code, or if the backend service does not respond at all,
    *   for example: disconnects, reset, read timeout, connection failure, and refused
    *   streams.
    * * gateway-error: Similar to 5xx, but only applies to response codes
    *   502, 503 or 504.
    * * connect-failure: Loadbalancer will retry on failures
    *   connecting to backend services, for example due to connection timeouts.
    * * retriable-4xx: Loadbalancer will retry for retriable 4xx response codes.
    *   Currently the only retriable error supported is 409.
    * * refused-stream: Loadbalancer will retry if the backend service resets the stream with a
    *   REFUSED_STREAM error code. This reset type indicates that it is safe to retry.
    * * cancelled: Loadbalancer will retry if the gRPC status code in the response
    *   header is set to cancelled
    * * deadline-exceeded: Loadbalancer will retry if the
    *   gRPC status code in the response header is set to deadline-exceeded
    * * resource-exhausted: Loadbalancer will retry if the gRPC status code in the response
    *   header is set to resource-exhausted
    * * unavailable: Loadbalancer will retry if the gRPC status code in
    *   the response header is set to unavailable
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#retry_conditions ComputeRegionUrlMap#retry_conditions}
    */
    readonly retryConditions?: string[];
    /**
    * per_try_timeout block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#per_try_timeout ComputeRegionUrlMap#per_try_timeout}
    */
    readonly perTryTimeout?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicyPerTryTimeout;
}
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicyToTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicyOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicy): any;
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicyToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicyOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicy): any;
export declare class ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicy | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicy | undefined);
    private _numRetries?;
    get numRetries(): number;
    set numRetries(value: number);
    get numRetriesInput(): number | undefined;
    private _retryConditions?;
    get retryConditions(): string[];
    set retryConditions(value: string[]);
    resetRetryConditions(): void;
    get retryConditionsInput(): string[] | undefined;
    private _perTryTimeout;
    get perTryTimeout(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicyPerTryTimeoutOutputReference;
    putPerTryTimeout(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicyPerTryTimeout): void;
    resetPerTryTimeout(): void;
    get perTryTimeoutInput(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicyPerTryTimeout | undefined;
}
export interface ComputeRegionUrlMapPathMatcherRouteRulesRouteActionTimeout {
    /**
    * Span of time that's a fraction of a second at nanosecond resolution. Durations
    * less than one second are represented with a 0 'seconds' field and a positive
    * 'nanos' field. Must be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#nanos ComputeRegionUrlMap#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second. Must be from 0 to 315,576,000,000
    * inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#seconds ComputeRegionUrlMap#seconds}
    */
    readonly seconds: string;
}
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionTimeoutToTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionTimeoutOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesRouteActionTimeout): any;
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionTimeoutToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionTimeoutOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesRouteActionTimeout): any;
export declare class ComputeRegionUrlMapPathMatcherRouteRulesRouteActionTimeoutOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionTimeout | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionTimeout | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): string;
    set seconds(value: string);
    get secondsInput(): string | undefined;
}
export interface ComputeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewriteRegexRewrite {
    /**
    * The regular expression used to match against the URL path.
    * It uses RE2 syntax with the following constraints:
    *
    * * Any single character operators are allowed.
    * * Groups may only contain a submatch operator, and may not
    *   contain character repetition (for example, '.*').
    * * Character repetition (for example, '.*') may only be used in
    *   a regex together with empty string operators, other
    *   repetitions, ranges, and repetitions of ranges.
    * * Ranges may only contain character ranges, digit ranges, and
    *   symbols allowed for ranges.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#path_pattern ComputeRegionUrlMap#path_pattern}
    */
    readonly pathPattern: string;
    /**
    * The substitution used to rewrite the parts of the URL path
    * matched by pathPattern. May reference capture groups from
    * pathPattern.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#path_substitution ComputeRegionUrlMap#path_substitution}
    */
    readonly pathSubstitution: string;
}
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewriteRegexRewriteToTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewriteRegexRewriteOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewriteRegexRewrite): any;
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewriteRegexRewriteToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewriteRegexRewriteOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewriteRegexRewrite): any;
export declare class ComputeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewriteRegexRewriteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewriteRegexRewrite | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewriteRegexRewrite | undefined);
    private _pathPattern?;
    get pathPattern(): string;
    set pathPattern(value: string);
    get pathPatternInput(): string | undefined;
    private _pathSubstitution?;
    get pathSubstitution(): string;
    set pathSubstitution(value: string);
    get pathSubstitutionInput(): string | undefined;
}
export interface ComputeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewrite {
    /**
    * Prior to forwarding the request to the selected service, the request's host
    * header is replaced with contents of hostRewrite. The value must be between 1 and
    * 255 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#host_rewrite ComputeRegionUrlMap#host_rewrite}
    */
    readonly hostRewrite?: string;
    /**
    * Prior to forwarding the request to the selected backend service, the matching
    * portion of the request's path is replaced by pathPrefixRewrite. The value must
    * be between 1 and 1024 characters.
    *
    * Only one of pathPrefixRewrite, pathTemplateRewrite, or regexRewrite may be
    * specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#path_prefix_rewrite ComputeRegionUrlMap#path_prefix_rewrite}
    */
    readonly pathPrefixRewrite?: string;
    /**
    * Prior to forwarding the request to the selected origin, if the
    * request matched a pathTemplateMatch, the matching portion of the
    * request's path is replaced re-written using the pattern specified
    * by pathTemplateRewrite.
    *
    * pathTemplateRewrite must be between 1 and 255 characters
    * (inclusive), must start with a '/', and must only use variables
    * captured by the route's pathTemplate matchers.
    *
    * pathTemplateRewrite may only be used when all of a route's
    * MatchRules specify pathTemplate.
    *
    * Only one of pathPrefixRewrite, pathTemplateRewrite, or regexRewrite may be
    * specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#path_template_rewrite ComputeRegionUrlMap#path_template_rewrite}
    */
    readonly pathTemplateRewrite?: string;
    /**
    * regex_rewrite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#regex_rewrite ComputeRegionUrlMap#regex_rewrite}
    */
    readonly regexRewrite?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewriteRegexRewrite;
}
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewriteToTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewriteOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewrite): any;
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewriteToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewriteOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewrite): any;
export declare class ComputeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewriteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewrite | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewrite | undefined);
    private _hostRewrite?;
    get hostRewrite(): string;
    set hostRewrite(value: string);
    resetHostRewrite(): void;
    get hostRewriteInput(): string | undefined;
    private _pathPrefixRewrite?;
    get pathPrefixRewrite(): string;
    set pathPrefixRewrite(value: string);
    resetPathPrefixRewrite(): void;
    get pathPrefixRewriteInput(): string | undefined;
    private _pathTemplateRewrite?;
    get pathTemplateRewrite(): string;
    set pathTemplateRewrite(value: string);
    resetPathTemplateRewrite(): void;
    get pathTemplateRewriteInput(): string | undefined;
    private _regexRewrite;
    get regexRewrite(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewriteRegexRewriteOutputReference;
    putRegexRewrite(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewriteRegexRewrite): void;
    resetRegexRewrite(): void;
    get regexRewriteInput(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewriteRegexRewrite | undefined;
}
export interface ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd {
    /**
    * The name of the header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_name ComputeRegionUrlMap#header_name}
    */
    readonly headerName: string;
    /**
    * The value of the header to add.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_value ComputeRegionUrlMap#header_value}
    */
    readonly headerValue: string;
    /**
    * If false, headerValue is appended to any values that already exist for the
    * header. If true, headerValue is set for the header, discarding any values that
    * were set for that header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#replace ComputeRegionUrlMap#replace}
    */
    readonly replace: boolean | cdktn.IResolvable;
}
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAddToTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd | cdktn.IResolvable): any;
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAddToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAddOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    get headerNameInput(): string | undefined;
    private _headerValue?;
    get headerValue(): string;
    set headerValue(value: string);
    get headerValueInput(): string | undefined;
    private _replace?;
    get replace(): boolean | cdktn.IResolvable;
    set replace(value: boolean | cdktn.IResolvable);
    get replaceInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAddList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAddOutputReference;
}
export interface ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd {
    /**
    * The name of the header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_name ComputeRegionUrlMap#header_name}
    */
    readonly headerName: string;
    /**
    * The value of the header to add.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_value ComputeRegionUrlMap#header_value}
    */
    readonly headerValue: string;
    /**
    * If false, headerValue is appended to any values that already exist for the
    * header. If true, headerValue is set for the header, discarding any values that
    * were set for that header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#replace ComputeRegionUrlMap#replace}
    */
    readonly replace: boolean | cdktn.IResolvable;
}
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAddToTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd | cdktn.IResolvable): any;
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAddToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAddOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    get headerNameInput(): string | undefined;
    private _headerValue?;
    get headerValue(): string;
    set headerValue(value: string);
    get headerValueInput(): string | undefined;
    private _replace?;
    get replace(): boolean | cdktn.IResolvable;
    set replace(value: boolean | cdktn.IResolvable);
    get replaceInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAddList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAddOutputReference;
}
export interface ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderAction {
    /**
    * A list of header names for headers that need to be removed from the request
    * prior to forwarding the request to the backendService.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#request_headers_to_remove ComputeRegionUrlMap#request_headers_to_remove}
    */
    readonly requestHeadersToRemove?: string[];
    /**
    * A list of header names for headers that need to be removed from the response
    * prior to sending the response back to the client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#response_headers_to_remove ComputeRegionUrlMap#response_headers_to_remove}
    */
    readonly responseHeadersToRemove?: string[];
    /**
    * request_headers_to_add block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#request_headers_to_add ComputeRegionUrlMap#request_headers_to_add}
    */
    readonly requestHeadersToAdd?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd[] | cdktn.IResolvable;
    /**
    * response_headers_to_add block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#response_headers_to_add ComputeRegionUrlMap#response_headers_to_add}
    */
    readonly responseHeadersToAdd?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd[] | cdktn.IResolvable;
}
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionToTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderAction): any;
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderAction): any;
export declare class ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderAction | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderAction | undefined);
    private _requestHeadersToRemove?;
    get requestHeadersToRemove(): string[];
    set requestHeadersToRemove(value: string[]);
    resetRequestHeadersToRemove(): void;
    get requestHeadersToRemoveInput(): string[] | undefined;
    private _responseHeadersToRemove?;
    get responseHeadersToRemove(): string[];
    set responseHeadersToRemove(value: string[]);
    resetResponseHeadersToRemove(): void;
    get responseHeadersToRemoveInput(): string[] | undefined;
    private _requestHeadersToAdd;
    get requestHeadersToAdd(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAddList;
    putRequestHeadersToAdd(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd[] | cdktn.IResolvable): void;
    resetRequestHeadersToAdd(): void;
    get requestHeadersToAddInput(): cdktn.IResolvable | ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionRequestHeadersToAdd[] | undefined;
    private _responseHeadersToAdd;
    get responseHeadersToAdd(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAddList;
    putResponseHeadersToAdd(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd[] | cdktn.IResolvable): void;
    resetResponseHeadersToAdd(): void;
    get responseHeadersToAddInput(): cdktn.IResolvable | ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionResponseHeadersToAdd[] | undefined;
}
export interface ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServices {
    /**
    * The default RegionBackendService resource. Before
    * forwarding the request to backendService, the loadbalancer applies any relevant
    * headerActions specified as part of this backendServiceWeight.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#backend_service ComputeRegionUrlMap#backend_service}
    */
    readonly backendService: string;
    /**
    * Specifies the fraction of traffic sent to backendService, computed as weight /
    * (sum of all weightedBackendService weights in routeAction) . The selection of a
    * backend service is determined only for new traffic. Once a user's request has
    * been directed to a backendService, subsequent requests will be sent to the same
    * backendService as determined by the BackendService's session affinity policy.
    * The value must be between 0 and 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#weight ComputeRegionUrlMap#weight}
    */
    readonly weight: number;
    /**
    * header_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_action ComputeRegionUrlMap#header_action}
    */
    readonly headerAction?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderAction;
}
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesToTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServices | cdktn.IResolvable): any;
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServices | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServices | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServices | cdktn.IResolvable | undefined);
    private _backendService?;
    get backendService(): string;
    set backendService(value: string);
    get backendServiceInput(): string | undefined;
    private _weight?;
    get weight(): number;
    set weight(value: number);
    get weightInput(): number | undefined;
    private _headerAction;
    get headerAction(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderActionOutputReference;
    putHeaderAction(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderAction): void;
    resetHeaderAction(): void;
    get headerActionInput(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesHeaderAction | undefined;
}
export declare class ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServices[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesOutputReference;
}
export interface ComputeRegionUrlMapPathMatcherRouteRulesRouteAction {
    /**
    * cors_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#cors_policy ComputeRegionUrlMap#cors_policy}
    */
    readonly corsPolicy?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionCorsPolicy;
    /**
    * fault_injection_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#fault_injection_policy ComputeRegionUrlMap#fault_injection_policy}
    */
    readonly faultInjectionPolicy?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicy;
    /**
    * request_mirror_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#request_mirror_policy ComputeRegionUrlMap#request_mirror_policy}
    */
    readonly requestMirrorPolicy?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRequestMirrorPolicy;
    /**
    * retry_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#retry_policy ComputeRegionUrlMap#retry_policy}
    */
    readonly retryPolicy?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicy;
    /**
    * timeout block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#timeout ComputeRegionUrlMap#timeout}
    */
    readonly timeout?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionTimeout;
    /**
    * url_rewrite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#url_rewrite ComputeRegionUrlMap#url_rewrite}
    */
    readonly urlRewrite?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewrite;
    /**
    * weighted_backend_services block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#weighted_backend_services ComputeRegionUrlMap#weighted_backend_services}
    */
    readonly weightedBackendServices?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServices[] | cdktn.IResolvable;
}
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionToTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesRouteAction): any;
export declare function computeRegionUrlMapPathMatcherRouteRulesRouteActionToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesRouteAction): any;
export declare class ComputeRegionUrlMapPathMatcherRouteRulesRouteActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherRouteRulesRouteAction | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteAction | undefined);
    private _corsPolicy;
    get corsPolicy(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionCorsPolicyOutputReference;
    putCorsPolicy(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionCorsPolicy): void;
    resetCorsPolicy(): void;
    get corsPolicyInput(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionCorsPolicy | undefined;
    private _faultInjectionPolicy;
    get faultInjectionPolicy(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicyOutputReference;
    putFaultInjectionPolicy(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicy): void;
    resetFaultInjectionPolicy(): void;
    get faultInjectionPolicyInput(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionFaultInjectionPolicy | undefined;
    private _requestMirrorPolicy;
    get requestMirrorPolicy(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRequestMirrorPolicyOutputReference;
    putRequestMirrorPolicy(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRequestMirrorPolicy): void;
    resetRequestMirrorPolicy(): void;
    get requestMirrorPolicyInput(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRequestMirrorPolicy | undefined;
    private _retryPolicy;
    get retryPolicy(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicyOutputReference;
    putRetryPolicy(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicy): void;
    resetRetryPolicy(): void;
    get retryPolicyInput(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionRetryPolicy | undefined;
    private _timeout;
    get timeout(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionTimeoutOutputReference;
    putTimeout(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionTimeout): void;
    resetTimeout(): void;
    get timeoutInput(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionTimeout | undefined;
    private _urlRewrite;
    get urlRewrite(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewriteOutputReference;
    putUrlRewrite(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewrite): void;
    resetUrlRewrite(): void;
    get urlRewriteInput(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionUrlRewrite | undefined;
    private _weightedBackendServices;
    get weightedBackendServices(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServicesList;
    putWeightedBackendServices(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServices[] | cdktn.IResolvable): void;
    resetWeightedBackendServices(): void;
    get weightedBackendServicesInput(): cdktn.IResolvable | ComputeRegionUrlMapPathMatcherRouteRulesRouteActionWeightedBackendServices[] | undefined;
}
export interface ComputeRegionUrlMapPathMatcherRouteRulesUrlRedirect {
    /**
    * The host that will be used in the redirect response instead of the one
    * that was supplied in the request. The value must be between 1 and 255
    * characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#host_redirect ComputeRegionUrlMap#host_redirect}
    */
    readonly hostRedirect?: string;
    /**
    * If set to true, the URL scheme in the redirected request is set to https.
    * If set to false, the URL scheme of the redirected request will remain the
    * same as that of the request. This must only be set for UrlMaps used in
    * TargetHttpProxys. Setting this true for TargetHttpsProxy is not
    * permitted. The default is set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#https_redirect ComputeRegionUrlMap#https_redirect}
    */
    readonly httpsRedirect?: boolean | cdktn.IResolvable;
    /**
    * The path that will be used in the redirect response instead of the one
    * that was supplied in the request. pathRedirect cannot be supplied
    * together with prefixRedirect. Supply one alone or neither. If neither is
    * supplied, the path of the original request will be used for the redirect.
    * The value must be between 1 and 1024 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#path_redirect ComputeRegionUrlMap#path_redirect}
    */
    readonly pathRedirect?: string;
    /**
    * The prefix that replaces the prefixMatch specified in the
    * HttpRouteRuleMatch, retaining the remaining portion of the URL before
    * redirecting the request. prefixRedirect cannot be supplied together with
    * pathRedirect. Supply one alone or neither. If neither is supplied, the
    * path of the original request will be used for the redirect. The value
    * must be between 1 and 1024 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#prefix_redirect ComputeRegionUrlMap#prefix_redirect}
    */
    readonly prefixRedirect?: string;
    /**
    * The HTTP Status code to use for this RedirectAction. Supported values are:
    *
    * * MOVED_PERMANENTLY_DEFAULT, which is the default value and corresponds to 301.
    *
    * * FOUND, which corresponds to 302.
    *
    * * SEE_OTHER which corresponds to 303.
    *
    * * TEMPORARY_REDIRECT, which corresponds to 307. In this case, the request method
    * will be retained.
    *
    * * PERMANENT_REDIRECT, which corresponds to 308. In this case,
    * the request method will be retained. Possible values: ["FOUND", "MOVED_PERMANENTLY_DEFAULT", "PERMANENT_REDIRECT", "SEE_OTHER", "TEMPORARY_REDIRECT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#redirect_response_code ComputeRegionUrlMap#redirect_response_code}
    */
    readonly redirectResponseCode?: string;
    /**
    * If set to true, any accompanying query portion of the original URL is
    * removed prior to redirecting the request. If set to false, the query
    * portion of the original URL is retained. The default value is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#strip_query ComputeRegionUrlMap#strip_query}
    */
    readonly stripQuery?: boolean | cdktn.IResolvable;
}
export declare function computeRegionUrlMapPathMatcherRouteRulesUrlRedirectToTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesUrlRedirectOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesUrlRedirect): any;
export declare function computeRegionUrlMapPathMatcherRouteRulesUrlRedirectToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRulesUrlRedirectOutputReference | ComputeRegionUrlMapPathMatcherRouteRulesUrlRedirect): any;
export declare class ComputeRegionUrlMapPathMatcherRouteRulesUrlRedirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapPathMatcherRouteRulesUrlRedirect | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherRouteRulesUrlRedirect | undefined);
    private _hostRedirect?;
    get hostRedirect(): string;
    set hostRedirect(value: string);
    resetHostRedirect(): void;
    get hostRedirectInput(): string | undefined;
    private _httpsRedirect?;
    get httpsRedirect(): boolean | cdktn.IResolvable;
    set httpsRedirect(value: boolean | cdktn.IResolvable);
    resetHttpsRedirect(): void;
    get httpsRedirectInput(): boolean | cdktn.IResolvable | undefined;
    private _pathRedirect?;
    get pathRedirect(): string;
    set pathRedirect(value: string);
    resetPathRedirect(): void;
    get pathRedirectInput(): string | undefined;
    private _prefixRedirect?;
    get prefixRedirect(): string;
    set prefixRedirect(value: string);
    resetPrefixRedirect(): void;
    get prefixRedirectInput(): string | undefined;
    private _redirectResponseCode?;
    get redirectResponseCode(): string;
    set redirectResponseCode(value: string);
    resetRedirectResponseCode(): void;
    get redirectResponseCodeInput(): string | undefined;
    private _stripQuery?;
    get stripQuery(): boolean | cdktn.IResolvable;
    set stripQuery(value: boolean | cdktn.IResolvable);
    resetStripQuery(): void;
    get stripQueryInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ComputeRegionUrlMapPathMatcherRouteRules {
    /**
    * For routeRules within a given pathMatcher, priority determines the order
    * in which load balancer will interpret routeRules. RouteRules are evaluated
    * in order of priority, from the lowest to highest number. The priority of
    * a rule decreases as its number increases (1, 2, 3, N+1). The first rule
    * that matches the request is applied.
    *
    * You cannot configure two or more routeRules with the same priority.
    * Priority for each rule must be set to a number between 0 and
    * 2147483647 inclusive.
    *
    * Priority numbers can have gaps, which enable you to add or remove rules
    * in the future without affecting the rest of the rules. For example,
    * 1, 2, 3, 4, 5, 9, 12, 16 is a valid series of priority numbers to which
    * you could add rules numbered from 6 to 8, 10 to 11, and 13 to 15 in the
    * future without any impact on existing rules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#priority ComputeRegionUrlMap#priority}
    */
    readonly priority: number;
    /**
    * The region backend service resource to which traffic is
    * directed if this rule is matched. If routeAction is additionally specified,
    * advanced routing actions like URL Rewrites, etc. take effect prior to sending
    * the request to the backend. However, if service is specified, routeAction cannot
    * contain any weightedBackendService s. Conversely, if routeAction specifies any
    * weightedBackendServices, service must not be specified. Only one of urlRedirect,
    * service or routeAction.weightedBackendService must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#service ComputeRegionUrlMap#service}
    */
    readonly service?: string;
    /**
    * header_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_action ComputeRegionUrlMap#header_action}
    */
    readonly headerAction?: ComputeRegionUrlMapPathMatcherRouteRulesHeaderAction;
    /**
    * match_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#match_rules ComputeRegionUrlMap#match_rules}
    */
    readonly matchRules?: ComputeRegionUrlMapPathMatcherRouteRulesMatchRules[] | cdktn.IResolvable;
    /**
    * route_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#route_action ComputeRegionUrlMap#route_action}
    */
    readonly routeAction?: ComputeRegionUrlMapPathMatcherRouteRulesRouteAction;
    /**
    * url_redirect block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#url_redirect ComputeRegionUrlMap#url_redirect}
    */
    readonly urlRedirect?: ComputeRegionUrlMapPathMatcherRouteRulesUrlRedirect;
}
export declare function computeRegionUrlMapPathMatcherRouteRulesToTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRules | cdktn.IResolvable): any;
export declare function computeRegionUrlMapPathMatcherRouteRulesToHclTerraform(struct?: ComputeRegionUrlMapPathMatcherRouteRules | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapPathMatcherRouteRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapPathMatcherRouteRules | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcherRouteRules | cdktn.IResolvable | undefined);
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
    private _headerAction;
    get headerAction(): ComputeRegionUrlMapPathMatcherRouteRulesHeaderActionOutputReference;
    putHeaderAction(value: ComputeRegionUrlMapPathMatcherRouteRulesHeaderAction): void;
    resetHeaderAction(): void;
    get headerActionInput(): ComputeRegionUrlMapPathMatcherRouteRulesHeaderAction | undefined;
    private _matchRules;
    get matchRules(): ComputeRegionUrlMapPathMatcherRouteRulesMatchRulesList;
    putMatchRules(value: ComputeRegionUrlMapPathMatcherRouteRulesMatchRules[] | cdktn.IResolvable): void;
    resetMatchRules(): void;
    get matchRulesInput(): cdktn.IResolvable | ComputeRegionUrlMapPathMatcherRouteRulesMatchRules[] | undefined;
    private _routeAction;
    get routeAction(): ComputeRegionUrlMapPathMatcherRouteRulesRouteActionOutputReference;
    putRouteAction(value: ComputeRegionUrlMapPathMatcherRouteRulesRouteAction): void;
    resetRouteAction(): void;
    get routeActionInput(): ComputeRegionUrlMapPathMatcherRouteRulesRouteAction | undefined;
    private _urlRedirect;
    get urlRedirect(): ComputeRegionUrlMapPathMatcherRouteRulesUrlRedirectOutputReference;
    putUrlRedirect(value: ComputeRegionUrlMapPathMatcherRouteRulesUrlRedirect): void;
    resetUrlRedirect(): void;
    get urlRedirectInput(): ComputeRegionUrlMapPathMatcherRouteRulesUrlRedirect | undefined;
}
export declare class ComputeRegionUrlMapPathMatcherRouteRulesList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapPathMatcherRouteRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapPathMatcherRouteRulesOutputReference;
}
export interface ComputeRegionUrlMapPathMatcher {
    /**
    * A reference to a RegionBackendService resource. This will be used if
    * none of the pathRules defined by this PathMatcher is matched by
    * the URL's path portion.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#default_service ComputeRegionUrlMap#default_service}
    */
    readonly defaultService?: string;
    /**
    * An optional description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#description ComputeRegionUrlMap#description}
    */
    readonly description?: string;
    /**
    * The name to which this PathMatcher is referred by the HostRule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#name ComputeRegionUrlMap#name}
    */
    readonly name: string;
    /**
    * default_route_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#default_route_action ComputeRegionUrlMap#default_route_action}
    */
    readonly defaultRouteAction?: ComputeRegionUrlMapPathMatcherDefaultRouteAction;
    /**
    * default_url_redirect block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#default_url_redirect ComputeRegionUrlMap#default_url_redirect}
    */
    readonly defaultUrlRedirect?: ComputeRegionUrlMapPathMatcherDefaultUrlRedirect;
    /**
    * header_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#header_action ComputeRegionUrlMap#header_action}
    */
    readonly headerAction?: ComputeRegionUrlMapPathMatcherHeaderAction;
    /**
    * path_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#path_rule ComputeRegionUrlMap#path_rule}
    */
    readonly pathRule?: ComputeRegionUrlMapPathMatcherPathRule[] | cdktn.IResolvable;
    /**
    * route_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#route_rules ComputeRegionUrlMap#route_rules}
    */
    readonly routeRules?: ComputeRegionUrlMapPathMatcherRouteRules[] | cdktn.IResolvable;
}
export declare function computeRegionUrlMapPathMatcherToTerraform(struct?: ComputeRegionUrlMapPathMatcher | cdktn.IResolvable): any;
export declare function computeRegionUrlMapPathMatcherToHclTerraform(struct?: ComputeRegionUrlMapPathMatcher | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapPathMatcherOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapPathMatcher | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapPathMatcher | cdktn.IResolvable | undefined);
    private _defaultService?;
    get defaultService(): string;
    set defaultService(value: string);
    resetDefaultService(): void;
    get defaultServiceInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _defaultRouteAction;
    get defaultRouteAction(): ComputeRegionUrlMapPathMatcherDefaultRouteActionOutputReference;
    putDefaultRouteAction(value: ComputeRegionUrlMapPathMatcherDefaultRouteAction): void;
    resetDefaultRouteAction(): void;
    get defaultRouteActionInput(): ComputeRegionUrlMapPathMatcherDefaultRouteAction | undefined;
    private _defaultUrlRedirect;
    get defaultUrlRedirect(): ComputeRegionUrlMapPathMatcherDefaultUrlRedirectOutputReference;
    putDefaultUrlRedirect(value: ComputeRegionUrlMapPathMatcherDefaultUrlRedirect): void;
    resetDefaultUrlRedirect(): void;
    get defaultUrlRedirectInput(): ComputeRegionUrlMapPathMatcherDefaultUrlRedirect | undefined;
    private _headerAction;
    get headerAction(): ComputeRegionUrlMapPathMatcherHeaderActionOutputReference;
    putHeaderAction(value: ComputeRegionUrlMapPathMatcherHeaderAction): void;
    resetHeaderAction(): void;
    get headerActionInput(): ComputeRegionUrlMapPathMatcherHeaderAction | undefined;
    private _pathRule;
    get pathRule(): ComputeRegionUrlMapPathMatcherPathRuleList;
    putPathRule(value: ComputeRegionUrlMapPathMatcherPathRule[] | cdktn.IResolvable): void;
    resetPathRule(): void;
    get pathRuleInput(): cdktn.IResolvable | ComputeRegionUrlMapPathMatcherPathRule[] | undefined;
    private _routeRules;
    get routeRules(): ComputeRegionUrlMapPathMatcherRouteRulesList;
    putRouteRules(value: ComputeRegionUrlMapPathMatcherRouteRules[] | cdktn.IResolvable): void;
    resetRouteRules(): void;
    get routeRulesInput(): cdktn.IResolvable | ComputeRegionUrlMapPathMatcherRouteRules[] | undefined;
}
export declare class ComputeRegionUrlMapPathMatcherList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapPathMatcher[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapPathMatcherOutputReference;
}
export interface ComputeRegionUrlMapTest {
    /**
    * Description of this test case.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#description ComputeRegionUrlMap#description}
    */
    readonly description?: string;
    /**
    * Host portion of the URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#host ComputeRegionUrlMap#host}
    */
    readonly host: string;
    /**
    * Path portion of the URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#path ComputeRegionUrlMap#path}
    */
    readonly path: string;
    /**
    * A reference to expected RegionBackendService resource the given URL should be mapped to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#service ComputeRegionUrlMap#service}
    */
    readonly service: string;
}
export declare function computeRegionUrlMapTestToTerraform(struct?: ComputeRegionUrlMapTest | cdktn.IResolvable): any;
export declare function computeRegionUrlMapTestToHclTerraform(struct?: ComputeRegionUrlMapTest | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapTestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionUrlMapTest | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapTest | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _host?;
    get host(): string;
    set host(value: string);
    get hostInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
}
export declare class ComputeRegionUrlMapTestList extends cdktn.ComplexList {
    internalValue?: ComputeRegionUrlMapTest[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionUrlMapTestOutputReference;
}
export interface ComputeRegionUrlMapTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#create ComputeRegionUrlMap#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#delete ComputeRegionUrlMap#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#update ComputeRegionUrlMap#update}
    */
    readonly update?: string;
}
export declare function computeRegionUrlMapTimeoutsToTerraform(struct?: ComputeRegionUrlMapTimeouts | cdktn.IResolvable): any;
export declare function computeRegionUrlMapTimeoutsToHclTerraform(struct?: ComputeRegionUrlMapTimeouts | cdktn.IResolvable): any;
export declare class ComputeRegionUrlMapTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionUrlMapTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionUrlMapTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map google_compute_region_url_map}
*/
export declare class ComputeRegionUrlMap extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_region_url_map";
    /**
    * Generates CDKTN code for importing a ComputeRegionUrlMap resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeRegionUrlMap to import
    * @param importFromId The id of the existing ComputeRegionUrlMap that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeRegionUrlMap to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_region_url_map google_compute_region_url_map} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeRegionUrlMapConfig
    */
    constructor(scope: Construct, id: string, config: ComputeRegionUrlMapConfig);
    get creationTimestamp(): string;
    private _defaultService?;
    get defaultService(): string;
    set defaultService(value: string);
    resetDefaultService(): void;
    get defaultServiceInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get fingerprint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get mapId(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get selfLink(): string;
    private _defaultRouteAction;
    get defaultRouteAction(): ComputeRegionUrlMapDefaultRouteActionOutputReference;
    putDefaultRouteAction(value: ComputeRegionUrlMapDefaultRouteAction): void;
    resetDefaultRouteAction(): void;
    get defaultRouteActionInput(): ComputeRegionUrlMapDefaultRouteAction | undefined;
    private _defaultUrlRedirect;
    get defaultUrlRedirect(): ComputeRegionUrlMapDefaultUrlRedirectOutputReference;
    putDefaultUrlRedirect(value: ComputeRegionUrlMapDefaultUrlRedirect): void;
    resetDefaultUrlRedirect(): void;
    get defaultUrlRedirectInput(): ComputeRegionUrlMapDefaultUrlRedirect | undefined;
    private _headerAction;
    get headerAction(): ComputeRegionUrlMapHeaderActionOutputReference;
    putHeaderAction(value: ComputeRegionUrlMapHeaderAction): void;
    resetHeaderAction(): void;
    get headerActionInput(): ComputeRegionUrlMapHeaderAction | undefined;
    private _hostRule;
    get hostRule(): ComputeRegionUrlMapHostRuleList;
    putHostRule(value: ComputeRegionUrlMapHostRule[] | cdktn.IResolvable): void;
    resetHostRule(): void;
    get hostRuleInput(): cdktn.IResolvable | ComputeRegionUrlMapHostRule[] | undefined;
    private _pathMatcher;
    get pathMatcher(): ComputeRegionUrlMapPathMatcherList;
    putPathMatcher(value: ComputeRegionUrlMapPathMatcher[] | cdktn.IResolvable): void;
    resetPathMatcher(): void;
    get pathMatcherInput(): cdktn.IResolvable | ComputeRegionUrlMapPathMatcher[] | undefined;
    private _test;
    get test(): ComputeRegionUrlMapTestList;
    putTest(value: ComputeRegionUrlMapTest[] | cdktn.IResolvable): void;
    resetTest(): void;
    get testInput(): cdktn.IResolvable | ComputeRegionUrlMapTest[] | undefined;
    private _timeouts;
    get timeouts(): ComputeRegionUrlMapTimeoutsOutputReference;
    putTimeouts(value: ComputeRegionUrlMapTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeRegionUrlMapTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
