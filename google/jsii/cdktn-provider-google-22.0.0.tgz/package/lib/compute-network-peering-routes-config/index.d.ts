/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeNetworkPeeringRoutesConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether to export the custom routes to the peer network.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_peering_routes_config#export_custom_routes ComputeNetworkPeeringRoutesConfig#export_custom_routes}
    */
    readonly exportCustomRoutes: boolean | cdktn.IResolvable;
    /**
    * Whether subnet routes with public IP range are exported.
    * IPv4 special-use ranges are always exported to peers and
    * are not controlled by this field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_peering_routes_config#export_subnet_routes_with_public_ip ComputeNetworkPeeringRoutesConfig#export_subnet_routes_with_public_ip}
    */
    readonly exportSubnetRoutesWithPublicIp?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_peering_routes_config#id ComputeNetworkPeeringRoutesConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Whether to import the custom routes to the peer network.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_peering_routes_config#import_custom_routes ComputeNetworkPeeringRoutesConfig#import_custom_routes}
    */
    readonly importCustomRoutes: boolean | cdktn.IResolvable;
    /**
    * Whether subnet routes with public IP range are imported.
    * IPv4 special-use ranges are always imported from peers and
    * are not controlled by this field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_peering_routes_config#import_subnet_routes_with_public_ip ComputeNetworkPeeringRoutesConfig#import_subnet_routes_with_public_ip}
    */
    readonly importSubnetRoutesWithPublicIp?: boolean | cdktn.IResolvable;
    /**
    * The name of the primary network for the peering.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_peering_routes_config#network ComputeNetworkPeeringRoutesConfig#network}
    */
    readonly network: string;
    /**
    * Name of the peering.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_peering_routes_config#peering ComputeNetworkPeeringRoutesConfig#peering}
    */
    readonly peering: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_peering_routes_config#project ComputeNetworkPeeringRoutesConfig#project}
    */
    readonly project?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_peering_routes_config#timeouts ComputeNetworkPeeringRoutesConfig#timeouts}
    */
    readonly timeouts?: ComputeNetworkPeeringRoutesConfigTimeouts;
}
export interface ComputeNetworkPeeringRoutesConfigTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_peering_routes_config#create ComputeNetworkPeeringRoutesConfig#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_peering_routes_config#delete ComputeNetworkPeeringRoutesConfig#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_peering_routes_config#update ComputeNetworkPeeringRoutesConfig#update}
    */
    readonly update?: string;
}
export declare function computeNetworkPeeringRoutesConfigTimeoutsToTerraform(struct?: ComputeNetworkPeeringRoutesConfigTimeouts | cdktn.IResolvable): any;
export declare function computeNetworkPeeringRoutesConfigTimeoutsToHclTerraform(struct?: ComputeNetworkPeeringRoutesConfigTimeouts | cdktn.IResolvable): any;
export declare class ComputeNetworkPeeringRoutesConfigTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeNetworkPeeringRoutesConfigTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeNetworkPeeringRoutesConfigTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_peering_routes_config google_compute_network_peering_routes_config}
*/
export declare class ComputeNetworkPeeringRoutesConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_network_peering_routes_config";
    /**
    * Generates CDKTN code for importing a ComputeNetworkPeeringRoutesConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeNetworkPeeringRoutesConfig to import
    * @param importFromId The id of the existing ComputeNetworkPeeringRoutesConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_peering_routes_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeNetworkPeeringRoutesConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_network_peering_routes_config google_compute_network_peering_routes_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeNetworkPeeringRoutesConfigConfig
    */
    constructor(scope: Construct, id: string, config: ComputeNetworkPeeringRoutesConfigConfig);
    private _exportCustomRoutes?;
    get exportCustomRoutes(): boolean | cdktn.IResolvable;
    set exportCustomRoutes(value: boolean | cdktn.IResolvable);
    get exportCustomRoutesInput(): boolean | cdktn.IResolvable | undefined;
    private _exportSubnetRoutesWithPublicIp?;
    get exportSubnetRoutesWithPublicIp(): boolean | cdktn.IResolvable;
    set exportSubnetRoutesWithPublicIp(value: boolean | cdktn.IResolvable);
    resetExportSubnetRoutesWithPublicIp(): void;
    get exportSubnetRoutesWithPublicIpInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _importCustomRoutes?;
    get importCustomRoutes(): boolean | cdktn.IResolvable;
    set importCustomRoutes(value: boolean | cdktn.IResolvable);
    get importCustomRoutesInput(): boolean | cdktn.IResolvable | undefined;
    private _importSubnetRoutesWithPublicIp?;
    get importSubnetRoutesWithPublicIp(): boolean | cdktn.IResolvable;
    set importSubnetRoutesWithPublicIp(value: boolean | cdktn.IResolvable);
    resetImportSubnetRoutesWithPublicIp(): void;
    get importSubnetRoutesWithPublicIpInput(): boolean | cdktn.IResolvable | undefined;
    private _network?;
    get network(): string;
    set network(value: string);
    get networkInput(): string | undefined;
    private _peering?;
    get peering(): string;
    set peering(value: string);
    get peeringInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _timeouts;
    get timeouts(): ComputeNetworkPeeringRoutesConfigTimeoutsOutputReference;
    putTimeouts(value: ComputeNetworkPeeringRoutesConfigTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeNetworkPeeringRoutesConfigTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
