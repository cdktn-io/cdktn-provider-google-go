/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeInterconnectGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_group#deletion_policy ComputeInterconnectGroup#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource. Provide this property when you create the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_group#description ComputeInterconnectGroup#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_group#id ComputeInterconnectGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the resource. Provided by the client when the resource is created. The name must be
    * 1-63 characters long, and comply with RFC1035. Specifically, the name must be 1-63 characters
    * long and match the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the first
    * character must be a lowercase letter, and all following characters must be a dash,
    * lowercase letter, or digit, except the last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_group#name ComputeInterconnectGroup#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_group#project ComputeInterconnectGroup#project}
    */
    readonly project?: string;
    /**
    * intent block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_group#intent ComputeInterconnectGroup#intent}
    */
    readonly intent: ComputeInterconnectGroupIntent;
    /**
    * interconnects block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_group#interconnects ComputeInterconnectGroup#interconnects}
    */
    readonly interconnects?: ComputeInterconnectGroupInterconnects[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_group#timeouts ComputeInterconnectGroup#timeouts}
    */
    readonly timeouts?: ComputeInterconnectGroupTimeouts;
}
export interface ComputeInterconnectGroupConfiguredTopologyCapabilityIntendedCapabilityBlockers {
}
export declare function computeInterconnectGroupConfiguredTopologyCapabilityIntendedCapabilityBlockersToTerraform(struct?: ComputeInterconnectGroupConfiguredTopologyCapabilityIntendedCapabilityBlockers): any;
export declare function computeInterconnectGroupConfiguredTopologyCapabilityIntendedCapabilityBlockersToHclTerraform(struct?: ComputeInterconnectGroupConfiguredTopologyCapabilityIntendedCapabilityBlockers): any;
export declare class ComputeInterconnectGroupConfiguredTopologyCapabilityIntendedCapabilityBlockersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInterconnectGroupConfiguredTopologyCapabilityIntendedCapabilityBlockers | undefined;
    set internalValue(value: ComputeInterconnectGroupConfiguredTopologyCapabilityIntendedCapabilityBlockers | undefined);
    get blockerType(): string;
    get documentationLink(): string;
    get explanation(): string;
    get facilities(): string[];
    get interconnects(): string[];
    get metros(): string[];
    get zones(): string[];
}
export declare class ComputeInterconnectGroupConfiguredTopologyCapabilityIntendedCapabilityBlockersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInterconnectGroupConfiguredTopologyCapabilityIntendedCapabilityBlockersOutputReference;
}
export interface ComputeInterconnectGroupConfiguredTopologyCapability {
}
export declare function computeInterconnectGroupConfiguredTopologyCapabilityToTerraform(struct?: ComputeInterconnectGroupConfiguredTopologyCapability): any;
export declare function computeInterconnectGroupConfiguredTopologyCapabilityToHclTerraform(struct?: ComputeInterconnectGroupConfiguredTopologyCapability): any;
export declare class ComputeInterconnectGroupConfiguredTopologyCapabilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInterconnectGroupConfiguredTopologyCapability | undefined;
    set internalValue(value: ComputeInterconnectGroupConfiguredTopologyCapability | undefined);
    private _intendedCapabilityBlockers;
    get intendedCapabilityBlockers(): ComputeInterconnectGroupConfiguredTopologyCapabilityIntendedCapabilityBlockersList;
    get supportedSla(): string;
}
export declare class ComputeInterconnectGroupConfiguredTopologyCapabilityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInterconnectGroupConfiguredTopologyCapabilityOutputReference;
}
export interface ComputeInterconnectGroupConfigured {
}
export declare function computeInterconnectGroupConfiguredToTerraform(struct?: ComputeInterconnectGroupConfigured): any;
export declare function computeInterconnectGroupConfiguredToHclTerraform(struct?: ComputeInterconnectGroupConfigured): any;
export declare class ComputeInterconnectGroupConfiguredOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInterconnectGroupConfigured | undefined;
    set internalValue(value: ComputeInterconnectGroupConfigured | undefined);
    private _topologyCapability;
    get topologyCapability(): ComputeInterconnectGroupConfiguredTopologyCapabilityList;
}
export declare class ComputeInterconnectGroupConfiguredList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInterconnectGroupConfiguredOutputReference;
}
export interface ComputeInterconnectGroupPhysicalStructureMetrosFacilitiesZones {
}
export declare function computeInterconnectGroupPhysicalStructureMetrosFacilitiesZonesToTerraform(struct?: ComputeInterconnectGroupPhysicalStructureMetrosFacilitiesZones): any;
export declare function computeInterconnectGroupPhysicalStructureMetrosFacilitiesZonesToHclTerraform(struct?: ComputeInterconnectGroupPhysicalStructureMetrosFacilitiesZones): any;
export declare class ComputeInterconnectGroupPhysicalStructureMetrosFacilitiesZonesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInterconnectGroupPhysicalStructureMetrosFacilitiesZones | undefined;
    set internalValue(value: ComputeInterconnectGroupPhysicalStructureMetrosFacilitiesZones | undefined);
    get interconnects(): string[];
    get zone(): string;
}
export declare class ComputeInterconnectGroupPhysicalStructureMetrosFacilitiesZonesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInterconnectGroupPhysicalStructureMetrosFacilitiesZonesOutputReference;
}
export interface ComputeInterconnectGroupPhysicalStructureMetrosFacilities {
}
export declare function computeInterconnectGroupPhysicalStructureMetrosFacilitiesToTerraform(struct?: ComputeInterconnectGroupPhysicalStructureMetrosFacilities): any;
export declare function computeInterconnectGroupPhysicalStructureMetrosFacilitiesToHclTerraform(struct?: ComputeInterconnectGroupPhysicalStructureMetrosFacilities): any;
export declare class ComputeInterconnectGroupPhysicalStructureMetrosFacilitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInterconnectGroupPhysicalStructureMetrosFacilities | undefined;
    set internalValue(value: ComputeInterconnectGroupPhysicalStructureMetrosFacilities | undefined);
    get facility(): string;
    private _zones;
    get zones(): ComputeInterconnectGroupPhysicalStructureMetrosFacilitiesZonesList;
}
export declare class ComputeInterconnectGroupPhysicalStructureMetrosFacilitiesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInterconnectGroupPhysicalStructureMetrosFacilitiesOutputReference;
}
export interface ComputeInterconnectGroupPhysicalStructureMetros {
}
export declare function computeInterconnectGroupPhysicalStructureMetrosToTerraform(struct?: ComputeInterconnectGroupPhysicalStructureMetros): any;
export declare function computeInterconnectGroupPhysicalStructureMetrosToHclTerraform(struct?: ComputeInterconnectGroupPhysicalStructureMetros): any;
export declare class ComputeInterconnectGroupPhysicalStructureMetrosOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInterconnectGroupPhysicalStructureMetros | undefined;
    set internalValue(value: ComputeInterconnectGroupPhysicalStructureMetros | undefined);
    private _facilities;
    get facilities(): ComputeInterconnectGroupPhysicalStructureMetrosFacilitiesList;
    get metro(): string;
}
export declare class ComputeInterconnectGroupPhysicalStructureMetrosList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInterconnectGroupPhysicalStructureMetrosOutputReference;
}
export interface ComputeInterconnectGroupPhysicalStructure {
}
export declare function computeInterconnectGroupPhysicalStructureToTerraform(struct?: ComputeInterconnectGroupPhysicalStructure): any;
export declare function computeInterconnectGroupPhysicalStructureToHclTerraform(struct?: ComputeInterconnectGroupPhysicalStructure): any;
export declare class ComputeInterconnectGroupPhysicalStructureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInterconnectGroupPhysicalStructure | undefined;
    set internalValue(value: ComputeInterconnectGroupPhysicalStructure | undefined);
    private _metros;
    get metros(): ComputeInterconnectGroupPhysicalStructureMetrosList;
}
export declare class ComputeInterconnectGroupPhysicalStructureList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInterconnectGroupPhysicalStructureOutputReference;
}
export interface ComputeInterconnectGroupIntent {
    /**
    * The reliability the user intends this group to be capable of, in terms
    * of the Interconnect product SLAs. Possible values: ["PRODUCTION_NON_CRITICAL", "PRODUCTION_CRITICAL", "NO_SLA", "AVAILABILITY_SLA_UNSPECIFIED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_group#topology_capability ComputeInterconnectGroup#topology_capability}
    */
    readonly topologyCapability?: string;
}
export declare function computeInterconnectGroupIntentToTerraform(struct?: ComputeInterconnectGroupIntentOutputReference | ComputeInterconnectGroupIntent): any;
export declare function computeInterconnectGroupIntentToHclTerraform(struct?: ComputeInterconnectGroupIntentOutputReference | ComputeInterconnectGroupIntent): any;
export declare class ComputeInterconnectGroupIntentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInterconnectGroupIntent | undefined;
    set internalValue(value: ComputeInterconnectGroupIntent | undefined);
    private _topologyCapability?;
    get topologyCapability(): string;
    set topologyCapability(value: string);
    resetTopologyCapability(): void;
    get topologyCapabilityInput(): string | undefined;
}
export interface ComputeInterconnectGroupInterconnects {
    /**
    * The URL of an Interconnect in this group. All Interconnects in the group are unique.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_group#interconnect ComputeInterconnectGroup#interconnect}
    */
    readonly interconnect?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_group#name ComputeInterconnectGroup#name}
    */
    readonly name: string;
}
export declare function computeInterconnectGroupInterconnectsToTerraform(struct?: ComputeInterconnectGroupInterconnects | cdktn.IResolvable): any;
export declare function computeInterconnectGroupInterconnectsToHclTerraform(struct?: ComputeInterconnectGroupInterconnects | cdktn.IResolvable): any;
export declare class ComputeInterconnectGroupInterconnectsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInterconnectGroupInterconnects | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInterconnectGroupInterconnects | cdktn.IResolvable | undefined);
    private _interconnect?;
    get interconnect(): string;
    set interconnect(value: string);
    resetInterconnect(): void;
    get interconnectInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class ComputeInterconnectGroupInterconnectsList extends cdktn.ComplexList {
    internalValue?: ComputeInterconnectGroupInterconnects[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInterconnectGroupInterconnectsOutputReference;
}
export interface ComputeInterconnectGroupTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_group#create ComputeInterconnectGroup#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_group#delete ComputeInterconnectGroup#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_group#update ComputeInterconnectGroup#update}
    */
    readonly update?: string;
}
export declare function computeInterconnectGroupTimeoutsToTerraform(struct?: ComputeInterconnectGroupTimeouts | cdktn.IResolvable): any;
export declare function computeInterconnectGroupTimeoutsToHclTerraform(struct?: ComputeInterconnectGroupTimeouts | cdktn.IResolvable): any;
export declare class ComputeInterconnectGroupTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInterconnectGroupTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInterconnectGroupTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_group google_compute_interconnect_group}
*/
export declare class ComputeInterconnectGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_interconnect_group";
    /**
    * Generates CDKTN code for importing a ComputeInterconnectGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeInterconnectGroup to import
    * @param importFromId The id of the existing ComputeInterconnectGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeInterconnectGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_group google_compute_interconnect_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeInterconnectGroupConfig
    */
    constructor(scope: Construct, id: string, config: ComputeInterconnectGroupConfig);
    private _configured;
    get configured(): ComputeInterconnectGroupConfiguredList;
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _physicalStructure;
    get physicalStructure(): ComputeInterconnectGroupPhysicalStructureList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _intent;
    get intent(): ComputeInterconnectGroupIntentOutputReference;
    putIntent(value: ComputeInterconnectGroupIntent): void;
    get intentInput(): ComputeInterconnectGroupIntent | undefined;
    private _interconnects;
    get interconnects(): ComputeInterconnectGroupInterconnectsList;
    putInterconnects(value: ComputeInterconnectGroupInterconnects[] | cdktn.IResolvable): void;
    resetInterconnects(): void;
    get interconnectsInput(): cdktn.IResolvable | ComputeInterconnectGroupInterconnects[] | undefined;
    private _timeouts;
    get timeouts(): ComputeInterconnectGroupTimeoutsOutputReference;
    putTimeouts(value: ComputeInterconnectGroupTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeInterconnectGroupTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
