/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeInterconnectAttachmentGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment_group#deletion_policy ComputeInterconnectAttachmentGroup#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource. Provide this property when you create the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment_group#description ComputeInterconnectAttachmentGroup#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment_group#id ComputeInterconnectAttachmentGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The URL of an InterconnectGroup that groups these Attachments'
    * Interconnects. Customers do not need to set this unless directed by
    * Google Support.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment_group#interconnect_group ComputeInterconnectAttachmentGroup#interconnect_group}
    */
    readonly interconnectGroup?: string;
    /**
    * Name of the resource. Provided by the client when the resource is created. The name must be
    * 1-63 characters long, and comply with RFC1035. Specifically, the name must be 1-63 characters
    * long and match the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the first
    * character must be a lowercase letter, and all following characters must be a dash,
    * lowercase letter, or digit, except the last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment_group#name ComputeInterconnectAttachmentGroup#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment_group#project ComputeInterconnectAttachmentGroup#project}
    */
    readonly project?: string;
    /**
    * attachments block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment_group#attachments ComputeInterconnectAttachmentGroup#attachments}
    */
    readonly attachments?: ComputeInterconnectAttachmentGroupAttachments[] | cdktn.IResolvable;
    /**
    * intent block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment_group#intent ComputeInterconnectAttachmentGroup#intent}
    */
    readonly intent: ComputeInterconnectAttachmentGroupIntent;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment_group#timeouts ComputeInterconnectAttachmentGroup#timeouts}
    */
    readonly timeouts?: ComputeInterconnectAttachmentGroupTimeouts;
}
export interface ComputeInterconnectAttachmentGroupConfiguredAvailabilitySlaIntendedSlaBlockers {
}
export declare function computeInterconnectAttachmentGroupConfiguredAvailabilitySlaIntendedSlaBlockersToTerraform(struct?: ComputeInterconnectAttachmentGroupConfiguredAvailabilitySlaIntendedSlaBlockers): any;
export declare function computeInterconnectAttachmentGroupConfiguredAvailabilitySlaIntendedSlaBlockersToHclTerraform(struct?: ComputeInterconnectAttachmentGroupConfiguredAvailabilitySlaIntendedSlaBlockers): any;
export declare class ComputeInterconnectAttachmentGroupConfiguredAvailabilitySlaIntendedSlaBlockersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInterconnectAttachmentGroupConfiguredAvailabilitySlaIntendedSlaBlockers | undefined;
    set internalValue(value: ComputeInterconnectAttachmentGroupConfiguredAvailabilitySlaIntendedSlaBlockers | undefined);
    get attachments(): string[];
    get blockerType(): string;
    get documentationLink(): string;
    get explanation(): string;
    get metros(): string[];
    get regions(): string[];
    get zones(): string[];
}
export declare class ComputeInterconnectAttachmentGroupConfiguredAvailabilitySlaIntendedSlaBlockersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInterconnectAttachmentGroupConfiguredAvailabilitySlaIntendedSlaBlockersOutputReference;
}
export interface ComputeInterconnectAttachmentGroupConfiguredAvailabilitySla {
}
export declare function computeInterconnectAttachmentGroupConfiguredAvailabilitySlaToTerraform(struct?: ComputeInterconnectAttachmentGroupConfiguredAvailabilitySla): any;
export declare function computeInterconnectAttachmentGroupConfiguredAvailabilitySlaToHclTerraform(struct?: ComputeInterconnectAttachmentGroupConfiguredAvailabilitySla): any;
export declare class ComputeInterconnectAttachmentGroupConfiguredAvailabilitySlaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInterconnectAttachmentGroupConfiguredAvailabilitySla | undefined;
    set internalValue(value: ComputeInterconnectAttachmentGroupConfiguredAvailabilitySla | undefined);
    get effectiveSla(): string;
    private _intendedSlaBlockers;
    get intendedSlaBlockers(): ComputeInterconnectAttachmentGroupConfiguredAvailabilitySlaIntendedSlaBlockersList;
}
export declare class ComputeInterconnectAttachmentGroupConfiguredAvailabilitySlaList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInterconnectAttachmentGroupConfiguredAvailabilitySlaOutputReference;
}
export interface ComputeInterconnectAttachmentGroupConfigured {
}
export declare function computeInterconnectAttachmentGroupConfiguredToTerraform(struct?: ComputeInterconnectAttachmentGroupConfigured): any;
export declare function computeInterconnectAttachmentGroupConfiguredToHclTerraform(struct?: ComputeInterconnectAttachmentGroupConfigured): any;
export declare class ComputeInterconnectAttachmentGroupConfiguredOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInterconnectAttachmentGroupConfigured | undefined;
    set internalValue(value: ComputeInterconnectAttachmentGroupConfigured | undefined);
    private _availabilitySla;
    get availabilitySla(): ComputeInterconnectAttachmentGroupConfiguredAvailabilitySlaList;
}
export declare class ComputeInterconnectAttachmentGroupConfiguredList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInterconnectAttachmentGroupConfiguredOutputReference;
}
export interface ComputeInterconnectAttachmentGroupLogicalStructureRegionsMetrosFacilitiesZones {
}
export declare function computeInterconnectAttachmentGroupLogicalStructureRegionsMetrosFacilitiesZonesToTerraform(struct?: ComputeInterconnectAttachmentGroupLogicalStructureRegionsMetrosFacilitiesZones): any;
export declare function computeInterconnectAttachmentGroupLogicalStructureRegionsMetrosFacilitiesZonesToHclTerraform(struct?: ComputeInterconnectAttachmentGroupLogicalStructureRegionsMetrosFacilitiesZones): any;
export declare class ComputeInterconnectAttachmentGroupLogicalStructureRegionsMetrosFacilitiesZonesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInterconnectAttachmentGroupLogicalStructureRegionsMetrosFacilitiesZones | undefined;
    set internalValue(value: ComputeInterconnectAttachmentGroupLogicalStructureRegionsMetrosFacilitiesZones | undefined);
    get attachments(): string[];
    get zone(): string;
}
export declare class ComputeInterconnectAttachmentGroupLogicalStructureRegionsMetrosFacilitiesZonesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInterconnectAttachmentGroupLogicalStructureRegionsMetrosFacilitiesZonesOutputReference;
}
export interface ComputeInterconnectAttachmentGroupLogicalStructureRegionsMetrosFacilities {
}
export declare function computeInterconnectAttachmentGroupLogicalStructureRegionsMetrosFacilitiesToTerraform(struct?: ComputeInterconnectAttachmentGroupLogicalStructureRegionsMetrosFacilities): any;
export declare function computeInterconnectAttachmentGroupLogicalStructureRegionsMetrosFacilitiesToHclTerraform(struct?: ComputeInterconnectAttachmentGroupLogicalStructureRegionsMetrosFacilities): any;
export declare class ComputeInterconnectAttachmentGroupLogicalStructureRegionsMetrosFacilitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInterconnectAttachmentGroupLogicalStructureRegionsMetrosFacilities | undefined;
    set internalValue(value: ComputeInterconnectAttachmentGroupLogicalStructureRegionsMetrosFacilities | undefined);
    get facility(): string;
    private _zones;
    get zones(): ComputeInterconnectAttachmentGroupLogicalStructureRegionsMetrosFacilitiesZonesList;
}
export declare class ComputeInterconnectAttachmentGroupLogicalStructureRegionsMetrosFacilitiesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInterconnectAttachmentGroupLogicalStructureRegionsMetrosFacilitiesOutputReference;
}
export interface ComputeInterconnectAttachmentGroupLogicalStructureRegionsMetros {
}
export declare function computeInterconnectAttachmentGroupLogicalStructureRegionsMetrosToTerraform(struct?: ComputeInterconnectAttachmentGroupLogicalStructureRegionsMetros): any;
export declare function computeInterconnectAttachmentGroupLogicalStructureRegionsMetrosToHclTerraform(struct?: ComputeInterconnectAttachmentGroupLogicalStructureRegionsMetros): any;
export declare class ComputeInterconnectAttachmentGroupLogicalStructureRegionsMetrosOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInterconnectAttachmentGroupLogicalStructureRegionsMetros | undefined;
    set internalValue(value: ComputeInterconnectAttachmentGroupLogicalStructureRegionsMetros | undefined);
    private _facilities;
    get facilities(): ComputeInterconnectAttachmentGroupLogicalStructureRegionsMetrosFacilitiesList;
    get metro(): string;
}
export declare class ComputeInterconnectAttachmentGroupLogicalStructureRegionsMetrosList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInterconnectAttachmentGroupLogicalStructureRegionsMetrosOutputReference;
}
export interface ComputeInterconnectAttachmentGroupLogicalStructureRegions {
}
export declare function computeInterconnectAttachmentGroupLogicalStructureRegionsToTerraform(struct?: ComputeInterconnectAttachmentGroupLogicalStructureRegions): any;
export declare function computeInterconnectAttachmentGroupLogicalStructureRegionsToHclTerraform(struct?: ComputeInterconnectAttachmentGroupLogicalStructureRegions): any;
export declare class ComputeInterconnectAttachmentGroupLogicalStructureRegionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInterconnectAttachmentGroupLogicalStructureRegions | undefined;
    set internalValue(value: ComputeInterconnectAttachmentGroupLogicalStructureRegions | undefined);
    private _metros;
    get metros(): ComputeInterconnectAttachmentGroupLogicalStructureRegionsMetrosList;
    get region(): string;
}
export declare class ComputeInterconnectAttachmentGroupLogicalStructureRegionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInterconnectAttachmentGroupLogicalStructureRegionsOutputReference;
}
export interface ComputeInterconnectAttachmentGroupLogicalStructure {
}
export declare function computeInterconnectAttachmentGroupLogicalStructureToTerraform(struct?: ComputeInterconnectAttachmentGroupLogicalStructure): any;
export declare function computeInterconnectAttachmentGroupLogicalStructureToHclTerraform(struct?: ComputeInterconnectAttachmentGroupLogicalStructure): any;
export declare class ComputeInterconnectAttachmentGroupLogicalStructureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInterconnectAttachmentGroupLogicalStructure | undefined;
    set internalValue(value: ComputeInterconnectAttachmentGroupLogicalStructure | undefined);
    private _regions;
    get regions(): ComputeInterconnectAttachmentGroupLogicalStructureRegionsList;
}
export declare class ComputeInterconnectAttachmentGroupLogicalStructureList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInterconnectAttachmentGroupLogicalStructureOutputReference;
}
export interface ComputeInterconnectAttachmentGroupAttachments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment_group#attachment ComputeInterconnectAttachmentGroup#attachment}
    */
    readonly attachment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment_group#name ComputeInterconnectAttachmentGroup#name}
    */
    readonly name: string;
}
export declare function computeInterconnectAttachmentGroupAttachmentsToTerraform(struct?: ComputeInterconnectAttachmentGroupAttachments | cdktn.IResolvable): any;
export declare function computeInterconnectAttachmentGroupAttachmentsToHclTerraform(struct?: ComputeInterconnectAttachmentGroupAttachments | cdktn.IResolvable): any;
export declare class ComputeInterconnectAttachmentGroupAttachmentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInterconnectAttachmentGroupAttachments | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInterconnectAttachmentGroupAttachments | cdktn.IResolvable | undefined);
    private _attachment?;
    get attachment(): string;
    set attachment(value: string);
    resetAttachment(): void;
    get attachmentInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class ComputeInterconnectAttachmentGroupAttachmentsList extends cdktn.ComplexList {
    internalValue?: ComputeInterconnectAttachmentGroupAttachments[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInterconnectAttachmentGroupAttachmentsOutputReference;
}
export interface ComputeInterconnectAttachmentGroupIntent {
    /**
    * Which SLA the user intends this group to support. Possible values: ["PRODUCTION_NON_CRITICAL", "PRODUCTION_CRITICAL", "NO_SLA", "AVAILABILITY_SLA_UNSPECIFIED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment_group#availability_sla ComputeInterconnectAttachmentGroup#availability_sla}
    */
    readonly availabilitySla?: string;
}
export declare function computeInterconnectAttachmentGroupIntentToTerraform(struct?: ComputeInterconnectAttachmentGroupIntentOutputReference | ComputeInterconnectAttachmentGroupIntent): any;
export declare function computeInterconnectAttachmentGroupIntentToHclTerraform(struct?: ComputeInterconnectAttachmentGroupIntentOutputReference | ComputeInterconnectAttachmentGroupIntent): any;
export declare class ComputeInterconnectAttachmentGroupIntentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInterconnectAttachmentGroupIntent | undefined;
    set internalValue(value: ComputeInterconnectAttachmentGroupIntent | undefined);
    private _availabilitySla?;
    get availabilitySla(): string;
    set availabilitySla(value: string);
    resetAvailabilitySla(): void;
    get availabilitySlaInput(): string | undefined;
}
export interface ComputeInterconnectAttachmentGroupTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment_group#create ComputeInterconnectAttachmentGroup#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment_group#delete ComputeInterconnectAttachmentGroup#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment_group#update ComputeInterconnectAttachmentGroup#update}
    */
    readonly update?: string;
}
export declare function computeInterconnectAttachmentGroupTimeoutsToTerraform(struct?: ComputeInterconnectAttachmentGroupTimeouts | cdktn.IResolvable): any;
export declare function computeInterconnectAttachmentGroupTimeoutsToHclTerraform(struct?: ComputeInterconnectAttachmentGroupTimeouts | cdktn.IResolvable): any;
export declare class ComputeInterconnectAttachmentGroupTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInterconnectAttachmentGroupTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInterconnectAttachmentGroupTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment_group google_compute_interconnect_attachment_group}
*/
export declare class ComputeInterconnectAttachmentGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_interconnect_attachment_group";
    /**
    * Generates CDKTN code for importing a ComputeInterconnectAttachmentGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeInterconnectAttachmentGroup to import
    * @param importFromId The id of the existing ComputeInterconnectAttachmentGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeInterconnectAttachmentGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_interconnect_attachment_group google_compute_interconnect_attachment_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeInterconnectAttachmentGroupConfig
    */
    constructor(scope: Construct, id: string, config: ComputeInterconnectAttachmentGroupConfig);
    private _configured;
    get configured(): ComputeInterconnectAttachmentGroupConfiguredList;
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _interconnectGroup?;
    get interconnectGroup(): string;
    set interconnectGroup(value: string);
    resetInterconnectGroup(): void;
    get interconnectGroupInput(): string | undefined;
    private _logicalStructure;
    get logicalStructure(): ComputeInterconnectAttachmentGroupLogicalStructureList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _attachments;
    get attachments(): ComputeInterconnectAttachmentGroupAttachmentsList;
    putAttachments(value: ComputeInterconnectAttachmentGroupAttachments[] | cdktn.IResolvable): void;
    resetAttachments(): void;
    get attachmentsInput(): cdktn.IResolvable | ComputeInterconnectAttachmentGroupAttachments[] | undefined;
    private _intent;
    get intent(): ComputeInterconnectAttachmentGroupIntentOutputReference;
    putIntent(value: ComputeInterconnectAttachmentGroupIntent): void;
    get intentInput(): ComputeInterconnectAttachmentGroupIntent | undefined;
    private _timeouts;
    get timeouts(): ComputeInterconnectAttachmentGroupTimeoutsOutputReference;
    putTimeouts(value: ComputeInterconnectAttachmentGroupTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeInterconnectAttachmentGroupTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
