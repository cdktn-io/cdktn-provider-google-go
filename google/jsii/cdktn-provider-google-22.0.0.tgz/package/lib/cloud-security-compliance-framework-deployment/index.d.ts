/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudSecurityComplianceFrameworkDeploymentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#deletion_policy CloudSecurityComplianceFrameworkDeployment#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * User provided description of the Framework deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#description CloudSecurityComplianceFrameworkDeployment#description}
    */
    readonly description?: string;
    /**
    * User provided identifier. It should be unique in scope of a parent.
    * This is optional and if not provided, a random UUID will be generated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#framework_deployment_id CloudSecurityComplianceFrameworkDeployment#framework_deployment_id}
    */
    readonly frameworkDeploymentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#id CloudSecurityComplianceFrameworkDeployment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#location CloudSecurityComplianceFrameworkDeployment#location}
    */
    readonly location?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#organization CloudSecurityComplianceFrameworkDeployment#organization}
    */
    readonly organization?: string;
    /**
    * The parent resource in which to create the resource.
    * Must be in one of the following formats:
    * * 'projects/{{project}}'
    * * 'organizations/{{organization}}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#parent CloudSecurityComplianceFrameworkDeployment#parent}
    */
    readonly parent?: string;
    /**
    * cloud_control_metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#cloud_control_metadata CloudSecurityComplianceFrameworkDeployment#cloud_control_metadata}
    */
    readonly cloudControlMetadata: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadata[] | cdktn.IResolvable;
    /**
    * framework block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#framework CloudSecurityComplianceFrameworkDeployment#framework}
    */
    readonly framework: CloudSecurityComplianceFrameworkDeploymentFramework;
    /**
    * target_resource_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#target_resource_config CloudSecurityComplianceFrameworkDeployment#target_resource_config}
    */
    readonly targetResourceConfig: CloudSecurityComplianceFrameworkDeploymentTargetResourceConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#timeouts CloudSecurityComplianceFrameworkDeployment#timeouts}
    */
    readonly timeouts?: CloudSecurityComplianceFrameworkDeploymentTimeouts;
}
export interface CloudSecurityComplianceFrameworkDeploymentCloudControlDeploymentReferences {
}
export declare function cloudSecurityComplianceFrameworkDeploymentCloudControlDeploymentReferencesToTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentCloudControlDeploymentReferences): any;
export declare function cloudSecurityComplianceFrameworkDeploymentCloudControlDeploymentReferencesToHclTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentCloudControlDeploymentReferences): any;
export declare class CloudSecurityComplianceFrameworkDeploymentCloudControlDeploymentReferencesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudSecurityComplianceFrameworkDeploymentCloudControlDeploymentReferences | undefined;
    set internalValue(value: CloudSecurityComplianceFrameworkDeploymentCloudControlDeploymentReferences | undefined);
    get cloudControlDeployment(): string;
}
export declare class CloudSecurityComplianceFrameworkDeploymentCloudControlDeploymentReferencesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudSecurityComplianceFrameworkDeploymentCloudControlDeploymentReferencesOutputReference;
}
export interface CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValue {
    /**
    * The strings in the list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#values CloudSecurityComplianceFrameworkDeployment#values}
    */
    readonly values: string[];
}
export declare function cloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValueToTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValueOutputReference | CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValue): any;
export declare function cloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValueToHclTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValueOutputReference | CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValue): any;
export declare class CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValue | undefined;
    set internalValue(value: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValue | undefined);
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export interface CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValue {
    /**
    * Represents a boolean value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#bool_value CloudSecurityComplianceFrameworkDeployment#bool_value}
    */
    readonly boolValue?: boolean | cdktn.IResolvable;
    /**
    * Represents a double value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#number_value CloudSecurityComplianceFrameworkDeployment#number_value}
    */
    readonly numberValue?: number;
    /**
    * Represents a string value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#string_value CloudSecurityComplianceFrameworkDeployment#string_value}
    */
    readonly stringValue?: string;
    /**
    * string_list_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#string_list_value CloudSecurityComplianceFrameworkDeployment#string_list_value}
    */
    readonly stringListValue?: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValue;
}
export declare function cloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValueToTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValueOutputReference | CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValue): any;
export declare function cloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValueToHclTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValueOutputReference | CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValue): any;
export declare class CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValue | undefined;
    set internalValue(value: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValue | undefined);
    private _boolValue?;
    get boolValue(): boolean | cdktn.IResolvable;
    set boolValue(value: boolean | cdktn.IResolvable);
    resetBoolValue(): void;
    get boolValueInput(): boolean | cdktn.IResolvable | undefined;
    private _numberValue?;
    get numberValue(): number;
    set numberValue(value: number);
    resetNumberValue(): void;
    get numberValueInput(): number | undefined;
    private _stringValue?;
    get stringValue(): string;
    set stringValue(value: string);
    resetStringValue(): void;
    get stringValueInput(): string | undefined;
    private _stringListValue;
    get stringListValue(): CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValueOutputReference;
    putStringListValue(value: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValue): void;
    resetStringListValue(): void;
    get stringListValueInput(): CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValue | undefined;
}
export interface CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValue {
    /**
    * The name of the parameter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#name CloudSecurityComplianceFrameworkDeployment#name}
    */
    readonly name?: string;
    /**
    * parameter_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#parameter_value CloudSecurityComplianceFrameworkDeployment#parameter_value}
    */
    readonly parameterValue?: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValue;
}
export declare function cloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueToTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueOutputReference | CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValue): any;
export declare function cloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueToHclTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueOutputReference | CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValue): any;
export declare class CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValue | undefined;
    set internalValue(value: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValue | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _parameterValue;
    get parameterValue(): CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValueOutputReference;
    putParameterValue(value: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValue): void;
    resetParameterValue(): void;
    get parameterValueInput(): CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueParameterValue | undefined;
}
export interface CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueStringListValue {
    /**
    * The strings in the list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#values CloudSecurityComplianceFrameworkDeployment#values}
    */
    readonly values: string[];
}
export declare function cloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueStringListValueToTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueStringListValueOutputReference | CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueStringListValue): any;
export declare function cloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueStringListValueToHclTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueStringListValueOutputReference | CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueStringListValue): any;
export declare class CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueStringListValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueStringListValue | undefined;
    set internalValue(value: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueStringListValue | undefined);
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export interface CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValue {
    /**
    * Represents a boolean value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#bool_value CloudSecurityComplianceFrameworkDeployment#bool_value}
    */
    readonly boolValue?: boolean | cdktn.IResolvable;
    /**
    * Represents a double value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#number_value CloudSecurityComplianceFrameworkDeployment#number_value}
    */
    readonly numberValue?: number;
    /**
    * Represents a string value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#string_value CloudSecurityComplianceFrameworkDeployment#string_value}
    */
    readonly stringValue?: string;
    /**
    * oneof_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#oneof_value CloudSecurityComplianceFrameworkDeployment#oneof_value}
    */
    readonly oneofValue?: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValue;
    /**
    * string_list_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#string_list_value CloudSecurityComplianceFrameworkDeployment#string_list_value}
    */
    readonly stringListValue?: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueStringListValue;
}
export declare function cloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueToTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOutputReference | CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValue): any;
export declare function cloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueToHclTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOutputReference | CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValue): any;
export declare class CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValue | undefined;
    set internalValue(value: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValue | undefined);
    private _boolValue?;
    get boolValue(): boolean | cdktn.IResolvable;
    set boolValue(value: boolean | cdktn.IResolvable);
    resetBoolValue(): void;
    get boolValueInput(): boolean | cdktn.IResolvable | undefined;
    private _numberValue?;
    get numberValue(): number;
    set numberValue(value: number);
    resetNumberValue(): void;
    get numberValueInput(): number | undefined;
    private _stringValue?;
    get stringValue(): string;
    set stringValue(value: string);
    resetStringValue(): void;
    get stringValueInput(): string | undefined;
    private _oneofValue;
    get oneofValue(): CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValueOutputReference;
    putOneofValue(value: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValue): void;
    resetOneofValue(): void;
    get oneofValueInput(): CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOneofValue | undefined;
    private _stringListValue;
    get stringListValue(): CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueStringListValueOutputReference;
    putStringListValue(value: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueStringListValue): void;
    resetStringListValue(): void;
    get stringListValueInput(): CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueStringListValue | undefined;
}
export interface CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParameters {
    /**
    * The name of the parameter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#name CloudSecurityComplianceFrameworkDeployment#name}
    */
    readonly name: string;
    /**
    * parameter_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#parameter_value CloudSecurityComplianceFrameworkDeployment#parameter_value}
    */
    readonly parameterValue: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValue;
}
export declare function cloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersToTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParameters | cdktn.IResolvable): any;
export declare function cloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersToHclTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParameters | cdktn.IResolvable): any;
export declare class CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParameters | cdktn.IResolvable | undefined;
    set internalValue(value: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParameters | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameterValue;
    get parameterValue(): CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValueOutputReference;
    putParameterValue(value: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValue): void;
    get parameterValueInput(): CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersParameterValue | undefined;
}
export declare class CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersList extends cdktn.ComplexList {
    internalValue?: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersOutputReference;
}
export interface CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetails {
    /**
    * Major revision of cloudcontrol
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#major_revision_id CloudSecurityComplianceFrameworkDeployment#major_revision_id}
    */
    readonly majorRevisionId: string;
    /**
    * The name of the CloudControl in the format:
    * "{parent}/locations/{location}/cloudControls/{cloud-control}"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#name CloudSecurityComplianceFrameworkDeployment#name}
    */
    readonly name: string;
    /**
    * parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#parameters CloudSecurityComplianceFrameworkDeployment#parameters}
    */
    readonly parameters?: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParameters[] | cdktn.IResolvable;
}
export declare function cloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsToTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsOutputReference | CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetails): any;
export declare function cloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsToHclTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsOutputReference | CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetails): any;
export declare class CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetails | undefined;
    set internalValue(value: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetails | undefined);
    private _majorRevisionId?;
    get majorRevisionId(): string;
    set majorRevisionId(value: string);
    get majorRevisionIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters;
    get parameters(): CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParametersList;
    putParameters(value: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParameters[] | cdktn.IResolvable): void;
    resetParameters(): void;
    get parametersInput(): cdktn.IResolvable | CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsParameters[] | undefined;
}
export interface CloudSecurityComplianceFrameworkDeploymentCloudControlMetadata {
    /**
    * Enforcement mode for the framework deployment.
    * Possible values:
    * PREVENTIVE
    * DETECTIVE
    * AUDIT
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#enforcement_mode CloudSecurityComplianceFrameworkDeployment#enforcement_mode}
    */
    readonly enforcementMode: string;
    /**
    * cloud_control_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#cloud_control_details CloudSecurityComplianceFrameworkDeployment#cloud_control_details}
    */
    readonly cloudControlDetails: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetails;
}
export declare function cloudSecurityComplianceFrameworkDeploymentCloudControlMetadataToTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadata | cdktn.IResolvable): any;
export declare function cloudSecurityComplianceFrameworkDeploymentCloudControlMetadataToHclTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadata | cdktn.IResolvable): any;
export declare class CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudSecurityComplianceFrameworkDeploymentCloudControlMetadata | cdktn.IResolvable | undefined;
    set internalValue(value: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadata | cdktn.IResolvable | undefined);
    private _enforcementMode?;
    get enforcementMode(): string;
    set enforcementMode(value: string);
    get enforcementModeInput(): string | undefined;
    private _cloudControlDetails;
    get cloudControlDetails(): CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetailsOutputReference;
    putCloudControlDetails(value: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetails): void;
    get cloudControlDetailsInput(): CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataCloudControlDetails | undefined;
}
export declare class CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataList extends cdktn.ComplexList {
    internalValue?: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadata[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataOutputReference;
}
export interface CloudSecurityComplianceFrameworkDeploymentFramework {
    /**
    * In the format:
    * {parent}/locations/{location}/frameworks/{framework}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#framework CloudSecurityComplianceFrameworkDeployment#framework}
    */
    readonly framework: string;
    /**
    * Major revision id of the framework.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#major_revision_id CloudSecurityComplianceFrameworkDeployment#major_revision_id}
    */
    readonly majorRevisionId: string;
}
export declare function cloudSecurityComplianceFrameworkDeploymentFrameworkToTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentFrameworkOutputReference | CloudSecurityComplianceFrameworkDeploymentFramework): any;
export declare function cloudSecurityComplianceFrameworkDeploymentFrameworkToHclTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentFrameworkOutputReference | CloudSecurityComplianceFrameworkDeploymentFramework): any;
export declare class CloudSecurityComplianceFrameworkDeploymentFrameworkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudSecurityComplianceFrameworkDeploymentFramework | undefined;
    set internalValue(value: CloudSecurityComplianceFrameworkDeploymentFramework | undefined);
    private _framework?;
    get framework(): string;
    set framework(value: string);
    get frameworkInput(): string | undefined;
    private _majorRevisionId?;
    get majorRevisionId(): string;
    set majorRevisionId(value: string);
    get majorRevisionIdInput(): string | undefined;
}
export interface CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigFolderCreationConfig {
    /**
    * Display name of the folder to be created
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#folder_display_name CloudSecurityComplianceFrameworkDeployment#folder_display_name}
    */
    readonly folderDisplayName: string;
    /**
    * The parent of the folder to be created. It can be an organizations/{org} or
    * folders/{folder}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#parent CloudSecurityComplianceFrameworkDeployment#parent}
    */
    readonly parent: string;
}
export declare function cloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigFolderCreationConfigToTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigFolderCreationConfigOutputReference | CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigFolderCreationConfig): any;
export declare function cloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigFolderCreationConfigToHclTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigFolderCreationConfigOutputReference | CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigFolderCreationConfig): any;
export declare class CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigFolderCreationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigFolderCreationConfig | undefined;
    set internalValue(value: CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigFolderCreationConfig | undefined);
    private _folderDisplayName?;
    get folderDisplayName(): string;
    set folderDisplayName(value: string);
    get folderDisplayNameInput(): string | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
}
export interface CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigProjectCreationConfig {
    /**
    * Billing account id to be used for the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#billing_account_id CloudSecurityComplianceFrameworkDeployment#billing_account_id}
    */
    readonly billingAccountId: string;
    /**
    * organizations/{org} or folders/{folder}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#parent CloudSecurityComplianceFrameworkDeployment#parent}
    */
    readonly parent: string;
    /**
    * Display name of the project to be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#project_display_name CloudSecurityComplianceFrameworkDeployment#project_display_name}
    */
    readonly projectDisplayName: string;
}
export declare function cloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigProjectCreationConfigToTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigProjectCreationConfigOutputReference | CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigProjectCreationConfig): any;
export declare function cloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigProjectCreationConfigToHclTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigProjectCreationConfigOutputReference | CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigProjectCreationConfig): any;
export declare class CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigProjectCreationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigProjectCreationConfig | undefined;
    set internalValue(value: CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigProjectCreationConfig | undefined);
    private _billingAccountId?;
    get billingAccountId(): string;
    set billingAccountId(value: string);
    get billingAccountIdInput(): string | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _projectDisplayName?;
    get projectDisplayName(): string;
    set projectDisplayName(value: string);
    get projectDisplayNameInput(): string | undefined;
}
export interface CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfig {
    /**
    * folder_creation_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#folder_creation_config CloudSecurityComplianceFrameworkDeployment#folder_creation_config}
    */
    readonly folderCreationConfig?: CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigFolderCreationConfig;
    /**
    * project_creation_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#project_creation_config CloudSecurityComplianceFrameworkDeployment#project_creation_config}
    */
    readonly projectCreationConfig?: CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigProjectCreationConfig;
}
export declare function cloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigToTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigOutputReference | CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfig): any;
export declare function cloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigToHclTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigOutputReference | CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfig): any;
export declare class CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfig | undefined;
    set internalValue(value: CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfig | undefined);
    private _folderCreationConfig;
    get folderCreationConfig(): CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigFolderCreationConfigOutputReference;
    putFolderCreationConfig(value: CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigFolderCreationConfig): void;
    resetFolderCreationConfig(): void;
    get folderCreationConfigInput(): CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigFolderCreationConfig | undefined;
    private _projectCreationConfig;
    get projectCreationConfig(): CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigProjectCreationConfigOutputReference;
    putProjectCreationConfig(value: CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigProjectCreationConfig): void;
    resetProjectCreationConfig(): void;
    get projectCreationConfigInput(): CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigProjectCreationConfig | undefined;
}
export interface CloudSecurityComplianceFrameworkDeploymentTargetResourceConfig {
    /**
    * CRM node in format organizations/{organization}, folders/{folder},
    * or projects/{project}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#existing_target_resource CloudSecurityComplianceFrameworkDeployment#existing_target_resource}
    */
    readonly existingTargetResource?: string;
    /**
    * target_resource_creation_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#target_resource_creation_config CloudSecurityComplianceFrameworkDeployment#target_resource_creation_config}
    */
    readonly targetResourceCreationConfig?: CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfig;
}
export declare function cloudSecurityComplianceFrameworkDeploymentTargetResourceConfigToTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigOutputReference | CloudSecurityComplianceFrameworkDeploymentTargetResourceConfig): any;
export declare function cloudSecurityComplianceFrameworkDeploymentTargetResourceConfigToHclTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigOutputReference | CloudSecurityComplianceFrameworkDeploymentTargetResourceConfig): any;
export declare class CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudSecurityComplianceFrameworkDeploymentTargetResourceConfig | undefined;
    set internalValue(value: CloudSecurityComplianceFrameworkDeploymentTargetResourceConfig | undefined);
    private _existingTargetResource?;
    get existingTargetResource(): string;
    set existingTargetResource(value: string);
    resetExistingTargetResource(): void;
    get existingTargetResourceInput(): string | undefined;
    private _targetResourceCreationConfig;
    get targetResourceCreationConfig(): CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfigOutputReference;
    putTargetResourceCreationConfig(value: CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfig): void;
    resetTargetResourceCreationConfig(): void;
    get targetResourceCreationConfigInput(): CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigTargetResourceCreationConfig | undefined;
}
export interface CloudSecurityComplianceFrameworkDeploymentTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#create CloudSecurityComplianceFrameworkDeployment#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#delete CloudSecurityComplianceFrameworkDeployment#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#update CloudSecurityComplianceFrameworkDeployment#update}
    */
    readonly update?: string;
}
export declare function cloudSecurityComplianceFrameworkDeploymentTimeoutsToTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentTimeouts | cdktn.IResolvable): any;
export declare function cloudSecurityComplianceFrameworkDeploymentTimeoutsToHclTerraform(struct?: CloudSecurityComplianceFrameworkDeploymentTimeouts | cdktn.IResolvable): any;
export declare class CloudSecurityComplianceFrameworkDeploymentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudSecurityComplianceFrameworkDeploymentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CloudSecurityComplianceFrameworkDeploymentTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment google_cloud_security_compliance_framework_deployment}
*/
export declare class CloudSecurityComplianceFrameworkDeployment extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_cloud_security_compliance_framework_deployment";
    /**
    * Generates CDKTN code for importing a CloudSecurityComplianceFrameworkDeployment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudSecurityComplianceFrameworkDeployment to import
    * @param importFromId The id of the existing CloudSecurityComplianceFrameworkDeployment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudSecurityComplianceFrameworkDeployment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/cloud_security_compliance_framework_deployment google_cloud_security_compliance_framework_deployment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudSecurityComplianceFrameworkDeploymentConfig
    */
    constructor(scope: Construct, id: string, config: CloudSecurityComplianceFrameworkDeploymentConfig);
    private _cloudControlDeploymentReferences;
    get cloudControlDeploymentReferences(): CloudSecurityComplianceFrameworkDeploymentCloudControlDeploymentReferencesList;
    get computedTargetResource(): string;
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    get deploymentState(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get etag(): string;
    private _frameworkDeploymentId?;
    get frameworkDeploymentId(): string;
    set frameworkDeploymentId(value: string);
    get frameworkDeploymentIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    get name(): string;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    resetParent(): void;
    get parentInput(): string | undefined;
    get targetResourceDisplayName(): string;
    get updateTime(): string;
    private _cloudControlMetadata;
    get cloudControlMetadata(): CloudSecurityComplianceFrameworkDeploymentCloudControlMetadataList;
    putCloudControlMetadata(value: CloudSecurityComplianceFrameworkDeploymentCloudControlMetadata[] | cdktn.IResolvable): void;
    get cloudControlMetadataInput(): cdktn.IResolvable | CloudSecurityComplianceFrameworkDeploymentCloudControlMetadata[] | undefined;
    private _framework;
    get framework(): CloudSecurityComplianceFrameworkDeploymentFrameworkOutputReference;
    putFramework(value: CloudSecurityComplianceFrameworkDeploymentFramework): void;
    get frameworkInput(): CloudSecurityComplianceFrameworkDeploymentFramework | undefined;
    private _targetResourceConfig;
    get targetResourceConfig(): CloudSecurityComplianceFrameworkDeploymentTargetResourceConfigOutputReference;
    putTargetResourceConfig(value: CloudSecurityComplianceFrameworkDeploymentTargetResourceConfig): void;
    get targetResourceConfigInput(): CloudSecurityComplianceFrameworkDeploymentTargetResourceConfig | undefined;
    private _timeouts;
    get timeouts(): CloudSecurityComplianceFrameworkDeploymentTimeoutsOutputReference;
    putTimeouts(value: CloudSecurityComplianceFrameworkDeploymentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CloudSecurityComplianceFrameworkDeploymentTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
