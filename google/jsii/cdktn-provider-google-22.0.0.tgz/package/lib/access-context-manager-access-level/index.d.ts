/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccessContextManagerAccessLevelConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#deletion_policy AccessContextManagerAccessLevel#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Description of the AccessLevel and its use. Does not affect behavior.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#description AccessContextManagerAccessLevel#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#id AccessContextManagerAccessLevel#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource name for the Access Level. The short_name component must begin
    * with a letter and only include alphanumeric and '_'.
    * Format: accessPolicies/{policy_id}/accessLevels/{short_name}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#name AccessContextManagerAccessLevel#name}
    */
    readonly name: string;
    /**
    * The AccessPolicy this AccessLevel lives in.
    * Format: accessPolicies/{policy_id}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#parent AccessContextManagerAccessLevel#parent}
    */
    readonly parent: string;
    /**
    * Human readable title. Must be unique within the Policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#title AccessContextManagerAccessLevel#title}
    */
    readonly title: string;
    /**
    * basic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#basic AccessContextManagerAccessLevel#basic}
    */
    readonly basic?: AccessContextManagerAccessLevelBasic;
    /**
    * custom block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#custom AccessContextManagerAccessLevel#custom}
    */
    readonly custom?: AccessContextManagerAccessLevelCustom;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#timeouts AccessContextManagerAccessLevel#timeouts}
    */
    readonly timeouts?: AccessContextManagerAccessLevelTimeouts;
}
export interface AccessContextManagerAccessLevelBasicConditionsDevicePolicyOsConstraints {
    /**
    * The minimum allowed OS version. If not set, any version
    * of this OS satisfies the constraint.
    * Format: "major.minor.patch" such as "10.5.301", "9.2.1".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#minimum_version AccessContextManagerAccessLevel#minimum_version}
    */
    readonly minimumVersion?: string;
    /**
    * The operating system type of the device. Possible values: ["OS_UNSPECIFIED", "DESKTOP_MAC", "DESKTOP_WINDOWS", "DESKTOP_LINUX", "DESKTOP_CHROME_OS", "ANDROID", "IOS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#os_type AccessContextManagerAccessLevel#os_type}
    */
    readonly osType: string;
    /**
    * If you specify DESKTOP_CHROME_OS for osType, you can optionally include requireVerifiedChromeOs to require Chrome Verified Access.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#require_verified_chrome_os AccessContextManagerAccessLevel#require_verified_chrome_os}
    */
    readonly requireVerifiedChromeOs?: boolean | cdktn.IResolvable;
}
export declare function accessContextManagerAccessLevelBasicConditionsDevicePolicyOsConstraintsToTerraform(struct?: AccessContextManagerAccessLevelBasicConditionsDevicePolicyOsConstraints | cdktn.IResolvable): any;
export declare function accessContextManagerAccessLevelBasicConditionsDevicePolicyOsConstraintsToHclTerraform(struct?: AccessContextManagerAccessLevelBasicConditionsDevicePolicyOsConstraints | cdktn.IResolvable): any;
export declare class AccessContextManagerAccessLevelBasicConditionsDevicePolicyOsConstraintsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerAccessLevelBasicConditionsDevicePolicyOsConstraints | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerAccessLevelBasicConditionsDevicePolicyOsConstraints | cdktn.IResolvable | undefined);
    private _minimumVersion?;
    get minimumVersion(): string;
    set minimumVersion(value: string);
    resetMinimumVersion(): void;
    get minimumVersionInput(): string | undefined;
    private _osType?;
    get osType(): string;
    set osType(value: string);
    get osTypeInput(): string | undefined;
    private _requireVerifiedChromeOs?;
    get requireVerifiedChromeOs(): boolean | cdktn.IResolvable;
    set requireVerifiedChromeOs(value: boolean | cdktn.IResolvable);
    resetRequireVerifiedChromeOs(): void;
    get requireVerifiedChromeOsInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class AccessContextManagerAccessLevelBasicConditionsDevicePolicyOsConstraintsList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerAccessLevelBasicConditionsDevicePolicyOsConstraints[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerAccessLevelBasicConditionsDevicePolicyOsConstraintsOutputReference;
}
export interface AccessContextManagerAccessLevelBasicConditionsDevicePolicy {
    /**
    * A list of allowed device management levels.
    * An empty list allows all management levels. Possible values: ["MANAGEMENT_UNSPECIFIED", "NONE", "BASIC", "COMPLETE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#allowed_device_management_levels AccessContextManagerAccessLevel#allowed_device_management_levels}
    */
    readonly allowedDeviceManagementLevels?: string[];
    /**
    * A list of allowed encryptions statuses.
    * An empty list allows all statuses. Possible values: ["ENCRYPTION_UNSPECIFIED", "ENCRYPTION_UNSUPPORTED", "UNENCRYPTED", "ENCRYPTED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#allowed_encryption_statuses AccessContextManagerAccessLevel#allowed_encryption_statuses}
    */
    readonly allowedEncryptionStatuses?: string[];
    /**
    * Whether the device needs to be approved by the customer admin.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#require_admin_approval AccessContextManagerAccessLevel#require_admin_approval}
    */
    readonly requireAdminApproval?: boolean | cdktn.IResolvable;
    /**
    * Whether the device needs to be corp owned.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#require_corp_owned AccessContextManagerAccessLevel#require_corp_owned}
    */
    readonly requireCorpOwned?: boolean | cdktn.IResolvable;
    /**
    * Whether or not screenlock is required for the DevicePolicy
    * to be true. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#require_screen_lock AccessContextManagerAccessLevel#require_screen_lock}
    */
    readonly requireScreenLock?: boolean | cdktn.IResolvable;
    /**
    * os_constraints block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#os_constraints AccessContextManagerAccessLevel#os_constraints}
    */
    readonly osConstraints?: AccessContextManagerAccessLevelBasicConditionsDevicePolicyOsConstraints[] | cdktn.IResolvable;
}
export declare function accessContextManagerAccessLevelBasicConditionsDevicePolicyToTerraform(struct?: AccessContextManagerAccessLevelBasicConditionsDevicePolicyOutputReference | AccessContextManagerAccessLevelBasicConditionsDevicePolicy): any;
export declare function accessContextManagerAccessLevelBasicConditionsDevicePolicyToHclTerraform(struct?: AccessContextManagerAccessLevelBasicConditionsDevicePolicyOutputReference | AccessContextManagerAccessLevelBasicConditionsDevicePolicy): any;
export declare class AccessContextManagerAccessLevelBasicConditionsDevicePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerAccessLevelBasicConditionsDevicePolicy | undefined;
    set internalValue(value: AccessContextManagerAccessLevelBasicConditionsDevicePolicy | undefined);
    private _allowedDeviceManagementLevels?;
    get allowedDeviceManagementLevels(): string[];
    set allowedDeviceManagementLevels(value: string[]);
    resetAllowedDeviceManagementLevels(): void;
    get allowedDeviceManagementLevelsInput(): string[] | undefined;
    private _allowedEncryptionStatuses?;
    get allowedEncryptionStatuses(): string[];
    set allowedEncryptionStatuses(value: string[]);
    resetAllowedEncryptionStatuses(): void;
    get allowedEncryptionStatusesInput(): string[] | undefined;
    private _requireAdminApproval?;
    get requireAdminApproval(): boolean | cdktn.IResolvable;
    set requireAdminApproval(value: boolean | cdktn.IResolvable);
    resetRequireAdminApproval(): void;
    get requireAdminApprovalInput(): boolean | cdktn.IResolvable | undefined;
    private _requireCorpOwned?;
    get requireCorpOwned(): boolean | cdktn.IResolvable;
    set requireCorpOwned(value: boolean | cdktn.IResolvable);
    resetRequireCorpOwned(): void;
    get requireCorpOwnedInput(): boolean | cdktn.IResolvable | undefined;
    private _requireScreenLock?;
    get requireScreenLock(): boolean | cdktn.IResolvable;
    set requireScreenLock(value: boolean | cdktn.IResolvable);
    resetRequireScreenLock(): void;
    get requireScreenLockInput(): boolean | cdktn.IResolvable | undefined;
    private _osConstraints;
    get osConstraints(): AccessContextManagerAccessLevelBasicConditionsDevicePolicyOsConstraintsList;
    putOsConstraints(value: AccessContextManagerAccessLevelBasicConditionsDevicePolicyOsConstraints[] | cdktn.IResolvable): void;
    resetOsConstraints(): void;
    get osConstraintsInput(): cdktn.IResolvable | AccessContextManagerAccessLevelBasicConditionsDevicePolicyOsConstraints[] | undefined;
}
export interface AccessContextManagerAccessLevelBasicConditionsVpcNetworkSourcesVpcSubnetwork {
    /**
    * Required. Network name to be allowed by this Access Level. Networks of foreign organizations requires 'compute.network.get' permission to be granted to caller.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#network AccessContextManagerAccessLevel#network}
    */
    readonly network: string;
    /**
    * A list of CIDR block IP subnetwork specification. Must be IPv4.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#vpc_ip_subnetworks AccessContextManagerAccessLevel#vpc_ip_subnetworks}
    */
    readonly vpcIpSubnetworks?: string[];
}
export declare function accessContextManagerAccessLevelBasicConditionsVpcNetworkSourcesVpcSubnetworkToTerraform(struct?: AccessContextManagerAccessLevelBasicConditionsVpcNetworkSourcesVpcSubnetworkOutputReference | AccessContextManagerAccessLevelBasicConditionsVpcNetworkSourcesVpcSubnetwork): any;
export declare function accessContextManagerAccessLevelBasicConditionsVpcNetworkSourcesVpcSubnetworkToHclTerraform(struct?: AccessContextManagerAccessLevelBasicConditionsVpcNetworkSourcesVpcSubnetworkOutputReference | AccessContextManagerAccessLevelBasicConditionsVpcNetworkSourcesVpcSubnetwork): any;
export declare class AccessContextManagerAccessLevelBasicConditionsVpcNetworkSourcesVpcSubnetworkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerAccessLevelBasicConditionsVpcNetworkSourcesVpcSubnetwork | undefined;
    set internalValue(value: AccessContextManagerAccessLevelBasicConditionsVpcNetworkSourcesVpcSubnetwork | undefined);
    private _network?;
    get network(): string;
    set network(value: string);
    get networkInput(): string | undefined;
    private _vpcIpSubnetworks?;
    get vpcIpSubnetworks(): string[];
    set vpcIpSubnetworks(value: string[]);
    resetVpcIpSubnetworks(): void;
    get vpcIpSubnetworksInput(): string[] | undefined;
}
export interface AccessContextManagerAccessLevelBasicConditionsVpcNetworkSources {
    /**
    * vpc_subnetwork block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#vpc_subnetwork AccessContextManagerAccessLevel#vpc_subnetwork}
    */
    readonly vpcSubnetwork?: AccessContextManagerAccessLevelBasicConditionsVpcNetworkSourcesVpcSubnetwork;
}
export declare function accessContextManagerAccessLevelBasicConditionsVpcNetworkSourcesToTerraform(struct?: AccessContextManagerAccessLevelBasicConditionsVpcNetworkSources | cdktn.IResolvable): any;
export declare function accessContextManagerAccessLevelBasicConditionsVpcNetworkSourcesToHclTerraform(struct?: AccessContextManagerAccessLevelBasicConditionsVpcNetworkSources | cdktn.IResolvable): any;
export declare class AccessContextManagerAccessLevelBasicConditionsVpcNetworkSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerAccessLevelBasicConditionsVpcNetworkSources | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerAccessLevelBasicConditionsVpcNetworkSources | cdktn.IResolvable | undefined);
    private _vpcSubnetwork;
    get vpcSubnetwork(): AccessContextManagerAccessLevelBasicConditionsVpcNetworkSourcesVpcSubnetworkOutputReference;
    putVpcSubnetwork(value: AccessContextManagerAccessLevelBasicConditionsVpcNetworkSourcesVpcSubnetwork): void;
    resetVpcSubnetwork(): void;
    get vpcSubnetworkInput(): AccessContextManagerAccessLevelBasicConditionsVpcNetworkSourcesVpcSubnetwork | undefined;
}
export declare class AccessContextManagerAccessLevelBasicConditionsVpcNetworkSourcesList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerAccessLevelBasicConditionsVpcNetworkSources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerAccessLevelBasicConditionsVpcNetworkSourcesOutputReference;
}
export interface AccessContextManagerAccessLevelBasicConditions {
    /**
    * A list of CIDR block IP subnetwork specification. May be IPv4
    * or IPv6.
    * Note that for a CIDR IP address block, the specified IP address
    * portion must be properly truncated (i.e. all the host bits must
    * be zero) or the input is considered malformed. For example,
    * "192.0.2.0/24" is accepted but "192.0.2.1/24" is not. Similarly,
    * for IPv6, "2001:db8::/32" is accepted whereas "2001:db8::1/32"
    * is not. The originating IP of a request must be in one of the
    * listed subnets in order for this Condition to be true.
    * If empty, all IP addresses are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#ip_subnetworks AccessContextManagerAccessLevel#ip_subnetworks}
    */
    readonly ipSubnetworks?: string[];
    /**
    * An allowed list of members (users, service accounts).
    * Using groups is not supported yet.
    *
    * The signed-in user originating the request must be a part of one
    * of the provided members. If not specified, a request may come
    * from any user (logged in/not logged in, not present in any
    * groups, etc.).
    * Formats: 'user:{emailid}', 'serviceAccount:{emailid}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#members AccessContextManagerAccessLevel#members}
    */
    readonly members?: string[];
    /**
    * Whether to negate the Condition. If true, the Condition becomes
    * a NAND over its non-empty fields, each field must be false for
    * the Condition overall to be satisfied. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#negate AccessContextManagerAccessLevel#negate}
    */
    readonly negate?: boolean | cdktn.IResolvable;
    /**
    * The request must originate from one of the provided
    * countries/regions.
    * Format: A valid ISO 3166-1 alpha-2 code.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#regions AccessContextManagerAccessLevel#regions}
    */
    readonly regions?: string[];
    /**
    * A list of other access levels defined in the same Policy,
    * referenced by resource name. Referencing an AccessLevel which
    * does not exist is an error. All access levels listed must be
    * granted for the Condition to be true.
    * Format: accessPolicies/{policy_id}/accessLevels/{short_name}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#required_access_levels AccessContextManagerAccessLevel#required_access_levels}
    */
    readonly requiredAccessLevels?: string[];
    /**
    * device_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#device_policy AccessContextManagerAccessLevel#device_policy}
    */
    readonly devicePolicy?: AccessContextManagerAccessLevelBasicConditionsDevicePolicy;
    /**
    * vpc_network_sources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#vpc_network_sources AccessContextManagerAccessLevel#vpc_network_sources}
    */
    readonly vpcNetworkSources?: AccessContextManagerAccessLevelBasicConditionsVpcNetworkSources[] | cdktn.IResolvable;
}
export declare function accessContextManagerAccessLevelBasicConditionsToTerraform(struct?: AccessContextManagerAccessLevelBasicConditions | cdktn.IResolvable): any;
export declare function accessContextManagerAccessLevelBasicConditionsToHclTerraform(struct?: AccessContextManagerAccessLevelBasicConditions | cdktn.IResolvable): any;
export declare class AccessContextManagerAccessLevelBasicConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerAccessLevelBasicConditions | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerAccessLevelBasicConditions | cdktn.IResolvable | undefined);
    private _ipSubnetworks?;
    get ipSubnetworks(): string[];
    set ipSubnetworks(value: string[]);
    resetIpSubnetworks(): void;
    get ipSubnetworksInput(): string[] | undefined;
    private _members?;
    get members(): string[];
    set members(value: string[]);
    resetMembers(): void;
    get membersInput(): string[] | undefined;
    private _negate?;
    get negate(): boolean | cdktn.IResolvable;
    set negate(value: boolean | cdktn.IResolvable);
    resetNegate(): void;
    get negateInput(): boolean | cdktn.IResolvable | undefined;
    private _regions?;
    get regions(): string[];
    set regions(value: string[]);
    resetRegions(): void;
    get regionsInput(): string[] | undefined;
    private _requiredAccessLevels?;
    get requiredAccessLevels(): string[];
    set requiredAccessLevels(value: string[]);
    resetRequiredAccessLevels(): void;
    get requiredAccessLevelsInput(): string[] | undefined;
    private _devicePolicy;
    get devicePolicy(): AccessContextManagerAccessLevelBasicConditionsDevicePolicyOutputReference;
    putDevicePolicy(value: AccessContextManagerAccessLevelBasicConditionsDevicePolicy): void;
    resetDevicePolicy(): void;
    get devicePolicyInput(): AccessContextManagerAccessLevelBasicConditionsDevicePolicy | undefined;
    private _vpcNetworkSources;
    get vpcNetworkSources(): AccessContextManagerAccessLevelBasicConditionsVpcNetworkSourcesList;
    putVpcNetworkSources(value: AccessContextManagerAccessLevelBasicConditionsVpcNetworkSources[] | cdktn.IResolvable): void;
    resetVpcNetworkSources(): void;
    get vpcNetworkSourcesInput(): cdktn.IResolvable | AccessContextManagerAccessLevelBasicConditionsVpcNetworkSources[] | undefined;
}
export declare class AccessContextManagerAccessLevelBasicConditionsList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerAccessLevelBasicConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerAccessLevelBasicConditionsOutputReference;
}
export interface AccessContextManagerAccessLevelBasic {
    /**
    * How the conditions list should be combined to determine if a request
    * is granted this AccessLevel. If AND is used, each Condition in
    * conditions must be satisfied for the AccessLevel to be applied. If
    * OR is used, at least one Condition in conditions must be satisfied
    * for the AccessLevel to be applied. Default value: "AND" Possible values: ["AND", "OR"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#combining_function AccessContextManagerAccessLevel#combining_function}
    */
    readonly combiningFunction?: string;
    /**
    * conditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#conditions AccessContextManagerAccessLevel#conditions}
    */
    readonly conditions: AccessContextManagerAccessLevelBasicConditions[] | cdktn.IResolvable;
}
export declare function accessContextManagerAccessLevelBasicToTerraform(struct?: AccessContextManagerAccessLevelBasicOutputReference | AccessContextManagerAccessLevelBasic): any;
export declare function accessContextManagerAccessLevelBasicToHclTerraform(struct?: AccessContextManagerAccessLevelBasicOutputReference | AccessContextManagerAccessLevelBasic): any;
export declare class AccessContextManagerAccessLevelBasicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerAccessLevelBasic | undefined;
    set internalValue(value: AccessContextManagerAccessLevelBasic | undefined);
    private _combiningFunction?;
    get combiningFunction(): string;
    set combiningFunction(value: string);
    resetCombiningFunction(): void;
    get combiningFunctionInput(): string | undefined;
    private _conditions;
    get conditions(): AccessContextManagerAccessLevelBasicConditionsList;
    putConditions(value: AccessContextManagerAccessLevelBasicConditions[] | cdktn.IResolvable): void;
    get conditionsInput(): cdktn.IResolvable | AccessContextManagerAccessLevelBasicConditions[] | undefined;
}
export interface AccessContextManagerAccessLevelCustomExpr {
    /**
    * Description of the expression
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#description AccessContextManagerAccessLevel#description}
    */
    readonly description?: string;
    /**
    * Textual representation of an expression in Common Expression Language syntax.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#expression AccessContextManagerAccessLevel#expression}
    */
    readonly expression: string;
    /**
    * String indicating the location of the expression for error reporting, e.g. a file name and a position in the file
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#location AccessContextManagerAccessLevel#location}
    */
    readonly location?: string;
    /**
    * Title for the expression, i.e. a short string describing its purpose.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#title AccessContextManagerAccessLevel#title}
    */
    readonly title?: string;
}
export declare function accessContextManagerAccessLevelCustomExprToTerraform(struct?: AccessContextManagerAccessLevelCustomExprOutputReference | AccessContextManagerAccessLevelCustomExpr): any;
export declare function accessContextManagerAccessLevelCustomExprToHclTerraform(struct?: AccessContextManagerAccessLevelCustomExprOutputReference | AccessContextManagerAccessLevelCustomExpr): any;
export declare class AccessContextManagerAccessLevelCustomExprOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerAccessLevelCustomExpr | undefined;
    set internalValue(value: AccessContextManagerAccessLevelCustomExpr | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
}
export interface AccessContextManagerAccessLevelCustom {
    /**
    * expr block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#expr AccessContextManagerAccessLevel#expr}
    */
    readonly expr: AccessContextManagerAccessLevelCustomExpr;
}
export declare function accessContextManagerAccessLevelCustomToTerraform(struct?: AccessContextManagerAccessLevelCustomOutputReference | AccessContextManagerAccessLevelCustom): any;
export declare function accessContextManagerAccessLevelCustomToHclTerraform(struct?: AccessContextManagerAccessLevelCustomOutputReference | AccessContextManagerAccessLevelCustom): any;
export declare class AccessContextManagerAccessLevelCustomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerAccessLevelCustom | undefined;
    set internalValue(value: AccessContextManagerAccessLevelCustom | undefined);
    private _expr;
    get expr(): AccessContextManagerAccessLevelCustomExprOutputReference;
    putExpr(value: AccessContextManagerAccessLevelCustomExpr): void;
    get exprInput(): AccessContextManagerAccessLevelCustomExpr | undefined;
}
export interface AccessContextManagerAccessLevelTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#create AccessContextManagerAccessLevel#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#delete AccessContextManagerAccessLevel#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#update AccessContextManagerAccessLevel#update}
    */
    readonly update?: string;
}
export declare function accessContextManagerAccessLevelTimeoutsToTerraform(struct?: AccessContextManagerAccessLevelTimeouts | cdktn.IResolvable): any;
export declare function accessContextManagerAccessLevelTimeoutsToHclTerraform(struct?: AccessContextManagerAccessLevelTimeouts | cdktn.IResolvable): any;
export declare class AccessContextManagerAccessLevelTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerAccessLevelTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerAccessLevelTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level google_access_context_manager_access_level}
*/
export declare class AccessContextManagerAccessLevel extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_access_context_manager_access_level";
    /**
    * Generates CDKTN code for importing a AccessContextManagerAccessLevel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessContextManagerAccessLevel to import
    * @param importFromId The id of the existing AccessContextManagerAccessLevel that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessContextManagerAccessLevel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/access_context_manager_access_level google_access_context_manager_access_level} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessContextManagerAccessLevelConfig
    */
    constructor(scope: Construct, id: string, config: AccessContextManagerAccessLevelConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    private _basic;
    get basic(): AccessContextManagerAccessLevelBasicOutputReference;
    putBasic(value: AccessContextManagerAccessLevelBasic): void;
    resetBasic(): void;
    get basicInput(): AccessContextManagerAccessLevelBasic | undefined;
    private _custom;
    get custom(): AccessContextManagerAccessLevelCustomOutputReference;
    putCustom(value: AccessContextManagerAccessLevelCustom): void;
    resetCustom(): void;
    get customInput(): AccessContextManagerAccessLevelCustom | undefined;
    private _timeouts;
    get timeouts(): AccessContextManagerAccessLevelTimeoutsOutputReference;
    putTimeouts(value: AccessContextManagerAccessLevelTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): AccessContextManagerAccessLevelTimeouts | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
