/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeRouterNatConfig extends cdktn.TerraformMetaArguments {
    /**
    * The network tier to use when automatically reserving NAT IP addresses.
    * Must be one of: PREMIUM, STANDARD. If not specified, then the current
    * project-level default tier is used. Possible values: ["PREMIUM", "STANDARD"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#auto_network_tier ComputeRouterNat#auto_network_tier}
    */
    readonly autoNetworkTier?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#deletion_policy ComputeRouterNat#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * A list of URLs of the IP resources to be drained. These IPs must be
    * valid static external IPs that have been assigned to the NAT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#drain_nat_ips ComputeRouterNat#drain_nat_ips}
    */
    readonly drainNatIps?: string[];
    /**
    * Enable Dynamic Port Allocation.
    * If minPortsPerVm is set, minPortsPerVm must be set to a power of two greater than or equal to 32.
    * If minPortsPerVm is not set, a minimum of 32 ports will be allocated to a VM from this NAT config.
    * If maxPortsPerVm is set, maxPortsPerVm must be set to a power of two greater than minPortsPerVm.
    * If maxPortsPerVm is not set, a maximum of 65536 ports will be allocated to a VM from this NAT config.
    *
    * Mutually exclusive with enableEndpointIndependentMapping.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#enable_dynamic_port_allocation ComputeRouterNat#enable_dynamic_port_allocation}
    */
    readonly enableDynamicPortAllocation?: boolean | cdktn.IResolvable;
    /**
    * Enable endpoint independent mapping.
    * For more information see the [official documentation](https://docs.cloud.google.com/nat/docs/public-nat#specs-rfcs).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#enable_endpoint_independent_mapping ComputeRouterNat#enable_endpoint_independent_mapping}
    */
    readonly enableEndpointIndependentMapping?: boolean | cdktn.IResolvable;
    /**
    * Specifies the endpoint Types supported by the NAT Gateway.
    * Supported values include:
    *       'ENDPOINT_TYPE_VM', 'ENDPOINT_TYPE_SWG',
    *       'ENDPOINT_TYPE_MANAGED_PROXY_LB'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#endpoint_types ComputeRouterNat#endpoint_types}
    */
    readonly endpointTypes?: string[];
    /**
    * Timeout (in seconds) for ICMP connections. Defaults to 30s if not set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#icmp_idle_timeout_sec ComputeRouterNat#icmp_idle_timeout_sec}
    */
    readonly icmpIdleTimeoutSec?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#id ComputeRouterNat#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Self-links of NAT IPs to be used as initial value for creation alongside a RouterNatAddress resource.
    * Conflicts with natIps and drainNatIps. Only valid if natIpAllocateOption is set to MANUAL_ONLY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#initial_nat_ips ComputeRouterNat#initial_nat_ips}
    */
    readonly initialNatIps?: string[];
    /**
    * Maximum number of ports allocated to a VM from this NAT.
    * This field can only be set when enableDynamicPortAllocation is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#max_ports_per_vm ComputeRouterNat#max_ports_per_vm}
    */
    readonly maxPortsPerVm?: number;
    /**
    * Minimum number of ports allocated to a VM from this NAT. Defaults to 64 for static port allocation and 32 dynamic port allocation if not set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#min_ports_per_vm ComputeRouterNat#min_ports_per_vm}
    */
    readonly minPortsPerVm?: number;
    /**
    * Name of the NAT service. The name must be 1-63 characters long and
    * comply with RFC1035.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#name ComputeRouterNat#name}
    */
    readonly name: string;
    /**
    * How external IPs should be allocated for this NAT. Valid values are
    * 'AUTO_ONLY' for only allowing NAT IPs allocated by Google Cloud
    * Platform, or 'MANUAL_ONLY' for only user-allocated NAT IP addresses. Possible values: ["MANUAL_ONLY", "AUTO_ONLY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#nat_ip_allocate_option ComputeRouterNat#nat_ip_allocate_option}
    */
    readonly natIpAllocateOption?: string;
    /**
    * Self-links of NAT IPs. Only valid if natIpAllocateOption
    * is set to MANUAL_ONLY.
    * If this field is used alongside with a count created list of address resources 'google_compute_address.foobar.*.self_link',
    * the access level resource for the address resource must have a 'lifecycle' block with 'create_before_destroy = true' so
    * the number of resources can be increased/decreased without triggering the 'resourceInUseByAnotherResource' error.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#nat_ips ComputeRouterNat#nat_ips}
    */
    readonly natIps?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#project ComputeRouterNat#project}
    */
    readonly project?: string;
    /**
    * Region where the router and NAT reside.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#region ComputeRouterNat#region}
    */
    readonly region?: string;
    /**
    * The name of the Cloud Router in which this NAT will be configured.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#router ComputeRouterNat#router}
    */
    readonly router: string;
    /**
    * How NAT should be configured per Subnetwork.
    * If 'ALL_SUBNETWORKS_ALL_IP_RANGES', all of the
    * IP ranges in every Subnetwork are allowed to Nat.
    * If 'ALL_SUBNETWORKS_ALL_PRIMARY_IP_RANGES', all of the primary IP
    * ranges in every Subnetwork are allowed to Nat.
    * 'LIST_OF_SUBNETWORKS': A list of Subnetworks are allowed to Nat
    * (specified in the field subnetwork below). Note that if this field
    * contains ALL_SUBNETWORKS_ALL_IP_RANGES or
    * ALL_SUBNETWORKS_ALL_PRIMARY_IP_RANGES, then there should not be any
    * other RouterNat section in any Router for this network in this region. Possible values: ["ALL_SUBNETWORKS_ALL_IP_RANGES", "ALL_SUBNETWORKS_ALL_PRIMARY_IP_RANGES", "LIST_OF_SUBNETWORKS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#source_subnetwork_ip_ranges_to_nat ComputeRouterNat#source_subnetwork_ip_ranges_to_nat}
    */
    readonly sourceSubnetworkIpRangesToNat: string;
    /**
    * Specify the Nat option for NAT64, which can take one of the following values:
    * ALL_IPV6_SUBNETWORKS: All of the IP ranges in every Subnetwork are allowed to Nat.
    * LIST_OF_IPV6_SUBNETWORKS: A list of Subnetworks are allowed to Nat (specified in the field nat64Subnetwork below).
    * Note that if this field contains NAT64_ALL_V6_SUBNETWORKS no other Router.Nat section in this region can also enable NAT64 for any Subnetworks in this network.
    * Other Router.Nat sections can still be present to enable NAT44 only. Possible values: ["ALL_IPV6_SUBNETWORKS", "LIST_OF_IPV6_SUBNETWORKS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#source_subnetwork_ip_ranges_to_nat64 ComputeRouterNat#source_subnetwork_ip_ranges_to_nat64}
    */
    readonly sourceSubnetworkIpRangesToNat64?: string;
    /**
    * Timeout (in seconds) for TCP established connections.
    * Defaults to 1200s if not set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#tcp_established_idle_timeout_sec ComputeRouterNat#tcp_established_idle_timeout_sec}
    */
    readonly tcpEstablishedIdleTimeoutSec?: number;
    /**
    * Timeout (in seconds) for TCP connections that are in TIME_WAIT state.
    * Defaults to 120s if not set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#tcp_time_wait_timeout_sec ComputeRouterNat#tcp_time_wait_timeout_sec}
    */
    readonly tcpTimeWaitTimeoutSec?: number;
    /**
    * Timeout (in seconds) for TCP transitory connections.
    * Defaults to 30s if not set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#tcp_transitory_idle_timeout_sec ComputeRouterNat#tcp_transitory_idle_timeout_sec}
    */
    readonly tcpTransitoryIdleTimeoutSec?: number;
    /**
    * Indicates whether this NAT is used for public or private IP translation.
    * If unspecified, it defaults to PUBLIC.
    * If 'PUBLIC' NAT used for public IP translation.
    * If 'PRIVATE' NAT used for private IP translation. Default value: "PUBLIC" Possible values: ["PUBLIC", "PRIVATE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#type ComputeRouterNat#type}
    */
    readonly type?: string;
    /**
    * Timeout (in seconds) for UDP connections. Defaults to 30s if not set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#udp_idle_timeout_sec ComputeRouterNat#udp_idle_timeout_sec}
    */
    readonly udpIdleTimeoutSec?: number;
    /**
    * log_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#log_config ComputeRouterNat#log_config}
    */
    readonly logConfig?: ComputeRouterNatLogConfig;
    /**
    * nat64_subnetwork block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#nat64_subnetwork ComputeRouterNat#nat64_subnetwork}
    */
    readonly nat64Subnetwork?: ComputeRouterNatNat64Subnetwork[] | cdktn.IResolvable;
    /**
    * rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#rules ComputeRouterNat#rules}
    */
    readonly rules?: ComputeRouterNatRules[] | cdktn.IResolvable;
    /**
    * subnetwork block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#subnetwork ComputeRouterNat#subnetwork}
    */
    readonly subnetwork?: ComputeRouterNatSubnetwork[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#timeouts ComputeRouterNat#timeouts}
    */
    readonly timeouts?: ComputeRouterNatTimeouts;
}
export interface ComputeRouterNatLogConfig {
    /**
    * Indicates whether or not to export logs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#enable ComputeRouterNat#enable}
    */
    readonly enable: boolean | cdktn.IResolvable;
    /**
    * Specifies the desired filtering of logs on this NAT. Possible values: ["ERRORS_ONLY", "TRANSLATIONS_ONLY", "ALL"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#filter ComputeRouterNat#filter}
    */
    readonly filter: string;
}
export declare function computeRouterNatLogConfigToTerraform(struct?: ComputeRouterNatLogConfigOutputReference | ComputeRouterNatLogConfig): any;
export declare function computeRouterNatLogConfigToHclTerraform(struct?: ComputeRouterNatLogConfigOutputReference | ComputeRouterNatLogConfig): any;
export declare class ComputeRouterNatLogConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRouterNatLogConfig | undefined;
    set internalValue(value: ComputeRouterNatLogConfig | undefined);
    private _enable?;
    get enable(): boolean | cdktn.IResolvable;
    set enable(value: boolean | cdktn.IResolvable);
    get enableInput(): boolean | cdktn.IResolvable | undefined;
    private _filter?;
    get filter(): string;
    set filter(value: string);
    get filterInput(): string | undefined;
}
export interface ComputeRouterNatNat64Subnetwork {
    /**
    * Self-link of the subnetwork resource that will use NAT64
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#name ComputeRouterNat#name}
    */
    readonly name: string;
}
export declare function computeRouterNatNat64SubnetworkToTerraform(struct?: ComputeRouterNatNat64Subnetwork | cdktn.IResolvable): any;
export declare function computeRouterNatNat64SubnetworkToHclTerraform(struct?: ComputeRouterNatNat64Subnetwork | cdktn.IResolvable): any;
export declare class ComputeRouterNatNat64SubnetworkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRouterNatNat64Subnetwork | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRouterNatNat64Subnetwork | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class ComputeRouterNatNat64SubnetworkList extends cdktn.ComplexList {
    internalValue?: ComputeRouterNatNat64Subnetwork[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRouterNatNat64SubnetworkOutputReference;
}
export interface ComputeRouterNatRulesAction {
    /**
    * A list of URLs of the IP resources used for this NAT rule.
    * These IP addresses must be valid static external IP addresses assigned to the project.
    * This field is used for public NAT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#source_nat_active_ips ComputeRouterNat#source_nat_active_ips}
    */
    readonly sourceNatActiveIps?: string[];
    /**
    * A list of URLs of the subnetworks used as source ranges for this NAT Rule.
    * These subnetworks must have purpose set to PRIVATE_NAT.
    * This field is used for private NAT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#source_nat_active_ranges ComputeRouterNat#source_nat_active_ranges}
    */
    readonly sourceNatActiveRanges?: string[];
    /**
    * A list of URLs of the IP resources to be drained.
    * These IPs must be valid static external IPs that have been assigned to the NAT.
    * These IPs should be used for updating/patching a NAT rule only.
    * This field is used for public NAT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#source_nat_drain_ips ComputeRouterNat#source_nat_drain_ips}
    */
    readonly sourceNatDrainIps?: string[];
    /**
    * A list of URLs of subnetworks representing source ranges to be drained.
    * This is only supported on patch/update, and these subnetworks must have previously been used as active ranges in this NAT Rule.
    * This field is used for private NAT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#source_nat_drain_ranges ComputeRouterNat#source_nat_drain_ranges}
    */
    readonly sourceNatDrainRanges?: string[];
}
export declare function computeRouterNatRulesActionToTerraform(struct?: ComputeRouterNatRulesActionOutputReference | ComputeRouterNatRulesAction): any;
export declare function computeRouterNatRulesActionToHclTerraform(struct?: ComputeRouterNatRulesActionOutputReference | ComputeRouterNatRulesAction): any;
export declare class ComputeRouterNatRulesActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRouterNatRulesAction | undefined;
    set internalValue(value: ComputeRouterNatRulesAction | undefined);
    private _sourceNatActiveIps?;
    get sourceNatActiveIps(): string[];
    set sourceNatActiveIps(value: string[]);
    resetSourceNatActiveIps(): void;
    get sourceNatActiveIpsInput(): string[] | undefined;
    private _sourceNatActiveRanges?;
    get sourceNatActiveRanges(): string[];
    set sourceNatActiveRanges(value: string[]);
    resetSourceNatActiveRanges(): void;
    get sourceNatActiveRangesInput(): string[] | undefined;
    private _sourceNatDrainIps?;
    get sourceNatDrainIps(): string[];
    set sourceNatDrainIps(value: string[]);
    resetSourceNatDrainIps(): void;
    get sourceNatDrainIpsInput(): string[] | undefined;
    private _sourceNatDrainRanges?;
    get sourceNatDrainRanges(): string[];
    set sourceNatDrainRanges(value: string[]);
    resetSourceNatDrainRanges(): void;
    get sourceNatDrainRangesInput(): string[] | undefined;
}
export interface ComputeRouterNatRules {
    /**
    * An optional description of this rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#description ComputeRouterNat#description}
    */
    readonly description?: string;
    /**
    * CEL expression that specifies the match condition that egress traffic from a VM is evaluated against.
    * If it evaluates to true, the corresponding action is enforced.
    *
    * The following examples are valid match expressions for public NAT:
    *
    * "inIpRange(destination.ip, '1.1.0.0/16') || inIpRange(destination.ip, '2.2.0.0/16')"
    *
    * "destination.ip == '1.1.0.1' || destination.ip == '8.8.8.8'"
    *
    * The following example is a valid match expression for private NAT:
    *
    * "nexthop.hub == 'https://networkconnectivity.googleapis.com/v1alpha1/projects/my-project/global/hub/hub-1'"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#match ComputeRouterNat#match}
    */
    readonly match: string;
    /**
    * An integer uniquely identifying a rule in the list.
    * The rule number must be a positive value between 0 and 65000, and must be unique among rules within a NAT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#rule_number ComputeRouterNat#rule_number}
    */
    readonly ruleNumber: number;
    /**
    * action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#action ComputeRouterNat#action}
    */
    readonly action?: ComputeRouterNatRulesAction;
}
export declare function computeRouterNatRulesToTerraform(struct?: ComputeRouterNatRules | cdktn.IResolvable): any;
export declare function computeRouterNatRulesToHclTerraform(struct?: ComputeRouterNatRules | cdktn.IResolvable): any;
export declare class ComputeRouterNatRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRouterNatRules | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRouterNatRules | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _match?;
    get match(): string;
    set match(value: string);
    get matchInput(): string | undefined;
    private _ruleNumber?;
    get ruleNumber(): number;
    set ruleNumber(value: number);
    get ruleNumberInput(): number | undefined;
    private _action;
    get action(): ComputeRouterNatRulesActionOutputReference;
    putAction(value: ComputeRouterNatRulesAction): void;
    resetAction(): void;
    get actionInput(): ComputeRouterNatRulesAction | undefined;
}
export declare class ComputeRouterNatRulesList extends cdktn.ComplexList {
    internalValue?: ComputeRouterNatRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRouterNatRulesOutputReference;
}
export interface ComputeRouterNatSubnetwork {
    /**
    * Self-link of subnetwork to NAT
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#name ComputeRouterNat#name}
    */
    readonly name: string;
    /**
    * List of the secondary ranges of the subnetwork that are allowed
    * to use NAT. This can be populated only if
    * 'LIST_OF_SECONDARY_IP_RANGES' is one of the values in
    * sourceIpRangesToNat
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#secondary_ip_range_names ComputeRouterNat#secondary_ip_range_names}
    */
    readonly secondaryIpRangeNames?: string[];
    /**
    * List of options for which source IPs in the subnetwork
    * should have NAT enabled. Supported values include:
    * 'ALL_IP_RANGES', 'LIST_OF_SECONDARY_IP_RANGES',
    * 'PRIMARY_IP_RANGE'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#source_ip_ranges_to_nat ComputeRouterNat#source_ip_ranges_to_nat}
    */
    readonly sourceIpRangesToNat: string[];
}
export declare function computeRouterNatSubnetworkToTerraform(struct?: ComputeRouterNatSubnetwork | cdktn.IResolvable): any;
export declare function computeRouterNatSubnetworkToHclTerraform(struct?: ComputeRouterNatSubnetwork | cdktn.IResolvable): any;
export declare class ComputeRouterNatSubnetworkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRouterNatSubnetwork | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRouterNatSubnetwork | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _secondaryIpRangeNames?;
    get secondaryIpRangeNames(): string[];
    set secondaryIpRangeNames(value: string[]);
    resetSecondaryIpRangeNames(): void;
    get secondaryIpRangeNamesInput(): string[] | undefined;
    private _sourceIpRangesToNat?;
    get sourceIpRangesToNat(): string[];
    set sourceIpRangesToNat(value: string[]);
    get sourceIpRangesToNatInput(): string[] | undefined;
}
export declare class ComputeRouterNatSubnetworkList extends cdktn.ComplexList {
    internalValue?: ComputeRouterNatSubnetwork[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRouterNatSubnetworkOutputReference;
}
export interface ComputeRouterNatTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#create ComputeRouterNat#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#delete ComputeRouterNat#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#update ComputeRouterNat#update}
    */
    readonly update?: string;
}
export declare function computeRouterNatTimeoutsToTerraform(struct?: ComputeRouterNatTimeouts | cdktn.IResolvable): any;
export declare function computeRouterNatTimeoutsToHclTerraform(struct?: ComputeRouterNatTimeouts | cdktn.IResolvable): any;
export declare class ComputeRouterNatTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRouterNatTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRouterNatTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat google_compute_router_nat}
*/
export declare class ComputeRouterNat extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_router_nat";
    /**
    * Generates CDKTN code for importing a ComputeRouterNat resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeRouterNat to import
    * @param importFromId The id of the existing ComputeRouterNat that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeRouterNat to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/compute_router_nat google_compute_router_nat} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeRouterNatConfig
    */
    constructor(scope: Construct, id: string, config: ComputeRouterNatConfig);
    private _autoNetworkTier?;
    get autoNetworkTier(): string;
    set autoNetworkTier(value: string);
    resetAutoNetworkTier(): void;
    get autoNetworkTierInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _drainNatIps?;
    get drainNatIps(): string[];
    set drainNatIps(value: string[]);
    resetDrainNatIps(): void;
    get drainNatIpsInput(): string[] | undefined;
    private _enableDynamicPortAllocation?;
    get enableDynamicPortAllocation(): boolean | cdktn.IResolvable;
    set enableDynamicPortAllocation(value: boolean | cdktn.IResolvable);
    resetEnableDynamicPortAllocation(): void;
    get enableDynamicPortAllocationInput(): boolean | cdktn.IResolvable | undefined;
    private _enableEndpointIndependentMapping?;
    get enableEndpointIndependentMapping(): boolean | cdktn.IResolvable;
    set enableEndpointIndependentMapping(value: boolean | cdktn.IResolvable);
    resetEnableEndpointIndependentMapping(): void;
    get enableEndpointIndependentMappingInput(): boolean | cdktn.IResolvable | undefined;
    private _endpointTypes?;
    get endpointTypes(): string[];
    set endpointTypes(value: string[]);
    resetEndpointTypes(): void;
    get endpointTypesInput(): string[] | undefined;
    private _icmpIdleTimeoutSec?;
    get icmpIdleTimeoutSec(): number;
    set icmpIdleTimeoutSec(value: number);
    resetIcmpIdleTimeoutSec(): void;
    get icmpIdleTimeoutSecInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _initialNatIps?;
    get initialNatIps(): string[];
    set initialNatIps(value: string[]);
    resetInitialNatIps(): void;
    get initialNatIpsInput(): string[] | undefined;
    private _maxPortsPerVm?;
    get maxPortsPerVm(): number;
    set maxPortsPerVm(value: number);
    resetMaxPortsPerVm(): void;
    get maxPortsPerVmInput(): number | undefined;
    private _minPortsPerVm?;
    get minPortsPerVm(): number;
    set minPortsPerVm(value: number);
    resetMinPortsPerVm(): void;
    get minPortsPerVmInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _natIpAllocateOption?;
    get natIpAllocateOption(): string;
    set natIpAllocateOption(value: string);
    resetNatIpAllocateOption(): void;
    get natIpAllocateOptionInput(): string | undefined;
    private _natIps?;
    get natIps(): string[];
    set natIps(value: string[]);
    resetNatIps(): void;
    get natIpsInput(): string[] | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _router?;
    get router(): string;
    set router(value: string);
    get routerInput(): string | undefined;
    private _sourceSubnetworkIpRangesToNat?;
    get sourceSubnetworkIpRangesToNat(): string;
    set sourceSubnetworkIpRangesToNat(value: string);
    get sourceSubnetworkIpRangesToNatInput(): string | undefined;
    private _sourceSubnetworkIpRangesToNat64?;
    get sourceSubnetworkIpRangesToNat64(): string;
    set sourceSubnetworkIpRangesToNat64(value: string);
    resetSourceSubnetworkIpRangesToNat64(): void;
    get sourceSubnetworkIpRangesToNat64Input(): string | undefined;
    private _tcpEstablishedIdleTimeoutSec?;
    get tcpEstablishedIdleTimeoutSec(): number;
    set tcpEstablishedIdleTimeoutSec(value: number);
    resetTcpEstablishedIdleTimeoutSec(): void;
    get tcpEstablishedIdleTimeoutSecInput(): number | undefined;
    private _tcpTimeWaitTimeoutSec?;
    get tcpTimeWaitTimeoutSec(): number;
    set tcpTimeWaitTimeoutSec(value: number);
    resetTcpTimeWaitTimeoutSec(): void;
    get tcpTimeWaitTimeoutSecInput(): number | undefined;
    private _tcpTransitoryIdleTimeoutSec?;
    get tcpTransitoryIdleTimeoutSec(): number;
    set tcpTransitoryIdleTimeoutSec(value: number);
    resetTcpTransitoryIdleTimeoutSec(): void;
    get tcpTransitoryIdleTimeoutSecInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _udpIdleTimeoutSec?;
    get udpIdleTimeoutSec(): number;
    set udpIdleTimeoutSec(value: number);
    resetUdpIdleTimeoutSec(): void;
    get udpIdleTimeoutSecInput(): number | undefined;
    private _logConfig;
    get logConfig(): ComputeRouterNatLogConfigOutputReference;
    putLogConfig(value: ComputeRouterNatLogConfig): void;
    resetLogConfig(): void;
    get logConfigInput(): ComputeRouterNatLogConfig | undefined;
    private _nat64Subnetwork;
    get nat64Subnetwork(): ComputeRouterNatNat64SubnetworkList;
    putNat64Subnetwork(value: ComputeRouterNatNat64Subnetwork[] | cdktn.IResolvable): void;
    resetNat64Subnetwork(): void;
    get nat64SubnetworkInput(): cdktn.IResolvable | ComputeRouterNatNat64Subnetwork[] | undefined;
    private _rules;
    get rules(): ComputeRouterNatRulesList;
    putRules(value: ComputeRouterNatRules[] | cdktn.IResolvable): void;
    resetRules(): void;
    get rulesInput(): cdktn.IResolvable | ComputeRouterNatRules[] | undefined;
    private _subnetwork;
    get subnetwork(): ComputeRouterNatSubnetworkList;
    putSubnetwork(value: ComputeRouterNatSubnetwork[] | cdktn.IResolvable): void;
    resetSubnetwork(): void;
    get subnetworkInput(): cdktn.IResolvable | ComputeRouterNatSubnetwork[] | undefined;
    private _timeouts;
    get timeouts(): ComputeRouterNatTimeoutsOutputReference;
    putTimeouts(value: ComputeRouterNatTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeRouterNatTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
