/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApihubHostProjectRegistrationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Required. Immutable. Google cloud project name in the format: "projects/abc" or "projects/123".
    * As input, project name with either project id or number are accepted.
    * As output, this field will contain project number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_host_project_registration#gcp_project ApihubHostProjectRegistration#gcp_project}
    */
    readonly gcpProject: string;
    /**
    * Required. The ID to use for the Host Project Registration, which will become the
    * final component of the host project registration's resource name. The ID
    * must be the same as the Google cloud project specified in the
    * host_project_registration.gcp_project field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_host_project_registration#host_project_registration_id ApihubHostProjectRegistration#host_project_registration_id}
    */
    readonly hostProjectRegistrationId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_host_project_registration#id ApihubHostProjectRegistration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Part of 'parent'. See documentation of 'projectsId'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_host_project_registration#location ApihubHostProjectRegistration#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_host_project_registration#project ApihubHostProjectRegistration#project}
    */
    readonly project?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_host_project_registration#timeouts ApihubHostProjectRegistration#timeouts}
    */
    readonly timeouts?: ApihubHostProjectRegistrationTimeouts;
}
export interface ApihubHostProjectRegistrationTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_host_project_registration#create ApihubHostProjectRegistration#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_host_project_registration#delete ApihubHostProjectRegistration#delete}
    */
    readonly delete?: string;
}
export declare function apihubHostProjectRegistrationTimeoutsToTerraform(struct?: ApihubHostProjectRegistrationTimeouts | cdktn.IResolvable): any;
export declare function apihubHostProjectRegistrationTimeoutsToHclTerraform(struct?: ApihubHostProjectRegistrationTimeouts | cdktn.IResolvable): any;
export declare class ApihubHostProjectRegistrationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApihubHostProjectRegistrationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApihubHostProjectRegistrationTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_host_project_registration google_apihub_host_project_registration}
*/
export declare class ApihubHostProjectRegistration extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apihub_host_project_registration";
    /**
    * Generates CDKTN code for importing a ApihubHostProjectRegistration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApihubHostProjectRegistration to import
    * @param importFromId The id of the existing ApihubHostProjectRegistration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_host_project_registration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApihubHostProjectRegistration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/apihub_host_project_registration google_apihub_host_project_registration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApihubHostProjectRegistrationConfig
    */
    constructor(scope: Construct, id: string, config: ApihubHostProjectRegistrationConfig);
    get createTime(): string;
    private _gcpProject?;
    get gcpProject(): string;
    set gcpProject(value: string);
    get gcpProjectInput(): string | undefined;
    private _hostProjectRegistrationId?;
    get hostProjectRegistrationId(): string;
    set hostProjectRegistrationId(value: string);
    get hostProjectRegistrationIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _timeouts;
    get timeouts(): ApihubHostProjectRegistrationTimeoutsOutputReference;
    putTimeouts(value: ApihubHostProjectRegistrationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApihubHostProjectRegistrationTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
