/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AlloydbClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Annotations to allow client tools to store small amount of arbitrary data. This is distinct from labels. https://google.aip.dev/128
    * An object containing a list of "key": value pairs. Example: { "name": "wrench", "mass": "1.3kg", "count": "3" }.
    *
    *
    * **Note**: This field is non-authoritative, and will only manage the annotations present in your configuration.
    * Please refer to the field 'effective_annotations' for all of the annotations present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#annotations AlloydbCluster#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * The ID of the alloydb cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#cluster_id AlloydbCluster#cluster_id}
    */
    readonly clusterId: string;
    /**
    * The type of cluster. If not set, defaults to PRIMARY. Default value: "PRIMARY" Possible values: ["PRIMARY", "SECONDARY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#cluster_type AlloydbCluster#cluster_type}
    */
    readonly clusterType?: string;
    /**
    * The database engine major version. This is an optional field and it's populated at the Cluster creation time.
    * Note: Changing this field to a higer version results in upgrading the AlloyDB cluster which is an irreversible change.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#database_version AlloydbCluster#database_version}
    */
    readonly databaseVersion?: string;
    /**
    * This field uses a custom implementation please refer to documentation under /hashicorp/terraform-provider-google-beta/website/docs/r/alloydb_cluster.html.markdown for specifics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#deletion_policy AlloydbCluster#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Whether Terraform will be prevented from destroying the cluster.
    * When the field is set to true or unset in Terraform state, a 'terraform apply'
    * or 'terraform destroy' that would delete the cluster will fail.
    * When the field is set to false, deleting the cluster is allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#deletion_protection AlloydbCluster#deletion_protection}
    */
    readonly deletionProtection?: boolean | cdktn.IResolvable;
    /**
    * User-settable and human-readable display name for the Cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#display_name AlloydbCluster#display_name}
    */
    readonly displayName?: string;
    /**
    * For Resource freshness validation (https://google.aip.dev/154)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#etag AlloydbCluster#etag}
    */
    readonly etag?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#id AlloydbCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * User-defined labels for the alloydb cluster.
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#labels AlloydbCluster#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The location where the alloydb cluster should reside.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#location AlloydbCluster#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#project AlloydbCluster#project}
    */
    readonly project?: string;
    /**
    * Set to true to skip awaiting on the major version upgrade of the cluster.
    * Possible values: true, false
    * Default value: "true"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#skip_await_major_version_upgrade AlloydbCluster#skip_await_major_version_upgrade}
    */
    readonly skipAwaitMajorVersionUpgrade?: boolean | cdktn.IResolvable;
    /**
    * The subscrition type of cluster. Possible values: ["TRIAL", "STANDARD"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#subscription_type AlloydbCluster#subscription_type}
    */
    readonly subscriptionType?: string;
    /**
    * automated_backup_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#automated_backup_policy AlloydbCluster#automated_backup_policy}
    */
    readonly automatedBackupPolicy?: AlloydbClusterAutomatedBackupPolicy;
    /**
    * continuous_backup_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#continuous_backup_config AlloydbCluster#continuous_backup_config}
    */
    readonly continuousBackupConfig?: AlloydbClusterContinuousBackupConfig;
    /**
    * dataplex_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#dataplex_config AlloydbCluster#dataplex_config}
    */
    readonly dataplexConfig?: AlloydbClusterDataplexConfig;
    /**
    * encryption_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#encryption_config AlloydbCluster#encryption_config}
    */
    readonly encryptionConfig?: AlloydbClusterEncryptionConfig;
    /**
    * initial_user block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#initial_user AlloydbCluster#initial_user}
    */
    readonly initialUser?: AlloydbClusterInitialUser;
    /**
    * maintenance_update_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#maintenance_update_policy AlloydbCluster#maintenance_update_policy}
    */
    readonly maintenanceUpdatePolicy?: AlloydbClusterMaintenanceUpdatePolicy;
    /**
    * network_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#network_config AlloydbCluster#network_config}
    */
    readonly networkConfig?: AlloydbClusterNetworkConfig;
    /**
    * psc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#psc_config AlloydbCluster#psc_config}
    */
    readonly pscConfig?: AlloydbClusterPscConfig;
    /**
    * restore_backup_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#restore_backup_source AlloydbCluster#restore_backup_source}
    */
    readonly restoreBackupSource?: AlloydbClusterRestoreBackupSource;
    /**
    * restore_backupdr_backup_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#restore_backupdr_backup_source AlloydbCluster#restore_backupdr_backup_source}
    */
    readonly restoreBackupdrBackupSource?: AlloydbClusterRestoreBackupdrBackupSource;
    /**
    * restore_backupdr_pitr_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#restore_backupdr_pitr_source AlloydbCluster#restore_backupdr_pitr_source}
    */
    readonly restoreBackupdrPitrSource?: AlloydbClusterRestoreBackupdrPitrSource;
    /**
    * restore_continuous_backup_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#restore_continuous_backup_source AlloydbCluster#restore_continuous_backup_source}
    */
    readonly restoreContinuousBackupSource?: AlloydbClusterRestoreContinuousBackupSource;
    /**
    * secondary_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#secondary_config AlloydbCluster#secondary_config}
    */
    readonly secondaryConfig?: AlloydbClusterSecondaryConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#timeouts AlloydbCluster#timeouts}
    */
    readonly timeouts?: AlloydbClusterTimeouts;
}
export interface AlloydbClusterBackupSource {
}
export declare function alloydbClusterBackupSourceToTerraform(struct?: AlloydbClusterBackupSource): any;
export declare function alloydbClusterBackupSourceToHclTerraform(struct?: AlloydbClusterBackupSource): any;
export declare class AlloydbClusterBackupSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlloydbClusterBackupSource | undefined;
    set internalValue(value: AlloydbClusterBackupSource | undefined);
    get backupName(): string;
}
export declare class AlloydbClusterBackupSourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlloydbClusterBackupSourceOutputReference;
}
export interface AlloydbClusterBackupdrBackupSource {
}
export declare function alloydbClusterBackupdrBackupSourceToTerraform(struct?: AlloydbClusterBackupdrBackupSource): any;
export declare function alloydbClusterBackupdrBackupSourceToHclTerraform(struct?: AlloydbClusterBackupdrBackupSource): any;
export declare class AlloydbClusterBackupdrBackupSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlloydbClusterBackupdrBackupSource | undefined;
    set internalValue(value: AlloydbClusterBackupdrBackupSource | undefined);
    get backup(): string;
}
export declare class AlloydbClusterBackupdrBackupSourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlloydbClusterBackupdrBackupSourceOutputReference;
}
export interface AlloydbClusterContinuousBackupInfoEncryptionInfo {
}
export declare function alloydbClusterContinuousBackupInfoEncryptionInfoToTerraform(struct?: AlloydbClusterContinuousBackupInfoEncryptionInfo): any;
export declare function alloydbClusterContinuousBackupInfoEncryptionInfoToHclTerraform(struct?: AlloydbClusterContinuousBackupInfoEncryptionInfo): any;
export declare class AlloydbClusterContinuousBackupInfoEncryptionInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlloydbClusterContinuousBackupInfoEncryptionInfo | undefined;
    set internalValue(value: AlloydbClusterContinuousBackupInfoEncryptionInfo | undefined);
    get encryptionType(): string;
    get kmsKeyVersions(): string[];
}
export declare class AlloydbClusterContinuousBackupInfoEncryptionInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlloydbClusterContinuousBackupInfoEncryptionInfoOutputReference;
}
export interface AlloydbClusterContinuousBackupInfo {
}
export declare function alloydbClusterContinuousBackupInfoToTerraform(struct?: AlloydbClusterContinuousBackupInfo): any;
export declare function alloydbClusterContinuousBackupInfoToHclTerraform(struct?: AlloydbClusterContinuousBackupInfo): any;
export declare class AlloydbClusterContinuousBackupInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlloydbClusterContinuousBackupInfo | undefined;
    set internalValue(value: AlloydbClusterContinuousBackupInfo | undefined);
    get earliestRestorableTime(): string;
    get enabledTime(): string;
    private _encryptionInfo;
    get encryptionInfo(): AlloydbClusterContinuousBackupInfoEncryptionInfoList;
    get schedule(): string[];
}
export declare class AlloydbClusterContinuousBackupInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlloydbClusterContinuousBackupInfoOutputReference;
}
export interface AlloydbClusterEncryptionInfo {
}
export declare function alloydbClusterEncryptionInfoToTerraform(struct?: AlloydbClusterEncryptionInfo): any;
export declare function alloydbClusterEncryptionInfoToHclTerraform(struct?: AlloydbClusterEncryptionInfo): any;
export declare class AlloydbClusterEncryptionInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlloydbClusterEncryptionInfo | undefined;
    set internalValue(value: AlloydbClusterEncryptionInfo | undefined);
    get encryptionType(): string;
    get kmsKeyVersions(): string[];
}
export declare class AlloydbClusterEncryptionInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlloydbClusterEncryptionInfoOutputReference;
}
export interface AlloydbClusterMigrationSource {
}
export declare function alloydbClusterMigrationSourceToTerraform(struct?: AlloydbClusterMigrationSource): any;
export declare function alloydbClusterMigrationSourceToHclTerraform(struct?: AlloydbClusterMigrationSource): any;
export declare class AlloydbClusterMigrationSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlloydbClusterMigrationSource | undefined;
    set internalValue(value: AlloydbClusterMigrationSource | undefined);
    get hostPort(): string;
    get referenceId(): string;
    get sourceType(): string;
}
export declare class AlloydbClusterMigrationSourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlloydbClusterMigrationSourceOutputReference;
}
export interface AlloydbClusterTrialMetadata {
}
export declare function alloydbClusterTrialMetadataToTerraform(struct?: AlloydbClusterTrialMetadata): any;
export declare function alloydbClusterTrialMetadataToHclTerraform(struct?: AlloydbClusterTrialMetadata): any;
export declare class AlloydbClusterTrialMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlloydbClusterTrialMetadata | undefined;
    set internalValue(value: AlloydbClusterTrialMetadata | undefined);
    get endTime(): string;
    get graceEndTime(): string;
    get startTime(): string;
    get upgradeTime(): string;
}
export declare class AlloydbClusterTrialMetadataList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlloydbClusterTrialMetadataOutputReference;
}
export interface AlloydbClusterAutomatedBackupPolicyEncryptionConfig {
    /**
    * The fully-qualified resource name of the KMS key. Each Cloud KMS key is regionalized and has the following format: projects/[PROJECT]/locations/[REGION]/keyRings/[RING]/cryptoKeys/[KEY_NAME].
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#kms_key_name AlloydbCluster#kms_key_name}
    */
    readonly kmsKeyName?: string;
}
export declare function alloydbClusterAutomatedBackupPolicyEncryptionConfigToTerraform(struct?: AlloydbClusterAutomatedBackupPolicyEncryptionConfigOutputReference | AlloydbClusterAutomatedBackupPolicyEncryptionConfig): any;
export declare function alloydbClusterAutomatedBackupPolicyEncryptionConfigToHclTerraform(struct?: AlloydbClusterAutomatedBackupPolicyEncryptionConfigOutputReference | AlloydbClusterAutomatedBackupPolicyEncryptionConfig): any;
export declare class AlloydbClusterAutomatedBackupPolicyEncryptionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbClusterAutomatedBackupPolicyEncryptionConfig | undefined;
    set internalValue(value: AlloydbClusterAutomatedBackupPolicyEncryptionConfig | undefined);
    private _kmsKeyName?;
    get kmsKeyName(): string;
    set kmsKeyName(value: string);
    resetKmsKeyName(): void;
    get kmsKeyNameInput(): string | undefined;
}
export interface AlloydbClusterAutomatedBackupPolicyQuantityBasedRetention {
    /**
    * The number of backups to retain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#count AlloydbCluster#count}
    */
    readonly count?: number;
}
export declare function alloydbClusterAutomatedBackupPolicyQuantityBasedRetentionToTerraform(struct?: AlloydbClusterAutomatedBackupPolicyQuantityBasedRetentionOutputReference | AlloydbClusterAutomatedBackupPolicyQuantityBasedRetention): any;
export declare function alloydbClusterAutomatedBackupPolicyQuantityBasedRetentionToHclTerraform(struct?: AlloydbClusterAutomatedBackupPolicyQuantityBasedRetentionOutputReference | AlloydbClusterAutomatedBackupPolicyQuantityBasedRetention): any;
export declare class AlloydbClusterAutomatedBackupPolicyQuantityBasedRetentionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbClusterAutomatedBackupPolicyQuantityBasedRetention | undefined;
    set internalValue(value: AlloydbClusterAutomatedBackupPolicyQuantityBasedRetention | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    resetCount(): void;
    get countInput(): number | undefined;
}
export interface AlloydbClusterAutomatedBackupPolicyTimeBasedRetention {
    /**
    * The retention period.
    * A duration in seconds with up to nine fractional digits, terminated by 's'. Example: "3.5s".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#retention_period AlloydbCluster#retention_period}
    */
    readonly retentionPeriod?: string;
}
export declare function alloydbClusterAutomatedBackupPolicyTimeBasedRetentionToTerraform(struct?: AlloydbClusterAutomatedBackupPolicyTimeBasedRetentionOutputReference | AlloydbClusterAutomatedBackupPolicyTimeBasedRetention): any;
export declare function alloydbClusterAutomatedBackupPolicyTimeBasedRetentionToHclTerraform(struct?: AlloydbClusterAutomatedBackupPolicyTimeBasedRetentionOutputReference | AlloydbClusterAutomatedBackupPolicyTimeBasedRetention): any;
export declare class AlloydbClusterAutomatedBackupPolicyTimeBasedRetentionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbClusterAutomatedBackupPolicyTimeBasedRetention | undefined;
    set internalValue(value: AlloydbClusterAutomatedBackupPolicyTimeBasedRetention | undefined);
    private _retentionPeriod?;
    get retentionPeriod(): string;
    set retentionPeriod(value: string);
    resetRetentionPeriod(): void;
    get retentionPeriodInput(): string | undefined;
}
export interface AlloydbClusterAutomatedBackupPolicyWeeklyScheduleStartTimes {
    /**
    * Hours of day in 24 hour format. Should be from 0 to 23. An API may choose to allow the value "24:00:00" for scenarios like business closing time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#hours AlloydbCluster#hours}
    */
    readonly hours?: number;
    /**
    * Minutes of hour of day. Currently, only the value 0 is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#minutes AlloydbCluster#minutes}
    */
    readonly minutes?: number;
    /**
    * Fractions of seconds in nanoseconds. Currently, only the value 0 is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#nanos AlloydbCluster#nanos}
    */
    readonly nanos?: number;
    /**
    * Seconds of minutes of the time. Currently, only the value 0 is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#seconds AlloydbCluster#seconds}
    */
    readonly seconds?: number;
}
export declare function alloydbClusterAutomatedBackupPolicyWeeklyScheduleStartTimesToTerraform(struct?: AlloydbClusterAutomatedBackupPolicyWeeklyScheduleStartTimes | cdktn.IResolvable): any;
export declare function alloydbClusterAutomatedBackupPolicyWeeklyScheduleStartTimesToHclTerraform(struct?: AlloydbClusterAutomatedBackupPolicyWeeklyScheduleStartTimes | cdktn.IResolvable): any;
export declare class AlloydbClusterAutomatedBackupPolicyWeeklyScheduleStartTimesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlloydbClusterAutomatedBackupPolicyWeeklyScheduleStartTimes | cdktn.IResolvable | undefined;
    set internalValue(value: AlloydbClusterAutomatedBackupPolicyWeeklyScheduleStartTimes | cdktn.IResolvable | undefined);
    private _hours?;
    get hours(): number;
    set hours(value: number);
    resetHours(): void;
    get hoursInput(): number | undefined;
    private _minutes?;
    get minutes(): number;
    set minutes(value: number);
    resetMinutes(): void;
    get minutesInput(): number | undefined;
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): number;
    set seconds(value: number);
    resetSeconds(): void;
    get secondsInput(): number | undefined;
}
export declare class AlloydbClusterAutomatedBackupPolicyWeeklyScheduleStartTimesList extends cdktn.ComplexList {
    internalValue?: AlloydbClusterAutomatedBackupPolicyWeeklyScheduleStartTimes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlloydbClusterAutomatedBackupPolicyWeeklyScheduleStartTimesOutputReference;
}
export interface AlloydbClusterAutomatedBackupPolicyWeeklySchedule {
    /**
    * The days of the week to perform a backup. At least one day of the week must be provided. Possible values: ["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY", "SUNDAY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#days_of_week AlloydbCluster#days_of_week}
    */
    readonly daysOfWeek?: string[];
    /**
    * start_times block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#start_times AlloydbCluster#start_times}
    */
    readonly startTimes: AlloydbClusterAutomatedBackupPolicyWeeklyScheduleStartTimes[] | cdktn.IResolvable;
}
export declare function alloydbClusterAutomatedBackupPolicyWeeklyScheduleToTerraform(struct?: AlloydbClusterAutomatedBackupPolicyWeeklyScheduleOutputReference | AlloydbClusterAutomatedBackupPolicyWeeklySchedule): any;
export declare function alloydbClusterAutomatedBackupPolicyWeeklyScheduleToHclTerraform(struct?: AlloydbClusterAutomatedBackupPolicyWeeklyScheduleOutputReference | AlloydbClusterAutomatedBackupPolicyWeeklySchedule): any;
export declare class AlloydbClusterAutomatedBackupPolicyWeeklyScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbClusterAutomatedBackupPolicyWeeklySchedule | undefined;
    set internalValue(value: AlloydbClusterAutomatedBackupPolicyWeeklySchedule | undefined);
    private _daysOfWeek?;
    get daysOfWeek(): string[];
    set daysOfWeek(value: string[]);
    resetDaysOfWeek(): void;
    get daysOfWeekInput(): string[] | undefined;
    private _startTimes;
    get startTimes(): AlloydbClusterAutomatedBackupPolicyWeeklyScheduleStartTimesList;
    putStartTimes(value: AlloydbClusterAutomatedBackupPolicyWeeklyScheduleStartTimes[] | cdktn.IResolvable): void;
    get startTimesInput(): cdktn.IResolvable | AlloydbClusterAutomatedBackupPolicyWeeklyScheduleStartTimes[] | undefined;
}
export interface AlloydbClusterAutomatedBackupPolicy {
    /**
    * The length of the time window during which a backup can be taken. If a backup does not succeed within this time window, it will be canceled and considered failed.
    *
    * The backup window must be at least 5 minutes long. There is no upper bound on the window. If not set, it will default to 1 hour.
    *
    * A duration in seconds with up to nine fractional digits, terminated by 's'. Example: "3.5s".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#backup_window AlloydbCluster#backup_window}
    */
    readonly backupWindow?: string;
    /**
    * Whether automated backups are enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#enabled AlloydbCluster#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Labels to apply to backups created using this configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#labels AlloydbCluster#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The location where the backup will be stored. Currently, the only supported option is to store the backup in the same region as the cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#location AlloydbCluster#location}
    */
    readonly location?: string;
    /**
    * encryption_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#encryption_config AlloydbCluster#encryption_config}
    */
    readonly encryptionConfig?: AlloydbClusterAutomatedBackupPolicyEncryptionConfig;
    /**
    * quantity_based_retention block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#quantity_based_retention AlloydbCluster#quantity_based_retention}
    */
    readonly quantityBasedRetention?: AlloydbClusterAutomatedBackupPolicyQuantityBasedRetention;
    /**
    * time_based_retention block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#time_based_retention AlloydbCluster#time_based_retention}
    */
    readonly timeBasedRetention?: AlloydbClusterAutomatedBackupPolicyTimeBasedRetention;
    /**
    * weekly_schedule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#weekly_schedule AlloydbCluster#weekly_schedule}
    */
    readonly weeklySchedule?: AlloydbClusterAutomatedBackupPolicyWeeklySchedule;
}
export declare function alloydbClusterAutomatedBackupPolicyToTerraform(struct?: AlloydbClusterAutomatedBackupPolicyOutputReference | AlloydbClusterAutomatedBackupPolicy): any;
export declare function alloydbClusterAutomatedBackupPolicyToHclTerraform(struct?: AlloydbClusterAutomatedBackupPolicyOutputReference | AlloydbClusterAutomatedBackupPolicy): any;
export declare class AlloydbClusterAutomatedBackupPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbClusterAutomatedBackupPolicy | undefined;
    set internalValue(value: AlloydbClusterAutomatedBackupPolicy | undefined);
    private _backupWindow?;
    get backupWindow(): string;
    set backupWindow(value: string);
    resetBackupWindow(): void;
    get backupWindowInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _encryptionConfig;
    get encryptionConfig(): AlloydbClusterAutomatedBackupPolicyEncryptionConfigOutputReference;
    putEncryptionConfig(value: AlloydbClusterAutomatedBackupPolicyEncryptionConfig): void;
    resetEncryptionConfig(): void;
    get encryptionConfigInput(): AlloydbClusterAutomatedBackupPolicyEncryptionConfig | undefined;
    private _quantityBasedRetention;
    get quantityBasedRetention(): AlloydbClusterAutomatedBackupPolicyQuantityBasedRetentionOutputReference;
    putQuantityBasedRetention(value: AlloydbClusterAutomatedBackupPolicyQuantityBasedRetention): void;
    resetQuantityBasedRetention(): void;
    get quantityBasedRetentionInput(): AlloydbClusterAutomatedBackupPolicyQuantityBasedRetention | undefined;
    private _timeBasedRetention;
    get timeBasedRetention(): AlloydbClusterAutomatedBackupPolicyTimeBasedRetentionOutputReference;
    putTimeBasedRetention(value: AlloydbClusterAutomatedBackupPolicyTimeBasedRetention): void;
    resetTimeBasedRetention(): void;
    get timeBasedRetentionInput(): AlloydbClusterAutomatedBackupPolicyTimeBasedRetention | undefined;
    private _weeklySchedule;
    get weeklySchedule(): AlloydbClusterAutomatedBackupPolicyWeeklyScheduleOutputReference;
    putWeeklySchedule(value: AlloydbClusterAutomatedBackupPolicyWeeklySchedule): void;
    resetWeeklySchedule(): void;
    get weeklyScheduleInput(): AlloydbClusterAutomatedBackupPolicyWeeklySchedule | undefined;
}
export interface AlloydbClusterContinuousBackupConfigEncryptionConfig {
    /**
    * The fully-qualified resource name of the KMS key. Each Cloud KMS key is regionalized and has the following format: projects/[PROJECT]/locations/[REGION]/keyRings/[RING]/cryptoKeys/[KEY_NAME].
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#kms_key_name AlloydbCluster#kms_key_name}
    */
    readonly kmsKeyName?: string;
}
export declare function alloydbClusterContinuousBackupConfigEncryptionConfigToTerraform(struct?: AlloydbClusterContinuousBackupConfigEncryptionConfigOutputReference | AlloydbClusterContinuousBackupConfigEncryptionConfig): any;
export declare function alloydbClusterContinuousBackupConfigEncryptionConfigToHclTerraform(struct?: AlloydbClusterContinuousBackupConfigEncryptionConfigOutputReference | AlloydbClusterContinuousBackupConfigEncryptionConfig): any;
export declare class AlloydbClusterContinuousBackupConfigEncryptionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbClusterContinuousBackupConfigEncryptionConfig | undefined;
    set internalValue(value: AlloydbClusterContinuousBackupConfigEncryptionConfig | undefined);
    private _kmsKeyName?;
    get kmsKeyName(): string;
    set kmsKeyName(value: string);
    resetKmsKeyName(): void;
    get kmsKeyNameInput(): string | undefined;
}
export interface AlloydbClusterContinuousBackupConfig {
    /**
    * Whether continuous backup recovery is enabled. If not set, defaults to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#enabled AlloydbCluster#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The numbers of days that are eligible to restore from using PITR. To support the entire recovery window, backups and logs are retained for one day more than the recovery window.
    *
    * If not set, defaults to 14 days.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#recovery_window_days AlloydbCluster#recovery_window_days}
    */
    readonly recoveryWindowDays?: number;
    /**
    * encryption_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#encryption_config AlloydbCluster#encryption_config}
    */
    readonly encryptionConfig?: AlloydbClusterContinuousBackupConfigEncryptionConfig;
}
export declare function alloydbClusterContinuousBackupConfigToTerraform(struct?: AlloydbClusterContinuousBackupConfigOutputReference | AlloydbClusterContinuousBackupConfig): any;
export declare function alloydbClusterContinuousBackupConfigToHclTerraform(struct?: AlloydbClusterContinuousBackupConfigOutputReference | AlloydbClusterContinuousBackupConfig): any;
export declare class AlloydbClusterContinuousBackupConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbClusterContinuousBackupConfig | undefined;
    set internalValue(value: AlloydbClusterContinuousBackupConfig | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _recoveryWindowDays?;
    get recoveryWindowDays(): number;
    set recoveryWindowDays(value: number);
    resetRecoveryWindowDays(): void;
    get recoveryWindowDaysInput(): number | undefined;
    private _encryptionConfig;
    get encryptionConfig(): AlloydbClusterContinuousBackupConfigEncryptionConfigOutputReference;
    putEncryptionConfig(value: AlloydbClusterContinuousBackupConfigEncryptionConfig): void;
    resetEncryptionConfig(): void;
    get encryptionConfigInput(): AlloydbClusterContinuousBackupConfigEncryptionConfig | undefined;
}
export interface AlloydbClusterDataplexConfig {
    /**
    * Indicates whether Dataplex integration is enabled for the cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#enabled AlloydbCluster#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function alloydbClusterDataplexConfigToTerraform(struct?: AlloydbClusterDataplexConfigOutputReference | AlloydbClusterDataplexConfig): any;
export declare function alloydbClusterDataplexConfigToHclTerraform(struct?: AlloydbClusterDataplexConfigOutputReference | AlloydbClusterDataplexConfig): any;
export declare class AlloydbClusterDataplexConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbClusterDataplexConfig | undefined;
    set internalValue(value: AlloydbClusterDataplexConfig | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AlloydbClusterEncryptionConfig {
    /**
    * The fully-qualified resource name of the KMS key. Each Cloud KMS key is regionalized and has the following format: projects/[PROJECT]/locations/[REGION]/keyRings/[RING]/cryptoKeys/[KEY_NAME].
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#kms_key_name AlloydbCluster#kms_key_name}
    */
    readonly kmsKeyName?: string;
}
export declare function alloydbClusterEncryptionConfigToTerraform(struct?: AlloydbClusterEncryptionConfigOutputReference | AlloydbClusterEncryptionConfig): any;
export declare function alloydbClusterEncryptionConfigToHclTerraform(struct?: AlloydbClusterEncryptionConfigOutputReference | AlloydbClusterEncryptionConfig): any;
export declare class AlloydbClusterEncryptionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbClusterEncryptionConfig | undefined;
    set internalValue(value: AlloydbClusterEncryptionConfig | undefined);
    private _kmsKeyName?;
    get kmsKeyName(): string;
    set kmsKeyName(value: string);
    resetKmsKeyName(): void;
    get kmsKeyNameInput(): string | undefined;
}
export interface AlloydbClusterInitialUser {
    /**
    * The initial password for the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#password AlloydbCluster#password}
    */
    readonly password?: string;
    /**
    * The initial password for the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#password_wo AlloydbCluster#password_wo}
    */
    readonly passwordWo?: string;
    /**
    * Triggers update of 'password_wo' write-only. Increment this value when an update to 'password_wo' is needed. For more info see [updating write-only arguments](/docs/providers/google/guides/using_write_only_arguments.html#updating-write-only-arguments)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#password_wo_version AlloydbCluster#password_wo_version}
    */
    readonly passwordWoVersion?: string;
    /**
    * The database username.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#user AlloydbCluster#user}
    */
    readonly user?: string;
}
export declare function alloydbClusterInitialUserToTerraform(struct?: AlloydbClusterInitialUserOutputReference | AlloydbClusterInitialUser): any;
export declare function alloydbClusterInitialUserToHclTerraform(struct?: AlloydbClusterInitialUserOutputReference | AlloydbClusterInitialUser): any;
export declare class AlloydbClusterInitialUserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbClusterInitialUser | undefined;
    set internalValue(value: AlloydbClusterInitialUser | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _passwordWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get passwordWo(): string;
    set passwordWo(value: string);
    resetPasswordWo(): void;
    get passwordWoInput(): string | undefined;
    private _passwordWoVersion?;
    get passwordWoVersion(): string;
    set passwordWoVersion(value: string);
    resetPasswordWoVersion(): void;
    get passwordWoVersionInput(): string | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
}
export interface AlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsStartTime {
    /**
    * Hours of day in 24 hour format. Should be from 0 to 23.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#hours AlloydbCluster#hours}
    */
    readonly hours: number;
    /**
    * Minutes of hour of day. Currently, only the value 0 is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#minutes AlloydbCluster#minutes}
    */
    readonly minutes?: number;
    /**
    * Fractions of seconds in nanoseconds. Currently, only the value 0 is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#nanos AlloydbCluster#nanos}
    */
    readonly nanos?: number;
    /**
    * Seconds of minutes of the time. Currently, only the value 0 is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#seconds AlloydbCluster#seconds}
    */
    readonly seconds?: number;
}
export declare function alloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsStartTimeToTerraform(struct?: AlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsStartTimeOutputReference | AlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsStartTime): any;
export declare function alloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsStartTimeToHclTerraform(struct?: AlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsStartTimeOutputReference | AlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsStartTime): any;
export declare class AlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsStartTime | undefined;
    set internalValue(value: AlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsStartTime | undefined);
    private _hours?;
    get hours(): number;
    set hours(value: number);
    get hoursInput(): number | undefined;
    private _minutes?;
    get minutes(): number;
    set minutes(value: number);
    resetMinutes(): void;
    get minutesInput(): number | undefined;
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): number;
    set seconds(value: number);
    resetSeconds(): void;
    get secondsInput(): number | undefined;
}
export interface AlloydbClusterMaintenanceUpdatePolicyMaintenanceWindows {
    /**
    * Preferred day of the week for maintenance, e.g. MONDAY, TUESDAY, etc. Possible values: ["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY", "SUNDAY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#day AlloydbCluster#day}
    */
    readonly day: string;
    /**
    * start_time block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#start_time AlloydbCluster#start_time}
    */
    readonly startTime: AlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsStartTime;
}
export declare function alloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsToTerraform(struct?: AlloydbClusterMaintenanceUpdatePolicyMaintenanceWindows | cdktn.IResolvable): any;
export declare function alloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsToHclTerraform(struct?: AlloydbClusterMaintenanceUpdatePolicyMaintenanceWindows | cdktn.IResolvable): any;
export declare class AlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlloydbClusterMaintenanceUpdatePolicyMaintenanceWindows | cdktn.IResolvable | undefined;
    set internalValue(value: AlloydbClusterMaintenanceUpdatePolicyMaintenanceWindows | cdktn.IResolvable | undefined);
    private _day?;
    get day(): string;
    set day(value: string);
    get dayInput(): string | undefined;
    private _startTime;
    get startTime(): AlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsStartTimeOutputReference;
    putStartTime(value: AlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsStartTime): void;
    get startTimeInput(): AlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsStartTime | undefined;
}
export declare class AlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsList extends cdktn.ComplexList {
    internalValue?: AlloydbClusterMaintenanceUpdatePolicyMaintenanceWindows[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsOutputReference;
}
export interface AlloydbClusterMaintenanceUpdatePolicy {
    /**
    * maintenance_windows block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#maintenance_windows AlloydbCluster#maintenance_windows}
    */
    readonly maintenanceWindows?: AlloydbClusterMaintenanceUpdatePolicyMaintenanceWindows[] | cdktn.IResolvable;
}
export declare function alloydbClusterMaintenanceUpdatePolicyToTerraform(struct?: AlloydbClusterMaintenanceUpdatePolicyOutputReference | AlloydbClusterMaintenanceUpdatePolicy): any;
export declare function alloydbClusterMaintenanceUpdatePolicyToHclTerraform(struct?: AlloydbClusterMaintenanceUpdatePolicyOutputReference | AlloydbClusterMaintenanceUpdatePolicy): any;
export declare class AlloydbClusterMaintenanceUpdatePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbClusterMaintenanceUpdatePolicy | undefined;
    set internalValue(value: AlloydbClusterMaintenanceUpdatePolicy | undefined);
    private _maintenanceWindows;
    get maintenanceWindows(): AlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsList;
    putMaintenanceWindows(value: AlloydbClusterMaintenanceUpdatePolicyMaintenanceWindows[] | cdktn.IResolvable): void;
    resetMaintenanceWindows(): void;
    get maintenanceWindowsInput(): cdktn.IResolvable | AlloydbClusterMaintenanceUpdatePolicyMaintenanceWindows[] | undefined;
}
export interface AlloydbClusterNetworkConfig {
    /**
    * The name of the allocated IP range for the private IP AlloyDB cluster. For example: "google-managed-services-default".
    * If set, the instance IPs for this cluster will be created in the allocated range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#allocated_ip_range AlloydbCluster#allocated_ip_range}
    */
    readonly allocatedIpRange?: string;
    /**
    * The resource link for the VPC network in which cluster resources are created and from which they are accessible via Private IP. The network must belong to the same project as the cluster.
    * It is specified in the form: "projects/{projectNumber}/global/networks/{network_id}".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#network AlloydbCluster#network}
    */
    readonly network?: string;
}
export declare function alloydbClusterNetworkConfigToTerraform(struct?: AlloydbClusterNetworkConfigOutputReference | AlloydbClusterNetworkConfig): any;
export declare function alloydbClusterNetworkConfigToHclTerraform(struct?: AlloydbClusterNetworkConfigOutputReference | AlloydbClusterNetworkConfig): any;
export declare class AlloydbClusterNetworkConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbClusterNetworkConfig | undefined;
    set internalValue(value: AlloydbClusterNetworkConfig | undefined);
    private _allocatedIpRange?;
    get allocatedIpRange(): string;
    set allocatedIpRange(value: string);
    resetAllocatedIpRange(): void;
    get allocatedIpRangeInput(): string | undefined;
    private _network?;
    get network(): string;
    set network(value: string);
    resetNetwork(): void;
    get networkInput(): string | undefined;
}
export interface AlloydbClusterPscConfig {
    /**
    * Create an instance that allows connections from Private Service Connect endpoints to the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#psc_enabled AlloydbCluster#psc_enabled}
    */
    readonly pscEnabled?: boolean | cdktn.IResolvable;
}
export declare function alloydbClusterPscConfigToTerraform(struct?: AlloydbClusterPscConfigOutputReference | AlloydbClusterPscConfig): any;
export declare function alloydbClusterPscConfigToHclTerraform(struct?: AlloydbClusterPscConfigOutputReference | AlloydbClusterPscConfig): any;
export declare class AlloydbClusterPscConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbClusterPscConfig | undefined;
    set internalValue(value: AlloydbClusterPscConfig | undefined);
    private _pscEnabled?;
    get pscEnabled(): boolean | cdktn.IResolvable;
    set pscEnabled(value: boolean | cdktn.IResolvable);
    resetPscEnabled(): void;
    get pscEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get serviceOwnedProjectNumber(): number;
}
export interface AlloydbClusterRestoreBackupSource {
    /**
    * The name of the backup that this cluster is restored from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#backup_name AlloydbCluster#backup_name}
    */
    readonly backupName: string;
}
export declare function alloydbClusterRestoreBackupSourceToTerraform(struct?: AlloydbClusterRestoreBackupSourceOutputReference | AlloydbClusterRestoreBackupSource): any;
export declare function alloydbClusterRestoreBackupSourceToHclTerraform(struct?: AlloydbClusterRestoreBackupSourceOutputReference | AlloydbClusterRestoreBackupSource): any;
export declare class AlloydbClusterRestoreBackupSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbClusterRestoreBackupSource | undefined;
    set internalValue(value: AlloydbClusterRestoreBackupSource | undefined);
    private _backupName?;
    get backupName(): string;
    set backupName(value: string);
    get backupNameInput(): string | undefined;
}
export interface AlloydbClusterRestoreBackupdrBackupSource {
    /**
    * The name of the BackupDR backup that this cluster is restored from. It must be of the format "projects/[PROJECT]/locations/[LOCATION]/backupVaults/[VAULT_ID]/dataSources/[DATASOURCE_ID]/backups/[BACKUP_ID]"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#backup AlloydbCluster#backup}
    */
    readonly backup: string;
}
export declare function alloydbClusterRestoreBackupdrBackupSourceToTerraform(struct?: AlloydbClusterRestoreBackupdrBackupSourceOutputReference | AlloydbClusterRestoreBackupdrBackupSource): any;
export declare function alloydbClusterRestoreBackupdrBackupSourceToHclTerraform(struct?: AlloydbClusterRestoreBackupdrBackupSourceOutputReference | AlloydbClusterRestoreBackupdrBackupSource): any;
export declare class AlloydbClusterRestoreBackupdrBackupSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbClusterRestoreBackupdrBackupSource | undefined;
    set internalValue(value: AlloydbClusterRestoreBackupdrBackupSource | undefined);
    private _backup?;
    get backup(): string;
    set backup(value: string);
    get backupInput(): string | undefined;
}
export interface AlloydbClusterRestoreBackupdrPitrSource {
    /**
    * The name of the BackupDR data source that this cluster is restore from. It must be of the format "projects/[PROJECT]/locations/[LOCATION]/backupVaults/[VAULT_ID]/dataSources/[DATASOURCE_ID]"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#data_source AlloydbCluster#data_source}
    */
    readonly dataSource: string;
    /**
    * The point in time that this cluster is restored to, in RFC 3339 format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#point_in_time AlloydbCluster#point_in_time}
    */
    readonly pointInTime: string;
}
export declare function alloydbClusterRestoreBackupdrPitrSourceToTerraform(struct?: AlloydbClusterRestoreBackupdrPitrSourceOutputReference | AlloydbClusterRestoreBackupdrPitrSource): any;
export declare function alloydbClusterRestoreBackupdrPitrSourceToHclTerraform(struct?: AlloydbClusterRestoreBackupdrPitrSourceOutputReference | AlloydbClusterRestoreBackupdrPitrSource): any;
export declare class AlloydbClusterRestoreBackupdrPitrSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbClusterRestoreBackupdrPitrSource | undefined;
    set internalValue(value: AlloydbClusterRestoreBackupdrPitrSource | undefined);
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _pointInTime?;
    get pointInTime(): string;
    set pointInTime(value: string);
    get pointInTimeInput(): string | undefined;
}
export interface AlloydbClusterRestoreContinuousBackupSource {
    /**
    * The name of the source cluster that this cluster is restored from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#cluster AlloydbCluster#cluster}
    */
    readonly cluster: string;
    /**
    * The point in time that this cluster is restored to, in RFC 3339 format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#point_in_time AlloydbCluster#point_in_time}
    */
    readonly pointInTime: string;
}
export declare function alloydbClusterRestoreContinuousBackupSourceToTerraform(struct?: AlloydbClusterRestoreContinuousBackupSourceOutputReference | AlloydbClusterRestoreContinuousBackupSource): any;
export declare function alloydbClusterRestoreContinuousBackupSourceToHclTerraform(struct?: AlloydbClusterRestoreContinuousBackupSourceOutputReference | AlloydbClusterRestoreContinuousBackupSource): any;
export declare class AlloydbClusterRestoreContinuousBackupSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbClusterRestoreContinuousBackupSource | undefined;
    set internalValue(value: AlloydbClusterRestoreContinuousBackupSource | undefined);
    private _cluster?;
    get cluster(): string;
    set cluster(value: string);
    get clusterInput(): string | undefined;
    private _pointInTime?;
    get pointInTime(): string;
    set pointInTime(value: string);
    get pointInTimeInput(): string | undefined;
}
export interface AlloydbClusterSecondaryConfig {
    /**
    * Name of the primary cluster must be in the format
    * 'projects/{project}/locations/{location}/clusters/{cluster_id}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#primary_cluster_name AlloydbCluster#primary_cluster_name}
    */
    readonly primaryClusterName: string;
}
export declare function alloydbClusterSecondaryConfigToTerraform(struct?: AlloydbClusterSecondaryConfigOutputReference | AlloydbClusterSecondaryConfig): any;
export declare function alloydbClusterSecondaryConfigToHclTerraform(struct?: AlloydbClusterSecondaryConfigOutputReference | AlloydbClusterSecondaryConfig): any;
export declare class AlloydbClusterSecondaryConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbClusterSecondaryConfig | undefined;
    set internalValue(value: AlloydbClusterSecondaryConfig | undefined);
    private _primaryClusterName?;
    get primaryClusterName(): string;
    set primaryClusterName(value: string);
    get primaryClusterNameInput(): string | undefined;
}
export interface AlloydbClusterTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#create AlloydbCluster#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#delete AlloydbCluster#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#update AlloydbCluster#update}
    */
    readonly update?: string;
}
export declare function alloydbClusterTimeoutsToTerraform(struct?: AlloydbClusterTimeouts | cdktn.IResolvable): any;
export declare function alloydbClusterTimeoutsToHclTerraform(struct?: AlloydbClusterTimeouts | cdktn.IResolvable): any;
export declare class AlloydbClusterTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbClusterTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AlloydbClusterTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster google_alloydb_cluster}
*/
export declare class AlloydbCluster extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_alloydb_cluster";
    /**
    * Generates CDKTN code for importing a AlloydbCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AlloydbCluster to import
    * @param importFromId The id of the existing AlloydbCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AlloydbCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.9.0/docs/resources/alloydb_cluster google_alloydb_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AlloydbClusterConfig
    */
    constructor(scope: Construct, id: string, config: AlloydbClusterConfig);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _backupSource;
    get backupSource(): AlloydbClusterBackupSourceList;
    private _backupdrBackupSource;
    get backupdrBackupSource(): AlloydbClusterBackupdrBackupSourceList;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _clusterType?;
    get clusterType(): string;
    set clusterType(value: string);
    resetClusterType(): void;
    get clusterTypeInput(): string | undefined;
    private _continuousBackupInfo;
    get continuousBackupInfo(): AlloydbClusterContinuousBackupInfoList;
    private _databaseVersion?;
    get databaseVersion(): string;
    set databaseVersion(value: string);
    resetDatabaseVersion(): void;
    get databaseVersionInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _deletionProtection?;
    get deletionProtection(): boolean | cdktn.IResolvable;
    set deletionProtection(value: boolean | cdktn.IResolvable);
    resetDeletionProtection(): void;
    get deletionProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _effectiveAnnotations;
    get effectiveAnnotations(): cdktn.StringMap;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _encryptionInfo;
    get encryptionInfo(): AlloydbClusterEncryptionInfoList;
    private _etag?;
    get etag(): string;
    set etag(value: string);
    resetEtag(): void;
    get etagInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _migrationSource;
    get migrationSource(): AlloydbClusterMigrationSourceList;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get reconciling(): cdktn.IResolvable;
    private _skipAwaitMajorVersionUpgrade?;
    get skipAwaitMajorVersionUpgrade(): boolean | cdktn.IResolvable;
    set skipAwaitMajorVersionUpgrade(value: boolean | cdktn.IResolvable);
    resetSkipAwaitMajorVersionUpgrade(): void;
    get skipAwaitMajorVersionUpgradeInput(): boolean | cdktn.IResolvable | undefined;
    get state(): string;
    private _subscriptionType?;
    get subscriptionType(): string;
    set subscriptionType(value: string);
    resetSubscriptionType(): void;
    get subscriptionTypeInput(): string | undefined;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _trialMetadata;
    get trialMetadata(): AlloydbClusterTrialMetadataList;
    get uid(): string;
    private _automatedBackupPolicy;
    get automatedBackupPolicy(): AlloydbClusterAutomatedBackupPolicyOutputReference;
    putAutomatedBackupPolicy(value: AlloydbClusterAutomatedBackupPolicy): void;
    resetAutomatedBackupPolicy(): void;
    get automatedBackupPolicyInput(): AlloydbClusterAutomatedBackupPolicy | undefined;
    private _continuousBackupConfig;
    get continuousBackupConfig(): AlloydbClusterContinuousBackupConfigOutputReference;
    putContinuousBackupConfig(value: AlloydbClusterContinuousBackupConfig): void;
    resetContinuousBackupConfig(): void;
    get continuousBackupConfigInput(): AlloydbClusterContinuousBackupConfig | undefined;
    private _dataplexConfig;
    get dataplexConfig(): AlloydbClusterDataplexConfigOutputReference;
    putDataplexConfig(value: AlloydbClusterDataplexConfig): void;
    resetDataplexConfig(): void;
    get dataplexConfigInput(): AlloydbClusterDataplexConfig | undefined;
    private _encryptionConfig;
    get encryptionConfig(): AlloydbClusterEncryptionConfigOutputReference;
    putEncryptionConfig(value: AlloydbClusterEncryptionConfig): void;
    resetEncryptionConfig(): void;
    get encryptionConfigInput(): AlloydbClusterEncryptionConfig | undefined;
    private _initialUser;
    get initialUser(): AlloydbClusterInitialUserOutputReference;
    putInitialUser(value: AlloydbClusterInitialUser): void;
    resetInitialUser(): void;
    get initialUserInput(): AlloydbClusterInitialUser | undefined;
    private _maintenanceUpdatePolicy;
    get maintenanceUpdatePolicy(): AlloydbClusterMaintenanceUpdatePolicyOutputReference;
    putMaintenanceUpdatePolicy(value: AlloydbClusterMaintenanceUpdatePolicy): void;
    resetMaintenanceUpdatePolicy(): void;
    get maintenanceUpdatePolicyInput(): AlloydbClusterMaintenanceUpdatePolicy | undefined;
    private _networkConfig;
    get networkConfig(): AlloydbClusterNetworkConfigOutputReference;
    putNetworkConfig(value: AlloydbClusterNetworkConfig): void;
    resetNetworkConfig(): void;
    get networkConfigInput(): AlloydbClusterNetworkConfig | undefined;
    private _pscConfig;
    get pscConfig(): AlloydbClusterPscConfigOutputReference;
    putPscConfig(value: AlloydbClusterPscConfig): void;
    resetPscConfig(): void;
    get pscConfigInput(): AlloydbClusterPscConfig | undefined;
    private _restoreBackupSource;
    get restoreBackupSource(): AlloydbClusterRestoreBackupSourceOutputReference;
    putRestoreBackupSource(value: AlloydbClusterRestoreBackupSource): void;
    resetRestoreBackupSource(): void;
    get restoreBackupSourceInput(): AlloydbClusterRestoreBackupSource | undefined;
    private _restoreBackupdrBackupSource;
    get restoreBackupdrBackupSource(): AlloydbClusterRestoreBackupdrBackupSourceOutputReference;
    putRestoreBackupdrBackupSource(value: AlloydbClusterRestoreBackupdrBackupSource): void;
    resetRestoreBackupdrBackupSource(): void;
    get restoreBackupdrBackupSourceInput(): AlloydbClusterRestoreBackupdrBackupSource | undefined;
    private _restoreBackupdrPitrSource;
    get restoreBackupdrPitrSource(): AlloydbClusterRestoreBackupdrPitrSourceOutputReference;
    putRestoreBackupdrPitrSource(value: AlloydbClusterRestoreBackupdrPitrSource): void;
    resetRestoreBackupdrPitrSource(): void;
    get restoreBackupdrPitrSourceInput(): AlloydbClusterRestoreBackupdrPitrSource | undefined;
    private _restoreContinuousBackupSource;
    get restoreContinuousBackupSource(): AlloydbClusterRestoreContinuousBackupSourceOutputReference;
    putRestoreContinuousBackupSource(value: AlloydbClusterRestoreContinuousBackupSource): void;
    resetRestoreContinuousBackupSource(): void;
    get restoreContinuousBackupSourceInput(): AlloydbClusterRestoreContinuousBackupSource | undefined;
    private _secondaryConfig;
    get secondaryConfig(): AlloydbClusterSecondaryConfigOutputReference;
    putSecondaryConfig(value: AlloydbClusterSecondaryConfig): void;
    resetSecondaryConfig(): void;
    get secondaryConfigInput(): AlloydbClusterSecondaryConfig | undefined;
    private _timeouts;
    get timeouts(): AlloydbClusterTimeoutsOutputReference;
    putTimeouts(value: AlloydbClusterTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AlloydbClusterTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
