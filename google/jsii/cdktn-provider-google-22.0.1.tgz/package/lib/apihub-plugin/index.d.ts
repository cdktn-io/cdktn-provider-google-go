/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApihubPluginConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#deletion_policy ApihubPlugin#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The plugin description. Max length is 2000 characters (Unicode code
    * points).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#description ApihubPlugin#description}
    */
    readonly description?: string;
    /**
    * The display name of the plugin. Max length is 50 characters (Unicode code
    * points).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#display_name ApihubPlugin#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#id ApihubPlugin#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#location ApihubPlugin#location}
    */
    readonly location: string;
    /**
    * Possible values:
    * PLUGIN_CATEGORY_UNSPECIFIED
    * API_GATEWAY
    * API_PRODUCER
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#plugin_category ApihubPlugin#plugin_category}
    */
    readonly pluginCategory?: string;
    /**
    * The ID to use for the Plugin resource, which will become the final
    * component of the Plugin's resource name. This field is optional.
    *
    * * If provided, the same will be used. The service will throw an error if
    * the specified id is already used by another Plugin resource in the API hub
    * instance.
    * * If not provided, a system generated id will be used.
    *
    * This value should be 4-63 characters, overall resource name which will be
    * of format
    * 'projects/{project}/locations/{location}/plugins/{plugin}',
    * its length is limited to 1000 characters and valid characters are
    * /a-z[0-9]-_/.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#plugin_id ApihubPlugin#plugin_id}
    */
    readonly pluginId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#project ApihubPlugin#project}
    */
    readonly project?: string;
    /**
    * actions_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#actions_config ApihubPlugin#actions_config}
    */
    readonly actionsConfig?: ApihubPluginActionsConfig[] | cdktn.IResolvable;
    /**
    * config_template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#config_template ApihubPlugin#config_template}
    */
    readonly configTemplate?: ApihubPluginConfigTemplate;
    /**
    * documentation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#documentation ApihubPlugin#documentation}
    */
    readonly documentation?: ApihubPluginDocumentation;
    /**
    * hosting_service block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#hosting_service ApihubPlugin#hosting_service}
    */
    readonly hostingService?: ApihubPluginHostingService;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#timeouts ApihubPlugin#timeouts}
    */
    readonly timeouts?: ApihubPluginTimeouts;
}
export interface ApihubPluginActionsConfig {
    /**
    * The description of the operation performed by the action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#description ApihubPlugin#description}
    */
    readonly description: string;
    /**
    * The display name of the action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#display_name ApihubPlugin#display_name}
    */
    readonly displayName: string;
    /**
    * The id of the action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#id ApihubPlugin#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * The trigger mode supported by the action.
    * Possible values:
    * TRIGGER_MODE_UNSPECIFIED
    * API_HUB_ON_DEMAND_TRIGGER
    * API_HUB_SCHEDULE_TRIGGER
    * NON_API_HUB_MANAGED
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#trigger_mode ApihubPlugin#trigger_mode}
    */
    readonly triggerMode: string;
}
export declare function apihubPluginActionsConfigToTerraform(struct?: ApihubPluginActionsConfig | cdktn.IResolvable): any;
export declare function apihubPluginActionsConfigToHclTerraform(struct?: ApihubPluginActionsConfig | cdktn.IResolvable): any;
export declare class ApihubPluginActionsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApihubPluginActionsConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ApihubPluginActionsConfig | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _triggerMode?;
    get triggerMode(): string;
    set triggerMode(value: string);
    get triggerModeInput(): string | undefined;
}
export declare class ApihubPluginActionsConfigList extends cdktn.ComplexList {
    internalValue?: ApihubPluginActionsConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApihubPluginActionsConfigOutputReference;
}
export interface ApihubPluginConfigTemplateAdditionalConfigTemplateEnumOptions {
    /**
    * Description of the option.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#description ApihubPlugin#description}
    */
    readonly description?: string;
    /**
    * Display name of the option.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#display_name ApihubPlugin#display_name}
    */
    readonly displayName: string;
    /**
    * Id of the option.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#id ApihubPlugin#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function apihubPluginConfigTemplateAdditionalConfigTemplateEnumOptionsToTerraform(struct?: ApihubPluginConfigTemplateAdditionalConfigTemplateEnumOptions | cdktn.IResolvable): any;
export declare function apihubPluginConfigTemplateAdditionalConfigTemplateEnumOptionsToHclTerraform(struct?: ApihubPluginConfigTemplateAdditionalConfigTemplateEnumOptions | cdktn.IResolvable): any;
export declare class ApihubPluginConfigTemplateAdditionalConfigTemplateEnumOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApihubPluginConfigTemplateAdditionalConfigTemplateEnumOptions | cdktn.IResolvable | undefined;
    set internalValue(value: ApihubPluginConfigTemplateAdditionalConfigTemplateEnumOptions | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class ApihubPluginConfigTemplateAdditionalConfigTemplateEnumOptionsList extends cdktn.ComplexList {
    internalValue?: ApihubPluginConfigTemplateAdditionalConfigTemplateEnumOptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApihubPluginConfigTemplateAdditionalConfigTemplateEnumOptionsOutputReference;
}
export interface ApihubPluginConfigTemplateAdditionalConfigTemplateMultiSelectOptions {
    /**
    * Description of the option.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#description ApihubPlugin#description}
    */
    readonly description?: string;
    /**
    * Display name of the option.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#display_name ApihubPlugin#display_name}
    */
    readonly displayName: string;
    /**
    * Id of the option.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#id ApihubPlugin#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function apihubPluginConfigTemplateAdditionalConfigTemplateMultiSelectOptionsToTerraform(struct?: ApihubPluginConfigTemplateAdditionalConfigTemplateMultiSelectOptions | cdktn.IResolvable): any;
export declare function apihubPluginConfigTemplateAdditionalConfigTemplateMultiSelectOptionsToHclTerraform(struct?: ApihubPluginConfigTemplateAdditionalConfigTemplateMultiSelectOptions | cdktn.IResolvable): any;
export declare class ApihubPluginConfigTemplateAdditionalConfigTemplateMultiSelectOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApihubPluginConfigTemplateAdditionalConfigTemplateMultiSelectOptions | cdktn.IResolvable | undefined;
    set internalValue(value: ApihubPluginConfigTemplateAdditionalConfigTemplateMultiSelectOptions | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class ApihubPluginConfigTemplateAdditionalConfigTemplateMultiSelectOptionsList extends cdktn.ComplexList {
    internalValue?: ApihubPluginConfigTemplateAdditionalConfigTemplateMultiSelectOptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApihubPluginConfigTemplateAdditionalConfigTemplateMultiSelectOptionsOutputReference;
}
export interface ApihubPluginConfigTemplateAdditionalConfigTemplate {
    /**
    * Description.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#description ApihubPlugin#description}
    */
    readonly description?: string;
    /**
    * ID of the config variable. Must be unique within the configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#id ApihubPlugin#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Flag represents that this 'ConfigVariable' must be provided for a
    * PluginInstance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#required ApihubPlugin#required}
    */
    readonly required?: boolean | cdktn.IResolvable;
    /**
    * Regular expression in RE2 syntax used for validating the 'value' of a
    * 'ConfigVariable'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#validation_regex ApihubPlugin#validation_regex}
    */
    readonly validationRegex?: string;
    /**
    * Type of the parameter: string, int, bool etc.
    * Possible values:
    * VALUE_TYPE_UNSPECIFIED
    * STRING
    * INT
    * BOOL
    * SECRET
    * ENUM
    * MULTI_SELECT
    * MULTI_STRING
    * MULTI_INT
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#value_type ApihubPlugin#value_type}
    */
    readonly valueType: string;
    /**
    * enum_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#enum_options ApihubPlugin#enum_options}
    */
    readonly enumOptions?: ApihubPluginConfigTemplateAdditionalConfigTemplateEnumOptions[] | cdktn.IResolvable;
    /**
    * multi_select_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#multi_select_options ApihubPlugin#multi_select_options}
    */
    readonly multiSelectOptions?: ApihubPluginConfigTemplateAdditionalConfigTemplateMultiSelectOptions[] | cdktn.IResolvable;
}
export declare function apihubPluginConfigTemplateAdditionalConfigTemplateToTerraform(struct?: ApihubPluginConfigTemplateAdditionalConfigTemplate | cdktn.IResolvable): any;
export declare function apihubPluginConfigTemplateAdditionalConfigTemplateToHclTerraform(struct?: ApihubPluginConfigTemplateAdditionalConfigTemplate | cdktn.IResolvable): any;
export declare class ApihubPluginConfigTemplateAdditionalConfigTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApihubPluginConfigTemplateAdditionalConfigTemplate | cdktn.IResolvable | undefined;
    set internalValue(value: ApihubPluginConfigTemplateAdditionalConfigTemplate | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _required?;
    get required(): boolean | cdktn.IResolvable;
    set required(value: boolean | cdktn.IResolvable);
    resetRequired(): void;
    get requiredInput(): boolean | cdktn.IResolvable | undefined;
    private _validationRegex?;
    get validationRegex(): string;
    set validationRegex(value: string);
    resetValidationRegex(): void;
    get validationRegexInput(): string | undefined;
    private _valueType?;
    get valueType(): string;
    set valueType(value: string);
    get valueTypeInput(): string | undefined;
    private _enumOptions;
    get enumOptions(): ApihubPluginConfigTemplateAdditionalConfigTemplateEnumOptionsList;
    putEnumOptions(value: ApihubPluginConfigTemplateAdditionalConfigTemplateEnumOptions[] | cdktn.IResolvable): void;
    resetEnumOptions(): void;
    get enumOptionsInput(): cdktn.IResolvable | ApihubPluginConfigTemplateAdditionalConfigTemplateEnumOptions[] | undefined;
    private _multiSelectOptions;
    get multiSelectOptions(): ApihubPluginConfigTemplateAdditionalConfigTemplateMultiSelectOptionsList;
    putMultiSelectOptions(value: ApihubPluginConfigTemplateAdditionalConfigTemplateMultiSelectOptions[] | cdktn.IResolvable): void;
    resetMultiSelectOptions(): void;
    get multiSelectOptionsInput(): cdktn.IResolvable | ApihubPluginConfigTemplateAdditionalConfigTemplateMultiSelectOptions[] | undefined;
}
export declare class ApihubPluginConfigTemplateAdditionalConfigTemplateList extends cdktn.ComplexList {
    internalValue?: ApihubPluginConfigTemplateAdditionalConfigTemplate[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApihubPluginConfigTemplateAdditionalConfigTemplateOutputReference;
}
export interface ApihubPluginConfigTemplateAuthConfigTemplateServiceAccount {
    /**
    * The service account to be used for authenticating request.
    *
    * The 'iam.serviceAccounts.getAccessToken' permission should be granted on
    * this service account to the impersonator service account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#service_account ApihubPlugin#service_account}
    */
    readonly serviceAccount: string;
}
export declare function apihubPluginConfigTemplateAuthConfigTemplateServiceAccountToTerraform(struct?: ApihubPluginConfigTemplateAuthConfigTemplateServiceAccountOutputReference | ApihubPluginConfigTemplateAuthConfigTemplateServiceAccount): any;
export declare function apihubPluginConfigTemplateAuthConfigTemplateServiceAccountToHclTerraform(struct?: ApihubPluginConfigTemplateAuthConfigTemplateServiceAccountOutputReference | ApihubPluginConfigTemplateAuthConfigTemplateServiceAccount): any;
export declare class ApihubPluginConfigTemplateAuthConfigTemplateServiceAccountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApihubPluginConfigTemplateAuthConfigTemplateServiceAccount | undefined;
    set internalValue(value: ApihubPluginConfigTemplateAuthConfigTemplateServiceAccount | undefined);
    private _serviceAccount?;
    get serviceAccount(): string;
    set serviceAccount(value: string);
    get serviceAccountInput(): string | undefined;
}
export interface ApihubPluginConfigTemplateAuthConfigTemplate {
    /**
    * The list of authentication types supported by the plugin.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#supported_auth_types ApihubPlugin#supported_auth_types}
    */
    readonly supportedAuthTypes: string[];
    /**
    * service_account block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#service_account ApihubPlugin#service_account}
    */
    readonly serviceAccount?: ApihubPluginConfigTemplateAuthConfigTemplateServiceAccount;
}
export declare function apihubPluginConfigTemplateAuthConfigTemplateToTerraform(struct?: ApihubPluginConfigTemplateAuthConfigTemplateOutputReference | ApihubPluginConfigTemplateAuthConfigTemplate): any;
export declare function apihubPluginConfigTemplateAuthConfigTemplateToHclTerraform(struct?: ApihubPluginConfigTemplateAuthConfigTemplateOutputReference | ApihubPluginConfigTemplateAuthConfigTemplate): any;
export declare class ApihubPluginConfigTemplateAuthConfigTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApihubPluginConfigTemplateAuthConfigTemplate | undefined;
    set internalValue(value: ApihubPluginConfigTemplateAuthConfigTemplate | undefined);
    private _supportedAuthTypes?;
    get supportedAuthTypes(): string[];
    set supportedAuthTypes(value: string[]);
    get supportedAuthTypesInput(): string[] | undefined;
    private _serviceAccount;
    get serviceAccount(): ApihubPluginConfigTemplateAuthConfigTemplateServiceAccountOutputReference;
    putServiceAccount(value: ApihubPluginConfigTemplateAuthConfigTemplateServiceAccount): void;
    resetServiceAccount(): void;
    get serviceAccountInput(): ApihubPluginConfigTemplateAuthConfigTemplateServiceAccount | undefined;
}
export interface ApihubPluginConfigTemplate {
    /**
    * additional_config_template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#additional_config_template ApihubPlugin#additional_config_template}
    */
    readonly additionalConfigTemplate?: ApihubPluginConfigTemplateAdditionalConfigTemplate[] | cdktn.IResolvable;
    /**
    * auth_config_template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#auth_config_template ApihubPlugin#auth_config_template}
    */
    readonly authConfigTemplate?: ApihubPluginConfigTemplateAuthConfigTemplate;
}
export declare function apihubPluginConfigTemplateToTerraform(struct?: ApihubPluginConfigTemplateOutputReference | ApihubPluginConfigTemplate): any;
export declare function apihubPluginConfigTemplateToHclTerraform(struct?: ApihubPluginConfigTemplateOutputReference | ApihubPluginConfigTemplate): any;
export declare class ApihubPluginConfigTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApihubPluginConfigTemplate | undefined;
    set internalValue(value: ApihubPluginConfigTemplate | undefined);
    private _additionalConfigTemplate;
    get additionalConfigTemplate(): ApihubPluginConfigTemplateAdditionalConfigTemplateList;
    putAdditionalConfigTemplate(value: ApihubPluginConfigTemplateAdditionalConfigTemplate[] | cdktn.IResolvable): void;
    resetAdditionalConfigTemplate(): void;
    get additionalConfigTemplateInput(): cdktn.IResolvable | ApihubPluginConfigTemplateAdditionalConfigTemplate[] | undefined;
    private _authConfigTemplate;
    get authConfigTemplate(): ApihubPluginConfigTemplateAuthConfigTemplateOutputReference;
    putAuthConfigTemplate(value: ApihubPluginConfigTemplateAuthConfigTemplate): void;
    resetAuthConfigTemplate(): void;
    get authConfigTemplateInput(): ApihubPluginConfigTemplateAuthConfigTemplate | undefined;
}
export interface ApihubPluginDocumentation {
    /**
    * The uri of the externally hosted documentation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#external_uri ApihubPlugin#external_uri}
    */
    readonly externalUri?: string;
}
export declare function apihubPluginDocumentationToTerraform(struct?: ApihubPluginDocumentationOutputReference | ApihubPluginDocumentation): any;
export declare function apihubPluginDocumentationToHclTerraform(struct?: ApihubPluginDocumentationOutputReference | ApihubPluginDocumentation): any;
export declare class ApihubPluginDocumentationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApihubPluginDocumentation | undefined;
    set internalValue(value: ApihubPluginDocumentation | undefined);
    private _externalUri?;
    get externalUri(): string;
    set externalUri(value: string);
    resetExternalUri(): void;
    get externalUriInput(): string | undefined;
}
export interface ApihubPluginHostingService {
    /**
    * The URI of the service implemented by the plugin developer, used to
    * invoke the plugin's functionality. This information is only required for
    * user defined plugins.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#service_uri ApihubPlugin#service_uri}
    */
    readonly serviceUri?: string;
}
export declare function apihubPluginHostingServiceToTerraform(struct?: ApihubPluginHostingServiceOutputReference | ApihubPluginHostingService): any;
export declare function apihubPluginHostingServiceToHclTerraform(struct?: ApihubPluginHostingServiceOutputReference | ApihubPluginHostingService): any;
export declare class ApihubPluginHostingServiceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApihubPluginHostingService | undefined;
    set internalValue(value: ApihubPluginHostingService | undefined);
    private _serviceUri?;
    get serviceUri(): string;
    set serviceUri(value: string);
    resetServiceUri(): void;
    get serviceUriInput(): string | undefined;
}
export interface ApihubPluginTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#create ApihubPlugin#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#delete ApihubPlugin#delete}
    */
    readonly delete?: string;
}
export declare function apihubPluginTimeoutsToTerraform(struct?: ApihubPluginTimeouts | cdktn.IResolvable): any;
export declare function apihubPluginTimeoutsToHclTerraform(struct?: ApihubPluginTimeouts | cdktn.IResolvable): any;
export declare class ApihubPluginTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApihubPluginTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApihubPluginTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin google_apihub_plugin}
*/
export declare class ApihubPlugin extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apihub_plugin";
    /**
    * Generates CDKTN code for importing a ApihubPlugin resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApihubPlugin to import
    * @param importFromId The id of the existing ApihubPlugin that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApihubPlugin to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_plugin google_apihub_plugin} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApihubPluginConfig
    */
    constructor(scope: Construct, id: string, config: ApihubPluginConfig);
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    get ownershipType(): string;
    private _pluginCategory?;
    get pluginCategory(): string;
    set pluginCategory(value: string);
    resetPluginCategory(): void;
    get pluginCategoryInput(): string | undefined;
    private _pluginId?;
    get pluginId(): string;
    set pluginId(value: string);
    get pluginIdInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get state(): string;
    get updateTime(): string;
    private _actionsConfig;
    get actionsConfig(): ApihubPluginActionsConfigList;
    putActionsConfig(value: ApihubPluginActionsConfig[] | cdktn.IResolvable): void;
    resetActionsConfig(): void;
    get actionsConfigInput(): cdktn.IResolvable | ApihubPluginActionsConfig[] | undefined;
    private _configTemplate;
    get configTemplate(): ApihubPluginConfigTemplateOutputReference;
    putConfigTemplate(value: ApihubPluginConfigTemplate): void;
    resetConfigTemplate(): void;
    get configTemplateInput(): ApihubPluginConfigTemplate | undefined;
    private _documentation;
    get documentation(): ApihubPluginDocumentationOutputReference;
    putDocumentation(value: ApihubPluginDocumentation): void;
    resetDocumentation(): void;
    get documentationInput(): ApihubPluginDocumentation | undefined;
    private _hostingService;
    get hostingService(): ApihubPluginHostingServiceOutputReference;
    putHostingService(value: ApihubPluginHostingService): void;
    resetHostingService(): void;
    get hostingServiceInput(): ApihubPluginHostingService | undefined;
    private _timeouts;
    get timeouts(): ApihubPluginTimeoutsOutputReference;
    putTimeouts(value: ApihubPluginTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApihubPluginTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
