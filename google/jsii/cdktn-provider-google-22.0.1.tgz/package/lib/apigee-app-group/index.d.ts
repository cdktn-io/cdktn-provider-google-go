/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigeeAppGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Channel identifier identifies the owner maintaining this grouping.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_app_group#channel_id ApigeeAppGroup#channel_id}
    */
    readonly channelId?: string;
    /**
    * A reference to the associated storefront/marketplace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_app_group#channel_uri ApigeeAppGroup#channel_uri}
    */
    readonly channelUri?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_app_group#deletion_policy ApigeeAppGroup#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * App group name displayed in the UI
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_app_group#display_name ApigeeAppGroup#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_app_group#id ApigeeAppGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the AppGroup. Characters you can use in the name are restricted to: A-Z0-9._-$ %.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_app_group#name ApigeeAppGroup#name}
    */
    readonly name: string;
    /**
    * The Apigee Organization associated with the Apigee app group,
    * in the format 'organizations/{{org_name}}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_app_group#org_id ApigeeAppGroup#org_id}
    */
    readonly orgId: string;
    /**
    * Valid values are active or inactive. Note that the status of the AppGroup should be updated via UpdateAppGroupRequest by setting the action as active or inactive. Possible values: ["active", "inactive"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_app_group#status ApigeeAppGroup#status}
    */
    readonly status?: string;
    /**
    * attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_app_group#attributes ApigeeAppGroup#attributes}
    */
    readonly attributes?: ApigeeAppGroupAttributes[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_app_group#timeouts ApigeeAppGroup#timeouts}
    */
    readonly timeouts?: ApigeeAppGroupTimeouts;
}
export interface ApigeeAppGroupAttributes {
    /**
    * Key of the attribute
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_app_group#name ApigeeAppGroup#name}
    */
    readonly name?: string;
    /**
    * Value of the attribute
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_app_group#value ApigeeAppGroup#value}
    */
    readonly value?: string;
}
export declare function apigeeAppGroupAttributesToTerraform(struct?: ApigeeAppGroupAttributes | cdktn.IResolvable): any;
export declare function apigeeAppGroupAttributesToHclTerraform(struct?: ApigeeAppGroupAttributes | cdktn.IResolvable): any;
export declare class ApigeeAppGroupAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigeeAppGroupAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeAppGroupAttributes | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApigeeAppGroupAttributesList extends cdktn.ComplexList {
    internalValue?: ApigeeAppGroupAttributes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigeeAppGroupAttributesOutputReference;
}
export interface ApigeeAppGroupTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_app_group#create ApigeeAppGroup#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_app_group#delete ApigeeAppGroup#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_app_group#update ApigeeAppGroup#update}
    */
    readonly update?: string;
}
export declare function apigeeAppGroupTimeoutsToTerraform(struct?: ApigeeAppGroupTimeouts | cdktn.IResolvable): any;
export declare function apigeeAppGroupTimeoutsToHclTerraform(struct?: ApigeeAppGroupTimeouts | cdktn.IResolvable): any;
export declare class ApigeeAppGroupTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeAppGroupTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeAppGroupTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_app_group google_apigee_app_group}
*/
export declare class ApigeeAppGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apigee_app_group";
    /**
    * Generates CDKTN code for importing a ApigeeAppGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigeeAppGroup to import
    * @param importFromId The id of the existing ApigeeAppGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_app_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigeeAppGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_app_group google_apigee_app_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigeeAppGroupConfig
    */
    constructor(scope: Construct, id: string, config: ApigeeAppGroupConfig);
    get appGroupId(): string;
    private _channelId?;
    get channelId(): string;
    set channelId(value: string);
    resetChannelId(): void;
    get channelIdInput(): string | undefined;
    private _channelUri?;
    get channelUri(): string;
    set channelUri(value: string);
    resetChannelUri(): void;
    get channelUriInput(): string | undefined;
    get createdAt(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastModifiedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _orgId?;
    get orgId(): string;
    set orgId(value: string);
    get orgIdInput(): string | undefined;
    get organization(): string;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _attributes;
    get attributes(): ApigeeAppGroupAttributesList;
    putAttributes(value: ApigeeAppGroupAttributes[] | cdktn.IResolvable): void;
    resetAttributes(): void;
    get attributesInput(): cdktn.IResolvable | ApigeeAppGroupAttributes[] | undefined;
    private _timeouts;
    get timeouts(): ApigeeAppGroupTimeoutsOutputReference;
    putTimeouts(value: ApigeeAppGroupTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApigeeAppGroupTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
