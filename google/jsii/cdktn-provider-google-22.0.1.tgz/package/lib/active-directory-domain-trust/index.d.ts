/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ActiveDirectoryDomainTrustConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/active_directory_domain_trust#deletion_policy ActiveDirectoryDomainTrust#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The fully qualified domain name. e.g. mydomain.myorganization.com, with the restrictions
    * of https://cloud.google.com/managed-microsoft-ad/reference/rest/v1/projects.locations.global.domains.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/active_directory_domain_trust#domain ActiveDirectoryDomainTrust#domain}
    */
    readonly domain: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/active_directory_domain_trust#id ActiveDirectoryDomainTrust#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/active_directory_domain_trust#project ActiveDirectoryDomainTrust#project}
    */
    readonly project?: string;
    /**
    * Whether the trusted side has forest/domain wide access or selective access to an approved set of resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/active_directory_domain_trust#selective_authentication ActiveDirectoryDomainTrust#selective_authentication}
    */
    readonly selectiveAuthentication?: boolean | cdktn.IResolvable;
    /**
    * The target DNS server IP addresses which can resolve the remote domain involved in the trust.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/active_directory_domain_trust#target_dns_ip_addresses ActiveDirectoryDomainTrust#target_dns_ip_addresses}
    */
    readonly targetDnsIpAddresses: string[];
    /**
    * The fully qualified target domain name which will be in trust with the current domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/active_directory_domain_trust#target_domain_name ActiveDirectoryDomainTrust#target_domain_name}
    */
    readonly targetDomainName: string;
    /**
    * The trust direction, which decides if the current domain is trusted, trusting, or both. Possible values: ["INBOUND", "OUTBOUND", "BIDIRECTIONAL"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/active_directory_domain_trust#trust_direction ActiveDirectoryDomainTrust#trust_direction}
    */
    readonly trustDirection: string;
    /**
    * The trust secret used for the handshake with the target domain. This will not be stored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/active_directory_domain_trust#trust_handshake_secret ActiveDirectoryDomainTrust#trust_handshake_secret}
    */
    readonly trustHandshakeSecret: string;
    /**
    * The type of trust represented by the trust resource. Possible values: ["FOREST", "EXTERNAL"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/active_directory_domain_trust#trust_type ActiveDirectoryDomainTrust#trust_type}
    */
    readonly trustType: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/active_directory_domain_trust#timeouts ActiveDirectoryDomainTrust#timeouts}
    */
    readonly timeouts?: ActiveDirectoryDomainTrustTimeouts;
}
export interface ActiveDirectoryDomainTrustTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/active_directory_domain_trust#create ActiveDirectoryDomainTrust#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/active_directory_domain_trust#delete ActiveDirectoryDomainTrust#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/active_directory_domain_trust#update ActiveDirectoryDomainTrust#update}
    */
    readonly update?: string;
}
export declare function activeDirectoryDomainTrustTimeoutsToTerraform(struct?: ActiveDirectoryDomainTrustTimeouts | cdktn.IResolvable): any;
export declare function activeDirectoryDomainTrustTimeoutsToHclTerraform(struct?: ActiveDirectoryDomainTrustTimeouts | cdktn.IResolvable): any;
export declare class ActiveDirectoryDomainTrustTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ActiveDirectoryDomainTrustTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ActiveDirectoryDomainTrustTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/active_directory_domain_trust google_active_directory_domain_trust}
*/
export declare class ActiveDirectoryDomainTrust extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_active_directory_domain_trust";
    /**
    * Generates CDKTN code for importing a ActiveDirectoryDomainTrust resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ActiveDirectoryDomainTrust to import
    * @param importFromId The id of the existing ActiveDirectoryDomainTrust that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/active_directory_domain_trust#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ActiveDirectoryDomainTrust to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/active_directory_domain_trust google_active_directory_domain_trust} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ActiveDirectoryDomainTrustConfig
    */
    constructor(scope: Construct, id: string, config: ActiveDirectoryDomainTrustConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    get domainInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _selectiveAuthentication?;
    get selectiveAuthentication(): boolean | cdktn.IResolvable;
    set selectiveAuthentication(value: boolean | cdktn.IResolvable);
    resetSelectiveAuthentication(): void;
    get selectiveAuthenticationInput(): boolean | cdktn.IResolvable | undefined;
    private _targetDnsIpAddresses?;
    get targetDnsIpAddresses(): string[];
    set targetDnsIpAddresses(value: string[]);
    get targetDnsIpAddressesInput(): string[] | undefined;
    private _targetDomainName?;
    get targetDomainName(): string;
    set targetDomainName(value: string);
    get targetDomainNameInput(): string | undefined;
    private _trustDirection?;
    get trustDirection(): string;
    set trustDirection(value: string);
    get trustDirectionInput(): string | undefined;
    private _trustHandshakeSecret?;
    get trustHandshakeSecret(): string;
    set trustHandshakeSecret(value: string);
    get trustHandshakeSecretInput(): string | undefined;
    private _trustType?;
    get trustType(): string;
    set trustType(value: string);
    get trustTypeInput(): string | undefined;
    private _timeouts;
    get timeouts(): ActiveDirectoryDomainTrustTimeoutsOutputReference;
    putTimeouts(value: ActiveDirectoryDomainTrustTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ActiveDirectoryDomainTrustTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
