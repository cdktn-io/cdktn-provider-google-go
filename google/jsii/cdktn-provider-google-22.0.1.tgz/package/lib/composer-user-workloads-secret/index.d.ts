/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComposerUserWorkloadsSecretConfig extends cdktn.TerraformMetaArguments {
    /**
    * A map of the secret data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/composer_user_workloads_secret#data ComposerUserWorkloadsSecret#data}
    */
    readonly data?: {
        [key: string]: string;
    };
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/composer_user_workloads_secret#deletion_policy ComposerUserWorkloadsSecret#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Name of the environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/composer_user_workloads_secret#environment ComposerUserWorkloadsSecret#environment}
    */
    readonly environment: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/composer_user_workloads_secret#id ComposerUserWorkloadsSecret#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the secret.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/composer_user_workloads_secret#name ComposerUserWorkloadsSecret#name}
    */
    readonly name: string;
    /**
    * The ID of the project in which the resource belongs. If it is not provided, the provider project is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/composer_user_workloads_secret#project ComposerUserWorkloadsSecret#project}
    */
    readonly project?: string;
    /**
    * The location or Compute Engine region for the environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/composer_user_workloads_secret#region ComposerUserWorkloadsSecret#region}
    */
    readonly region?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/composer_user_workloads_secret#timeouts ComposerUserWorkloadsSecret#timeouts}
    */
    readonly timeouts?: ComposerUserWorkloadsSecretTimeouts;
}
export interface ComposerUserWorkloadsSecretTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/composer_user_workloads_secret#create ComposerUserWorkloadsSecret#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/composer_user_workloads_secret#delete ComposerUserWorkloadsSecret#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/composer_user_workloads_secret#update ComposerUserWorkloadsSecret#update}
    */
    readonly update?: string;
}
export declare function composerUserWorkloadsSecretTimeoutsToTerraform(struct?: ComposerUserWorkloadsSecretTimeouts | cdktn.IResolvable): any;
export declare function composerUserWorkloadsSecretTimeoutsToHclTerraform(struct?: ComposerUserWorkloadsSecretTimeouts | cdktn.IResolvable): any;
export declare class ComposerUserWorkloadsSecretTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComposerUserWorkloadsSecretTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComposerUserWorkloadsSecretTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/composer_user_workloads_secret google_composer_user_workloads_secret}
*/
export declare class ComposerUserWorkloadsSecret extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_composer_user_workloads_secret";
    /**
    * Generates CDKTN code for importing a ComposerUserWorkloadsSecret resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComposerUserWorkloadsSecret to import
    * @param importFromId The id of the existing ComposerUserWorkloadsSecret that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/composer_user_workloads_secret#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComposerUserWorkloadsSecret to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/composer_user_workloads_secret google_composer_user_workloads_secret} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComposerUserWorkloadsSecretConfig
    */
    constructor(scope: Construct, id: string, config: ComposerUserWorkloadsSecretConfig);
    private _data?;
    get data(): {
        [key: string]: string;
    };
    set data(value: {
        [key: string]: string;
    });
    resetData(): void;
    get dataInput(): {
        [key: string]: string;
    } | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _environment?;
    get environment(): string;
    set environment(value: string);
    get environmentInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _timeouts;
    get timeouts(): ComposerUserWorkloadsSecretTimeoutsOutputReference;
    putTimeouts(value: ComposerUserWorkloadsSecretTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComposerUserWorkloadsSecretTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
