/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeRegionBackendServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Lifetime of cookies in seconds if session_affinity is
    * GENERATED_COOKIE. If set to 0, the cookie is non-persistent and lasts
    * only until the end of the browser session (or equivalent). The
    * maximum allowed value for TTL is one day.
    *
    * When the load balancing scheme is INTERNAL, this field is not used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#affinity_cookie_ttl_sec ComputeRegionBackendService#affinity_cookie_ttl_sec}
    */
    readonly affinityCookieTtlSec?: number;
    /**
    * Time for which instance will be drained (not accept new
    * connections, but still work to finish started).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#connection_draining_timeout_sec ComputeRegionBackendService#connection_draining_timeout_sec}
    */
    readonly connectionDrainingTimeoutSec?: number;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#deletion_policy ComputeRegionBackendService#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#description ComputeRegionBackendService#description}
    */
    readonly description?: string;
    /**
    * If true, enable Cloud CDN for this RegionBackendService.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#enable_cdn ComputeRegionBackendService#enable_cdn}
    */
    readonly enableCdn?: boolean | cdktn.IResolvable;
    /**
    * The set of URLs to HealthCheck resources for health checking
    * this RegionBackendService. Currently at most one health
    * check can be specified.
    *
    * A health check must be specified unless the backend service uses an internet
    * or serverless NEG as a backend.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#health_checks ComputeRegionBackendService#health_checks}
    */
    readonly healthChecks?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#id ComputeRegionBackendService#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies preference of traffic to the backend (from the proxy and from the client for proxyless gRPC). Possible values: ["IPV4_ONLY", "PREFER_IPV6", "IPV6_ONLY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#ip_address_selection_policy ComputeRegionBackendService#ip_address_selection_policy}
    */
    readonly ipAddressSelectionPolicy?: string;
    /**
    * Indicates what kind of load balancing this regional backend service
    * will be used for. A backend service created for one type of load
    * balancing cannot be used with the other(s). For more information, refer to
    * [Choosing a load balancer](https://cloud.google.com/load-balancing/docs/backend-service). Default value: "INTERNAL" Possible values: ["EXTERNAL", "EXTERNAL_MANAGED", "INTERNAL", "INTERNAL_MANAGED", "INTERNAL_SELF_MANAGED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#load_balancing_scheme ComputeRegionBackendService#load_balancing_scheme}
    */
    readonly loadBalancingScheme?: string;
    /**
    * The load balancing algorithm used within the scope of the locality.
    * The possible values are:
    *
    * * 'ROUND_ROBIN': This is a simple policy in which each healthy backend
    *                  is selected in round robin order.
    *
    * * 'LEAST_REQUEST': An O(1) algorithm which selects two random healthy
    *                    hosts and picks the host which has fewer active requests.
    *
    * * 'RING_HASH': The ring/modulo hash load balancer implements consistent
    *                hashing to backends. The algorithm has the property that the
    *                addition/removal of a host from a set of N hosts only affects
    *                1/N of the requests.
    *
    * * 'RANDOM': The load balancer selects a random healthy host.
    *
    * * 'ORIGINAL_DESTINATION': Backend host is selected based on the client
    *                           connection metadata, i.e., connections are opened
    *                           to the same address as the destination address of
    *                           the incoming connection before the connection
    *                           was redirected to the load balancer.
    *
    * * 'MAGLEV': used as a drop in replacement for the ring hash load balancer.
    *             Maglev is not as stable as ring hash but has faster table lookup
    *             build times and host selection times. For more information about
    *             Maglev, refer to https://ai.google/research/pubs/pub44824
    *
    * * 'WEIGHTED_MAGLEV': Per-instance weighted Load Balancing via health check
    *                      reported weights. Only applicable to loadBalancingScheme
    *                      EXTERNAL. If set, the Backend Service must
    *                      configure a non legacy HTTP-based Health Check, and
    *                      health check replies are expected to contain
    *                      non-standard HTTP response header field
    *                      X-Load-Balancing-Endpoint-Weight to specify the
    *                      per-instance weights. If set, Load Balancing is weight
    *                      based on the per-instance weights reported in the last
    *                      processed health check replies, as long as every
    *                      instance either reported a valid weight or had
    *                      UNAVAILABLE_WEIGHT. Otherwise, Load Balancing remains
    *                      equal-weight.
    *
    * * 'WEIGHTED_ROUND_ROBIN': Per-endpoint weighted round-robin Load Balancing using weights computed
    *                           from Backend reported Custom Metrics. If set, the Backend Service
    *                           responses are expected to contain non-standard HTTP response header field
    *                           X-Endpoint-Load-Metrics. The reported metrics
    *                           to use for computing the weights are specified via the
    *                           backends[].customMetrics fields.
    *
    * locality_lb_policy is applicable to either:
    *
    * * A regional backend service with the service_protocol set to HTTP, HTTPS, HTTP2 or H2C,
    *   and loadBalancingScheme set to INTERNAL_MANAGED.
    * * A global backend service with the load_balancing_scheme set to INTERNAL_SELF_MANAGED.
    * * A regional backend service with loadBalancingScheme set to EXTERNAL (External Network
    *   Load Balancing). Only MAGLEV and WEIGHTED_MAGLEV values are possible for External
    *   Network Load Balancing. The default is MAGLEV.
    *
    * If session_affinity is not NONE, and locality_lb_policy is not set to MAGLEV, WEIGHTED_MAGLEV,
    * or RING_HASH, session affinity settings will not take effect.
    *
    * Only ROUND_ROBIN and RING_HASH are supported when the backend service is referenced
    * by a URL map that is bound to target gRPC proxy that has validate_for_proxyless
    * field set to true. Possible values: ["ROUND_ROBIN", "LEAST_REQUEST", "RING_HASH", "RANDOM", "ORIGINAL_DESTINATION", "MAGLEV", "WEIGHTED_MAGLEV", "WEIGHTED_ROUND_ROBIN"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#locality_lb_policy ComputeRegionBackendService#locality_lb_policy}
    */
    readonly localityLbPolicy?: string;
    /**
    * Name of the resource. Provided by the client when the resource is
    * created. The name must be 1-63 characters long, and comply with
    * RFC1035. Specifically, the name must be 1-63 characters long and match
    * the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the
    * first character must be a lowercase letter, and all following
    * characters must be a dash, lowercase letter, or digit, except the last
    * character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#name ComputeRegionBackendService#name}
    */
    readonly name: string;
    /**
    * The URL of the network to which this backend service belongs.
    * This field must be set for Internal Passthrough Network Load Balancers when the haPolicy is enabled, and for External Passthrough Network Load Balancers when the haPolicy fastIpMove is enabled.
    * This field can only be specified when the load balancing scheme is set to INTERNAL, or when the load balancing scheme is set to EXTERNAL and haPolicy fastIpMove is enabled.
    * Changes to this field force recreation of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#network ComputeRegionBackendService#network}
    */
    readonly network?: string;
    /**
    * A named port on a backend instance group representing the port for
    * communication to the backend VMs in that group. Required when the
    * loadBalancingScheme is EXTERNAL, EXTERNAL_MANAGED, INTERNAL_MANAGED, or INTERNAL_SELF_MANAGED
    * and the backends are instance groups. The named port must be defined on each
    * backend instance group. This parameter has no meaning if the backends are NEGs. API sets a
    * default of "http" if not given.
    * Must be omitted when the loadBalancingScheme is INTERNAL (Internal TCP/UDP Load Balancing).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#port_name ComputeRegionBackendService#port_name}
    */
    readonly portName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#project ComputeRegionBackendService#project}
    */
    readonly project?: string;
    /**
    * The protocol this BackendService uses to communicate with backends.
    * The default is HTTP. Possible values are HTTP, HTTPS, HTTP2, H2C, TCP, SSL, UDP
    * or GRPC. Refer to the documentation for the load balancers or for Traffic Director
    * for more information. Possible values: ["HTTP", "HTTPS", "HTTP2", "TCP", "SSL", "UDP", "GRPC", "UNSPECIFIED", "H2C"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#protocol ComputeRegionBackendService#protocol}
    */
    readonly protocol?: string;
    /**
    * The Region in which the created backend service should reside.
    * If it is not provided, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#region ComputeRegionBackendService#region}
    */
    readonly region?: string;
    /**
    * The security policy associated with this backend service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#security_policy ComputeRegionBackendService#security_policy}
    */
    readonly securityPolicy?: string;
    /**
    * URL to networkservices.ServiceLbPolicy resource.
    * Can only be set if load balancing scheme is EXTERNAL_MANAGED, INTERNAL_MANAGED or INTERNAL_SELF_MANAGED.
    * The service lb policy must be regional and in the same region as the backend service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#service_lb_policy ComputeRegionBackendService#service_lb_policy}
    */
    readonly serviceLbPolicy?: string;
    /**
    * Type of session affinity to use. The default is NONE. Session affinity is
    * not applicable if the protocol is UDP. Possible values: ["NONE", "CLIENT_IP", "CLIENT_IP_PORT_PROTO", "CLIENT_IP_PROTO", "GENERATED_COOKIE", "HEADER_FIELD", "HTTP_COOKIE", "CLIENT_IP_NO_DESTINATION", "STRONG_COOKIE_AFFINITY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#session_affinity ComputeRegionBackendService#session_affinity}
    */
    readonly sessionAffinity?: string;
    /**
    * The backend service timeout has a different meaning depending on the type of load balancer.
    * For more information see, [Backend service settings](https://cloud.google.com/compute/docs/reference/rest/v1/backendServices).
    * The default is 30 seconds.
    * The full range of timeout values allowed goes from 1 through 2,147,483,647 seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#timeout_sec ComputeRegionBackendService#timeout_sec}
    */
    readonly timeoutSec?: number;
    /**
    * backend block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#backend ComputeRegionBackendService#backend}
    */
    readonly backend?: ComputeRegionBackendServiceBackend[] | cdktn.IResolvable;
    /**
    * cdn_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#cdn_policy ComputeRegionBackendService#cdn_policy}
    */
    readonly cdnPolicy?: ComputeRegionBackendServiceCdnPolicy;
    /**
    * circuit_breakers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#circuit_breakers ComputeRegionBackendService#circuit_breakers}
    */
    readonly circuitBreakers?: ComputeRegionBackendServiceCircuitBreakers;
    /**
    * connection_tracking_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#connection_tracking_policy ComputeRegionBackendService#connection_tracking_policy}
    */
    readonly connectionTrackingPolicy?: ComputeRegionBackendServiceConnectionTrackingPolicy;
    /**
    * consistent_hash block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#consistent_hash ComputeRegionBackendService#consistent_hash}
    */
    readonly consistentHash?: ComputeRegionBackendServiceConsistentHash;
    /**
    * custom_metrics block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#custom_metrics ComputeRegionBackendService#custom_metrics}
    */
    readonly customMetrics?: ComputeRegionBackendServiceCustomMetrics[] | cdktn.IResolvable;
    /**
    * failover_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#failover_policy ComputeRegionBackendService#failover_policy}
    */
    readonly failoverPolicy?: ComputeRegionBackendServiceFailoverPolicy;
    /**
    * ha_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#ha_policy ComputeRegionBackendService#ha_policy}
    */
    readonly haPolicy?: ComputeRegionBackendServiceHaPolicy;
    /**
    * iap block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#iap ComputeRegionBackendService#iap}
    */
    readonly iap?: ComputeRegionBackendServiceIap;
    /**
    * log_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#log_config ComputeRegionBackendService#log_config}
    */
    readonly logConfig?: ComputeRegionBackendServiceLogConfig;
    /**
    * network_pass_through_lb_traffic_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#network_pass_through_lb_traffic_policy ComputeRegionBackendService#network_pass_through_lb_traffic_policy}
    */
    readonly networkPassThroughLbTrafficPolicy?: ComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicy;
    /**
    * outlier_detection block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#outlier_detection ComputeRegionBackendService#outlier_detection}
    */
    readonly outlierDetection?: ComputeRegionBackendServiceOutlierDetection;
    /**
    * params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#params ComputeRegionBackendService#params}
    */
    readonly params?: ComputeRegionBackendServiceParams;
    /**
    * strong_session_affinity_cookie block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#strong_session_affinity_cookie ComputeRegionBackendService#strong_session_affinity_cookie}
    */
    readonly strongSessionAffinityCookie?: ComputeRegionBackendServiceStrongSessionAffinityCookie;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#timeouts ComputeRegionBackendService#timeouts}
    */
    readonly timeouts?: ComputeRegionBackendServiceTimeouts;
    /**
    * tls_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#tls_settings ComputeRegionBackendService#tls_settings}
    */
    readonly tlsSettings?: ComputeRegionBackendServiceTlsSettings;
}
export interface ComputeRegionBackendServiceBackendCustomMetrics {
    /**
    * If true, the metric data is collected and reported to Cloud
    * Monitoring, but is not used for load balancing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#dry_run ComputeRegionBackendService#dry_run}
    */
    readonly dryRun: boolean | cdktn.IResolvable;
    /**
    * Optional parameter to define a target utilization for the Custom Metrics
    * balancing mode. The valid range is <code>[0.0, 1.0]</code>.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#max_utilization ComputeRegionBackendService#max_utilization}
    */
    readonly maxUtilization?: number;
    /**
    * Name of a custom utilization signal. The name must be 1-64 characters
    * long and match the regular expression [a-z]([-_.a-z0-9]*[a-z0-9])? which
    * means the first character must be a lowercase letter, and all following
    * characters must be a dash, period, underscore, lowercase letter, or
    * digit, except the last character, which cannot be a dash, period, or
    * underscore. For usage guidelines, see Custom Metrics balancing mode. This
    * field can only be used for a global or regional backend service with the
    * loadBalancingScheme set to <code>EXTERNAL_MANAGED</code>,
    * <code>INTERNAL_MANAGED</code> <code>INTERNAL_SELF_MANAGED</code>.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#name ComputeRegionBackendService#name}
    */
    readonly name: string;
}
export declare function computeRegionBackendServiceBackendCustomMetricsToTerraform(struct?: ComputeRegionBackendServiceBackendCustomMetrics | cdktn.IResolvable): any;
export declare function computeRegionBackendServiceBackendCustomMetricsToHclTerraform(struct?: ComputeRegionBackendServiceBackendCustomMetrics | cdktn.IResolvable): any;
export declare class ComputeRegionBackendServiceBackendCustomMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionBackendServiceBackendCustomMetrics | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionBackendServiceBackendCustomMetrics | cdktn.IResolvable | undefined);
    private _dryRun?;
    get dryRun(): boolean | cdktn.IResolvable;
    set dryRun(value: boolean | cdktn.IResolvable);
    get dryRunInput(): boolean | cdktn.IResolvable | undefined;
    private _maxUtilization?;
    get maxUtilization(): number;
    set maxUtilization(value: number);
    resetMaxUtilization(): void;
    get maxUtilizationInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class ComputeRegionBackendServiceBackendCustomMetricsList extends cdktn.ComplexList {
    internalValue?: ComputeRegionBackendServiceBackendCustomMetrics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionBackendServiceBackendCustomMetricsOutputReference;
}
export interface ComputeRegionBackendServiceBackend {
    /**
    * Specifies the balancing mode for this backend.
    *
    * See the [Backend Services Overview](https://cloud.google.com/load-balancing/docs/backend-service#balancing-mode)
    * for an explanation of load balancing modes. Default value: "UTILIZATION" Possible values: ["UTILIZATION", "RATE", "CONNECTION", "CUSTOM_METRICS", "IN_FLIGHT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#balancing_mode ComputeRegionBackendService#balancing_mode}
    */
    readonly balancingMode?: string;
    /**
    * A multiplier applied to the group's maximum servicing capacity
    * (based on UTILIZATION, RATE or CONNECTION).
    *
    * ~>**NOTE**: This field cannot be set for
    * INTERNAL region backend services (default loadBalancingScheme),
    * but is required for non-INTERNAL backend service. The total
    * capacity_scaler for all backends must be non-zero.
    *
    * A setting of 0 means the group is completely drained, offering
    * 0% of its available Capacity. Valid range is [0.0,1.0].
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#capacity_scaler ComputeRegionBackendService#capacity_scaler}
    */
    readonly capacityScaler?: number;
    /**
    * An optional description of this resource.
    * Provide this property when you create the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#description ComputeRegionBackendService#description}
    */
    readonly description?: string;
    /**
    * This field designates whether this is a failover backend. More
    * than one failover backend can be configured for a given RegionBackendService.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#failover ComputeRegionBackendService#failover}
    */
    readonly failover?: boolean | cdktn.IResolvable;
    /**
    * The fully-qualified URL of an Instance Group or Network Endpoint
    * Group resource. In case of instance group this defines the list
    * of instances that serve traffic. Member virtual machine
    * instances from each instance group must live in the same zone as
    * the instance group itself. No two backends in a backend service
    * are allowed to use same Instance Group resource.
    *
    * For Network Endpoint Groups this defines list of endpoints. All
    * endpoints of Network Endpoint Group must be hosted on instances
    * located in the same zone as the Network Endpoint Group.
    *
    * Backend services cannot mix Instance Group and
    * Network Endpoint Group backends.
    *
    * When the 'load_balancing_scheme' is INTERNAL, only instance groups
    * are supported.
    *
    * Note that you must specify an Instance Group or Network Endpoint
    * Group resource using the fully-qualified URL, rather than a
    * partial URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#group ComputeRegionBackendService#group}
    */
    readonly group: string;
    /**
    * The max number of simultaneous connections for the group. Can
    * be used with either CONNECTION or UTILIZATION balancing modes.
    * Cannot be set for INTERNAL backend services.
    *
    * For CONNECTION mode, either maxConnections or one
    * of maxConnectionsPerInstance or maxConnectionsPerEndpoint,
    * as appropriate for group type, must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#max_connections ComputeRegionBackendService#max_connections}
    */
    readonly maxConnections?: number;
    /**
    * The max number of simultaneous connections that a single backend
    * network endpoint can handle. Cannot be set
    * for INTERNAL backend services.
    *
    * This is used to calculate the capacity of the group. Can be
    * used in either CONNECTION or UTILIZATION balancing modes. For
    * CONNECTION mode, either maxConnections or
    * maxConnectionsPerEndpoint must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#max_connections_per_endpoint ComputeRegionBackendService#max_connections_per_endpoint}
    */
    readonly maxConnectionsPerEndpoint?: number;
    /**
    * The max number of simultaneous connections that a single
    * backend instance can handle. Cannot be set for INTERNAL backend
    * services.
    *
    * This is used to calculate the capacity of the group.
    * Can be used in either CONNECTION or UTILIZATION balancing modes.
    * For CONNECTION mode, either maxConnections or
    * maxConnectionsPerInstance must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#max_connections_per_instance ComputeRegionBackendService#max_connections_per_instance}
    */
    readonly maxConnectionsPerInstance?: number;
    /**
    * The max requests per second (RPS) of the group. Cannot be set
    * for INTERNAL backend services.
    *
    * Can be used with either RATE or UTILIZATION balancing modes,
    * but required if RATE mode. Either maxRate or one
    * of maxRatePerInstance or maxRatePerEndpoint, as appropriate for
    * group type, must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#max_rate ComputeRegionBackendService#max_rate}
    */
    readonly maxRate?: number;
    /**
    * The max requests per second (RPS) that a single backend network
    * endpoint can handle. This is used to calculate the capacity of
    * the group. Can be used in either balancing mode. For RATE mode,
    * either maxRate or maxRatePerEndpoint must be set. Cannot be set
    * for INTERNAL backend services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#max_rate_per_endpoint ComputeRegionBackendService#max_rate_per_endpoint}
    */
    readonly maxRatePerEndpoint?: number;
    /**
    * The max requests per second (RPS) that a single backend
    * instance can handle. This is used to calculate the capacity of
    * the group. Can be used in either balancing mode. For RATE mode,
    * either maxRate or maxRatePerInstance must be set. Cannot be set
    * for INTERNAL backend services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#max_rate_per_instance ComputeRegionBackendService#max_rate_per_instance}
    */
    readonly maxRatePerInstance?: number;
    /**
    * Used when balancingMode is UTILIZATION. This ratio defines the
    * CPU utilization target for the group. Valid range is [0.0, 1.0].
    * Cannot be set for INTERNAL backend services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#max_utilization ComputeRegionBackendService#max_utilization}
    */
    readonly maxUtilization?: number;
    /**
    * custom_metrics block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#custom_metrics ComputeRegionBackendService#custom_metrics}
    */
    readonly customMetrics?: ComputeRegionBackendServiceBackendCustomMetrics[] | cdktn.IResolvable;
}
export declare function computeRegionBackendServiceBackendToTerraform(struct?: ComputeRegionBackendServiceBackend | cdktn.IResolvable): any;
export declare function computeRegionBackendServiceBackendToHclTerraform(struct?: ComputeRegionBackendServiceBackend | cdktn.IResolvable): any;
export declare class ComputeRegionBackendServiceBackendOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionBackendServiceBackend | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionBackendServiceBackend | cdktn.IResolvable | undefined);
    private _balancingMode?;
    get balancingMode(): string;
    set balancingMode(value: string);
    resetBalancingMode(): void;
    get balancingModeInput(): string | undefined;
    private _capacityScaler?;
    get capacityScaler(): number;
    set capacityScaler(value: number);
    resetCapacityScaler(): void;
    get capacityScalerInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _failover?;
    get failover(): boolean | cdktn.IResolvable;
    set failover(value: boolean | cdktn.IResolvable);
    resetFailover(): void;
    get failoverInput(): boolean | cdktn.IResolvable | undefined;
    private _group?;
    get group(): string;
    set group(value: string);
    get groupInput(): string | undefined;
    private _maxConnections?;
    get maxConnections(): number;
    set maxConnections(value: number);
    resetMaxConnections(): void;
    get maxConnectionsInput(): number | undefined;
    private _maxConnectionsPerEndpoint?;
    get maxConnectionsPerEndpoint(): number;
    set maxConnectionsPerEndpoint(value: number);
    resetMaxConnectionsPerEndpoint(): void;
    get maxConnectionsPerEndpointInput(): number | undefined;
    private _maxConnectionsPerInstance?;
    get maxConnectionsPerInstance(): number;
    set maxConnectionsPerInstance(value: number);
    resetMaxConnectionsPerInstance(): void;
    get maxConnectionsPerInstanceInput(): number | undefined;
    private _maxRate?;
    get maxRate(): number;
    set maxRate(value: number);
    resetMaxRate(): void;
    get maxRateInput(): number | undefined;
    private _maxRatePerEndpoint?;
    get maxRatePerEndpoint(): number;
    set maxRatePerEndpoint(value: number);
    resetMaxRatePerEndpoint(): void;
    get maxRatePerEndpointInput(): number | undefined;
    private _maxRatePerInstance?;
    get maxRatePerInstance(): number;
    set maxRatePerInstance(value: number);
    resetMaxRatePerInstance(): void;
    get maxRatePerInstanceInput(): number | undefined;
    private _maxUtilization?;
    get maxUtilization(): number;
    set maxUtilization(value: number);
    resetMaxUtilization(): void;
    get maxUtilizationInput(): number | undefined;
    private _customMetrics;
    get customMetrics(): ComputeRegionBackendServiceBackendCustomMetricsList;
    putCustomMetrics(value: ComputeRegionBackendServiceBackendCustomMetrics[] | cdktn.IResolvable): void;
    resetCustomMetrics(): void;
    get customMetricsInput(): cdktn.IResolvable | ComputeRegionBackendServiceBackendCustomMetrics[] | undefined;
}
export declare class ComputeRegionBackendServiceBackendList extends cdktn.ComplexList {
    internalValue?: ComputeRegionBackendServiceBackend[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionBackendServiceBackendOutputReference;
}
export interface ComputeRegionBackendServiceCdnPolicyCacheKeyPolicy {
    /**
    * If true requests to different hosts will be cached separately.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#include_host ComputeRegionBackendService#include_host}
    */
    readonly includeHost?: boolean | cdktn.IResolvable;
    /**
    * Names of cookies to include in cache keys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#include_named_cookies ComputeRegionBackendService#include_named_cookies}
    */
    readonly includeNamedCookies?: string[];
    /**
    * If true, http and https requests will be cached separately.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#include_protocol ComputeRegionBackendService#include_protocol}
    */
    readonly includeProtocol?: boolean | cdktn.IResolvable;
    /**
    * If true, include query string parameters in the cache key
    * according to query_string_whitelist and
    * query_string_blacklist. If neither is set, the entire query
    * string will be included.
    *
    * If false, the query string will be excluded from the cache
    * key entirely.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#include_query_string ComputeRegionBackendService#include_query_string}
    */
    readonly includeQueryString?: boolean | cdktn.IResolvable;
    /**
    * Names of query string parameters to exclude in cache keys.
    *
    * All other parameters will be included. Either specify
    * query_string_whitelist or query_string_blacklist, not both.
    * '&' and '=' will be percent encoded and not treated as
    * delimiters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#query_string_blacklist ComputeRegionBackendService#query_string_blacklist}
    */
    readonly queryStringBlacklist?: string[];
    /**
    * Names of query string parameters to include in cache keys.
    *
    * All other parameters will be excluded. Either specify
    * query_string_whitelist or query_string_blacklist, not both.
    * '&' and '=' will be percent encoded and not treated as
    * delimiters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#query_string_whitelist ComputeRegionBackendService#query_string_whitelist}
    */
    readonly queryStringWhitelist?: string[];
}
export declare function computeRegionBackendServiceCdnPolicyCacheKeyPolicyToTerraform(struct?: ComputeRegionBackendServiceCdnPolicyCacheKeyPolicyOutputReference | ComputeRegionBackendServiceCdnPolicyCacheKeyPolicy): any;
export declare function computeRegionBackendServiceCdnPolicyCacheKeyPolicyToHclTerraform(struct?: ComputeRegionBackendServiceCdnPolicyCacheKeyPolicyOutputReference | ComputeRegionBackendServiceCdnPolicyCacheKeyPolicy): any;
export declare class ComputeRegionBackendServiceCdnPolicyCacheKeyPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionBackendServiceCdnPolicyCacheKeyPolicy | undefined;
    set internalValue(value: ComputeRegionBackendServiceCdnPolicyCacheKeyPolicy | undefined);
    private _includeHost?;
    get includeHost(): boolean | cdktn.IResolvable;
    set includeHost(value: boolean | cdktn.IResolvable);
    resetIncludeHost(): void;
    get includeHostInput(): boolean | cdktn.IResolvable | undefined;
    private _includeNamedCookies?;
    get includeNamedCookies(): string[];
    set includeNamedCookies(value: string[]);
    resetIncludeNamedCookies(): void;
    get includeNamedCookiesInput(): string[] | undefined;
    private _includeProtocol?;
    get includeProtocol(): boolean | cdktn.IResolvable;
    set includeProtocol(value: boolean | cdktn.IResolvable);
    resetIncludeProtocol(): void;
    get includeProtocolInput(): boolean | cdktn.IResolvable | undefined;
    private _includeQueryString?;
    get includeQueryString(): boolean | cdktn.IResolvable;
    set includeQueryString(value: boolean | cdktn.IResolvable);
    resetIncludeQueryString(): void;
    get includeQueryStringInput(): boolean | cdktn.IResolvable | undefined;
    private _queryStringBlacklist?;
    get queryStringBlacklist(): string[];
    set queryStringBlacklist(value: string[]);
    resetQueryStringBlacklist(): void;
    get queryStringBlacklistInput(): string[] | undefined;
    private _queryStringWhitelist?;
    get queryStringWhitelist(): string[];
    set queryStringWhitelist(value: string[]);
    resetQueryStringWhitelist(): void;
    get queryStringWhitelistInput(): string[] | undefined;
}
export interface ComputeRegionBackendServiceCdnPolicyNegativeCachingPolicy {
    /**
    * The HTTP status code to define a TTL against. Only HTTP status codes 300, 301, 308, 404, 405, 410, 421, 451 and 501
    * can be specified as values, and you cannot specify a status code more than once.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#code ComputeRegionBackendService#code}
    */
    readonly code?: number;
}
export declare function computeRegionBackendServiceCdnPolicyNegativeCachingPolicyToTerraform(struct?: ComputeRegionBackendServiceCdnPolicyNegativeCachingPolicy | cdktn.IResolvable): any;
export declare function computeRegionBackendServiceCdnPolicyNegativeCachingPolicyToHclTerraform(struct?: ComputeRegionBackendServiceCdnPolicyNegativeCachingPolicy | cdktn.IResolvable): any;
export declare class ComputeRegionBackendServiceCdnPolicyNegativeCachingPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionBackendServiceCdnPolicyNegativeCachingPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionBackendServiceCdnPolicyNegativeCachingPolicy | cdktn.IResolvable | undefined);
    private _code?;
    get code(): number;
    set code(value: number);
    resetCode(): void;
    get codeInput(): number | undefined;
}
export declare class ComputeRegionBackendServiceCdnPolicyNegativeCachingPolicyList extends cdktn.ComplexList {
    internalValue?: ComputeRegionBackendServiceCdnPolicyNegativeCachingPolicy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionBackendServiceCdnPolicyNegativeCachingPolicyOutputReference;
}
export interface ComputeRegionBackendServiceCdnPolicy {
    /**
    * Specifies the cache setting for all responses from this backend.
    * The possible values are: USE_ORIGIN_HEADERS, FORCE_CACHE_ALL and CACHE_ALL_STATIC Possible values: ["USE_ORIGIN_HEADERS", "FORCE_CACHE_ALL", "CACHE_ALL_STATIC"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#cache_mode ComputeRegionBackendService#cache_mode}
    */
    readonly cacheMode?: string;
    /**
    * Specifies the maximum allowed TTL for cached content served by this origin.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#client_ttl ComputeRegionBackendService#client_ttl}
    */
    readonly clientTtl?: number;
    /**
    * Specifies the default TTL for cached content served by this origin for responses
    * that do not have an existing valid TTL (max-age or s-max-age).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#default_ttl ComputeRegionBackendService#default_ttl}
    */
    readonly defaultTtl?: number;
    /**
    * Specifies the maximum allowed TTL for cached content served by this origin.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#max_ttl ComputeRegionBackendService#max_ttl}
    */
    readonly maxTtl?: number;
    /**
    * Negative caching allows per-status code TTLs to be set, in order to apply fine-grained caching for common errors or redirects.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#negative_caching ComputeRegionBackendService#negative_caching}
    */
    readonly negativeCaching?: boolean | cdktn.IResolvable;
    /**
    * Serve existing content from the cache (if available) when revalidating content with the origin, or when an error is encountered when refreshing the cache.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#serve_while_stale ComputeRegionBackendService#serve_while_stale}
    */
    readonly serveWhileStale?: number;
    /**
    * Maximum number of seconds the response to a signed URL request
    * will be considered fresh, defaults to 1hr (3600s). After this
    * time period, the response will be revalidated before
    * being served.
    *
    * When serving responses to signed URL requests, Cloud CDN will
    * internally behave as though all responses from this backend had a
    * "Cache-Control: public, max-age=[TTL]" header, regardless of any
    * existing Cache-Control header. The actual headers served in
    * responses will not be altered.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#signed_url_cache_max_age_sec ComputeRegionBackendService#signed_url_cache_max_age_sec}
    */
    readonly signedUrlCacheMaxAgeSec?: number;
    /**
    * cache_key_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#cache_key_policy ComputeRegionBackendService#cache_key_policy}
    */
    readonly cacheKeyPolicy?: ComputeRegionBackendServiceCdnPolicyCacheKeyPolicy;
    /**
    * negative_caching_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#negative_caching_policy ComputeRegionBackendService#negative_caching_policy}
    */
    readonly negativeCachingPolicy?: ComputeRegionBackendServiceCdnPolicyNegativeCachingPolicy[] | cdktn.IResolvable;
}
export declare function computeRegionBackendServiceCdnPolicyToTerraform(struct?: ComputeRegionBackendServiceCdnPolicyOutputReference | ComputeRegionBackendServiceCdnPolicy): any;
export declare function computeRegionBackendServiceCdnPolicyToHclTerraform(struct?: ComputeRegionBackendServiceCdnPolicyOutputReference | ComputeRegionBackendServiceCdnPolicy): any;
export declare class ComputeRegionBackendServiceCdnPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionBackendServiceCdnPolicy | undefined;
    set internalValue(value: ComputeRegionBackendServiceCdnPolicy | undefined);
    private _cacheMode?;
    get cacheMode(): string;
    set cacheMode(value: string);
    resetCacheMode(): void;
    get cacheModeInput(): string | undefined;
    private _clientTtl?;
    get clientTtl(): number;
    set clientTtl(value: number);
    resetClientTtl(): void;
    get clientTtlInput(): number | undefined;
    private _defaultTtl?;
    get defaultTtl(): number;
    set defaultTtl(value: number);
    resetDefaultTtl(): void;
    get defaultTtlInput(): number | undefined;
    private _maxTtl?;
    get maxTtl(): number;
    set maxTtl(value: number);
    resetMaxTtl(): void;
    get maxTtlInput(): number | undefined;
    private _negativeCaching?;
    get negativeCaching(): boolean | cdktn.IResolvable;
    set negativeCaching(value: boolean | cdktn.IResolvable);
    resetNegativeCaching(): void;
    get negativeCachingInput(): boolean | cdktn.IResolvable | undefined;
    private _serveWhileStale?;
    get serveWhileStale(): number;
    set serveWhileStale(value: number);
    resetServeWhileStale(): void;
    get serveWhileStaleInput(): number | undefined;
    private _signedUrlCacheMaxAgeSec?;
    get signedUrlCacheMaxAgeSec(): number;
    set signedUrlCacheMaxAgeSec(value: number);
    resetSignedUrlCacheMaxAgeSec(): void;
    get signedUrlCacheMaxAgeSecInput(): number | undefined;
    private _cacheKeyPolicy;
    get cacheKeyPolicy(): ComputeRegionBackendServiceCdnPolicyCacheKeyPolicyOutputReference;
    putCacheKeyPolicy(value: ComputeRegionBackendServiceCdnPolicyCacheKeyPolicy): void;
    resetCacheKeyPolicy(): void;
    get cacheKeyPolicyInput(): ComputeRegionBackendServiceCdnPolicyCacheKeyPolicy | undefined;
    private _negativeCachingPolicy;
    get negativeCachingPolicy(): ComputeRegionBackendServiceCdnPolicyNegativeCachingPolicyList;
    putNegativeCachingPolicy(value: ComputeRegionBackendServiceCdnPolicyNegativeCachingPolicy[] | cdktn.IResolvable): void;
    resetNegativeCachingPolicy(): void;
    get negativeCachingPolicyInput(): cdktn.IResolvable | ComputeRegionBackendServiceCdnPolicyNegativeCachingPolicy[] | undefined;
}
export interface ComputeRegionBackendServiceCircuitBreakers {
    /**
    * The maximum number of connections to the backend cluster.
    * Defaults to 1024.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#max_connections ComputeRegionBackendService#max_connections}
    */
    readonly maxConnections?: number;
    /**
    * The maximum number of pending requests to the backend cluster.
    * Defaults to 1024.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#max_pending_requests ComputeRegionBackendService#max_pending_requests}
    */
    readonly maxPendingRequests?: number;
    /**
    * The maximum number of parallel requests to the backend cluster.
    * Defaults to 1024.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#max_requests ComputeRegionBackendService#max_requests}
    */
    readonly maxRequests?: number;
    /**
    * Maximum requests for a single backend connection. This parameter
    * is respected by both the HTTP/1.1 and HTTP/2 implementations. If
    * not specified, there is no limit. Setting this parameter to 1
    * will effectively disable keep alive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#max_requests_per_connection ComputeRegionBackendService#max_requests_per_connection}
    */
    readonly maxRequestsPerConnection?: number;
    /**
    * The maximum number of parallel retries to the backend cluster.
    * Defaults to 3.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#max_retries ComputeRegionBackendService#max_retries}
    */
    readonly maxRetries?: number;
}
export declare function computeRegionBackendServiceCircuitBreakersToTerraform(struct?: ComputeRegionBackendServiceCircuitBreakersOutputReference | ComputeRegionBackendServiceCircuitBreakers): any;
export declare function computeRegionBackendServiceCircuitBreakersToHclTerraform(struct?: ComputeRegionBackendServiceCircuitBreakersOutputReference | ComputeRegionBackendServiceCircuitBreakers): any;
export declare class ComputeRegionBackendServiceCircuitBreakersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionBackendServiceCircuitBreakers | undefined;
    set internalValue(value: ComputeRegionBackendServiceCircuitBreakers | undefined);
    private _maxConnections?;
    get maxConnections(): number;
    set maxConnections(value: number);
    resetMaxConnections(): void;
    get maxConnectionsInput(): number | undefined;
    private _maxPendingRequests?;
    get maxPendingRequests(): number;
    set maxPendingRequests(value: number);
    resetMaxPendingRequests(): void;
    get maxPendingRequestsInput(): number | undefined;
    private _maxRequests?;
    get maxRequests(): number;
    set maxRequests(value: number);
    resetMaxRequests(): void;
    get maxRequestsInput(): number | undefined;
    private _maxRequestsPerConnection?;
    get maxRequestsPerConnection(): number;
    set maxRequestsPerConnection(value: number);
    resetMaxRequestsPerConnection(): void;
    get maxRequestsPerConnectionInput(): number | undefined;
    private _maxRetries?;
    get maxRetries(): number;
    set maxRetries(value: number);
    resetMaxRetries(): void;
    get maxRetriesInput(): number | undefined;
}
export interface ComputeRegionBackendServiceConnectionTrackingPolicy {
    /**
    * Specifies connection persistence when backends are unhealthy.
    *
    * If set to 'DEFAULT_FOR_PROTOCOL', the existing connections persist on
    * unhealthy backends only for connection-oriented protocols (TCP and SCTP)
    * and only if the Tracking Mode is PER_CONNECTION (default tracking mode)
    * or the Session Affinity is configured for 5-tuple. They do not persist
    * for UDP.
    *
    * If set to 'NEVER_PERSIST', after a backend becomes unhealthy, the existing
    * connections on the unhealthy backend are never persisted on the unhealthy
    * backend. They are always diverted to newly selected healthy backends
    * (unless all backends are unhealthy).
    *
    * If set to 'ALWAYS_PERSIST', existing connections always persist on
    * unhealthy backends regardless of protocol and session affinity. It is
    * generally not recommended to use this mode overriding the default. Default value: "DEFAULT_FOR_PROTOCOL" Possible values: ["DEFAULT_FOR_PROTOCOL", "NEVER_PERSIST", "ALWAYS_PERSIST"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#connection_persistence_on_unhealthy_backends ComputeRegionBackendService#connection_persistence_on_unhealthy_backends}
    */
    readonly connectionPersistenceOnUnhealthyBackends?: string;
    /**
    * Enable Strong Session Affinity for Network Load Balancing. This option is not available publicly.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#enable_strong_affinity ComputeRegionBackendService#enable_strong_affinity}
    */
    readonly enableStrongAffinity?: boolean | cdktn.IResolvable;
    /**
    * Specifies how long to keep a Connection Tracking entry while there is
    * no matching traffic (in seconds).
    *
    * For L4 ILB the minimum(default) is 10 minutes and maximum is 16 hours.
    *
    * For NLB the minimum(default) is 60 seconds and the maximum is 16 hours.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#idle_timeout_sec ComputeRegionBackendService#idle_timeout_sec}
    */
    readonly idleTimeoutSec?: number;
    /**
    * Specifies the key used for connection tracking. There are two options:
    * 'PER_CONNECTION': The Connection Tracking is performed as per the
    * Connection Key (default Hash Method) for the specific protocol.
    *
    * 'PER_SESSION': The Connection Tracking is performed as per the
    * configured Session Affinity. It matches the configured Session Affinity. Default value: "PER_CONNECTION" Possible values: ["PER_CONNECTION", "PER_SESSION"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#tracking_mode ComputeRegionBackendService#tracking_mode}
    */
    readonly trackingMode?: string;
}
export declare function computeRegionBackendServiceConnectionTrackingPolicyToTerraform(struct?: ComputeRegionBackendServiceConnectionTrackingPolicyOutputReference | ComputeRegionBackendServiceConnectionTrackingPolicy): any;
export declare function computeRegionBackendServiceConnectionTrackingPolicyToHclTerraform(struct?: ComputeRegionBackendServiceConnectionTrackingPolicyOutputReference | ComputeRegionBackendServiceConnectionTrackingPolicy): any;
export declare class ComputeRegionBackendServiceConnectionTrackingPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionBackendServiceConnectionTrackingPolicy | undefined;
    set internalValue(value: ComputeRegionBackendServiceConnectionTrackingPolicy | undefined);
    private _connectionPersistenceOnUnhealthyBackends?;
    get connectionPersistenceOnUnhealthyBackends(): string;
    set connectionPersistenceOnUnhealthyBackends(value: string);
    resetConnectionPersistenceOnUnhealthyBackends(): void;
    get connectionPersistenceOnUnhealthyBackendsInput(): string | undefined;
    private _enableStrongAffinity?;
    get enableStrongAffinity(): boolean | cdktn.IResolvable;
    set enableStrongAffinity(value: boolean | cdktn.IResolvable);
    resetEnableStrongAffinity(): void;
    get enableStrongAffinityInput(): boolean | cdktn.IResolvable | undefined;
    private _idleTimeoutSec?;
    get idleTimeoutSec(): number;
    set idleTimeoutSec(value: number);
    resetIdleTimeoutSec(): void;
    get idleTimeoutSecInput(): number | undefined;
    private _trackingMode?;
    get trackingMode(): string;
    set trackingMode(value: string);
    resetTrackingMode(): void;
    get trackingModeInput(): string | undefined;
}
export interface ComputeRegionBackendServiceConsistentHashHttpCookieTtl {
    /**
    * Span of time that's a fraction of a second at nanosecond
    * resolution. Durations less than one second are represented
    * with a 0 seconds field and a positive nanos field. Must
    * be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#nanos ComputeRegionBackendService#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second.
    * Must be from 0 to 315,576,000,000 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#seconds ComputeRegionBackendService#seconds}
    */
    readonly seconds: number;
}
export declare function computeRegionBackendServiceConsistentHashHttpCookieTtlToTerraform(struct?: ComputeRegionBackendServiceConsistentHashHttpCookieTtlOutputReference | ComputeRegionBackendServiceConsistentHashHttpCookieTtl): any;
export declare function computeRegionBackendServiceConsistentHashHttpCookieTtlToHclTerraform(struct?: ComputeRegionBackendServiceConsistentHashHttpCookieTtlOutputReference | ComputeRegionBackendServiceConsistentHashHttpCookieTtl): any;
export declare class ComputeRegionBackendServiceConsistentHashHttpCookieTtlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionBackendServiceConsistentHashHttpCookieTtl | undefined;
    set internalValue(value: ComputeRegionBackendServiceConsistentHashHttpCookieTtl | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): number;
    set seconds(value: number);
    get secondsInput(): number | undefined;
}
export interface ComputeRegionBackendServiceConsistentHashHttpCookie {
    /**
    * Name of the cookie.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#name ComputeRegionBackendService#name}
    */
    readonly name?: string;
    /**
    * Path to set for the cookie.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#path ComputeRegionBackendService#path}
    */
    readonly path?: string;
    /**
    * ttl block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#ttl ComputeRegionBackendService#ttl}
    */
    readonly ttl?: ComputeRegionBackendServiceConsistentHashHttpCookieTtl;
}
export declare function computeRegionBackendServiceConsistentHashHttpCookieToTerraform(struct?: ComputeRegionBackendServiceConsistentHashHttpCookieOutputReference | ComputeRegionBackendServiceConsistentHashHttpCookie): any;
export declare function computeRegionBackendServiceConsistentHashHttpCookieToHclTerraform(struct?: ComputeRegionBackendServiceConsistentHashHttpCookieOutputReference | ComputeRegionBackendServiceConsistentHashHttpCookie): any;
export declare class ComputeRegionBackendServiceConsistentHashHttpCookieOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionBackendServiceConsistentHashHttpCookie | undefined;
    set internalValue(value: ComputeRegionBackendServiceConsistentHashHttpCookie | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _ttl;
    get ttl(): ComputeRegionBackendServiceConsistentHashHttpCookieTtlOutputReference;
    putTtl(value: ComputeRegionBackendServiceConsistentHashHttpCookieTtl): void;
    resetTtl(): void;
    get ttlInput(): ComputeRegionBackendServiceConsistentHashHttpCookieTtl | undefined;
}
export interface ComputeRegionBackendServiceConsistentHash {
    /**
    * The hash based on the value of the specified header field.
    * This field is applicable if the sessionAffinity is set to HEADER_FIELD.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#http_header_name ComputeRegionBackendService#http_header_name}
    */
    readonly httpHeaderName?: string;
    /**
    * The minimum number of virtual nodes to use for the hash ring.
    * Larger ring sizes result in more granular load
    * distributions. If the number of hosts in the load balancing pool
    * is larger than the ring size, each host will be assigned a single
    * virtual node.
    * Defaults to 1024.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#minimum_ring_size ComputeRegionBackendService#minimum_ring_size}
    */
    readonly minimumRingSize?: number;
    /**
    * http_cookie block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#http_cookie ComputeRegionBackendService#http_cookie}
    */
    readonly httpCookie?: ComputeRegionBackendServiceConsistentHashHttpCookie;
}
export declare function computeRegionBackendServiceConsistentHashToTerraform(struct?: ComputeRegionBackendServiceConsistentHashOutputReference | ComputeRegionBackendServiceConsistentHash): any;
export declare function computeRegionBackendServiceConsistentHashToHclTerraform(struct?: ComputeRegionBackendServiceConsistentHashOutputReference | ComputeRegionBackendServiceConsistentHash): any;
export declare class ComputeRegionBackendServiceConsistentHashOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionBackendServiceConsistentHash | undefined;
    set internalValue(value: ComputeRegionBackendServiceConsistentHash | undefined);
    private _httpHeaderName?;
    get httpHeaderName(): string;
    set httpHeaderName(value: string);
    resetHttpHeaderName(): void;
    get httpHeaderNameInput(): string | undefined;
    private _minimumRingSize?;
    get minimumRingSize(): number;
    set minimumRingSize(value: number);
    resetMinimumRingSize(): void;
    get minimumRingSizeInput(): number | undefined;
    private _httpCookie;
    get httpCookie(): ComputeRegionBackendServiceConsistentHashHttpCookieOutputReference;
    putHttpCookie(value: ComputeRegionBackendServiceConsistentHashHttpCookie): void;
    resetHttpCookie(): void;
    get httpCookieInput(): ComputeRegionBackendServiceConsistentHashHttpCookie | undefined;
}
export interface ComputeRegionBackendServiceCustomMetrics {
    /**
    * If true, the metric data is not used for load balancing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#dry_run ComputeRegionBackendService#dry_run}
    */
    readonly dryRun: boolean | cdktn.IResolvable;
    /**
    * Name of a custom utilization signal. The name must be 1-64 characters
    * long and match the regular expression [a-z]([-_.a-z0-9]*[a-z0-9])? which
    * means the first character must be a lowercase letter, and all following
    * characters must be a dash, period, underscore, lowercase letter, or
    * digit, except the last character, which cannot be a dash, period, or
    * underscore. For usage guidelines, see Custom Metrics balancing mode. This
    * field can only be used for a global or regional backend service with the
    * loadBalancingScheme set to <code>EXTERNAL_MANAGED</code>,
    * <code>INTERNAL_MANAGED</code> <code>INTERNAL_SELF_MANAGED</code>.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#name ComputeRegionBackendService#name}
    */
    readonly name: string;
}
export declare function computeRegionBackendServiceCustomMetricsToTerraform(struct?: ComputeRegionBackendServiceCustomMetrics | cdktn.IResolvable): any;
export declare function computeRegionBackendServiceCustomMetricsToHclTerraform(struct?: ComputeRegionBackendServiceCustomMetrics | cdktn.IResolvable): any;
export declare class ComputeRegionBackendServiceCustomMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionBackendServiceCustomMetrics | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionBackendServiceCustomMetrics | cdktn.IResolvable | undefined);
    private _dryRun?;
    get dryRun(): boolean | cdktn.IResolvable;
    set dryRun(value: boolean | cdktn.IResolvable);
    get dryRunInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class ComputeRegionBackendServiceCustomMetricsList extends cdktn.ComplexList {
    internalValue?: ComputeRegionBackendServiceCustomMetrics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionBackendServiceCustomMetricsOutputReference;
}
export interface ComputeRegionBackendServiceFailoverPolicy {
    /**
    * On failover or failback, this field indicates whether connection drain
    * will be honored. Setting this to true has the following effect: connections
    * to the old active pool are not drained. Connections to the new active pool
    * use the timeout of 10 min (currently fixed). Setting to false has the
    * following effect: both old and new connections will have a drain timeout
    * of 10 min.
    * This can be set to true only if the protocol is TCP.
    * The default is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#disable_connection_drain_on_failover ComputeRegionBackendService#disable_connection_drain_on_failover}
    */
    readonly disableConnectionDrainOnFailover?: boolean | cdktn.IResolvable;
    /**
    * This option is used only when no healthy VMs are detected in the primary
    * and backup instance groups. When set to true, traffic is dropped. When
    * set to false, new connections are sent across all VMs in the primary group.
    * The default is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#drop_traffic_if_unhealthy ComputeRegionBackendService#drop_traffic_if_unhealthy}
    */
    readonly dropTrafficIfUnhealthy?: boolean | cdktn.IResolvable;
    /**
    * The value of the field must be in [0, 1]. If the ratio of the healthy
    * VMs in the primary backend is at or below this number, traffic arriving
    * at the load-balanced IP will be directed to the failover backend.
    * In case where 'failoverRatio' is not set or all the VMs in the backup
    * backend are unhealthy, the traffic will be directed back to the primary
    * backend in the "force" mode, where traffic will be spread to the healthy
    * VMs with the best effort, or to all VMs when no VM is healthy.
    * This field is only used with l4 load balancing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#failover_ratio ComputeRegionBackendService#failover_ratio}
    */
    readonly failoverRatio?: number;
}
export declare function computeRegionBackendServiceFailoverPolicyToTerraform(struct?: ComputeRegionBackendServiceFailoverPolicyOutputReference | ComputeRegionBackendServiceFailoverPolicy): any;
export declare function computeRegionBackendServiceFailoverPolicyToHclTerraform(struct?: ComputeRegionBackendServiceFailoverPolicyOutputReference | ComputeRegionBackendServiceFailoverPolicy): any;
export declare class ComputeRegionBackendServiceFailoverPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionBackendServiceFailoverPolicy | undefined;
    set internalValue(value: ComputeRegionBackendServiceFailoverPolicy | undefined);
    private _disableConnectionDrainOnFailover?;
    get disableConnectionDrainOnFailover(): boolean | cdktn.IResolvable;
    set disableConnectionDrainOnFailover(value: boolean | cdktn.IResolvable);
    resetDisableConnectionDrainOnFailover(): void;
    get disableConnectionDrainOnFailoverInput(): boolean | cdktn.IResolvable | undefined;
    private _dropTrafficIfUnhealthy?;
    get dropTrafficIfUnhealthy(): boolean | cdktn.IResolvable;
    set dropTrafficIfUnhealthy(value: boolean | cdktn.IResolvable);
    resetDropTrafficIfUnhealthy(): void;
    get dropTrafficIfUnhealthyInput(): boolean | cdktn.IResolvable | undefined;
    private _failoverRatio?;
    get failoverRatio(): number;
    set failoverRatio(value: number);
    resetFailoverRatio(): void;
    get failoverRatioInput(): number | undefined;
}
export interface ComputeRegionBackendServiceHaPolicyLeaderNetworkEndpoint {
    /**
    * The name of the VM instance of the leader network endpoint. The instance must
    * already be attached to the NEG specified in the haPolicy.leader.backendGroup.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#instance ComputeRegionBackendService#instance}
    */
    readonly instance?: string;
}
export declare function computeRegionBackendServiceHaPolicyLeaderNetworkEndpointToTerraform(struct?: ComputeRegionBackendServiceHaPolicyLeaderNetworkEndpointOutputReference | ComputeRegionBackendServiceHaPolicyLeaderNetworkEndpoint): any;
export declare function computeRegionBackendServiceHaPolicyLeaderNetworkEndpointToHclTerraform(struct?: ComputeRegionBackendServiceHaPolicyLeaderNetworkEndpointOutputReference | ComputeRegionBackendServiceHaPolicyLeaderNetworkEndpoint): any;
export declare class ComputeRegionBackendServiceHaPolicyLeaderNetworkEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionBackendServiceHaPolicyLeaderNetworkEndpoint | undefined;
    set internalValue(value: ComputeRegionBackendServiceHaPolicyLeaderNetworkEndpoint | undefined);
    private _instance?;
    get instance(): string;
    set instance(value: string);
    resetInstance(): void;
    get instanceInput(): string | undefined;
}
export interface ComputeRegionBackendServiceHaPolicyLeader {
    /**
    * A fully-qualified URL of the zonal Network Endpoint Group (NEG) that the leader is
    * attached to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#backend_group ComputeRegionBackendService#backend_group}
    */
    readonly backendGroup?: string;
    /**
    * network_endpoint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#network_endpoint ComputeRegionBackendService#network_endpoint}
    */
    readonly networkEndpoint?: ComputeRegionBackendServiceHaPolicyLeaderNetworkEndpoint;
}
export declare function computeRegionBackendServiceHaPolicyLeaderToTerraform(struct?: ComputeRegionBackendServiceHaPolicyLeaderOutputReference | ComputeRegionBackendServiceHaPolicyLeader): any;
export declare function computeRegionBackendServiceHaPolicyLeaderToHclTerraform(struct?: ComputeRegionBackendServiceHaPolicyLeaderOutputReference | ComputeRegionBackendServiceHaPolicyLeader): any;
export declare class ComputeRegionBackendServiceHaPolicyLeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionBackendServiceHaPolicyLeader | undefined;
    set internalValue(value: ComputeRegionBackendServiceHaPolicyLeader | undefined);
    private _backendGroup?;
    get backendGroup(): string;
    set backendGroup(value: string);
    resetBackendGroup(): void;
    get backendGroupInput(): string | undefined;
    private _networkEndpoint;
    get networkEndpoint(): ComputeRegionBackendServiceHaPolicyLeaderNetworkEndpointOutputReference;
    putNetworkEndpoint(value: ComputeRegionBackendServiceHaPolicyLeaderNetworkEndpoint): void;
    resetNetworkEndpoint(): void;
    get networkEndpointInput(): ComputeRegionBackendServiceHaPolicyLeaderNetworkEndpoint | undefined;
}
export interface ComputeRegionBackendServiceHaPolicy {
    /**
    * Specifies whether fast IP move is enabled, and if so, the mechanism to achieve it.
    * Supported values are:
    *
    * * 'DISABLED': Fast IP Move is disabled. You can only use the haPolicy.leader API to
    *               update the leader.
    *
    * * 'GARP_RA': Provides a method to very quickly define a new network endpoint as the
    *              leader. This method is faster than updating the leader using the
    *              haPolicy.leader API. Fast IP move works as follows: The VM hosting the
    *              network endpoint that should become the new leader sends either a
    *              Gratuitous ARP (GARP) packet (IPv4) or an ICMPv6 Router Advertisement(RA)
    *              packet (IPv6). Google Cloud immediately but temporarily associates the
    *              forwarding rule IP address with that VM, and both new and in-flight packets
    *              are quickly delivered to that VM. Possible values: ["DISABLED", "GARP_RA"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#fast_ip_move ComputeRegionBackendService#fast_ip_move}
    */
    readonly fastIpMove?: string;
    /**
    * leader block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#leader ComputeRegionBackendService#leader}
    */
    readonly leader?: ComputeRegionBackendServiceHaPolicyLeader;
}
export declare function computeRegionBackendServiceHaPolicyToTerraform(struct?: ComputeRegionBackendServiceHaPolicyOutputReference | ComputeRegionBackendServiceHaPolicy): any;
export declare function computeRegionBackendServiceHaPolicyToHclTerraform(struct?: ComputeRegionBackendServiceHaPolicyOutputReference | ComputeRegionBackendServiceHaPolicy): any;
export declare class ComputeRegionBackendServiceHaPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionBackendServiceHaPolicy | undefined;
    set internalValue(value: ComputeRegionBackendServiceHaPolicy | undefined);
    private _fastIpMove?;
    get fastIpMove(): string;
    set fastIpMove(value: string);
    resetFastIpMove(): void;
    get fastIpMoveInput(): string | undefined;
    private _leader;
    get leader(): ComputeRegionBackendServiceHaPolicyLeaderOutputReference;
    putLeader(value: ComputeRegionBackendServiceHaPolicyLeader): void;
    resetLeader(): void;
    get leaderInput(): ComputeRegionBackendServiceHaPolicyLeader | undefined;
}
export interface ComputeRegionBackendServiceIap {
    /**
    * Whether the serving infrastructure will authenticate and authorize all incoming requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#enabled ComputeRegionBackendService#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * OAuth2 Client ID for IAP
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#oauth2_client_id ComputeRegionBackendService#oauth2_client_id}
    */
    readonly oauth2ClientId?: string;
    /**
    * OAuth2 Client Secret for IAP
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#oauth2_client_secret ComputeRegionBackendService#oauth2_client_secret}
    */
    readonly oauth2ClientSecret?: string;
}
export declare function computeRegionBackendServiceIapToTerraform(struct?: ComputeRegionBackendServiceIapOutputReference | ComputeRegionBackendServiceIap): any;
export declare function computeRegionBackendServiceIapToHclTerraform(struct?: ComputeRegionBackendServiceIapOutputReference | ComputeRegionBackendServiceIap): any;
export declare class ComputeRegionBackendServiceIapOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionBackendServiceIap | undefined;
    set internalValue(value: ComputeRegionBackendServiceIap | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _oauth2ClientId?;
    get oauth2ClientId(): string;
    set oauth2ClientId(value: string);
    resetOauth2ClientId(): void;
    get oauth2ClientIdInput(): string | undefined;
    private _oauth2ClientSecret?;
    get oauth2ClientSecret(): string;
    set oauth2ClientSecret(value: string);
    resetOauth2ClientSecret(): void;
    get oauth2ClientSecretInput(): string | undefined;
    get oauth2ClientSecretSha256(): string;
}
export interface ComputeRegionBackendServiceLogConfigRequestHeaders {
    /**
    * The header name to match on for logging.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#header_name ComputeRegionBackendService#header_name}
    */
    readonly headerName: string;
}
export declare function computeRegionBackendServiceLogConfigRequestHeadersToTerraform(struct?: ComputeRegionBackendServiceLogConfigRequestHeaders | cdktn.IResolvable): any;
export declare function computeRegionBackendServiceLogConfigRequestHeadersToHclTerraform(struct?: ComputeRegionBackendServiceLogConfigRequestHeaders | cdktn.IResolvable): any;
export declare class ComputeRegionBackendServiceLogConfigRequestHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionBackendServiceLogConfigRequestHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionBackendServiceLogConfigRequestHeaders | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    get headerNameInput(): string | undefined;
}
export declare class ComputeRegionBackendServiceLogConfigRequestHeadersList extends cdktn.ComplexList {
    internalValue?: ComputeRegionBackendServiceLogConfigRequestHeaders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionBackendServiceLogConfigRequestHeadersOutputReference;
}
export interface ComputeRegionBackendServiceLogConfigResponseHeaders {
    /**
    * The header name to match on for logging.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#header_name ComputeRegionBackendService#header_name}
    */
    readonly headerName: string;
}
export declare function computeRegionBackendServiceLogConfigResponseHeadersToTerraform(struct?: ComputeRegionBackendServiceLogConfigResponseHeaders | cdktn.IResolvable): any;
export declare function computeRegionBackendServiceLogConfigResponseHeadersToHclTerraform(struct?: ComputeRegionBackendServiceLogConfigResponseHeaders | cdktn.IResolvable): any;
export declare class ComputeRegionBackendServiceLogConfigResponseHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionBackendServiceLogConfigResponseHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionBackendServiceLogConfigResponseHeaders | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    get headerNameInput(): string | undefined;
}
export declare class ComputeRegionBackendServiceLogConfigResponseHeadersList extends cdktn.ComplexList {
    internalValue?: ComputeRegionBackendServiceLogConfigResponseHeaders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionBackendServiceLogConfigResponseHeadersOutputReference;
}
export interface ComputeRegionBackendServiceLogConfig {
    /**
    * Whether to enable logging for the load balancer traffic served by this backend service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#enable ComputeRegionBackendService#enable}
    */
    readonly enable?: boolean | cdktn.IResolvable;
    /**
    * Specifies the fields to include in logging. This field can only be specified if logging is enabled for this backend service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#optional_fields ComputeRegionBackendService#optional_fields}
    */
    readonly optionalFields?: string[];
    /**
    * Specifies the optional logging mode for the load balancer traffic.
    * Supported values: INCLUDE_ALL_OPTIONAL, EXCLUDE_ALL_OPTIONAL, CUSTOM. Possible values: ["INCLUDE_ALL_OPTIONAL", "EXCLUDE_ALL_OPTIONAL", "CUSTOM"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#optional_mode ComputeRegionBackendService#optional_mode}
    */
    readonly optionalMode?: string;
    /**
    * This field can only be specified if logging is enabled for this backend service. The value of
    * the field must be in [0, 1]. This configures the sampling rate of requests to the load balancer
    * where 1.0 means all logged requests are reported and 0.0 means no logged requests are reported.
    * The default value is 1.0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#sample_rate ComputeRegionBackendService#sample_rate}
    */
    readonly sampleRate?: number;
    /**
    * request_headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#request_headers ComputeRegionBackendService#request_headers}
    */
    readonly requestHeaders?: ComputeRegionBackendServiceLogConfigRequestHeaders[] | cdktn.IResolvable;
    /**
    * response_headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#response_headers ComputeRegionBackendService#response_headers}
    */
    readonly responseHeaders?: ComputeRegionBackendServiceLogConfigResponseHeaders[] | cdktn.IResolvable;
}
export declare function computeRegionBackendServiceLogConfigToTerraform(struct?: ComputeRegionBackendServiceLogConfigOutputReference | ComputeRegionBackendServiceLogConfig): any;
export declare function computeRegionBackendServiceLogConfigToHclTerraform(struct?: ComputeRegionBackendServiceLogConfigOutputReference | ComputeRegionBackendServiceLogConfig): any;
export declare class ComputeRegionBackendServiceLogConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionBackendServiceLogConfig | undefined;
    set internalValue(value: ComputeRegionBackendServiceLogConfig | undefined);
    private _enable?;
    get enable(): boolean | cdktn.IResolvable;
    set enable(value: boolean | cdktn.IResolvable);
    resetEnable(): void;
    get enableInput(): boolean | cdktn.IResolvable | undefined;
    private _optionalFields?;
    get optionalFields(): string[];
    set optionalFields(value: string[]);
    resetOptionalFields(): void;
    get optionalFieldsInput(): string[] | undefined;
    private _optionalMode?;
    get optionalMode(): string;
    set optionalMode(value: string);
    resetOptionalMode(): void;
    get optionalModeInput(): string | undefined;
    private _sampleRate?;
    get sampleRate(): number;
    set sampleRate(value: number);
    resetSampleRate(): void;
    get sampleRateInput(): number | undefined;
    private _requestHeaders;
    get requestHeaders(): ComputeRegionBackendServiceLogConfigRequestHeadersList;
    putRequestHeaders(value: ComputeRegionBackendServiceLogConfigRequestHeaders[] | cdktn.IResolvable): void;
    resetRequestHeaders(): void;
    get requestHeadersInput(): cdktn.IResolvable | ComputeRegionBackendServiceLogConfigRequestHeaders[] | undefined;
    private _responseHeaders;
    get responseHeaders(): ComputeRegionBackendServiceLogConfigResponseHeadersList;
    putResponseHeaders(value: ComputeRegionBackendServiceLogConfigResponseHeaders[] | cdktn.IResolvable): void;
    resetResponseHeaders(): void;
    get responseHeadersInput(): cdktn.IResolvable | ComputeRegionBackendServiceLogConfigResponseHeaders[] | undefined;
}
export interface ComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinity {
    /**
    * This field indicates whether zonal affinity is enabled or not. Default value: "ZONAL_AFFINITY_DISABLED" Possible values: ["ZONAL_AFFINITY_DISABLED", "ZONAL_AFFINITY_SPILL_CROSS_ZONE", "ZONAL_AFFINITY_STAY_WITHIN_ZONE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#spillover ComputeRegionBackendService#spillover}
    */
    readonly spillover?: string;
    /**
    * The value of the field must be in [0, 1]. When the ratio of the count of healthy backend endpoints in a zone
    * to the count of backend endpoints in that same zone is equal to or above this threshold, the load balancer
    * distributes new connections to all healthy endpoints in the local zone only. When the ratio of the count
    * of healthy backend endpoints in a zone to the count of backend endpoints in that same zone is below this
    * threshold, the load balancer distributes all new connections to all healthy endpoints across all zones.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#spillover_ratio ComputeRegionBackendService#spillover_ratio}
    */
    readonly spilloverRatio?: number;
}
export declare function computeRegionBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinityToTerraform(struct?: ComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinityOutputReference | ComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinity): any;
export declare function computeRegionBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinityToHclTerraform(struct?: ComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinityOutputReference | ComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinity): any;
export declare class ComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinity | undefined;
    set internalValue(value: ComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinity | undefined);
    private _spillover?;
    get spillover(): string;
    set spillover(value: string);
    resetSpillover(): void;
    get spilloverInput(): string | undefined;
    private _spilloverRatio?;
    get spilloverRatio(): number;
    set spilloverRatio(value: number);
    resetSpilloverRatio(): void;
    get spilloverRatioInput(): number | undefined;
}
export interface ComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicy {
    /**
    * zonal_affinity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#zonal_affinity ComputeRegionBackendService#zonal_affinity}
    */
    readonly zonalAffinity?: ComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinity;
}
export declare function computeRegionBackendServiceNetworkPassThroughLbTrafficPolicyToTerraform(struct?: ComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyOutputReference | ComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicy): any;
export declare function computeRegionBackendServiceNetworkPassThroughLbTrafficPolicyToHclTerraform(struct?: ComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyOutputReference | ComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicy): any;
export declare class ComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicy | undefined;
    set internalValue(value: ComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicy | undefined);
    private _zonalAffinity;
    get zonalAffinity(): ComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinityOutputReference;
    putZonalAffinity(value: ComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinity): void;
    resetZonalAffinity(): void;
    get zonalAffinityInput(): ComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinity | undefined;
}
export interface ComputeRegionBackendServiceOutlierDetectionBaseEjectionTime {
    /**
    * Span of time that's a fraction of a second at nanosecond resolution. Durations
    * less than one second are represented with a 0 'seconds' field and a positive
    * 'nanos' field. Must be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#nanos ComputeRegionBackendService#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second. Must be from 0 to 315,576,000,000
    * inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#seconds ComputeRegionBackendService#seconds}
    */
    readonly seconds: number;
}
export declare function computeRegionBackendServiceOutlierDetectionBaseEjectionTimeToTerraform(struct?: ComputeRegionBackendServiceOutlierDetectionBaseEjectionTimeOutputReference | ComputeRegionBackendServiceOutlierDetectionBaseEjectionTime): any;
export declare function computeRegionBackendServiceOutlierDetectionBaseEjectionTimeToHclTerraform(struct?: ComputeRegionBackendServiceOutlierDetectionBaseEjectionTimeOutputReference | ComputeRegionBackendServiceOutlierDetectionBaseEjectionTime): any;
export declare class ComputeRegionBackendServiceOutlierDetectionBaseEjectionTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionBackendServiceOutlierDetectionBaseEjectionTime | undefined;
    set internalValue(value: ComputeRegionBackendServiceOutlierDetectionBaseEjectionTime | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): number;
    set seconds(value: number);
    get secondsInput(): number | undefined;
}
export interface ComputeRegionBackendServiceOutlierDetectionInterval {
    /**
    * Span of time that's a fraction of a second at nanosecond resolution. Durations
    * less than one second are represented with a 0 'seconds' field and a positive
    * 'nanos' field. Must be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#nanos ComputeRegionBackendService#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second. Must be from 0 to 315,576,000,000
    * inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#seconds ComputeRegionBackendService#seconds}
    */
    readonly seconds: number;
}
export declare function computeRegionBackendServiceOutlierDetectionIntervalToTerraform(struct?: ComputeRegionBackendServiceOutlierDetectionIntervalOutputReference | ComputeRegionBackendServiceOutlierDetectionInterval): any;
export declare function computeRegionBackendServiceOutlierDetectionIntervalToHclTerraform(struct?: ComputeRegionBackendServiceOutlierDetectionIntervalOutputReference | ComputeRegionBackendServiceOutlierDetectionInterval): any;
export declare class ComputeRegionBackendServiceOutlierDetectionIntervalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionBackendServiceOutlierDetectionInterval | undefined;
    set internalValue(value: ComputeRegionBackendServiceOutlierDetectionInterval | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): number;
    set seconds(value: number);
    get secondsInput(): number | undefined;
}
export interface ComputeRegionBackendServiceOutlierDetection {
    /**
    * Number of errors before a host is ejected from the connection pool. When the
    * backend host is accessed over HTTP, a 5xx return code qualifies as an error.
    * Defaults to 5.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#consecutive_errors ComputeRegionBackendService#consecutive_errors}
    */
    readonly consecutiveErrors?: number;
    /**
    * The number of consecutive gateway failures (502, 503, 504 status or connection
    * errors that are mapped to one of those status codes) before a consecutive
    * gateway failure ejection occurs. Defaults to 5.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#consecutive_gateway_failure ComputeRegionBackendService#consecutive_gateway_failure}
    */
    readonly consecutiveGatewayFailure?: number;
    /**
    * The percentage chance that a host will be actually ejected when an outlier
    * status is detected through consecutive 5xx. This setting can be used to disable
    * ejection or to ramp it up slowly. Defaults to 100.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#enforcing_consecutive_errors ComputeRegionBackendService#enforcing_consecutive_errors}
    */
    readonly enforcingConsecutiveErrors?: number;
    /**
    * The percentage chance that a host will be actually ejected when an outlier
    * status is detected through consecutive gateway failures. This setting can be
    * used to disable ejection or to ramp it up slowly. Defaults to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#enforcing_consecutive_gateway_failure ComputeRegionBackendService#enforcing_consecutive_gateway_failure}
    */
    readonly enforcingConsecutiveGatewayFailure?: number;
    /**
    * The percentage chance that a host will be actually ejected when an outlier
    * status is detected through success rate statistics. This setting can be used to
    * disable ejection or to ramp it up slowly. Defaults to 100.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#enforcing_success_rate ComputeRegionBackendService#enforcing_success_rate}
    */
    readonly enforcingSuccessRate?: number;
    /**
    * Maximum percentage of hosts in the load balancing pool for the backend service
    * that can be ejected. Defaults to 10%.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#max_ejection_percent ComputeRegionBackendService#max_ejection_percent}
    */
    readonly maxEjectionPercent?: number;
    /**
    * The number of hosts in a cluster that must have enough request volume to detect
    * success rate outliers. If the number of hosts is less than this setting, outlier
    * detection via success rate statistics is not performed for any host in the
    * cluster. Defaults to 5.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#success_rate_minimum_hosts ComputeRegionBackendService#success_rate_minimum_hosts}
    */
    readonly successRateMinimumHosts?: number;
    /**
    * The minimum number of total requests that must be collected in one interval (as
    * defined by the interval duration above) to include this host in success rate
    * based outlier detection. If the volume is lower than this setting, outlier
    * detection via success rate statistics is not performed for that host. Defaults
    * to 100.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#success_rate_request_volume ComputeRegionBackendService#success_rate_request_volume}
    */
    readonly successRateRequestVolume?: number;
    /**
    * This factor is used to determine the ejection threshold for success rate outlier
    * ejection. The ejection threshold is the difference between the mean success
    * rate, and the product of this factor and the standard deviation of the mean
    * success rate: mean - (stdev * success_rate_stdev_factor). This factor is divided
    * by a thousand to get a double. That is, if the desired factor is 1.9, the
    * runtime value should be 1900. Defaults to 1900.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#success_rate_stdev_factor ComputeRegionBackendService#success_rate_stdev_factor}
    */
    readonly successRateStdevFactor?: number;
    /**
    * base_ejection_time block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#base_ejection_time ComputeRegionBackendService#base_ejection_time}
    */
    readonly baseEjectionTime?: ComputeRegionBackendServiceOutlierDetectionBaseEjectionTime;
    /**
    * interval block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#interval ComputeRegionBackendService#interval}
    */
    readonly interval?: ComputeRegionBackendServiceOutlierDetectionInterval;
}
export declare function computeRegionBackendServiceOutlierDetectionToTerraform(struct?: ComputeRegionBackendServiceOutlierDetectionOutputReference | ComputeRegionBackendServiceOutlierDetection): any;
export declare function computeRegionBackendServiceOutlierDetectionToHclTerraform(struct?: ComputeRegionBackendServiceOutlierDetectionOutputReference | ComputeRegionBackendServiceOutlierDetection): any;
export declare class ComputeRegionBackendServiceOutlierDetectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionBackendServiceOutlierDetection | undefined;
    set internalValue(value: ComputeRegionBackendServiceOutlierDetection | undefined);
    private _consecutiveErrors?;
    get consecutiveErrors(): number;
    set consecutiveErrors(value: number);
    resetConsecutiveErrors(): void;
    get consecutiveErrorsInput(): number | undefined;
    private _consecutiveGatewayFailure?;
    get consecutiveGatewayFailure(): number;
    set consecutiveGatewayFailure(value: number);
    resetConsecutiveGatewayFailure(): void;
    get consecutiveGatewayFailureInput(): number | undefined;
    private _enforcingConsecutiveErrors?;
    get enforcingConsecutiveErrors(): number;
    set enforcingConsecutiveErrors(value: number);
    resetEnforcingConsecutiveErrors(): void;
    get enforcingConsecutiveErrorsInput(): number | undefined;
    private _enforcingConsecutiveGatewayFailure?;
    get enforcingConsecutiveGatewayFailure(): number;
    set enforcingConsecutiveGatewayFailure(value: number);
    resetEnforcingConsecutiveGatewayFailure(): void;
    get enforcingConsecutiveGatewayFailureInput(): number | undefined;
    private _enforcingSuccessRate?;
    get enforcingSuccessRate(): number;
    set enforcingSuccessRate(value: number);
    resetEnforcingSuccessRate(): void;
    get enforcingSuccessRateInput(): number | undefined;
    private _maxEjectionPercent?;
    get maxEjectionPercent(): number;
    set maxEjectionPercent(value: number);
    resetMaxEjectionPercent(): void;
    get maxEjectionPercentInput(): number | undefined;
    private _successRateMinimumHosts?;
    get successRateMinimumHosts(): number;
    set successRateMinimumHosts(value: number);
    resetSuccessRateMinimumHosts(): void;
    get successRateMinimumHostsInput(): number | undefined;
    private _successRateRequestVolume?;
    get successRateRequestVolume(): number;
    set successRateRequestVolume(value: number);
    resetSuccessRateRequestVolume(): void;
    get successRateRequestVolumeInput(): number | undefined;
    private _successRateStdevFactor?;
    get successRateStdevFactor(): number;
    set successRateStdevFactor(value: number);
    resetSuccessRateStdevFactor(): void;
    get successRateStdevFactorInput(): number | undefined;
    private _baseEjectionTime;
    get baseEjectionTime(): ComputeRegionBackendServiceOutlierDetectionBaseEjectionTimeOutputReference;
    putBaseEjectionTime(value: ComputeRegionBackendServiceOutlierDetectionBaseEjectionTime): void;
    resetBaseEjectionTime(): void;
    get baseEjectionTimeInput(): ComputeRegionBackendServiceOutlierDetectionBaseEjectionTime | undefined;
    private _interval;
    get interval(): ComputeRegionBackendServiceOutlierDetectionIntervalOutputReference;
    putInterval(value: ComputeRegionBackendServiceOutlierDetectionInterval): void;
    resetInterval(): void;
    get intervalInput(): ComputeRegionBackendServiceOutlierDetectionInterval | undefined;
}
export interface ComputeRegionBackendServiceParams {
    /**
    * Resource manager tags to be bound to the region backend service. Tag keys and values have the
    * same definition as resource manager tags. Keys must be in the format tagKeys/{tag_key_id},
    * and values are in the format tagValues/456.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#resource_manager_tags ComputeRegionBackendService#resource_manager_tags}
    */
    readonly resourceManagerTags?: {
        [key: string]: string;
    };
}
export declare function computeRegionBackendServiceParamsToTerraform(struct?: ComputeRegionBackendServiceParamsOutputReference | ComputeRegionBackendServiceParams): any;
export declare function computeRegionBackendServiceParamsToHclTerraform(struct?: ComputeRegionBackendServiceParamsOutputReference | ComputeRegionBackendServiceParams): any;
export declare class ComputeRegionBackendServiceParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionBackendServiceParams | undefined;
    set internalValue(value: ComputeRegionBackendServiceParams | undefined);
    private _resourceManagerTags?;
    get resourceManagerTags(): {
        [key: string]: string;
    };
    set resourceManagerTags(value: {
        [key: string]: string;
    });
    resetResourceManagerTags(): void;
    get resourceManagerTagsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ComputeRegionBackendServiceStrongSessionAffinityCookieTtl {
    /**
    * Span of time that's a fraction of a second at nanosecond
    * resolution. Durations less than one second are represented
    * with a 0 seconds field and a positive nanos field. Must
    * be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#nanos ComputeRegionBackendService#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second.
    * Must be from 0 to 315,576,000,000 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#seconds ComputeRegionBackendService#seconds}
    */
    readonly seconds: number;
}
export declare function computeRegionBackendServiceStrongSessionAffinityCookieTtlToTerraform(struct?: ComputeRegionBackendServiceStrongSessionAffinityCookieTtlOutputReference | ComputeRegionBackendServiceStrongSessionAffinityCookieTtl): any;
export declare function computeRegionBackendServiceStrongSessionAffinityCookieTtlToHclTerraform(struct?: ComputeRegionBackendServiceStrongSessionAffinityCookieTtlOutputReference | ComputeRegionBackendServiceStrongSessionAffinityCookieTtl): any;
export declare class ComputeRegionBackendServiceStrongSessionAffinityCookieTtlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionBackendServiceStrongSessionAffinityCookieTtl | undefined;
    set internalValue(value: ComputeRegionBackendServiceStrongSessionAffinityCookieTtl | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): number;
    set seconds(value: number);
    get secondsInput(): number | undefined;
}
export interface ComputeRegionBackendServiceStrongSessionAffinityCookie {
    /**
    * Name of the cookie.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#name ComputeRegionBackendService#name}
    */
    readonly name?: string;
    /**
    * Path to set for the cookie.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#path ComputeRegionBackendService#path}
    */
    readonly path?: string;
    /**
    * ttl block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#ttl ComputeRegionBackendService#ttl}
    */
    readonly ttl?: ComputeRegionBackendServiceStrongSessionAffinityCookieTtl;
}
export declare function computeRegionBackendServiceStrongSessionAffinityCookieToTerraform(struct?: ComputeRegionBackendServiceStrongSessionAffinityCookieOutputReference | ComputeRegionBackendServiceStrongSessionAffinityCookie): any;
export declare function computeRegionBackendServiceStrongSessionAffinityCookieToHclTerraform(struct?: ComputeRegionBackendServiceStrongSessionAffinityCookieOutputReference | ComputeRegionBackendServiceStrongSessionAffinityCookie): any;
export declare class ComputeRegionBackendServiceStrongSessionAffinityCookieOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionBackendServiceStrongSessionAffinityCookie | undefined;
    set internalValue(value: ComputeRegionBackendServiceStrongSessionAffinityCookie | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _ttl;
    get ttl(): ComputeRegionBackendServiceStrongSessionAffinityCookieTtlOutputReference;
    putTtl(value: ComputeRegionBackendServiceStrongSessionAffinityCookieTtl): void;
    resetTtl(): void;
    get ttlInput(): ComputeRegionBackendServiceStrongSessionAffinityCookieTtl | undefined;
}
export interface ComputeRegionBackendServiceTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#create ComputeRegionBackendService#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#delete ComputeRegionBackendService#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#update ComputeRegionBackendService#update}
    */
    readonly update?: string;
}
export declare function computeRegionBackendServiceTimeoutsToTerraform(struct?: ComputeRegionBackendServiceTimeouts | cdktn.IResolvable): any;
export declare function computeRegionBackendServiceTimeoutsToHclTerraform(struct?: ComputeRegionBackendServiceTimeouts | cdktn.IResolvable): any;
export declare class ComputeRegionBackendServiceTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionBackendServiceTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionBackendServiceTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface ComputeRegionBackendServiceTlsSettingsSubjectAltNames {
    /**
    * The SAN specified as a DNS Name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#dns_name ComputeRegionBackendService#dns_name}
    */
    readonly dnsName?: string;
    /**
    * The SAN specified as a URI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#uniform_resource_identifier ComputeRegionBackendService#uniform_resource_identifier}
    */
    readonly uniformResourceIdentifier?: string;
}
export declare function computeRegionBackendServiceTlsSettingsSubjectAltNamesToTerraform(struct?: ComputeRegionBackendServiceTlsSettingsSubjectAltNames | cdktn.IResolvable): any;
export declare function computeRegionBackendServiceTlsSettingsSubjectAltNamesToHclTerraform(struct?: ComputeRegionBackendServiceTlsSettingsSubjectAltNames | cdktn.IResolvable): any;
export declare class ComputeRegionBackendServiceTlsSettingsSubjectAltNamesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionBackendServiceTlsSettingsSubjectAltNames | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionBackendServiceTlsSettingsSubjectAltNames | cdktn.IResolvable | undefined);
    private _dnsName?;
    get dnsName(): string;
    set dnsName(value: string);
    resetDnsName(): void;
    get dnsNameInput(): string | undefined;
    private _uniformResourceIdentifier?;
    get uniformResourceIdentifier(): string;
    set uniformResourceIdentifier(value: string);
    resetUniformResourceIdentifier(): void;
    get uniformResourceIdentifierInput(): string | undefined;
}
export declare class ComputeRegionBackendServiceTlsSettingsSubjectAltNamesList extends cdktn.ComplexList {
    internalValue?: ComputeRegionBackendServiceTlsSettingsSubjectAltNames[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionBackendServiceTlsSettingsSubjectAltNamesOutputReference;
}
export interface ComputeRegionBackendServiceTlsSettings {
    /**
    * Reference to the BackendAuthenticationConfig resource from the networksecurity.googleapis.com namespace.
    * Can be used in authenticating TLS connections to the backend, as specified by the authenticationMode field.
    * Can only be specified if authenticationMode is not NONE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#authentication_config ComputeRegionBackendService#authentication_config}
    */
    readonly authenticationConfig?: string;
    /**
    * The fully-specified SPIFFE ID without the spiffe:// scheme. Must be in the format //<trust_domain>/ns/<namespace>/sa/<subject>.
    * The load balancer uses certificates and roots of trust provisioned by the Managed Workload Identity system for this identity.
    * The Trust Domain within the identity must refer to a valid Workload Identity Pool, from which the TrustConfig and CertificateIssuanceConfig are inherited.
    * If set, you cannot configure sni, subjectAltNames, or authenticationConfig manually.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#identity ComputeRegionBackendService#identity}
    */
    readonly identity?: string;
    /**
    * Server Name Indication - see RFC3546 section 3.1. If set, the load balancer sends this string as the SNI hostname in the
    * TLS connection to the backend, and requires that this string match a Subject Alternative Name (SAN) in the backend's
    * server certificate. With a Regional Internet NEG backend, if the SNI is specified here, the load balancer uses it
    * regardless of whether the Regional Internet NEG is specified with FQDN or IP address and port.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#sni ComputeRegionBackendService#sni}
    */
    readonly sni?: string;
    /**
    * subject_alt_names block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#subject_alt_names ComputeRegionBackendService#subject_alt_names}
    */
    readonly subjectAltNames?: ComputeRegionBackendServiceTlsSettingsSubjectAltNames[] | cdktn.IResolvable;
}
export declare function computeRegionBackendServiceTlsSettingsToTerraform(struct?: ComputeRegionBackendServiceTlsSettingsOutputReference | ComputeRegionBackendServiceTlsSettings): any;
export declare function computeRegionBackendServiceTlsSettingsToHclTerraform(struct?: ComputeRegionBackendServiceTlsSettingsOutputReference | ComputeRegionBackendServiceTlsSettings): any;
export declare class ComputeRegionBackendServiceTlsSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionBackendServiceTlsSettings | undefined;
    set internalValue(value: ComputeRegionBackendServiceTlsSettings | undefined);
    private _authenticationConfig?;
    get authenticationConfig(): string;
    set authenticationConfig(value: string);
    resetAuthenticationConfig(): void;
    get authenticationConfigInput(): string | undefined;
    private _identity?;
    get identity(): string;
    set identity(value: string);
    resetIdentity(): void;
    get identityInput(): string | undefined;
    private _sni?;
    get sni(): string;
    set sni(value: string);
    resetSni(): void;
    get sniInput(): string | undefined;
    private _subjectAltNames;
    get subjectAltNames(): ComputeRegionBackendServiceTlsSettingsSubjectAltNamesList;
    putSubjectAltNames(value: ComputeRegionBackendServiceTlsSettingsSubjectAltNames[] | cdktn.IResolvable): void;
    resetSubjectAltNames(): void;
    get subjectAltNamesInput(): cdktn.IResolvable | ComputeRegionBackendServiceTlsSettingsSubjectAltNames[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service google_compute_region_backend_service}
*/
export declare class ComputeRegionBackendService extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_region_backend_service";
    /**
    * Generates CDKTN code for importing a ComputeRegionBackendService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeRegionBackendService to import
    * @param importFromId The id of the existing ComputeRegionBackendService that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeRegionBackendService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_backend_service google_compute_region_backend_service} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeRegionBackendServiceConfig
    */
    constructor(scope: Construct, id: string, config: ComputeRegionBackendServiceConfig);
    private _affinityCookieTtlSec?;
    get affinityCookieTtlSec(): number;
    set affinityCookieTtlSec(value: number);
    resetAffinityCookieTtlSec(): void;
    get affinityCookieTtlSecInput(): number | undefined;
    private _connectionDrainingTimeoutSec?;
    get connectionDrainingTimeoutSec(): number;
    set connectionDrainingTimeoutSec(value: number);
    resetConnectionDrainingTimeoutSec(): void;
    get connectionDrainingTimeoutSecInput(): number | undefined;
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enableCdn?;
    get enableCdn(): boolean | cdktn.IResolvable;
    set enableCdn(value: boolean | cdktn.IResolvable);
    resetEnableCdn(): void;
    get enableCdnInput(): boolean | cdktn.IResolvable | undefined;
    get fingerprint(): string;
    get generatedId(): number;
    private _healthChecks?;
    get healthChecks(): string[];
    set healthChecks(value: string[]);
    resetHealthChecks(): void;
    get healthChecksInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipAddressSelectionPolicy?;
    get ipAddressSelectionPolicy(): string;
    set ipAddressSelectionPolicy(value: string);
    resetIpAddressSelectionPolicy(): void;
    get ipAddressSelectionPolicyInput(): string | undefined;
    private _loadBalancingScheme?;
    get loadBalancingScheme(): string;
    set loadBalancingScheme(value: string);
    resetLoadBalancingScheme(): void;
    get loadBalancingSchemeInput(): string | undefined;
    private _localityLbPolicy?;
    get localityLbPolicy(): string;
    set localityLbPolicy(value: string);
    resetLocalityLbPolicy(): void;
    get localityLbPolicyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _network?;
    get network(): string;
    set network(value: string);
    resetNetwork(): void;
    get networkInput(): string | undefined;
    private _portName?;
    get portName(): string;
    set portName(value: string);
    resetPortName(): void;
    get portNameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    resetProtocol(): void;
    get protocolInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityPolicy?;
    get securityPolicy(): string;
    set securityPolicy(value: string);
    resetSecurityPolicy(): void;
    get securityPolicyInput(): string | undefined;
    get selfLink(): string;
    private _serviceLbPolicy?;
    get serviceLbPolicy(): string;
    set serviceLbPolicy(value: string);
    resetServiceLbPolicy(): void;
    get serviceLbPolicyInput(): string | undefined;
    private _sessionAffinity?;
    get sessionAffinity(): string;
    set sessionAffinity(value: string);
    resetSessionAffinity(): void;
    get sessionAffinityInput(): string | undefined;
    private _timeoutSec?;
    get timeoutSec(): number;
    set timeoutSec(value: number);
    resetTimeoutSec(): void;
    get timeoutSecInput(): number | undefined;
    private _backend;
    get backend(): ComputeRegionBackendServiceBackendList;
    putBackend(value: ComputeRegionBackendServiceBackend[] | cdktn.IResolvable): void;
    resetBackend(): void;
    get backendInput(): cdktn.IResolvable | ComputeRegionBackendServiceBackend[] | undefined;
    private _cdnPolicy;
    get cdnPolicy(): ComputeRegionBackendServiceCdnPolicyOutputReference;
    putCdnPolicy(value: ComputeRegionBackendServiceCdnPolicy): void;
    resetCdnPolicy(): void;
    get cdnPolicyInput(): ComputeRegionBackendServiceCdnPolicy | undefined;
    private _circuitBreakers;
    get circuitBreakers(): ComputeRegionBackendServiceCircuitBreakersOutputReference;
    putCircuitBreakers(value: ComputeRegionBackendServiceCircuitBreakers): void;
    resetCircuitBreakers(): void;
    get circuitBreakersInput(): ComputeRegionBackendServiceCircuitBreakers | undefined;
    private _connectionTrackingPolicy;
    get connectionTrackingPolicy(): ComputeRegionBackendServiceConnectionTrackingPolicyOutputReference;
    putConnectionTrackingPolicy(value: ComputeRegionBackendServiceConnectionTrackingPolicy): void;
    resetConnectionTrackingPolicy(): void;
    get connectionTrackingPolicyInput(): ComputeRegionBackendServiceConnectionTrackingPolicy | undefined;
    private _consistentHash;
    get consistentHash(): ComputeRegionBackendServiceConsistentHashOutputReference;
    putConsistentHash(value: ComputeRegionBackendServiceConsistentHash): void;
    resetConsistentHash(): void;
    get consistentHashInput(): ComputeRegionBackendServiceConsistentHash | undefined;
    private _customMetrics;
    get customMetrics(): ComputeRegionBackendServiceCustomMetricsList;
    putCustomMetrics(value: ComputeRegionBackendServiceCustomMetrics[] | cdktn.IResolvable): void;
    resetCustomMetrics(): void;
    get customMetricsInput(): cdktn.IResolvable | ComputeRegionBackendServiceCustomMetrics[] | undefined;
    private _failoverPolicy;
    get failoverPolicy(): ComputeRegionBackendServiceFailoverPolicyOutputReference;
    putFailoverPolicy(value: ComputeRegionBackendServiceFailoverPolicy): void;
    resetFailoverPolicy(): void;
    get failoverPolicyInput(): ComputeRegionBackendServiceFailoverPolicy | undefined;
    private _haPolicy;
    get haPolicy(): ComputeRegionBackendServiceHaPolicyOutputReference;
    putHaPolicy(value: ComputeRegionBackendServiceHaPolicy): void;
    resetHaPolicy(): void;
    get haPolicyInput(): ComputeRegionBackendServiceHaPolicy | undefined;
    private _iap;
    get iap(): ComputeRegionBackendServiceIapOutputReference;
    putIap(value: ComputeRegionBackendServiceIap): void;
    resetIap(): void;
    get iapInput(): ComputeRegionBackendServiceIap | undefined;
    private _logConfig;
    get logConfig(): ComputeRegionBackendServiceLogConfigOutputReference;
    putLogConfig(value: ComputeRegionBackendServiceLogConfig): void;
    resetLogConfig(): void;
    get logConfigInput(): ComputeRegionBackendServiceLogConfig | undefined;
    private _networkPassThroughLbTrafficPolicy;
    get networkPassThroughLbTrafficPolicy(): ComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyOutputReference;
    putNetworkPassThroughLbTrafficPolicy(value: ComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicy): void;
    resetNetworkPassThroughLbTrafficPolicy(): void;
    get networkPassThroughLbTrafficPolicyInput(): ComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicy | undefined;
    private _outlierDetection;
    get outlierDetection(): ComputeRegionBackendServiceOutlierDetectionOutputReference;
    putOutlierDetection(value: ComputeRegionBackendServiceOutlierDetection): void;
    resetOutlierDetection(): void;
    get outlierDetectionInput(): ComputeRegionBackendServiceOutlierDetection | undefined;
    private _params;
    get params(): ComputeRegionBackendServiceParamsOutputReference;
    putParams(value: ComputeRegionBackendServiceParams): void;
    resetParams(): void;
    get paramsInput(): ComputeRegionBackendServiceParams | undefined;
    private _strongSessionAffinityCookie;
    get strongSessionAffinityCookie(): ComputeRegionBackendServiceStrongSessionAffinityCookieOutputReference;
    putStrongSessionAffinityCookie(value: ComputeRegionBackendServiceStrongSessionAffinityCookie): void;
    resetStrongSessionAffinityCookie(): void;
    get strongSessionAffinityCookieInput(): ComputeRegionBackendServiceStrongSessionAffinityCookie | undefined;
    private _timeouts;
    get timeouts(): ComputeRegionBackendServiceTimeoutsOutputReference;
    putTimeouts(value: ComputeRegionBackendServiceTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeRegionBackendServiceTimeouts | undefined;
    private _tlsSettings;
    get tlsSettings(): ComputeRegionBackendServiceTlsSettingsOutputReference;
    putTlsSettings(value: ComputeRegionBackendServiceTlsSettings): void;
    resetTlsSettings(): void;
    get tlsSettingsInput(): ComputeRegionBackendServiceTlsSettings | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
