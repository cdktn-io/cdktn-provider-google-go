/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AlloydbUserConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifies the alloydb cluster. Must be in the format
    * 'projects/{project}/locations/{location}/clusters/{cluster_id}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_user#cluster AlloydbUser#cluster}
    */
    readonly cluster: string;
    /**
    * List of database roles this database user has.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_user#database_roles AlloydbUser#database_roles}
    */
    readonly databaseRoles?: string[];
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_user#deletion_policy AlloydbUser#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_user#id AlloydbUser#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Password for this database user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_user#password AlloydbUser#password}
    */
    readonly password?: string;
    /**
    * Password for this database user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_user#password_wo AlloydbUser#password_wo}
    */
    readonly passwordWo?: string;
    /**
    * Triggers update of 'password_wo' write-only. Increment this value when an update to 'password_wo' is needed. For more info see [updating write-only arguments](/docs/providers/google/guides/using_write_only_arguments.html#updating-write-only-arguments)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_user#password_wo_version AlloydbUser#password_wo_version}
    */
    readonly passwordWoVersion?: string;
    /**
    * The database role name of the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_user#user_id AlloydbUser#user_id}
    */
    readonly userId: string;
    /**
    * The type of this user. Note that 'ALLOYDB_IAM_GROUP' is currently only supported by
    * the google-beta provider (which uses the v1beta alloydb API). Only new or Google-whitelisted
    * AlloyDB clusters support IAM group authentication. See
    * https://docs.cloud.google.com/alloydb/docs/database-users/manage-iam-auth for details. Possible values: ["ALLOYDB_BUILT_IN", "ALLOYDB_IAM_USER", "ALLOYDB_IAM_GROUP"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_user#user_type AlloydbUser#user_type}
    */
    readonly userType: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_user#timeouts AlloydbUser#timeouts}
    */
    readonly timeouts?: AlloydbUserTimeouts;
}
export interface AlloydbUserTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_user#create AlloydbUser#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_user#delete AlloydbUser#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_user#update AlloydbUser#update}
    */
    readonly update?: string;
}
export declare function alloydbUserTimeoutsToTerraform(struct?: AlloydbUserTimeouts | cdktn.IResolvable): any;
export declare function alloydbUserTimeoutsToHclTerraform(struct?: AlloydbUserTimeouts | cdktn.IResolvable): any;
export declare class AlloydbUserTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbUserTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AlloydbUserTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_user google_alloydb_user}
*/
export declare class AlloydbUser extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_alloydb_user";
    /**
    * Generates CDKTN code for importing a AlloydbUser resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AlloydbUser to import
    * @param importFromId The id of the existing AlloydbUser that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AlloydbUser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_user google_alloydb_user} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AlloydbUserConfig
    */
    constructor(scope: Construct, id: string, config: AlloydbUserConfig);
    private _cluster?;
    get cluster(): string;
    set cluster(value: string);
    get clusterInput(): string | undefined;
    private _databaseRoles?;
    get databaseRoles(): string[];
    set databaseRoles(value: string[]);
    resetDatabaseRoles(): void;
    get databaseRolesInput(): string[] | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _passwordWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get passwordWo(): string;
    set passwordWo(value: string);
    resetPasswordWo(): void;
    get passwordWoInput(): string | undefined;
    private _passwordWoVersion?;
    get passwordWoVersion(): string;
    set passwordWoVersion(value: string);
    resetPasswordWoVersion(): void;
    get passwordWoVersionInput(): string | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    get userIdInput(): string | undefined;
    private _userType?;
    get userType(): string;
    set userType(value: string);
    get userTypeInput(): string | undefined;
    private _timeouts;
    get timeouts(): AlloydbUserTimeoutsOutputReference;
    putTimeouts(value: AlloydbUserTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AlloydbUserTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
