/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeSubnetworkConfig extends cdktn.TerraformMetaArguments {
    /**
    * Typically packets destined to IPs within the subnetwork range that do not match
    * existing resources are dropped and prevented from leaving the VPC.
    * Setting this field to true will allow these packets to match dynamic routes injected
    * via BGP even if their destinations match existing subnet ranges.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#allow_subnet_cidr_routes_overlap ComputeSubnetwork#allow_subnet_cidr_routes_overlap}
    */
    readonly allowSubnetCidrRoutesOverlap?: boolean | cdktn.IResolvable;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#deletion_policy ComputeSubnetwork#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource. Provide this property when
    * you create the resource. This field can be set only at resource
    * creation time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#description ComputeSubnetwork#description}
    */
    readonly description?: string;
    /**
    * The range of external IPv6 addresses that are owned by this subnetwork. It's immutable and can only be
    * specified during creation or the first time the subnet is updated into IPV4_IPV6 dual stack. Changing this
    * field at any other time forces recreation of the subnetwork.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#external_ipv6_prefix ComputeSubnetwork#external_ipv6_prefix}
    */
    readonly externalIpv6Prefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#id ComputeSubnetwork#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The internal IPv6 address range that is assigned to this subnetwork.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#internal_ipv6_prefix ComputeSubnetwork#internal_ipv6_prefix}
    */
    readonly internalIpv6Prefix?: string;
    /**
    * The range of internal addresses that are owned by this subnetwork.
    * Provide this property when you create the subnetwork. For example,
    * 10.0.0.0/8 or 192.168.0.0/16. Ranges must be unique and
    * non-overlapping within a network. Only IPv4 is supported.
    * Field is optional when 'reserved_internal_range' is defined, otherwise required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#ip_cidr_range ComputeSubnetwork#ip_cidr_range}
    */
    readonly ipCidrRange?: string;
    /**
    * Resource reference of a PublicDelegatedPrefix. The PDP must be a sub-PDP
    * in EXTERNAL_IPV6_SUBNETWORK_CREATION or INTERNAL_IPV6_SUBNETWORK_CREATION
    * mode. It's immutable and can only be specified during creation or the first
    * time the subnet is updated into IPV4_IPV6 dual stack. Changing this field at
    * any other time forces recreation of the subnetwork.
    * Use one of the following formats to specify a sub-PDP when creating
    * a dual stack or IPv6-only subnetwork using BYOIP:
    * Full resource URL, as in:
    *   * 'https://www.googleapis.com/compute/v1/projects/{{projectId}}/regions/{{region}}/publicDelegatedPrefixes/{{sub-pdp-name}}'
    * Partial URL, as in:
    *   * 'projects/{{projectId}}/regions/region/publicDelegatedPrefixes/{{sub-pdp-name}}'
    *   * 'regions/{{region}}/publicDelegatedPrefixes/{{sub-pdp-name}}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#ip_collection ComputeSubnetwork#ip_collection}
    */
    readonly ipCollection?: string;
    /**
    * The access type of IPv6 address this subnet holds. It's immutable and can only be specified during creation
    * or the first time the subnet is updated into IPV4_IPV6 dual stack. If the ipv6_type is EXTERNAL then this subnet
    * cannot enable direct path. Changing this field at any other time forces recreation of the subnetwork. Possible values: ["EXTERNAL", "INTERNAL"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#ipv6_access_type ComputeSubnetwork#ipv6_access_type}
    */
    readonly ipv6AccessType?: string;
    /**
    * The name of the resource, provided by the client when initially
    * creating the resource. The name must be 1-63 characters long, and
    * comply with RFC1035. Specifically, the name must be 1-63 characters
    * long and match the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which
    * means the first character must be a lowercase letter, and all
    * following characters must be a dash, lowercase letter, or digit,
    * except the last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#name ComputeSubnetwork#name}
    */
    readonly name: string;
    /**
    * The network this subnet belongs to.
    * Only networks that are in the distributed mode can have subnetworks.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#network ComputeSubnetwork#network}
    */
    readonly network: string;
    /**
    * When enabled, VMs in this subnetwork without external IP addresses can
    * access Google APIs and services by using Private Google Access.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#private_ip_google_access ComputeSubnetwork#private_ip_google_access}
    */
    readonly privateIpGoogleAccess?: boolean | cdktn.IResolvable;
    /**
    * The private IPv6 google access type for the VMs in this subnet.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#private_ipv6_google_access ComputeSubnetwork#private_ipv6_google_access}
    */
    readonly privateIpv6GoogleAccess?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#project ComputeSubnetwork#project}
    */
    readonly project?: string;
    /**
    * The purpose of the resource. This field can be either 'PRIVATE', 'REGIONAL_MANAGED_PROXY', 'GLOBAL_MANAGED_PROXY', 'PRIVATE_SERVICE_CONNECT', 'PEER_MIGRATION', 'PRIVATE_NAT'([Beta](../guides/provider_versions.html.markdown)) or 'CUSTOM_HARDWARE_LINK'([Beta](../guides/provider_versions.html.markdown)).
    * A subnet with purpose set to 'REGIONAL_MANAGED_PROXY' is a user-created subnetwork that is reserved for regional Envoy-based load balancers.
    * A subnetwork in a given region with purpose set to 'GLOBAL_MANAGED_PROXY' is a proxy-only subnet and is shared between all the cross-regional Envoy-based load balancers.
    * A subnetwork with purpose set to 'PRIVATE_SERVICE_CONNECT' reserves the subnet for hosting a Private Service Connect published service.
    * A subnetwork with purpose set to 'PEER_MIGRATION' is a user created subnetwork that is reserved for migrating resources from one peered network to another.
    * A subnetwork with purpose set to 'PRIVATE_NAT' is used as source range for Private NAT gateways.
    * A subnetwork with purpose set to 'CUSTOM_HARDWARE_LINK' is used by Custom Hardware Link.
    * Note that 'REGIONAL_MANAGED_PROXY' is the preferred setting for all regional Envoy load balancers.
    * If unspecified, the purpose defaults to 'PRIVATE'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#purpose ComputeSubnetwork#purpose}
    */
    readonly purpose?: string;
    /**
    * The GCP region for this subnetwork.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#region ComputeSubnetwork#region}
    */
    readonly region?: string;
    /**
    * The ID of the reserved internal range. Must be prefixed with 'networkconnectivity.googleapis.com'
    * E.g. 'networkconnectivity.googleapis.com/projects/{project}/locations/global/internalRanges/{rangeId}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#reserved_internal_range ComputeSubnetwork#reserved_internal_range}
    */
    readonly reservedInternalRange?: string;
    /**
    * 'Configures subnet mask resolution for this subnetwork.' Possible values: ["ARP_ALL_RANGES", "ARP_PRIMARY_RANGE", "ARP_BROADCAST_PRIMARY_RANGE", "ARP_BROADCAST_PRIMARY_RANGE_WITH_LEARNING"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#resolve_subnet_mask ComputeSubnetwork#resolve_subnet_mask}
    */
    readonly resolveSubnetMask?: string;
    /**
    * The role of subnetwork.
    * Currently, this field is only used when 'purpose' is 'REGIONAL_MANAGED_PROXY' or 'GLOBAL_MANAGED_PROXY'.
    * The value can be set to 'ACTIVE' or 'BACKUP'.
    * An 'ACTIVE' subnetwork is one that is currently being used for Envoy-based load balancers in a region.
    * A 'BACKUP' subnetwork is one that is ready to be promoted to 'ACTIVE' or is currently draining. Possible values: ["ACTIVE", "BACKUP"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#role ComputeSubnetwork#role}
    */
    readonly role?: string;
    /**
    * Controls the removal behavior of secondary_ip_range.
    * When false, removing secondary_ip_range from config will not produce a diff as
    * the provider will default to the API's value.
    * When true, the provider will treat removing secondary_ip_range as sending an
    * empty list of secondary IP ranges to the API.
    * Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#send_secondary_ip_range_if_empty ComputeSubnetwork#send_secondary_ip_range_if_empty}
    */
    readonly sendSecondaryIpRangeIfEmpty?: boolean | cdktn.IResolvable;
    /**
    * The stack type for this subnet to identify whether the IPv6 feature is enabled or not.
    * If not specified IPV4_ONLY will be used. Possible values: ["IPV4_ONLY", "IPV4_IPV6", "IPV6_ONLY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#stack_type ComputeSubnetwork#stack_type}
    */
    readonly stackType?: string;
    /**
    * log_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#log_config ComputeSubnetwork#log_config}
    */
    readonly logConfig?: ComputeSubnetworkLogConfig;
    /**
    * params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#params ComputeSubnetwork#params}
    */
    readonly params?: ComputeSubnetworkParams;
    /**
    * secondary_ip_range block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#secondary_ip_range ComputeSubnetwork#secondary_ip_range}
    */
    readonly secondaryIpRange?: ComputeSubnetworkSecondaryIpRange[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#timeouts ComputeSubnetwork#timeouts}
    */
    readonly timeouts?: ComputeSubnetworkTimeouts;
}
export interface ComputeSubnetworkLogConfig {
    /**
    * Can only be specified if VPC flow logging for this subnetwork is enabled.
    * Toggles the aggregation interval for collecting flow logs. Increasing the
    * interval time will reduce the amount of generated flow logs for long
    * lasting connections. Default is an interval of 5 seconds per connection. Default value: "INTERVAL_5_SEC" Possible values: ["INTERVAL_5_SEC", "INTERVAL_30_SEC", "INTERVAL_1_MIN", "INTERVAL_5_MIN", "INTERVAL_10_MIN", "INTERVAL_15_MIN"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#aggregation_interval ComputeSubnetwork#aggregation_interval}
    */
    readonly aggregationInterval?: string;
    /**
    * Export filter used to define which VPC flow logs should be logged, as as CEL expression. See
    * https://cloud.google.com/vpc/docs/flow-logs#filtering for details on how to format this field.
    * The default value is 'true', which evaluates to include everything.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#filter_expr ComputeSubnetwork#filter_expr}
    */
    readonly filterExpr?: string;
    /**
    * Can only be specified if VPC flow logging for this subnetwork is enabled.
    * The value of the field must be in [0, 1]. Set the sampling rate of VPC
    * flow logs within the subnetwork where 1.0 means all collected logs are
    * reported and 0.0 means no logs are reported. Default is 0.5 which means
    * half of all collected logs are reported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#flow_sampling ComputeSubnetwork#flow_sampling}
    */
    readonly flowSampling?: number;
    /**
    * Can only be specified if VPC flow logging for this subnetwork is enabled.
    * Configures whether metadata fields should be added to the reported VPC
    * flow logs. Default value: "INCLUDE_ALL_METADATA" Possible values: ["EXCLUDE_ALL_METADATA", "INCLUDE_ALL_METADATA", "CUSTOM_METADATA"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#metadata ComputeSubnetwork#metadata}
    */
    readonly metadata?: string;
    /**
    * List of metadata fields that should be added to reported logs.
    * Can only be specified if VPC flow logs for this subnetwork is enabled and "metadata" is set to CUSTOM_METADATA.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#metadata_fields ComputeSubnetwork#metadata_fields}
    */
    readonly metadataFields?: string[];
}
export declare function computeSubnetworkLogConfigToTerraform(struct?: ComputeSubnetworkLogConfigOutputReference | ComputeSubnetworkLogConfig): any;
export declare function computeSubnetworkLogConfigToHclTerraform(struct?: ComputeSubnetworkLogConfigOutputReference | ComputeSubnetworkLogConfig): any;
export declare class ComputeSubnetworkLogConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSubnetworkLogConfig | undefined;
    set internalValue(value: ComputeSubnetworkLogConfig | undefined);
    private _aggregationInterval?;
    get aggregationInterval(): string;
    set aggregationInterval(value: string);
    resetAggregationInterval(): void;
    get aggregationIntervalInput(): string | undefined;
    private _filterExpr?;
    get filterExpr(): string;
    set filterExpr(value: string);
    resetFilterExpr(): void;
    get filterExprInput(): string | undefined;
    private _flowSampling?;
    get flowSampling(): number;
    set flowSampling(value: number);
    resetFlowSampling(): void;
    get flowSamplingInput(): number | undefined;
    private _metadata?;
    get metadata(): string;
    set metadata(value: string);
    resetMetadata(): void;
    get metadataInput(): string | undefined;
    private _metadataFields?;
    get metadataFields(): string[];
    set metadataFields(value: string[]);
    resetMetadataFields(): void;
    get metadataFieldsInput(): string[] | undefined;
}
export interface ComputeSubnetworkParams {
    /**
    * Resource manager tags to be bound to the subnetwork. Tag keys and values have the
    * same definition as resource manager tags. Keys must be in the format tagKeys/{tag_key_id},
    * and values are in the format tagValues/456. The field is ignored when empty.
    * The field is immutable and causes resource replacement when mutated. This field is only
    * set at create time and modifying this field after creation will trigger recreation.
    * To apply tags to an existing resource, see the google_tags_tag_binding resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#resource_manager_tags ComputeSubnetwork#resource_manager_tags}
    */
    readonly resourceManagerTags?: {
        [key: string]: string;
    };
}
export declare function computeSubnetworkParamsToTerraform(struct?: ComputeSubnetworkParamsOutputReference | ComputeSubnetworkParams): any;
export declare function computeSubnetworkParamsToHclTerraform(struct?: ComputeSubnetworkParamsOutputReference | ComputeSubnetworkParams): any;
export declare class ComputeSubnetworkParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSubnetworkParams | undefined;
    set internalValue(value: ComputeSubnetworkParams | undefined);
    private _resourceManagerTags?;
    get resourceManagerTags(): {
        [key: string]: string;
    };
    set resourceManagerTags(value: {
        [key: string]: string;
    });
    resetResourceManagerTags(): void;
    get resourceManagerTagsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ComputeSubnetworkSecondaryIpRange {
    /**
    * The range of IP addresses belonging to this subnetwork secondary
    * range. Provide this property when you create the subnetwork.
    * Ranges must be unique and non-overlapping with all primary and
    * secondary IP ranges within a network. Only IPv4 is supported.
    * Field is optional when 'reserved_internal_range' is defined, otherwise required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#ip_cidr_range ComputeSubnetwork#ip_cidr_range}
    */
    readonly ipCidrRange?: string;
    /**
    * The name associated with this subnetwork secondary range, used
    * when adding an alias IP range to a VM instance. The name must
    * be 1-63 characters long, and comply with RFC1035. The name
    * must be unique within the subnetwork.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#range_name ComputeSubnetwork#range_name}
    */
    readonly rangeName: string;
    /**
    * The ID of the reserved internal range. Must be prefixed with 'networkconnectivity.googleapis.com'
    * E.g. 'networkconnectivity.googleapis.com/projects/{project}/locations/global/internalRanges/{rangeId}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#reserved_internal_range ComputeSubnetwork#reserved_internal_range}
    */
    readonly reservedInternalRange?: string;
}
export declare function computeSubnetworkSecondaryIpRangeToTerraform(struct?: ComputeSubnetworkSecondaryIpRange | cdktn.IResolvable): any;
export declare function computeSubnetworkSecondaryIpRangeToHclTerraform(struct?: ComputeSubnetworkSecondaryIpRange | cdktn.IResolvable): any;
export declare class ComputeSubnetworkSecondaryIpRangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeSubnetworkSecondaryIpRange | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeSubnetworkSecondaryIpRange | cdktn.IResolvable | undefined);
    private _ipCidrRange?;
    get ipCidrRange(): string;
    set ipCidrRange(value: string);
    resetIpCidrRange(): void;
    get ipCidrRangeInput(): string | undefined;
    private _rangeName?;
    get rangeName(): string;
    set rangeName(value: string);
    get rangeNameInput(): string | undefined;
    private _reservedInternalRange?;
    get reservedInternalRange(): string;
    set reservedInternalRange(value: string);
    resetReservedInternalRange(): void;
    get reservedInternalRangeInput(): string | undefined;
}
export declare class ComputeSubnetworkSecondaryIpRangeList extends cdktn.ComplexList {
    internalValue?: ComputeSubnetworkSecondaryIpRange[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeSubnetworkSecondaryIpRangeOutputReference;
}
export interface ComputeSubnetworkTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#create ComputeSubnetwork#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#delete ComputeSubnetwork#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#update ComputeSubnetwork#update}
    */
    readonly update?: string;
}
export declare function computeSubnetworkTimeoutsToTerraform(struct?: ComputeSubnetworkTimeouts | cdktn.IResolvable): any;
export declare function computeSubnetworkTimeoutsToHclTerraform(struct?: ComputeSubnetworkTimeouts | cdktn.IResolvable): any;
export declare class ComputeSubnetworkTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSubnetworkTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeSubnetworkTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork google_compute_subnetwork}
*/
export declare class ComputeSubnetwork extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_subnetwork";
    /**
    * Generates CDKTN code for importing a ComputeSubnetwork resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeSubnetwork to import
    * @param importFromId The id of the existing ComputeSubnetwork that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeSubnetwork to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_subnetwork google_compute_subnetwork} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeSubnetworkConfig
    */
    constructor(scope: Construct, id: string, config: ComputeSubnetworkConfig);
    private _allowSubnetCidrRoutesOverlap?;
    get allowSubnetCidrRoutesOverlap(): boolean | cdktn.IResolvable;
    set allowSubnetCidrRoutesOverlap(value: boolean | cdktn.IResolvable);
    resetAllowSubnetCidrRoutesOverlap(): void;
    get allowSubnetCidrRoutesOverlapInput(): boolean | cdktn.IResolvable | undefined;
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _externalIpv6Prefix?;
    get externalIpv6Prefix(): string;
    set externalIpv6Prefix(value: string);
    resetExternalIpv6Prefix(): void;
    get externalIpv6PrefixInput(): string | undefined;
    get fingerprint(): string;
    get gatewayAddress(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _internalIpv6Prefix?;
    get internalIpv6Prefix(): string;
    set internalIpv6Prefix(value: string);
    resetInternalIpv6Prefix(): void;
    get internalIpv6PrefixInput(): string | undefined;
    private _ipCidrRange?;
    get ipCidrRange(): string;
    set ipCidrRange(value: string);
    resetIpCidrRange(): void;
    get ipCidrRangeInput(): string | undefined;
    private _ipCollection?;
    get ipCollection(): string;
    set ipCollection(value: string);
    resetIpCollection(): void;
    get ipCollectionInput(): string | undefined;
    private _ipv6AccessType?;
    get ipv6AccessType(): string;
    set ipv6AccessType(value: string);
    resetIpv6AccessType(): void;
    get ipv6AccessTypeInput(): string | undefined;
    get ipv6CidrRange(): string;
    get ipv6GceEndpoint(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _network?;
    get network(): string;
    set network(value: string);
    get networkInput(): string | undefined;
    private _privateIpGoogleAccess?;
    get privateIpGoogleAccess(): boolean | cdktn.IResolvable;
    set privateIpGoogleAccess(value: boolean | cdktn.IResolvable);
    resetPrivateIpGoogleAccess(): void;
    get privateIpGoogleAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _privateIpv6GoogleAccess?;
    get privateIpv6GoogleAccess(): string;
    set privateIpv6GoogleAccess(value: string);
    resetPrivateIpv6GoogleAccess(): void;
    get privateIpv6GoogleAccessInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _purpose?;
    get purpose(): string;
    set purpose(value: string);
    resetPurpose(): void;
    get purposeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _reservedInternalRange?;
    get reservedInternalRange(): string;
    set reservedInternalRange(value: string);
    resetReservedInternalRange(): void;
    get reservedInternalRangeInput(): string | undefined;
    private _resolveSubnetMask?;
    get resolveSubnetMask(): string;
    set resolveSubnetMask(value: string);
    resetResolveSubnetMask(): void;
    get resolveSubnetMaskInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    resetRole(): void;
    get roleInput(): string | undefined;
    get selfLink(): string;
    private _sendSecondaryIpRangeIfEmpty?;
    get sendSecondaryIpRangeIfEmpty(): boolean | cdktn.IResolvable;
    set sendSecondaryIpRangeIfEmpty(value: boolean | cdktn.IResolvable);
    resetSendSecondaryIpRangeIfEmpty(): void;
    get sendSecondaryIpRangeIfEmptyInput(): boolean | cdktn.IResolvable | undefined;
    private _stackType?;
    get stackType(): string;
    set stackType(value: string);
    resetStackType(): void;
    get stackTypeInput(): string | undefined;
    get state(): string;
    get subnetworkId(): number;
    private _logConfig;
    get logConfig(): ComputeSubnetworkLogConfigOutputReference;
    putLogConfig(value: ComputeSubnetworkLogConfig): void;
    resetLogConfig(): void;
    get logConfigInput(): ComputeSubnetworkLogConfig | undefined;
    private _params;
    get params(): ComputeSubnetworkParamsOutputReference;
    putParams(value: ComputeSubnetworkParams): void;
    resetParams(): void;
    get paramsInput(): ComputeSubnetworkParams | undefined;
    private _secondaryIpRange;
    get secondaryIpRange(): ComputeSubnetworkSecondaryIpRangeList;
    putSecondaryIpRange(value: ComputeSubnetworkSecondaryIpRange[] | cdktn.IResolvable): void;
    resetSecondaryIpRange(): void;
    get secondaryIpRangeInput(): cdktn.IResolvable | ComputeSubnetworkSecondaryIpRange[] | undefined;
    private _timeouts;
    get timeouts(): ComputeSubnetworkTimeoutsOutputReference;
    putTimeouts(value: ComputeSubnetworkTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeSubnetworkTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
