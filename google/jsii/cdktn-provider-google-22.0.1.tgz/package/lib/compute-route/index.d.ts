/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeRouteConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_route#deletion_policy ComputeRoute#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource. Provide this property
    * when you create the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_route#description ComputeRoute#description}
    */
    readonly description?: string;
    /**
    * The destination range of outgoing packets that this route applies to.
    * Only IPv4 is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_route#dest_range ComputeRoute#dest_range}
    */
    readonly destRange: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_route#id ComputeRoute#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the resource. Provided by the client when the resource is
    * created. The name must be 1-63 characters long, and comply with
    * RFC1035.  Specifically, the name must be 1-63 characters long and
    * match the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means
    * the first character must be a lowercase letter, and all following
    * characters must be a dash, lowercase letter, or digit, except the
    * last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_route#name ComputeRoute#name}
    */
    readonly name: string;
    /**
    * The network that this route applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_route#network ComputeRoute#network}
    */
    readonly network: string;
    /**
    * URL to a gateway that should handle matching packets.
    * Currently, you can only specify the internet gateway, using a full or
    * partial valid URL:
    * * 'https://www.googleapis.com/compute/v1/projects/project/global/gateways/default-internet-gateway'
    * * 'projects/project/global/gateways/default-internet-gateway'
    * * 'global/gateways/default-internet-gateway'
    * * The string 'default-internet-gateway'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_route#next_hop_gateway ComputeRoute#next_hop_gateway}
    */
    readonly nextHopGateway?: string;
    /**
    * The IP address or URL to a forwarding rule of type
    * loadBalancingScheme=INTERNAL that should handle matching
    * packets.
    *
    * With the GA provider you can only specify the forwarding
    * rule as a partial or full URL. For example, the following
    * are all valid values:
    * * 10.128.0.56
    * * https://www.googleapis.com/compute/v1/projects/project/regions/region/forwardingRules/forwardingRule
    * * regions/region/forwardingRules/forwardingRule
    *
    * When the beta provider, you can also specify the IP address
    * of a forwarding rule from the same VPC or any peered VPC.
    *
    * Note that this can only be used when the destinationRange is
    * a public (non-RFC 1918) IP CIDR range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_route#next_hop_ilb ComputeRoute#next_hop_ilb}
    */
    readonly nextHopIlb?: string;
    /**
    * URL to an instance that should handle matching packets.
    * You can specify this as a full or partial URL. For example:
    * * 'https://www.googleapis.com/compute/v1/projects/project/zones/zone/instances/instance'
    * * 'projects/project/zones/zone/instances/instance'
    * * 'zones/zone/instances/instance'
    * * Just the instance name, with the zone in 'next_hop_instance_zone'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_route#next_hop_instance ComputeRoute#next_hop_instance}
    */
    readonly nextHopInstance?: string;
    /**
    * The zone of the instance specified in next_hop_instance. Omit if next_hop_instance is specified as a URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_route#next_hop_instance_zone ComputeRoute#next_hop_instance_zone}
    */
    readonly nextHopInstanceZone?: string;
    /**
    * Network IP address of an instance that should handle matching packets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_route#next_hop_ip ComputeRoute#next_hop_ip}
    */
    readonly nextHopIp?: string;
    /**
    * URL to a VpnTunnel that should handle matching packets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_route#next_hop_vpn_tunnel ComputeRoute#next_hop_vpn_tunnel}
    */
    readonly nextHopVpnTunnel?: string;
    /**
    * The priority of this route. Priority is used to break ties in cases
    * where there is more than one matching route of equal prefix length.
    *
    * In the case of two routes with equal prefix length, the one with the
    * lowest-numbered priority value wins.
    *
    * Default value is 1000. Valid range is 0 through 65535.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_route#priority ComputeRoute#priority}
    */
    readonly priority?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_route#project ComputeRoute#project}
    */
    readonly project?: string;
    /**
    * A list of instance tags to which this route applies.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_route#tags ComputeRoute#tags}
    */
    readonly tags?: string[];
    /**
    * params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_route#params ComputeRoute#params}
    */
    readonly params?: ComputeRouteParams;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_route#timeouts ComputeRoute#timeouts}
    */
    readonly timeouts?: ComputeRouteTimeouts;
}
export interface ComputeRouteAsPaths {
}
export declare function computeRouteAsPathsToTerraform(struct?: ComputeRouteAsPaths): any;
export declare function computeRouteAsPathsToHclTerraform(struct?: ComputeRouteAsPaths): any;
export declare class ComputeRouteAsPathsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRouteAsPaths | undefined;
    set internalValue(value: ComputeRouteAsPaths | undefined);
    get asLists(): number[];
    get pathSegmentType(): string;
}
export declare class ComputeRouteAsPathsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRouteAsPathsOutputReference;
}
export interface ComputeRouteWarningsData {
}
export declare function computeRouteWarningsDataToTerraform(struct?: ComputeRouteWarningsData): any;
export declare function computeRouteWarningsDataToHclTerraform(struct?: ComputeRouteWarningsData): any;
export declare class ComputeRouteWarningsDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRouteWarningsData | undefined;
    set internalValue(value: ComputeRouteWarningsData | undefined);
    get key(): string;
    get value(): string;
}
export declare class ComputeRouteWarningsDataList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRouteWarningsDataOutputReference;
}
export interface ComputeRouteWarnings {
}
export declare function computeRouteWarningsToTerraform(struct?: ComputeRouteWarnings): any;
export declare function computeRouteWarningsToHclTerraform(struct?: ComputeRouteWarnings): any;
export declare class ComputeRouteWarningsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRouteWarnings | undefined;
    set internalValue(value: ComputeRouteWarnings | undefined);
    get code(): string;
    private _data;
    get data(): ComputeRouteWarningsDataList;
    get message(): string;
}
export declare class ComputeRouteWarningsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRouteWarningsOutputReference;
}
export interface ComputeRouteParams {
    /**
    * Resource manager tags to be bound to the route. Tag keys and values have the
    * same definition as resource manager tags. Keys must be in the format tagKeys/{tag_key_id},
    * and values are in the format tagValues/456. The field is ignored when empty.
    * The field is immutable and causes resource replacement when mutated. This field is only
    * set at create time and modifying this field after creation will trigger recreation.
    * To apply tags to an existing resource, see the google_tags_tag_binding resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_route#resource_manager_tags ComputeRoute#resource_manager_tags}
    */
    readonly resourceManagerTags?: {
        [key: string]: string;
    };
}
export declare function computeRouteParamsToTerraform(struct?: ComputeRouteParamsOutputReference | ComputeRouteParams): any;
export declare function computeRouteParamsToHclTerraform(struct?: ComputeRouteParamsOutputReference | ComputeRouteParams): any;
export declare class ComputeRouteParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRouteParams | undefined;
    set internalValue(value: ComputeRouteParams | undefined);
    private _resourceManagerTags?;
    get resourceManagerTags(): {
        [key: string]: string;
    };
    set resourceManagerTags(value: {
        [key: string]: string;
    });
    resetResourceManagerTags(): void;
    get resourceManagerTagsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ComputeRouteTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_route#create ComputeRoute#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_route#delete ComputeRoute#delete}
    */
    readonly delete?: string;
}
export declare function computeRouteTimeoutsToTerraform(struct?: ComputeRouteTimeouts | cdktn.IResolvable): any;
export declare function computeRouteTimeoutsToHclTerraform(struct?: ComputeRouteTimeouts | cdktn.IResolvable): any;
export declare class ComputeRouteTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRouteTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRouteTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_route google_compute_route}
*/
export declare class ComputeRoute extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_route";
    /**
    * Generates CDKTN code for importing a ComputeRoute resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeRoute to import
    * @param importFromId The id of the existing ComputeRoute that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_route#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeRoute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_route google_compute_route} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeRouteConfig
    */
    constructor(scope: Construct, id: string, config: ComputeRouteConfig);
    private _asPaths;
    get asPaths(): ComputeRouteAsPathsList;
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _destRange?;
    get destRange(): string;
    set destRange(value: string);
    get destRangeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _network?;
    get network(): string;
    set network(value: string);
    get networkInput(): string | undefined;
    private _nextHopGateway?;
    get nextHopGateway(): string;
    set nextHopGateway(value: string);
    resetNextHopGateway(): void;
    get nextHopGatewayInput(): string | undefined;
    get nextHopHub(): string;
    private _nextHopIlb?;
    get nextHopIlb(): string;
    set nextHopIlb(value: string);
    resetNextHopIlb(): void;
    get nextHopIlbInput(): string | undefined;
    private _nextHopInstance?;
    get nextHopInstance(): string;
    set nextHopInstance(value: string);
    resetNextHopInstance(): void;
    get nextHopInstanceInput(): string | undefined;
    private _nextHopInstanceZone?;
    get nextHopInstanceZone(): string;
    set nextHopInstanceZone(value: string);
    resetNextHopInstanceZone(): void;
    get nextHopInstanceZoneInput(): string | undefined;
    get nextHopInterRegionCost(): string;
    private _nextHopIp?;
    get nextHopIp(): string;
    set nextHopIp(value: string);
    resetNextHopIp(): void;
    get nextHopIpInput(): string | undefined;
    get nextHopMed(): string;
    get nextHopNetwork(): string;
    get nextHopOrigin(): string;
    get nextHopPeering(): string;
    private _nextHopVpnTunnel?;
    get nextHopVpnTunnel(): string;
    set nextHopVpnTunnel(value: string);
    resetNextHopVpnTunnel(): void;
    get nextHopVpnTunnelInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get routeStatus(): string;
    get routeType(): string;
    get selfLink(): string;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _warnings;
    get warnings(): ComputeRouteWarningsList;
    private _params;
    get params(): ComputeRouteParamsOutputReference;
    putParams(value: ComputeRouteParams): void;
    resetParams(): void;
    get paramsInput(): ComputeRouteParams | undefined;
    private _timeouts;
    get timeouts(): ComputeRouteTimeoutsOutputReference;
    putTimeouts(value: ComputeRouteTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeRouteTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
