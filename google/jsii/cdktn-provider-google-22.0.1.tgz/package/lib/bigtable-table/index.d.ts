/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BigtableTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Duration to retain change stream data for the table. Set to 0 to disable. Must be between 1 and 7 days.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_table#change_stream_retention BigtableTable#change_stream_retention}
    */
    readonly changeStreamRetention?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_table#deletion_policy BigtableTable#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * A field to make the table protected against data loss i.e. when set to PROTECTED, deleting the table, the column families in the table, and the instance containing the table would be prohibited. If not provided, currently deletion protection will be set to UNPROTECTED as it is the API default value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_table#deletion_protection BigtableTable#deletion_protection}
    */
    readonly deletionProtection?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_table#id BigtableTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the Bigtable instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_table#instance_name BigtableTable#instance_name}
    */
    readonly instanceName: string;
    /**
    * The name of the table. Must be 1-50 characters and must only contain hyphens, underscores, periods, letters and numbers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_table#name BigtableTable#name}
    */
    readonly name: string;
    /**
    * The ID of the project in which the resource belongs. If it is not provided, the provider project is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_table#project BigtableTable#project}
    */
    readonly project?: string;
    /**
    * Defines the row key schema of a table. To create or update a table with a row key schema, specify this argument.
    * 					Note that in-place update is not supported, and any in-place modification to the schema will lead to failure.
    * 				    To update a schema, please clear it (by omitting the field), and update the resource again with a new schema.\n
    *
    * 					The schema must be a valid JSON encoded string representing a Type's struct protobuf message. Note that for bytes sequence (like delimited_bytes.delimiter)
    * 					the delimiter must be base64 encoded. For example, if you want to set a delimiter to a single byte character "#", it should be set to "Iw==", which is the base64 encoding of the byte sequence "#".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_table#row_key_schema BigtableTable#row_key_schema}
    */
    readonly rowKeySchema?: string;
    /**
    * A list of predefined keys to split the table on. !> Warning: Modifying the split_keys of an existing table will cause Terraform to delete/recreate the entire google_bigtable_table resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_table#split_keys BigtableTable#split_keys}
    */
    readonly splitKeys?: string[];
    /**
    * automated_backup_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_table#automated_backup_policy BigtableTable#automated_backup_policy}
    */
    readonly automatedBackupPolicy?: BigtableTableAutomatedBackupPolicy;
    /**
    * column_family block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_table#column_family BigtableTable#column_family}
    */
    readonly columnFamily?: BigtableTableColumnFamily[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_table#timeouts BigtableTable#timeouts}
    */
    readonly timeouts?: BigtableTableTimeouts;
}
export interface BigtableTableAutomatedBackupPolicy {
    /**
    * How frequently automated backups should occur.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_table#frequency BigtableTable#frequency}
    */
    readonly frequency?: string;
    /**
    * A list of Cloud Bigtable zones where automated backups are allowed to be created. If empty, automated backups will be created in all zones of the instance. Locations are in the format projects/{project}/locations/{zone}. This field can only be set for tables in Enterprise Plus instances.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_table#locations BigtableTable#locations}
    */
    readonly locations?: string[];
    /**
    * How long the automated backups should be retained.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_table#retention_period BigtableTable#retention_period}
    */
    readonly retentionPeriod?: string;
}
export declare function bigtableTableAutomatedBackupPolicyToTerraform(struct?: BigtableTableAutomatedBackupPolicyOutputReference | BigtableTableAutomatedBackupPolicy): any;
export declare function bigtableTableAutomatedBackupPolicyToHclTerraform(struct?: BigtableTableAutomatedBackupPolicyOutputReference | BigtableTableAutomatedBackupPolicy): any;
export declare class BigtableTableAutomatedBackupPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigtableTableAutomatedBackupPolicy | undefined;
    set internalValue(value: BigtableTableAutomatedBackupPolicy | undefined);
    private _frequency?;
    get frequency(): string;
    set frequency(value: string);
    resetFrequency(): void;
    get frequencyInput(): string | undefined;
    private _locations?;
    get locations(): string[];
    set locations(value: string[]);
    resetLocations(): void;
    get locationsInput(): string[] | undefined;
    private _retentionPeriod?;
    get retentionPeriod(): string;
    set retentionPeriod(value: string);
    resetRetentionPeriod(): void;
    get retentionPeriodInput(): string | undefined;
}
export interface BigtableTableColumnFamily {
    /**
    * The name of the column family.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_table#family BigtableTable#family}
    */
    readonly family: string;
    /**
    * The type of the column family.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_table#type BigtableTable#type}
    */
    readonly type?: string;
}
export declare function bigtableTableColumnFamilyToTerraform(struct?: BigtableTableColumnFamily | cdktn.IResolvable): any;
export declare function bigtableTableColumnFamilyToHclTerraform(struct?: BigtableTableColumnFamily | cdktn.IResolvable): any;
export declare class BigtableTableColumnFamilyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BigtableTableColumnFamily | cdktn.IResolvable | undefined;
    set internalValue(value: BigtableTableColumnFamily | cdktn.IResolvable | undefined);
    private _family?;
    get family(): string;
    set family(value: string);
    get familyInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class BigtableTableColumnFamilyList extends cdktn.ComplexList {
    internalValue?: BigtableTableColumnFamily[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BigtableTableColumnFamilyOutputReference;
}
export interface BigtableTableTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_table#create BigtableTable#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_table#update BigtableTable#update}
    */
    readonly update?: string;
}
export declare function bigtableTableTimeoutsToTerraform(struct?: BigtableTableTimeouts | cdktn.IResolvable): any;
export declare function bigtableTableTimeoutsToHclTerraform(struct?: BigtableTableTimeouts | cdktn.IResolvable): any;
export declare class BigtableTableTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigtableTableTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BigtableTableTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_table google_bigtable_table}
*/
export declare class BigtableTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_bigtable_table";
    /**
    * Generates CDKTN code for importing a BigtableTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BigtableTable to import
    * @param importFromId The id of the existing BigtableTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BigtableTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_table google_bigtable_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BigtableTableConfig
    */
    constructor(scope: Construct, id: string, config: BigtableTableConfig);
    private _changeStreamRetention?;
    get changeStreamRetention(): string;
    set changeStreamRetention(value: string);
    resetChangeStreamRetention(): void;
    get changeStreamRetentionInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _deletionProtection?;
    get deletionProtection(): string;
    set deletionProtection(value: string);
    resetDeletionProtection(): void;
    get deletionProtectionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceName?;
    get instanceName(): string;
    set instanceName(value: string);
    get instanceNameInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _rowKeySchema?;
    get rowKeySchema(): string;
    set rowKeySchema(value: string);
    resetRowKeySchema(): void;
    get rowKeySchemaInput(): string | undefined;
    private _splitKeys?;
    get splitKeys(): string[];
    set splitKeys(value: string[]);
    resetSplitKeys(): void;
    get splitKeysInput(): string[] | undefined;
    private _automatedBackupPolicy;
    get automatedBackupPolicy(): BigtableTableAutomatedBackupPolicyOutputReference;
    putAutomatedBackupPolicy(value: BigtableTableAutomatedBackupPolicy): void;
    resetAutomatedBackupPolicy(): void;
    get automatedBackupPolicyInput(): BigtableTableAutomatedBackupPolicy | undefined;
    private _columnFamily;
    get columnFamily(): BigtableTableColumnFamilyList;
    putColumnFamily(value: BigtableTableColumnFamily[] | cdktn.IResolvable): void;
    resetColumnFamily(): void;
    get columnFamilyInput(): cdktn.IResolvable | BigtableTableColumnFamily[] | undefined;
    private _timeouts;
    get timeouts(): BigtableTableTimeoutsOutputReference;
    putTimeouts(value: BigtableTableTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BigtableTableTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
