/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ClouddeployCustomTargetTypeConfig extends cdktn.TerraformMetaArguments {
    /**
    * User annotations. These attributes can only be set and used by the user, and not by Cloud Deploy. See https://google.aip.dev/128#annotations for more details such as format and size limitations.
    *
    * **Note**: This field is non-authoritative, and will only manage the annotations present in your configuration.
    * Please refer to the field 'effective_annotations' for all of the annotations present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#annotations ClouddeployCustomTargetType#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#deletion_policy ClouddeployCustomTargetType#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Description of the 'CustomTargetType'. Max length is 255 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#description ClouddeployCustomTargetType#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#id ClouddeployCustomTargetType#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Labels are attributes that can be set and used by both the user and by Cloud Deploy. Labels must meet the following constraints: * Keys and values can contain only lowercase letters, numeric characters, underscores, and dashes. * All characters must use UTF-8 encoding, and international characters are allowed. * Keys must start with a lowercase letter or international character. * Each resource is limited to a maximum of 64 labels. Both keys and values are additionally constrained to be <= 128 bytes.
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#labels ClouddeployCustomTargetType#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The location of the source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#location ClouddeployCustomTargetType#location}
    */
    readonly location: string;
    /**
    * Name of the 'CustomTargetType'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#name ClouddeployCustomTargetType#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#project ClouddeployCustomTargetType#project}
    */
    readonly project?: string;
    /**
    * custom_actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#custom_actions ClouddeployCustomTargetType#custom_actions}
    */
    readonly customActions?: ClouddeployCustomTargetTypeCustomActions;
    /**
    * tasks block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#tasks ClouddeployCustomTargetType#tasks}
    */
    readonly tasks?: ClouddeployCustomTargetTypeTasks;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#timeouts ClouddeployCustomTargetType#timeouts}
    */
    readonly timeouts?: ClouddeployCustomTargetTypeTimeouts;
}
export interface ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGit {
    /**
    * Relative path from the repository root to the Skaffold file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#path ClouddeployCustomTargetType#path}
    */
    readonly path?: string;
    /**
    * Git ref the package should be cloned from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#ref ClouddeployCustomTargetType#ref}
    */
    readonly ref?: string;
    /**
    * Git repository the package should be cloned from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#repo ClouddeployCustomTargetType#repo}
    */
    readonly repo: string;
}
export declare function clouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGitToTerraform(struct?: ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGitOutputReference | ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGit): any;
export declare function clouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGitToHclTerraform(struct?: ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGitOutputReference | ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGit): any;
export declare class ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGit | undefined;
    set internalValue(value: ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGit | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _ref?;
    get ref(): string;
    set ref(value: string);
    resetRef(): void;
    get refInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    get repoInput(): string | undefined;
}
export interface ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudBuildRepo {
    /**
    * Relative path from the repository root to the Skaffold file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#path ClouddeployCustomTargetType#path}
    */
    readonly path?: string;
    /**
    * Branch or tag to use when cloning the repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#ref ClouddeployCustomTargetType#ref}
    */
    readonly ref?: string;
    /**
    * Cloud Build 2nd gen repository in the format of 'projects/<project>/locations/<location>/connections/<connection>/repositories/<repository>'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#repository ClouddeployCustomTargetType#repository}
    */
    readonly repository: string;
}
export declare function clouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudBuildRepoToTerraform(struct?: ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudBuildRepoOutputReference | ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudBuildRepo): any;
export declare function clouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudBuildRepoToHclTerraform(struct?: ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudBuildRepoOutputReference | ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudBuildRepo): any;
export declare class ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudBuildRepoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudBuildRepo | undefined;
    set internalValue(value: ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudBuildRepo | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _ref?;
    get ref(): string;
    set ref(value: string);
    resetRef(): void;
    get refInput(): string | undefined;
    private _repository?;
    get repository(): string;
    set repository(value: string);
    get repositoryInput(): string | undefined;
}
export interface ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudStorage {
    /**
    * Relative path from the source to the Skaffold file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#path ClouddeployCustomTargetType#path}
    */
    readonly path?: string;
    /**
    * Cloud Storage source paths to copy recursively. For example, providing 'gs://my-bucket/dir/configs/*' will result in Skaffold copying all files within the 'dir/configs' directory in the bucket 'my-bucket'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#source ClouddeployCustomTargetType#source}
    */
    readonly source: string;
}
export declare function clouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudStorageToTerraform(struct?: ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudStorageOutputReference | ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudStorage): any;
export declare function clouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudStorageToHclTerraform(struct?: ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudStorageOutputReference | ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudStorage): any;
export declare class ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudStorageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudStorage | undefined;
    set internalValue(value: ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudStorage | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
}
export interface ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModules {
    /**
    * The Skaffold Config modules to use from the specified source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#configs ClouddeployCustomTargetType#configs}
    */
    readonly configs?: string[];
    /**
    * git block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#git ClouddeployCustomTargetType#git}
    */
    readonly git?: ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGit;
    /**
    * google_cloud_build_repo block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#google_cloud_build_repo ClouddeployCustomTargetType#google_cloud_build_repo}
    */
    readonly googleCloudBuildRepo?: ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudBuildRepo;
    /**
    * google_cloud_storage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#google_cloud_storage ClouddeployCustomTargetType#google_cloud_storage}
    */
    readonly googleCloudStorage?: ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudStorage;
}
export declare function clouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesToTerraform(struct?: ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModules | cdktn.IResolvable): any;
export declare function clouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesToHclTerraform(struct?: ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModules | cdktn.IResolvable): any;
export declare class ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModules | cdktn.IResolvable | undefined;
    set internalValue(value: ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModules | cdktn.IResolvable | undefined);
    private _configs?;
    get configs(): string[];
    set configs(value: string[]);
    resetConfigs(): void;
    get configsInput(): string[] | undefined;
    private _git;
    get git(): ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGitOutputReference;
    putGit(value: ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGit): void;
    resetGit(): void;
    get gitInput(): ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGit | undefined;
    private _googleCloudBuildRepo;
    get googleCloudBuildRepo(): ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudBuildRepoOutputReference;
    putGoogleCloudBuildRepo(value: ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudBuildRepo): void;
    resetGoogleCloudBuildRepo(): void;
    get googleCloudBuildRepoInput(): ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudBuildRepo | undefined;
    private _googleCloudStorage;
    get googleCloudStorage(): ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudStorageOutputReference;
    putGoogleCloudStorage(value: ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudStorage): void;
    resetGoogleCloudStorage(): void;
    get googleCloudStorageInput(): ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesGoogleCloudStorage | undefined;
}
export declare class ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesList extends cdktn.ComplexList {
    internalValue?: ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesOutputReference;
}
export interface ClouddeployCustomTargetTypeCustomActions {
    /**
    * The Skaffold custom action responsible for deploy operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#deploy_action ClouddeployCustomTargetType#deploy_action}
    */
    readonly deployAction: string;
    /**
    * The Skaffold custom action responsible for render operations. If not provided then Cloud Deploy will perform the render operations via 'skaffold render'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#render_action ClouddeployCustomTargetType#render_action}
    */
    readonly renderAction?: string;
    /**
    * include_skaffold_modules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#include_skaffold_modules ClouddeployCustomTargetType#include_skaffold_modules}
    */
    readonly includeSkaffoldModules?: ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModules[] | cdktn.IResolvable;
}
export declare function clouddeployCustomTargetTypeCustomActionsToTerraform(struct?: ClouddeployCustomTargetTypeCustomActionsOutputReference | ClouddeployCustomTargetTypeCustomActions): any;
export declare function clouddeployCustomTargetTypeCustomActionsToHclTerraform(struct?: ClouddeployCustomTargetTypeCustomActionsOutputReference | ClouddeployCustomTargetTypeCustomActions): any;
export declare class ClouddeployCustomTargetTypeCustomActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddeployCustomTargetTypeCustomActions | undefined;
    set internalValue(value: ClouddeployCustomTargetTypeCustomActions | undefined);
    private _deployAction?;
    get deployAction(): string;
    set deployAction(value: string);
    get deployActionInput(): string | undefined;
    private _renderAction?;
    get renderAction(): string;
    set renderAction(value: string);
    resetRenderAction(): void;
    get renderActionInput(): string | undefined;
    private _includeSkaffoldModules;
    get includeSkaffoldModules(): ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModulesList;
    putIncludeSkaffoldModules(value: ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModules[] | cdktn.IResolvable): void;
    resetIncludeSkaffoldModules(): void;
    get includeSkaffoldModulesInput(): cdktn.IResolvable | ClouddeployCustomTargetTypeCustomActionsIncludeSkaffoldModules[] | undefined;
}
export interface ClouddeployCustomTargetTypeTasksDeployContainer {
    /**
    * Args is the container arguments to use. This overrides the default arguments defined in the container image.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#args ClouddeployCustomTargetType#args}
    */
    readonly args?: string[];
    /**
    * Command is the container entrypoint to use. This overrides the default entrypoint defined in the container image.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#command ClouddeployCustomTargetType#command}
    */
    readonly command?: string[];
    /**
    * Environment variables that are set in the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#env ClouddeployCustomTargetType#env}
    */
    readonly env?: {
        [key: string]: string;
    };
    /**
    * Image is the container image to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#image ClouddeployCustomTargetType#image}
    */
    readonly image: string;
}
export declare function clouddeployCustomTargetTypeTasksDeployContainerToTerraform(struct?: ClouddeployCustomTargetTypeTasksDeployContainerOutputReference | ClouddeployCustomTargetTypeTasksDeployContainer): any;
export declare function clouddeployCustomTargetTypeTasksDeployContainerToHclTerraform(struct?: ClouddeployCustomTargetTypeTasksDeployContainerOutputReference | ClouddeployCustomTargetTypeTasksDeployContainer): any;
export declare class ClouddeployCustomTargetTypeTasksDeployContainerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddeployCustomTargetTypeTasksDeployContainer | undefined;
    set internalValue(value: ClouddeployCustomTargetTypeTasksDeployContainer | undefined);
    private _args?;
    get args(): string[];
    set args(value: string[]);
    resetArgs(): void;
    get argsInput(): string[] | undefined;
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
    private _env?;
    get env(): {
        [key: string]: string;
    };
    set env(value: {
        [key: string]: string;
    });
    resetEnv(): void;
    get envInput(): {
        [key: string]: string;
    } | undefined;
    private _image?;
    get image(): string;
    set image(value: string);
    get imageInput(): string | undefined;
}
export interface ClouddeployCustomTargetTypeTasksDeploy {
    /**
    * container block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#container ClouddeployCustomTargetType#container}
    */
    readonly container?: ClouddeployCustomTargetTypeTasksDeployContainer;
}
export declare function clouddeployCustomTargetTypeTasksDeployToTerraform(struct?: ClouddeployCustomTargetTypeTasksDeployOutputReference | ClouddeployCustomTargetTypeTasksDeploy): any;
export declare function clouddeployCustomTargetTypeTasksDeployToHclTerraform(struct?: ClouddeployCustomTargetTypeTasksDeployOutputReference | ClouddeployCustomTargetTypeTasksDeploy): any;
export declare class ClouddeployCustomTargetTypeTasksDeployOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddeployCustomTargetTypeTasksDeploy | undefined;
    set internalValue(value: ClouddeployCustomTargetTypeTasksDeploy | undefined);
    private _container;
    get container(): ClouddeployCustomTargetTypeTasksDeployContainerOutputReference;
    putContainer(value: ClouddeployCustomTargetTypeTasksDeployContainer): void;
    resetContainer(): void;
    get containerInput(): ClouddeployCustomTargetTypeTasksDeployContainer | undefined;
}
export interface ClouddeployCustomTargetTypeTasksRenderContainer {
    /**
    * Args is the container arguments to use. This overrides the default arguments defined in the container image.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#args ClouddeployCustomTargetType#args}
    */
    readonly args?: string[];
    /**
    * Command is the container entrypoint to use. This overrides the default entrypoint defined in the container image.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#command ClouddeployCustomTargetType#command}
    */
    readonly command?: string[];
    /**
    * Environment variables that are set in the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#env ClouddeployCustomTargetType#env}
    */
    readonly env?: {
        [key: string]: string;
    };
    /**
    * Image is the container image to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#image ClouddeployCustomTargetType#image}
    */
    readonly image: string;
}
export declare function clouddeployCustomTargetTypeTasksRenderContainerToTerraform(struct?: ClouddeployCustomTargetTypeTasksRenderContainerOutputReference | ClouddeployCustomTargetTypeTasksRenderContainer): any;
export declare function clouddeployCustomTargetTypeTasksRenderContainerToHclTerraform(struct?: ClouddeployCustomTargetTypeTasksRenderContainerOutputReference | ClouddeployCustomTargetTypeTasksRenderContainer): any;
export declare class ClouddeployCustomTargetTypeTasksRenderContainerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddeployCustomTargetTypeTasksRenderContainer | undefined;
    set internalValue(value: ClouddeployCustomTargetTypeTasksRenderContainer | undefined);
    private _args?;
    get args(): string[];
    set args(value: string[]);
    resetArgs(): void;
    get argsInput(): string[] | undefined;
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
    private _env?;
    get env(): {
        [key: string]: string;
    };
    set env(value: {
        [key: string]: string;
    });
    resetEnv(): void;
    get envInput(): {
        [key: string]: string;
    } | undefined;
    private _image?;
    get image(): string;
    set image(value: string);
    get imageInput(): string | undefined;
}
export interface ClouddeployCustomTargetTypeTasksRender {
    /**
    * container block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#container ClouddeployCustomTargetType#container}
    */
    readonly container?: ClouddeployCustomTargetTypeTasksRenderContainer;
}
export declare function clouddeployCustomTargetTypeTasksRenderToTerraform(struct?: ClouddeployCustomTargetTypeTasksRenderOutputReference | ClouddeployCustomTargetTypeTasksRender): any;
export declare function clouddeployCustomTargetTypeTasksRenderToHclTerraform(struct?: ClouddeployCustomTargetTypeTasksRenderOutputReference | ClouddeployCustomTargetTypeTasksRender): any;
export declare class ClouddeployCustomTargetTypeTasksRenderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddeployCustomTargetTypeTasksRender | undefined;
    set internalValue(value: ClouddeployCustomTargetTypeTasksRender | undefined);
    private _container;
    get container(): ClouddeployCustomTargetTypeTasksRenderContainerOutputReference;
    putContainer(value: ClouddeployCustomTargetTypeTasksRenderContainer): void;
    resetContainer(): void;
    get containerInput(): ClouddeployCustomTargetTypeTasksRenderContainer | undefined;
}
export interface ClouddeployCustomTargetTypeTasks {
    /**
    * deploy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#deploy ClouddeployCustomTargetType#deploy}
    */
    readonly deploy: ClouddeployCustomTargetTypeTasksDeploy;
    /**
    * render block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#render ClouddeployCustomTargetType#render}
    */
    readonly render?: ClouddeployCustomTargetTypeTasksRender;
}
export declare function clouddeployCustomTargetTypeTasksToTerraform(struct?: ClouddeployCustomTargetTypeTasksOutputReference | ClouddeployCustomTargetTypeTasks): any;
export declare function clouddeployCustomTargetTypeTasksToHclTerraform(struct?: ClouddeployCustomTargetTypeTasksOutputReference | ClouddeployCustomTargetTypeTasks): any;
export declare class ClouddeployCustomTargetTypeTasksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddeployCustomTargetTypeTasks | undefined;
    set internalValue(value: ClouddeployCustomTargetTypeTasks | undefined);
    private _deploy;
    get deploy(): ClouddeployCustomTargetTypeTasksDeployOutputReference;
    putDeploy(value: ClouddeployCustomTargetTypeTasksDeploy): void;
    get deployInput(): ClouddeployCustomTargetTypeTasksDeploy | undefined;
    private _render;
    get render(): ClouddeployCustomTargetTypeTasksRenderOutputReference;
    putRender(value: ClouddeployCustomTargetTypeTasksRender): void;
    resetRender(): void;
    get renderInput(): ClouddeployCustomTargetTypeTasksRender | undefined;
}
export interface ClouddeployCustomTargetTypeTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#create ClouddeployCustomTargetType#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#delete ClouddeployCustomTargetType#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#update ClouddeployCustomTargetType#update}
    */
    readonly update?: string;
}
export declare function clouddeployCustomTargetTypeTimeoutsToTerraform(struct?: ClouddeployCustomTargetTypeTimeouts | cdktn.IResolvable): any;
export declare function clouddeployCustomTargetTypeTimeoutsToHclTerraform(struct?: ClouddeployCustomTargetTypeTimeouts | cdktn.IResolvable): any;
export declare class ClouddeployCustomTargetTypeTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddeployCustomTargetTypeTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ClouddeployCustomTargetTypeTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type google_clouddeploy_custom_target_type}
*/
export declare class ClouddeployCustomTargetType extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_clouddeploy_custom_target_type";
    /**
    * Generates CDKTN code for importing a ClouddeployCustomTargetType resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ClouddeployCustomTargetType to import
    * @param importFromId The id of the existing ClouddeployCustomTargetType that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ClouddeployCustomTargetType to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_custom_target_type google_clouddeploy_custom_target_type} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ClouddeployCustomTargetTypeConfig
    */
    constructor(scope: Construct, id: string, config: ClouddeployCustomTargetTypeConfig);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    get createTime(): string;
    get customTargetTypeId(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _effectiveAnnotations;
    get effectiveAnnotations(): cdktn.StringMap;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get uid(): string;
    get updateTime(): string;
    private _customActions;
    get customActions(): ClouddeployCustomTargetTypeCustomActionsOutputReference;
    putCustomActions(value: ClouddeployCustomTargetTypeCustomActions): void;
    resetCustomActions(): void;
    get customActionsInput(): ClouddeployCustomTargetTypeCustomActions | undefined;
    private _tasks;
    get tasks(): ClouddeployCustomTargetTypeTasksOutputReference;
    putTasks(value: ClouddeployCustomTargetTypeTasks): void;
    resetTasks(): void;
    get tasksInput(): ClouddeployCustomTargetTypeTasks | undefined;
    private _timeouts;
    get timeouts(): ClouddeployCustomTargetTypeTimeoutsOutputReference;
    putTimeouts(value: ClouddeployCustomTargetTypeTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ClouddeployCustomTargetTypeTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
