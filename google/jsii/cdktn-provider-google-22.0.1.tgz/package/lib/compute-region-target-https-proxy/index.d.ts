/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeRegionTargetHttpsProxyConfig extends cdktn.TerraformMetaArguments {
    /**
    * URLs to certificate manager certificate resources that are used to authenticate connections between users and the load balancer.
    * sslCertificates and certificateManagerCertificates can't be defined together.
    * Accepted format is '//certificatemanager.googleapis.com/projects/{project}/locations/{location}/certificates/{resourceName}' or just the self_link 'projects/{project}/locations/{location}/certificates/{resourceName}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_target_https_proxy#certificate_manager_certificates ComputeRegionTargetHttpsProxy#certificate_manager_certificates}
    */
    readonly certificateManagerCertificates?: string[];
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_target_https_proxy#deletion_policy ComputeRegionTargetHttpsProxy#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_target_https_proxy#description ComputeRegionTargetHttpsProxy#description}
    */
    readonly description?: string;
    /**
    * Specifies how long to keep a connection open, after completing a response,
    * while there is no matching traffic (in seconds). If an HTTP keepalive is
    * not specified, a default value (600 seconds) will be used. For Regioanl
    * HTTP(S) load balancer, the minimum allowed value is 5 seconds and the
    * maximum allowed value is 600 seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_target_https_proxy#http_keep_alive_timeout_sec ComputeRegionTargetHttpsProxy#http_keep_alive_timeout_sec}
    */
    readonly httpKeepAliveTimeoutSec?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_target_https_proxy#id ComputeRegionTargetHttpsProxy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the resource. Provided by the client when the resource is
    * created. The name must be 1-63 characters long, and comply with
    * RFC1035. Specifically, the name must be 1-63 characters long and match
    * the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the
    * first character must be a lowercase letter, and all following
    * characters must be a dash, lowercase letter, or digit, except the last
    * character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_target_https_proxy#name ComputeRegionTargetHttpsProxy#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_target_https_proxy#project ComputeRegionTargetHttpsProxy#project}
    */
    readonly project?: string;
    /**
    * The Region in which the created target https proxy should reside.
    * If it is not provided, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_target_https_proxy#region ComputeRegionTargetHttpsProxy#region}
    */
    readonly region?: string;
    /**
    * A URL referring to a networksecurity.ServerTlsPolicy
    * resource that describes how the proxy should authenticate inbound
    * traffic. serverTlsPolicy only applies to a global TargetHttpsProxy
    * attached to globalForwardingRules with the loadBalancingScheme
    * set to INTERNAL_SELF_MANAGED or EXTERNAL or EXTERNAL_MANAGED.
    * For details which ServerTlsPolicy resources are accepted with
    * INTERNAL_SELF_MANAGED and which with EXTERNAL, EXTERNAL_MANAGED
    * loadBalancingScheme consult ServerTlsPolicy documentation.
    * If left blank, communications are not encrypted.
    *
    * If you remove this field from your configuration at the same time as
    * deleting or recreating a referenced ServerTlsPolicy resource, you will
    * receive a resourceInUseByAnotherResource error. Use lifecycle.create_before_destroy
    * within the ServerTlsPolicy resource to avoid this.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_target_https_proxy#server_tls_policy ComputeRegionTargetHttpsProxy#server_tls_policy}
    */
    readonly serverTlsPolicy?: string;
    /**
    * URLs to SslCertificate resources that are used to authenticate connections between users and the load balancer.
    * At least one SSL certificate must be specified. Currently, you may specify up to 15 SSL certificates.
    * sslCertificates do not apply when the load balancing scheme is set to INTERNAL_SELF_MANAGED.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_target_https_proxy#ssl_certificates ComputeRegionTargetHttpsProxy#ssl_certificates}
    */
    readonly sslCertificates?: string[];
    /**
    * A reference to the Region SslPolicy resource that will be associated with
    * the TargetHttpsProxy resource. If not set, the TargetHttpsProxy
    * resource will not have any SSL policy configured.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_target_https_proxy#ssl_policy ComputeRegionTargetHttpsProxy#ssl_policy}
    */
    readonly sslPolicy?: string;
    /**
    * A reference to the RegionUrlMap resource that defines the mapping from URL
    * to the RegionBackendService.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_target_https_proxy#url_map ComputeRegionTargetHttpsProxy#url_map}
    */
    readonly urlMap: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_target_https_proxy#timeouts ComputeRegionTargetHttpsProxy#timeouts}
    */
    readonly timeouts?: ComputeRegionTargetHttpsProxyTimeouts;
}
export interface ComputeRegionTargetHttpsProxyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_target_https_proxy#create ComputeRegionTargetHttpsProxy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_target_https_proxy#delete ComputeRegionTargetHttpsProxy#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_target_https_proxy#update ComputeRegionTargetHttpsProxy#update}
    */
    readonly update?: string;
}
export declare function computeRegionTargetHttpsProxyTimeoutsToTerraform(struct?: ComputeRegionTargetHttpsProxyTimeouts | cdktn.IResolvable): any;
export declare function computeRegionTargetHttpsProxyTimeoutsToHclTerraform(struct?: ComputeRegionTargetHttpsProxyTimeouts | cdktn.IResolvable): any;
export declare class ComputeRegionTargetHttpsProxyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionTargetHttpsProxyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionTargetHttpsProxyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_target_https_proxy google_compute_region_target_https_proxy}
*/
export declare class ComputeRegionTargetHttpsProxy extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_region_target_https_proxy";
    /**
    * Generates CDKTN code for importing a ComputeRegionTargetHttpsProxy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeRegionTargetHttpsProxy to import
    * @param importFromId The id of the existing ComputeRegionTargetHttpsProxy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_target_https_proxy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeRegionTargetHttpsProxy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_target_https_proxy google_compute_region_target_https_proxy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeRegionTargetHttpsProxyConfig
    */
    constructor(scope: Construct, id: string, config: ComputeRegionTargetHttpsProxyConfig);
    private _certificateManagerCertificates?;
    get certificateManagerCertificates(): string[];
    set certificateManagerCertificates(value: string[]);
    resetCertificateManagerCertificates(): void;
    get certificateManagerCertificatesInput(): string[] | undefined;
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _httpKeepAliveTimeoutSec?;
    get httpKeepAliveTimeoutSec(): number;
    set httpKeepAliveTimeoutSec(value: number);
    resetHttpKeepAliveTimeoutSec(): void;
    get httpKeepAliveTimeoutSecInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get proxyId(): number;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get selfLink(): string;
    private _serverTlsPolicy?;
    get serverTlsPolicy(): string;
    set serverTlsPolicy(value: string);
    resetServerTlsPolicy(): void;
    get serverTlsPolicyInput(): string | undefined;
    private _sslCertificates?;
    get sslCertificates(): string[];
    set sslCertificates(value: string[]);
    resetSslCertificates(): void;
    get sslCertificatesInput(): string[] | undefined;
    private _sslPolicy?;
    get sslPolicy(): string;
    set sslPolicy(value: string);
    resetSslPolicy(): void;
    get sslPolicyInput(): string | undefined;
    private _urlMap?;
    get urlMap(): string;
    set urlMap(value: string);
    get urlMapInput(): string | undefined;
    private _timeouts;
    get timeouts(): ComputeRegionTargetHttpsProxyTimeoutsOutputReference;
    putTimeouts(value: ComputeRegionTargetHttpsProxyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeRegionTargetHttpsProxyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
