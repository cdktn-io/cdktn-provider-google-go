/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AgentRegistryBindingConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the Binding.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_binding#binding_id AgentRegistryBinding#binding_id}
    */
    readonly bindingId: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_binding#deletion_policy AgentRegistryBinding#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The description of the Binding.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_binding#description AgentRegistryBinding#description}
    */
    readonly description?: string;
    /**
    * User-defined display name for the Binding.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_binding#display_name AgentRegistryBinding#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_binding#id AgentRegistryBinding#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_binding#location AgentRegistryBinding#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_binding#project AgentRegistryBinding#project}
    */
    readonly project?: string;
    /**
    * auth_provider_binding block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_binding#auth_provider_binding AgentRegistryBinding#auth_provider_binding}
    */
    readonly authProviderBinding: AgentRegistryBindingAuthProviderBinding;
    /**
    * source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_binding#source AgentRegistryBinding#source}
    */
    readonly source?: AgentRegistryBindingSource;
    /**
    * target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_binding#target AgentRegistryBinding#target}
    */
    readonly target: AgentRegistryBindingTarget;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_binding#timeouts AgentRegistryBinding#timeouts}
    */
    readonly timeouts?: AgentRegistryBindingTimeouts;
}
export interface AgentRegistryBindingAuthProviderBinding {
    /**
    * The resource name of the target auth provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_binding#auth_provider AgentRegistryBinding#auth_provider}
    */
    readonly authProvider: string;
    /**
    * The continue URI of the auth provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_binding#continue_uri AgentRegistryBinding#continue_uri}
    */
    readonly continueUri?: string;
    /**
    * The list of OAuth2 scopes of the auth provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_binding#scopes AgentRegistryBinding#scopes}
    */
    readonly scopes?: string[];
}
export declare function agentRegistryBindingAuthProviderBindingToTerraform(struct?: AgentRegistryBindingAuthProviderBindingOutputReference | AgentRegistryBindingAuthProviderBinding): any;
export declare function agentRegistryBindingAuthProviderBindingToHclTerraform(struct?: AgentRegistryBindingAuthProviderBindingOutputReference | AgentRegistryBindingAuthProviderBinding): any;
export declare class AgentRegistryBindingAuthProviderBindingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentRegistryBindingAuthProviderBinding | undefined;
    set internalValue(value: AgentRegistryBindingAuthProviderBinding | undefined);
    private _authProvider?;
    get authProvider(): string;
    set authProvider(value: string);
    get authProviderInput(): string | undefined;
    private _continueUri?;
    get continueUri(): string;
    set continueUri(value: string);
    resetContinueUri(): void;
    get continueUriInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AgentRegistryBindingSource {
    /**
    * The identifier of the source Agent. Format: 'urn:agent:{publisher}:{namespace}:{name}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_binding#identifier AgentRegistryBinding#identifier}
    */
    readonly identifier: string;
}
export declare function agentRegistryBindingSourceToTerraform(struct?: AgentRegistryBindingSourceOutputReference | AgentRegistryBindingSource): any;
export declare function agentRegistryBindingSourceToHclTerraform(struct?: AgentRegistryBindingSourceOutputReference | AgentRegistryBindingSource): any;
export declare class AgentRegistryBindingSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentRegistryBindingSource | undefined;
    set internalValue(value: AgentRegistryBindingSource | undefined);
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
}
export interface AgentRegistryBindingTarget {
    /**
    * The identifier of the target Agent, MCP Server, or Endpoint. Format:
    * * 'urn:agent:{publisher}:{namespace}:{name}'
    * * 'urn:mcp:{publisher}:{namespace}:{name}'
    * * 'urn:endpoint:{publisher}:{namespace}:{name}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_binding#identifier AgentRegistryBinding#identifier}
    */
    readonly identifier: string;
}
export declare function agentRegistryBindingTargetToTerraform(struct?: AgentRegistryBindingTargetOutputReference | AgentRegistryBindingTarget): any;
export declare function agentRegistryBindingTargetToHclTerraform(struct?: AgentRegistryBindingTargetOutputReference | AgentRegistryBindingTarget): any;
export declare class AgentRegistryBindingTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentRegistryBindingTarget | undefined;
    set internalValue(value: AgentRegistryBindingTarget | undefined);
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
}
export interface AgentRegistryBindingTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_binding#create AgentRegistryBinding#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_binding#delete AgentRegistryBinding#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_binding#update AgentRegistryBinding#update}
    */
    readonly update?: string;
}
export declare function agentRegistryBindingTimeoutsToTerraform(struct?: AgentRegistryBindingTimeouts | cdktn.IResolvable): any;
export declare function agentRegistryBindingTimeoutsToHclTerraform(struct?: AgentRegistryBindingTimeouts | cdktn.IResolvable): any;
export declare class AgentRegistryBindingTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentRegistryBindingTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AgentRegistryBindingTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_binding google_agent_registry_binding}
*/
export declare class AgentRegistryBinding extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_agent_registry_binding";
    /**
    * Generates CDKTN code for importing a AgentRegistryBinding resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AgentRegistryBinding to import
    * @param importFromId The id of the existing AgentRegistryBinding that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_binding#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AgentRegistryBinding to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_binding google_agent_registry_binding} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AgentRegistryBindingConfig
    */
    constructor(scope: Construct, id: string, config: AgentRegistryBindingConfig);
    private _bindingId?;
    get bindingId(): string;
    set bindingId(value: string);
    get bindingIdInput(): string | undefined;
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get updateTime(): string;
    private _authProviderBinding;
    get authProviderBinding(): AgentRegistryBindingAuthProviderBindingOutputReference;
    putAuthProviderBinding(value: AgentRegistryBindingAuthProviderBinding): void;
    get authProviderBindingInput(): AgentRegistryBindingAuthProviderBinding | undefined;
    private _source;
    get source(): AgentRegistryBindingSourceOutputReference;
    putSource(value: AgentRegistryBindingSource): void;
    resetSource(): void;
    get sourceInput(): AgentRegistryBindingSource | undefined;
    private _target;
    get target(): AgentRegistryBindingTargetOutputReference;
    putTarget(value: AgentRegistryBindingTarget): void;
    get targetInput(): AgentRegistryBindingTarget | undefined;
    private _timeouts;
    get timeouts(): AgentRegistryBindingTimeoutsOutputReference;
    putTimeouts(value: AgentRegistryBindingTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AgentRegistryBindingTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
