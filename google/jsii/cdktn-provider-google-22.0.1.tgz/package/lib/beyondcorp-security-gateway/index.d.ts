/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BeyondcorpSecurityGatewayConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#deletion_policy BeyondcorpSecurityGateway#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Optional. An arbitrary user-provided name for the SecurityGateway.
    * Cannot exceed 64 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#display_name BeyondcorpSecurityGateway#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#id BeyondcorpSecurityGateway#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122. Must be omitted or set to 'global'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#location BeyondcorpSecurityGateway#location}
    */
    readonly location?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#project BeyondcorpSecurityGateway#project}
    */
    readonly project?: string;
    /**
    * Optional. User-settable SecurityGateway resource ID.
    * * Must start with a letter.
    * * Must contain between 4-63 characters from '/a-z-/'.
    * * Must end with a number or letter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#security_gateway_id BeyondcorpSecurityGateway#security_gateway_id}
    */
    readonly securityGatewayId: string;
    /**
    * hubs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#hubs BeyondcorpSecurityGateway#hubs}
    */
    readonly hubs?: BeyondcorpSecurityGatewayHubs[] | cdktn.IResolvable;
    /**
    * logging block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#logging BeyondcorpSecurityGateway#logging}
    */
    readonly logging?: BeyondcorpSecurityGatewayLogging;
    /**
    * proxy_protocol_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#proxy_protocol_config BeyondcorpSecurityGateway#proxy_protocol_config}
    */
    readonly proxyProtocolConfig?: BeyondcorpSecurityGatewayProxyProtocolConfig;
    /**
    * service_discovery block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#service_discovery BeyondcorpSecurityGateway#service_discovery}
    */
    readonly serviceDiscovery?: BeyondcorpSecurityGatewayServiceDiscovery;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#timeouts BeyondcorpSecurityGateway#timeouts}
    */
    readonly timeouts?: BeyondcorpSecurityGatewayTimeouts;
}
export interface BeyondcorpSecurityGatewayHubsInternetGateway {
}
export declare function beyondcorpSecurityGatewayHubsInternetGatewayToTerraform(struct?: BeyondcorpSecurityGatewayHubsInternetGatewayOutputReference | BeyondcorpSecurityGatewayHubsInternetGateway): any;
export declare function beyondcorpSecurityGatewayHubsInternetGatewayToHclTerraform(struct?: BeyondcorpSecurityGatewayHubsInternetGatewayOutputReference | BeyondcorpSecurityGatewayHubsInternetGateway): any;
export declare class BeyondcorpSecurityGatewayHubsInternetGatewayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BeyondcorpSecurityGatewayHubsInternetGateway | undefined;
    set internalValue(value: BeyondcorpSecurityGatewayHubsInternetGateway | undefined);
    get assignedIps(): string[];
}
export interface BeyondcorpSecurityGatewayHubs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#region BeyondcorpSecurityGateway#region}
    */
    readonly region: string;
    /**
    * internet_gateway block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#internet_gateway BeyondcorpSecurityGateway#internet_gateway}
    */
    readonly internetGateway?: BeyondcorpSecurityGatewayHubsInternetGateway;
}
export declare function beyondcorpSecurityGatewayHubsToTerraform(struct?: BeyondcorpSecurityGatewayHubs | cdktn.IResolvable): any;
export declare function beyondcorpSecurityGatewayHubsToHclTerraform(struct?: BeyondcorpSecurityGatewayHubs | cdktn.IResolvable): any;
export declare class BeyondcorpSecurityGatewayHubsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BeyondcorpSecurityGatewayHubs | cdktn.IResolvable | undefined;
    set internalValue(value: BeyondcorpSecurityGatewayHubs | cdktn.IResolvable | undefined);
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _internetGateway;
    get internetGateway(): BeyondcorpSecurityGatewayHubsInternetGatewayOutputReference;
    putInternetGateway(value: BeyondcorpSecurityGatewayHubsInternetGateway): void;
    resetInternetGateway(): void;
    get internetGatewayInput(): BeyondcorpSecurityGatewayHubsInternetGateway | undefined;
}
export declare class BeyondcorpSecurityGatewayHubsList extends cdktn.ComplexList {
    internalValue?: BeyondcorpSecurityGatewayHubs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BeyondcorpSecurityGatewayHubsOutputReference;
}
export interface BeyondcorpSecurityGatewayLogging {
}
export declare function beyondcorpSecurityGatewayLoggingToTerraform(struct?: BeyondcorpSecurityGatewayLoggingOutputReference | BeyondcorpSecurityGatewayLogging): any;
export declare function beyondcorpSecurityGatewayLoggingToHclTerraform(struct?: BeyondcorpSecurityGatewayLoggingOutputReference | BeyondcorpSecurityGatewayLogging): any;
export declare class BeyondcorpSecurityGatewayLoggingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BeyondcorpSecurityGatewayLogging | undefined;
    set internalValue(value: BeyondcorpSecurityGatewayLogging | undefined);
}
export interface BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersDeviceInfo {
    /**
    * The output type of the delegated device info. Possible values: ["PROTOBUF", "JSON", "NONE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#output_type BeyondcorpSecurityGateway#output_type}
    */
    readonly outputType?: string;
}
export declare function beyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersDeviceInfoToTerraform(struct?: BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersDeviceInfoOutputReference | BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersDeviceInfo): any;
export declare function beyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersDeviceInfoToHclTerraform(struct?: BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersDeviceInfoOutputReference | BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersDeviceInfo): any;
export declare class BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersDeviceInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersDeviceInfo | undefined;
    set internalValue(value: BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersDeviceInfo | undefined);
    private _outputType?;
    get outputType(): string;
    set outputType(value: string);
    resetOutputType(): void;
    get outputTypeInput(): string | undefined;
}
export interface BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersGroupInfo {
    /**
    * The output type of the delegated group info. Possible values: ["PROTOBUF", "JSON", "NONE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#output_type BeyondcorpSecurityGateway#output_type}
    */
    readonly outputType?: string;
}
export declare function beyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersGroupInfoToTerraform(struct?: BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersGroupInfoOutputReference | BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersGroupInfo): any;
export declare function beyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersGroupInfoToHclTerraform(struct?: BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersGroupInfoOutputReference | BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersGroupInfo): any;
export declare class BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersGroupInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersGroupInfo | undefined;
    set internalValue(value: BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersGroupInfo | undefined);
    private _outputType?;
    get outputType(): string;
    set outputType(value: string);
    resetOutputType(): void;
    get outputTypeInput(): string | undefined;
}
export interface BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersUserInfo {
    /**
    * The output type of the delegated user info. Possible values: ["PROTOBUF", "JSON", "NONE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#output_type BeyondcorpSecurityGateway#output_type}
    */
    readonly outputType?: string;
}
export declare function beyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersUserInfoToTerraform(struct?: BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersUserInfoOutputReference | BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersUserInfo): any;
export declare function beyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersUserInfoToHclTerraform(struct?: BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersUserInfoOutputReference | BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersUserInfo): any;
export declare class BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersUserInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersUserInfo | undefined;
    set internalValue(value: BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersUserInfo | undefined);
    private _outputType?;
    get outputType(): string;
    set outputType(value: string);
    resetOutputType(): void;
    get outputTypeInput(): string | undefined;
}
export interface BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeaders {
    /**
    * Default output type for all enabled headers. Possible values: ["PROTOBUF", "JSON", "NONE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#output_type BeyondcorpSecurityGateway#output_type}
    */
    readonly outputType?: string;
    /**
    * device_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#device_info BeyondcorpSecurityGateway#device_info}
    */
    readonly deviceInfo?: BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersDeviceInfo;
    /**
    * group_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#group_info BeyondcorpSecurityGateway#group_info}
    */
    readonly groupInfo?: BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersGroupInfo;
    /**
    * user_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#user_info BeyondcorpSecurityGateway#user_info}
    */
    readonly userInfo?: BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersUserInfo;
}
export declare function beyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersToTerraform(struct?: BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersOutputReference | BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeaders): any;
export declare function beyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersToHclTerraform(struct?: BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersOutputReference | BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeaders): any;
export declare class BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeaders | undefined;
    set internalValue(value: BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeaders | undefined);
    private _outputType?;
    get outputType(): string;
    set outputType(value: string);
    resetOutputType(): void;
    get outputTypeInput(): string | undefined;
    private _deviceInfo;
    get deviceInfo(): BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersDeviceInfoOutputReference;
    putDeviceInfo(value: BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersDeviceInfo): void;
    resetDeviceInfo(): void;
    get deviceInfoInput(): BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersDeviceInfo | undefined;
    private _groupInfo;
    get groupInfo(): BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersGroupInfoOutputReference;
    putGroupInfo(value: BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersGroupInfo): void;
    resetGroupInfo(): void;
    get groupInfoInput(): BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersGroupInfo | undefined;
    private _userInfo;
    get userInfo(): BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersUserInfoOutputReference;
    putUserInfo(value: BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersUserInfo): void;
    resetUserInfo(): void;
    get userInfoInput(): BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersUserInfo | undefined;
}
export interface BeyondcorpSecurityGatewayProxyProtocolConfig {
    /**
    * The configuration for the proxy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#allowed_client_headers BeyondcorpSecurityGateway#allowed_client_headers}
    */
    readonly allowedClientHeaders?: string[];
    /**
    * Client IP configuration. The client IP address is included if true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#client_ip BeyondcorpSecurityGateway#client_ip}
    */
    readonly clientIp?: boolean | cdktn.IResolvable;
    /**
    * Gateway identity configuration. Possible values: ["RESOURCE_NAME"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#gateway_identity BeyondcorpSecurityGateway#gateway_identity}
    */
    readonly gatewayIdentity?: string;
    /**
    * Custom resource specific headers along with the values.
    * The names should conform to RFC 9110:
    * > Field names SHOULD constrain themselves to alphanumeric characters, "-",
    *   and ".", and SHOULD begin with a letter.
    * > Field values SHOULD contain only ASCII printable characters and tab.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#metadata_headers BeyondcorpSecurityGateway#metadata_headers}
    */
    readonly metadataHeaders?: {
        [key: string]: string;
    };
    /**
    * contextual_headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#contextual_headers BeyondcorpSecurityGateway#contextual_headers}
    */
    readonly contextualHeaders?: BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeaders;
}
export declare function beyondcorpSecurityGatewayProxyProtocolConfigToTerraform(struct?: BeyondcorpSecurityGatewayProxyProtocolConfigOutputReference | BeyondcorpSecurityGatewayProxyProtocolConfig): any;
export declare function beyondcorpSecurityGatewayProxyProtocolConfigToHclTerraform(struct?: BeyondcorpSecurityGatewayProxyProtocolConfigOutputReference | BeyondcorpSecurityGatewayProxyProtocolConfig): any;
export declare class BeyondcorpSecurityGatewayProxyProtocolConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BeyondcorpSecurityGatewayProxyProtocolConfig | undefined;
    set internalValue(value: BeyondcorpSecurityGatewayProxyProtocolConfig | undefined);
    private _allowedClientHeaders?;
    get allowedClientHeaders(): string[];
    set allowedClientHeaders(value: string[]);
    resetAllowedClientHeaders(): void;
    get allowedClientHeadersInput(): string[] | undefined;
    private _clientIp?;
    get clientIp(): boolean | cdktn.IResolvable;
    set clientIp(value: boolean | cdktn.IResolvable);
    resetClientIp(): void;
    get clientIpInput(): boolean | cdktn.IResolvable | undefined;
    private _gatewayIdentity?;
    get gatewayIdentity(): string;
    set gatewayIdentity(value: string);
    resetGatewayIdentity(): void;
    get gatewayIdentityInput(): string | undefined;
    private _metadataHeaders?;
    get metadataHeaders(): {
        [key: string]: string;
    };
    set metadataHeaders(value: {
        [key: string]: string;
    });
    resetMetadataHeaders(): void;
    get metadataHeadersInput(): {
        [key: string]: string;
    } | undefined;
    private _contextualHeaders;
    get contextualHeaders(): BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersOutputReference;
    putContextualHeaders(value: BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeaders): void;
    resetContextualHeaders(): void;
    get contextualHeadersInput(): BeyondcorpSecurityGatewayProxyProtocolConfigContextualHeaders | undefined;
}
export interface BeyondcorpSecurityGatewayServiceDiscoveryApiGatewayResourceOverride {
    /**
    * Contains uri path fragment where HTTP request is sent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#path BeyondcorpSecurityGateway#path}
    */
    readonly path?: string;
}
export declare function beyondcorpSecurityGatewayServiceDiscoveryApiGatewayResourceOverrideToTerraform(struct?: BeyondcorpSecurityGatewayServiceDiscoveryApiGatewayResourceOverrideOutputReference | BeyondcorpSecurityGatewayServiceDiscoveryApiGatewayResourceOverride): any;
export declare function beyondcorpSecurityGatewayServiceDiscoveryApiGatewayResourceOverrideToHclTerraform(struct?: BeyondcorpSecurityGatewayServiceDiscoveryApiGatewayResourceOverrideOutputReference | BeyondcorpSecurityGatewayServiceDiscoveryApiGatewayResourceOverride): any;
export declare class BeyondcorpSecurityGatewayServiceDiscoveryApiGatewayResourceOverrideOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BeyondcorpSecurityGatewayServiceDiscoveryApiGatewayResourceOverride | undefined;
    set internalValue(value: BeyondcorpSecurityGatewayServiceDiscoveryApiGatewayResourceOverride | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export interface BeyondcorpSecurityGatewayServiceDiscoveryApiGateway {
    /**
    * resource_override block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#resource_override BeyondcorpSecurityGateway#resource_override}
    */
    readonly resourceOverride?: BeyondcorpSecurityGatewayServiceDiscoveryApiGatewayResourceOverride;
}
export declare function beyondcorpSecurityGatewayServiceDiscoveryApiGatewayToTerraform(struct?: BeyondcorpSecurityGatewayServiceDiscoveryApiGatewayOutputReference | BeyondcorpSecurityGatewayServiceDiscoveryApiGateway): any;
export declare function beyondcorpSecurityGatewayServiceDiscoveryApiGatewayToHclTerraform(struct?: BeyondcorpSecurityGatewayServiceDiscoveryApiGatewayOutputReference | BeyondcorpSecurityGatewayServiceDiscoveryApiGateway): any;
export declare class BeyondcorpSecurityGatewayServiceDiscoveryApiGatewayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BeyondcorpSecurityGatewayServiceDiscoveryApiGateway | undefined;
    set internalValue(value: BeyondcorpSecurityGatewayServiceDiscoveryApiGateway | undefined);
    private _resourceOverride;
    get resourceOverride(): BeyondcorpSecurityGatewayServiceDiscoveryApiGatewayResourceOverrideOutputReference;
    putResourceOverride(value: BeyondcorpSecurityGatewayServiceDiscoveryApiGatewayResourceOverride): void;
    resetResourceOverride(): void;
    get resourceOverrideInput(): BeyondcorpSecurityGatewayServiceDiscoveryApiGatewayResourceOverride | undefined;
}
export interface BeyondcorpSecurityGatewayServiceDiscovery {
    /**
    * api_gateway block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#api_gateway BeyondcorpSecurityGateway#api_gateway}
    */
    readonly apiGateway?: BeyondcorpSecurityGatewayServiceDiscoveryApiGateway;
}
export declare function beyondcorpSecurityGatewayServiceDiscoveryToTerraform(struct?: BeyondcorpSecurityGatewayServiceDiscoveryOutputReference | BeyondcorpSecurityGatewayServiceDiscovery): any;
export declare function beyondcorpSecurityGatewayServiceDiscoveryToHclTerraform(struct?: BeyondcorpSecurityGatewayServiceDiscoveryOutputReference | BeyondcorpSecurityGatewayServiceDiscovery): any;
export declare class BeyondcorpSecurityGatewayServiceDiscoveryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BeyondcorpSecurityGatewayServiceDiscovery | undefined;
    set internalValue(value: BeyondcorpSecurityGatewayServiceDiscovery | undefined);
    private _apiGateway;
    get apiGateway(): BeyondcorpSecurityGatewayServiceDiscoveryApiGatewayOutputReference;
    putApiGateway(value: BeyondcorpSecurityGatewayServiceDiscoveryApiGateway): void;
    resetApiGateway(): void;
    get apiGatewayInput(): BeyondcorpSecurityGatewayServiceDiscoveryApiGateway | undefined;
}
export interface BeyondcorpSecurityGatewayTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#create BeyondcorpSecurityGateway#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#delete BeyondcorpSecurityGateway#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#update BeyondcorpSecurityGateway#update}
    */
    readonly update?: string;
}
export declare function beyondcorpSecurityGatewayTimeoutsToTerraform(struct?: BeyondcorpSecurityGatewayTimeouts | cdktn.IResolvable): any;
export declare function beyondcorpSecurityGatewayTimeoutsToHclTerraform(struct?: BeyondcorpSecurityGatewayTimeouts | cdktn.IResolvable): any;
export declare class BeyondcorpSecurityGatewayTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BeyondcorpSecurityGatewayTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BeyondcorpSecurityGatewayTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway google_beyondcorp_security_gateway}
*/
export declare class BeyondcorpSecurityGateway extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_beyondcorp_security_gateway";
    /**
    * Generates CDKTN code for importing a BeyondcorpSecurityGateway resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BeyondcorpSecurityGateway to import
    * @param importFromId The id of the existing BeyondcorpSecurityGateway that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BeyondcorpSecurityGateway to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway google_beyondcorp_security_gateway} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BeyondcorpSecurityGatewayConfig
    */
    constructor(scope: Construct, id: string, config: BeyondcorpSecurityGatewayConfig);
    get createTime(): string;
    get delegatingServiceAccount(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    get externalIps(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _securityGatewayId?;
    get securityGatewayId(): string;
    set securityGatewayId(value: string);
    get securityGatewayIdInput(): string | undefined;
    get state(): string;
    get updateTime(): string;
    private _hubs;
    get hubs(): BeyondcorpSecurityGatewayHubsList;
    putHubs(value: BeyondcorpSecurityGatewayHubs[] | cdktn.IResolvable): void;
    resetHubs(): void;
    get hubsInput(): cdktn.IResolvable | BeyondcorpSecurityGatewayHubs[] | undefined;
    private _logging;
    get logging(): BeyondcorpSecurityGatewayLoggingOutputReference;
    putLogging(value: BeyondcorpSecurityGatewayLogging): void;
    resetLogging(): void;
    get loggingInput(): BeyondcorpSecurityGatewayLogging | undefined;
    private _proxyProtocolConfig;
    get proxyProtocolConfig(): BeyondcorpSecurityGatewayProxyProtocolConfigOutputReference;
    putProxyProtocolConfig(value: BeyondcorpSecurityGatewayProxyProtocolConfig): void;
    resetProxyProtocolConfig(): void;
    get proxyProtocolConfigInput(): BeyondcorpSecurityGatewayProxyProtocolConfig | undefined;
    private _serviceDiscovery;
    get serviceDiscovery(): BeyondcorpSecurityGatewayServiceDiscoveryOutputReference;
    putServiceDiscovery(value: BeyondcorpSecurityGatewayServiceDiscovery): void;
    resetServiceDiscovery(): void;
    get serviceDiscoveryInput(): BeyondcorpSecurityGatewayServiceDiscovery | undefined;
    private _timeouts;
    get timeouts(): BeyondcorpSecurityGatewayTimeoutsOutputReference;
    putTimeouts(value: BeyondcorpSecurityGatewayTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BeyondcorpSecurityGatewayTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
