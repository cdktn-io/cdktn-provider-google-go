/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChronicleDataTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID to use for the data table. This is also the display name for
    * the data table. It must satisfy the following requirements:
    * - Starts with letter.
    * - Contains only letters, numbers and underscore.
    * - Must be unique and has length < 256.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_table#data_table_id ChronicleDataTable#data_table_id}
    */
    readonly dataTableId: string;
    /**
    * This field uses a custom implementation please refer to documentation under /hashicorp/terraform-provider-google-beta/website/docs/r/chronicle_data_table.html.markdown for specifics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_table#deletion_policy ChronicleDataTable#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * A user-provided description of the data table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_table#description ChronicleDataTable#description}
    */
    readonly description: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_table#id ChronicleDataTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_table#instance ChronicleDataTable#instance}
    */
    readonly instance: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_table#location ChronicleDataTable#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_table#project ChronicleDataTable#project}
    */
    readonly project?: string;
    /**
    * User-provided TTL of the data table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_table#row_time_to_live ChronicleDataTable#row_time_to_live}
    */
    readonly rowTimeToLive?: string;
    /**
    * column_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_table#column_info ChronicleDataTable#column_info}
    */
    readonly columnInfo?: ChronicleDataTableColumnInfo[] | cdktn.IResolvable;
    /**
    * scope_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_table#scope_info ChronicleDataTable#scope_info}
    */
    readonly scopeInfo?: ChronicleDataTableScopeInfo;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_table#timeouts ChronicleDataTable#timeouts}
    */
    readonly timeouts?: ChronicleDataTableTimeouts;
}
export interface ChronicleDataTableColumnInfo {
    /**
    * Column Index. 0,1,2...
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_table#column_index ChronicleDataTable#column_index}
    */
    readonly columnIndex: number;
    /**
    * Column type can be STRING, CIDR (Ex- 10.1.1.0/24), REGEX
    * Possible values:
    * STRING
    * REGEX
    * CIDR
    * NUMBER Possible values: ["STRING", "REGEX", "CIDR", "NUMBER"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_table#column_type ChronicleDataTable#column_type}
    */
    readonly columnType?: string;
    /**
    * Whether to include this column in the calculation of the row ID.
    * If no columns have key_column = true, all columns will be included in the
    * calculation of the row ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_table#key_column ChronicleDataTable#key_column}
    */
    readonly keyColumn?: boolean | cdktn.IResolvable;
    /**
    * Entity proto field path that the column is mapped to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_table#mapped_column_path ChronicleDataTable#mapped_column_path}
    */
    readonly mappedColumnPath?: string;
    /**
    * Original column name of the Data Table (present in the CSV header in case
    * of creation of data tables using file uploads). It must satisfy the
    * following requirements:
    * - Starts with letter.
    * - Contains only letters, numbers and underscore.
    * - Must be unique and has length < 256
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_table#original_column ChronicleDataTable#original_column}
    */
    readonly originalColumn: string;
    /**
    * Whether the column is a repeated values column.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_table#repeated_values ChronicleDataTable#repeated_values}
    */
    readonly repeatedValues?: boolean | cdktn.IResolvable;
}
export declare function chronicleDataTableColumnInfoToTerraform(struct?: ChronicleDataTableColumnInfo | cdktn.IResolvable): any;
export declare function chronicleDataTableColumnInfoToHclTerraform(struct?: ChronicleDataTableColumnInfo | cdktn.IResolvable): any;
export declare class ChronicleDataTableColumnInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleDataTableColumnInfo | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleDataTableColumnInfo | cdktn.IResolvable | undefined);
    private _columnIndex?;
    get columnIndex(): number;
    set columnIndex(value: number);
    get columnIndexInput(): number | undefined;
    private _columnType?;
    get columnType(): string;
    set columnType(value: string);
    resetColumnType(): void;
    get columnTypeInput(): string | undefined;
    private _keyColumn?;
    get keyColumn(): boolean | cdktn.IResolvable;
    set keyColumn(value: boolean | cdktn.IResolvable);
    resetKeyColumn(): void;
    get keyColumnInput(): boolean | cdktn.IResolvable | undefined;
    private _mappedColumnPath?;
    get mappedColumnPath(): string;
    set mappedColumnPath(value: string);
    resetMappedColumnPath(): void;
    get mappedColumnPathInput(): string | undefined;
    private _originalColumn?;
    get originalColumn(): string;
    set originalColumn(value: string);
    get originalColumnInput(): string | undefined;
    private _repeatedValues?;
    get repeatedValues(): boolean | cdktn.IResolvable;
    set repeatedValues(value: boolean | cdktn.IResolvable);
    resetRepeatedValues(): void;
    get repeatedValuesInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class ChronicleDataTableColumnInfoList extends cdktn.ComplexList {
    internalValue?: ChronicleDataTableColumnInfo[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleDataTableColumnInfoOutputReference;
}
export interface ChronicleDataTableScopeInfo {
    /**
    * Contains the list of scope names of the data table. If the list is empty,
    * the data table is treated as unscoped. The scope names should be
    * full resource names and should be of the format:
    * "projects/{project}/locations/{location}/instances/{instance}/dataAccessScopes/{scope_name}"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_table#data_access_scopes ChronicleDataTable#data_access_scopes}
    */
    readonly dataAccessScopes: string[];
}
export declare function chronicleDataTableScopeInfoToTerraform(struct?: ChronicleDataTableScopeInfoOutputReference | ChronicleDataTableScopeInfo): any;
export declare function chronicleDataTableScopeInfoToHclTerraform(struct?: ChronicleDataTableScopeInfoOutputReference | ChronicleDataTableScopeInfo): any;
export declare class ChronicleDataTableScopeInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDataTableScopeInfo | undefined;
    set internalValue(value: ChronicleDataTableScopeInfo | undefined);
    private _dataAccessScopes?;
    get dataAccessScopes(): string[];
    set dataAccessScopes(value: string[]);
    get dataAccessScopesInput(): string[] | undefined;
}
export interface ChronicleDataTableTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_table#create ChronicleDataTable#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_table#delete ChronicleDataTable#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_table#update ChronicleDataTable#update}
    */
    readonly update?: string;
}
export declare function chronicleDataTableTimeoutsToTerraform(struct?: ChronicleDataTableTimeouts | cdktn.IResolvable): any;
export declare function chronicleDataTableTimeoutsToHclTerraform(struct?: ChronicleDataTableTimeouts | cdktn.IResolvable): any;
export declare class ChronicleDataTableTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDataTableTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleDataTableTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_table google_chronicle_data_table}
*/
export declare class ChronicleDataTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_chronicle_data_table";
    /**
    * Generates CDKTN code for importing a ChronicleDataTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChronicleDataTable to import
    * @param importFromId The id of the existing ChronicleDataTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChronicleDataTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_table google_chronicle_data_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChronicleDataTableConfig
    */
    constructor(scope: Construct, id: string, config: ChronicleDataTableConfig);
    get approximateRowCount(): number;
    get createTime(): string;
    private _dataTableId?;
    get dataTableId(): string;
    set dataTableId(value: string);
    get dataTableIdInput(): string | undefined;
    get dataTableUuid(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    get displayName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instance?;
    get instance(): string;
    set instance(value: string);
    get instanceInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _rowTimeToLive?;
    get rowTimeToLive(): string;
    set rowTimeToLive(value: string);
    resetRowTimeToLive(): void;
    get rowTimeToLiveInput(): string | undefined;
    get rowTimeToLiveUpdateTime(): string;
    get ruleAssociationsCount(): number;
    get rules(): string[];
    get updateSource(): string;
    get updateTime(): string;
    private _columnInfo;
    get columnInfo(): ChronicleDataTableColumnInfoList;
    putColumnInfo(value: ChronicleDataTableColumnInfo[] | cdktn.IResolvable): void;
    resetColumnInfo(): void;
    get columnInfoInput(): cdktn.IResolvable | ChronicleDataTableColumnInfo[] | undefined;
    private _scopeInfo;
    get scopeInfo(): ChronicleDataTableScopeInfoOutputReference;
    putScopeInfo(value: ChronicleDataTableScopeInfo): void;
    resetScopeInfo(): void;
    get scopeInfoInput(): ChronicleDataTableScopeInfo | undefined;
    private _timeouts;
    get timeouts(): ChronicleDataTableTimeoutsOutputReference;
    putTimeouts(value: ChronicleDataTableTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ChronicleDataTableTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
