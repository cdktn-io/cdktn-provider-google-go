/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AgentIdentityAuthProviderConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of scopes that are allowed to be requested for this auth_provider.
    * If this list is non-empty, only scopes within this list may be requested.
    * If this list is empty, all scopes may be requested.
    * Scopes appearing in 'blocked_scopes' are disallowed even if they appear in
    * 'allowed_scopes'.
    * The number of allowed scopes is limited to 200.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#allowed_scopes AgentIdentityAuthProvider#allowed_scopes}
    */
    readonly allowedScopes?: string[];
    /**
    * The ID to use for the AuthProvider, which will become the final segment
    * of the AuthProvider's resource name.
    * This value should be 1-63 characters, and valid characters
    * are /a-z-/. The first character must be a lowercase letter, and the
    * last character must be a lowercase letter or a number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#auth_provider_id AgentIdentityAuthProvider#auth_provider_id}
    */
    readonly authProviderId: string;
    /**
    * List of scopes that are blocked from being requested for this
    * auth_provider. If a scope appears in this list, it will not be requested,
    * even if it also appears in 'allowed_scopes'. 'blocked_scopes' takes
    * precedence over 'allowed_scopes'. The number of blocked scopes is limited
    * to 200.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#blocked_scopes AgentIdentityAuthProvider#blocked_scopes}
    */
    readonly blockedScopes?: string[];
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#deletion_policy AgentIdentityAuthProvider#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Description of the resource.
    * Must be less than 256 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#description AgentIdentityAuthProvider#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#id AgentIdentityAuthProvider#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Labels as key value pairs
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#labels AgentIdentityAuthProvider#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#location AgentIdentityAuthProvider#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#project AgentIdentityAuthProvider#project}
    */
    readonly project?: string;
    /**
    * Input only. Represents the workload identity in IAM 'principal://' format of the
    * agent(s) that will use this AuthProvider. Example:
    * 'principal://agents.global.org-${ORG_ID}.system.id.goog/resources/aiplatform/projects/{PROJECT_ID}/locations/{LOCATIONS}/reasoningEngines/{ID}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#workload_ids AgentIdentityAuthProvider#workload_ids}
    */
    readonly workloadIds?: string[];
    /**
    * auth_provider_type_params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#auth_provider_type_params AgentIdentityAuthProvider#auth_provider_type_params}
    */
    readonly authProviderTypeParams: AgentIdentityAuthProviderAuthProviderTypeParams;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#timeouts AgentIdentityAuthProvider#timeouts}
    */
    readonly timeouts?: AgentIdentityAuthProviderTimeouts;
}
export interface AgentIdentityAuthProviderAuthProviderTypeParamsGeAuthProvider {
}
export declare function agentIdentityAuthProviderAuthProviderTypeParamsGeAuthProviderToTerraform(struct?: AgentIdentityAuthProviderAuthProviderTypeParamsGeAuthProvider): any;
export declare function agentIdentityAuthProviderAuthProviderTypeParamsGeAuthProviderToHclTerraform(struct?: AgentIdentityAuthProviderAuthProviderTypeParamsGeAuthProvider): any;
export declare class AgentIdentityAuthProviderAuthProviderTypeParamsGeAuthProviderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AgentIdentityAuthProviderAuthProviderTypeParamsGeAuthProvider | undefined;
    set internalValue(value: AgentIdentityAuthProviderAuthProviderTypeParamsGeAuthProvider | undefined);
}
export declare class AgentIdentityAuthProviderAuthProviderTypeParamsGeAuthProviderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AgentIdentityAuthProviderAuthProviderTypeParamsGeAuthProviderOutputReference;
}
export interface AgentIdentityAuthProviderAuthProviderTypeParamsApiKey {
    /**
    * Input only. The API key for this auth_provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#api_key AgentIdentityAuthProvider#api_key}
    */
    readonly apiKey?: string;
}
export declare function agentIdentityAuthProviderAuthProviderTypeParamsApiKeyToTerraform(struct?: AgentIdentityAuthProviderAuthProviderTypeParamsApiKeyOutputReference | AgentIdentityAuthProviderAuthProviderTypeParamsApiKey): any;
export declare function agentIdentityAuthProviderAuthProviderTypeParamsApiKeyToHclTerraform(struct?: AgentIdentityAuthProviderAuthProviderTypeParamsApiKeyOutputReference | AgentIdentityAuthProviderAuthProviderTypeParamsApiKey): any;
export declare class AgentIdentityAuthProviderAuthProviderTypeParamsApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentIdentityAuthProviderAuthProviderTypeParamsApiKey | undefined;
    set internalValue(value: AgentIdentityAuthProviderAuthProviderTypeParamsApiKey | undefined);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
}
export interface AgentIdentityAuthProviderAuthProviderTypeParamsThreeLeggedOauth {
    /**
    * The authorization endpoint to send users to for consenting to delegate
    * to the agent.
    * eg. "https://auth.atlassian.com/authorize"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#authorization_url AgentIdentityAuthProvider#authorization_url}
    */
    readonly authorizationUrl?: string;
    /**
    * The client ID of the OAuth client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#client_id AgentIdentityAuthProvider#client_id}
    */
    readonly clientId?: string;
    /**
    * Input only. The client secret of the OAuth client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#client_secret AgentIdentityAuthProvider#client_secret}
    */
    readonly clientSecret?: string;
    /**
    * Input only. The client secret of the OAuth client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#client_secret_wo AgentIdentityAuthProvider#client_secret_wo}
    */
    readonly clientSecretWo?: string;
    /**
    * Triggers update of 'client_secret_wo' write-only. Increment this value when an update to 'client_secret_wo' is needed. For more info see [updating write-only arguments](/docs/providers/google/guides/using_write_only_arguments.html#updating-write-only-arguments)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#client_secret_wo_version AgentIdentityAuthProvider#client_secret_wo_version}
    */
    readonly clientSecretWoVersion?: string;
    /**
    * The default continue URI for 3LO flow and it will be used when no continue
    * URI is provided in the RetrieveCredentials request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#default_continue_uri AgentIdentityAuthProvider#default_continue_uri}
    */
    readonly defaultContinueUri?: string;
    /**
    * Enables Proof Key for Code Exchange (PKCE) for the OAuth flow to prevent
    * authorization code interception attacks.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#enable_pkce AgentIdentityAuthProvider#enable_pkce}
    */
    readonly enablePkce?: boolean | cdktn.IResolvable;
    /**
    * The token endpoint for requesting tokens on behalf of an end user.
    * eg. "https://auth.atlassian.com/oauth/token"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#token_url AgentIdentityAuthProvider#token_url}
    */
    readonly tokenUrl?: string;
}
export declare function agentIdentityAuthProviderAuthProviderTypeParamsThreeLeggedOauthToTerraform(struct?: AgentIdentityAuthProviderAuthProviderTypeParamsThreeLeggedOauthOutputReference | AgentIdentityAuthProviderAuthProviderTypeParamsThreeLeggedOauth): any;
export declare function agentIdentityAuthProviderAuthProviderTypeParamsThreeLeggedOauthToHclTerraform(struct?: AgentIdentityAuthProviderAuthProviderTypeParamsThreeLeggedOauthOutputReference | AgentIdentityAuthProviderAuthProviderTypeParamsThreeLeggedOauth): any;
export declare class AgentIdentityAuthProviderAuthProviderTypeParamsThreeLeggedOauthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentIdentityAuthProviderAuthProviderTypeParamsThreeLeggedOauth | undefined;
    set internalValue(value: AgentIdentityAuthProviderAuthProviderTypeParamsThreeLeggedOauth | undefined);
    private _authorizationUrl?;
    get authorizationUrl(): string;
    set authorizationUrl(value: string);
    resetAuthorizationUrl(): void;
    get authorizationUrlInput(): string | undefined;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    resetClientSecret(): void;
    get clientSecretInput(): string | undefined;
    private _clientSecretWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get clientSecretWo(): string;
    set clientSecretWo(value: string);
    resetClientSecretWo(): void;
    get clientSecretWoInput(): string | undefined;
    private _clientSecretWoVersion?;
    get clientSecretWoVersion(): string;
    set clientSecretWoVersion(value: string);
    resetClientSecretWoVersion(): void;
    get clientSecretWoVersionInput(): string | undefined;
    private _defaultContinueUri?;
    get defaultContinueUri(): string;
    set defaultContinueUri(value: string);
    resetDefaultContinueUri(): void;
    get defaultContinueUriInput(): string | undefined;
    private _enablePkce?;
    get enablePkce(): boolean | cdktn.IResolvable;
    set enablePkce(value: boolean | cdktn.IResolvable);
    resetEnablePkce(): void;
    get enablePkceInput(): boolean | cdktn.IResolvable | undefined;
    get redirectUrl(): string;
    private _tokenUrl?;
    get tokenUrl(): string;
    set tokenUrl(value: string);
    resetTokenUrl(): void;
    get tokenUrlInput(): string | undefined;
}
export interface AgentIdentityAuthProviderAuthProviderTypeParamsTwoLeggedOauth {
    /**
    * The client ID of the OAuth client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#client_id AgentIdentityAuthProvider#client_id}
    */
    readonly clientId?: string;
    /**
    * Input only. The client secret of the OAuth client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#client_secret AgentIdentityAuthProvider#client_secret}
    */
    readonly clientSecret?: string;
    /**
    * Input only. The client secret of the OAuth client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#client_secret_wo AgentIdentityAuthProvider#client_secret_wo}
    */
    readonly clientSecretWo?: string;
    /**
    * Triggers update of 'client_secret_wo' write-only. Increment this value when an update to 'client_secret_wo' is needed. For more info see [updating write-only arguments](/docs/providers/google/guides/using_write_only_arguments.html#updating-write-only-arguments)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#client_secret_wo_version AgentIdentityAuthProvider#client_secret_wo_version}
    */
    readonly clientSecretWoVersion?: string;
    /**
    * The token endpoint of the OAuth client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#token_url AgentIdentityAuthProvider#token_url}
    */
    readonly tokenUrl?: string;
}
export declare function agentIdentityAuthProviderAuthProviderTypeParamsTwoLeggedOauthToTerraform(struct?: AgentIdentityAuthProviderAuthProviderTypeParamsTwoLeggedOauthOutputReference | AgentIdentityAuthProviderAuthProviderTypeParamsTwoLeggedOauth): any;
export declare function agentIdentityAuthProviderAuthProviderTypeParamsTwoLeggedOauthToHclTerraform(struct?: AgentIdentityAuthProviderAuthProviderTypeParamsTwoLeggedOauthOutputReference | AgentIdentityAuthProviderAuthProviderTypeParamsTwoLeggedOauth): any;
export declare class AgentIdentityAuthProviderAuthProviderTypeParamsTwoLeggedOauthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentIdentityAuthProviderAuthProviderTypeParamsTwoLeggedOauth | undefined;
    set internalValue(value: AgentIdentityAuthProviderAuthProviderTypeParamsTwoLeggedOauth | undefined);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    resetClientSecret(): void;
    get clientSecretInput(): string | undefined;
    private _clientSecretWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get clientSecretWo(): string;
    set clientSecretWo(value: string);
    resetClientSecretWo(): void;
    get clientSecretWoInput(): string | undefined;
    private _clientSecretWoVersion?;
    get clientSecretWoVersion(): string;
    set clientSecretWoVersion(value: string);
    resetClientSecretWoVersion(): void;
    get clientSecretWoVersionInput(): string | undefined;
    private _tokenUrl?;
    get tokenUrl(): string;
    set tokenUrl(value: string);
    resetTokenUrl(): void;
    get tokenUrlInput(): string | undefined;
}
export interface AgentIdentityAuthProviderAuthProviderTypeParams {
    /**
    * api_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#api_key AgentIdentityAuthProvider#api_key}
    */
    readonly apiKey?: AgentIdentityAuthProviderAuthProviderTypeParamsApiKey;
    /**
    * three_legged_oauth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#three_legged_oauth AgentIdentityAuthProvider#three_legged_oauth}
    */
    readonly threeLeggedOauth?: AgentIdentityAuthProviderAuthProviderTypeParamsThreeLeggedOauth;
    /**
    * two_legged_oauth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#two_legged_oauth AgentIdentityAuthProvider#two_legged_oauth}
    */
    readonly twoLeggedOauth?: AgentIdentityAuthProviderAuthProviderTypeParamsTwoLeggedOauth;
}
export declare function agentIdentityAuthProviderAuthProviderTypeParamsToTerraform(struct?: AgentIdentityAuthProviderAuthProviderTypeParamsOutputReference | AgentIdentityAuthProviderAuthProviderTypeParams): any;
export declare function agentIdentityAuthProviderAuthProviderTypeParamsToHclTerraform(struct?: AgentIdentityAuthProviderAuthProviderTypeParamsOutputReference | AgentIdentityAuthProviderAuthProviderTypeParams): any;
export declare class AgentIdentityAuthProviderAuthProviderTypeParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentIdentityAuthProviderAuthProviderTypeParams | undefined;
    set internalValue(value: AgentIdentityAuthProviderAuthProviderTypeParams | undefined);
    private _geAuthProvider;
    get geAuthProvider(): AgentIdentityAuthProviderAuthProviderTypeParamsGeAuthProviderList;
    private _apiKey;
    get apiKey(): AgentIdentityAuthProviderAuthProviderTypeParamsApiKeyOutputReference;
    putApiKey(value: AgentIdentityAuthProviderAuthProviderTypeParamsApiKey): void;
    resetApiKey(): void;
    get apiKeyInput(): AgentIdentityAuthProviderAuthProviderTypeParamsApiKey | undefined;
    private _threeLeggedOauth;
    get threeLeggedOauth(): AgentIdentityAuthProviderAuthProviderTypeParamsThreeLeggedOauthOutputReference;
    putThreeLeggedOauth(value: AgentIdentityAuthProviderAuthProviderTypeParamsThreeLeggedOauth): void;
    resetThreeLeggedOauth(): void;
    get threeLeggedOauthInput(): AgentIdentityAuthProviderAuthProviderTypeParamsThreeLeggedOauth | undefined;
    private _twoLeggedOauth;
    get twoLeggedOauth(): AgentIdentityAuthProviderAuthProviderTypeParamsTwoLeggedOauthOutputReference;
    putTwoLeggedOauth(value: AgentIdentityAuthProviderAuthProviderTypeParamsTwoLeggedOauth): void;
    resetTwoLeggedOauth(): void;
    get twoLeggedOauthInput(): AgentIdentityAuthProviderAuthProviderTypeParamsTwoLeggedOauth | undefined;
}
export interface AgentIdentityAuthProviderTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#create AgentIdentityAuthProvider#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#delete AgentIdentityAuthProvider#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#update AgentIdentityAuthProvider#update}
    */
    readonly update?: string;
}
export declare function agentIdentityAuthProviderTimeoutsToTerraform(struct?: AgentIdentityAuthProviderTimeouts | cdktn.IResolvable): any;
export declare function agentIdentityAuthProviderTimeoutsToHclTerraform(struct?: AgentIdentityAuthProviderTimeouts | cdktn.IResolvable): any;
export declare class AgentIdentityAuthProviderTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentIdentityAuthProviderTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AgentIdentityAuthProviderTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider google_agent_identity_auth_provider}
*/
export declare class AgentIdentityAuthProvider extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_agent_identity_auth_provider";
    /**
    * Generates CDKTN code for importing a AgentIdentityAuthProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AgentIdentityAuthProvider to import
    * @param importFromId The id of the existing AgentIdentityAuthProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AgentIdentityAuthProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_identity_auth_provider google_agent_identity_auth_provider} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AgentIdentityAuthProviderConfig
    */
    constructor(scope: Construct, id: string, config: AgentIdentityAuthProviderConfig);
    private _allowedScopes?;
    get allowedScopes(): string[];
    set allowedScopes(value: string[]);
    resetAllowedScopes(): void;
    get allowedScopesInput(): string[] | undefined;
    private _authProviderId?;
    get authProviderId(): string;
    set authProviderId(value: string);
    get authProviderIdInput(): string | undefined;
    private _blockedScopes?;
    get blockedScopes(): string[];
    set blockedScopes(value: string[]);
    resetBlockedScopes(): void;
    get blockedScopesInput(): string[] | undefined;
    get createTime(): string;
    get deleted(): cdktn.IResolvable;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get expireTime(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get state(): string;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get updateTime(): string;
    private _workloadIds?;
    get workloadIds(): string[];
    set workloadIds(value: string[]);
    resetWorkloadIds(): void;
    get workloadIdsInput(): string[] | undefined;
    private _authProviderTypeParams;
    get authProviderTypeParams(): AgentIdentityAuthProviderAuthProviderTypeParamsOutputReference;
    putAuthProviderTypeParams(value: AgentIdentityAuthProviderAuthProviderTypeParams): void;
    get authProviderTypeParamsInput(): AgentIdentityAuthProviderAuthProviderTypeParams | undefined;
    private _timeouts;
    get timeouts(): AgentIdentityAuthProviderTimeoutsOutputReference;
    putTimeouts(value: AgentIdentityAuthProviderTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AgentIdentityAuthProviderTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
