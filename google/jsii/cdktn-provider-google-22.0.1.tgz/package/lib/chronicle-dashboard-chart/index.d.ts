/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChronicleDashboardChartConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#deletion_policy ChronicleDashboardChart#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#id ChronicleDashboardChart#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the Chronicle instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#instance ChronicleDashboardChart#instance}
    */
    readonly instance: string;
    /**
    * The location of the Chronicle instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#location ChronicleDashboardChart#location}
    */
    readonly location: string;
    /**
    * The parent NativeDashboard resource name, formatted as projects/{project}/locations/{location}/instances/{instance}/nativeDashboards/{dashboard_id}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#native_dashboard ChronicleDashboardChart#native_dashboard}
    */
    readonly nativeDashboard?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#project ChronicleDashboardChart#project}
    */
    readonly project?: string;
    /**
    * chart_layout block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#chart_layout ChronicleDashboardChart#chart_layout}
    */
    readonly chartLayout?: ChronicleDashboardChartChartLayout;
    /**
    * dashboard_chart block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#dashboard_chart ChronicleDashboardChart#dashboard_chart}
    */
    readonly dashboardChart: ChronicleDashboardChartDashboardChart;
    /**
    * dashboard_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#dashboard_query ChronicleDashboardChart#dashboard_query}
    */
    readonly dashboardQuery?: ChronicleDashboardChartDashboardQuery;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#timeouts ChronicleDashboardChart#timeouts}
    */
    readonly timeouts?: ChronicleDashboardChartTimeouts;
}
export interface ChronicleDashboardChartChartLayout {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#span_x ChronicleDashboardChart#span_x}
    */
    readonly spanX: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#span_y ChronicleDashboardChart#span_y}
    */
    readonly spanY: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#start_x ChronicleDashboardChart#start_x}
    */
    readonly startX?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#start_y ChronicleDashboardChart#start_y}
    */
    readonly startY?: number;
}
export declare function chronicleDashboardChartChartLayoutToTerraform(struct?: ChronicleDashboardChartChartLayoutOutputReference | ChronicleDashboardChartChartLayout): any;
export declare function chronicleDashboardChartChartLayoutToHclTerraform(struct?: ChronicleDashboardChartChartLayoutOutputReference | ChronicleDashboardChartChartLayout): any;
export declare class ChronicleDashboardChartChartLayoutOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartChartLayout | undefined;
    set internalValue(value: ChronicleDashboardChartChartLayout | undefined);
    private _spanX?;
    get spanX(): number;
    set spanX(value: number);
    get spanXInput(): number | undefined;
    private _spanY?;
    get spanY(): number;
    set spanY(value: number);
    get spanYInput(): number | undefined;
    private _startX?;
    get startX(): number;
    set startX(value: number);
    resetStartX(): void;
    get startXInput(): number | undefined;
    private _startY?;
    get startY(): number;
    set startY(value: number);
    resetStartY(): void;
    get startYInput(): number | undefined;
}
export interface ChronicleDashboardChartDashboardChartChartDatasource {
    /**
    * Name(s) of the datasource used in the chart. Available values include:
    * 'UDM', 'ENTITY', 'INGESTION_METRICS', 'RULE_DETECTIONS', 'RULESETS',
    * 'GLOBAL', 'IOC_MATCHES', 'RULES', 'SOAR_CASES', 'SOAR_PLAYBOOKS',
    * 'SOAR_CASE_HISTORY', 'DATA_TABLE', 'INVESTIGATION', 'INVESTIGATION_FEEDBACK'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#data_sources ChronicleDashboardChart#data_sources}
    */
    readonly dataSources?: string[];
}
export declare function chronicleDashboardChartDashboardChartChartDatasourceToTerraform(struct?: ChronicleDashboardChartDashboardChartChartDatasourceOutputReference | ChronicleDashboardChartDashboardChartChartDatasource): any;
export declare function chronicleDashboardChartDashboardChartChartDatasourceToHclTerraform(struct?: ChronicleDashboardChartDashboardChartChartDatasourceOutputReference | ChronicleDashboardChartDashboardChartChartDatasource): any;
export declare class ChronicleDashboardChartDashboardChartChartDatasourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartChartDatasource | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartChartDatasource | undefined);
    get dashboardQuery(): string;
    private _dataSources?;
    get dataSources(): string[];
    set dataSources(value: string[]);
    resetDataSources(): void;
    get dataSourcesInput(): string[] | undefined;
}
export interface ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsExternalLink {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#description ChronicleDashboardChart#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#link ChronicleDashboardChart#link}
    */
    readonly link: string;
}
export declare function chronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsExternalLinkToTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsExternalLinkOutputReference | ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsExternalLink): any;
export declare function chronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsExternalLinkToHclTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsExternalLinkOutputReference | ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsExternalLink): any;
export declare class ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsExternalLinkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsExternalLink | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsExternalLink | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _link?;
    get link(): string;
    set link(value: string);
    get linkInput(): string | undefined;
}
export interface ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValues {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#field_values ChronicleDashboardChart#field_values}
    */
    readonly fieldValues?: string[];
    /**
    *  Possible values: ["EQUAL", "NOT_EQUAL", "IN", "GREATER_THAN", "GREATER_THAN_OR_EQUAL_TO", "LESS_THAN", "LESS_THAN_OR_EQUAL_TO", "BETWEEN", "PAST", "IS_NULL", "IS_NOT_NULL", "STARTS_WITH", "ENDS_WITH", "DOES_NOT_STARTS_WITH", "DOES_NOT_ENDS_WITH", "NOT_IN", "CONTAINS", "DOES_NOT_CONTAIN"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#filter_operator ChronicleDashboardChart#filter_operator}
    */
    readonly filterOperator?: string;
}
export declare function chronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValuesToTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValues | cdktn.IResolvable): any;
export declare function chronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValuesToHclTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValues | cdktn.IResolvable): any;
export declare class ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValues | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValues | cdktn.IResolvable | undefined);
    private _fieldValues?;
    get fieldValues(): string[];
    set fieldValues(value: string[]);
    resetFieldValues(): void;
    get fieldValuesInput(): string[] | undefined;
    private _filterOperator?;
    get filterOperator(): string;
    set filterOperator(value: string);
    resetFilterOperator(): void;
    get filterOperatorInput(): string | undefined;
}
export declare class ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValuesList extends cdktn.ComplexList {
    internalValue?: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValuesOutputReference;
}
export interface ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFilters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#dashboard_filter_id ChronicleDashboardChart#dashboard_filter_id}
    */
    readonly dashboardFilterId: string;
    /**
    * filter_operator_and_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#filter_operator_and_values ChronicleDashboardChart#filter_operator_and_values}
    */
    readonly filterOperatorAndValues: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValues[] | cdktn.IResolvable;
}
export declare function chronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFiltersToTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFilters | cdktn.IResolvable): any;
export declare function chronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFiltersToHclTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFilters | cdktn.IResolvable): any;
export declare class ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFilters | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFilters | cdktn.IResolvable | undefined);
    private _dashboardFilterId?;
    get dashboardFilterId(): string;
    set dashboardFilterId(value: string);
    get dashboardFilterIdInput(): string | undefined;
    private _filterOperatorAndValues;
    get filterOperatorAndValues(): ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValuesList;
    putFilterOperatorAndValues(value: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValues[] | cdktn.IResolvable): void;
    get filterOperatorAndValuesInput(): cdktn.IResolvable | ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValues[] | undefined;
}
export declare class ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFiltersList extends cdktn.ComplexList {
    internalValue?: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFiltersOutputReference;
}
export interface ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilter {
    /**
    * dashboard_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#dashboard_filters ChronicleDashboardChart#dashboard_filters}
    */
    readonly dashboardFilters: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFilters[] | cdktn.IResolvable;
}
export declare function chronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterToTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterOutputReference | ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilter): any;
export declare function chronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterToHclTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterOutputReference | ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilter): any;
export declare class ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilter | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilter | undefined);
    private _dashboardFilters;
    get dashboardFilters(): ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFiltersList;
    putDashboardFilters(value: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFilters[] | cdktn.IResolvable): void;
    get dashboardFiltersInput(): cdktn.IResolvable | ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterDashboardFilters[] | undefined;
}
export interface ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsQuery {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#query ChronicleDashboardChart#query}
    */
    readonly query: string;
}
export declare function chronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsQueryToTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsQueryOutputReference | ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsQuery): any;
export declare function chronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsQueryToHclTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsQueryOutputReference | ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsQuery): any;
export declare class ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsQuery | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsQuery | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#left_click_column ChronicleDashboardChart#left_click_column}
    */
    readonly leftClickColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#new_tab ChronicleDashboardChart#new_tab}
    */
    readonly newTab: boolean | cdktn.IResolvable;
    /**
    * external_link block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#external_link ChronicleDashboardChart#external_link}
    */
    readonly externalLink?: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsExternalLink;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#filter ChronicleDashboardChart#filter}
    */
    readonly filter?: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilter;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#query ChronicleDashboardChart#query}
    */
    readonly query?: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsQuery;
}
export declare function chronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsToTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsOutputReference | ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettings): any;
export declare function chronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsToHclTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsOutputReference | ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettings): any;
export declare class ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettings | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettings | undefined);
    private _leftClickColumn?;
    get leftClickColumn(): string;
    set leftClickColumn(value: string);
    resetLeftClickColumn(): void;
    get leftClickColumnInput(): string | undefined;
    private _newTab?;
    get newTab(): boolean | cdktn.IResolvable;
    set newTab(value: boolean | cdktn.IResolvable);
    get newTabInput(): boolean | cdktn.IResolvable | undefined;
    private _externalLink;
    get externalLink(): ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsExternalLinkOutputReference;
    putExternalLink(value: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsExternalLink): void;
    resetExternalLink(): void;
    get externalLinkInput(): ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsExternalLink | undefined;
    private _filter;
    get filter(): ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilterOutputReference;
    putFilter(value: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilter): void;
    resetFilter(): void;
    get filterInput(): ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsFilter | undefined;
    private _query;
    get query(): ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsQueryOutputReference;
    putQuery(value: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsQuery): void;
    resetQuery(): void;
    get queryInput(): ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsQuery | undefined;
}
export interface ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsDefaultSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#enabled ChronicleDashboardChart#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function chronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsDefaultSettingsToTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsDefaultSettingsOutputReference | ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsDefaultSettings): any;
export declare function chronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsDefaultSettingsToHclTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsDefaultSettingsOutputReference | ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsDefaultSettings): any;
export declare class ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsDefaultSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsDefaultSettings | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsDefaultSettings | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDowns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#display_name ChronicleDashboardChart#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#id ChronicleDashboardChart#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * custom_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#custom_settings ChronicleDashboardChart#custom_settings}
    */
    readonly customSettings?: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettings;
    /**
    * default_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#default_settings ChronicleDashboardChart#default_settings}
    */
    readonly defaultSettings?: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsDefaultSettings;
}
export declare function chronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsToTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDowns | cdktn.IResolvable): any;
export declare function chronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsToHclTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDowns | cdktn.IResolvable): any;
export declare class ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDowns | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDowns | cdktn.IResolvable | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _customSettings;
    get customSettings(): ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettingsOutputReference;
    putCustomSettings(value: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettings): void;
    resetCustomSettings(): void;
    get customSettingsInput(): ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsCustomSettings | undefined;
    private _defaultSettings;
    get defaultSettings(): ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsDefaultSettingsOutputReference;
    putDefaultSettings(value: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsDefaultSettings): void;
    resetDefaultSettings(): void;
    get defaultSettingsInput(): ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsDefaultSettings | undefined;
}
export declare class ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsList extends cdktn.ComplexList {
    internalValue?: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDowns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsOutputReference;
}
export interface ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsExternalLink {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#description ChronicleDashboardChart#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#link ChronicleDashboardChart#link}
    */
    readonly link: string;
}
export declare function chronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsExternalLinkToTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsExternalLinkOutputReference | ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsExternalLink): any;
export declare function chronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsExternalLinkToHclTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsExternalLinkOutputReference | ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsExternalLink): any;
export declare class ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsExternalLinkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsExternalLink | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsExternalLink | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _link?;
    get link(): string;
    set link(value: string);
    get linkInput(): string | undefined;
}
export interface ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValues {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#field_values ChronicleDashboardChart#field_values}
    */
    readonly fieldValues?: string[];
    /**
    *  Possible values: ["EQUAL", "NOT_EQUAL", "IN", "GREATER_THAN", "GREATER_THAN_OR_EQUAL_TO", "LESS_THAN", "LESS_THAN_OR_EQUAL_TO", "BETWEEN", "PAST", "IS_NULL", "IS_NOT_NULL", "STARTS_WITH", "ENDS_WITH", "DOES_NOT_STARTS_WITH", "DOES_NOT_ENDS_WITH", "NOT_IN", "CONTAINS", "DOES_NOT_CONTAIN"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#filter_operator ChronicleDashboardChart#filter_operator}
    */
    readonly filterOperator?: string;
}
export declare function chronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValuesToTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValues | cdktn.IResolvable): any;
export declare function chronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValuesToHclTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValues | cdktn.IResolvable): any;
export declare class ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValues | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValues | cdktn.IResolvable | undefined);
    private _fieldValues?;
    get fieldValues(): string[];
    set fieldValues(value: string[]);
    resetFieldValues(): void;
    get fieldValuesInput(): string[] | undefined;
    private _filterOperator?;
    get filterOperator(): string;
    set filterOperator(value: string);
    resetFilterOperator(): void;
    get filterOperatorInput(): string | undefined;
}
export declare class ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValuesList extends cdktn.ComplexList {
    internalValue?: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValuesOutputReference;
}
export interface ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFilters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#dashboard_filter_id ChronicleDashboardChart#dashboard_filter_id}
    */
    readonly dashboardFilterId: string;
    /**
    * filter_operator_and_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#filter_operator_and_values ChronicleDashboardChart#filter_operator_and_values}
    */
    readonly filterOperatorAndValues: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValues[] | cdktn.IResolvable;
}
export declare function chronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFiltersToTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFilters | cdktn.IResolvable): any;
export declare function chronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFiltersToHclTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFilters | cdktn.IResolvable): any;
export declare class ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFilters | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFilters | cdktn.IResolvable | undefined);
    private _dashboardFilterId?;
    get dashboardFilterId(): string;
    set dashboardFilterId(value: string);
    get dashboardFilterIdInput(): string | undefined;
    private _filterOperatorAndValues;
    get filterOperatorAndValues(): ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValuesList;
    putFilterOperatorAndValues(value: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValues[] | cdktn.IResolvable): void;
    get filterOperatorAndValuesInput(): cdktn.IResolvable | ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFiltersFilterOperatorAndValues[] | undefined;
}
export declare class ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFiltersList extends cdktn.ComplexList {
    internalValue?: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFiltersOutputReference;
}
export interface ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilter {
    /**
    * dashboard_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#dashboard_filters ChronicleDashboardChart#dashboard_filters}
    */
    readonly dashboardFilters: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFilters[] | cdktn.IResolvable;
}
export declare function chronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterToTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterOutputReference | ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilter): any;
export declare function chronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterToHclTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterOutputReference | ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilter): any;
export declare class ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilter | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilter | undefined);
    private _dashboardFilters;
    get dashboardFilters(): ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFiltersList;
    putDashboardFilters(value: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFilters[] | cdktn.IResolvable): void;
    get dashboardFiltersInput(): cdktn.IResolvable | ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterDashboardFilters[] | undefined;
}
export interface ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsQuery {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#query ChronicleDashboardChart#query}
    */
    readonly query: string;
}
export declare function chronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsQueryToTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsQueryOutputReference | ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsQuery): any;
export declare function chronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsQueryToHclTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsQueryOutputReference | ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsQuery): any;
export declare class ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsQuery | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsQuery | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#new_tab ChronicleDashboardChart#new_tab}
    */
    readonly newTab: boolean | cdktn.IResolvable;
    /**
    * external_link block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#external_link ChronicleDashboardChart#external_link}
    */
    readonly externalLink?: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsExternalLink;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#filter ChronicleDashboardChart#filter}
    */
    readonly filter?: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilter;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#query ChronicleDashboardChart#query}
    */
    readonly query?: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsQuery;
}
export declare function chronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsToTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsOutputReference | ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettings): any;
export declare function chronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsToHclTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsOutputReference | ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettings): any;
export declare class ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettings | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettings | undefined);
    private _newTab?;
    get newTab(): boolean | cdktn.IResolvable;
    set newTab(value: boolean | cdktn.IResolvable);
    get newTabInput(): boolean | cdktn.IResolvable | undefined;
    private _externalLink;
    get externalLink(): ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsExternalLinkOutputReference;
    putExternalLink(value: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsExternalLink): void;
    resetExternalLink(): void;
    get externalLinkInput(): ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsExternalLink | undefined;
    private _filter;
    get filter(): ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilterOutputReference;
    putFilter(value: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilter): void;
    resetFilter(): void;
    get filterInput(): ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsFilter | undefined;
    private _query;
    get query(): ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsQueryOutputReference;
    putQuery(value: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsQuery): void;
    resetQuery(): void;
    get queryInput(): ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsQuery | undefined;
}
export interface ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsDefaultSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#enabled ChronicleDashboardChart#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function chronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsDefaultSettingsToTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsDefaultSettingsOutputReference | ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsDefaultSettings): any;
export declare function chronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsDefaultSettingsToHclTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsDefaultSettingsOutputReference | ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsDefaultSettings): any;
export declare class ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsDefaultSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsDefaultSettings | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsDefaultSettings | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDowns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#display_name ChronicleDashboardChart#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#id ChronicleDashboardChart#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * custom_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#custom_settings ChronicleDashboardChart#custom_settings}
    */
    readonly customSettings?: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettings;
    /**
    * default_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#default_settings ChronicleDashboardChart#default_settings}
    */
    readonly defaultSettings?: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsDefaultSettings;
}
export declare function chronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsToTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDowns | cdktn.IResolvable): any;
export declare function chronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsToHclTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDowns | cdktn.IResolvable): any;
export declare class ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDowns | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDowns | cdktn.IResolvable | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _customSettings;
    get customSettings(): ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettingsOutputReference;
    putCustomSettings(value: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettings): void;
    resetCustomSettings(): void;
    get customSettingsInput(): ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsCustomSettings | undefined;
    private _defaultSettings;
    get defaultSettings(): ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsDefaultSettingsOutputReference;
    putDefaultSettings(value: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsDefaultSettings): void;
    resetDefaultSettings(): void;
    get defaultSettingsInput(): ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsDefaultSettings | undefined;
}
export declare class ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsList extends cdktn.ComplexList {
    internalValue?: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDowns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsOutputReference;
}
export interface ChronicleDashboardChartDashboardChartDrillDownConfig {
    /**
    * left_drill_downs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#left_drill_downs ChronicleDashboardChart#left_drill_downs}
    */
    readonly leftDrillDowns?: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDowns[] | cdktn.IResolvable;
    /**
    * right_drill_downs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#right_drill_downs ChronicleDashboardChart#right_drill_downs}
    */
    readonly rightDrillDowns?: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDowns[] | cdktn.IResolvable;
}
export declare function chronicleDashboardChartDashboardChartDrillDownConfigToTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigOutputReference | ChronicleDashboardChartDashboardChartDrillDownConfig): any;
export declare function chronicleDashboardChartDashboardChartDrillDownConfigToHclTerraform(struct?: ChronicleDashboardChartDashboardChartDrillDownConfigOutputReference | ChronicleDashboardChartDashboardChartDrillDownConfig): any;
export declare class ChronicleDashboardChartDashboardChartDrillDownConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartDrillDownConfig | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartDrillDownConfig | undefined);
    private _leftDrillDowns;
    get leftDrillDowns(): ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDownsList;
    putLeftDrillDowns(value: ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDowns[] | cdktn.IResolvable): void;
    resetLeftDrillDowns(): void;
    get leftDrillDownsInput(): cdktn.IResolvable | ChronicleDashboardChartDashboardChartDrillDownConfigLeftDrillDowns[] | undefined;
    private _rightDrillDowns;
    get rightDrillDowns(): ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDownsList;
    putRightDrillDowns(value: ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDowns[] | cdktn.IResolvable): void;
    resetRightDrillDowns(): void;
    get rightDrillDownsInput(): cdktn.IResolvable | ChronicleDashboardChartDashboardChartDrillDownConfigRightDrillDowns[] | undefined;
}
export interface ChronicleDashboardChartDashboardChartVisualizationButtonProperties {
    /**
    *  Possible values: ["BUTTON_STYLE_UNSPECIFIED", "BUTTON_STYLE_FILLED", "BUTTON_STYLE_OUTLINED", "BUTTON_STYLE_TRANSPARENT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#button_style ChronicleDashboardChart#button_style}
    */
    readonly buttonStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#color ChronicleDashboardChart#color}
    */
    readonly color?: string;
}
export declare function chronicleDashboardChartDashboardChartVisualizationButtonPropertiesToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationButtonPropertiesOutputReference | ChronicleDashboardChartDashboardChartVisualizationButtonProperties): any;
export declare function chronicleDashboardChartDashboardChartVisualizationButtonPropertiesToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationButtonPropertiesOutputReference | ChronicleDashboardChartDashboardChartVisualizationButtonProperties): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationButtonPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationButtonProperties | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationButtonProperties | undefined);
    private _buttonStyle?;
    get buttonStyle(): string;
    set buttonStyle(value: string);
    resetButtonStyle(): void;
    get buttonStyleInput(): string | undefined;
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
}
export interface ChronicleDashboardChartDashboardChartVisualizationButton {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#description ChronicleDashboardChart#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#hyperlink ChronicleDashboardChart#hyperlink}
    */
    readonly hyperlink: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#label ChronicleDashboardChart#label}
    */
    readonly label: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#new_tab ChronicleDashboardChart#new_tab}
    */
    readonly newTab?: boolean | cdktn.IResolvable;
    /**
    * properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#properties ChronicleDashboardChart#properties}
    */
    readonly properties?: ChronicleDashboardChartDashboardChartVisualizationButtonProperties;
}
export declare function chronicleDashboardChartDashboardChartVisualizationButtonToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationButtonOutputReference | ChronicleDashboardChartDashboardChartVisualizationButton): any;
export declare function chronicleDashboardChartDashboardChartVisualizationButtonToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationButtonOutputReference | ChronicleDashboardChartDashboardChartVisualizationButton): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationButtonOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationButton | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationButton | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _hyperlink?;
    get hyperlink(): string;
    set hyperlink(value: string);
    get hyperlinkInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
    private _newTab?;
    get newTab(): boolean | cdktn.IResolvable;
    set newTab(value: boolean | cdktn.IResolvable);
    resetNewTab(): void;
    get newTabInput(): boolean | cdktn.IResolvable | undefined;
    private _properties;
    get properties(): ChronicleDashboardChartDashboardChartVisualizationButtonPropertiesOutputReference;
    putProperties(value: ChronicleDashboardChartDashboardChartVisualizationButtonProperties): void;
    resetProperties(): void;
    get propertiesInput(): ChronicleDashboardChartDashboardChartVisualizationButtonProperties | undefined;
}
export interface ChronicleDashboardChartDashboardChartVisualizationColumnDefs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#field ChronicleDashboardChart#field}
    */
    readonly field?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#header ChronicleDashboardChart#header}
    */
    readonly header?: string;
}
export declare function chronicleDashboardChartDashboardChartVisualizationColumnDefsToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationColumnDefs | cdktn.IResolvable): any;
export declare function chronicleDashboardChartDashboardChartVisualizationColumnDefsToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationColumnDefs | cdktn.IResolvable): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationColumnDefsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationColumnDefs | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationColumnDefs | cdktn.IResolvable | undefined);
    private _field?;
    get field(): string;
    set field(value: string);
    resetField(): void;
    get fieldInput(): string | undefined;
    private _header?;
    get header(): string;
    set header(value: string);
    resetHeader(): void;
    get headerInput(): string | undefined;
}
export declare class ChronicleDashboardChartDashboardChartVisualizationColumnDefsList extends cdktn.ComplexList {
    internalValue?: ChronicleDashboardChartDashboardChartVisualizationColumnDefs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleDashboardChartDashboardChartVisualizationColumnDefsOutputReference;
}
export interface ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigDataSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#count_column ChronicleDashboardChart#count_column}
    */
    readonly countColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#latitude_column ChronicleDashboardChart#latitude_column}
    */
    readonly latitudeColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#longitude_column ChronicleDashboardChart#longitude_column}
    */
    readonly longitudeColumn?: string;
}
export declare function chronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigDataSettingsToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigDataSettingsOutputReference | ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigDataSettings): any;
export declare function chronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigDataSettingsToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigDataSettingsOutputReference | ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigDataSettings): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigDataSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigDataSettings | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigDataSettings | undefined);
    private _countColumn?;
    get countColumn(): string;
    set countColumn(value: string);
    resetCountColumn(): void;
    get countColumnInput(): string | undefined;
    private _latitudeColumn?;
    get latitudeColumn(): string;
    set latitudeColumn(value: string);
    resetLatitudeColumn(): void;
    get latitudeColumnInput(): string | undefined;
    private _longitudeColumn?;
    get longitudeColumn(): string;
    set longitudeColumn(value: string);
    resetLongitudeColumn(): void;
    get longitudeColumnInput(): string | undefined;
}
export interface ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigMapPosition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#fit_data ChronicleDashboardChart#fit_data}
    */
    readonly fitData?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#latitude_value ChronicleDashboardChart#latitude_value}
    */
    readonly latitudeValue?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#longitude_value ChronicleDashboardChart#longitude_value}
    */
    readonly longitudeValue?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#zoom_scale_value ChronicleDashboardChart#zoom_scale_value}
    */
    readonly zoomScaleValue?: number;
}
export declare function chronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigMapPositionToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigMapPositionOutputReference | ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigMapPosition): any;
export declare function chronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigMapPositionToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigMapPositionOutputReference | ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigMapPosition): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigMapPositionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigMapPosition | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigMapPosition | undefined);
    private _fitData?;
    get fitData(): boolean | cdktn.IResolvable;
    set fitData(value: boolean | cdktn.IResolvable);
    resetFitData(): void;
    get fitDataInput(): boolean | cdktn.IResolvable | undefined;
    private _latitudeValue?;
    get latitudeValue(): number;
    set latitudeValue(value: number);
    resetLatitudeValue(): void;
    get latitudeValueInput(): number | undefined;
    private _longitudeValue?;
    get longitudeValue(): number;
    set longitudeValue(value: number);
    resetLongitudeValue(): void;
    get longitudeValueInput(): number | undefined;
    private _zoomScaleValue?;
    get zoomScaleValue(): number;
    set zoomScaleValue(value: number);
    resetZoomScaleValue(): void;
    get zoomScaleValueInput(): number | undefined;
}
export interface ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigPointSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#color ChronicleDashboardChart#color}
    */
    readonly color?: string;
    /**
    *  Possible values: ["POINT_SIZE_TYPE_UNSPECIFIED", "POINT_SIZE_TYPE_FIXED", "POINT_SIZE_TYPE_PROPORTIONAL_TO_SIZE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#point_size_type ChronicleDashboardChart#point_size_type}
    */
    readonly pointSizeType?: string;
}
export declare function chronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigPointSettingsToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigPointSettingsOutputReference | ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigPointSettings): any;
export declare function chronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigPointSettingsToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigPointSettingsOutputReference | ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigPointSettings): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigPointSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigPointSettings | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigPointSettings | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _pointSizeType?;
    get pointSizeType(): string;
    set pointSizeType(value: string);
    resetPointSizeType(): void;
    get pointSizeTypeInput(): string | undefined;
}
export interface ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfig {
    /**
    *  Possible values: ["PLOT_MODE_UNSPECIFIED", "PLOT_MODE_POINTS", "PLOT_MODE_HEATMAP", "PLOT_MODE_BOTH"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#plot_mode ChronicleDashboardChart#plot_mode}
    */
    readonly plotMode?: string;
    /**
    * data_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#data_settings ChronicleDashboardChart#data_settings}
    */
    readonly dataSettings?: ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigDataSettings;
    /**
    * map_position block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#map_position ChronicleDashboardChart#map_position}
    */
    readonly mapPosition?: ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigMapPosition;
    /**
    * point_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#point_settings ChronicleDashboardChart#point_settings}
    */
    readonly pointSettings?: ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigPointSettings;
}
export declare function chronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigOutputReference | ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfig): any;
export declare function chronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigOutputReference | ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfig): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfig | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfig | undefined);
    private _plotMode?;
    get plotMode(): string;
    set plotMode(value: string);
    resetPlotMode(): void;
    get plotModeInput(): string | undefined;
    private _dataSettings;
    get dataSettings(): ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigDataSettingsOutputReference;
    putDataSettings(value: ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigDataSettings): void;
    resetDataSettings(): void;
    get dataSettingsInput(): ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigDataSettings | undefined;
    private _mapPosition;
    get mapPosition(): ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigMapPositionOutputReference;
    putMapPosition(value: ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigMapPosition): void;
    resetMapPosition(): void;
    get mapPositionInput(): ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigMapPosition | undefined;
    private _pointSettings;
    get pointSettings(): ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigPointSettingsOutputReference;
    putPointSettings(value: ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigPointSettings): void;
    resetPointSettings(): void;
    get pointSettingsInput(): ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigPointSettings | undefined;
}
export interface ChronicleDashboardChartDashboardChartVisualizationLegends {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#bottom ChronicleDashboardChart#bottom}
    */
    readonly bottom?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#id ChronicleDashboardChart#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#left ChronicleDashboardChart#left}
    */
    readonly left?: number;
    /**
    *  Possible values: ["AUTO", "LEFT", "RIGHT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#legend_align ChronicleDashboardChart#legend_align}
    */
    readonly legendAlign?: string;
    /**
    *  Possible values: ["VERTICAL", "HORIZONTAL"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#legend_orient ChronicleDashboardChart#legend_orient}
    */
    readonly legendOrient?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#padding ChronicleDashboardChart#padding}
    */
    readonly padding?: number[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#right ChronicleDashboardChart#right}
    */
    readonly right?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#show ChronicleDashboardChart#show}
    */
    readonly show?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#top ChronicleDashboardChart#top}
    */
    readonly top?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#z ChronicleDashboardChart#z}
    */
    readonly z?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#z_level ChronicleDashboardChart#z_level}
    */
    readonly zLevel?: number;
}
export declare function chronicleDashboardChartDashboardChartVisualizationLegendsToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationLegends | cdktn.IResolvable): any;
export declare function chronicleDashboardChartDashboardChartVisualizationLegendsToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationLegends | cdktn.IResolvable): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationLegendsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationLegends | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationLegends | cdktn.IResolvable | undefined);
    private _bottom?;
    get bottom(): number;
    set bottom(value: number);
    resetBottom(): void;
    get bottomInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _left?;
    get left(): number;
    set left(value: number);
    resetLeft(): void;
    get leftInput(): number | undefined;
    private _legendAlign?;
    get legendAlign(): string;
    set legendAlign(value: string);
    resetLegendAlign(): void;
    get legendAlignInput(): string | undefined;
    private _legendOrient?;
    get legendOrient(): string;
    set legendOrient(value: string);
    resetLegendOrient(): void;
    get legendOrientInput(): string | undefined;
    private _padding?;
    get padding(): number[];
    set padding(value: number[]);
    resetPadding(): void;
    get paddingInput(): number[] | undefined;
    private _right?;
    get right(): number;
    set right(value: number);
    resetRight(): void;
    get rightInput(): number | undefined;
    private _show?;
    get show(): boolean | cdktn.IResolvable;
    set show(value: boolean | cdktn.IResolvable);
    resetShow(): void;
    get showInput(): boolean | cdktn.IResolvable | undefined;
    private _top?;
    get top(): number;
    set top(value: number);
    resetTop(): void;
    get topInput(): number | undefined;
    private _z?;
    get z(): number;
    set z(value: number);
    resetZ(): void;
    get zInput(): number | undefined;
    private _zLevel?;
    get zLevel(): number;
    set zLevel(value: number);
    resetZLevel(): void;
    get zLevelInput(): number | undefined;
}
export declare class ChronicleDashboardChartDashboardChartVisualizationLegendsList extends cdktn.ComplexList {
    internalValue?: ChronicleDashboardChartDashboardChartVisualizationLegends[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleDashboardChartDashboardChartVisualizationLegendsOutputReference;
}
export interface ChronicleDashboardChartDashboardChartVisualizationMarkdownProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#background_color ChronicleDashboardChart#background_color}
    */
    readonly backgroundColor?: string;
}
export declare function chronicleDashboardChartDashboardChartVisualizationMarkdownPropertiesToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationMarkdownPropertiesOutputReference | ChronicleDashboardChartDashboardChartVisualizationMarkdownProperties): any;
export declare function chronicleDashboardChartDashboardChartVisualizationMarkdownPropertiesToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationMarkdownPropertiesOutputReference | ChronicleDashboardChartDashboardChartVisualizationMarkdownProperties): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationMarkdownPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationMarkdownProperties | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationMarkdownProperties | undefined);
    private _backgroundColor?;
    get backgroundColor(): string;
    set backgroundColor(value: string);
    resetBackgroundColor(): void;
    get backgroundColorInput(): string | undefined;
}
export interface ChronicleDashboardChartDashboardChartVisualizationMarkdown {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#content ChronicleDashboardChart#content}
    */
    readonly content: string;
    /**
    * properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#properties ChronicleDashboardChart#properties}
    */
    readonly properties?: ChronicleDashboardChartDashboardChartVisualizationMarkdownProperties;
}
export declare function chronicleDashboardChartDashboardChartVisualizationMarkdownToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationMarkdownOutputReference | ChronicleDashboardChartDashboardChartVisualizationMarkdown): any;
export declare function chronicleDashboardChartDashboardChartVisualizationMarkdownToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationMarkdownOutputReference | ChronicleDashboardChartDashboardChartVisualizationMarkdown): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationMarkdownOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationMarkdown | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationMarkdown | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    private _properties;
    get properties(): ChronicleDashboardChartDashboardChartVisualizationMarkdownPropertiesOutputReference;
    putProperties(value: ChronicleDashboardChartDashboardChartVisualizationMarkdownProperties): void;
    resetProperties(): void;
    get propertiesInput(): ChronicleDashboardChartDashboardChartVisualizationMarkdownProperties | undefined;
}
export interface ChronicleDashboardChartDashboardChartVisualizationSeriesAreaStyle {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#color ChronicleDashboardChart#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#opacity ChronicleDashboardChart#opacity}
    */
    readonly opacity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#origin ChronicleDashboardChart#origin}
    */
    readonly origin?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#shadow_blur ChronicleDashboardChart#shadow_blur}
    */
    readonly shadowBlur?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#shadow_color ChronicleDashboardChart#shadow_color}
    */
    readonly shadowColor?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#shadow_offset_x ChronicleDashboardChart#shadow_offset_x}
    */
    readonly shadowOffsetX?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#shadow_offset_y ChronicleDashboardChart#shadow_offset_y}
    */
    readonly shadowOffsetY?: number;
}
export declare function chronicleDashboardChartDashboardChartVisualizationSeriesAreaStyleToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationSeriesAreaStyleOutputReference | ChronicleDashboardChartDashboardChartVisualizationSeriesAreaStyle): any;
export declare function chronicleDashboardChartDashboardChartVisualizationSeriesAreaStyleToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationSeriesAreaStyleOutputReference | ChronicleDashboardChartDashboardChartVisualizationSeriesAreaStyle): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationSeriesAreaStyleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationSeriesAreaStyle | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationSeriesAreaStyle | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _opacity?;
    get opacity(): number;
    set opacity(value: number);
    resetOpacity(): void;
    get opacityInput(): number | undefined;
    private _origin?;
    get origin(): string;
    set origin(value: string);
    resetOrigin(): void;
    get originInput(): string | undefined;
    private _shadowBlur?;
    get shadowBlur(): number;
    set shadowBlur(value: number);
    resetShadowBlur(): void;
    get shadowBlurInput(): number | undefined;
    private _shadowColor?;
    get shadowColor(): string;
    set shadowColor(value: string);
    resetShadowColor(): void;
    get shadowColorInput(): string | undefined;
    private _shadowOffsetX?;
    get shadowOffsetX(): number;
    set shadowOffsetX(value: number);
    resetShadowOffsetX(): void;
    get shadowOffsetXInput(): number | undefined;
    private _shadowOffsetY?;
    get shadowOffsetY(): number;
    set shadowOffsetY(value: number);
    resetShadowOffsetY(): void;
    get shadowOffsetYInput(): number | undefined;
}
export interface ChronicleDashboardChartDashboardChartVisualizationSeriesDataLabel {
    /**
    * Whether to show data label.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#show ChronicleDashboardChart#show}
    */
    readonly show?: boolean | cdktn.IResolvable;
}
export declare function chronicleDashboardChartDashboardChartVisualizationSeriesDataLabelToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationSeriesDataLabelOutputReference | ChronicleDashboardChartDashboardChartVisualizationSeriesDataLabel): any;
export declare function chronicleDashboardChartDashboardChartVisualizationSeriesDataLabelToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationSeriesDataLabelOutputReference | ChronicleDashboardChartDashboardChartVisualizationSeriesDataLabel): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationSeriesDataLabelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationSeriesDataLabel | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationSeriesDataLabel | undefined);
    private _show?;
    get show(): boolean | cdktn.IResolvable;
    set show(value: boolean | cdktn.IResolvable);
    resetShow(): void;
    get showInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ChronicleDashboardChartDashboardChartVisualizationSeriesEncode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#item_name ChronicleDashboardChart#item_name}
    */
    readonly itemName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#value ChronicleDashboardChart#value}
    */
    readonly value?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#x ChronicleDashboardChart#x}
    */
    readonly x?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#y ChronicleDashboardChart#y}
    */
    readonly y?: string;
}
export declare function chronicleDashboardChartDashboardChartVisualizationSeriesEncodeToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationSeriesEncodeOutputReference | ChronicleDashboardChartDashboardChartVisualizationSeriesEncode): any;
export declare function chronicleDashboardChartDashboardChartVisualizationSeriesEncodeToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationSeriesEncodeOutputReference | ChronicleDashboardChartDashboardChartVisualizationSeriesEncode): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationSeriesEncodeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationSeriesEncode | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationSeriesEncode | undefined);
    private _itemName?;
    get itemName(): string;
    set itemName(value: string);
    resetItemName(): void;
    get itemNameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _x?;
    get x(): string;
    set x(value: string);
    resetX(): void;
    get xInput(): string | undefined;
    private _y?;
    get y(): string;
    set y(value: string);
    resetY(): void;
    get yInput(): string | undefined;
}
export interface ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigBaseValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#color ChronicleDashboardChart#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#value ChronicleDashboardChart#value}
    */
    readonly value?: number;
}
export declare function chronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigBaseValueToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigBaseValueOutputReference | ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigBaseValue): any;
export declare function chronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigBaseValueToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigBaseValueOutputReference | ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigBaseValue): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigBaseValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigBaseValue | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigBaseValue | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export interface ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigLimitValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#color ChronicleDashboardChart#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#value ChronicleDashboardChart#value}
    */
    readonly value?: number;
}
export declare function chronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigLimitValueToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigLimitValueOutputReference | ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigLimitValue): any;
export declare function chronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigLimitValueToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigLimitValueOutputReference | ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigLimitValue): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigLimitValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigLimitValue | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigLimitValue | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export interface ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigThresholdValues {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#color ChronicleDashboardChart#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#value ChronicleDashboardChart#value}
    */
    readonly value?: number;
}
export declare function chronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigThresholdValuesToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigThresholdValues | cdktn.IResolvable): any;
export declare function chronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigThresholdValuesToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigThresholdValues | cdktn.IResolvable): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigThresholdValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigThresholdValues | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigThresholdValues | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export declare class ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigThresholdValuesList extends cdktn.ComplexList {
    internalValue?: ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigThresholdValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigThresholdValuesOutputReference;
}
export interface ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfig {
    /**
    * base_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#base_value ChronicleDashboardChart#base_value}
    */
    readonly baseValue?: ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigBaseValue;
    /**
    * limit_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#limit_value ChronicleDashboardChart#limit_value}
    */
    readonly limitValue?: ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigLimitValue;
    /**
    * threshold_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#threshold_values ChronicleDashboardChart#threshold_values}
    */
    readonly thresholdValues?: ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigThresholdValues[] | cdktn.IResolvable;
}
export declare function chronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigOutputReference | ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfig): any;
export declare function chronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigOutputReference | ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfig): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfig | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfig | undefined);
    private _baseValue;
    get baseValue(): ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigBaseValueOutputReference;
    putBaseValue(value: ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigBaseValue): void;
    resetBaseValue(): void;
    get baseValueInput(): ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigBaseValue | undefined;
    private _limitValue;
    get limitValue(): ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigLimitValueOutputReference;
    putLimitValue(value: ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigLimitValue): void;
    resetLimitValue(): void;
    get limitValueInput(): ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigLimitValue | undefined;
    private _thresholdValues;
    get thresholdValues(): ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigThresholdValuesList;
    putThresholdValues(value: ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigThresholdValues[] | cdktn.IResolvable): void;
    resetThresholdValues(): void;
    get thresholdValuesInput(): cdktn.IResolvable | ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigThresholdValues[] | undefined;
}
export interface ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColorsValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#color ChronicleDashboardChart#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#label ChronicleDashboardChart#label}
    */
    readonly label?: string;
}
export declare function chronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColorsValueToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColorsValueOutputReference | ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColorsValue): any;
export declare function chronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColorsValueToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColorsValueOutputReference | ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColorsValue): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColorsValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColorsValue | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColorsValue | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
}
export interface ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#key ChronicleDashboardChart#key}
    */
    readonly key?: string;
    /**
    * value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#value ChronicleDashboardChart#value}
    */
    readonly value?: ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColorsValue;
}
export declare function chronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColorsToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColors | cdktn.IResolvable): any;
export declare function chronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColorsToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColors | cdktn.IResolvable): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColors | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColors | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value;
    get value(): ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColorsValueOutputReference;
    putValue(value: ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColorsValue): void;
    resetValue(): void;
    get valueInput(): ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColorsValue | undefined;
}
export declare class ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColorsList extends cdktn.ComplexList {
    internalValue?: ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColorsOutputReference;
}
export interface ChronicleDashboardChartDashboardChartVisualizationSeriesItemColors {
    /**
    * colors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#colors ChronicleDashboardChart#colors}
    */
    readonly colors?: ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColors[] | cdktn.IResolvable;
}
export declare function chronicleDashboardChartDashboardChartVisualizationSeriesItemColorsToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsOutputReference | ChronicleDashboardChartDashboardChartVisualizationSeriesItemColors): any;
export declare function chronicleDashboardChartDashboardChartVisualizationSeriesItemColorsToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsOutputReference | ChronicleDashboardChartDashboardChartVisualizationSeriesItemColors): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationSeriesItemColors | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationSeriesItemColors | undefined);
    private _colors;
    get colors(): ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColorsList;
    putColors(value: ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColors[] | cdktn.IResolvable): void;
    resetColors(): void;
    get colorsInput(): cdktn.IResolvable | ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsColors[] | undefined;
}
export interface ChronicleDashboardChartDashboardChartVisualizationSeriesItemStyle {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#border_color ChronicleDashboardChart#border_color}
    */
    readonly borderColor?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#border_width ChronicleDashboardChart#border_width}
    */
    readonly borderWidth?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#color ChronicleDashboardChart#color}
    */
    readonly color?: string;
}
export declare function chronicleDashboardChartDashboardChartVisualizationSeriesItemStyleToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationSeriesItemStyleOutputReference | ChronicleDashboardChartDashboardChartVisualizationSeriesItemStyle): any;
export declare function chronicleDashboardChartDashboardChartVisualizationSeriesItemStyleToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationSeriesItemStyleOutputReference | ChronicleDashboardChartDashboardChartVisualizationSeriesItemStyle): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationSeriesItemStyleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationSeriesItemStyle | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationSeriesItemStyle | undefined);
    private _borderColor?;
    get borderColor(): string;
    set borderColor(value: string);
    resetBorderColor(): void;
    get borderColorInput(): string | undefined;
    private _borderWidth?;
    get borderWidth(): number;
    set borderWidth(value: number);
    resetBorderWidth(): void;
    get borderWidthInput(): number | undefined;
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
}
export interface ChronicleDashboardChartDashboardChartVisualizationSeriesMetricTrendConfig {
    /**
    *  Possible values: ["METRIC_DISPLAY_TREND_UNSPECIFIED", "METRIC_DISPLAY_TREND_ABSOLUTE_VALUE", "METRIC_DISPLAY_TREND_PERCENTAGE", "METRIC_DISPLAY_TREND_ABSOLUTE_VALUE_AND_PERCENTAGE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#metric_display_trend ChronicleDashboardChart#metric_display_trend}
    */
    readonly metricDisplayTrend?: string;
    /**
    *  Possible values: ["METRIC_FORMAT_UNSPECIFIED", "METRIC_FORMAT_NUMBER", "METRIC_FORMAT_PLAIN_TEXT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#metric_format ChronicleDashboardChart#metric_format}
    */
    readonly metricFormat?: string;
    /**
    *  Possible values: ["METRIC_TREND_TYPE_UNSPECIFIED", "METRIC_TREND_TYPE_REGULAR", "METRIC_TREND_TYPE_INVERSE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#metric_trend_type ChronicleDashboardChart#metric_trend_type}
    */
    readonly metricTrendType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#show_metric_trend ChronicleDashboardChart#show_metric_trend}
    */
    readonly showMetricTrend?: boolean | cdktn.IResolvable;
}
export declare function chronicleDashboardChartDashboardChartVisualizationSeriesMetricTrendConfigToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationSeriesMetricTrendConfigOutputReference | ChronicleDashboardChartDashboardChartVisualizationSeriesMetricTrendConfig): any;
export declare function chronicleDashboardChartDashboardChartVisualizationSeriesMetricTrendConfigToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationSeriesMetricTrendConfigOutputReference | ChronicleDashboardChartDashboardChartVisualizationSeriesMetricTrendConfig): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationSeriesMetricTrendConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationSeriesMetricTrendConfig | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationSeriesMetricTrendConfig | undefined);
    private _metricDisplayTrend?;
    get metricDisplayTrend(): string;
    set metricDisplayTrend(value: string);
    resetMetricDisplayTrend(): void;
    get metricDisplayTrendInput(): string | undefined;
    private _metricFormat?;
    get metricFormat(): string;
    set metricFormat(value: string);
    resetMetricFormat(): void;
    get metricFormatInput(): string | undefined;
    private _metricTrendType?;
    get metricTrendType(): string;
    set metricTrendType(value: string);
    resetMetricTrendType(): void;
    get metricTrendTypeInput(): string | undefined;
    private _showMetricTrend?;
    get showMetricTrend(): boolean | cdktn.IResolvable;
    set showMetricTrend(value: boolean | cdktn.IResolvable);
    resetShowMetricTrend(): void;
    get showMetricTrendInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ChronicleDashboardChartDashboardChartVisualizationSeries {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#field ChronicleDashboardChart#field}
    */
    readonly field?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#label ChronicleDashboardChart#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#radius ChronicleDashboardChart#radius}
    */
    readonly radius?: string[];
    /**
    * User specified series label.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#series_name ChronicleDashboardChart#series_name}
    */
    readonly seriesName?: string;
    /**
    *  Possible values: ["SAMESIGN", "ALL", "POSITIVE", "NEGATIVE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#series_stack_strategy ChronicleDashboardChart#series_stack_strategy}
    */
    readonly seriesStackStrategy?: string;
    /**
    *  Possible values: ["LINE", "BAR", "PIE", "TEXT", "MAP", "GAUGE", "SCATTERPLOT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#series_type ChronicleDashboardChart#series_type}
    */
    readonly seriesType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#series_unique_value ChronicleDashboardChart#series_unique_value}
    */
    readonly seriesUniqueValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#show_background ChronicleDashboardChart#show_background}
    */
    readonly showBackground?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#show_symbol ChronicleDashboardChart#show_symbol}
    */
    readonly showSymbol?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#stack ChronicleDashboardChart#stack}
    */
    readonly stack?: string;
    /**
    * area_style block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#area_style ChronicleDashboardChart#area_style}
    */
    readonly areaStyle?: ChronicleDashboardChartDashboardChartVisualizationSeriesAreaStyle;
    /**
    * data_label block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#data_label ChronicleDashboardChart#data_label}
    */
    readonly dataLabel?: ChronicleDashboardChartDashboardChartVisualizationSeriesDataLabel;
    /**
    * encode block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#encode ChronicleDashboardChart#encode}
    */
    readonly encode?: ChronicleDashboardChartDashboardChartVisualizationSeriesEncode;
    /**
    * gauge_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#gauge_config ChronicleDashboardChart#gauge_config}
    */
    readonly gaugeConfig?: ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfig;
    /**
    * item_colors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#item_colors ChronicleDashboardChart#item_colors}
    */
    readonly itemColors?: ChronicleDashboardChartDashboardChartVisualizationSeriesItemColors;
    /**
    * item_style block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#item_style ChronicleDashboardChart#item_style}
    */
    readonly itemStyle?: ChronicleDashboardChartDashboardChartVisualizationSeriesItemStyle;
    /**
    * metric_trend_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#metric_trend_config ChronicleDashboardChart#metric_trend_config}
    */
    readonly metricTrendConfig?: ChronicleDashboardChartDashboardChartVisualizationSeriesMetricTrendConfig;
}
export declare function chronicleDashboardChartDashboardChartVisualizationSeriesToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationSeries | cdktn.IResolvable): any;
export declare function chronicleDashboardChartDashboardChartVisualizationSeriesToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationSeries | cdktn.IResolvable): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationSeriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationSeries | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationSeries | cdktn.IResolvable | undefined);
    private _field?;
    get field(): string;
    set field(value: string);
    resetField(): void;
    get fieldInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _radius?;
    get radius(): string[];
    set radius(value: string[]);
    resetRadius(): void;
    get radiusInput(): string[] | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
    private _seriesStackStrategy?;
    get seriesStackStrategy(): string;
    set seriesStackStrategy(value: string);
    resetSeriesStackStrategy(): void;
    get seriesStackStrategyInput(): string | undefined;
    private _seriesType?;
    get seriesType(): string;
    set seriesType(value: string);
    resetSeriesType(): void;
    get seriesTypeInput(): string | undefined;
    private _seriesUniqueValue?;
    get seriesUniqueValue(): string;
    set seriesUniqueValue(value: string);
    resetSeriesUniqueValue(): void;
    get seriesUniqueValueInput(): string | undefined;
    private _showBackground?;
    get showBackground(): boolean | cdktn.IResolvable;
    set showBackground(value: boolean | cdktn.IResolvable);
    resetShowBackground(): void;
    get showBackgroundInput(): boolean | cdktn.IResolvable | undefined;
    private _showSymbol?;
    get showSymbol(): boolean | cdktn.IResolvable;
    set showSymbol(value: boolean | cdktn.IResolvable);
    resetShowSymbol(): void;
    get showSymbolInput(): boolean | cdktn.IResolvable | undefined;
    private _stack?;
    get stack(): string;
    set stack(value: string);
    resetStack(): void;
    get stackInput(): string | undefined;
    private _areaStyle;
    get areaStyle(): ChronicleDashboardChartDashboardChartVisualizationSeriesAreaStyleOutputReference;
    putAreaStyle(value: ChronicleDashboardChartDashboardChartVisualizationSeriesAreaStyle): void;
    resetAreaStyle(): void;
    get areaStyleInput(): ChronicleDashboardChartDashboardChartVisualizationSeriesAreaStyle | undefined;
    private _dataLabel;
    get dataLabel(): ChronicleDashboardChartDashboardChartVisualizationSeriesDataLabelOutputReference;
    putDataLabel(value: ChronicleDashboardChartDashboardChartVisualizationSeriesDataLabel): void;
    resetDataLabel(): void;
    get dataLabelInput(): ChronicleDashboardChartDashboardChartVisualizationSeriesDataLabel | undefined;
    private _encode;
    get encode(): ChronicleDashboardChartDashboardChartVisualizationSeriesEncodeOutputReference;
    putEncode(value: ChronicleDashboardChartDashboardChartVisualizationSeriesEncode): void;
    resetEncode(): void;
    get encodeInput(): ChronicleDashboardChartDashboardChartVisualizationSeriesEncode | undefined;
    private _gaugeConfig;
    get gaugeConfig(): ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfigOutputReference;
    putGaugeConfig(value: ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfig): void;
    resetGaugeConfig(): void;
    get gaugeConfigInput(): ChronicleDashboardChartDashboardChartVisualizationSeriesGaugeConfig | undefined;
    private _itemColors;
    get itemColors(): ChronicleDashboardChartDashboardChartVisualizationSeriesItemColorsOutputReference;
    putItemColors(value: ChronicleDashboardChartDashboardChartVisualizationSeriesItemColors): void;
    resetItemColors(): void;
    get itemColorsInput(): ChronicleDashboardChartDashboardChartVisualizationSeriesItemColors | undefined;
    private _itemStyle;
    get itemStyle(): ChronicleDashboardChartDashboardChartVisualizationSeriesItemStyleOutputReference;
    putItemStyle(value: ChronicleDashboardChartDashboardChartVisualizationSeriesItemStyle): void;
    resetItemStyle(): void;
    get itemStyleInput(): ChronicleDashboardChartDashboardChartVisualizationSeriesItemStyle | undefined;
    private _metricTrendConfig;
    get metricTrendConfig(): ChronicleDashboardChartDashboardChartVisualizationSeriesMetricTrendConfigOutputReference;
    putMetricTrendConfig(value: ChronicleDashboardChartDashboardChartVisualizationSeriesMetricTrendConfig): void;
    resetMetricTrendConfig(): void;
    get metricTrendConfigInput(): ChronicleDashboardChartDashboardChartVisualizationSeriesMetricTrendConfig | undefined;
}
export declare class ChronicleDashboardChartDashboardChartVisualizationSeriesList extends cdktn.ComplexList {
    internalValue?: ChronicleDashboardChartDashboardChartVisualizationSeries[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleDashboardChartDashboardChartVisualizationSeriesOutputReference;
}
export interface ChronicleDashboardChartDashboardChartVisualizationTableConfigColumnRenderTypeSettings {
    /**
    *  Possible values: ["RENDER_TYPE_UNSPECIFIED", "RENDER_TYPE_TEXT", "RENDER_TYPE_ICON", "RENDER_TYPE_ICON_AND_TEXT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#column_render_type ChronicleDashboardChart#column_render_type}
    */
    readonly columnRenderType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#field ChronicleDashboardChart#field}
    */
    readonly field?: string;
}
export declare function chronicleDashboardChartDashboardChartVisualizationTableConfigColumnRenderTypeSettingsToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationTableConfigColumnRenderTypeSettings | cdktn.IResolvable): any;
export declare function chronicleDashboardChartDashboardChartVisualizationTableConfigColumnRenderTypeSettingsToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationTableConfigColumnRenderTypeSettings | cdktn.IResolvable): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationTableConfigColumnRenderTypeSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationTableConfigColumnRenderTypeSettings | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationTableConfigColumnRenderTypeSettings | cdktn.IResolvable | undefined);
    private _columnRenderType?;
    get columnRenderType(): string;
    set columnRenderType(value: string);
    resetColumnRenderType(): void;
    get columnRenderTypeInput(): string | undefined;
    private _field?;
    get field(): string;
    set field(value: string);
    resetField(): void;
    get fieldInput(): string | undefined;
}
export declare class ChronicleDashboardChartDashboardChartVisualizationTableConfigColumnRenderTypeSettingsList extends cdktn.ComplexList {
    internalValue?: ChronicleDashboardChartDashboardChartVisualizationTableConfigColumnRenderTypeSettings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleDashboardChartDashboardChartVisualizationTableConfigColumnRenderTypeSettingsOutputReference;
}
export interface ChronicleDashboardChartDashboardChartVisualizationTableConfigColumnTooltipSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#cell_tooltip_text ChronicleDashboardChart#cell_tooltip_text}
    */
    readonly cellTooltipText?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#field ChronicleDashboardChart#field}
    */
    readonly field: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#header_tooltip_text ChronicleDashboardChart#header_tooltip_text}
    */
    readonly headerTooltipText?: string;
}
export declare function chronicleDashboardChartDashboardChartVisualizationTableConfigColumnTooltipSettingsToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationTableConfigColumnTooltipSettings | cdktn.IResolvable): any;
export declare function chronicleDashboardChartDashboardChartVisualizationTableConfigColumnTooltipSettingsToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationTableConfigColumnTooltipSettings | cdktn.IResolvable): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationTableConfigColumnTooltipSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationTableConfigColumnTooltipSettings | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationTableConfigColumnTooltipSettings | cdktn.IResolvable | undefined);
    private _cellTooltipText?;
    get cellTooltipText(): string;
    set cellTooltipText(value: string);
    resetCellTooltipText(): void;
    get cellTooltipTextInput(): string | undefined;
    private _field?;
    get field(): string;
    set field(value: string);
    get fieldInput(): string | undefined;
    private _headerTooltipText?;
    get headerTooltipText(): string;
    set headerTooltipText(value: string);
    resetHeaderTooltipText(): void;
    get headerTooltipTextInput(): string | undefined;
}
export declare class ChronicleDashboardChartDashboardChartVisualizationTableConfigColumnTooltipSettingsList extends cdktn.ComplexList {
    internalValue?: ChronicleDashboardChartDashboardChartVisualizationTableConfigColumnTooltipSettings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleDashboardChartDashboardChartVisualizationTableConfigColumnTooltipSettingsOutputReference;
}
export interface ChronicleDashboardChartDashboardChartVisualizationTableConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#enable_text_wrap ChronicleDashboardChart#enable_text_wrap}
    */
    readonly enableTextWrap?: boolean | cdktn.IResolvable;
    /**
    * column_render_type_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#column_render_type_settings ChronicleDashboardChart#column_render_type_settings}
    */
    readonly columnRenderTypeSettings?: ChronicleDashboardChartDashboardChartVisualizationTableConfigColumnRenderTypeSettings[] | cdktn.IResolvable;
    /**
    * column_tooltip_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#column_tooltip_settings ChronicleDashboardChart#column_tooltip_settings}
    */
    readonly columnTooltipSettings?: ChronicleDashboardChartDashboardChartVisualizationTableConfigColumnTooltipSettings[] | cdktn.IResolvable;
}
export declare function chronicleDashboardChartDashboardChartVisualizationTableConfigToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationTableConfigOutputReference | ChronicleDashboardChartDashboardChartVisualizationTableConfig): any;
export declare function chronicleDashboardChartDashboardChartVisualizationTableConfigToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationTableConfigOutputReference | ChronicleDashboardChartDashboardChartVisualizationTableConfig): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationTableConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationTableConfig | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationTableConfig | undefined);
    private _enableTextWrap?;
    get enableTextWrap(): boolean | cdktn.IResolvable;
    set enableTextWrap(value: boolean | cdktn.IResolvable);
    resetEnableTextWrap(): void;
    get enableTextWrapInput(): boolean | cdktn.IResolvable | undefined;
    private _columnRenderTypeSettings;
    get columnRenderTypeSettings(): ChronicleDashboardChartDashboardChartVisualizationTableConfigColumnRenderTypeSettingsList;
    putColumnRenderTypeSettings(value: ChronicleDashboardChartDashboardChartVisualizationTableConfigColumnRenderTypeSettings[] | cdktn.IResolvable): void;
    resetColumnRenderTypeSettings(): void;
    get columnRenderTypeSettingsInput(): cdktn.IResolvable | ChronicleDashboardChartDashboardChartVisualizationTableConfigColumnRenderTypeSettings[] | undefined;
    private _columnTooltipSettings;
    get columnTooltipSettings(): ChronicleDashboardChartDashboardChartVisualizationTableConfigColumnTooltipSettingsList;
    putColumnTooltipSettings(value: ChronicleDashboardChartDashboardChartVisualizationTableConfigColumnTooltipSettings[] | cdktn.IResolvable): void;
    resetColumnTooltipSettings(): void;
    get columnTooltipSettingsInput(): cdktn.IResolvable | ChronicleDashboardChartDashboardChartVisualizationTableConfigColumnTooltipSettings[] | undefined;
}
export interface ChronicleDashboardChartDashboardChartVisualizationTooltip {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#show ChronicleDashboardChart#show}
    */
    readonly show?: boolean | cdktn.IResolvable;
    /**
    *  Possible values: ["TOOLTIP_TRIGGER_UNSPECIFIED", "TOOLTIP_TRIGGER_NONE", "TOOLTIP_TRIGGER_ITEM", "TOOLTIP_TRIGGER_AXIS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#tooltip_trigger ChronicleDashboardChart#tooltip_trigger}
    */
    readonly tooltipTrigger?: string;
}
export declare function chronicleDashboardChartDashboardChartVisualizationTooltipToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationTooltipOutputReference | ChronicleDashboardChartDashboardChartVisualizationTooltip): any;
export declare function chronicleDashboardChartDashboardChartVisualizationTooltipToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationTooltipOutputReference | ChronicleDashboardChartDashboardChartVisualizationTooltip): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationTooltipOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationTooltip | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationTooltip | undefined);
    private _show?;
    get show(): boolean | cdktn.IResolvable;
    set show(value: boolean | cdktn.IResolvable);
    resetShow(): void;
    get showInput(): boolean | cdktn.IResolvable | undefined;
    private _tooltipTrigger?;
    get tooltipTrigger(): string;
    set tooltipTrigger(value: string);
    resetTooltipTrigger(): void;
    get tooltipTriggerInput(): string | undefined;
}
export interface ChronicleDashboardChartDashboardChartVisualizationVisualMapsPieces {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#color ChronicleDashboardChart#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#label ChronicleDashboardChart#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#max ChronicleDashboardChart#max}
    */
    readonly max?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#min ChronicleDashboardChart#min}
    */
    readonly min?: number;
}
export declare function chronicleDashboardChartDashboardChartVisualizationVisualMapsPiecesToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationVisualMapsPieces | cdktn.IResolvable): any;
export declare function chronicleDashboardChartDashboardChartVisualizationVisualMapsPiecesToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationVisualMapsPieces | cdktn.IResolvable): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationVisualMapsPiecesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationVisualMapsPieces | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationVisualMapsPieces | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _max?;
    get max(): number;
    set max(value: number);
    resetMax(): void;
    get maxInput(): number | undefined;
    private _min?;
    get min(): number;
    set min(value: number);
    resetMin(): void;
    get minInput(): number | undefined;
}
export declare class ChronicleDashboardChartDashboardChartVisualizationVisualMapsPiecesList extends cdktn.ComplexList {
    internalValue?: ChronicleDashboardChartDashboardChartVisualizationVisualMapsPieces[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleDashboardChartDashboardChartVisualizationVisualMapsPiecesOutputReference;
}
export interface ChronicleDashboardChartDashboardChartVisualizationVisualMaps {
    /**
    *  Possible values: ["VISUAL_MAP_TYPE_UNSPECIFIED", "CONTINUOUS", "PIECEWISE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#visual_map_type ChronicleDashboardChart#visual_map_type}
    */
    readonly visualMapType?: string;
    /**
    * pieces block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#pieces ChronicleDashboardChart#pieces}
    */
    readonly pieces?: ChronicleDashboardChartDashboardChartVisualizationVisualMapsPieces[] | cdktn.IResolvable;
}
export declare function chronicleDashboardChartDashboardChartVisualizationVisualMapsToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationVisualMaps | cdktn.IResolvable): any;
export declare function chronicleDashboardChartDashboardChartVisualizationVisualMapsToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationVisualMaps | cdktn.IResolvable): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationVisualMapsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationVisualMaps | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationVisualMaps | cdktn.IResolvable | undefined);
    private _visualMapType?;
    get visualMapType(): string;
    set visualMapType(value: string);
    resetVisualMapType(): void;
    get visualMapTypeInput(): string | undefined;
    private _pieces;
    get pieces(): ChronicleDashboardChartDashboardChartVisualizationVisualMapsPiecesList;
    putPieces(value: ChronicleDashboardChartDashboardChartVisualizationVisualMapsPieces[] | cdktn.IResolvable): void;
    resetPieces(): void;
    get piecesInput(): cdktn.IResolvable | ChronicleDashboardChartDashboardChartVisualizationVisualMapsPieces[] | undefined;
}
export declare class ChronicleDashboardChartDashboardChartVisualizationVisualMapsList extends cdktn.ComplexList {
    internalValue?: ChronicleDashboardChartDashboardChartVisualizationVisualMaps[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleDashboardChartDashboardChartVisualizationVisualMapsOutputReference;
}
export interface ChronicleDashboardChartDashboardChartVisualizationXAxes {
    /**
    *  Possible values: ["VALUE", "CATEGORY", "TIME", "LOG"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#axis_type ChronicleDashboardChart#axis_type}
    */
    readonly axisType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#display_name ChronicleDashboardChart#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#max ChronicleDashboardChart#max}
    */
    readonly max?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#min ChronicleDashboardChart#min}
    */
    readonly min?: number;
}
export declare function chronicleDashboardChartDashboardChartVisualizationXAxesToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationXAxes | cdktn.IResolvable): any;
export declare function chronicleDashboardChartDashboardChartVisualizationXAxesToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationXAxes | cdktn.IResolvable): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationXAxesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationXAxes | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationXAxes | cdktn.IResolvable | undefined);
    private _axisType?;
    get axisType(): string;
    set axisType(value: string);
    resetAxisType(): void;
    get axisTypeInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _max?;
    get max(): number;
    set max(value: number);
    resetMax(): void;
    get maxInput(): number | undefined;
    private _min?;
    get min(): number;
    set min(value: number);
    resetMin(): void;
    get minInput(): number | undefined;
}
export declare class ChronicleDashboardChartDashboardChartVisualizationXAxesList extends cdktn.ComplexList {
    internalValue?: ChronicleDashboardChartDashboardChartVisualizationXAxes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleDashboardChartDashboardChartVisualizationXAxesOutputReference;
}
export interface ChronicleDashboardChartDashboardChartVisualizationYAxes {
    /**
    *  Possible values: ["VALUE", "CATEGORY", "TIME", "LOG"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#axis_type ChronicleDashboardChart#axis_type}
    */
    readonly axisType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#display_name ChronicleDashboardChart#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#max ChronicleDashboardChart#max}
    */
    readonly max?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#min ChronicleDashboardChart#min}
    */
    readonly min?: number;
}
export declare function chronicleDashboardChartDashboardChartVisualizationYAxesToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationYAxes | cdktn.IResolvable): any;
export declare function chronicleDashboardChartDashboardChartVisualizationYAxesToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationYAxes | cdktn.IResolvable): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationYAxesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualizationYAxes | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualizationYAxes | cdktn.IResolvable | undefined);
    private _axisType?;
    get axisType(): string;
    set axisType(value: string);
    resetAxisType(): void;
    get axisTypeInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _max?;
    get max(): number;
    set max(value: number);
    resetMax(): void;
    get maxInput(): number | undefined;
    private _min?;
    get min(): number;
    set min(value: number);
    resetMin(): void;
    get minInput(): number | undefined;
}
export declare class ChronicleDashboardChartDashboardChartVisualizationYAxesList extends cdktn.ComplexList {
    internalValue?: ChronicleDashboardChartDashboardChartVisualizationYAxes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleDashboardChartDashboardChartVisualizationYAxesOutputReference;
}
export interface ChronicleDashboardChartDashboardChartVisualization {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#grouping_type ChronicleDashboardChart#grouping_type}
    */
    readonly groupingType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#series_column ChronicleDashboardChart#series_column}
    */
    readonly seriesColumn?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#threshold_coloring_enabled ChronicleDashboardChart#threshold_coloring_enabled}
    */
    readonly thresholdColoringEnabled?: boolean | cdktn.IResolvable;
    /**
    * button block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#button ChronicleDashboardChart#button}
    */
    readonly button?: ChronicleDashboardChartDashboardChartVisualizationButton;
    /**
    * column_defs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#column_defs ChronicleDashboardChart#column_defs}
    */
    readonly columnDefs?: ChronicleDashboardChartDashboardChartVisualizationColumnDefs[] | cdktn.IResolvable;
    /**
    * google_maps_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#google_maps_config ChronicleDashboardChart#google_maps_config}
    */
    readonly googleMapsConfig?: ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfig;
    /**
    * legends block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#legends ChronicleDashboardChart#legends}
    */
    readonly legends?: ChronicleDashboardChartDashboardChartVisualizationLegends[] | cdktn.IResolvable;
    /**
    * markdown block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#markdown ChronicleDashboardChart#markdown}
    */
    readonly markdown?: ChronicleDashboardChartDashboardChartVisualizationMarkdown;
    /**
    * series block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#series ChronicleDashboardChart#series}
    */
    readonly series?: ChronicleDashboardChartDashboardChartVisualizationSeries[] | cdktn.IResolvable;
    /**
    * table_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#table_config ChronicleDashboardChart#table_config}
    */
    readonly tableConfig?: ChronicleDashboardChartDashboardChartVisualizationTableConfig;
    /**
    * tooltip block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#tooltip ChronicleDashboardChart#tooltip}
    */
    readonly tooltip?: ChronicleDashboardChartDashboardChartVisualizationTooltip;
    /**
    * visual_maps block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#visual_maps ChronicleDashboardChart#visual_maps}
    */
    readonly visualMaps?: ChronicleDashboardChartDashboardChartVisualizationVisualMaps[] | cdktn.IResolvable;
    /**
    * x_axes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#x_axes ChronicleDashboardChart#x_axes}
    */
    readonly xAxes?: ChronicleDashboardChartDashboardChartVisualizationXAxes[] | cdktn.IResolvable;
    /**
    * y_axes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#y_axes ChronicleDashboardChart#y_axes}
    */
    readonly yAxes?: ChronicleDashboardChartDashboardChartVisualizationYAxes[] | cdktn.IResolvable;
}
export declare function chronicleDashboardChartDashboardChartVisualizationToTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationOutputReference | ChronicleDashboardChartDashboardChartVisualization): any;
export declare function chronicleDashboardChartDashboardChartVisualizationToHclTerraform(struct?: ChronicleDashboardChartDashboardChartVisualizationOutputReference | ChronicleDashboardChartDashboardChartVisualization): any;
export declare class ChronicleDashboardChartDashboardChartVisualizationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChartVisualization | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChartVisualization | undefined);
    private _groupingType?;
    get groupingType(): string;
    set groupingType(value: string);
    resetGroupingType(): void;
    get groupingTypeInput(): string | undefined;
    private _seriesColumn?;
    get seriesColumn(): string[];
    set seriesColumn(value: string[]);
    resetSeriesColumn(): void;
    get seriesColumnInput(): string[] | undefined;
    private _thresholdColoringEnabled?;
    get thresholdColoringEnabled(): boolean | cdktn.IResolvable;
    set thresholdColoringEnabled(value: boolean | cdktn.IResolvable);
    resetThresholdColoringEnabled(): void;
    get thresholdColoringEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _button;
    get button(): ChronicleDashboardChartDashboardChartVisualizationButtonOutputReference;
    putButton(value: ChronicleDashboardChartDashboardChartVisualizationButton): void;
    resetButton(): void;
    get buttonInput(): ChronicleDashboardChartDashboardChartVisualizationButton | undefined;
    private _columnDefs;
    get columnDefs(): ChronicleDashboardChartDashboardChartVisualizationColumnDefsList;
    putColumnDefs(value: ChronicleDashboardChartDashboardChartVisualizationColumnDefs[] | cdktn.IResolvable): void;
    resetColumnDefs(): void;
    get columnDefsInput(): cdktn.IResolvable | ChronicleDashboardChartDashboardChartVisualizationColumnDefs[] | undefined;
    private _googleMapsConfig;
    get googleMapsConfig(): ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfigOutputReference;
    putGoogleMapsConfig(value: ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfig): void;
    resetGoogleMapsConfig(): void;
    get googleMapsConfigInput(): ChronicleDashboardChartDashboardChartVisualizationGoogleMapsConfig | undefined;
    private _legends;
    get legends(): ChronicleDashboardChartDashboardChartVisualizationLegendsList;
    putLegends(value: ChronicleDashboardChartDashboardChartVisualizationLegends[] | cdktn.IResolvable): void;
    resetLegends(): void;
    get legendsInput(): cdktn.IResolvable | ChronicleDashboardChartDashboardChartVisualizationLegends[] | undefined;
    private _markdown;
    get markdown(): ChronicleDashboardChartDashboardChartVisualizationMarkdownOutputReference;
    putMarkdown(value: ChronicleDashboardChartDashboardChartVisualizationMarkdown): void;
    resetMarkdown(): void;
    get markdownInput(): ChronicleDashboardChartDashboardChartVisualizationMarkdown | undefined;
    private _series;
    get series(): ChronicleDashboardChartDashboardChartVisualizationSeriesList;
    putSeries(value: ChronicleDashboardChartDashboardChartVisualizationSeries[] | cdktn.IResolvable): void;
    resetSeries(): void;
    get seriesInput(): cdktn.IResolvable | ChronicleDashboardChartDashboardChartVisualizationSeries[] | undefined;
    private _tableConfig;
    get tableConfig(): ChronicleDashboardChartDashboardChartVisualizationTableConfigOutputReference;
    putTableConfig(value: ChronicleDashboardChartDashboardChartVisualizationTableConfig): void;
    resetTableConfig(): void;
    get tableConfigInput(): ChronicleDashboardChartDashboardChartVisualizationTableConfig | undefined;
    private _tooltip;
    get tooltip(): ChronicleDashboardChartDashboardChartVisualizationTooltipOutputReference;
    putTooltip(value: ChronicleDashboardChartDashboardChartVisualizationTooltip): void;
    resetTooltip(): void;
    get tooltipInput(): ChronicleDashboardChartDashboardChartVisualizationTooltip | undefined;
    private _visualMaps;
    get visualMaps(): ChronicleDashboardChartDashboardChartVisualizationVisualMapsList;
    putVisualMaps(value: ChronicleDashboardChartDashboardChartVisualizationVisualMaps[] | cdktn.IResolvable): void;
    resetVisualMaps(): void;
    get visualMapsInput(): cdktn.IResolvable | ChronicleDashboardChartDashboardChartVisualizationVisualMaps[] | undefined;
    private _xAxes;
    get xAxes(): ChronicleDashboardChartDashboardChartVisualizationXAxesList;
    putXAxes(value: ChronicleDashboardChartDashboardChartVisualizationXAxes[] | cdktn.IResolvable): void;
    resetXAxes(): void;
    get xAxesInput(): cdktn.IResolvable | ChronicleDashboardChartDashboardChartVisualizationXAxes[] | undefined;
    private _yAxes;
    get yAxes(): ChronicleDashboardChartDashboardChartVisualizationYAxesList;
    putYAxes(value: ChronicleDashboardChartDashboardChartVisualizationYAxes[] | cdktn.IResolvable): void;
    resetYAxes(): void;
    get yAxesInput(): cdktn.IResolvable | ChronicleDashboardChartDashboardChartVisualizationYAxes[] | undefined;
}
export interface ChronicleDashboardChartDashboardChart {
    /**
    * Description of the dashboardChart.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#description ChronicleDashboardChart#description}
    */
    readonly description?: string;
    /**
    * Display name/Title of the dashboardChart visible to users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#display_name ChronicleDashboardChart#display_name}
    */
    readonly displayName: string;
    /**
    * Type of tile (e.g., visualization, button, markdown). Possible values: ["TILE_TYPE_UNSPECIFIED", "TILE_TYPE_VISUALIZATION", "TILE_TYPE_BUTTON", "TILE_TYPE_MARKDOWN"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#tile_type ChronicleDashboardChart#tile_type}
    */
    readonly tileType?: string;
    /**
    * chart_datasource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#chart_datasource ChronicleDashboardChart#chart_datasource}
    */
    readonly chartDatasource?: ChronicleDashboardChartDashboardChartChartDatasource;
    /**
    * drill_down_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#drill_down_config ChronicleDashboardChart#drill_down_config}
    */
    readonly drillDownConfig?: ChronicleDashboardChartDashboardChartDrillDownConfig;
    /**
    * visualization block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#visualization ChronicleDashboardChart#visualization}
    */
    readonly visualization: ChronicleDashboardChartDashboardChartVisualization;
}
export declare function chronicleDashboardChartDashboardChartToTerraform(struct?: ChronicleDashboardChartDashboardChartOutputReference | ChronicleDashboardChartDashboardChart): any;
export declare function chronicleDashboardChartDashboardChartToHclTerraform(struct?: ChronicleDashboardChartDashboardChartOutputReference | ChronicleDashboardChartDashboardChart): any;
export declare class ChronicleDashboardChartDashboardChartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardChart | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardChart | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get etag(): string;
    get name(): string;
    private _tileType?;
    get tileType(): string;
    set tileType(value: string);
    resetTileType(): void;
    get tileTypeInput(): string | undefined;
    private _chartDatasource;
    get chartDatasource(): ChronicleDashboardChartDashboardChartChartDatasourceOutputReference;
    putChartDatasource(value: ChronicleDashboardChartDashboardChartChartDatasource): void;
    resetChartDatasource(): void;
    get chartDatasourceInput(): ChronicleDashboardChartDashboardChartChartDatasource | undefined;
    private _drillDownConfig;
    get drillDownConfig(): ChronicleDashboardChartDashboardChartDrillDownConfigOutputReference;
    putDrillDownConfig(value: ChronicleDashboardChartDashboardChartDrillDownConfig): void;
    resetDrillDownConfig(): void;
    get drillDownConfigInput(): ChronicleDashboardChartDashboardChartDrillDownConfig | undefined;
    private _visualization;
    get visualization(): ChronicleDashboardChartDashboardChartVisualizationOutputReference;
    putVisualization(value: ChronicleDashboardChartDashboardChartVisualization): void;
    get visualizationInput(): ChronicleDashboardChartDashboardChartVisualization | undefined;
}
export interface ChronicleDashboardChartDashboardQueryInputRelativeTime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#start_time_val ChronicleDashboardChart#start_time_val}
    */
    readonly startTimeVal: string;
    /**
    * The time unit for the relative range. Possible values: ["SECOND", "MINUTE", "HOUR", "DAY", "WEEK", "MONTH", "YEAR"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#time_unit ChronicleDashboardChart#time_unit}
    */
    readonly timeUnit: string;
}
export declare function chronicleDashboardChartDashboardQueryInputRelativeTimeToTerraform(struct?: ChronicleDashboardChartDashboardQueryInputRelativeTimeOutputReference | ChronicleDashboardChartDashboardQueryInputRelativeTime): any;
export declare function chronicleDashboardChartDashboardQueryInputRelativeTimeToHclTerraform(struct?: ChronicleDashboardChartDashboardQueryInputRelativeTimeOutputReference | ChronicleDashboardChartDashboardQueryInputRelativeTime): any;
export declare class ChronicleDashboardChartDashboardQueryInputRelativeTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardQueryInputRelativeTime | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardQueryInputRelativeTime | undefined);
    private _startTimeVal?;
    get startTimeVal(): string;
    set startTimeVal(value: string);
    get startTimeValInput(): string | undefined;
    private _timeUnit?;
    get timeUnit(): string;
    set timeUnit(value: string);
    get timeUnitInput(): string | undefined;
}
export interface ChronicleDashboardChartDashboardQueryInputTimeWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#end_time ChronicleDashboardChart#end_time}
    */
    readonly endTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#start_time ChronicleDashboardChart#start_time}
    */
    readonly startTime?: string;
}
export declare function chronicleDashboardChartDashboardQueryInputTimeWindowToTerraform(struct?: ChronicleDashboardChartDashboardQueryInputTimeWindowOutputReference | ChronicleDashboardChartDashboardQueryInputTimeWindow): any;
export declare function chronicleDashboardChartDashboardQueryInputTimeWindowToHclTerraform(struct?: ChronicleDashboardChartDashboardQueryInputTimeWindowOutputReference | ChronicleDashboardChartDashboardQueryInputTimeWindow): any;
export declare class ChronicleDashboardChartDashboardQueryInputTimeWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardQueryInputTimeWindow | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardQueryInputTimeWindow | undefined);
    private _endTime?;
    get endTime(): string;
    set endTime(value: string);
    resetEndTime(): void;
    get endTimeInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    resetStartTime(): void;
    get startTimeInput(): string | undefined;
}
export interface ChronicleDashboardChartDashboardQueryInput {
    /**
    * relative_time block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#relative_time ChronicleDashboardChart#relative_time}
    */
    readonly relativeTime?: ChronicleDashboardChartDashboardQueryInputRelativeTime;
    /**
    * time_window block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#time_window ChronicleDashboardChart#time_window}
    */
    readonly timeWindow?: ChronicleDashboardChartDashboardQueryInputTimeWindow;
}
export declare function chronicleDashboardChartDashboardQueryInputToTerraform(struct?: ChronicleDashboardChartDashboardQueryInputOutputReference | ChronicleDashboardChartDashboardQueryInput): any;
export declare function chronicleDashboardChartDashboardQueryInputToHclTerraform(struct?: ChronicleDashboardChartDashboardQueryInputOutputReference | ChronicleDashboardChartDashboardQueryInput): any;
export declare class ChronicleDashboardChartDashboardQueryInputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardQueryInput | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardQueryInput | undefined);
    private _relativeTime;
    get relativeTime(): ChronicleDashboardChartDashboardQueryInputRelativeTimeOutputReference;
    putRelativeTime(value: ChronicleDashboardChartDashboardQueryInputRelativeTime): void;
    resetRelativeTime(): void;
    get relativeTimeInput(): ChronicleDashboardChartDashboardQueryInputRelativeTime | undefined;
    private _timeWindow;
    get timeWindow(): ChronicleDashboardChartDashboardQueryInputTimeWindowOutputReference;
    putTimeWindow(value: ChronicleDashboardChartDashboardQueryInputTimeWindow): void;
    resetTimeWindow(): void;
    get timeWindowInput(): ChronicleDashboardChartDashboardQueryInputTimeWindow | undefined;
}
export interface ChronicleDashboardChartDashboardQuery {
    /**
    * The raw query string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#query ChronicleDashboardChart#query}
    */
    readonly query: string;
    /**
    * input block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#input ChronicleDashboardChart#input}
    */
    readonly input?: ChronicleDashboardChartDashboardQueryInput;
}
export declare function chronicleDashboardChartDashboardQueryToTerraform(struct?: ChronicleDashboardChartDashboardQueryOutputReference | ChronicleDashboardChartDashboardQuery): any;
export declare function chronicleDashboardChartDashboardQueryToHclTerraform(struct?: ChronicleDashboardChartDashboardQueryOutputReference | ChronicleDashboardChartDashboardQuery): any;
export declare class ChronicleDashboardChartDashboardQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartDashboardQuery | undefined;
    set internalValue(value: ChronicleDashboardChartDashboardQuery | undefined);
    get etag(): string;
    get name(): string;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _input;
    get input(): ChronicleDashboardChartDashboardQueryInputOutputReference;
    putInput(value: ChronicleDashboardChartDashboardQueryInput): void;
    resetInput(): void;
    get inputInput(): ChronicleDashboardChartDashboardQueryInput | undefined;
}
export interface ChronicleDashboardChartTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#create ChronicleDashboardChart#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#delete ChronicleDashboardChart#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#update ChronicleDashboardChart#update}
    */
    readonly update?: string;
}
export declare function chronicleDashboardChartTimeoutsToTerraform(struct?: ChronicleDashboardChartTimeouts | cdktn.IResolvable): any;
export declare function chronicleDashboardChartTimeoutsToHclTerraform(struct?: ChronicleDashboardChartTimeouts | cdktn.IResolvable): any;
export declare class ChronicleDashboardChartTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDashboardChartTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleDashboardChartTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart google_chronicle_dashboard_chart}
*/
export declare class ChronicleDashboardChart extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_chronicle_dashboard_chart";
    /**
    * Generates CDKTN code for importing a ChronicleDashboardChart resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChronicleDashboardChart to import
    * @param importFromId The id of the existing ChronicleDashboardChart that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChronicleDashboardChart to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_dashboard_chart google_chronicle_dashboard_chart} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChronicleDashboardChartConfig
    */
    constructor(scope: Construct, id: string, config: ChronicleDashboardChartConfig);
    get chartId(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instance?;
    get instance(): string;
    set instance(value: string);
    get instanceInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _nativeDashboard?;
    get nativeDashboard(): string;
    set nativeDashboard(value: string);
    resetNativeDashboard(): void;
    get nativeDashboardInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _chartLayout;
    get chartLayout(): ChronicleDashboardChartChartLayoutOutputReference;
    putChartLayout(value: ChronicleDashboardChartChartLayout): void;
    resetChartLayout(): void;
    get chartLayoutInput(): ChronicleDashboardChartChartLayout | undefined;
    private _dashboardChart;
    get dashboardChart(): ChronicleDashboardChartDashboardChartOutputReference;
    putDashboardChart(value: ChronicleDashboardChartDashboardChart): void;
    get dashboardChartInput(): ChronicleDashboardChartDashboardChart | undefined;
    private _dashboardQuery;
    get dashboardQuery(): ChronicleDashboardChartDashboardQueryOutputReference;
    putDashboardQuery(value: ChronicleDashboardChartDashboardQuery): void;
    resetDashboardQuery(): void;
    get dashboardQueryInput(): ChronicleDashboardChartDashboardQuery | undefined;
    private _timeouts;
    get timeouts(): ChronicleDashboardChartTimeoutsOutputReference;
    putTimeouts(value: ChronicleDashboardChartTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ChronicleDashboardChartTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
