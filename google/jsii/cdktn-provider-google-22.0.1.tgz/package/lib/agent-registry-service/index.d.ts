/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AgentRegistryServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_service#deletion_policy AgentRegistryService#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The description of the Service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_service#description AgentRegistryService#description}
    */
    readonly description?: string;
    /**
    * User-defined display name for the Service. Can have a maximum length of 63 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_service#display_name AgentRegistryService#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_service#id AgentRegistryService#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_service#location AgentRegistryService#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_service#project AgentRegistryService#project}
    */
    readonly project?: string;
    /**
    * The name of the Service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_service#service_id AgentRegistryService#service_id}
    */
    readonly serviceId: string;
    /**
    * agent_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_service#agent_spec AgentRegistryService#agent_spec}
    */
    readonly agentSpec?: AgentRegistryServiceAgentSpec;
    /**
    * endpoint_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_service#endpoint_spec AgentRegistryService#endpoint_spec}
    */
    readonly endpointSpec?: AgentRegistryServiceEndpointSpec;
    /**
    * interfaces block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_service#interfaces AgentRegistryService#interfaces}
    */
    readonly interfaces?: AgentRegistryServiceInterfaces[] | cdktn.IResolvable;
    /**
    * mcp_server_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_service#mcp_server_spec AgentRegistryService#mcp_server_spec}
    */
    readonly mcpServerSpec?: AgentRegistryServiceMcpServerSpec;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_service#timeouts AgentRegistryService#timeouts}
    */
    readonly timeouts?: AgentRegistryServiceTimeouts;
}
export interface AgentRegistryServiceAgentSpec {
    /**
    * The content of the Agent spec in the JSON format. This payload is validated against the schema for the specified type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_service#content AgentRegistryService#content}
    */
    readonly content?: string;
    /**
    * The type of the Agent spec content. Possible values: ["NO_SPEC", "A2A_AGENT_CARD"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_service#type AgentRegistryService#type}
    */
    readonly type: string;
}
export declare function agentRegistryServiceAgentSpecToTerraform(struct?: AgentRegistryServiceAgentSpecOutputReference | AgentRegistryServiceAgentSpec): any;
export declare function agentRegistryServiceAgentSpecToHclTerraform(struct?: AgentRegistryServiceAgentSpecOutputReference | AgentRegistryServiceAgentSpec): any;
export declare class AgentRegistryServiceAgentSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentRegistryServiceAgentSpec | undefined;
    set internalValue(value: AgentRegistryServiceAgentSpec | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    resetContent(): void;
    get contentInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface AgentRegistryServiceEndpointSpec {
    /**
    * The type of the Endpoint spec content. Possible values: ["NO_SPEC"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_service#type AgentRegistryService#type}
    */
    readonly type: string;
}
export declare function agentRegistryServiceEndpointSpecToTerraform(struct?: AgentRegistryServiceEndpointSpecOutputReference | AgentRegistryServiceEndpointSpec): any;
export declare function agentRegistryServiceEndpointSpecToHclTerraform(struct?: AgentRegistryServiceEndpointSpecOutputReference | AgentRegistryServiceEndpointSpec): any;
export declare class AgentRegistryServiceEndpointSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentRegistryServiceEndpointSpec | undefined;
    set internalValue(value: AgentRegistryServiceEndpointSpec | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface AgentRegistryServiceInterfaces {
    /**
    * The protocol binding of the interface. Possible values: ["JSONRPC", "GRPC", "HTTP_JSON"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_service#protocol_binding AgentRegistryService#protocol_binding}
    */
    readonly protocolBinding: string;
    /**
    * The destination URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_service#url AgentRegistryService#url}
    */
    readonly url: string;
}
export declare function agentRegistryServiceInterfacesToTerraform(struct?: AgentRegistryServiceInterfaces | cdktn.IResolvable): any;
export declare function agentRegistryServiceInterfacesToHclTerraform(struct?: AgentRegistryServiceInterfaces | cdktn.IResolvable): any;
export declare class AgentRegistryServiceInterfacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AgentRegistryServiceInterfaces | cdktn.IResolvable | undefined;
    set internalValue(value: AgentRegistryServiceInterfaces | cdktn.IResolvable | undefined);
    private _protocolBinding?;
    get protocolBinding(): string;
    set protocolBinding(value: string);
    get protocolBindingInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export declare class AgentRegistryServiceInterfacesList extends cdktn.ComplexList {
    internalValue?: AgentRegistryServiceInterfaces[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AgentRegistryServiceInterfacesOutputReference;
}
export interface AgentRegistryServiceMcpServerSpec {
    /**
    * The content of the MCP Server spec. This payload is validated against the schema for the specified type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_service#content AgentRegistryService#content}
    */
    readonly content?: string;
    /**
    * The type of the MCP Server spec content. Possible values: ["NO_SPEC", "TOOL_SPEC"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_service#type AgentRegistryService#type}
    */
    readonly type: string;
}
export declare function agentRegistryServiceMcpServerSpecToTerraform(struct?: AgentRegistryServiceMcpServerSpecOutputReference | AgentRegistryServiceMcpServerSpec): any;
export declare function agentRegistryServiceMcpServerSpecToHclTerraform(struct?: AgentRegistryServiceMcpServerSpecOutputReference | AgentRegistryServiceMcpServerSpec): any;
export declare class AgentRegistryServiceMcpServerSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentRegistryServiceMcpServerSpec | undefined;
    set internalValue(value: AgentRegistryServiceMcpServerSpec | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    resetContent(): void;
    get contentInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface AgentRegistryServiceTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_service#create AgentRegistryService#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_service#delete AgentRegistryService#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_service#update AgentRegistryService#update}
    */
    readonly update?: string;
}
export declare function agentRegistryServiceTimeoutsToTerraform(struct?: AgentRegistryServiceTimeouts | cdktn.IResolvable): any;
export declare function agentRegistryServiceTimeoutsToHclTerraform(struct?: AgentRegistryServiceTimeouts | cdktn.IResolvable): any;
export declare class AgentRegistryServiceTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentRegistryServiceTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AgentRegistryServiceTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_service google_agent_registry_service}
*/
export declare class AgentRegistryService extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_agent_registry_service";
    /**
    * Generates CDKTN code for importing a AgentRegistryService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AgentRegistryService to import
    * @param importFromId The id of the existing AgentRegistryService that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AgentRegistryService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/agent_registry_service google_agent_registry_service} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AgentRegistryServiceConfig
    */
    constructor(scope: Construct, id: string, config: AgentRegistryServiceConfig);
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get registryResource(): string;
    private _serviceId?;
    get serviceId(): string;
    set serviceId(value: string);
    get serviceIdInput(): string | undefined;
    get updateTime(): string;
    private _agentSpec;
    get agentSpec(): AgentRegistryServiceAgentSpecOutputReference;
    putAgentSpec(value: AgentRegistryServiceAgentSpec): void;
    resetAgentSpec(): void;
    get agentSpecInput(): AgentRegistryServiceAgentSpec | undefined;
    private _endpointSpec;
    get endpointSpec(): AgentRegistryServiceEndpointSpecOutputReference;
    putEndpointSpec(value: AgentRegistryServiceEndpointSpec): void;
    resetEndpointSpec(): void;
    get endpointSpecInput(): AgentRegistryServiceEndpointSpec | undefined;
    private _interfaces;
    get interfaces(): AgentRegistryServiceInterfacesList;
    putInterfaces(value: AgentRegistryServiceInterfaces[] | cdktn.IResolvable): void;
    resetInterfaces(): void;
    get interfacesInput(): cdktn.IResolvable | AgentRegistryServiceInterfaces[] | undefined;
    private _mcpServerSpec;
    get mcpServerSpec(): AgentRegistryServiceMcpServerSpecOutputReference;
    putMcpServerSpec(value: AgentRegistryServiceMcpServerSpec): void;
    resetMcpServerSpec(): void;
    get mcpServerSpecInput(): AgentRegistryServiceMcpServerSpec | undefined;
    private _timeouts;
    get timeouts(): AgentRegistryServiceTimeoutsOutputReference;
    putTimeouts(value: AgentRegistryServiceTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AgentRegistryServiceTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
