/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BackupDrAutoProtectionPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the auto protection policy. This becomes the final component of the policy's resource name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_auto_protection_policy#auto_protection_policy_id BackupDrAutoProtectionPolicy#auto_protection_policy_id}
    */
    readonly autoProtectionPolicyId: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_auto_protection_policy#deletion_policy BackupDrAutoProtectionPolicy#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * A description of the auto protection policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_auto_protection_policy#description BackupDrAutoProtectionPolicy#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_auto_protection_policy#id BackupDrAutoProtectionPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the auto protection policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_auto_protection_policy#location BackupDrAutoProtectionPolicy#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_auto_protection_policy#project BackupDrAutoProtectionPolicy#project}
    */
    readonly project?: string;
    /**
    * backup_plan_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_auto_protection_policy#backup_plan_details BackupDrAutoProtectionPolicy#backup_plan_details}
    */
    readonly backupPlanDetails: BackupDrAutoProtectionPolicyBackupPlanDetails[] | cdktn.IResolvable;
    /**
    * criteria block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_auto_protection_policy#criteria BackupDrAutoProtectionPolicy#criteria}
    */
    readonly criteria: BackupDrAutoProtectionPolicyCriteria;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_auto_protection_policy#timeouts BackupDrAutoProtectionPolicy#timeouts}
    */
    readonly timeouts?: BackupDrAutoProtectionPolicyTimeouts;
}
export interface BackupDrAutoProtectionPolicyBindingSummary {
}
export declare function backupDrAutoProtectionPolicyBindingSummaryToTerraform(struct?: BackupDrAutoProtectionPolicyBindingSummary): any;
export declare function backupDrAutoProtectionPolicyBindingSummaryToHclTerraform(struct?: BackupDrAutoProtectionPolicyBindingSummary): any;
export declare class BackupDrAutoProtectionPolicyBindingSummaryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupDrAutoProtectionPolicyBindingSummary | undefined;
    set internalValue(value: BackupDrAutoProtectionPolicyBindingSummary | undefined);
    get projectCount(): string;
}
export declare class BackupDrAutoProtectionPolicyBindingSummaryList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupDrAutoProtectionPolicyBindingSummaryOutputReference;
}
export interface BackupDrAutoProtectionPolicyPolicyEvaluationSummary {
}
export declare function backupDrAutoProtectionPolicyPolicyEvaluationSummaryToTerraform(struct?: BackupDrAutoProtectionPolicyPolicyEvaluationSummary): any;
export declare function backupDrAutoProtectionPolicyPolicyEvaluationSummaryToHclTerraform(struct?: BackupDrAutoProtectionPolicyPolicyEvaluationSummary): any;
export declare class BackupDrAutoProtectionPolicyPolicyEvaluationSummaryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupDrAutoProtectionPolicyPolicyEvaluationSummary | undefined;
    set internalValue(value: BackupDrAutoProtectionPolicyPolicyEvaluationSummary | undefined);
    get failedResourceCount(): string;
    get matchingResourceCount(): string;
    get protectedResourceCount(): string;
}
export declare class BackupDrAutoProtectionPolicyPolicyEvaluationSummaryList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupDrAutoProtectionPolicyPolicyEvaluationSummaryOutputReference;
}
export interface BackupDrAutoProtectionPolicyBackupPlanDetails {
    /**
    * The resource name of the backup plan to apply to the matching resources, in the format
    * 'projects/{project}/locations/{location}/backupPlans/{backup_plan_id}'. The backup plan
    * must be in the same location as the auto protection policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_auto_protection_policy#backup_plan BackupDrAutoProtectionPolicy#backup_plan}
    */
    readonly backupPlan: string;
    /**
    * The type of resource that this policy automatically protects, for example
    * 'compute.googleapis.com/Instance' or 'compute.googleapis.com/Disk'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_auto_protection_policy#resource_type BackupDrAutoProtectionPolicy#resource_type}
    */
    readonly resourceType: string;
}
export declare function backupDrAutoProtectionPolicyBackupPlanDetailsToTerraform(struct?: BackupDrAutoProtectionPolicyBackupPlanDetails | cdktn.IResolvable): any;
export declare function backupDrAutoProtectionPolicyBackupPlanDetailsToHclTerraform(struct?: BackupDrAutoProtectionPolicyBackupPlanDetails | cdktn.IResolvable): any;
export declare class BackupDrAutoProtectionPolicyBackupPlanDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupDrAutoProtectionPolicyBackupPlanDetails | cdktn.IResolvable | undefined;
    set internalValue(value: BackupDrAutoProtectionPolicyBackupPlanDetails | cdktn.IResolvable | undefined);
    private _backupPlan?;
    get backupPlan(): string;
    set backupPlan(value: string);
    get backupPlanInput(): string | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    get resourceTypeInput(): string | undefined;
}
export declare class BackupDrAutoProtectionPolicyBackupPlanDetailsList extends cdktn.ComplexList {
    internalValue?: BackupDrAutoProtectionPolicyBackupPlanDetails[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupDrAutoProtectionPolicyBackupPlanDetailsOutputReference;
}
export interface BackupDrAutoProtectionPolicyCriteriaMatchingConditionsLabelCondition {
    /**
    * The key of the label to match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_auto_protection_policy#key BackupDrAutoProtectionPolicy#key}
    */
    readonly key: string;
    /**
    * The values of the label to match. A resource matches the condition if its label
    * value is equal to any of the listed values. Currently, only one value is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_auto_protection_policy#values BackupDrAutoProtectionPolicy#values}
    */
    readonly values: string[];
}
export declare function backupDrAutoProtectionPolicyCriteriaMatchingConditionsLabelConditionToTerraform(struct?: BackupDrAutoProtectionPolicyCriteriaMatchingConditionsLabelConditionOutputReference | BackupDrAutoProtectionPolicyCriteriaMatchingConditionsLabelCondition): any;
export declare function backupDrAutoProtectionPolicyCriteriaMatchingConditionsLabelConditionToHclTerraform(struct?: BackupDrAutoProtectionPolicyCriteriaMatchingConditionsLabelConditionOutputReference | BackupDrAutoProtectionPolicyCriteriaMatchingConditionsLabelCondition): any;
export declare class BackupDrAutoProtectionPolicyCriteriaMatchingConditionsLabelConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrAutoProtectionPolicyCriteriaMatchingConditionsLabelCondition | undefined;
    set internalValue(value: BackupDrAutoProtectionPolicyCriteriaMatchingConditionsLabelCondition | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export interface BackupDrAutoProtectionPolicyCriteriaMatchingConditions {
    /**
    * label_condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_auto_protection_policy#label_condition BackupDrAutoProtectionPolicy#label_condition}
    */
    readonly labelCondition?: BackupDrAutoProtectionPolicyCriteriaMatchingConditionsLabelCondition;
}
export declare function backupDrAutoProtectionPolicyCriteriaMatchingConditionsToTerraform(struct?: BackupDrAutoProtectionPolicyCriteriaMatchingConditions | cdktn.IResolvable): any;
export declare function backupDrAutoProtectionPolicyCriteriaMatchingConditionsToHclTerraform(struct?: BackupDrAutoProtectionPolicyCriteriaMatchingConditions | cdktn.IResolvable): any;
export declare class BackupDrAutoProtectionPolicyCriteriaMatchingConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupDrAutoProtectionPolicyCriteriaMatchingConditions | cdktn.IResolvable | undefined;
    set internalValue(value: BackupDrAutoProtectionPolicyCriteriaMatchingConditions | cdktn.IResolvable | undefined);
    private _labelCondition;
    get labelCondition(): BackupDrAutoProtectionPolicyCriteriaMatchingConditionsLabelConditionOutputReference;
    putLabelCondition(value: BackupDrAutoProtectionPolicyCriteriaMatchingConditionsLabelCondition): void;
    resetLabelCondition(): void;
    get labelConditionInput(): BackupDrAutoProtectionPolicyCriteriaMatchingConditionsLabelCondition | undefined;
}
export declare class BackupDrAutoProtectionPolicyCriteriaMatchingConditionsList extends cdktn.ComplexList {
    internalValue?: BackupDrAutoProtectionPolicyCriteriaMatchingConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupDrAutoProtectionPolicyCriteriaMatchingConditionsOutputReference;
}
export interface BackupDrAutoProtectionPolicyCriteria {
    /**
    * matching_conditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_auto_protection_policy#matching_conditions BackupDrAutoProtectionPolicy#matching_conditions}
    */
    readonly matchingConditions: BackupDrAutoProtectionPolicyCriteriaMatchingConditions[] | cdktn.IResolvable;
}
export declare function backupDrAutoProtectionPolicyCriteriaToTerraform(struct?: BackupDrAutoProtectionPolicyCriteriaOutputReference | BackupDrAutoProtectionPolicyCriteria): any;
export declare function backupDrAutoProtectionPolicyCriteriaToHclTerraform(struct?: BackupDrAutoProtectionPolicyCriteriaOutputReference | BackupDrAutoProtectionPolicyCriteria): any;
export declare class BackupDrAutoProtectionPolicyCriteriaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrAutoProtectionPolicyCriteria | undefined;
    set internalValue(value: BackupDrAutoProtectionPolicyCriteria | undefined);
    private _matchingConditions;
    get matchingConditions(): BackupDrAutoProtectionPolicyCriteriaMatchingConditionsList;
    putMatchingConditions(value: BackupDrAutoProtectionPolicyCriteriaMatchingConditions[] | cdktn.IResolvable): void;
    get matchingConditionsInput(): cdktn.IResolvable | BackupDrAutoProtectionPolicyCriteriaMatchingConditions[] | undefined;
}
export interface BackupDrAutoProtectionPolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_auto_protection_policy#create BackupDrAutoProtectionPolicy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_auto_protection_policy#delete BackupDrAutoProtectionPolicy#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_auto_protection_policy#update BackupDrAutoProtectionPolicy#update}
    */
    readonly update?: string;
}
export declare function backupDrAutoProtectionPolicyTimeoutsToTerraform(struct?: BackupDrAutoProtectionPolicyTimeouts | cdktn.IResolvable): any;
export declare function backupDrAutoProtectionPolicyTimeoutsToHclTerraform(struct?: BackupDrAutoProtectionPolicyTimeouts | cdktn.IResolvable): any;
export declare class BackupDrAutoProtectionPolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrAutoProtectionPolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BackupDrAutoProtectionPolicyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_auto_protection_policy google_backup_dr_auto_protection_policy}
*/
export declare class BackupDrAutoProtectionPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_backup_dr_auto_protection_policy";
    /**
    * Generates CDKTN code for importing a BackupDrAutoProtectionPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BackupDrAutoProtectionPolicy to import
    * @param importFromId The id of the existing BackupDrAutoProtectionPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_auto_protection_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BackupDrAutoProtectionPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_auto_protection_policy google_backup_dr_auto_protection_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BackupDrAutoProtectionPolicyConfig
    */
    constructor(scope: Construct, id: string, config: BackupDrAutoProtectionPolicyConfig);
    private _autoProtectionPolicyId?;
    get autoProtectionPolicyId(): string;
    set autoProtectionPolicyId(value: string);
    get autoProtectionPolicyIdInput(): string | undefined;
    private _bindingSummary;
    get bindingSummary(): BackupDrAutoProtectionPolicyBindingSummaryList;
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _policyEvaluationSummary;
    get policyEvaluationSummary(): BackupDrAutoProtectionPolicyPolicyEvaluationSummaryList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get state(): string;
    get updateTime(): string;
    private _backupPlanDetails;
    get backupPlanDetails(): BackupDrAutoProtectionPolicyBackupPlanDetailsList;
    putBackupPlanDetails(value: BackupDrAutoProtectionPolicyBackupPlanDetails[] | cdktn.IResolvable): void;
    get backupPlanDetailsInput(): cdktn.IResolvable | BackupDrAutoProtectionPolicyBackupPlanDetails[] | undefined;
    private _criteria;
    get criteria(): BackupDrAutoProtectionPolicyCriteriaOutputReference;
    putCriteria(value: BackupDrAutoProtectionPolicyCriteria): void;
    get criteriaInput(): BackupDrAutoProtectionPolicyCriteria | undefined;
    private _timeouts;
    get timeouts(): BackupDrAutoProtectionPolicyTimeoutsOutputReference;
    putTimeouts(value: BackupDrAutoProtectionPolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BackupDrAutoProtectionPolicyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
