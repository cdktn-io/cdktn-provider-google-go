/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigeeApiConfig extends cdktn.TerraformMetaArguments {
    /**
    * Path to the config zip bundle
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_api#config_bundle ApigeeApi#config_bundle}
    */
    readonly configBundle: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_api#deletion_policy ApigeeApi#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * A hash of local config bundle in string, user needs to use a Terraform Hash function of their choice. A change in hash will trigger an update.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_api#detect_md5hash ApigeeApi#detect_md5hash}
    */
    readonly detectMd5Hash?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_api#id ApigeeApi#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * User labels applied to this API proxy.
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_api#labels ApigeeApi#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the API proxy. This field only accepts the following characters: A-Za-z0-9._-.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_api#name ApigeeApi#name}
    */
    readonly name: string;
    /**
    * The Apigee Organization name associated with the Apigee instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_api#org_id ApigeeApi#org_id}
    */
    readonly orgId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_api#timeouts ApigeeApi#timeouts}
    */
    readonly timeouts?: ApigeeApiTimeouts;
}
export interface ApigeeApiMetaData {
}
export declare function apigeeApiMetaDataToTerraform(struct?: ApigeeApiMetaData): any;
export declare function apigeeApiMetaDataToHclTerraform(struct?: ApigeeApiMetaData): any;
export declare class ApigeeApiMetaDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigeeApiMetaData | undefined;
    set internalValue(value: ApigeeApiMetaData | undefined);
    get createdAt(): string;
    get lastModifiedAt(): string;
    get subType(): string;
}
export declare class ApigeeApiMetaDataList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigeeApiMetaDataOutputReference;
}
export interface ApigeeApiTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_api#create ApigeeApi#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_api#delete ApigeeApi#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_api#update ApigeeApi#update}
    */
    readonly update?: string;
}
export declare function apigeeApiTimeoutsToTerraform(struct?: ApigeeApiTimeouts | cdktn.IResolvable): any;
export declare function apigeeApiTimeoutsToHclTerraform(struct?: ApigeeApiTimeouts | cdktn.IResolvable): any;
export declare class ApigeeApiTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeApiTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeApiTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_api google_apigee_api}
*/
export declare class ApigeeApi extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apigee_api";
    /**
    * Generates CDKTN code for importing a ApigeeApi resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigeeApi to import
    * @param importFromId The id of the existing ApigeeApi that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_api#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigeeApi to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_api google_apigee_api} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigeeApiConfig
    */
    constructor(scope: Construct, id: string, config: ApigeeApiConfig);
    private _configBundle?;
    get configBundle(): string;
    set configBundle(value: string);
    get configBundleInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _detectMd5Hash?;
    get detectMd5Hash(): string;
    set detectMd5Hash(value: string);
    resetDetectMd5Hash(): void;
    get detectMd5HashInput(): string | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    get latestRevisionId(): string;
    get md5Hash(): string;
    private _metaData;
    get metaData(): ApigeeApiMetaDataList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _orgId?;
    get orgId(): string;
    set orgId(value: string);
    get orgIdInput(): string | undefined;
    get revision(): string[];
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _timeouts;
    get timeouts(): ApigeeApiTimeoutsOutputReference;
    putTimeouts(value: ApigeeApiTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApigeeApiTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
