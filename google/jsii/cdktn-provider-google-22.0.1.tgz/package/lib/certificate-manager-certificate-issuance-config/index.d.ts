/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CertificateManagerCertificateIssuanceConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/certificate_manager_certificate_issuance_config#deletion_policy CertificateManagerCertificateIssuanceConfig#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * One or more paragraphs of text description of a CertificateIssuanceConfig.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/certificate_manager_certificate_issuance_config#description CertificateManagerCertificateIssuanceConfig#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/certificate_manager_certificate_issuance_config#id CertificateManagerCertificateIssuanceConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Key algorithm to use when generating the private key. Possible values: ["RSA_2048", "ECDSA_P256"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/certificate_manager_certificate_issuance_config#key_algorithm CertificateManagerCertificateIssuanceConfig#key_algorithm}
    */
    readonly keyAlgorithm: string;
    /**
    * 'Set of label tags associated with the CertificateIssuanceConfig resource.
    *  An object containing a list of "key": value pairs. Example: { "name": "wrench", "count": "3" }.
    *
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/certificate_manager_certificate_issuance_config#labels CertificateManagerCertificateIssuanceConfig#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Lifetime of issued certificates. A duration in seconds with up to nine fractional digits, ending with 's'.
    * Example: "1814400s". Valid values are from 21 days (1814400s) to 30 days (2592000s)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/certificate_manager_certificate_issuance_config#lifetime CertificateManagerCertificateIssuanceConfig#lifetime}
    */
    readonly lifetime: string;
    /**
    * The Certificate Manager location. If not specified, "global" is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/certificate_manager_certificate_issuance_config#location CertificateManagerCertificateIssuanceConfig#location}
    */
    readonly location?: string;
    /**
    * A user-defined name of the certificate issuance config.
    * CertificateIssuanceConfig names must be unique globally.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/certificate_manager_certificate_issuance_config#name CertificateManagerCertificateIssuanceConfig#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/certificate_manager_certificate_issuance_config#project CertificateManagerCertificateIssuanceConfig#project}
    */
    readonly project?: string;
    /**
    * It specifies the percentage of elapsed time of the certificate lifetime to wait before renewing the certificate.
    * Must be a number between 1-99, inclusive.
    * You must set the rotation window percentage in relation to the certificate lifetime so that certificate renewal occurs at least 7 days after
    * the certificate has been issued and at least 7 days before it expires.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/certificate_manager_certificate_issuance_config#rotation_window_percentage CertificateManagerCertificateIssuanceConfig#rotation_window_percentage}
    */
    readonly rotationWindowPercentage: number;
    /**
    * certificate_authority_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/certificate_manager_certificate_issuance_config#certificate_authority_config CertificateManagerCertificateIssuanceConfig#certificate_authority_config}
    */
    readonly certificateAuthorityConfig: CertificateManagerCertificateIssuanceConfigCertificateAuthorityConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/certificate_manager_certificate_issuance_config#timeouts CertificateManagerCertificateIssuanceConfig#timeouts}
    */
    readonly timeouts?: CertificateManagerCertificateIssuanceConfigTimeouts;
}
export interface CertificateManagerCertificateIssuanceConfigCertificateAuthorityConfigCertificateAuthorityServiceConfig {
    /**
    * A CA pool resource used to issue a certificate.
    * The CA pool string has a relative resource path following the form
    * "projects/{project}/locations/{location}/caPools/{caPool}".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/certificate_manager_certificate_issuance_config#ca_pool CertificateManagerCertificateIssuanceConfig#ca_pool}
    */
    readonly caPool: string;
}
export declare function certificateManagerCertificateIssuanceConfigCertificateAuthorityConfigCertificateAuthorityServiceConfigToTerraform(struct?: CertificateManagerCertificateIssuanceConfigCertificateAuthorityConfigCertificateAuthorityServiceConfigOutputReference | CertificateManagerCertificateIssuanceConfigCertificateAuthorityConfigCertificateAuthorityServiceConfig): any;
export declare function certificateManagerCertificateIssuanceConfigCertificateAuthorityConfigCertificateAuthorityServiceConfigToHclTerraform(struct?: CertificateManagerCertificateIssuanceConfigCertificateAuthorityConfigCertificateAuthorityServiceConfigOutputReference | CertificateManagerCertificateIssuanceConfigCertificateAuthorityConfigCertificateAuthorityServiceConfig): any;
export declare class CertificateManagerCertificateIssuanceConfigCertificateAuthorityConfigCertificateAuthorityServiceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CertificateManagerCertificateIssuanceConfigCertificateAuthorityConfigCertificateAuthorityServiceConfig | undefined;
    set internalValue(value: CertificateManagerCertificateIssuanceConfigCertificateAuthorityConfigCertificateAuthorityServiceConfig | undefined);
    private _caPool?;
    get caPool(): string;
    set caPool(value: string);
    get caPoolInput(): string | undefined;
}
export interface CertificateManagerCertificateIssuanceConfigCertificateAuthorityConfig {
    /**
    * certificate_authority_service_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/certificate_manager_certificate_issuance_config#certificate_authority_service_config CertificateManagerCertificateIssuanceConfig#certificate_authority_service_config}
    */
    readonly certificateAuthorityServiceConfig?: CertificateManagerCertificateIssuanceConfigCertificateAuthorityConfigCertificateAuthorityServiceConfig;
}
export declare function certificateManagerCertificateIssuanceConfigCertificateAuthorityConfigToTerraform(struct?: CertificateManagerCertificateIssuanceConfigCertificateAuthorityConfigOutputReference | CertificateManagerCertificateIssuanceConfigCertificateAuthorityConfig): any;
export declare function certificateManagerCertificateIssuanceConfigCertificateAuthorityConfigToHclTerraform(struct?: CertificateManagerCertificateIssuanceConfigCertificateAuthorityConfigOutputReference | CertificateManagerCertificateIssuanceConfigCertificateAuthorityConfig): any;
export declare class CertificateManagerCertificateIssuanceConfigCertificateAuthorityConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CertificateManagerCertificateIssuanceConfigCertificateAuthorityConfig | undefined;
    set internalValue(value: CertificateManagerCertificateIssuanceConfigCertificateAuthorityConfig | undefined);
    private _certificateAuthorityServiceConfig;
    get certificateAuthorityServiceConfig(): CertificateManagerCertificateIssuanceConfigCertificateAuthorityConfigCertificateAuthorityServiceConfigOutputReference;
    putCertificateAuthorityServiceConfig(value: CertificateManagerCertificateIssuanceConfigCertificateAuthorityConfigCertificateAuthorityServiceConfig): void;
    resetCertificateAuthorityServiceConfig(): void;
    get certificateAuthorityServiceConfigInput(): CertificateManagerCertificateIssuanceConfigCertificateAuthorityConfigCertificateAuthorityServiceConfig | undefined;
}
export interface CertificateManagerCertificateIssuanceConfigTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/certificate_manager_certificate_issuance_config#create CertificateManagerCertificateIssuanceConfig#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/certificate_manager_certificate_issuance_config#delete CertificateManagerCertificateIssuanceConfig#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/certificate_manager_certificate_issuance_config#update CertificateManagerCertificateIssuanceConfig#update}
    */
    readonly update?: string;
}
export declare function certificateManagerCertificateIssuanceConfigTimeoutsToTerraform(struct?: CertificateManagerCertificateIssuanceConfigTimeouts | cdktn.IResolvable): any;
export declare function certificateManagerCertificateIssuanceConfigTimeoutsToHclTerraform(struct?: CertificateManagerCertificateIssuanceConfigTimeouts | cdktn.IResolvable): any;
export declare class CertificateManagerCertificateIssuanceConfigTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CertificateManagerCertificateIssuanceConfigTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CertificateManagerCertificateIssuanceConfigTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/certificate_manager_certificate_issuance_config google_certificate_manager_certificate_issuance_config}
*/
export declare class CertificateManagerCertificateIssuanceConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_certificate_manager_certificate_issuance_config";
    /**
    * Generates CDKTN code for importing a CertificateManagerCertificateIssuanceConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CertificateManagerCertificateIssuanceConfig to import
    * @param importFromId The id of the existing CertificateManagerCertificateIssuanceConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/certificate_manager_certificate_issuance_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CertificateManagerCertificateIssuanceConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/certificate_manager_certificate_issuance_config google_certificate_manager_certificate_issuance_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CertificateManagerCertificateIssuanceConfigConfig
    */
    constructor(scope: Construct, id: string, config: CertificateManagerCertificateIssuanceConfigConfig);
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keyAlgorithm?;
    get keyAlgorithm(): string;
    set keyAlgorithm(value: string);
    get keyAlgorithmInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _lifetime?;
    get lifetime(): string;
    set lifetime(value: string);
    get lifetimeInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _rotationWindowPercentage?;
    get rotationWindowPercentage(): number;
    set rotationWindowPercentage(value: number);
    get rotationWindowPercentageInput(): number | undefined;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get updateTime(): string;
    private _certificateAuthorityConfig;
    get certificateAuthorityConfig(): CertificateManagerCertificateIssuanceConfigCertificateAuthorityConfigOutputReference;
    putCertificateAuthorityConfig(value: CertificateManagerCertificateIssuanceConfigCertificateAuthorityConfig): void;
    get certificateAuthorityConfigInput(): CertificateManagerCertificateIssuanceConfigCertificateAuthorityConfig | undefined;
    private _timeouts;
    get timeouts(): CertificateManagerCertificateIssuanceConfigTimeoutsOutputReference;
    putTimeouts(value: CertificateManagerCertificateIssuanceConfigTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CertificateManagerCertificateIssuanceConfigTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
