/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AlloydbBackupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Annotations to allow client tools to store small amount of arbitrary data. This is distinct from labels. https://google.aip.dev/128
    * An object containing a list of "key": value pairs. Example: { "name": "wrench", "mass": "1.3kg", "count": "3" }.
    *
    *
    * **Note**: This field is non-authoritative, and will only manage the annotations present in your configuration.
    * Please refer to the field 'effective_annotations' for all of the annotations present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_backup#annotations AlloydbBackup#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * The ID of the alloydb backup.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_backup#backup_id AlloydbBackup#backup_id}
    */
    readonly backupId: string;
    /**
    * The full resource name of the backup source cluster (e.g., projects/{project}/locations/{location}/clusters/{clusterId}).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_backup#cluster_name AlloydbBackup#cluster_name}
    */
    readonly clusterName: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_backup#deletion_policy AlloydbBackup#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * User-provided description of the backup.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_backup#description AlloydbBackup#description}
    */
    readonly description?: string;
    /**
    * User-settable and human-readable display name for the Backup.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_backup#display_name AlloydbBackup#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_backup#id AlloydbBackup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * User-defined labels for the alloydb backup. An object containing a list of "key": value pairs. Example: { "name": "wrench", "mass": "1.3kg", "count": "3" }.
    *
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_backup#labels AlloydbBackup#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The location where the alloydb backup should reside.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_backup#location AlloydbBackup#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_backup#project AlloydbBackup#project}
    */
    readonly project?: string;
    /**
    * The backup type, which suggests the trigger for the backup. Possible values: ["TYPE_UNSPECIFIED", "ON_DEMAND", "AUTOMATED", "CONTINUOUS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_backup#type AlloydbBackup#type}
    */
    readonly type?: string;
    /**
    * encryption_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_backup#encryption_config AlloydbBackup#encryption_config}
    */
    readonly encryptionConfig?: AlloydbBackupEncryptionConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_backup#timeouts AlloydbBackup#timeouts}
    */
    readonly timeouts?: AlloydbBackupTimeouts;
}
export interface AlloydbBackupEncryptionInfo {
}
export declare function alloydbBackupEncryptionInfoToTerraform(struct?: AlloydbBackupEncryptionInfo): any;
export declare function alloydbBackupEncryptionInfoToHclTerraform(struct?: AlloydbBackupEncryptionInfo): any;
export declare class AlloydbBackupEncryptionInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlloydbBackupEncryptionInfo | undefined;
    set internalValue(value: AlloydbBackupEncryptionInfo | undefined);
    get encryptionType(): string;
    get kmsKeyVersions(): string[];
}
export declare class AlloydbBackupEncryptionInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlloydbBackupEncryptionInfoOutputReference;
}
export interface AlloydbBackupExpiryQuantity {
}
export declare function alloydbBackupExpiryQuantityToTerraform(struct?: AlloydbBackupExpiryQuantity): any;
export declare function alloydbBackupExpiryQuantityToHclTerraform(struct?: AlloydbBackupExpiryQuantity): any;
export declare class AlloydbBackupExpiryQuantityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlloydbBackupExpiryQuantity | undefined;
    set internalValue(value: AlloydbBackupExpiryQuantity | undefined);
    get retentionCount(): number;
    get totalRetentionCount(): number;
}
export declare class AlloydbBackupExpiryQuantityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlloydbBackupExpiryQuantityOutputReference;
}
export interface AlloydbBackupEncryptionConfig {
    /**
    * The fully-qualified resource name of the KMS key. Each Cloud KMS key is regionalized and has the following format: projects/[PROJECT]/locations/[REGION]/keyRings/[RING]/cryptoKeys/[KEY_NAME].
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_backup#kms_key_name AlloydbBackup#kms_key_name}
    */
    readonly kmsKeyName?: string;
}
export declare function alloydbBackupEncryptionConfigToTerraform(struct?: AlloydbBackupEncryptionConfigOutputReference | AlloydbBackupEncryptionConfig): any;
export declare function alloydbBackupEncryptionConfigToHclTerraform(struct?: AlloydbBackupEncryptionConfigOutputReference | AlloydbBackupEncryptionConfig): any;
export declare class AlloydbBackupEncryptionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbBackupEncryptionConfig | undefined;
    set internalValue(value: AlloydbBackupEncryptionConfig | undefined);
    private _kmsKeyName?;
    get kmsKeyName(): string;
    set kmsKeyName(value: string);
    resetKmsKeyName(): void;
    get kmsKeyNameInput(): string | undefined;
}
export interface AlloydbBackupTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_backup#create AlloydbBackup#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_backup#delete AlloydbBackup#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_backup#update AlloydbBackup#update}
    */
    readonly update?: string;
}
export declare function alloydbBackupTimeoutsToTerraform(struct?: AlloydbBackupTimeouts | cdktn.IResolvable): any;
export declare function alloydbBackupTimeoutsToHclTerraform(struct?: AlloydbBackupTimeouts | cdktn.IResolvable): any;
export declare class AlloydbBackupTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbBackupTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AlloydbBackupTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_backup google_alloydb_backup}
*/
export declare class AlloydbBackup extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_alloydb_backup";
    /**
    * Generates CDKTN code for importing a AlloydbBackup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AlloydbBackup to import
    * @param importFromId The id of the existing AlloydbBackup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_backup#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AlloydbBackup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_backup google_alloydb_backup} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AlloydbBackupConfig
    */
    constructor(scope: Construct, id: string, config: AlloydbBackupConfig);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _backupId?;
    get backupId(): string;
    set backupId(value: string);
    get backupIdInput(): string | undefined;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    get clusterNameInput(): string | undefined;
    get clusterUid(): string;
    get createTime(): string;
    get deleteTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _effectiveAnnotations;
    get effectiveAnnotations(): cdktn.StringMap;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _encryptionInfo;
    get encryptionInfo(): AlloydbBackupEncryptionInfoList;
    get etag(): string;
    private _expiryQuantity;
    get expiryQuantity(): AlloydbBackupExpiryQuantityList;
    get expiryTime(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get reconciling(): cdktn.IResolvable;
    get sizeBytes(): string;
    get state(): string;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    get uid(): string;
    get updateTime(): string;
    private _encryptionConfig;
    get encryptionConfig(): AlloydbBackupEncryptionConfigOutputReference;
    putEncryptionConfig(value: AlloydbBackupEncryptionConfig): void;
    resetEncryptionConfig(): void;
    get encryptionConfigInput(): AlloydbBackupEncryptionConfig | undefined;
    private _timeouts;
    get timeouts(): AlloydbBackupTimeoutsOutputReference;
    putTimeouts(value: AlloydbBackupTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AlloydbBackupTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
