/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BinaryAuthorizationPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/binary_authorization_policy#deletion_policy BinaryAuthorizationPolicy#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * A descriptive comment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/binary_authorization_policy#description BinaryAuthorizationPolicy#description}
    */
    readonly description?: string;
    /**
    * Controls the evaluation of a Google-maintained global admission policy
    * for common system-level images. Images not covered by the global
    * policy will be subject to the project admission policy. Possible values: ["ENABLE", "DISABLE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/binary_authorization_policy#global_policy_evaluation_mode BinaryAuthorizationPolicy#global_policy_evaluation_mode}
    */
    readonly globalPolicyEvaluationMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/binary_authorization_policy#id BinaryAuthorizationPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/binary_authorization_policy#project BinaryAuthorizationPolicy#project}
    */
    readonly project?: string;
    /**
    * admission_whitelist_patterns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/binary_authorization_policy#admission_whitelist_patterns BinaryAuthorizationPolicy#admission_whitelist_patterns}
    */
    readonly admissionWhitelistPatterns?: BinaryAuthorizationPolicyAdmissionWhitelistPatterns[] | cdktn.IResolvable;
    /**
    * cluster_admission_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/binary_authorization_policy#cluster_admission_rules BinaryAuthorizationPolicy#cluster_admission_rules}
    */
    readonly clusterAdmissionRules?: BinaryAuthorizationPolicyClusterAdmissionRules[] | cdktn.IResolvable;
    /**
    * default_admission_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/binary_authorization_policy#default_admission_rule BinaryAuthorizationPolicy#default_admission_rule}
    */
    readonly defaultAdmissionRule: BinaryAuthorizationPolicyDefaultAdmissionRule;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/binary_authorization_policy#timeouts BinaryAuthorizationPolicy#timeouts}
    */
    readonly timeouts?: BinaryAuthorizationPolicyTimeouts;
}
export interface BinaryAuthorizationPolicyAdmissionWhitelistPatterns {
    /**
    * An image name pattern to whitelist, in the form
    * 'registry/path/to/image'. This supports a trailing * as a
    * wildcard, but this is allowed only in text after the registry/
    * part.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/binary_authorization_policy#name_pattern BinaryAuthorizationPolicy#name_pattern}
    */
    readonly namePattern: string;
}
export declare function binaryAuthorizationPolicyAdmissionWhitelistPatternsToTerraform(struct?: BinaryAuthorizationPolicyAdmissionWhitelistPatterns | cdktn.IResolvable): any;
export declare function binaryAuthorizationPolicyAdmissionWhitelistPatternsToHclTerraform(struct?: BinaryAuthorizationPolicyAdmissionWhitelistPatterns | cdktn.IResolvable): any;
export declare class BinaryAuthorizationPolicyAdmissionWhitelistPatternsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BinaryAuthorizationPolicyAdmissionWhitelistPatterns | cdktn.IResolvable | undefined;
    set internalValue(value: BinaryAuthorizationPolicyAdmissionWhitelistPatterns | cdktn.IResolvable | undefined);
    private _namePattern?;
    get namePattern(): string;
    set namePattern(value: string);
    get namePatternInput(): string | undefined;
}
export declare class BinaryAuthorizationPolicyAdmissionWhitelistPatternsList extends cdktn.ComplexList {
    internalValue?: BinaryAuthorizationPolicyAdmissionWhitelistPatterns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BinaryAuthorizationPolicyAdmissionWhitelistPatternsOutputReference;
}
export interface BinaryAuthorizationPolicyClusterAdmissionRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/binary_authorization_policy#cluster BinaryAuthorizationPolicy#cluster}
    */
    readonly cluster: string;
    /**
    * The action when a pod creation is denied by the admission rule. Possible values: ["ENFORCED_BLOCK_AND_AUDIT_LOG", "DRYRUN_AUDIT_LOG_ONLY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/binary_authorization_policy#enforcement_mode BinaryAuthorizationPolicy#enforcement_mode}
    */
    readonly enforcementMode: string;
    /**
    * How this admission rule will be evaluated. Possible values: ["ALWAYS_ALLOW", "REQUIRE_ATTESTATION", "ALWAYS_DENY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/binary_authorization_policy#evaluation_mode BinaryAuthorizationPolicy#evaluation_mode}
    */
    readonly evaluationMode: string;
    /**
    * The resource names of the attestors that must attest to a
    * container image. If the attestor is in a different project from the
    * policy, it should be specified in the format 'projects/* /attestors/*'.
    * Each attestor must exist before a policy can reference it. To add an
    * attestor to a policy the principal issuing the policy change
    * request must be able to read the attestor resource.
    *
    * Note: this field must be non-empty when the evaluation_mode field
    * specifies REQUIRE_ATTESTATION, otherwise it must be empty.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/binary_authorization_policy#require_attestations_by BinaryAuthorizationPolicy#require_attestations_by}
     *
    * Note: The above comment contained a comment block ending sequence (* followed by /). We have introduced a space between to prevent syntax errors. Please ignore the space.
    */
    readonly requireAttestationsBy?: string[];
}
export declare function binaryAuthorizationPolicyClusterAdmissionRulesToTerraform(struct?: BinaryAuthorizationPolicyClusterAdmissionRules | cdktn.IResolvable): any;
export declare function binaryAuthorizationPolicyClusterAdmissionRulesToHclTerraform(struct?: BinaryAuthorizationPolicyClusterAdmissionRules | cdktn.IResolvable): any;
export declare class BinaryAuthorizationPolicyClusterAdmissionRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BinaryAuthorizationPolicyClusterAdmissionRules | cdktn.IResolvable | undefined;
    set internalValue(value: BinaryAuthorizationPolicyClusterAdmissionRules | cdktn.IResolvable | undefined);
    private _cluster?;
    get cluster(): string;
    set cluster(value: string);
    get clusterInput(): string | undefined;
    private _enforcementMode?;
    get enforcementMode(): string;
    set enforcementMode(value: string);
    get enforcementModeInput(): string | undefined;
    private _evaluationMode?;
    get evaluationMode(): string;
    set evaluationMode(value: string);
    get evaluationModeInput(): string | undefined;
    private _requireAttestationsBy?;
    get requireAttestationsBy(): string[];
    set requireAttestationsBy(value: string[]);
    resetRequireAttestationsBy(): void;
    get requireAttestationsByInput(): string[] | undefined;
}
export declare class BinaryAuthorizationPolicyClusterAdmissionRulesList extends cdktn.ComplexList {
    internalValue?: BinaryAuthorizationPolicyClusterAdmissionRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BinaryAuthorizationPolicyClusterAdmissionRulesOutputReference;
}
export interface BinaryAuthorizationPolicyDefaultAdmissionRule {
    /**
    * The action when a pod creation is denied by the admission rule. Possible values: ["ENFORCED_BLOCK_AND_AUDIT_LOG", "DRYRUN_AUDIT_LOG_ONLY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/binary_authorization_policy#enforcement_mode BinaryAuthorizationPolicy#enforcement_mode}
    */
    readonly enforcementMode: string;
    /**
    * How this admission rule will be evaluated. Possible values: ["ALWAYS_ALLOW", "REQUIRE_ATTESTATION", "ALWAYS_DENY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/binary_authorization_policy#evaluation_mode BinaryAuthorizationPolicy#evaluation_mode}
    */
    readonly evaluationMode: string;
    /**
    * The resource names of the attestors that must attest to a
    * container image. If the attestor is in a different project from the
    * policy, it should be specified in the format 'projects/* /attestors/*'.
    * Each attestor must exist before a policy can reference it. To add an
    * attestor to a policy the principal issuing the policy change
    * request must be able to read the attestor resource.
    *
    * Note: this field must be non-empty when the evaluation_mode field
    * specifies REQUIRE_ATTESTATION, otherwise it must be empty.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/binary_authorization_policy#require_attestations_by BinaryAuthorizationPolicy#require_attestations_by}
     *
    * Note: The above comment contained a comment block ending sequence (* followed by /). We have introduced a space between to prevent syntax errors. Please ignore the space.
    */
    readonly requireAttestationsBy?: string[];
}
export declare function binaryAuthorizationPolicyDefaultAdmissionRuleToTerraform(struct?: BinaryAuthorizationPolicyDefaultAdmissionRuleOutputReference | BinaryAuthorizationPolicyDefaultAdmissionRule): any;
export declare function binaryAuthorizationPolicyDefaultAdmissionRuleToHclTerraform(struct?: BinaryAuthorizationPolicyDefaultAdmissionRuleOutputReference | BinaryAuthorizationPolicyDefaultAdmissionRule): any;
export declare class BinaryAuthorizationPolicyDefaultAdmissionRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BinaryAuthorizationPolicyDefaultAdmissionRule | undefined;
    set internalValue(value: BinaryAuthorizationPolicyDefaultAdmissionRule | undefined);
    private _enforcementMode?;
    get enforcementMode(): string;
    set enforcementMode(value: string);
    get enforcementModeInput(): string | undefined;
    private _evaluationMode?;
    get evaluationMode(): string;
    set evaluationMode(value: string);
    get evaluationModeInput(): string | undefined;
    private _requireAttestationsBy?;
    get requireAttestationsBy(): string[];
    set requireAttestationsBy(value: string[]);
    resetRequireAttestationsBy(): void;
    get requireAttestationsByInput(): string[] | undefined;
}
export interface BinaryAuthorizationPolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/binary_authorization_policy#create BinaryAuthorizationPolicy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/binary_authorization_policy#delete BinaryAuthorizationPolicy#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/binary_authorization_policy#update BinaryAuthorizationPolicy#update}
    */
    readonly update?: string;
}
export declare function binaryAuthorizationPolicyTimeoutsToTerraform(struct?: BinaryAuthorizationPolicyTimeouts | cdktn.IResolvable): any;
export declare function binaryAuthorizationPolicyTimeoutsToHclTerraform(struct?: BinaryAuthorizationPolicyTimeouts | cdktn.IResolvable): any;
export declare class BinaryAuthorizationPolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BinaryAuthorizationPolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BinaryAuthorizationPolicyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/binary_authorization_policy google_binary_authorization_policy}
*/
export declare class BinaryAuthorizationPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_binary_authorization_policy";
    /**
    * Generates CDKTN code for importing a BinaryAuthorizationPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BinaryAuthorizationPolicy to import
    * @param importFromId The id of the existing BinaryAuthorizationPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/binary_authorization_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BinaryAuthorizationPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/binary_authorization_policy google_binary_authorization_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BinaryAuthorizationPolicyConfig
    */
    constructor(scope: Construct, id: string, config: BinaryAuthorizationPolicyConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _globalPolicyEvaluationMode?;
    get globalPolicyEvaluationMode(): string;
    set globalPolicyEvaluationMode(value: string);
    resetGlobalPolicyEvaluationMode(): void;
    get globalPolicyEvaluationModeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _admissionWhitelistPatterns;
    get admissionWhitelistPatterns(): BinaryAuthorizationPolicyAdmissionWhitelistPatternsList;
    putAdmissionWhitelistPatterns(value: BinaryAuthorizationPolicyAdmissionWhitelistPatterns[] | cdktn.IResolvable): void;
    resetAdmissionWhitelistPatterns(): void;
    get admissionWhitelistPatternsInput(): cdktn.IResolvable | BinaryAuthorizationPolicyAdmissionWhitelistPatterns[] | undefined;
    private _clusterAdmissionRules;
    get clusterAdmissionRules(): BinaryAuthorizationPolicyClusterAdmissionRulesList;
    putClusterAdmissionRules(value: BinaryAuthorizationPolicyClusterAdmissionRules[] | cdktn.IResolvable): void;
    resetClusterAdmissionRules(): void;
    get clusterAdmissionRulesInput(): cdktn.IResolvable | BinaryAuthorizationPolicyClusterAdmissionRules[] | undefined;
    private _defaultAdmissionRule;
    get defaultAdmissionRule(): BinaryAuthorizationPolicyDefaultAdmissionRuleOutputReference;
    putDefaultAdmissionRule(value: BinaryAuthorizationPolicyDefaultAdmissionRule): void;
    get defaultAdmissionRuleInput(): BinaryAuthorizationPolicyDefaultAdmissionRule | undefined;
    private _timeouts;
    get timeouts(): BinaryAuthorizationPolicyTimeoutsOutputReference;
    putTimeouts(value: BinaryAuthorizationPolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BinaryAuthorizationPolicyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
