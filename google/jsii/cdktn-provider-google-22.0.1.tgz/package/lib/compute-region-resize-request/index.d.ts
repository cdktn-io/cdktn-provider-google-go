/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeRegionResizeRequestConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_resize_request#deletion_policy ComputeRegionResizeRequest#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resize-request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_resize_request#description ComputeRegionResizeRequest#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_resize_request#id ComputeRegionResizeRequest#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The reference of the regional instance group manager this ResizeRequest is a part of.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_resize_request#instance_group_manager ComputeRegionResizeRequest#instance_group_manager}
    */
    readonly instanceGroupManager: string;
    /**
    * The name of this resize request. The name must be 1-63 characters long, and comply with RFC1035.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_resize_request#name ComputeRegionResizeRequest#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_resize_request#project ComputeRegionResizeRequest#project}
    */
    readonly project?: string;
    /**
    * The reference of the compute region scoping this request. If it is not provided, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_resize_request#region ComputeRegionResizeRequest#region}
    */
    readonly region?: string;
    /**
    * The number of instances to be created by this resize request. The group's target size will be increased by this number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_resize_request#resize_by ComputeRegionResizeRequest#resize_by}
    */
    readonly resizeBy: number;
    /**
    * requested_run_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_resize_request#requested_run_duration ComputeRegionResizeRequest#requested_run_duration}
    */
    readonly requestedRunDuration?: ComputeRegionResizeRequestRequestedRunDuration;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_resize_request#timeouts ComputeRegionResizeRequest#timeouts}
    */
    readonly timeouts?: ComputeRegionResizeRequestTimeouts;
}
export interface ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsErrorInfo {
}
export declare function computeRegionResizeRequestStatusErrorErrorsErrorDetailsErrorInfoToTerraform(struct?: ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsErrorInfo): any;
export declare function computeRegionResizeRequestStatusErrorErrorsErrorDetailsErrorInfoToHclTerraform(struct?: ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsErrorInfo): any;
export declare class ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsErrorInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsErrorInfo | undefined;
    set internalValue(value: ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsErrorInfo | undefined);
    get domain(): string;
    private _metadatas;
    get metadatas(): cdktn.StringMap;
    get reason(): string;
}
export declare class ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsErrorInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsErrorInfoOutputReference;
}
export interface ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsHelpLinks {
}
export declare function computeRegionResizeRequestStatusErrorErrorsErrorDetailsHelpLinksToTerraform(struct?: ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsHelpLinks): any;
export declare function computeRegionResizeRequestStatusErrorErrorsErrorDetailsHelpLinksToHclTerraform(struct?: ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsHelpLinks): any;
export declare class ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsHelpLinksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsHelpLinks | undefined;
    set internalValue(value: ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsHelpLinks | undefined);
    get description(): string;
    get url(): string;
}
export declare class ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsHelpLinksList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsHelpLinksOutputReference;
}
export interface ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsHelp {
}
export declare function computeRegionResizeRequestStatusErrorErrorsErrorDetailsHelpToTerraform(struct?: ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsHelp): any;
export declare function computeRegionResizeRequestStatusErrorErrorsErrorDetailsHelpToHclTerraform(struct?: ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsHelp): any;
export declare class ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsHelpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsHelp | undefined;
    set internalValue(value: ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsHelp | undefined);
    private _links;
    get links(): ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsHelpLinksList;
}
export declare class ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsHelpList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsHelpOutputReference;
}
export interface ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsLocalizedMessage {
}
export declare function computeRegionResizeRequestStatusErrorErrorsErrorDetailsLocalizedMessageToTerraform(struct?: ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsLocalizedMessage): any;
export declare function computeRegionResizeRequestStatusErrorErrorsErrorDetailsLocalizedMessageToHclTerraform(struct?: ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsLocalizedMessage): any;
export declare class ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsLocalizedMessageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsLocalizedMessage | undefined;
    set internalValue(value: ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsLocalizedMessage | undefined);
    get locale(): string;
    get message(): string;
}
export declare class ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsLocalizedMessageList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsLocalizedMessageOutputReference;
}
export interface ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsQuotaInfo {
}
export declare function computeRegionResizeRequestStatusErrorErrorsErrorDetailsQuotaInfoToTerraform(struct?: ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsQuotaInfo): any;
export declare function computeRegionResizeRequestStatusErrorErrorsErrorDetailsQuotaInfoToHclTerraform(struct?: ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsQuotaInfo): any;
export declare class ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsQuotaInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsQuotaInfo | undefined;
    set internalValue(value: ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsQuotaInfo | undefined);
    private _dimensions;
    get dimensions(): cdktn.StringMap;
    get futureLimit(): number;
    get limit(): number;
    get limitName(): string;
    get metricName(): string;
    get rolloutStatus(): string;
}
export declare class ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsQuotaInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsQuotaInfoOutputReference;
}
export interface ComputeRegionResizeRequestStatusErrorErrorsErrorDetails {
}
export declare function computeRegionResizeRequestStatusErrorErrorsErrorDetailsToTerraform(struct?: ComputeRegionResizeRequestStatusErrorErrorsErrorDetails): any;
export declare function computeRegionResizeRequestStatusErrorErrorsErrorDetailsToHclTerraform(struct?: ComputeRegionResizeRequestStatusErrorErrorsErrorDetails): any;
export declare class ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionResizeRequestStatusErrorErrorsErrorDetails | undefined;
    set internalValue(value: ComputeRegionResizeRequestStatusErrorErrorsErrorDetails | undefined);
    private _errorInfo;
    get errorInfo(): ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsErrorInfoList;
    private _help;
    get help(): ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsHelpList;
    private _localizedMessage;
    get localizedMessage(): ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsLocalizedMessageList;
    private _quotaInfo;
    get quotaInfo(): ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsQuotaInfoList;
}
export declare class ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsOutputReference;
}
export interface ComputeRegionResizeRequestStatusErrorErrors {
}
export declare function computeRegionResizeRequestStatusErrorErrorsToTerraform(struct?: ComputeRegionResizeRequestStatusErrorErrors): any;
export declare function computeRegionResizeRequestStatusErrorErrorsToHclTerraform(struct?: ComputeRegionResizeRequestStatusErrorErrors): any;
export declare class ComputeRegionResizeRequestStatusErrorErrorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionResizeRequestStatusErrorErrors | undefined;
    set internalValue(value: ComputeRegionResizeRequestStatusErrorErrors | undefined);
    get code(): string;
    private _errorDetails;
    get errorDetails(): ComputeRegionResizeRequestStatusErrorErrorsErrorDetailsList;
    get location(): string;
    get message(): string;
}
export declare class ComputeRegionResizeRequestStatusErrorErrorsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionResizeRequestStatusErrorErrorsOutputReference;
}
export interface ComputeRegionResizeRequestStatusError {
}
export declare function computeRegionResizeRequestStatusErrorToTerraform(struct?: ComputeRegionResizeRequestStatusError): any;
export declare function computeRegionResizeRequestStatusErrorToHclTerraform(struct?: ComputeRegionResizeRequestStatusError): any;
export declare class ComputeRegionResizeRequestStatusErrorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionResizeRequestStatusError | undefined;
    set internalValue(value: ComputeRegionResizeRequestStatusError | undefined);
    private _errors;
    get errors(): ComputeRegionResizeRequestStatusErrorErrorsList;
}
export declare class ComputeRegionResizeRequestStatusErrorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionResizeRequestStatusErrorOutputReference;
}
export interface ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsErrorInfo {
}
export declare function computeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsErrorInfoToTerraform(struct?: ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsErrorInfo): any;
export declare function computeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsErrorInfoToHclTerraform(struct?: ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsErrorInfo): any;
export declare class ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsErrorInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsErrorInfo | undefined;
    set internalValue(value: ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsErrorInfo | undefined);
    get domain(): string;
    private _metadatas;
    get metadatas(): cdktn.StringMap;
    get reason(): string;
}
export declare class ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsErrorInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsErrorInfoOutputReference;
}
export interface ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpLinks {
}
export declare function computeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpLinksToTerraform(struct?: ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpLinks): any;
export declare function computeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpLinksToHclTerraform(struct?: ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpLinks): any;
export declare class ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpLinksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpLinks | undefined;
    set internalValue(value: ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpLinks | undefined);
    get description(): string;
    get url(): string;
}
export declare class ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpLinksList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpLinksOutputReference;
}
export interface ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelp {
}
export declare function computeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpToTerraform(struct?: ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelp): any;
export declare function computeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpToHclTerraform(struct?: ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelp): any;
export declare class ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelp | undefined;
    set internalValue(value: ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelp | undefined);
    private _links;
    get links(): ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpLinksList;
}
export declare class ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpOutputReference;
}
export interface ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsLocalizedMessage {
}
export declare function computeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsLocalizedMessageToTerraform(struct?: ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsLocalizedMessage): any;
export declare function computeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsLocalizedMessageToHclTerraform(struct?: ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsLocalizedMessage): any;
export declare class ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsLocalizedMessageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsLocalizedMessage | undefined;
    set internalValue(value: ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsLocalizedMessage | undefined);
    get locale(): string;
    get message(): string;
}
export declare class ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsLocalizedMessageList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsLocalizedMessageOutputReference;
}
export interface ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsQuotaInfo {
}
export declare function computeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsQuotaInfoToTerraform(struct?: ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsQuotaInfo): any;
export declare function computeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsQuotaInfoToHclTerraform(struct?: ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsQuotaInfo): any;
export declare class ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsQuotaInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsQuotaInfo | undefined;
    set internalValue(value: ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsQuotaInfo | undefined);
    private _dimensions;
    get dimensions(): cdktn.StringMap;
    get futureLimit(): number;
    get limit(): number;
    get limitName(): string;
    get metricName(): string;
    get rolloutStatus(): string;
}
export declare class ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsQuotaInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsQuotaInfoOutputReference;
}
export interface ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetails {
}
export declare function computeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsToTerraform(struct?: ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetails): any;
export declare function computeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsToHclTerraform(struct?: ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetails): any;
export declare class ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetails | undefined;
    set internalValue(value: ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetails | undefined);
    private _errorInfo;
    get errorInfo(): ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsErrorInfoList;
    private _help;
    get help(): ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsHelpList;
    private _localizedMessage;
    get localizedMessage(): ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsLocalizedMessageList;
    private _quotaInfo;
    get quotaInfo(): ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsQuotaInfoList;
}
export declare class ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsOutputReference;
}
export interface ComputeRegionResizeRequestStatusLastAttemptErrorErrors {
}
export declare function computeRegionResizeRequestStatusLastAttemptErrorErrorsToTerraform(struct?: ComputeRegionResizeRequestStatusLastAttemptErrorErrors): any;
export declare function computeRegionResizeRequestStatusLastAttemptErrorErrorsToHclTerraform(struct?: ComputeRegionResizeRequestStatusLastAttemptErrorErrors): any;
export declare class ComputeRegionResizeRequestStatusLastAttemptErrorErrorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionResizeRequestStatusLastAttemptErrorErrors | undefined;
    set internalValue(value: ComputeRegionResizeRequestStatusLastAttemptErrorErrors | undefined);
    get code(): string;
    private _errorDetails;
    get errorDetails(): ComputeRegionResizeRequestStatusLastAttemptErrorErrorsErrorDetailsList;
    get location(): string;
    get message(): string;
}
export declare class ComputeRegionResizeRequestStatusLastAttemptErrorErrorsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionResizeRequestStatusLastAttemptErrorErrorsOutputReference;
}
export interface ComputeRegionResizeRequestStatusLastAttemptError {
}
export declare function computeRegionResizeRequestStatusLastAttemptErrorToTerraform(struct?: ComputeRegionResizeRequestStatusLastAttemptError): any;
export declare function computeRegionResizeRequestStatusLastAttemptErrorToHclTerraform(struct?: ComputeRegionResizeRequestStatusLastAttemptError): any;
export declare class ComputeRegionResizeRequestStatusLastAttemptErrorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionResizeRequestStatusLastAttemptError | undefined;
    set internalValue(value: ComputeRegionResizeRequestStatusLastAttemptError | undefined);
    private _errors;
    get errors(): ComputeRegionResizeRequestStatusLastAttemptErrorErrorsList;
}
export declare class ComputeRegionResizeRequestStatusLastAttemptErrorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionResizeRequestStatusLastAttemptErrorOutputReference;
}
export interface ComputeRegionResizeRequestStatusLastAttempt {
}
export declare function computeRegionResizeRequestStatusLastAttemptToTerraform(struct?: ComputeRegionResizeRequestStatusLastAttempt): any;
export declare function computeRegionResizeRequestStatusLastAttemptToHclTerraform(struct?: ComputeRegionResizeRequestStatusLastAttempt): any;
export declare class ComputeRegionResizeRequestStatusLastAttemptOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionResizeRequestStatusLastAttempt | undefined;
    set internalValue(value: ComputeRegionResizeRequestStatusLastAttempt | undefined);
    private _error;
    get error(): ComputeRegionResizeRequestStatusLastAttemptErrorList;
}
export declare class ComputeRegionResizeRequestStatusLastAttemptList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionResizeRequestStatusLastAttemptOutputReference;
}
export interface ComputeRegionResizeRequestStatus {
}
export declare function computeRegionResizeRequestStatusToTerraform(struct?: ComputeRegionResizeRequestStatus): any;
export declare function computeRegionResizeRequestStatusToHclTerraform(struct?: ComputeRegionResizeRequestStatus): any;
export declare class ComputeRegionResizeRequestStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionResizeRequestStatus | undefined;
    set internalValue(value: ComputeRegionResizeRequestStatus | undefined);
    private _error;
    get error(): ComputeRegionResizeRequestStatusErrorList;
    private _lastAttempt;
    get lastAttempt(): ComputeRegionResizeRequestStatusLastAttemptList;
}
export declare class ComputeRegionResizeRequestStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionResizeRequestStatusOutputReference;
}
export interface ComputeRegionResizeRequestRequestedRunDuration {
    /**
    * Span of time that's a fraction of a second at nanosecond resolution. Durations less than one second are represented with a 0 seconds field and a positive nanos field. Must be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_resize_request#nanos ComputeRegionResizeRequest#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second. Must be from 600 to 604800 inclusive. Note: minimum and maximum allowed range for requestedRunDuration is 10 minutes (600 seconds) and 7 days(604800 seconds) correspondingly.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_resize_request#seconds ComputeRegionResizeRequest#seconds}
    */
    readonly seconds: string;
}
export declare function computeRegionResizeRequestRequestedRunDurationToTerraform(struct?: ComputeRegionResizeRequestRequestedRunDurationOutputReference | ComputeRegionResizeRequestRequestedRunDuration): any;
export declare function computeRegionResizeRequestRequestedRunDurationToHclTerraform(struct?: ComputeRegionResizeRequestRequestedRunDurationOutputReference | ComputeRegionResizeRequestRequestedRunDuration): any;
export declare class ComputeRegionResizeRequestRequestedRunDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionResizeRequestRequestedRunDuration | undefined;
    set internalValue(value: ComputeRegionResizeRequestRequestedRunDuration | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): string;
    set seconds(value: string);
    get secondsInput(): string | undefined;
}
export interface ComputeRegionResizeRequestTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_resize_request#create ComputeRegionResizeRequest#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_resize_request#delete ComputeRegionResizeRequest#delete}
    */
    readonly delete?: string;
}
export declare function computeRegionResizeRequestTimeoutsToTerraform(struct?: ComputeRegionResizeRequestTimeouts | cdktn.IResolvable): any;
export declare function computeRegionResizeRequestTimeoutsToHclTerraform(struct?: ComputeRegionResizeRequestTimeouts | cdktn.IResolvable): any;
export declare class ComputeRegionResizeRequestTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionResizeRequestTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionResizeRequestTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_resize_request google_compute_region_resize_request}
*/
export declare class ComputeRegionResizeRequest extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_region_resize_request";
    /**
    * Generates CDKTN code for importing a ComputeRegionResizeRequest resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeRegionResizeRequest to import
    * @param importFromId The id of the existing ComputeRegionResizeRequest that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_resize_request#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeRegionResizeRequest to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_resize_request google_compute_region_resize_request} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeRegionResizeRequestConfig
    */
    constructor(scope: Construct, id: string, config: ComputeRegionResizeRequestConfig);
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceGroupManager?;
    get instanceGroupManager(): string;
    set instanceGroupManager(value: string);
    get instanceGroupManagerInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resizeBy?;
    get resizeBy(): number;
    set resizeBy(value: number);
    get resizeByInput(): number | undefined;
    get state(): string;
    private _status;
    get status(): ComputeRegionResizeRequestStatusList;
    private _requestedRunDuration;
    get requestedRunDuration(): ComputeRegionResizeRequestRequestedRunDurationOutputReference;
    putRequestedRunDuration(value: ComputeRegionResizeRequestRequestedRunDuration): void;
    resetRequestedRunDuration(): void;
    get requestedRunDurationInput(): ComputeRegionResizeRequestRequestedRunDuration | undefined;
    private _timeouts;
    get timeouts(): ComputeRegionResizeRequestTimeoutsOutputReference;
    putTimeouts(value: ComputeRegionResizeRequestTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeRegionResizeRequestTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
