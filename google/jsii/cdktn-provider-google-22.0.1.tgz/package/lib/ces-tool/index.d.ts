/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CesToolConfig extends cdktn.TerraformMetaArguments {
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#app CesTool#app}
    */
    readonly app: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#deletion_policy CesTool#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Possible values:
    * SYNCHRONOUS
    * ASYNCHRONOUS
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#execution_type CesTool#execution_type}
    */
    readonly executionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#id CesTool#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#location CesTool#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#project CesTool#project}
    */
    readonly project?: string;
    /**
    * The timeout for the tool execution. If not set, the default timeout is 30
    * seconds for SYNCHRONOUS tools and 60 seconds for ASYNCHRONOUS tools.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#timeout CesTool#timeout}
    */
    readonly timeout?: string;
    /**
    * The ID to use for the tool, which will become the final component of
    * the tool's resource name. If not provided, a unique ID will be
    * automatically assigned for the tool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#tool_id CesTool#tool_id}
    */
    readonly toolId: string;
    /**
    * agent_tool block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#agent_tool CesTool#agent_tool}
    */
    readonly agentTool?: CesToolAgentTool;
    /**
    * client_function block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#client_function CesTool#client_function}
    */
    readonly clientFunction?: CesToolClientFunction;
    /**
    * data_store_tool block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#data_store_tool CesTool#data_store_tool}
    */
    readonly dataStoreTool?: CesToolDataStoreTool;
    /**
    * file_search_tool block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#file_search_tool CesTool#file_search_tool}
    */
    readonly fileSearchTool?: CesToolFileSearchTool;
    /**
    * google_search_tool block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#google_search_tool CesTool#google_search_tool}
    */
    readonly googleSearchTool?: CesToolGoogleSearchTool;
    /**
    * python_function block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#python_function CesTool#python_function}
    */
    readonly pythonFunction?: CesToolPythonFunction;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#timeouts CesTool#timeouts}
    */
    readonly timeouts?: CesToolTimeouts;
    /**
    * tool_fake_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#tool_fake_config CesTool#tool_fake_config}
    */
    readonly toolFakeConfig?: CesToolToolFakeConfig;
    /**
    * widget_tool block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#widget_tool CesTool#widget_tool}
    */
    readonly widgetTool?: CesToolWidgetTool;
}
export interface CesToolConnectorToolActionEntityOperation {
}
export declare function cesToolConnectorToolActionEntityOperationToTerraform(struct?: CesToolConnectorToolActionEntityOperation): any;
export declare function cesToolConnectorToolActionEntityOperationToHclTerraform(struct?: CesToolConnectorToolActionEntityOperation): any;
export declare class CesToolConnectorToolActionEntityOperationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolConnectorToolActionEntityOperation | undefined;
    set internalValue(value: CesToolConnectorToolActionEntityOperation | undefined);
    get entityId(): string;
    get operation(): string;
}
export declare class CesToolConnectorToolActionEntityOperationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolConnectorToolActionEntityOperationOutputReference;
}
export interface CesToolConnectorToolAction {
}
export declare function cesToolConnectorToolActionToTerraform(struct?: CesToolConnectorToolAction): any;
export declare function cesToolConnectorToolActionToHclTerraform(struct?: CesToolConnectorToolAction): any;
export declare class CesToolConnectorToolActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolConnectorToolAction | undefined;
    set internalValue(value: CesToolConnectorToolAction | undefined);
    get connectionActionId(): string;
    private _entityOperation;
    get entityOperation(): CesToolConnectorToolActionEntityOperationList;
    get inputFields(): string[];
    get outputFields(): string[];
}
export declare class CesToolConnectorToolActionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolConnectorToolActionOutputReference;
}
export interface CesToolConnectorTool {
}
export declare function cesToolConnectorToolToTerraform(struct?: CesToolConnectorTool): any;
export declare function cesToolConnectorToolToHclTerraform(struct?: CesToolConnectorTool): any;
export declare class CesToolConnectorToolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolConnectorTool | undefined;
    set internalValue(value: CesToolConnectorTool | undefined);
    private _action;
    get action(): CesToolConnectorToolActionList;
    get authConfig(): string;
    get connection(): string;
    get description(): string;
    get name(): string;
}
export declare class CesToolConnectorToolList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolConnectorToolOutputReference;
}
export interface CesToolMcpToolApiAuthenticationApiKeyConfig {
}
export declare function cesToolMcpToolApiAuthenticationApiKeyConfigToTerraform(struct?: CesToolMcpToolApiAuthenticationApiKeyConfig): any;
export declare function cesToolMcpToolApiAuthenticationApiKeyConfigToHclTerraform(struct?: CesToolMcpToolApiAuthenticationApiKeyConfig): any;
export declare class CesToolMcpToolApiAuthenticationApiKeyConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolMcpToolApiAuthenticationApiKeyConfig | undefined;
    set internalValue(value: CesToolMcpToolApiAuthenticationApiKeyConfig | undefined);
    get apiKeySecretVersion(): string;
    get keyName(): string;
    get requestLocation(): string;
}
export declare class CesToolMcpToolApiAuthenticationApiKeyConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolMcpToolApiAuthenticationApiKeyConfigOutputReference;
}
export interface CesToolMcpToolApiAuthenticationBearerTokenConfig {
}
export declare function cesToolMcpToolApiAuthenticationBearerTokenConfigToTerraform(struct?: CesToolMcpToolApiAuthenticationBearerTokenConfig): any;
export declare function cesToolMcpToolApiAuthenticationBearerTokenConfigToHclTerraform(struct?: CesToolMcpToolApiAuthenticationBearerTokenConfig): any;
export declare class CesToolMcpToolApiAuthenticationBearerTokenConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolMcpToolApiAuthenticationBearerTokenConfig | undefined;
    set internalValue(value: CesToolMcpToolApiAuthenticationBearerTokenConfig | undefined);
    get token(): string;
}
export declare class CesToolMcpToolApiAuthenticationBearerTokenConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolMcpToolApiAuthenticationBearerTokenConfigOutputReference;
}
export interface CesToolMcpToolApiAuthenticationOauthConfig {
}
export declare function cesToolMcpToolApiAuthenticationOauthConfigToTerraform(struct?: CesToolMcpToolApiAuthenticationOauthConfig): any;
export declare function cesToolMcpToolApiAuthenticationOauthConfigToHclTerraform(struct?: CesToolMcpToolApiAuthenticationOauthConfig): any;
export declare class CesToolMcpToolApiAuthenticationOauthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolMcpToolApiAuthenticationOauthConfig | undefined;
    set internalValue(value: CesToolMcpToolApiAuthenticationOauthConfig | undefined);
    get clientId(): string;
    get clientSecretVersion(): string;
    get oauthGrantType(): string;
    get scopes(): string[];
    get tokenEndpoint(): string;
}
export declare class CesToolMcpToolApiAuthenticationOauthConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolMcpToolApiAuthenticationOauthConfigOutputReference;
}
export interface CesToolMcpToolApiAuthenticationServiceAccountAuthConfig {
}
export declare function cesToolMcpToolApiAuthenticationServiceAccountAuthConfigToTerraform(struct?: CesToolMcpToolApiAuthenticationServiceAccountAuthConfig): any;
export declare function cesToolMcpToolApiAuthenticationServiceAccountAuthConfigToHclTerraform(struct?: CesToolMcpToolApiAuthenticationServiceAccountAuthConfig): any;
export declare class CesToolMcpToolApiAuthenticationServiceAccountAuthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolMcpToolApiAuthenticationServiceAccountAuthConfig | undefined;
    set internalValue(value: CesToolMcpToolApiAuthenticationServiceAccountAuthConfig | undefined);
    get scopes(): string[];
    get serviceAccount(): string;
}
export declare class CesToolMcpToolApiAuthenticationServiceAccountAuthConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolMcpToolApiAuthenticationServiceAccountAuthConfigOutputReference;
}
export interface CesToolMcpToolApiAuthenticationServiceAgentIdTokenAuthConfig {
}
export declare function cesToolMcpToolApiAuthenticationServiceAgentIdTokenAuthConfigToTerraform(struct?: CesToolMcpToolApiAuthenticationServiceAgentIdTokenAuthConfig): any;
export declare function cesToolMcpToolApiAuthenticationServiceAgentIdTokenAuthConfigToHclTerraform(struct?: CesToolMcpToolApiAuthenticationServiceAgentIdTokenAuthConfig): any;
export declare class CesToolMcpToolApiAuthenticationServiceAgentIdTokenAuthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolMcpToolApiAuthenticationServiceAgentIdTokenAuthConfig | undefined;
    set internalValue(value: CesToolMcpToolApiAuthenticationServiceAgentIdTokenAuthConfig | undefined);
}
export declare class CesToolMcpToolApiAuthenticationServiceAgentIdTokenAuthConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolMcpToolApiAuthenticationServiceAgentIdTokenAuthConfigOutputReference;
}
export interface CesToolMcpToolApiAuthentication {
}
export declare function cesToolMcpToolApiAuthenticationToTerraform(struct?: CesToolMcpToolApiAuthentication): any;
export declare function cesToolMcpToolApiAuthenticationToHclTerraform(struct?: CesToolMcpToolApiAuthentication): any;
export declare class CesToolMcpToolApiAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolMcpToolApiAuthentication | undefined;
    set internalValue(value: CesToolMcpToolApiAuthentication | undefined);
    private _apiKeyConfig;
    get apiKeyConfig(): CesToolMcpToolApiAuthenticationApiKeyConfigList;
    private _bearerTokenConfig;
    get bearerTokenConfig(): CesToolMcpToolApiAuthenticationBearerTokenConfigList;
    private _oauthConfig;
    get oauthConfig(): CesToolMcpToolApiAuthenticationOauthConfigList;
    private _serviceAccountAuthConfig;
    get serviceAccountAuthConfig(): CesToolMcpToolApiAuthenticationServiceAccountAuthConfigList;
    private _serviceAgentIdTokenAuthConfig;
    get serviceAgentIdTokenAuthConfig(): CesToolMcpToolApiAuthenticationServiceAgentIdTokenAuthConfigList;
}
export declare class CesToolMcpToolApiAuthenticationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolMcpToolApiAuthenticationOutputReference;
}
export interface CesToolMcpToolServiceDirectoryConfig {
}
export declare function cesToolMcpToolServiceDirectoryConfigToTerraform(struct?: CesToolMcpToolServiceDirectoryConfig): any;
export declare function cesToolMcpToolServiceDirectoryConfigToHclTerraform(struct?: CesToolMcpToolServiceDirectoryConfig): any;
export declare class CesToolMcpToolServiceDirectoryConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolMcpToolServiceDirectoryConfig | undefined;
    set internalValue(value: CesToolMcpToolServiceDirectoryConfig | undefined);
    get service(): string;
}
export declare class CesToolMcpToolServiceDirectoryConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolMcpToolServiceDirectoryConfigOutputReference;
}
export interface CesToolMcpToolTlsConfigCaCerts {
}
export declare function cesToolMcpToolTlsConfigCaCertsToTerraform(struct?: CesToolMcpToolTlsConfigCaCerts): any;
export declare function cesToolMcpToolTlsConfigCaCertsToHclTerraform(struct?: CesToolMcpToolTlsConfigCaCerts): any;
export declare class CesToolMcpToolTlsConfigCaCertsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolMcpToolTlsConfigCaCerts | undefined;
    set internalValue(value: CesToolMcpToolTlsConfigCaCerts | undefined);
    get cert(): string;
    get displayName(): string;
}
export declare class CesToolMcpToolTlsConfigCaCertsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolMcpToolTlsConfigCaCertsOutputReference;
}
export interface CesToolMcpToolTlsConfig {
}
export declare function cesToolMcpToolTlsConfigToTerraform(struct?: CesToolMcpToolTlsConfig): any;
export declare function cesToolMcpToolTlsConfigToHclTerraform(struct?: CesToolMcpToolTlsConfig): any;
export declare class CesToolMcpToolTlsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolMcpToolTlsConfig | undefined;
    set internalValue(value: CesToolMcpToolTlsConfig | undefined);
    private _caCerts;
    get caCerts(): CesToolMcpToolTlsConfigCaCertsList;
}
export declare class CesToolMcpToolTlsConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolMcpToolTlsConfigOutputReference;
}
export interface CesToolMcpTool {
}
export declare function cesToolMcpToolToTerraform(struct?: CesToolMcpTool): any;
export declare function cesToolMcpToolToHclTerraform(struct?: CesToolMcpTool): any;
export declare class CesToolMcpToolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolMcpTool | undefined;
    set internalValue(value: CesToolMcpTool | undefined);
    private _apiAuthentication;
    get apiAuthentication(): CesToolMcpToolApiAuthenticationList;
    private _customHeaders;
    get customHeaders(): cdktn.StringMap;
    get description(): string;
    get inputSchema(): string;
    get name(): string;
    get nameOverride(): string;
    get outputSchema(): string;
    get serverAddress(): string;
    private _serviceDirectoryConfig;
    get serviceDirectoryConfig(): CesToolMcpToolServiceDirectoryConfigList;
    get state(): string;
    private _tlsConfig;
    get tlsConfig(): CesToolMcpToolTlsConfigList;
}
export declare class CesToolMcpToolList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolMcpToolOutputReference;
}
export interface CesToolOpenApiToolApiAuthenticationApiKeyConfig {
}
export declare function cesToolOpenApiToolApiAuthenticationApiKeyConfigToTerraform(struct?: CesToolOpenApiToolApiAuthenticationApiKeyConfig): any;
export declare function cesToolOpenApiToolApiAuthenticationApiKeyConfigToHclTerraform(struct?: CesToolOpenApiToolApiAuthenticationApiKeyConfig): any;
export declare class CesToolOpenApiToolApiAuthenticationApiKeyConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolOpenApiToolApiAuthenticationApiKeyConfig | undefined;
    set internalValue(value: CesToolOpenApiToolApiAuthenticationApiKeyConfig | undefined);
    get apiKeySecretVersion(): string;
    get keyName(): string;
    get requestLocation(): string;
}
export declare class CesToolOpenApiToolApiAuthenticationApiKeyConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolOpenApiToolApiAuthenticationApiKeyConfigOutputReference;
}
export interface CesToolOpenApiToolApiAuthenticationBearerTokenConfig {
}
export declare function cesToolOpenApiToolApiAuthenticationBearerTokenConfigToTerraform(struct?: CesToolOpenApiToolApiAuthenticationBearerTokenConfig): any;
export declare function cesToolOpenApiToolApiAuthenticationBearerTokenConfigToHclTerraform(struct?: CesToolOpenApiToolApiAuthenticationBearerTokenConfig): any;
export declare class CesToolOpenApiToolApiAuthenticationBearerTokenConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolOpenApiToolApiAuthenticationBearerTokenConfig | undefined;
    set internalValue(value: CesToolOpenApiToolApiAuthenticationBearerTokenConfig | undefined);
    get token(): string;
}
export declare class CesToolOpenApiToolApiAuthenticationBearerTokenConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolOpenApiToolApiAuthenticationBearerTokenConfigOutputReference;
}
export interface CesToolOpenApiToolApiAuthenticationOauthConfig {
}
export declare function cesToolOpenApiToolApiAuthenticationOauthConfigToTerraform(struct?: CesToolOpenApiToolApiAuthenticationOauthConfig): any;
export declare function cesToolOpenApiToolApiAuthenticationOauthConfigToHclTerraform(struct?: CesToolOpenApiToolApiAuthenticationOauthConfig): any;
export declare class CesToolOpenApiToolApiAuthenticationOauthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolOpenApiToolApiAuthenticationOauthConfig | undefined;
    set internalValue(value: CesToolOpenApiToolApiAuthenticationOauthConfig | undefined);
    get clientId(): string;
    get clientSecretVersion(): string;
    get oauthGrantType(): string;
    get scopes(): string[];
    get tokenEndpoint(): string;
}
export declare class CesToolOpenApiToolApiAuthenticationOauthConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolOpenApiToolApiAuthenticationOauthConfigOutputReference;
}
export interface CesToolOpenApiToolApiAuthenticationServiceAccountAuthConfig {
}
export declare function cesToolOpenApiToolApiAuthenticationServiceAccountAuthConfigToTerraform(struct?: CesToolOpenApiToolApiAuthenticationServiceAccountAuthConfig): any;
export declare function cesToolOpenApiToolApiAuthenticationServiceAccountAuthConfigToHclTerraform(struct?: CesToolOpenApiToolApiAuthenticationServiceAccountAuthConfig): any;
export declare class CesToolOpenApiToolApiAuthenticationServiceAccountAuthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolOpenApiToolApiAuthenticationServiceAccountAuthConfig | undefined;
    set internalValue(value: CesToolOpenApiToolApiAuthenticationServiceAccountAuthConfig | undefined);
    get scopes(): string[];
    get serviceAccount(): string;
}
export declare class CesToolOpenApiToolApiAuthenticationServiceAccountAuthConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolOpenApiToolApiAuthenticationServiceAccountAuthConfigOutputReference;
}
export interface CesToolOpenApiToolApiAuthenticationServiceAgentIdTokenAuthConfig {
}
export declare function cesToolOpenApiToolApiAuthenticationServiceAgentIdTokenAuthConfigToTerraform(struct?: CesToolOpenApiToolApiAuthenticationServiceAgentIdTokenAuthConfig): any;
export declare function cesToolOpenApiToolApiAuthenticationServiceAgentIdTokenAuthConfigToHclTerraform(struct?: CesToolOpenApiToolApiAuthenticationServiceAgentIdTokenAuthConfig): any;
export declare class CesToolOpenApiToolApiAuthenticationServiceAgentIdTokenAuthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolOpenApiToolApiAuthenticationServiceAgentIdTokenAuthConfig | undefined;
    set internalValue(value: CesToolOpenApiToolApiAuthenticationServiceAgentIdTokenAuthConfig | undefined);
}
export declare class CesToolOpenApiToolApiAuthenticationServiceAgentIdTokenAuthConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolOpenApiToolApiAuthenticationServiceAgentIdTokenAuthConfigOutputReference;
}
export interface CesToolOpenApiToolApiAuthentication {
}
export declare function cesToolOpenApiToolApiAuthenticationToTerraform(struct?: CesToolOpenApiToolApiAuthentication): any;
export declare function cesToolOpenApiToolApiAuthenticationToHclTerraform(struct?: CesToolOpenApiToolApiAuthentication): any;
export declare class CesToolOpenApiToolApiAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolOpenApiToolApiAuthentication | undefined;
    set internalValue(value: CesToolOpenApiToolApiAuthentication | undefined);
    private _apiKeyConfig;
    get apiKeyConfig(): CesToolOpenApiToolApiAuthenticationApiKeyConfigList;
    private _bearerTokenConfig;
    get bearerTokenConfig(): CesToolOpenApiToolApiAuthenticationBearerTokenConfigList;
    private _oauthConfig;
    get oauthConfig(): CesToolOpenApiToolApiAuthenticationOauthConfigList;
    private _serviceAccountAuthConfig;
    get serviceAccountAuthConfig(): CesToolOpenApiToolApiAuthenticationServiceAccountAuthConfigList;
    private _serviceAgentIdTokenAuthConfig;
    get serviceAgentIdTokenAuthConfig(): CesToolOpenApiToolApiAuthenticationServiceAgentIdTokenAuthConfigList;
}
export declare class CesToolOpenApiToolApiAuthenticationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolOpenApiToolApiAuthenticationOutputReference;
}
export interface CesToolOpenApiToolServiceDirectoryConfig {
}
export declare function cesToolOpenApiToolServiceDirectoryConfigToTerraform(struct?: CesToolOpenApiToolServiceDirectoryConfig): any;
export declare function cesToolOpenApiToolServiceDirectoryConfigToHclTerraform(struct?: CesToolOpenApiToolServiceDirectoryConfig): any;
export declare class CesToolOpenApiToolServiceDirectoryConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolOpenApiToolServiceDirectoryConfig | undefined;
    set internalValue(value: CesToolOpenApiToolServiceDirectoryConfig | undefined);
    get service(): string;
}
export declare class CesToolOpenApiToolServiceDirectoryConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolOpenApiToolServiceDirectoryConfigOutputReference;
}
export interface CesToolOpenApiToolTlsConfigCaCerts {
}
export declare function cesToolOpenApiToolTlsConfigCaCertsToTerraform(struct?: CesToolOpenApiToolTlsConfigCaCerts): any;
export declare function cesToolOpenApiToolTlsConfigCaCertsToHclTerraform(struct?: CesToolOpenApiToolTlsConfigCaCerts): any;
export declare class CesToolOpenApiToolTlsConfigCaCertsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolOpenApiToolTlsConfigCaCerts | undefined;
    set internalValue(value: CesToolOpenApiToolTlsConfigCaCerts | undefined);
    get cert(): string;
    get displayName(): string;
}
export declare class CesToolOpenApiToolTlsConfigCaCertsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolOpenApiToolTlsConfigCaCertsOutputReference;
}
export interface CesToolOpenApiToolTlsConfig {
}
export declare function cesToolOpenApiToolTlsConfigToTerraform(struct?: CesToolOpenApiToolTlsConfig): any;
export declare function cesToolOpenApiToolTlsConfigToHclTerraform(struct?: CesToolOpenApiToolTlsConfig): any;
export declare class CesToolOpenApiToolTlsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolOpenApiToolTlsConfig | undefined;
    set internalValue(value: CesToolOpenApiToolTlsConfig | undefined);
    private _caCerts;
    get caCerts(): CesToolOpenApiToolTlsConfigCaCertsList;
}
export declare class CesToolOpenApiToolTlsConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolOpenApiToolTlsConfigOutputReference;
}
export interface CesToolOpenApiTool {
}
export declare function cesToolOpenApiToolToTerraform(struct?: CesToolOpenApiTool): any;
export declare function cesToolOpenApiToolToHclTerraform(struct?: CesToolOpenApiTool): any;
export declare class CesToolOpenApiToolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolOpenApiTool | undefined;
    set internalValue(value: CesToolOpenApiTool | undefined);
    private _apiAuthentication;
    get apiAuthentication(): CesToolOpenApiToolApiAuthenticationList;
    get description(): string;
    get ignoreUnknownFields(): cdktn.IResolvable;
    get name(): string;
    get openApiSchema(): string;
    private _serviceDirectoryConfig;
    get serviceDirectoryConfig(): CesToolOpenApiToolServiceDirectoryConfigList;
    private _tlsConfig;
    get tlsConfig(): CesToolOpenApiToolTlsConfigList;
    get url(): string;
}
export declare class CesToolOpenApiToolList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolOpenApiToolOutputReference;
}
export interface CesToolRemoteAgentToolAgentCardSkills {
}
export declare function cesToolRemoteAgentToolAgentCardSkillsToTerraform(struct?: CesToolRemoteAgentToolAgentCardSkills): any;
export declare function cesToolRemoteAgentToolAgentCardSkillsToHclTerraform(struct?: CesToolRemoteAgentToolAgentCardSkills): any;
export declare class CesToolRemoteAgentToolAgentCardSkillsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolRemoteAgentToolAgentCardSkills | undefined;
    set internalValue(value: CesToolRemoteAgentToolAgentCardSkills | undefined);
    get description(): string;
    get examples(): string[];
    get id(): string;
    get inputModes(): string[];
    get name(): string;
    get outputModes(): string[];
    get tags(): string[];
}
export declare class CesToolRemoteAgentToolAgentCardSkillsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolRemoteAgentToolAgentCardSkillsOutputReference;
}
export interface CesToolRemoteAgentToolAgentCardSupportedInterfaces {
}
export declare function cesToolRemoteAgentToolAgentCardSupportedInterfacesToTerraform(struct?: CesToolRemoteAgentToolAgentCardSupportedInterfaces): any;
export declare function cesToolRemoteAgentToolAgentCardSupportedInterfacesToHclTerraform(struct?: CesToolRemoteAgentToolAgentCardSupportedInterfaces): any;
export declare class CesToolRemoteAgentToolAgentCardSupportedInterfacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolRemoteAgentToolAgentCardSupportedInterfaces | undefined;
    set internalValue(value: CesToolRemoteAgentToolAgentCardSupportedInterfaces | undefined);
    get protocolBinding(): string;
    get protocolVersion(): string;
    get tenant(): string;
    get url(): string;
}
export declare class CesToolRemoteAgentToolAgentCardSupportedInterfacesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolRemoteAgentToolAgentCardSupportedInterfacesOutputReference;
}
export interface CesToolRemoteAgentToolAgentCard {
}
export declare function cesToolRemoteAgentToolAgentCardToTerraform(struct?: CesToolRemoteAgentToolAgentCard): any;
export declare function cesToolRemoteAgentToolAgentCardToHclTerraform(struct?: CesToolRemoteAgentToolAgentCard): any;
export declare class CesToolRemoteAgentToolAgentCardOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolRemoteAgentToolAgentCard | undefined;
    set internalValue(value: CesToolRemoteAgentToolAgentCard | undefined);
    get description(): string;
    get name(): string;
    private _skills;
    get skills(): CesToolRemoteAgentToolAgentCardSkillsList;
    private _supportedInterfaces;
    get supportedInterfaces(): CesToolRemoteAgentToolAgentCardSupportedInterfacesList;
    get version(): string;
}
export declare class CesToolRemoteAgentToolAgentCardList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolRemoteAgentToolAgentCardOutputReference;
}
export interface CesToolRemoteAgentToolApiAuthenticationApiKeyConfig {
}
export declare function cesToolRemoteAgentToolApiAuthenticationApiKeyConfigToTerraform(struct?: CesToolRemoteAgentToolApiAuthenticationApiKeyConfig): any;
export declare function cesToolRemoteAgentToolApiAuthenticationApiKeyConfigToHclTerraform(struct?: CesToolRemoteAgentToolApiAuthenticationApiKeyConfig): any;
export declare class CesToolRemoteAgentToolApiAuthenticationApiKeyConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolRemoteAgentToolApiAuthenticationApiKeyConfig | undefined;
    set internalValue(value: CesToolRemoteAgentToolApiAuthenticationApiKeyConfig | undefined);
    get apiKeySecretVersion(): string;
    get keyName(): string;
    get requestLocation(): string;
}
export declare class CesToolRemoteAgentToolApiAuthenticationApiKeyConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolRemoteAgentToolApiAuthenticationApiKeyConfigOutputReference;
}
export interface CesToolRemoteAgentToolApiAuthenticationBearerTokenConfig {
}
export declare function cesToolRemoteAgentToolApiAuthenticationBearerTokenConfigToTerraform(struct?: CesToolRemoteAgentToolApiAuthenticationBearerTokenConfig): any;
export declare function cesToolRemoteAgentToolApiAuthenticationBearerTokenConfigToHclTerraform(struct?: CesToolRemoteAgentToolApiAuthenticationBearerTokenConfig): any;
export declare class CesToolRemoteAgentToolApiAuthenticationBearerTokenConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolRemoteAgentToolApiAuthenticationBearerTokenConfig | undefined;
    set internalValue(value: CesToolRemoteAgentToolApiAuthenticationBearerTokenConfig | undefined);
    get token(): string;
}
export declare class CesToolRemoteAgentToolApiAuthenticationBearerTokenConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolRemoteAgentToolApiAuthenticationBearerTokenConfigOutputReference;
}
export interface CesToolRemoteAgentToolApiAuthenticationOauthConfig {
}
export declare function cesToolRemoteAgentToolApiAuthenticationOauthConfigToTerraform(struct?: CesToolRemoteAgentToolApiAuthenticationOauthConfig): any;
export declare function cesToolRemoteAgentToolApiAuthenticationOauthConfigToHclTerraform(struct?: CesToolRemoteAgentToolApiAuthenticationOauthConfig): any;
export declare class CesToolRemoteAgentToolApiAuthenticationOauthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolRemoteAgentToolApiAuthenticationOauthConfig | undefined;
    set internalValue(value: CesToolRemoteAgentToolApiAuthenticationOauthConfig | undefined);
    get clientId(): string;
    get clientSecretVersion(): string;
    get oauthGrantType(): string;
    get scopes(): string[];
    get tokenEndpoint(): string;
}
export declare class CesToolRemoteAgentToolApiAuthenticationOauthConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolRemoteAgentToolApiAuthenticationOauthConfigOutputReference;
}
export interface CesToolRemoteAgentToolApiAuthenticationServiceAccountAuthConfig {
}
export declare function cesToolRemoteAgentToolApiAuthenticationServiceAccountAuthConfigToTerraform(struct?: CesToolRemoteAgentToolApiAuthenticationServiceAccountAuthConfig): any;
export declare function cesToolRemoteAgentToolApiAuthenticationServiceAccountAuthConfigToHclTerraform(struct?: CesToolRemoteAgentToolApiAuthenticationServiceAccountAuthConfig): any;
export declare class CesToolRemoteAgentToolApiAuthenticationServiceAccountAuthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolRemoteAgentToolApiAuthenticationServiceAccountAuthConfig | undefined;
    set internalValue(value: CesToolRemoteAgentToolApiAuthenticationServiceAccountAuthConfig | undefined);
    get scopes(): string[];
    get serviceAccount(): string;
}
export declare class CesToolRemoteAgentToolApiAuthenticationServiceAccountAuthConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolRemoteAgentToolApiAuthenticationServiceAccountAuthConfigOutputReference;
}
export interface CesToolRemoteAgentToolApiAuthenticationServiceAgentIdTokenAuthConfig {
}
export declare function cesToolRemoteAgentToolApiAuthenticationServiceAgentIdTokenAuthConfigToTerraform(struct?: CesToolRemoteAgentToolApiAuthenticationServiceAgentIdTokenAuthConfig): any;
export declare function cesToolRemoteAgentToolApiAuthenticationServiceAgentIdTokenAuthConfigToHclTerraform(struct?: CesToolRemoteAgentToolApiAuthenticationServiceAgentIdTokenAuthConfig): any;
export declare class CesToolRemoteAgentToolApiAuthenticationServiceAgentIdTokenAuthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolRemoteAgentToolApiAuthenticationServiceAgentIdTokenAuthConfig | undefined;
    set internalValue(value: CesToolRemoteAgentToolApiAuthenticationServiceAgentIdTokenAuthConfig | undefined);
}
export declare class CesToolRemoteAgentToolApiAuthenticationServiceAgentIdTokenAuthConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolRemoteAgentToolApiAuthenticationServiceAgentIdTokenAuthConfigOutputReference;
}
export interface CesToolRemoteAgentToolApiAuthentication {
}
export declare function cesToolRemoteAgentToolApiAuthenticationToTerraform(struct?: CesToolRemoteAgentToolApiAuthentication): any;
export declare function cesToolRemoteAgentToolApiAuthenticationToHclTerraform(struct?: CesToolRemoteAgentToolApiAuthentication): any;
export declare class CesToolRemoteAgentToolApiAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolRemoteAgentToolApiAuthentication | undefined;
    set internalValue(value: CesToolRemoteAgentToolApiAuthentication | undefined);
    private _apiKeyConfig;
    get apiKeyConfig(): CesToolRemoteAgentToolApiAuthenticationApiKeyConfigList;
    private _bearerTokenConfig;
    get bearerTokenConfig(): CesToolRemoteAgentToolApiAuthenticationBearerTokenConfigList;
    private _oauthConfig;
    get oauthConfig(): CesToolRemoteAgentToolApiAuthenticationOauthConfigList;
    private _serviceAccountAuthConfig;
    get serviceAccountAuthConfig(): CesToolRemoteAgentToolApiAuthenticationServiceAccountAuthConfigList;
    private _serviceAgentIdTokenAuthConfig;
    get serviceAgentIdTokenAuthConfig(): CesToolRemoteAgentToolApiAuthenticationServiceAgentIdTokenAuthConfigList;
}
export declare class CesToolRemoteAgentToolApiAuthenticationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolRemoteAgentToolApiAuthenticationOutputReference;
}
export interface CesToolRemoteAgentTool {
}
export declare function cesToolRemoteAgentToolToTerraform(struct?: CesToolRemoteAgentTool): any;
export declare function cesToolRemoteAgentToolToHclTerraform(struct?: CesToolRemoteAgentTool): any;
export declare class CesToolRemoteAgentToolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolRemoteAgentTool | undefined;
    set internalValue(value: CesToolRemoteAgentTool | undefined);
    private _agentCard;
    get agentCard(): CesToolRemoteAgentToolAgentCardList;
    private _apiAuthentication;
    get apiAuthentication(): CesToolRemoteAgentToolApiAuthenticationList;
    get description(): string;
    private _inputVariableMapping;
    get inputVariableMapping(): cdktn.StringMap;
    get name(): string;
    private _outputVariableMapping;
    get outputVariableMapping(): cdktn.StringMap;
    get statefulAgent(): cdktn.IResolvable;
}
export declare class CesToolRemoteAgentToolList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolRemoteAgentToolOutputReference;
}
export interface CesToolSystemTool {
}
export declare function cesToolSystemToolToTerraform(struct?: CesToolSystemTool): any;
export declare function cesToolSystemToolToHclTerraform(struct?: CesToolSystemTool): any;
export declare class CesToolSystemToolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolSystemTool | undefined;
    set internalValue(value: CesToolSystemTool | undefined);
    get description(): string;
    get name(): string;
}
export declare class CesToolSystemToolList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolSystemToolOutputReference;
}
export interface CesToolAgentTool {
    /**
    * Optional. The resource name of the agent that is the entry point of the tool.
    * Format: projects/{project}/locations/{location}/agents/{agent}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#agent CesTool#agent}
    */
    readonly agent?: string;
    /**
    * Optional. Description of the tool's purpose.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#description CesTool#description}
    */
    readonly description?: string;
    /**
    * Required. The name of the agent tool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#name CesTool#name}
    */
    readonly name: string;
}
export declare function cesToolAgentToolToTerraform(struct?: CesToolAgentToolOutputReference | CesToolAgentTool): any;
export declare function cesToolAgentToolToHclTerraform(struct?: CesToolAgentToolOutputReference | CesToolAgentTool): any;
export declare class CesToolAgentToolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolAgentTool | undefined;
    set internalValue(value: CesToolAgentTool | undefined);
    private _agent?;
    get agent(): string;
    set agent(value: string);
    resetAgent(): void;
    get agentInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface CesToolClientFunctionParameters {
    /**
    * Defines the schema for additional properties allowed in an object.
    * The value must be a valid JSON string representing the Schema object.
    * (Note: OpenAPI also allows a boolean, this definition expects a Schema JSON).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#additional_properties CesTool#additional_properties}
    */
    readonly additionalProperties?: string;
    /**
    * The instance value should be valid against at least one of the schemas in this list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#any_of CesTool#any_of}
    */
    readonly anyOf?: string;
    /**
    * Default value of the data. Represents a dynamically typed value
    * which can be either null, a number, a string, a boolean, a struct,
    * or a list of values. The provided default value must be compatible
    * with the defined 'type' and other schema constraints.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#default CesTool#default}
    */
    readonly default?: string;
    /**
    * A map of definitions for use by ref. Only allowed at the root of the schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#defs CesTool#defs}
    */
    readonly defs?: string;
    /**
    * The description of the data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#description CesTool#description}
    */
    readonly description?: string;
    /**
    * Possible values of the element of primitive type with enum format.
    * Examples:
    * 1. We can define direction as :
    * {type:STRING, format:enum, enum:["EAST", NORTH", "SOUTH", "WEST"]}
    * 2. We can define apartment number as :
    * {type:INTEGER, format:enum, enum:["101", "201", "301"]}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#enum CesTool#enum}
    */
    readonly enum?: string[];
    /**
    * Schema of the elements of Type.ARRAY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#items CesTool#items}
    */
    readonly items?: string;
    /**
    * Maximum number of the elements for Type.ARRAY. (int64 format)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#max_items CesTool#max_items}
    */
    readonly maxItems?: number;
    /**
    * Maximum value for Type.INTEGER and Type.NUMBER.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#maximum CesTool#maximum}
    */
    readonly maximum?: number;
    /**
    * Minimum number of the elements for Type.ARRAY. (int64 format)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#min_items CesTool#min_items}
    */
    readonly minItems?: number;
    /**
    * Minimum value for Type.INTEGER and Type.NUMBER.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#minimum CesTool#minimum}
    */
    readonly minimum?: number;
    /**
    * Indicates if the value may be null.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#nullable CesTool#nullable}
    */
    readonly nullable?: boolean | cdktn.IResolvable;
    /**
    * Schemas of initial elements of Type.ARRAY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#prefix_items CesTool#prefix_items}
    */
    readonly prefixItems?: string;
    /**
    * Properties of Type.OBJECT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#properties CesTool#properties}
    */
    readonly properties?: string;
    /**
    * Allows indirect references between schema nodes. The value should be a
    * valid reference to a child of the root 'defs'.
    * For example, the following schema defines a reference to a schema node
    * named "Pet":
    * type: object
    * properties:
    *   pet:
    *     ref: #/defs/Pet
    * defs:
    *   Pet:
    *     type: object
    *     properties:
    *       name:
    *         type: string
    * The value of the "pet" property is a reference to the schema node
    * named "Pet".
    * See details in
    * https://json-schema.org/understanding-json-schema/structuring.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#ref CesTool#ref}
    */
    readonly ref?: string;
    /**
    * Required properties of Type.OBJECT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#required CesTool#required}
    */
    readonly required?: string[];
    /**
    * The title of the schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#title CesTool#title}
    */
    readonly title?: string;
    /**
    * The type of the data.
    * Possible values:
    * STRING
    * INTEGER
    * NUMBER
    * BOOLEAN
    * OBJECT
    * ARRAY
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#type CesTool#type}
    */
    readonly type: string;
    /**
    * Indicate the items in the array must be unique. Only applies to TYPE.ARRAY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#unique_items CesTool#unique_items}
    */
    readonly uniqueItems?: boolean | cdktn.IResolvable;
}
export declare function cesToolClientFunctionParametersToTerraform(struct?: CesToolClientFunctionParametersOutputReference | CesToolClientFunctionParameters): any;
export declare function cesToolClientFunctionParametersToHclTerraform(struct?: CesToolClientFunctionParametersOutputReference | CesToolClientFunctionParameters): any;
export declare class CesToolClientFunctionParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolClientFunctionParameters | undefined;
    set internalValue(value: CesToolClientFunctionParameters | undefined);
    private _additionalProperties?;
    get additionalProperties(): string;
    set additionalProperties(value: string);
    resetAdditionalProperties(): void;
    get additionalPropertiesInput(): string | undefined;
    private _anyOf?;
    get anyOf(): string;
    set anyOf(value: string);
    resetAnyOf(): void;
    get anyOfInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _defs?;
    get defs(): string;
    set defs(value: string);
    resetDefs(): void;
    get defsInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enum?;
    get enum(): string[];
    set enum(value: string[]);
    resetEnum(): void;
    get enumInput(): string[] | undefined;
    private _items?;
    get items(): string;
    set items(value: string);
    resetItems(): void;
    get itemsInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _maximum?;
    get maximum(): number;
    set maximum(value: number);
    resetMaximum(): void;
    get maximumInput(): number | undefined;
    private _minItems?;
    get minItems(): number;
    set minItems(value: number);
    resetMinItems(): void;
    get minItemsInput(): number | undefined;
    private _minimum?;
    get minimum(): number;
    set minimum(value: number);
    resetMinimum(): void;
    get minimumInput(): number | undefined;
    private _nullable?;
    get nullable(): boolean | cdktn.IResolvable;
    set nullable(value: boolean | cdktn.IResolvable);
    resetNullable(): void;
    get nullableInput(): boolean | cdktn.IResolvable | undefined;
    private _prefixItems?;
    get prefixItems(): string;
    set prefixItems(value: string);
    resetPrefixItems(): void;
    get prefixItemsInput(): string | undefined;
    private _properties?;
    get properties(): string;
    set properties(value: string);
    resetProperties(): void;
    get propertiesInput(): string | undefined;
    private _ref?;
    get ref(): string;
    set ref(value: string);
    resetRef(): void;
    get refInput(): string | undefined;
    private _required?;
    get required(): string[];
    set required(value: string[]);
    resetRequired(): void;
    get requiredInput(): string[] | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _uniqueItems?;
    get uniqueItems(): boolean | cdktn.IResolvable;
    set uniqueItems(value: boolean | cdktn.IResolvable);
    resetUniqueItems(): void;
    get uniqueItemsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CesToolClientFunctionResponse {
    /**
    * Defines the schema for additional properties allowed in an object.
    * The value must be a valid JSON string representing the Schema object.
    * (Note: OpenAPI also allows a boolean, this definition expects a Schema JSON).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#additional_properties CesTool#additional_properties}
    */
    readonly additionalProperties?: string;
    /**
    * The instance value should be valid against at least one of the schemas in this list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#any_of CesTool#any_of}
    */
    readonly anyOf?: string;
    /**
    * Default value of the data. Represents a dynamically typed value
    * which can be either null, a number, a string, a boolean, a struct,
    * or a list of values. The provided default value must be compatible
    * with the defined 'type' and other schema constraints.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#default CesTool#default}
    */
    readonly default?: string;
    /**
    * A map of definitions for use by ref. Only allowed at the root of the schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#defs CesTool#defs}
    */
    readonly defs?: string;
    /**
    * The description of the data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#description CesTool#description}
    */
    readonly description?: string;
    /**
    * Possible values of the element of primitive type with enum format.
    * Examples:
    * 1. We can define direction as :
    * {type:STRING, format:enum, enum:["EAST", NORTH", "SOUTH", "WEST"]}
    * 2. We can define apartment number as :
    * {type:INTEGER, format:enum, enum:["101", "201", "301"]}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#enum CesTool#enum}
    */
    readonly enum?: string[];
    /**
    * Schema of the elements of Type.ARRAY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#items CesTool#items}
    */
    readonly items?: string;
    /**
    * Maximum number of the elements for Type.ARRAY. (int64 format)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#max_items CesTool#max_items}
    */
    readonly maxItems?: number;
    /**
    * Maximum value for Type.INTEGER and Type.NUMBER.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#maximum CesTool#maximum}
    */
    readonly maximum?: number;
    /**
    * Minimum number of the elements for Type.ARRAY. (int64 format)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#min_items CesTool#min_items}
    */
    readonly minItems?: number;
    /**
    * Minimum value for Type.INTEGER and Type.NUMBER.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#minimum CesTool#minimum}
    */
    readonly minimum?: number;
    /**
    * Indicates if the value may be null.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#nullable CesTool#nullable}
    */
    readonly nullable?: boolean | cdktn.IResolvable;
    /**
    * Schemas of initial elements of Type.ARRAY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#prefix_items CesTool#prefix_items}
    */
    readonly prefixItems?: string;
    /**
    * Properties of Type.OBJECT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#properties CesTool#properties}
    */
    readonly properties?: string;
    /**
    * Allows indirect references between schema nodes. The value should be a
    * valid reference to a child of the root 'defs'.
    * For example, the following schema defines a reference to a schema node
    * named "Pet":
    * type: object
    * properties:
    *   pet:
    *     ref: #/defs/Pet
    * defs:
    *   Pet:
    *     type: object
    *     properties:
    *       name:
    *         type: string
    * The value of the "pet" property is a reference to the schema node
    * named "Pet".
    * See details in
    * https://json-schema.org/understanding-json-schema/structuring.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#ref CesTool#ref}
    */
    readonly ref?: string;
    /**
    * Required properties of Type.OBJECT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#required CesTool#required}
    */
    readonly required?: string[];
    /**
    * The title of the schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#title CesTool#title}
    */
    readonly title?: string;
    /**
    * The type of the data.
    * Possible values:
    * STRING
    * INTEGER
    * NUMBER
    * BOOLEAN
    * OBJECT
    * ARRAY
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#type CesTool#type}
    */
    readonly type: string;
    /**
    * Indicate the items in the array must be unique. Only applies to TYPE.ARRAY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#unique_items CesTool#unique_items}
    */
    readonly uniqueItems?: boolean | cdktn.IResolvable;
}
export declare function cesToolClientFunctionResponseToTerraform(struct?: CesToolClientFunctionResponseOutputReference | CesToolClientFunctionResponse): any;
export declare function cesToolClientFunctionResponseToHclTerraform(struct?: CesToolClientFunctionResponseOutputReference | CesToolClientFunctionResponse): any;
export declare class CesToolClientFunctionResponseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolClientFunctionResponse | undefined;
    set internalValue(value: CesToolClientFunctionResponse | undefined);
    private _additionalProperties?;
    get additionalProperties(): string;
    set additionalProperties(value: string);
    resetAdditionalProperties(): void;
    get additionalPropertiesInput(): string | undefined;
    private _anyOf?;
    get anyOf(): string;
    set anyOf(value: string);
    resetAnyOf(): void;
    get anyOfInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _defs?;
    get defs(): string;
    set defs(value: string);
    resetDefs(): void;
    get defsInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enum?;
    get enum(): string[];
    set enum(value: string[]);
    resetEnum(): void;
    get enumInput(): string[] | undefined;
    private _items?;
    get items(): string;
    set items(value: string);
    resetItems(): void;
    get itemsInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _maximum?;
    get maximum(): number;
    set maximum(value: number);
    resetMaximum(): void;
    get maximumInput(): number | undefined;
    private _minItems?;
    get minItems(): number;
    set minItems(value: number);
    resetMinItems(): void;
    get minItemsInput(): number | undefined;
    private _minimum?;
    get minimum(): number;
    set minimum(value: number);
    resetMinimum(): void;
    get minimumInput(): number | undefined;
    private _nullable?;
    get nullable(): boolean | cdktn.IResolvable;
    set nullable(value: boolean | cdktn.IResolvable);
    resetNullable(): void;
    get nullableInput(): boolean | cdktn.IResolvable | undefined;
    private _prefixItems?;
    get prefixItems(): string;
    set prefixItems(value: string);
    resetPrefixItems(): void;
    get prefixItemsInput(): string | undefined;
    private _properties?;
    get properties(): string;
    set properties(value: string);
    resetProperties(): void;
    get propertiesInput(): string | undefined;
    private _ref?;
    get ref(): string;
    set ref(value: string);
    resetRef(): void;
    get refInput(): string | undefined;
    private _required?;
    get required(): string[];
    set required(value: string[]);
    resetRequired(): void;
    get requiredInput(): string[] | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _uniqueItems?;
    get uniqueItems(): boolean | cdktn.IResolvable;
    set uniqueItems(value: boolean | cdktn.IResolvable);
    resetUniqueItems(): void;
    get uniqueItemsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CesToolClientFunction {
    /**
    * The function description.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#description CesTool#description}
    */
    readonly description?: string;
    /**
    * The function name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#name CesTool#name}
    */
    readonly name: string;
    /**
    * parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#parameters CesTool#parameters}
    */
    readonly parameters?: CesToolClientFunctionParameters;
    /**
    * response block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#response CesTool#response}
    */
    readonly response?: CesToolClientFunctionResponse;
}
export declare function cesToolClientFunctionToTerraform(struct?: CesToolClientFunctionOutputReference | CesToolClientFunction): any;
export declare function cesToolClientFunctionToHclTerraform(struct?: CesToolClientFunctionOutputReference | CesToolClientFunction): any;
export declare class CesToolClientFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolClientFunction | undefined;
    set internalValue(value: CesToolClientFunction | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters;
    get parameters(): CesToolClientFunctionParametersOutputReference;
    putParameters(value: CesToolClientFunctionParameters): void;
    resetParameters(): void;
    get parametersInput(): CesToolClientFunctionParameters | undefined;
    private _response;
    get response(): CesToolClientFunctionResponseOutputReference;
    putResponse(value: CesToolClientFunctionResponse): void;
    resetResponse(): void;
    get responseInput(): CesToolClientFunctionResponse | undefined;
}
export interface CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpecControlPoints {
    /**
    * Can be one of:
    * 1. The numerical field value.
    * 2. The duration spec for freshness:
    * The value must be formatted as an XSD 'dayTimeDuration' value (a
    * restricted subset of an ISO 8601 duration value). The pattern for
    * this is: 'nDnM]'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#attribute_value CesTool#attribute_value}
    */
    readonly attributeValue?: string;
    /**
    * The value between -1 to 1 by which to boost the score if the
    * attribute_value evaluates to the value specified above.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#boost_amount CesTool#boost_amount}
    */
    readonly boostAmount?: number;
}
export declare function cesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpecControlPointsToTerraform(struct?: CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpecControlPoints | cdktn.IResolvable): any;
export declare function cesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpecControlPointsToHclTerraform(struct?: CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpecControlPoints | cdktn.IResolvable): any;
export declare class CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpecControlPointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpecControlPoints | cdktn.IResolvable | undefined;
    set internalValue(value: CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpecControlPoints | cdktn.IResolvable | undefined);
    private _attributeValue?;
    get attributeValue(): string;
    set attributeValue(value: string);
    resetAttributeValue(): void;
    get attributeValueInput(): string | undefined;
    private _boostAmount?;
    get boostAmount(): number;
    set boostAmount(value: number);
    resetBoostAmount(): void;
    get boostAmountInput(): number | undefined;
}
export declare class CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpecControlPointsList extends cdktn.ComplexList {
    internalValue?: CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpecControlPoints[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpecControlPointsOutputReference;
}
export interface CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpec {
    /**
    * The attribute type to be used to determine the boost amount. The
    * attribute value can be derived from the field value of the specified
    * field_name. In the case of numerical it is straightforward i.e.
    * attribute_value = numerical_field_value. In the case of freshness
    * however, attribute_value = (time.now() - datetime_field_value).
    * Possible values:
    * NUMERICAL
    * FRESHNESS
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#attribute_type CesTool#attribute_type}
    */
    readonly attributeType?: string;
    /**
    * The name of the field whose value will be used to determine the
    * boost amount.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#field_name CesTool#field_name}
    */
    readonly fieldName?: string;
    /**
    * The interpolation type to be applied to connect the control points
    * listed below.
    * Possible values:
    * LINEAR
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#interpolation_type CesTool#interpolation_type}
    */
    readonly interpolationType?: string;
    /**
    * control_points block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#control_points CesTool#control_points}
    */
    readonly controlPoints?: CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpecControlPoints[] | cdktn.IResolvable;
}
export declare function cesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpecToTerraform(struct?: CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpecOutputReference | CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpec): any;
export declare function cesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpecToHclTerraform(struct?: CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpecOutputReference | CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpec): any;
export declare class CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpec | undefined;
    set internalValue(value: CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpec | undefined);
    private _attributeType?;
    get attributeType(): string;
    set attributeType(value: string);
    resetAttributeType(): void;
    get attributeTypeInput(): string | undefined;
    private _fieldName?;
    get fieldName(): string;
    set fieldName(value: string);
    resetFieldName(): void;
    get fieldNameInput(): string | undefined;
    private _interpolationType?;
    get interpolationType(): string;
    set interpolationType(value: string);
    resetInterpolationType(): void;
    get interpolationTypeInput(): string | undefined;
    private _controlPoints;
    get controlPoints(): CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpecControlPointsList;
    putControlPoints(value: CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpecControlPoints[] | cdktn.IResolvable): void;
    resetControlPoints(): void;
    get controlPointsInput(): cdktn.IResolvable | CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpecControlPoints[] | undefined;
}
export interface CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecs {
    /**
    * Strength of the boost, which should be in [-1, 1]. Negative boost means
    * demotion. Default is 0.0.
    * Setting to 1.0 gives the suggestions a big promotion. However, it does
    * not necessarily mean that the top result will be a boosted suggestion.
    * Setting to -1.0 gives the suggestions a big demotion. However, other
    * suggestions that are relevant might still be shown.
    * Setting to 0.0 means no boost applied. The boosting condition is
    * ignored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#boost CesTool#boost}
    */
    readonly boost?: number;
    /**
    * An expression which specifies a boost condition. The syntax is the same
    * as filter expression syntax. Currently, the only supported condition is
    * a list of BCP-47 lang codes.
    * Example: To boost suggestions in languages en or fr:
    * (lang_code: ANY("en", "fr"))
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#condition CesTool#condition}
    */
    readonly condition: string;
    /**
    * boost_control_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#boost_control_spec CesTool#boost_control_spec}
    */
    readonly boostControlSpec?: CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpec;
}
export declare function cesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsToTerraform(struct?: CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecs | cdktn.IResolvable): any;
export declare function cesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsToHclTerraform(struct?: CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecs | cdktn.IResolvable): any;
export declare class CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecs | cdktn.IResolvable | undefined;
    set internalValue(value: CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecs | cdktn.IResolvable | undefined);
    private _boost?;
    get boost(): number;
    set boost(value: number);
    resetBoost(): void;
    get boostInput(): number | undefined;
    private _condition?;
    get condition(): string;
    set condition(value: string);
    get conditionInput(): string | undefined;
    private _boostControlSpec;
    get boostControlSpec(): CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpecOutputReference;
    putBoostControlSpec(value: CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpec): void;
    resetBoostControlSpec(): void;
    get boostControlSpecInput(): CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsBoostControlSpec | undefined;
}
export declare class CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsList extends cdktn.ComplexList {
    internalValue?: CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsOutputReference;
}
export interface CesToolDataStoreToolBoostSpecsSpec {
    /**
    * condition_boost_specs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#condition_boost_specs CesTool#condition_boost_specs}
    */
    readonly conditionBoostSpecs: CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecs[] | cdktn.IResolvable;
}
export declare function cesToolDataStoreToolBoostSpecsSpecToTerraform(struct?: CesToolDataStoreToolBoostSpecsSpec | cdktn.IResolvable): any;
export declare function cesToolDataStoreToolBoostSpecsSpecToHclTerraform(struct?: CesToolDataStoreToolBoostSpecsSpec | cdktn.IResolvable): any;
export declare class CesToolDataStoreToolBoostSpecsSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolDataStoreToolBoostSpecsSpec | cdktn.IResolvable | undefined;
    set internalValue(value: CesToolDataStoreToolBoostSpecsSpec | cdktn.IResolvable | undefined);
    private _conditionBoostSpecs;
    get conditionBoostSpecs(): CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecsList;
    putConditionBoostSpecs(value: CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecs[] | cdktn.IResolvable): void;
    get conditionBoostSpecsInput(): cdktn.IResolvable | CesToolDataStoreToolBoostSpecsSpecConditionBoostSpecs[] | undefined;
}
export declare class CesToolDataStoreToolBoostSpecsSpecList extends cdktn.ComplexList {
    internalValue?: CesToolDataStoreToolBoostSpecsSpec[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolDataStoreToolBoostSpecsSpecOutputReference;
}
export interface CesToolDataStoreToolBoostSpecs {
    /**
    * The Data Store where the boosting configuration is applied. Full resource
    * name of DataStore, such as
    * projects/{project}/locations/{location}/collections/{collection}/dataStores/{dataStore}.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#data_stores CesTool#data_stores}
    */
    readonly dataStores: string[];
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#spec CesTool#spec}
    */
    readonly spec: CesToolDataStoreToolBoostSpecsSpec[] | cdktn.IResolvable;
}
export declare function cesToolDataStoreToolBoostSpecsToTerraform(struct?: CesToolDataStoreToolBoostSpecs | cdktn.IResolvable): any;
export declare function cesToolDataStoreToolBoostSpecsToHclTerraform(struct?: CesToolDataStoreToolBoostSpecs | cdktn.IResolvable): any;
export declare class CesToolDataStoreToolBoostSpecsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolDataStoreToolBoostSpecs | cdktn.IResolvable | undefined;
    set internalValue(value: CesToolDataStoreToolBoostSpecs | cdktn.IResolvable | undefined);
    private _dataStores?;
    get dataStores(): string[];
    set dataStores(value: string[]);
    get dataStoresInput(): string[] | undefined;
    private _spec;
    get spec(): CesToolDataStoreToolBoostSpecsSpecList;
    putSpec(value: CesToolDataStoreToolBoostSpecsSpec[] | cdktn.IResolvable): void;
    get specInput(): cdktn.IResolvable | CesToolDataStoreToolBoostSpecsSpec[] | undefined;
}
export declare class CesToolDataStoreToolBoostSpecsList extends cdktn.ComplexList {
    internalValue?: CesToolDataStoreToolBoostSpecs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolDataStoreToolBoostSpecsOutputReference;
}
export interface CesToolDataStoreToolDataStoreSourceDataStoreConnectorConfig {
}
export declare function cesToolDataStoreToolDataStoreSourceDataStoreConnectorConfigToTerraform(struct?: CesToolDataStoreToolDataStoreSourceDataStoreConnectorConfig): any;
export declare function cesToolDataStoreToolDataStoreSourceDataStoreConnectorConfigToHclTerraform(struct?: CesToolDataStoreToolDataStoreSourceDataStoreConnectorConfig): any;
export declare class CesToolDataStoreToolDataStoreSourceDataStoreConnectorConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolDataStoreToolDataStoreSourceDataStoreConnectorConfig | undefined;
    set internalValue(value: CesToolDataStoreToolDataStoreSourceDataStoreConnectorConfig | undefined);
    get collection(): string;
    get collectionDisplayName(): string;
    get dataSource(): string;
}
export declare class CesToolDataStoreToolDataStoreSourceDataStoreConnectorConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolDataStoreToolDataStoreSourceDataStoreConnectorConfigOutputReference;
}
export interface CesToolDataStoreToolDataStoreSourceDataStore {
    /**
    * Full resource name of the DataStore.
    * Format: projects/{project}/locations/{location}/collections/{collection}/dataStores/{dataStore}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#name CesTool#name}
    */
    readonly name: string;
}
export declare function cesToolDataStoreToolDataStoreSourceDataStoreToTerraform(struct?: CesToolDataStoreToolDataStoreSourceDataStoreOutputReference | CesToolDataStoreToolDataStoreSourceDataStore): any;
export declare function cesToolDataStoreToolDataStoreSourceDataStoreToHclTerraform(struct?: CesToolDataStoreToolDataStoreSourceDataStoreOutputReference | CesToolDataStoreToolDataStoreSourceDataStore): any;
export declare class CesToolDataStoreToolDataStoreSourceDataStoreOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolDataStoreToolDataStoreSourceDataStore | undefined;
    set internalValue(value: CesToolDataStoreToolDataStoreSourceDataStore | undefined);
    private _connectorConfig;
    get connectorConfig(): CesToolDataStoreToolDataStoreSourceDataStoreConnectorConfigList;
    get createTime(): string;
    get displayName(): string;
    get documentProcessingMode(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get type(): string;
}
export interface CesToolDataStoreToolDataStoreSource {
    /**
    * Optional. Filter specification for the DataStore.
    * See: https://cloud.google.com/generative-ai-app-builder/docs/filter-search-metadata
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#filter CesTool#filter}
    */
    readonly filter?: string;
    /**
    * data_store block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#data_store CesTool#data_store}
    */
    readonly dataStore?: CesToolDataStoreToolDataStoreSourceDataStore;
}
export declare function cesToolDataStoreToolDataStoreSourceToTerraform(struct?: CesToolDataStoreToolDataStoreSourceOutputReference | CesToolDataStoreToolDataStoreSource): any;
export declare function cesToolDataStoreToolDataStoreSourceToHclTerraform(struct?: CesToolDataStoreToolDataStoreSourceOutputReference | CesToolDataStoreToolDataStoreSource): any;
export declare class CesToolDataStoreToolDataStoreSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolDataStoreToolDataStoreSource | undefined;
    set internalValue(value: CesToolDataStoreToolDataStoreSource | undefined);
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _dataStore;
    get dataStore(): CesToolDataStoreToolDataStoreSourceDataStoreOutputReference;
    putDataStore(value: CesToolDataStoreToolDataStoreSourceDataStore): void;
    resetDataStore(): void;
    get dataStoreInput(): CesToolDataStoreToolDataStoreSourceDataStore | undefined;
}
export interface CesToolDataStoreToolEngineSourceDataStoreSourcesDataStoreConnectorConfig {
}
export declare function cesToolDataStoreToolEngineSourceDataStoreSourcesDataStoreConnectorConfigToTerraform(struct?: CesToolDataStoreToolEngineSourceDataStoreSourcesDataStoreConnectorConfig): any;
export declare function cesToolDataStoreToolEngineSourceDataStoreSourcesDataStoreConnectorConfigToHclTerraform(struct?: CesToolDataStoreToolEngineSourceDataStoreSourcesDataStoreConnectorConfig): any;
export declare class CesToolDataStoreToolEngineSourceDataStoreSourcesDataStoreConnectorConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolDataStoreToolEngineSourceDataStoreSourcesDataStoreConnectorConfig | undefined;
    set internalValue(value: CesToolDataStoreToolEngineSourceDataStoreSourcesDataStoreConnectorConfig | undefined);
    get collection(): string;
    get collectionDisplayName(): string;
    get dataSource(): string;
}
export declare class CesToolDataStoreToolEngineSourceDataStoreSourcesDataStoreConnectorConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolDataStoreToolEngineSourceDataStoreSourcesDataStoreConnectorConfigOutputReference;
}
export interface CesToolDataStoreToolEngineSourceDataStoreSourcesDataStore {
    /**
    * Full resource name of the DataStore.
    * Format:
    * 'projects/{project}/locations/{location}/collections/{collection}/dataStores/{dataStore}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#name CesTool#name}
    */
    readonly name: string;
}
export declare function cesToolDataStoreToolEngineSourceDataStoreSourcesDataStoreToTerraform(struct?: CesToolDataStoreToolEngineSourceDataStoreSourcesDataStoreOutputReference | CesToolDataStoreToolEngineSourceDataStoreSourcesDataStore): any;
export declare function cesToolDataStoreToolEngineSourceDataStoreSourcesDataStoreToHclTerraform(struct?: CesToolDataStoreToolEngineSourceDataStoreSourcesDataStoreOutputReference | CesToolDataStoreToolEngineSourceDataStoreSourcesDataStore): any;
export declare class CesToolDataStoreToolEngineSourceDataStoreSourcesDataStoreOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolDataStoreToolEngineSourceDataStoreSourcesDataStore | undefined;
    set internalValue(value: CesToolDataStoreToolEngineSourceDataStoreSourcesDataStore | undefined);
    private _connectorConfig;
    get connectorConfig(): CesToolDataStoreToolEngineSourceDataStoreSourcesDataStoreConnectorConfigList;
    get createTime(): string;
    get displayName(): string;
    get documentProcessingMode(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get type(): string;
}
export interface CesToolDataStoreToolEngineSourceDataStoreSources {
    /**
    * Filter specification for the DataStore.
    * See:
    * https://cloud.google.com/generative-ai-app-builder/docs/filter-search-metadata
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#filter CesTool#filter}
    */
    readonly filter?: string;
    /**
    * data_store block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#data_store CesTool#data_store}
    */
    readonly dataStore?: CesToolDataStoreToolEngineSourceDataStoreSourcesDataStore;
}
export declare function cesToolDataStoreToolEngineSourceDataStoreSourcesToTerraform(struct?: CesToolDataStoreToolEngineSourceDataStoreSources | cdktn.IResolvable): any;
export declare function cesToolDataStoreToolEngineSourceDataStoreSourcesToHclTerraform(struct?: CesToolDataStoreToolEngineSourceDataStoreSources | cdktn.IResolvable): any;
export declare class CesToolDataStoreToolEngineSourceDataStoreSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolDataStoreToolEngineSourceDataStoreSources | cdktn.IResolvable | undefined;
    set internalValue(value: CesToolDataStoreToolEngineSourceDataStoreSources | cdktn.IResolvable | undefined);
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _dataStore;
    get dataStore(): CesToolDataStoreToolEngineSourceDataStoreSourcesDataStoreOutputReference;
    putDataStore(value: CesToolDataStoreToolEngineSourceDataStoreSourcesDataStore): void;
    resetDataStore(): void;
    get dataStoreInput(): CesToolDataStoreToolEngineSourceDataStoreSourcesDataStore | undefined;
}
export declare class CesToolDataStoreToolEngineSourceDataStoreSourcesList extends cdktn.ComplexList {
    internalValue?: CesToolDataStoreToolEngineSourceDataStoreSources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolDataStoreToolEngineSourceDataStoreSourcesOutputReference;
}
export interface CesToolDataStoreToolEngineSource {
    /**
    * Full resource name of the Engine.
    * Format:
    * 'projects/{project}/locations/{location}/collections/{collection}/engines/{engine}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#engine CesTool#engine}
    */
    readonly engine: string;
    /**
    * A filter applied to the search across the Engine. Not relevant and not
    * used if 'data_store_sources' is provided.
    * See:
    * https://cloud.google.com/generative-ai-app-builder/docs/filter-search-metadata
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#filter CesTool#filter}
    */
    readonly filter?: string;
    /**
    * data_store_sources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#data_store_sources CesTool#data_store_sources}
    */
    readonly dataStoreSources?: CesToolDataStoreToolEngineSourceDataStoreSources[] | cdktn.IResolvable;
}
export declare function cesToolDataStoreToolEngineSourceToTerraform(struct?: CesToolDataStoreToolEngineSourceOutputReference | CesToolDataStoreToolEngineSource): any;
export declare function cesToolDataStoreToolEngineSourceToHclTerraform(struct?: CesToolDataStoreToolEngineSourceOutputReference | CesToolDataStoreToolEngineSource): any;
export declare class CesToolDataStoreToolEngineSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolDataStoreToolEngineSource | undefined;
    set internalValue(value: CesToolDataStoreToolEngineSource | undefined);
    private _engine?;
    get engine(): string;
    set engine(value: string);
    get engineInput(): string | undefined;
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _dataStoreSources;
    get dataStoreSources(): CesToolDataStoreToolEngineSourceDataStoreSourcesList;
    putDataStoreSources(value: CesToolDataStoreToolEngineSourceDataStoreSources[] | cdktn.IResolvable): void;
    resetDataStoreSources(): void;
    get dataStoreSourcesInput(): cdktn.IResolvable | CesToolDataStoreToolEngineSourceDataStoreSources[] | undefined;
}
export interface CesToolDataStoreToolModalityConfigsGroundingConfig {
    /**
    * Whether grounding is disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#disabled CesTool#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * The groundedness threshold of the answer based on the retrieved sources.
    * The value has a configurable range of [1, 5]. The level is used to
    * threshold the groundedness of the answer, meaning that all responses with
    * a groundedness score below the threshold will fall back to returning
    * relevant snippets only.
    * For example, a level of 3 means that the groundedness score must be
    * 3 or higher for the response to be returned.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#grounding_level CesTool#grounding_level}
    */
    readonly groundingLevel?: number;
}
export declare function cesToolDataStoreToolModalityConfigsGroundingConfigToTerraform(struct?: CesToolDataStoreToolModalityConfigsGroundingConfigOutputReference | CesToolDataStoreToolModalityConfigsGroundingConfig): any;
export declare function cesToolDataStoreToolModalityConfigsGroundingConfigToHclTerraform(struct?: CesToolDataStoreToolModalityConfigsGroundingConfigOutputReference | CesToolDataStoreToolModalityConfigsGroundingConfig): any;
export declare class CesToolDataStoreToolModalityConfigsGroundingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolDataStoreToolModalityConfigsGroundingConfig | undefined;
    set internalValue(value: CesToolDataStoreToolModalityConfigsGroundingConfig | undefined);
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _groundingLevel?;
    get groundingLevel(): number;
    set groundingLevel(value: number);
    resetGroundingLevel(): void;
    get groundingLevelInput(): number | undefined;
}
export interface CesToolDataStoreToolModalityConfigsRewriterConfigModelSettings {
    /**
    * The LLM model that the agent should use.
    * If not set, the agent will inherit the model from its parent agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#model CesTool#model}
    */
    readonly model?: string;
    /**
    * If set, this temperature will be used for the LLM model. Temperature
    * controls the randomness of the model's responses. Lower temperatures
    * produce responses that are more predictable. Higher temperatures produce
    * responses that are more creative.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#temperature CesTool#temperature}
    */
    readonly temperature?: number;
    /**
    * The thinking level of the model.
    * Possible values:
    * DEFAULT
    * LOW
    * MEDIUM
    * HIGH Possible values: ["DEFAULT", "LOW", "MEDIUM", "HIGH"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#thinking_level CesTool#thinking_level}
    */
    readonly thinkingLevel?: string;
}
export declare function cesToolDataStoreToolModalityConfigsRewriterConfigModelSettingsToTerraform(struct?: CesToolDataStoreToolModalityConfigsRewriterConfigModelSettingsOutputReference | CesToolDataStoreToolModalityConfigsRewriterConfigModelSettings): any;
export declare function cesToolDataStoreToolModalityConfigsRewriterConfigModelSettingsToHclTerraform(struct?: CesToolDataStoreToolModalityConfigsRewriterConfigModelSettingsOutputReference | CesToolDataStoreToolModalityConfigsRewriterConfigModelSettings): any;
export declare class CesToolDataStoreToolModalityConfigsRewriterConfigModelSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolDataStoreToolModalityConfigsRewriterConfigModelSettings | undefined;
    set internalValue(value: CesToolDataStoreToolModalityConfigsRewriterConfigModelSettings | undefined);
    private _model?;
    get model(): string;
    set model(value: string);
    resetModel(): void;
    get modelInput(): string | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _thinkingLevel?;
    get thinkingLevel(): string;
    set thinkingLevel(value: string);
    resetThinkingLevel(): void;
    get thinkingLevelInput(): string | undefined;
}
export interface CesToolDataStoreToolModalityConfigsRewriterConfig {
    /**
    * Whether the rewriter is disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#disabled CesTool#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * The prompt definition. If not set, default prompt will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#prompt CesTool#prompt}
    */
    readonly prompt?: string;
    /**
    * model_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#model_settings CesTool#model_settings}
    */
    readonly modelSettings: CesToolDataStoreToolModalityConfigsRewriterConfigModelSettings;
}
export declare function cesToolDataStoreToolModalityConfigsRewriterConfigToTerraform(struct?: CesToolDataStoreToolModalityConfigsRewriterConfigOutputReference | CesToolDataStoreToolModalityConfigsRewriterConfig): any;
export declare function cesToolDataStoreToolModalityConfigsRewriterConfigToHclTerraform(struct?: CesToolDataStoreToolModalityConfigsRewriterConfigOutputReference | CesToolDataStoreToolModalityConfigsRewriterConfig): any;
export declare class CesToolDataStoreToolModalityConfigsRewriterConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolDataStoreToolModalityConfigsRewriterConfig | undefined;
    set internalValue(value: CesToolDataStoreToolModalityConfigsRewriterConfig | undefined);
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _prompt?;
    get prompt(): string;
    set prompt(value: string);
    resetPrompt(): void;
    get promptInput(): string | undefined;
    private _modelSettings;
    get modelSettings(): CesToolDataStoreToolModalityConfigsRewriterConfigModelSettingsOutputReference;
    putModelSettings(value: CesToolDataStoreToolModalityConfigsRewriterConfigModelSettings): void;
    get modelSettingsInput(): CesToolDataStoreToolModalityConfigsRewriterConfigModelSettings | undefined;
}
export interface CesToolDataStoreToolModalityConfigsSnippetsConfig {
    /**
    * Whether snippets are enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#enable_snippets CesTool#enable_snippets}
    */
    readonly enableSnippets?: boolean | cdktn.IResolvable;
    /**
    * Number of snippets to return per query.
    * If unset, returns all snippets from the service by default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#max_snippets CesTool#max_snippets}
    */
    readonly maxSnippets?: number;
}
export declare function cesToolDataStoreToolModalityConfigsSnippetsConfigToTerraform(struct?: CesToolDataStoreToolModalityConfigsSnippetsConfigOutputReference | CesToolDataStoreToolModalityConfigsSnippetsConfig): any;
export declare function cesToolDataStoreToolModalityConfigsSnippetsConfigToHclTerraform(struct?: CesToolDataStoreToolModalityConfigsSnippetsConfigOutputReference | CesToolDataStoreToolModalityConfigsSnippetsConfig): any;
export declare class CesToolDataStoreToolModalityConfigsSnippetsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolDataStoreToolModalityConfigsSnippetsConfig | undefined;
    set internalValue(value: CesToolDataStoreToolModalityConfigsSnippetsConfig | undefined);
    private _enableSnippets?;
    get enableSnippets(): boolean | cdktn.IResolvable;
    set enableSnippets(value: boolean | cdktn.IResolvable);
    resetEnableSnippets(): void;
    get enableSnippetsInput(): boolean | cdktn.IResolvable | undefined;
    private _maxSnippets?;
    get maxSnippets(): number;
    set maxSnippets(value: number);
    resetMaxSnippets(): void;
    get maxSnippetsInput(): number | undefined;
}
export interface CesToolDataStoreToolModalityConfigsSummarizationConfigModelSettings {
    /**
    * The LLM model that the agent should use.
    * If not set, the agent will inherit the model from its parent agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#model CesTool#model}
    */
    readonly model?: string;
    /**
    * If set, this temperature will be used for the LLM model. Temperature
    * controls the randomness of the model's responses. Lower temperatures
    * produce responses that are more predictable. Higher temperatures produce
    * responses that are more creative.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#temperature CesTool#temperature}
    */
    readonly temperature?: number;
    /**
    * The thinking level of the model.
    * Possible values:
    * DEFAULT
    * LOW
    * MEDIUM
    * HIGH Possible values: ["DEFAULT", "LOW", "MEDIUM", "HIGH"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#thinking_level CesTool#thinking_level}
    */
    readonly thinkingLevel?: string;
}
export declare function cesToolDataStoreToolModalityConfigsSummarizationConfigModelSettingsToTerraform(struct?: CesToolDataStoreToolModalityConfigsSummarizationConfigModelSettingsOutputReference | CesToolDataStoreToolModalityConfigsSummarizationConfigModelSettings): any;
export declare function cesToolDataStoreToolModalityConfigsSummarizationConfigModelSettingsToHclTerraform(struct?: CesToolDataStoreToolModalityConfigsSummarizationConfigModelSettingsOutputReference | CesToolDataStoreToolModalityConfigsSummarizationConfigModelSettings): any;
export declare class CesToolDataStoreToolModalityConfigsSummarizationConfigModelSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolDataStoreToolModalityConfigsSummarizationConfigModelSettings | undefined;
    set internalValue(value: CesToolDataStoreToolModalityConfigsSummarizationConfigModelSettings | undefined);
    private _model?;
    get model(): string;
    set model(value: string);
    resetModel(): void;
    get modelInput(): string | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _thinkingLevel?;
    get thinkingLevel(): string;
    set thinkingLevel(value: string);
    resetThinkingLevel(): void;
    get thinkingLevelInput(): string | undefined;
}
export interface CesToolDataStoreToolModalityConfigsSummarizationConfig {
    /**
    * Whether summarization is disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#disabled CesTool#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * The prompt definition. If not set, default prompt will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#prompt CesTool#prompt}
    */
    readonly prompt?: string;
    /**
    * model_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#model_settings CesTool#model_settings}
    */
    readonly modelSettings?: CesToolDataStoreToolModalityConfigsSummarizationConfigModelSettings;
}
export declare function cesToolDataStoreToolModalityConfigsSummarizationConfigToTerraform(struct?: CesToolDataStoreToolModalityConfigsSummarizationConfigOutputReference | CesToolDataStoreToolModalityConfigsSummarizationConfig): any;
export declare function cesToolDataStoreToolModalityConfigsSummarizationConfigToHclTerraform(struct?: CesToolDataStoreToolModalityConfigsSummarizationConfigOutputReference | CesToolDataStoreToolModalityConfigsSummarizationConfig): any;
export declare class CesToolDataStoreToolModalityConfigsSummarizationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolDataStoreToolModalityConfigsSummarizationConfig | undefined;
    set internalValue(value: CesToolDataStoreToolModalityConfigsSummarizationConfig | undefined);
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _prompt?;
    get prompt(): string;
    set prompt(value: string);
    resetPrompt(): void;
    get promptInput(): string | undefined;
    private _modelSettings;
    get modelSettings(): CesToolDataStoreToolModalityConfigsSummarizationConfigModelSettingsOutputReference;
    putModelSettings(value: CesToolDataStoreToolModalityConfigsSummarizationConfigModelSettings): void;
    resetModelSettings(): void;
    get modelSettingsInput(): CesToolDataStoreToolModalityConfigsSummarizationConfigModelSettings | undefined;
}
export interface CesToolDataStoreToolModalityConfigs {
    /**
    * The modality type.
    * Possible values:
    * TEXT
    * AUDIO
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#modality_type CesTool#modality_type}
    */
    readonly modalityType: string;
    /**
    * grounding_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#grounding_config CesTool#grounding_config}
    */
    readonly groundingConfig?: CesToolDataStoreToolModalityConfigsGroundingConfig;
    /**
    * rewriter_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#rewriter_config CesTool#rewriter_config}
    */
    readonly rewriterConfig?: CesToolDataStoreToolModalityConfigsRewriterConfig;
    /**
    * snippets_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#snippets_config CesTool#snippets_config}
    */
    readonly snippetsConfig?: CesToolDataStoreToolModalityConfigsSnippetsConfig;
    /**
    * summarization_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#summarization_config CesTool#summarization_config}
    */
    readonly summarizationConfig?: CesToolDataStoreToolModalityConfigsSummarizationConfig;
}
export declare function cesToolDataStoreToolModalityConfigsToTerraform(struct?: CesToolDataStoreToolModalityConfigs | cdktn.IResolvable): any;
export declare function cesToolDataStoreToolModalityConfigsToHclTerraform(struct?: CesToolDataStoreToolModalityConfigs | cdktn.IResolvable): any;
export declare class CesToolDataStoreToolModalityConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesToolDataStoreToolModalityConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: CesToolDataStoreToolModalityConfigs | cdktn.IResolvable | undefined);
    private _modalityType?;
    get modalityType(): string;
    set modalityType(value: string);
    get modalityTypeInput(): string | undefined;
    private _groundingConfig;
    get groundingConfig(): CesToolDataStoreToolModalityConfigsGroundingConfigOutputReference;
    putGroundingConfig(value: CesToolDataStoreToolModalityConfigsGroundingConfig): void;
    resetGroundingConfig(): void;
    get groundingConfigInput(): CesToolDataStoreToolModalityConfigsGroundingConfig | undefined;
    private _rewriterConfig;
    get rewriterConfig(): CesToolDataStoreToolModalityConfigsRewriterConfigOutputReference;
    putRewriterConfig(value: CesToolDataStoreToolModalityConfigsRewriterConfig): void;
    resetRewriterConfig(): void;
    get rewriterConfigInput(): CesToolDataStoreToolModalityConfigsRewriterConfig | undefined;
    private _snippetsConfig;
    get snippetsConfig(): CesToolDataStoreToolModalityConfigsSnippetsConfigOutputReference;
    putSnippetsConfig(value: CesToolDataStoreToolModalityConfigsSnippetsConfig): void;
    resetSnippetsConfig(): void;
    get snippetsConfigInput(): CesToolDataStoreToolModalityConfigsSnippetsConfig | undefined;
    private _summarizationConfig;
    get summarizationConfig(): CesToolDataStoreToolModalityConfigsSummarizationConfigOutputReference;
    putSummarizationConfig(value: CesToolDataStoreToolModalityConfigsSummarizationConfig): void;
    resetSummarizationConfig(): void;
    get summarizationConfigInput(): CesToolDataStoreToolModalityConfigsSummarizationConfig | undefined;
}
export declare class CesToolDataStoreToolModalityConfigsList extends cdktn.ComplexList {
    internalValue?: CesToolDataStoreToolModalityConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesToolDataStoreToolModalityConfigsOutputReference;
}
export interface CesToolDataStoreTool {
    /**
    * The tool description.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#description CesTool#description}
    */
    readonly description?: string;
    /**
    * Optional. The filter parameter behavior.
    * Possible values:
    * FILTER_PARAMETER_BEHAVIOR_UNSPECIFIED
    * ALWAYS_INCLUDE
    * NEVER_INCLUDE Possible values: ["FILTER_PARAMETER_BEHAVIOR_UNSPECIFIED", "ALWAYS_INCLUDE", "NEVER_INCLUDE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#filter_parameter_behavior CesTool#filter_parameter_behavior}
    */
    readonly filterParameterBehavior?: string;
    /**
    * Number of search results to return per query.
    * The default value is 10. The maximum allowed value is 10.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#max_results CesTool#max_results}
    */
    readonly maxResults?: number;
    /**
    * The data store tool name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#name CesTool#name}
    */
    readonly name: string;
    /**
    * boost_specs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#boost_specs CesTool#boost_specs}
    */
    readonly boostSpecs?: CesToolDataStoreToolBoostSpecs[] | cdktn.IResolvable;
    /**
    * data_store_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#data_store_source CesTool#data_store_source}
    */
    readonly dataStoreSource?: CesToolDataStoreToolDataStoreSource;
    /**
    * engine_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#engine_source CesTool#engine_source}
    */
    readonly engineSource?: CesToolDataStoreToolEngineSource;
    /**
    * modality_configs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#modality_configs CesTool#modality_configs}
    */
    readonly modalityConfigs?: CesToolDataStoreToolModalityConfigs[] | cdktn.IResolvable;
}
export declare function cesToolDataStoreToolToTerraform(struct?: CesToolDataStoreToolOutputReference | CesToolDataStoreTool): any;
export declare function cesToolDataStoreToolToHclTerraform(struct?: CesToolDataStoreToolOutputReference | CesToolDataStoreTool): any;
export declare class CesToolDataStoreToolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolDataStoreTool | undefined;
    set internalValue(value: CesToolDataStoreTool | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _filterParameterBehavior?;
    get filterParameterBehavior(): string;
    set filterParameterBehavior(value: string);
    resetFilterParameterBehavior(): void;
    get filterParameterBehaviorInput(): string | undefined;
    private _maxResults?;
    get maxResults(): number;
    set maxResults(value: number);
    resetMaxResults(): void;
    get maxResultsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _boostSpecs;
    get boostSpecs(): CesToolDataStoreToolBoostSpecsList;
    putBoostSpecs(value: CesToolDataStoreToolBoostSpecs[] | cdktn.IResolvable): void;
    resetBoostSpecs(): void;
    get boostSpecsInput(): cdktn.IResolvable | CesToolDataStoreToolBoostSpecs[] | undefined;
    private _dataStoreSource;
    get dataStoreSource(): CesToolDataStoreToolDataStoreSourceOutputReference;
    putDataStoreSource(value: CesToolDataStoreToolDataStoreSource): void;
    resetDataStoreSource(): void;
    get dataStoreSourceInput(): CesToolDataStoreToolDataStoreSource | undefined;
    private _engineSource;
    get engineSource(): CesToolDataStoreToolEngineSourceOutputReference;
    putEngineSource(value: CesToolDataStoreToolEngineSource): void;
    resetEngineSource(): void;
    get engineSourceInput(): CesToolDataStoreToolEngineSource | undefined;
    private _modalityConfigs;
    get modalityConfigs(): CesToolDataStoreToolModalityConfigsList;
    putModalityConfigs(value: CesToolDataStoreToolModalityConfigs[] | cdktn.IResolvable): void;
    resetModalityConfigs(): void;
    get modalityConfigsInput(): cdktn.IResolvable | CesToolDataStoreToolModalityConfigs[] | undefined;
}
export interface CesToolFileSearchTool {
    /**
    * Optional. The type of the corpus. Default is FULLY_MANAGED.
    * Possible values:
    * CORPUS_TYPE_UNSPECIFIED
    * USER_OWNED
    * FULLY_MANAGED Possible values: ["CORPUS_TYPE_UNSPECIFIED", "USER_OWNED", "FULLY_MANAGED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#corpus_type CesTool#corpus_type}
    */
    readonly corpusType?: string;
    /**
    * Optional. The tool description.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#description CesTool#description}
    */
    readonly description?: string;
    /**
    * Optional. The corpus where files are stored.
    * Format: projects/{project}/locations/{location}/ragCorpora/{rag_corpus}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#file_corpus CesTool#file_corpus}
    */
    readonly fileCorpus?: string;
    /**
    * Required. The tool name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#name CesTool#name}
    */
    readonly name: string;
}
export declare function cesToolFileSearchToolToTerraform(struct?: CesToolFileSearchToolOutputReference | CesToolFileSearchTool): any;
export declare function cesToolFileSearchToolToHclTerraform(struct?: CesToolFileSearchToolOutputReference | CesToolFileSearchTool): any;
export declare class CesToolFileSearchToolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolFileSearchTool | undefined;
    set internalValue(value: CesToolFileSearchTool | undefined);
    private _corpusType?;
    get corpusType(): string;
    set corpusType(value: string);
    resetCorpusType(): void;
    get corpusTypeInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _fileCorpus?;
    get fileCorpus(): string;
    set fileCorpus(value: string);
    resetFileCorpus(): void;
    get fileCorpusInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface CesToolGoogleSearchToolPromptConfig {
    /**
    * Optional. Defines the prompt used for the system instructions when interacting with the
    * agent in chat conversations. If not set, default prompt will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#text_prompt CesTool#text_prompt}
    */
    readonly textPrompt?: string;
    /**
    * Optional. Defines the prompt used for the system instructions when interacting with the
    * agent in voice conversations. If not set, default prompt will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#voice_prompt CesTool#voice_prompt}
    */
    readonly voicePrompt?: string;
}
export declare function cesToolGoogleSearchToolPromptConfigToTerraform(struct?: CesToolGoogleSearchToolPromptConfigOutputReference | CesToolGoogleSearchToolPromptConfig): any;
export declare function cesToolGoogleSearchToolPromptConfigToHclTerraform(struct?: CesToolGoogleSearchToolPromptConfigOutputReference | CesToolGoogleSearchToolPromptConfig): any;
export declare class CesToolGoogleSearchToolPromptConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolGoogleSearchToolPromptConfig | undefined;
    set internalValue(value: CesToolGoogleSearchToolPromptConfig | undefined);
    private _textPrompt?;
    get textPrompt(): string;
    set textPrompt(value: string);
    resetTextPrompt(): void;
    get textPromptInput(): string | undefined;
    private _voicePrompt?;
    get voicePrompt(): string;
    set voicePrompt(value: string);
    resetVoicePrompt(): void;
    get voicePromptInput(): string | undefined;
}
export interface CesToolGoogleSearchTool {
    /**
    * Content will be fetched directly from these URLs for context and grounding.
    * More details: https://cloud.google.com/vertex-ai/generative-ai/docs/url-context.
    * Example: "https://example.com/path.html". A maximum of 20 URLs are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#context_urls CesTool#context_urls}
    */
    readonly contextUrls?: string[];
    /**
    * Description of the tool's purpose.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#description CesTool#description}
    */
    readonly description?: string;
    /**
    * List of domains to be excluded from the search results.
    * Example: "example.com".
    * A maximum of 2000 domains can be excluded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#exclude_domains CesTool#exclude_domains}
    */
    readonly excludeDomains?: string[];
    /**
    * The name of the tool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#name CesTool#name}
    */
    readonly name: string;
    /**
    * Specifies domain names to guide the search.
    * The model will be instructed to prioritize these domains
    * when formulating queries for google search.
    * This is a best-effort hint and these domains may or may
    * not be exclusively reflected in the final search results.
    * Example: "example.com", "another.site".
    * A maximum of 20 domains can be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#preferred_domains CesTool#preferred_domains}
    */
    readonly preferredDomains?: string[];
    /**
    * prompt_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#prompt_config CesTool#prompt_config}
    */
    readonly promptConfig?: CesToolGoogleSearchToolPromptConfig;
}
export declare function cesToolGoogleSearchToolToTerraform(struct?: CesToolGoogleSearchToolOutputReference | CesToolGoogleSearchTool): any;
export declare function cesToolGoogleSearchToolToHclTerraform(struct?: CesToolGoogleSearchToolOutputReference | CesToolGoogleSearchTool): any;
export declare class CesToolGoogleSearchToolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolGoogleSearchTool | undefined;
    set internalValue(value: CesToolGoogleSearchTool | undefined);
    private _contextUrls?;
    get contextUrls(): string[];
    set contextUrls(value: string[]);
    resetContextUrls(): void;
    get contextUrlsInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _excludeDomains?;
    get excludeDomains(): string[];
    set excludeDomains(value: string[]);
    resetExcludeDomains(): void;
    get excludeDomainsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _preferredDomains?;
    get preferredDomains(): string[];
    set preferredDomains(value: string[]);
    resetPreferredDomains(): void;
    get preferredDomainsInput(): string[] | undefined;
    private _promptConfig;
    get promptConfig(): CesToolGoogleSearchToolPromptConfigOutputReference;
    putPromptConfig(value: CesToolGoogleSearchToolPromptConfig): void;
    resetPromptConfig(): void;
    get promptConfigInput(): CesToolGoogleSearchToolPromptConfig | undefined;
}
export interface CesToolPythonFunctionServiceDirectoryConfig {
    /**
    * The name of Service Directory service.
    * Format: projects/{project}/locations/{location}/namespaces/{namespace}/services/{service}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#service CesTool#service}
    */
    readonly service: string;
}
export declare function cesToolPythonFunctionServiceDirectoryConfigToTerraform(struct?: CesToolPythonFunctionServiceDirectoryConfigOutputReference | CesToolPythonFunctionServiceDirectoryConfig): any;
export declare function cesToolPythonFunctionServiceDirectoryConfigToHclTerraform(struct?: CesToolPythonFunctionServiceDirectoryConfigOutputReference | CesToolPythonFunctionServiceDirectoryConfig): any;
export declare class CesToolPythonFunctionServiceDirectoryConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolPythonFunctionServiceDirectoryConfig | undefined;
    set internalValue(value: CesToolPythonFunctionServiceDirectoryConfig | undefined);
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
}
export interface CesToolPythonFunction {
    /**
    * The name of the Python function to execute. Must match a Python function
    * name defined in the python code. Case sensitive. If the name is not
    * provided, the first function defined in the python code will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#name CesTool#name}
    */
    readonly name?: string;
    /**
    * The Python code to execute for the tool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#python_code CesTool#python_code}
    */
    readonly pythonCode?: string;
    /**
    * service_directory_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#service_directory_config CesTool#service_directory_config}
    */
    readonly serviceDirectoryConfig?: CesToolPythonFunctionServiceDirectoryConfig;
}
export declare function cesToolPythonFunctionToTerraform(struct?: CesToolPythonFunctionOutputReference | CesToolPythonFunction): any;
export declare function cesToolPythonFunctionToHclTerraform(struct?: CesToolPythonFunctionOutputReference | CesToolPythonFunction): any;
export declare class CesToolPythonFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolPythonFunction | undefined;
    set internalValue(value: CesToolPythonFunction | undefined);
    get description(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _pythonCode?;
    get pythonCode(): string;
    set pythonCode(value: string);
    resetPythonCode(): void;
    get pythonCodeInput(): string | undefined;
    private _serviceDirectoryConfig;
    get serviceDirectoryConfig(): CesToolPythonFunctionServiceDirectoryConfigOutputReference;
    putServiceDirectoryConfig(value: CesToolPythonFunctionServiceDirectoryConfig): void;
    resetServiceDirectoryConfig(): void;
    get serviceDirectoryConfigInput(): CesToolPythonFunctionServiceDirectoryConfig | undefined;
}
export interface CesToolTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#create CesTool#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#delete CesTool#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#update CesTool#update}
    */
    readonly update?: string;
}
export declare function cesToolTimeoutsToTerraform(struct?: CesToolTimeouts | cdktn.IResolvable): any;
export declare function cesToolTimeoutsToHclTerraform(struct?: CesToolTimeouts | cdktn.IResolvable): any;
export declare class CesToolTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CesToolTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface CesToolToolFakeConfigCodeBlock {
    /**
    * Python code which will be invoked in tool fake mode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#python_code CesTool#python_code}
    */
    readonly pythonCode: string;
}
export declare function cesToolToolFakeConfigCodeBlockToTerraform(struct?: CesToolToolFakeConfigCodeBlockOutputReference | CesToolToolFakeConfigCodeBlock): any;
export declare function cesToolToolFakeConfigCodeBlockToHclTerraform(struct?: CesToolToolFakeConfigCodeBlockOutputReference | CesToolToolFakeConfigCodeBlock): any;
export declare class CesToolToolFakeConfigCodeBlockOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolToolFakeConfigCodeBlock | undefined;
    set internalValue(value: CesToolToolFakeConfigCodeBlock | undefined);
    private _pythonCode?;
    get pythonCode(): string;
    set pythonCode(value: string);
    get pythonCodeInput(): string | undefined;
}
export interface CesToolToolFakeConfig {
    /**
    * Whether the tool is using fake mode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#enable_fake_mode CesTool#enable_fake_mode}
    */
    readonly enableFakeMode?: boolean | cdktn.IResolvable;
    /**
    * code_block block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#code_block CesTool#code_block}
    */
    readonly codeBlock?: CesToolToolFakeConfigCodeBlock;
}
export declare function cesToolToolFakeConfigToTerraform(struct?: CesToolToolFakeConfigOutputReference | CesToolToolFakeConfig): any;
export declare function cesToolToolFakeConfigToHclTerraform(struct?: CesToolToolFakeConfigOutputReference | CesToolToolFakeConfig): any;
export declare class CesToolToolFakeConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolToolFakeConfig | undefined;
    set internalValue(value: CesToolToolFakeConfig | undefined);
    private _enableFakeMode?;
    get enableFakeMode(): boolean | cdktn.IResolvable;
    set enableFakeMode(value: boolean | cdktn.IResolvable);
    resetEnableFakeMode(): void;
    get enableFakeModeInput(): boolean | cdktn.IResolvable | undefined;
    private _codeBlock;
    get codeBlock(): CesToolToolFakeConfigCodeBlockOutputReference;
    putCodeBlock(value: CesToolToolFakeConfigCodeBlock): void;
    resetCodeBlock(): void;
    get codeBlockInput(): CesToolToolFakeConfigCodeBlock | undefined;
}
export interface CesToolWidgetToolDataMappingPythonFunction {
    /**
    * Optional. The name of the Python function to execute. Must match a Python function
    * name defined in the python code. Case sensitive. If the name is not
    * provided, the first function defined in the python code will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#name CesTool#name}
    */
    readonly name?: string;
    /**
    * Optional. The Python code to execute for the tool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#python_code CesTool#python_code}
    */
    readonly pythonCode?: string;
}
export declare function cesToolWidgetToolDataMappingPythonFunctionToTerraform(struct?: CesToolWidgetToolDataMappingPythonFunctionOutputReference | CesToolWidgetToolDataMappingPythonFunction): any;
export declare function cesToolWidgetToolDataMappingPythonFunctionToHclTerraform(struct?: CesToolWidgetToolDataMappingPythonFunctionOutputReference | CesToolWidgetToolDataMappingPythonFunction): any;
export declare class CesToolWidgetToolDataMappingPythonFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolWidgetToolDataMappingPythonFunction | undefined;
    set internalValue(value: CesToolWidgetToolDataMappingPythonFunction | undefined);
    get description(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _pythonCode?;
    get pythonCode(): string;
    set pythonCode(value: string);
    resetPythonCode(): void;
    get pythonCodeInput(): string | undefined;
}
export interface CesToolWidgetToolDataMapping {
    /**
    * Optional. A map of widget input parameter fields to the corresponding output fields of the source tool.
    * An object containing a list of "key": value pairs. Example: { "name": "wrench", "mass": "1.3kg", "count": "3" }.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#field_mappings CesTool#field_mappings}
    */
    readonly fieldMappings?: {
        [key: string]: string;
    };
    /**
    * Optional. The mode of the data mapping.
    * Possible values:
    * MODE_UNSPECIFIED
    * FIELD_MAPPING
    * PYTHON_SCRIPT Possible values: ["MODE_UNSPECIFIED", "FIELD_MAPPING", "PYTHON_SCRIPT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#mode CesTool#mode}
    */
    readonly mode?: string;
    /**
    * Optional. The resource name of the tool that provides the data for the widget (e.g., a search tool or a custom function).
    * Format: projects/{project}/locations/{location}/agents/{agent}/tools/{tool}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#source_tool_name CesTool#source_tool_name}
    */
    readonly sourceToolName?: string;
    /**
    * python_function block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#python_function CesTool#python_function}
    */
    readonly pythonFunction?: CesToolWidgetToolDataMappingPythonFunction;
}
export declare function cesToolWidgetToolDataMappingToTerraform(struct?: CesToolWidgetToolDataMappingOutputReference | CesToolWidgetToolDataMapping): any;
export declare function cesToolWidgetToolDataMappingToHclTerraform(struct?: CesToolWidgetToolDataMappingOutputReference | CesToolWidgetToolDataMapping): any;
export declare class CesToolWidgetToolDataMappingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolWidgetToolDataMapping | undefined;
    set internalValue(value: CesToolWidgetToolDataMapping | undefined);
    private _fieldMappings?;
    get fieldMappings(): {
        [key: string]: string;
    };
    set fieldMappings(value: {
        [key: string]: string;
    });
    resetFieldMappings(): void;
    get fieldMappingsInput(): {
        [key: string]: string;
    } | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _sourceToolName?;
    get sourceToolName(): string;
    set sourceToolName(value: string);
    resetSourceToolName(): void;
    get sourceToolNameInput(): string | undefined;
    private _pythonFunction;
    get pythonFunction(): CesToolWidgetToolDataMappingPythonFunctionOutputReference;
    putPythonFunction(value: CesToolWidgetToolDataMappingPythonFunction): void;
    resetPythonFunction(): void;
    get pythonFunctionInput(): CesToolWidgetToolDataMappingPythonFunction | undefined;
}
export interface CesToolWidgetToolParameters {
    /**
    * Defines the schema for additional properties allowed in an object.
    * The value must be a valid JSON string representing the Schema object.
    * (Note: OpenAPI also allows a boolean, this definition expects a Schema JSON).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#additional_properties CesTool#additional_properties}
    */
    readonly additionalProperties?: string;
    /**
    * The instance value should be valid against at least one of the schemas in this list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#any_of CesTool#any_of}
    */
    readonly anyOf?: string;
    /**
    * Default value of the data. Represents a dynamically typed value
    * which can be either null, a number, a string, a boolean, a struct,
    * or a list of values. The provided default value must be compatible
    * with the defined 'type' and other schema constraints.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#default CesTool#default}
    */
    readonly default?: string;
    /**
    * A map of definitions for use by ref. Only allowed at the root of the schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#defs CesTool#defs}
    */
    readonly defs?: string;
    /**
    * The description of the data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#description CesTool#description}
    */
    readonly description?: string;
    /**
    * Possible values of the element of primitive type with enum format.
    * Examples:
    * 1. We can define direction as :
    * {type:STRING, format:enum, enum:["EAST", NORTH", "SOUTH", "WEST"]}
    * 2. We can define apartment number as :
    * {type:INTEGER, format:enum, enum:["101", "201", "301"]}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#enum CesTool#enum}
    */
    readonly enum?: string[];
    /**
    * Schema of the elements of Type.ARRAY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#items CesTool#items}
    */
    readonly items?: string;
    /**
    * Maximum number of the elements for Type.ARRAY. (int64 format)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#max_items CesTool#max_items}
    */
    readonly maxItems?: number;
    /**
    * Maximum value for Type.INTEGER and Type.NUMBER.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#maximum CesTool#maximum}
    */
    readonly maximum?: number;
    /**
    * Minimum number of the elements for Type.ARRAY. (int64 format)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#min_items CesTool#min_items}
    */
    readonly minItems?: number;
    /**
    * Minimum value for Type.INTEGER and Type.NUMBER.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#minimum CesTool#minimum}
    */
    readonly minimum?: number;
    /**
    * Indicates if the value may be null.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#nullable CesTool#nullable}
    */
    readonly nullable?: boolean | cdktn.IResolvable;
    /**
    * Schemas of initial elements of Type.ARRAY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#prefix_items CesTool#prefix_items}
    */
    readonly prefixItems?: string;
    /**
    * Properties of Type.OBJECT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#properties CesTool#properties}
    */
    readonly properties?: string;
    /**
    * Allows indirect references between schema nodes. The value should be a
    * valid reference to a child of the root 'defs'.
    * For example, the following schema defines a reference to a schema node
    * named "Pet":
    * type: object
    * properties:
    *   pet:
    *     ref: #/defs/Pet
    * defs:
    *   Pet:
    *     type: object
    *     properties:
    *       name:
    *         type: string
    * The value of the "pet" property is a reference to the schema node
    * named "Pet".
    * See details in
    * https://json-schema.org/understanding-json-schema/structuring.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#ref CesTool#ref}
    */
    readonly ref?: string;
    /**
    * Required properties of Type.OBJECT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#required CesTool#required}
    */
    readonly required?: string[];
    /**
    * The title of the schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#title CesTool#title}
    */
    readonly title?: string;
    /**
    * The type of the data.
    * Possible values:
    * STRING
    * INTEGER
    * NUMBER
    * BOOLEAN
    * OBJECT
    * ARRAY
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#type CesTool#type}
    */
    readonly type: string;
    /**
    * Indicate the items in the array must be unique. Only applies to TYPE.ARRAY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#unique_items CesTool#unique_items}
    */
    readonly uniqueItems?: boolean | cdktn.IResolvable;
}
export declare function cesToolWidgetToolParametersToTerraform(struct?: CesToolWidgetToolParametersOutputReference | CesToolWidgetToolParameters): any;
export declare function cesToolWidgetToolParametersToHclTerraform(struct?: CesToolWidgetToolParametersOutputReference | CesToolWidgetToolParameters): any;
export declare class CesToolWidgetToolParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolWidgetToolParameters | undefined;
    set internalValue(value: CesToolWidgetToolParameters | undefined);
    private _additionalProperties?;
    get additionalProperties(): string;
    set additionalProperties(value: string);
    resetAdditionalProperties(): void;
    get additionalPropertiesInput(): string | undefined;
    private _anyOf?;
    get anyOf(): string;
    set anyOf(value: string);
    resetAnyOf(): void;
    get anyOfInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _defs?;
    get defs(): string;
    set defs(value: string);
    resetDefs(): void;
    get defsInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enum?;
    get enum(): string[];
    set enum(value: string[]);
    resetEnum(): void;
    get enumInput(): string[] | undefined;
    private _items?;
    get items(): string;
    set items(value: string);
    resetItems(): void;
    get itemsInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _maximum?;
    get maximum(): number;
    set maximum(value: number);
    resetMaximum(): void;
    get maximumInput(): number | undefined;
    private _minItems?;
    get minItems(): number;
    set minItems(value: number);
    resetMinItems(): void;
    get minItemsInput(): number | undefined;
    private _minimum?;
    get minimum(): number;
    set minimum(value: number);
    resetMinimum(): void;
    get minimumInput(): number | undefined;
    private _nullable?;
    get nullable(): boolean | cdktn.IResolvable;
    set nullable(value: boolean | cdktn.IResolvable);
    resetNullable(): void;
    get nullableInput(): boolean | cdktn.IResolvable | undefined;
    private _prefixItems?;
    get prefixItems(): string;
    set prefixItems(value: string);
    resetPrefixItems(): void;
    get prefixItemsInput(): string | undefined;
    private _properties?;
    get properties(): string;
    set properties(value: string);
    resetProperties(): void;
    get propertiesInput(): string | undefined;
    private _ref?;
    get ref(): string;
    set ref(value: string);
    resetRef(): void;
    get refInput(): string | undefined;
    private _required?;
    get required(): string[];
    set required(value: string[]);
    resetRequired(): void;
    get requiredInput(): string[] | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _uniqueItems?;
    get uniqueItems(): boolean | cdktn.IResolvable;
    set uniqueItems(value: boolean | cdktn.IResolvable);
    resetUniqueItems(): void;
    get uniqueItemsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CesToolWidgetToolTextResponseConfig {
    /**
    * Optional. The static text response to return when type is STATIC.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#static_text CesTool#static_text}
    */
    readonly staticText?: string;
    /**
    * Optional. Instruction for the LLM on how to generate the text response. Used as
    * the description for the text response parameter if type is LLM_GENERATED.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#text_response_instruction CesTool#text_response_instruction}
    */
    readonly textResponseInstruction?: string;
    /**
    * Optional. The strategy for providing the text response.
    * Possible values:
    * TYPE_UNSPECIFIED
    * NONE
    * LLM_GENERATED
    * STATIC Possible values: ["TYPE_UNSPECIFIED", "NONE", "LLM_GENERATED", "STATIC"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#type CesTool#type}
    */
    readonly type?: string;
}
export declare function cesToolWidgetToolTextResponseConfigToTerraform(struct?: CesToolWidgetToolTextResponseConfigOutputReference | CesToolWidgetToolTextResponseConfig): any;
export declare function cesToolWidgetToolTextResponseConfigToHclTerraform(struct?: CesToolWidgetToolTextResponseConfigOutputReference | CesToolWidgetToolTextResponseConfig): any;
export declare class CesToolWidgetToolTextResponseConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolWidgetToolTextResponseConfig | undefined;
    set internalValue(value: CesToolWidgetToolTextResponseConfig | undefined);
    private _staticText?;
    get staticText(): string;
    set staticText(value: string);
    resetStaticText(): void;
    get staticTextInput(): string | undefined;
    private _textResponseInstruction?;
    get textResponseInstruction(): string;
    set textResponseInstruction(value: string);
    resetTextResponseInstruction(): void;
    get textResponseInstructionInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface CesToolWidgetTool {
    /**
    * Optional. The description of the widget tool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#description CesTool#description}
    */
    readonly description?: string;
    /**
    * Required. The display name of the widget tool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#name CesTool#name}
    */
    readonly name: string;
    /**
    * Optional. Configuration for rendering the widget. Represents a JSON object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#ui_config CesTool#ui_config}
    */
    readonly uiConfig?: string;
    /**
    * Optional. The type of the widget tool. If not specified, the default type will be CUSTOMIZED.
    * Possible values:
    * WIDGET_TYPE_UNSPECIFIED
    * CUSTOM
    * PRODUCT_CAROUSEL
    * PRODUCT_DETAILS
    * QUICK_ACTIONS
    * PRODUCT_COMPARISON
    * ADVANCED_PRODUCT_DETAILS
    * SHORT_FORM
    * OVERALL_SATISFACTION
    * ORDER_SUMMARY
    * APPOINTMENT_DETAILS
    * APPOINTMENT_SCHEDULER
    * CONTACT_FORM Possible values: ["WIDGET_TYPE_UNSPECIFIED", "CUSTOM", "PRODUCT_CAROUSEL", "PRODUCT_DETAILS", "QUICK_ACTIONS", "PRODUCT_COMPARISON", "ADVANCED_PRODUCT_DETAILS", "SHORT_FORM", "OVERALL_SATISFACTION", "ORDER_SUMMARY", "APPOINTMENT_DETAILS", "APPOINTMENT_SCHEDULER", "CONTACT_FORM"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#widget_type CesTool#widget_type}
    */
    readonly widgetType?: string;
    /**
    * data_mapping block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#data_mapping CesTool#data_mapping}
    */
    readonly dataMapping?: CesToolWidgetToolDataMapping;
    /**
    * parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#parameters CesTool#parameters}
    */
    readonly parameters?: CesToolWidgetToolParameters;
    /**
    * text_response_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#text_response_config CesTool#text_response_config}
    */
    readonly textResponseConfig?: CesToolWidgetToolTextResponseConfig;
}
export declare function cesToolWidgetToolToTerraform(struct?: CesToolWidgetToolOutputReference | CesToolWidgetTool): any;
export declare function cesToolWidgetToolToHclTerraform(struct?: CesToolWidgetToolOutputReference | CesToolWidgetTool): any;
export declare class CesToolWidgetToolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesToolWidgetTool | undefined;
    set internalValue(value: CesToolWidgetTool | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _uiConfig?;
    get uiConfig(): string;
    set uiConfig(value: string);
    resetUiConfig(): void;
    get uiConfigInput(): string | undefined;
    private _widgetType?;
    get widgetType(): string;
    set widgetType(value: string);
    resetWidgetType(): void;
    get widgetTypeInput(): string | undefined;
    private _dataMapping;
    get dataMapping(): CesToolWidgetToolDataMappingOutputReference;
    putDataMapping(value: CesToolWidgetToolDataMapping): void;
    resetDataMapping(): void;
    get dataMappingInput(): CesToolWidgetToolDataMapping | undefined;
    private _parameters;
    get parameters(): CesToolWidgetToolParametersOutputReference;
    putParameters(value: CesToolWidgetToolParameters): void;
    resetParameters(): void;
    get parametersInput(): CesToolWidgetToolParameters | undefined;
    private _textResponseConfig;
    get textResponseConfig(): CesToolWidgetToolTextResponseConfigOutputReference;
    putTextResponseConfig(value: CesToolWidgetToolTextResponseConfig): void;
    resetTextResponseConfig(): void;
    get textResponseConfigInput(): CesToolWidgetToolTextResponseConfig | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool google_ces_tool}
*/
export declare class CesTool extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_ces_tool";
    /**
    * Generates CDKTN code for importing a CesTool resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CesTool to import
    * @param importFromId The id of the existing CesTool that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CesTool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_tool google_ces_tool} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CesToolConfig
    */
    constructor(scope: Construct, id: string, config: CesToolConfig);
    private _app?;
    get app(): string;
    set app(value: string);
    get appInput(): string | undefined;
    private _connectorTool;
    get connectorTool(): CesToolConnectorToolList;
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    get displayName(): string;
    get etag(): string;
    private _executionType?;
    get executionType(): string;
    set executionType(value: string);
    resetExecutionType(): void;
    get executionTypeInput(): string | undefined;
    get generatedSummary(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _mcpTool;
    get mcpTool(): CesToolMcpToolList;
    get name(): string;
    private _openApiTool;
    get openApiTool(): CesToolOpenApiToolList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _remoteAgentTool;
    get remoteAgentTool(): CesToolRemoteAgentToolList;
    private _systemTool;
    get systemTool(): CesToolSystemToolList;
    private _timeout?;
    get timeout(): string;
    set timeout(value: string);
    resetTimeout(): void;
    get timeoutInput(): string | undefined;
    private _toolId?;
    get toolId(): string;
    set toolId(value: string);
    get toolIdInput(): string | undefined;
    get updateTime(): string;
    private _agentTool;
    get agentTool(): CesToolAgentToolOutputReference;
    putAgentTool(value: CesToolAgentTool): void;
    resetAgentTool(): void;
    get agentToolInput(): CesToolAgentTool | undefined;
    private _clientFunction;
    get clientFunction(): CesToolClientFunctionOutputReference;
    putClientFunction(value: CesToolClientFunction): void;
    resetClientFunction(): void;
    get clientFunctionInput(): CesToolClientFunction | undefined;
    private _dataStoreTool;
    get dataStoreTool(): CesToolDataStoreToolOutputReference;
    putDataStoreTool(value: CesToolDataStoreTool): void;
    resetDataStoreTool(): void;
    get dataStoreToolInput(): CesToolDataStoreTool | undefined;
    private _fileSearchTool;
    get fileSearchTool(): CesToolFileSearchToolOutputReference;
    putFileSearchTool(value: CesToolFileSearchTool): void;
    resetFileSearchTool(): void;
    get fileSearchToolInput(): CesToolFileSearchTool | undefined;
    private _googleSearchTool;
    get googleSearchTool(): CesToolGoogleSearchToolOutputReference;
    putGoogleSearchTool(value: CesToolGoogleSearchTool): void;
    resetGoogleSearchTool(): void;
    get googleSearchToolInput(): CesToolGoogleSearchTool | undefined;
    private _pythonFunction;
    get pythonFunction(): CesToolPythonFunctionOutputReference;
    putPythonFunction(value: CesToolPythonFunction): void;
    resetPythonFunction(): void;
    get pythonFunctionInput(): CesToolPythonFunction | undefined;
    private _timeouts;
    get timeouts(): CesToolTimeoutsOutputReference;
    putTimeouts(value: CesToolTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CesToolTimeouts | undefined;
    private _toolFakeConfig;
    get toolFakeConfig(): CesToolToolFakeConfigOutputReference;
    putToolFakeConfig(value: CesToolToolFakeConfig): void;
    resetToolFakeConfig(): void;
    get toolFakeConfigInput(): CesToolToolFakeConfig | undefined;
    private _widgetTool;
    get widgetTool(): CesToolWidgetToolOutputReference;
    putWidgetTool(value: CesToolWidgetTool): void;
    resetWidgetTool(): void;
    get widgetToolInput(): CesToolWidgetTool | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
