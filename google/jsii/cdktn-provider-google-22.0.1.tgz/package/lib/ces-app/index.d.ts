/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CesAppConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID to use for the app, which will become the final component of
    * the app's resource name. If not provided, a unique ID will be
    * automatically assigned for the app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#app_id CesApp#app_id}
    */
    readonly appId: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#deletion_policy CesApp#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Human-readable description of the app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#description CesApp#description}
    */
    readonly description?: string;
    /**
    * Display name of the app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#display_name CesApp#display_name}
    */
    readonly displayName: string;
    /**
    * Instructions for all the agents in the app.
    * You can use this instruction to set up a stable identity or personality
    * across all the agents.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#global_instruction CesApp#global_instruction}
    */
    readonly globalInstruction?: string;
    /**
    * List of guardrails for the app.
    * Format:
    * 'projects/{project}/locations/{location}/apps/{app}/guardrails/{guardrail}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#guardrails CesApp#guardrails}
    */
    readonly guardrails?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#id CesApp#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#location CesApp#location}
    */
    readonly location: string;
    /**
    * Indicates whether the app is locked for changes. If the app is locked,
    * modifications to the app resources will be rejected.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#locked CesApp#locked}
    */
    readonly locked?: boolean | cdktn.IResolvable;
    /**
    * Metadata about the app. This field can be used to store additional
    * information relevant to the app's details or intended usages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#metadata CesApp#metadata}
    */
    readonly metadata?: {
        [key: string]: string;
    };
    /**
    * Whether the app is pinned in the app list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#pinned CesApp#pinned}
    */
    readonly pinned?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#project CesApp#project}
    */
    readonly project?: string;
    /**
    * The root agent is the entry point of the app.
    * Format: 'projects/{project}/locations/{location}/apps/{app}/agents/{agent}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#root_agent CesApp#root_agent}
    */
    readonly rootAgent?: string;
    /**
    * The tool execution mode for the app.
    * See the [API reference](https://docs.cloud.google.com/customer-engagement-ai/conversational-agents/ps/reference/rpc/google.cloud.ces.v1#google.cloud.ces.v1.App.ToolExecutionMode) for more details.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#tool_execution_mode CesApp#tool_execution_mode}
    */
    readonly toolExecutionMode?: string;
    /**
    * audio_processing_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#audio_processing_config CesApp#audio_processing_config}
    */
    readonly audioProcessingConfig?: CesAppAudioProcessingConfig;
    /**
    * client_certificate_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#client_certificate_settings CesApp#client_certificate_settings}
    */
    readonly clientCertificateSettings?: CesAppClientCertificateSettings;
    /**
    * data_store_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#data_store_settings CesApp#data_store_settings}
    */
    readonly dataStoreSettings?: CesAppDataStoreSettings;
    /**
    * default_channel_profile block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#default_channel_profile CesApp#default_channel_profile}
    */
    readonly defaultChannelProfile?: CesAppDefaultChannelProfile;
    /**
    * error_handling_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#error_handling_settings CesApp#error_handling_settings}
    */
    readonly errorHandlingSettings?: CesAppErrorHandlingSettings;
    /**
    * evaluation_metrics_thresholds block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#evaluation_metrics_thresholds CesApp#evaluation_metrics_thresholds}
    */
    readonly evaluationMetricsThresholds?: CesAppEvaluationMetricsThresholds;
    /**
    * language_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#language_settings CesApp#language_settings}
    */
    readonly languageSettings?: CesAppLanguageSettings;
    /**
    * logging_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#logging_settings CesApp#logging_settings}
    */
    readonly loggingSettings?: CesAppLoggingSettings;
    /**
    * model_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#model_settings CesApp#model_settings}
    */
    readonly modelSettings?: CesAppModelSettings;
    /**
    * time_zone_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#time_zone_settings CesApp#time_zone_settings}
    */
    readonly timeZoneSettings?: CesAppTimeZoneSettings;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#timeouts CesApp#timeouts}
    */
    readonly timeouts?: CesAppTimeouts;
    /**
    * variable_declarations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#variable_declarations CesApp#variable_declarations}
    */
    readonly variableDeclarations?: CesAppVariableDeclarations[] | cdktn.IResolvable;
    /**
    * vpc_sc_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#vpc_sc_settings CesApp#vpc_sc_settings}
    */
    readonly vpcScSettings?: CesAppVpcScSettings;
}
export interface CesAppAudioProcessingConfigAmbientSoundConfig {
    /**
    * Ambient noise as a mono-channel, 16kHz WAV file stored in [Cloud
    * Storage](https://cloud.google.com/storage).
    * Note: Please make sure the CES service agent
    * 'service-@gcp-sa-ces.iam.gserviceaccount.com' has
    * 'storage.objects.get' permission to the Cloud Storage object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#gcs_uri CesApp#gcs_uri}
    */
    readonly gcsUri?: string;
    /**
    * Name of the prebuilt ambient sound.
    * Valid values are: - "coffee_shop" - "keyboard" - "keypad" - "hum"
    * -"office_1" - "office_2" - "office_3"
    * -"room_1" - "room_2" - "room_3"
    * -"room_4" - "room_5" - "air_conditioner"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#prebuilt_ambient_sound CesApp#prebuilt_ambient_sound}
    */
    readonly prebuiltAmbientSound?: string;
    /**
    * Volume gain (in dB) of the normal native volume supported by
    * ambient noise, in the range [-96.0, 16.0]. If unset, or set to a value of
    * 0.0 (dB), will play at normal native signal amplitude. A value of -6.0 (dB)
    * will play at approximately half the amplitude of the normal native signal
    * amplitude. A value of +6.0 (dB) will play at approximately twice the
    * amplitude of the normal native signal amplitude. We strongly recommend not
    * to exceed +10 (dB) as there's usually no effective increase in loudness for
    * any value greater than that.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#volume_gain_db CesApp#volume_gain_db}
    */
    readonly volumeGainDb?: number;
}
export declare function cesAppAudioProcessingConfigAmbientSoundConfigToTerraform(struct?: CesAppAudioProcessingConfigAmbientSoundConfigOutputReference | CesAppAudioProcessingConfigAmbientSoundConfig): any;
export declare function cesAppAudioProcessingConfigAmbientSoundConfigToHclTerraform(struct?: CesAppAudioProcessingConfigAmbientSoundConfigOutputReference | CesAppAudioProcessingConfigAmbientSoundConfig): any;
export declare class CesAppAudioProcessingConfigAmbientSoundConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppAudioProcessingConfigAmbientSoundConfig | undefined;
    set internalValue(value: CesAppAudioProcessingConfigAmbientSoundConfig | undefined);
    private _gcsUri?;
    get gcsUri(): string;
    set gcsUri(value: string);
    resetGcsUri(): void;
    get gcsUriInput(): string | undefined;
    private _prebuiltAmbientSound?;
    get prebuiltAmbientSound(): string;
    set prebuiltAmbientSound(value: string);
    resetPrebuiltAmbientSound(): void;
    get prebuiltAmbientSoundInput(): string | undefined;
    private _volumeGainDb?;
    get volumeGainDb(): number;
    set volumeGainDb(value: number);
    resetVolumeGainDb(): void;
    get volumeGainDbInput(): number | undefined;
}
export interface CesAppAudioProcessingConfigBargeInConfig {
    /**
    * If enabled, the agent will adapt its next response based on the assumption
    * that the user hasn't heard the full preceding agent message.
    * This should not be used in scenarios where agent responses are displayed
    * visually.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#barge_in_awareness CesApp#barge_in_awareness}
    */
    readonly bargeInAwareness?: boolean | cdktn.IResolvable;
}
export declare function cesAppAudioProcessingConfigBargeInConfigToTerraform(struct?: CesAppAudioProcessingConfigBargeInConfigOutputReference | CesAppAudioProcessingConfigBargeInConfig): any;
export declare function cesAppAudioProcessingConfigBargeInConfigToHclTerraform(struct?: CesAppAudioProcessingConfigBargeInConfigOutputReference | CesAppAudioProcessingConfigBargeInConfig): any;
export declare class CesAppAudioProcessingConfigBargeInConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppAudioProcessingConfigBargeInConfig | undefined;
    set internalValue(value: CesAppAudioProcessingConfigBargeInConfig | undefined);
    private _bargeInAwareness?;
    get bargeInAwareness(): boolean | cdktn.IResolvable;
    set bargeInAwareness(value: boolean | cdktn.IResolvable);
    resetBargeInAwareness(): void;
    get bargeInAwarenessInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CesAppAudioProcessingConfigSynthesizeSpeechConfigs {
    /**
    * The instruction used to synthesize speech when using a generative model.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#instruction CesApp#instruction}
    */
    readonly instruction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#language_code CesApp#language_code}
    */
    readonly languageCode: string;
    /**
    * The model used to synthesize audio.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#model CesApp#model}
    */
    readonly model?: string;
    /**
    * The speaking rate/speed in the range [0.25, 2.0]. 1.0 is the normal native
    * speed supported by the specific voice. 2.0 is twice as fast, and 0.5 is
    * half as fast. Values outside of the range [0.25, 2.0] will return an error.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#speaking_rate CesApp#speaking_rate}
    */
    readonly speakingRate?: number;
    /**
    * The name of the voice. If not set, the service will choose a
    * voice based on the other parameters such as language_code.
    * For the list of available voices, please refer to Supported voices and
    * languages from Cloud Text-to-Speech.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#voice CesApp#voice}
    */
    readonly voice?: string;
}
export declare function cesAppAudioProcessingConfigSynthesizeSpeechConfigsToTerraform(struct?: CesAppAudioProcessingConfigSynthesizeSpeechConfigs | cdktn.IResolvable): any;
export declare function cesAppAudioProcessingConfigSynthesizeSpeechConfigsToHclTerraform(struct?: CesAppAudioProcessingConfigSynthesizeSpeechConfigs | cdktn.IResolvable): any;
export declare class CesAppAudioProcessingConfigSynthesizeSpeechConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesAppAudioProcessingConfigSynthesizeSpeechConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: CesAppAudioProcessingConfigSynthesizeSpeechConfigs | cdktn.IResolvable | undefined);
    private _instruction?;
    get instruction(): string;
    set instruction(value: string);
    resetInstruction(): void;
    get instructionInput(): string | undefined;
    private _languageCode?;
    get languageCode(): string;
    set languageCode(value: string);
    get languageCodeInput(): string | undefined;
    private _model?;
    get model(): string;
    set model(value: string);
    resetModel(): void;
    get modelInput(): string | undefined;
    private _speakingRate?;
    get speakingRate(): number;
    set speakingRate(value: number);
    resetSpeakingRate(): void;
    get speakingRateInput(): number | undefined;
    private _voice?;
    get voice(): string;
    set voice(value: string);
    resetVoice(): void;
    get voiceInput(): string | undefined;
}
export declare class CesAppAudioProcessingConfigSynthesizeSpeechConfigsList extends cdktn.ComplexList {
    internalValue?: CesAppAudioProcessingConfigSynthesizeSpeechConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesAppAudioProcessingConfigSynthesizeSpeechConfigsOutputReference;
}
export interface CesAppAudioProcessingConfig {
    /**
    * The duration of user inactivity (no speech or interaction) before the agent
    * prompts the user for reengagement. If not set, the agent will not prompt
    * the user for reengagement.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#inactivity_timeout CesApp#inactivity_timeout}
    */
    readonly inactivityTimeout?: string;
    /**
    * ambient_sound_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#ambient_sound_config CesApp#ambient_sound_config}
    */
    readonly ambientSoundConfig?: CesAppAudioProcessingConfigAmbientSoundConfig;
    /**
    * barge_in_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#barge_in_config CesApp#barge_in_config}
    */
    readonly bargeInConfig?: CesAppAudioProcessingConfigBargeInConfig;
    /**
    * synthesize_speech_configs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#synthesize_speech_configs CesApp#synthesize_speech_configs}
    */
    readonly synthesizeSpeechConfigs?: CesAppAudioProcessingConfigSynthesizeSpeechConfigs[] | cdktn.IResolvable;
}
export declare function cesAppAudioProcessingConfigToTerraform(struct?: CesAppAudioProcessingConfigOutputReference | CesAppAudioProcessingConfig): any;
export declare function cesAppAudioProcessingConfigToHclTerraform(struct?: CesAppAudioProcessingConfigOutputReference | CesAppAudioProcessingConfig): any;
export declare class CesAppAudioProcessingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppAudioProcessingConfig | undefined;
    set internalValue(value: CesAppAudioProcessingConfig | undefined);
    private _inactivityTimeout?;
    get inactivityTimeout(): string;
    set inactivityTimeout(value: string);
    resetInactivityTimeout(): void;
    get inactivityTimeoutInput(): string | undefined;
    private _ambientSoundConfig;
    get ambientSoundConfig(): CesAppAudioProcessingConfigAmbientSoundConfigOutputReference;
    putAmbientSoundConfig(value: CesAppAudioProcessingConfigAmbientSoundConfig): void;
    resetAmbientSoundConfig(): void;
    get ambientSoundConfigInput(): CesAppAudioProcessingConfigAmbientSoundConfig | undefined;
    private _bargeInConfig;
    get bargeInConfig(): CesAppAudioProcessingConfigBargeInConfigOutputReference;
    putBargeInConfig(value: CesAppAudioProcessingConfigBargeInConfig): void;
    resetBargeInConfig(): void;
    get bargeInConfigInput(): CesAppAudioProcessingConfigBargeInConfig | undefined;
    private _synthesizeSpeechConfigs;
    get synthesizeSpeechConfigs(): CesAppAudioProcessingConfigSynthesizeSpeechConfigsList;
    putSynthesizeSpeechConfigs(value: CesAppAudioProcessingConfigSynthesizeSpeechConfigs[] | cdktn.IResolvable): void;
    resetSynthesizeSpeechConfigs(): void;
    get synthesizeSpeechConfigsInput(): cdktn.IResolvable | CesAppAudioProcessingConfigSynthesizeSpeechConfigs[] | undefined;
}
export interface CesAppClientCertificateSettings {
    /**
    * The passphrase to decrypt the private key.
    * Should be left unset if the private key is not encrypted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#passphrase CesApp#passphrase}
    */
    readonly passphrase?: string;
    /**
    * The name of the SecretManager secret version resource
    * storing the private key encoded in PEM format.
    * Format: projects/{project}/secrets/{secret}/versions/{version}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#private_key CesApp#private_key}
    */
    readonly privateKey: string;
    /**
    * The TLS certificate encoded in PEM format.
    * This string must include the begin header and end footer lines.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#tls_certificate CesApp#tls_certificate}
    */
    readonly tlsCertificate: string;
}
export declare function cesAppClientCertificateSettingsToTerraform(struct?: CesAppClientCertificateSettingsOutputReference | CesAppClientCertificateSettings): any;
export declare function cesAppClientCertificateSettingsToHclTerraform(struct?: CesAppClientCertificateSettingsOutputReference | CesAppClientCertificateSettings): any;
export declare class CesAppClientCertificateSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppClientCertificateSettings | undefined;
    set internalValue(value: CesAppClientCertificateSettings | undefined);
    private _passphrase?;
    get passphrase(): string;
    set passphrase(value: string);
    resetPassphrase(): void;
    get passphraseInput(): string | undefined;
    private _privateKey?;
    get privateKey(): string;
    set privateKey(value: string);
    get privateKeyInput(): string | undefined;
    private _tlsCertificate?;
    get tlsCertificate(): string;
    set tlsCertificate(value: string);
    get tlsCertificateInput(): string | undefined;
}
export interface CesAppDataStoreSettingsEngines {
}
export declare function cesAppDataStoreSettingsEnginesToTerraform(struct?: CesAppDataStoreSettingsEngines): any;
export declare function cesAppDataStoreSettingsEnginesToHclTerraform(struct?: CesAppDataStoreSettingsEngines): any;
export declare class CesAppDataStoreSettingsEnginesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesAppDataStoreSettingsEngines | undefined;
    set internalValue(value: CesAppDataStoreSettingsEngines | undefined);
    get name(): string;
    get type(): string;
}
export declare class CesAppDataStoreSettingsEnginesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesAppDataStoreSettingsEnginesOutputReference;
}
export interface CesAppDataStoreSettings {
}
export declare function cesAppDataStoreSettingsToTerraform(struct?: CesAppDataStoreSettingsOutputReference | CesAppDataStoreSettings): any;
export declare function cesAppDataStoreSettingsToHclTerraform(struct?: CesAppDataStoreSettingsOutputReference | CesAppDataStoreSettings): any;
export declare class CesAppDataStoreSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppDataStoreSettings | undefined;
    set internalValue(value: CesAppDataStoreSettings | undefined);
    private _engines;
    get engines(): CesAppDataStoreSettingsEnginesList;
}
export interface CesAppDefaultChannelProfilePersonaProperty {
    /**
    * The persona of the channel.
    * Possible values:
    * UNKNOWN
    * CONCISE
    * CHATTY
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#persona CesApp#persona}
    */
    readonly persona?: string;
}
export declare function cesAppDefaultChannelProfilePersonaPropertyToTerraform(struct?: CesAppDefaultChannelProfilePersonaPropertyOutputReference | CesAppDefaultChannelProfilePersonaProperty): any;
export declare function cesAppDefaultChannelProfilePersonaPropertyToHclTerraform(struct?: CesAppDefaultChannelProfilePersonaPropertyOutputReference | CesAppDefaultChannelProfilePersonaProperty): any;
export declare class CesAppDefaultChannelProfilePersonaPropertyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppDefaultChannelProfilePersonaProperty | undefined;
    set internalValue(value: CesAppDefaultChannelProfilePersonaProperty | undefined);
    private _persona?;
    get persona(): string;
    set persona(value: string);
    resetPersona(): void;
    get personaInput(): string | undefined;
}
export interface CesAppDefaultChannelProfileWebWidgetConfigSecuritySettings {
    /**
    * The origins that are allowed to host the web widget. An origin is
    * defined by RFC 6454. If empty, all origins are allowed.
    * A maximum of 100 origins is allowed.
    * Example: "https://example.com"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#allowed_origins CesApp#allowed_origins}
    */
    readonly allowedOrigins?: string[];
    /**
    * Indicates whether origin check for the web widget is enabled.
    * If 'true', the web widget will check the origin of the website that
    * loads the web widget and only allow it to be loaded in the same origin
    * or any of the allowed origins.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#enable_origin_check CesApp#enable_origin_check}
    */
    readonly enableOriginCheck?: boolean | cdktn.IResolvable;
    /**
    * Indicates whether public access to the web widget is enabled.
    * If 'true', the web widget will be publicly accessible.
    * If 'false', the web widget must be integrated with your own
    * authentication and authorization system to return valid credentials for
    * accessing the CES agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#enable_public_access CesApp#enable_public_access}
    */
    readonly enablePublicAccess?: boolean | cdktn.IResolvable;
    /**
    * Indicates whether reCAPTCHA verification for the web widget is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#enable_recaptcha CesApp#enable_recaptcha}
    */
    readonly enableRecaptcha?: boolean | cdktn.IResolvable;
}
export declare function cesAppDefaultChannelProfileWebWidgetConfigSecuritySettingsToTerraform(struct?: CesAppDefaultChannelProfileWebWidgetConfigSecuritySettingsOutputReference | CesAppDefaultChannelProfileWebWidgetConfigSecuritySettings): any;
export declare function cesAppDefaultChannelProfileWebWidgetConfigSecuritySettingsToHclTerraform(struct?: CesAppDefaultChannelProfileWebWidgetConfigSecuritySettingsOutputReference | CesAppDefaultChannelProfileWebWidgetConfigSecuritySettings): any;
export declare class CesAppDefaultChannelProfileWebWidgetConfigSecuritySettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppDefaultChannelProfileWebWidgetConfigSecuritySettings | undefined;
    set internalValue(value: CesAppDefaultChannelProfileWebWidgetConfigSecuritySettings | undefined);
    private _allowedOrigins?;
    get allowedOrigins(): string[];
    set allowedOrigins(value: string[]);
    resetAllowedOrigins(): void;
    get allowedOriginsInput(): string[] | undefined;
    private _enableOriginCheck?;
    get enableOriginCheck(): boolean | cdktn.IResolvable;
    set enableOriginCheck(value: boolean | cdktn.IResolvable);
    resetEnableOriginCheck(): void;
    get enableOriginCheckInput(): boolean | cdktn.IResolvable | undefined;
    private _enablePublicAccess?;
    get enablePublicAccess(): boolean | cdktn.IResolvable;
    set enablePublicAccess(value: boolean | cdktn.IResolvable);
    resetEnablePublicAccess(): void;
    get enablePublicAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _enableRecaptcha?;
    get enableRecaptcha(): boolean | cdktn.IResolvable;
    set enableRecaptcha(value: boolean | cdktn.IResolvable);
    resetEnableRecaptcha(): void;
    get enableRecaptchaInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CesAppDefaultChannelProfileWebWidgetConfig {
    /**
    * The modality of the web widget.
    * Possible values:
    * UNKNOWN_MODALITY
    * CHAT_AND_VOICE
    * VOICE_ONLY
    * CHAT_ONLY
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#modality CesApp#modality}
    */
    readonly modality?: string;
    /**
    * The theme of the web widget.
    * Possible values:
    * UNKNOWN_THEME
    * LIGHT
    * DARK
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#theme CesApp#theme}
    */
    readonly theme?: string;
    /**
    * The title of the web widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#web_widget_title CesApp#web_widget_title}
    */
    readonly webWidgetTitle?: string;
    /**
    * security_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#security_settings CesApp#security_settings}
    */
    readonly securitySettings?: CesAppDefaultChannelProfileWebWidgetConfigSecuritySettings;
}
export declare function cesAppDefaultChannelProfileWebWidgetConfigToTerraform(struct?: CesAppDefaultChannelProfileWebWidgetConfigOutputReference | CesAppDefaultChannelProfileWebWidgetConfig): any;
export declare function cesAppDefaultChannelProfileWebWidgetConfigToHclTerraform(struct?: CesAppDefaultChannelProfileWebWidgetConfigOutputReference | CesAppDefaultChannelProfileWebWidgetConfig): any;
export declare class CesAppDefaultChannelProfileWebWidgetConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppDefaultChannelProfileWebWidgetConfig | undefined;
    set internalValue(value: CesAppDefaultChannelProfileWebWidgetConfig | undefined);
    private _modality?;
    get modality(): string;
    set modality(value: string);
    resetModality(): void;
    get modalityInput(): string | undefined;
    private _theme?;
    get theme(): string;
    set theme(value: string);
    resetTheme(): void;
    get themeInput(): string | undefined;
    private _webWidgetTitle?;
    get webWidgetTitle(): string;
    set webWidgetTitle(value: string);
    resetWebWidgetTitle(): void;
    get webWidgetTitleInput(): string | undefined;
    private _securitySettings;
    get securitySettings(): CesAppDefaultChannelProfileWebWidgetConfigSecuritySettingsOutputReference;
    putSecuritySettings(value: CesAppDefaultChannelProfileWebWidgetConfigSecuritySettings): void;
    resetSecuritySettings(): void;
    get securitySettingsInput(): CesAppDefaultChannelProfileWebWidgetConfigSecuritySettings | undefined;
}
export interface CesAppDefaultChannelProfileWhatsappConfig {
    /**
    * The phone number in E.164 format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#phone_number CesApp#phone_number}
    */
    readonly phoneNumber?: string;
    /**
    * The Meta phone number ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#phone_number_id CesApp#phone_number_id}
    */
    readonly phoneNumberId: string;
    /**
    * The WhatsApp Business Account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#waba_id CesApp#waba_id}
    */
    readonly wabaId: string;
}
export declare function cesAppDefaultChannelProfileWhatsappConfigToTerraform(struct?: CesAppDefaultChannelProfileWhatsappConfigOutputReference | CesAppDefaultChannelProfileWhatsappConfig): any;
export declare function cesAppDefaultChannelProfileWhatsappConfigToHclTerraform(struct?: CesAppDefaultChannelProfileWhatsappConfigOutputReference | CesAppDefaultChannelProfileWhatsappConfig): any;
export declare class CesAppDefaultChannelProfileWhatsappConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppDefaultChannelProfileWhatsappConfig | undefined;
    set internalValue(value: CesAppDefaultChannelProfileWhatsappConfig | undefined);
    get description(): string;
    get displayName(): string;
    private _phoneNumber?;
    get phoneNumber(): string;
    set phoneNumber(value: string);
    resetPhoneNumber(): void;
    get phoneNumberInput(): string | undefined;
    private _phoneNumberId?;
    get phoneNumberId(): string;
    set phoneNumberId(value: string);
    get phoneNumberIdInput(): string | undefined;
    get thumbnailUrl(): string;
    private _wabaId?;
    get wabaId(): string;
    set wabaId(value: string);
    get wabaIdInput(): string | undefined;
}
export interface CesAppDefaultChannelProfile {
    /**
    * The type of the channel profile.
    * Possible values:
    * UNKNOWN
    * WEB_UI
    * API
    * TWILIO
    * GOOGLE_TELEPHONY_PLATFORM
    * CONTACT_CENTER_AS_A_SERVICE
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#channel_type CesApp#channel_type}
    */
    readonly channelType?: string;
    /**
    * Whether to disable user barge-in in the conversation.
    * - true: User interruptions are disabled while the agent is speaking.
    * - false: The agent retains automatic control over when the user can interrupt.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#disable_barge_in_control CesApp#disable_barge_in_control}
    */
    readonly disableBargeInControl?: boolean | cdktn.IResolvable;
    /**
    * Whether to disable DTMF (dual-tone multi-frequency).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#disable_dtmf CesApp#disable_dtmf}
    */
    readonly disableDtmf?: boolean | cdktn.IResolvable;
    /**
    * The unique identifier of the channel profile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#profile_id CesApp#profile_id}
    */
    readonly profileId?: string;
    /**
    * persona_property block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#persona_property CesApp#persona_property}
    */
    readonly personaProperty?: CesAppDefaultChannelProfilePersonaProperty;
    /**
    * web_widget_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#web_widget_config CesApp#web_widget_config}
    */
    readonly webWidgetConfig?: CesAppDefaultChannelProfileWebWidgetConfig;
    /**
    * whatsapp_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#whatsapp_config CesApp#whatsapp_config}
    */
    readonly whatsappConfig?: CesAppDefaultChannelProfileWhatsappConfig;
}
export declare function cesAppDefaultChannelProfileToTerraform(struct?: CesAppDefaultChannelProfileOutputReference | CesAppDefaultChannelProfile): any;
export declare function cesAppDefaultChannelProfileToHclTerraform(struct?: CesAppDefaultChannelProfileOutputReference | CesAppDefaultChannelProfile): any;
export declare class CesAppDefaultChannelProfileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppDefaultChannelProfile | undefined;
    set internalValue(value: CesAppDefaultChannelProfile | undefined);
    private _channelType?;
    get channelType(): string;
    set channelType(value: string);
    resetChannelType(): void;
    get channelTypeInput(): string | undefined;
    private _disableBargeInControl?;
    get disableBargeInControl(): boolean | cdktn.IResolvable;
    set disableBargeInControl(value: boolean | cdktn.IResolvable);
    resetDisableBargeInControl(): void;
    get disableBargeInControlInput(): boolean | cdktn.IResolvable | undefined;
    private _disableDtmf?;
    get disableDtmf(): boolean | cdktn.IResolvable;
    set disableDtmf(value: boolean | cdktn.IResolvable);
    resetDisableDtmf(): void;
    get disableDtmfInput(): boolean | cdktn.IResolvable | undefined;
    private _profileId?;
    get profileId(): string;
    set profileId(value: string);
    resetProfileId(): void;
    get profileIdInput(): string | undefined;
    private _personaProperty;
    get personaProperty(): CesAppDefaultChannelProfilePersonaPropertyOutputReference;
    putPersonaProperty(value: CesAppDefaultChannelProfilePersonaProperty): void;
    resetPersonaProperty(): void;
    get personaPropertyInput(): CesAppDefaultChannelProfilePersonaProperty | undefined;
    private _webWidgetConfig;
    get webWidgetConfig(): CesAppDefaultChannelProfileWebWidgetConfigOutputReference;
    putWebWidgetConfig(value: CesAppDefaultChannelProfileWebWidgetConfig): void;
    resetWebWidgetConfig(): void;
    get webWidgetConfigInput(): CesAppDefaultChannelProfileWebWidgetConfig | undefined;
    private _whatsappConfig;
    get whatsappConfig(): CesAppDefaultChannelProfileWhatsappConfigOutputReference;
    putWhatsappConfig(value: CesAppDefaultChannelProfileWhatsappConfig): void;
    resetWhatsappConfig(): void;
    get whatsappConfigInput(): CesAppDefaultChannelProfileWhatsappConfig | undefined;
}
export interface CesAppErrorHandlingSettingsEndSessionConfig {
    /**
    * Whether to escalate the session in EndSession. If session is escalated,
    * metadata in EndSession will contain session_escalated = true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#escalate_session CesApp#escalate_session}
    */
    readonly escalateSession?: boolean | cdktn.IResolvable;
}
export declare function cesAppErrorHandlingSettingsEndSessionConfigToTerraform(struct?: CesAppErrorHandlingSettingsEndSessionConfigOutputReference | CesAppErrorHandlingSettingsEndSessionConfig): any;
export declare function cesAppErrorHandlingSettingsEndSessionConfigToHclTerraform(struct?: CesAppErrorHandlingSettingsEndSessionConfigOutputReference | CesAppErrorHandlingSettingsEndSessionConfig): any;
export declare class CesAppErrorHandlingSettingsEndSessionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppErrorHandlingSettingsEndSessionConfig | undefined;
    set internalValue(value: CesAppErrorHandlingSettingsEndSessionConfig | undefined);
    private _escalateSession?;
    get escalateSession(): boolean | cdktn.IResolvable;
    set escalateSession(value: boolean | cdktn.IResolvable);
    resetEscalateSession(): void;
    get escalateSessionInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CesAppErrorHandlingSettingsFallbackResponseConfig {
    /**
    * The fallback messages in case of system errors (e.g. LLM errors),
    * mapped by supported language code
    * (https://docs.cloud.google.com/customer-engagement-ai/conversational-agents/ps/reference/language).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#custom_fallback_messages CesApp#custom_fallback_messages}
    */
    readonly customFallbackMessages?: {
        [key: string]: string;
    };
    /**
    * The maximum number of fallback attempts to make before the agent
    * emitting EndSession Signal.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#max_fallback_attempts CesApp#max_fallback_attempts}
    */
    readonly maxFallbackAttempts?: number;
}
export declare function cesAppErrorHandlingSettingsFallbackResponseConfigToTerraform(struct?: CesAppErrorHandlingSettingsFallbackResponseConfigOutputReference | CesAppErrorHandlingSettingsFallbackResponseConfig): any;
export declare function cesAppErrorHandlingSettingsFallbackResponseConfigToHclTerraform(struct?: CesAppErrorHandlingSettingsFallbackResponseConfigOutputReference | CesAppErrorHandlingSettingsFallbackResponseConfig): any;
export declare class CesAppErrorHandlingSettingsFallbackResponseConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppErrorHandlingSettingsFallbackResponseConfig | undefined;
    set internalValue(value: CesAppErrorHandlingSettingsFallbackResponseConfig | undefined);
    private _customFallbackMessages?;
    get customFallbackMessages(): {
        [key: string]: string;
    };
    set customFallbackMessages(value: {
        [key: string]: string;
    });
    resetCustomFallbackMessages(): void;
    get customFallbackMessagesInput(): {
        [key: string]: string;
    } | undefined;
    private _maxFallbackAttempts?;
    get maxFallbackAttempts(): number;
    set maxFallbackAttempts(value: number);
    resetMaxFallbackAttempts(): void;
    get maxFallbackAttemptsInput(): number | undefined;
}
export interface CesAppErrorHandlingSettings {
    /**
    * The strategy to use for error handling.
    * Possible values:
    * NONE
    * FALLBACK_RESPONSE
    * END_SESSION
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#error_handling_strategy CesApp#error_handling_strategy}
    */
    readonly errorHandlingStrategy?: string;
    /**
    * end_session_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#end_session_config CesApp#end_session_config}
    */
    readonly endSessionConfig?: CesAppErrorHandlingSettingsEndSessionConfig;
    /**
    * fallback_response_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#fallback_response_config CesApp#fallback_response_config}
    */
    readonly fallbackResponseConfig?: CesAppErrorHandlingSettingsFallbackResponseConfig;
}
export declare function cesAppErrorHandlingSettingsToTerraform(struct?: CesAppErrorHandlingSettingsOutputReference | CesAppErrorHandlingSettings): any;
export declare function cesAppErrorHandlingSettingsToHclTerraform(struct?: CesAppErrorHandlingSettingsOutputReference | CesAppErrorHandlingSettings): any;
export declare class CesAppErrorHandlingSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppErrorHandlingSettings | undefined;
    set internalValue(value: CesAppErrorHandlingSettings | undefined);
    private _errorHandlingStrategy?;
    get errorHandlingStrategy(): string;
    set errorHandlingStrategy(value: string);
    resetErrorHandlingStrategy(): void;
    get errorHandlingStrategyInput(): string | undefined;
    private _endSessionConfig;
    get endSessionConfig(): CesAppErrorHandlingSettingsEndSessionConfigOutputReference;
    putEndSessionConfig(value: CesAppErrorHandlingSettingsEndSessionConfig): void;
    resetEndSessionConfig(): void;
    get endSessionConfigInput(): CesAppErrorHandlingSettingsEndSessionConfig | undefined;
    private _fallbackResponseConfig;
    get fallbackResponseConfig(): CesAppErrorHandlingSettingsFallbackResponseConfigOutputReference;
    putFallbackResponseConfig(value: CesAppErrorHandlingSettingsFallbackResponseConfig): void;
    resetFallbackResponseConfig(): void;
    get fallbackResponseConfigInput(): CesAppErrorHandlingSettingsFallbackResponseConfig | undefined;
}
export interface CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsExpectationLevelMetricsThresholds {
    /**
    * The success threshold for individual tool invocation parameter
    * correctness. Must be a float between 0 and 1. Default is 1.0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#tool_invocation_parameter_correctness_threshold CesApp#tool_invocation_parameter_correctness_threshold}
    */
    readonly toolInvocationParameterCorrectnessThreshold?: number;
}
export declare function cesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsExpectationLevelMetricsThresholdsToTerraform(struct?: CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsExpectationLevelMetricsThresholdsOutputReference | CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsExpectationLevelMetricsThresholds): any;
export declare function cesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsExpectationLevelMetricsThresholdsToHclTerraform(struct?: CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsExpectationLevelMetricsThresholdsOutputReference | CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsExpectationLevelMetricsThresholds): any;
export declare class CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsExpectationLevelMetricsThresholdsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsExpectationLevelMetricsThresholds | undefined;
    set internalValue(value: CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsExpectationLevelMetricsThresholds | undefined);
    private _toolInvocationParameterCorrectnessThreshold?;
    get toolInvocationParameterCorrectnessThreshold(): number;
    set toolInvocationParameterCorrectnessThreshold(value: number);
    resetToolInvocationParameterCorrectnessThreshold(): void;
    get toolInvocationParameterCorrectnessThresholdInput(): number | undefined;
}
export interface CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsToolMatchingSettings {
    /**
    * Defines the behavior when an extra tool call is encountered. An extra
    * tool call is a tool call that is present in the execution but does
    * not match any tool call in the golden expectation. Possible values: ["FAIL", "ALLOW"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#extra_tool_call_behavior CesApp#extra_tool_call_behavior}
    */
    readonly extraToolCallBehavior?: string;
}
export declare function cesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsToolMatchingSettingsToTerraform(struct?: CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsToolMatchingSettingsOutputReference | CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsToolMatchingSettings): any;
export declare function cesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsToolMatchingSettingsToHclTerraform(struct?: CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsToolMatchingSettingsOutputReference | CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsToolMatchingSettings): any;
export declare class CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsToolMatchingSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsToolMatchingSettings | undefined;
    set internalValue(value: CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsToolMatchingSettings | undefined);
    private _extraToolCallBehavior?;
    get extraToolCallBehavior(): string;
    set extraToolCallBehavior(value: string);
    resetExtraToolCallBehavior(): void;
    get extraToolCallBehaviorInput(): string | undefined;
}
export interface CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsTurnLevelMetricsThresholds {
    /**
    * The success threshold for overall tool invocation correctness. Must be
    * a float between 0 and 1. Default is 1.0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#overall_tool_invocation_correctness_threshold CesApp#overall_tool_invocation_correctness_threshold}
    */
    readonly overallToolInvocationCorrectnessThreshold?: number;
    /**
    * The semantic similarity channel to use for evaluation.
    * Possible values:
    * SEMANTIC_SIMILARITY_CHANNEL_UNSPECIFIED
    * TEXT
    * AUDIO
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#semantic_similarity_channel CesApp#semantic_similarity_channel}
    */
    readonly semanticSimilarityChannel?: string;
    /**
    * The success threshold for semantic similarity. Must be an integer
    * between 0 and 4. Default is >= 3.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#semantic_similarity_success_threshold CesApp#semantic_similarity_success_threshold}
    */
    readonly semanticSimilaritySuccessThreshold?: number;
}
export declare function cesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsTurnLevelMetricsThresholdsToTerraform(struct?: CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsTurnLevelMetricsThresholdsOutputReference | CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsTurnLevelMetricsThresholds): any;
export declare function cesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsTurnLevelMetricsThresholdsToHclTerraform(struct?: CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsTurnLevelMetricsThresholdsOutputReference | CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsTurnLevelMetricsThresholds): any;
export declare class CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsTurnLevelMetricsThresholdsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsTurnLevelMetricsThresholds | undefined;
    set internalValue(value: CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsTurnLevelMetricsThresholds | undefined);
    private _overallToolInvocationCorrectnessThreshold?;
    get overallToolInvocationCorrectnessThreshold(): number;
    set overallToolInvocationCorrectnessThreshold(value: number);
    resetOverallToolInvocationCorrectnessThreshold(): void;
    get overallToolInvocationCorrectnessThresholdInput(): number | undefined;
    private _semanticSimilarityChannel?;
    get semanticSimilarityChannel(): string;
    set semanticSimilarityChannel(value: string);
    resetSemanticSimilarityChannel(): void;
    get semanticSimilarityChannelInput(): string | undefined;
    private _semanticSimilaritySuccessThreshold?;
    get semanticSimilaritySuccessThreshold(): number;
    set semanticSimilaritySuccessThreshold(value: number);
    resetSemanticSimilaritySuccessThreshold(): void;
    get semanticSimilaritySuccessThresholdInput(): number | undefined;
}
export interface CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholds {
    /**
    * expectation_level_metrics_thresholds block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#expectation_level_metrics_thresholds CesApp#expectation_level_metrics_thresholds}
    */
    readonly expectationLevelMetricsThresholds?: CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsExpectationLevelMetricsThresholds;
    /**
    * tool_matching_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#tool_matching_settings CesApp#tool_matching_settings}
    */
    readonly toolMatchingSettings?: CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsToolMatchingSettings;
    /**
    * turn_level_metrics_thresholds block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#turn_level_metrics_thresholds CesApp#turn_level_metrics_thresholds}
    */
    readonly turnLevelMetricsThresholds?: CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsTurnLevelMetricsThresholds;
}
export declare function cesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsToTerraform(struct?: CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsOutputReference | CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholds): any;
export declare function cesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsToHclTerraform(struct?: CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsOutputReference | CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholds): any;
export declare class CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholds | undefined;
    set internalValue(value: CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholds | undefined);
    private _expectationLevelMetricsThresholds;
    get expectationLevelMetricsThresholds(): CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsExpectationLevelMetricsThresholdsOutputReference;
    putExpectationLevelMetricsThresholds(value: CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsExpectationLevelMetricsThresholds): void;
    resetExpectationLevelMetricsThresholds(): void;
    get expectationLevelMetricsThresholdsInput(): CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsExpectationLevelMetricsThresholds | undefined;
    private _toolMatchingSettings;
    get toolMatchingSettings(): CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsToolMatchingSettingsOutputReference;
    putToolMatchingSettings(value: CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsToolMatchingSettings): void;
    resetToolMatchingSettings(): void;
    get toolMatchingSettingsInput(): CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsToolMatchingSettings | undefined;
    private _turnLevelMetricsThresholds;
    get turnLevelMetricsThresholds(): CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsTurnLevelMetricsThresholdsOutputReference;
    putTurnLevelMetricsThresholds(value: CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsTurnLevelMetricsThresholds): void;
    resetTurnLevelMetricsThresholds(): void;
    get turnLevelMetricsThresholdsInput(): CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsTurnLevelMetricsThresholds | undefined;
}
export interface CesAppEvaluationMetricsThresholds {
    /**
    * The hallucination metric behavior for golden evaluations. Possible values: ["DISABLED", "ENABLED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#golden_hallucination_metric_behavior CesApp#golden_hallucination_metric_behavior}
    */
    readonly goldenHallucinationMetricBehavior?: string;
    /**
    * The hallucination metric behavior for scenario evaluations. Possible values: ["DISABLED", "ENABLED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#scenario_hallucination_metric_behavior CesApp#scenario_hallucination_metric_behavior}
    */
    readonly scenarioHallucinationMetricBehavior?: string;
    /**
    * golden_evaluation_metrics_thresholds block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#golden_evaluation_metrics_thresholds CesApp#golden_evaluation_metrics_thresholds}
    */
    readonly goldenEvaluationMetricsThresholds?: CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholds;
}
export declare function cesAppEvaluationMetricsThresholdsToTerraform(struct?: CesAppEvaluationMetricsThresholdsOutputReference | CesAppEvaluationMetricsThresholds): any;
export declare function cesAppEvaluationMetricsThresholdsToHclTerraform(struct?: CesAppEvaluationMetricsThresholdsOutputReference | CesAppEvaluationMetricsThresholds): any;
export declare class CesAppEvaluationMetricsThresholdsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppEvaluationMetricsThresholds | undefined;
    set internalValue(value: CesAppEvaluationMetricsThresholds | undefined);
    private _goldenHallucinationMetricBehavior?;
    get goldenHallucinationMetricBehavior(): string;
    set goldenHallucinationMetricBehavior(value: string);
    resetGoldenHallucinationMetricBehavior(): void;
    get goldenHallucinationMetricBehaviorInput(): string | undefined;
    private _scenarioHallucinationMetricBehavior?;
    get scenarioHallucinationMetricBehavior(): string;
    set scenarioHallucinationMetricBehavior(value: string);
    resetScenarioHallucinationMetricBehavior(): void;
    get scenarioHallucinationMetricBehaviorInput(): string | undefined;
    private _goldenEvaluationMetricsThresholds;
    get goldenEvaluationMetricsThresholds(): CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholdsOutputReference;
    putGoldenEvaluationMetricsThresholds(value: CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholds): void;
    resetGoldenEvaluationMetricsThresholds(): void;
    get goldenEvaluationMetricsThresholdsInput(): CesAppEvaluationMetricsThresholdsGoldenEvaluationMetricsThresholds | undefined;
}
export interface CesAppLanguageSettings {
    /**
    * The default language code of the app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#default_language_code CesApp#default_language_code}
    */
    readonly defaultLanguageCode?: string;
    /**
    * Enables multilingual support. If true, agents in the app will use pre-built
    * instructions to improve handling of multilingual input.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#enable_multilingual_support CesApp#enable_multilingual_support}
    */
    readonly enableMultilingualSupport?: boolean | cdktn.IResolvable;
    /**
    * The action to perform when an agent receives input in an unsupported
    * language.
    * This can be a predefined action or a custom tool call.
    * Valid values are:
    * - A tool's full resource name, which triggers a specific tool execution.
    * - A predefined system action, such as "escalate" or "exit", which triggers
    * an EndSession signal with corresponding metadata
    * to terminate the conversation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#fallback_action CesApp#fallback_action}
    */
    readonly fallbackAction?: string;
    /**
    * List of languages codes supported by the app, in addition to the
    * 'default_language_code'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#supported_language_codes CesApp#supported_language_codes}
    */
    readonly supportedLanguageCodes?: string[];
}
export declare function cesAppLanguageSettingsToTerraform(struct?: CesAppLanguageSettingsOutputReference | CesAppLanguageSettings): any;
export declare function cesAppLanguageSettingsToHclTerraform(struct?: CesAppLanguageSettingsOutputReference | CesAppLanguageSettings): any;
export declare class CesAppLanguageSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppLanguageSettings | undefined;
    set internalValue(value: CesAppLanguageSettings | undefined);
    private _defaultLanguageCode?;
    get defaultLanguageCode(): string;
    set defaultLanguageCode(value: string);
    resetDefaultLanguageCode(): void;
    get defaultLanguageCodeInput(): string | undefined;
    private _enableMultilingualSupport?;
    get enableMultilingualSupport(): boolean | cdktn.IResolvable;
    set enableMultilingualSupport(value: boolean | cdktn.IResolvable);
    resetEnableMultilingualSupport(): void;
    get enableMultilingualSupportInput(): boolean | cdktn.IResolvable | undefined;
    private _fallbackAction?;
    get fallbackAction(): string;
    set fallbackAction(value: string);
    resetFallbackAction(): void;
    get fallbackActionInput(): string | undefined;
    private _supportedLanguageCodes?;
    get supportedLanguageCodes(): string[];
    set supportedLanguageCodes(value: string[]);
    resetSupportedLanguageCodes(): void;
    get supportedLanguageCodesInput(): string[] | undefined;
}
export interface CesAppLoggingSettingsAudioRecordingConfig {
    /**
    * The [Cloud Storage](https://cloud.google.com/storage) bucket to store the
    * session audio recordings. The URI must start with "gs://".
    * Note: If the Cloud Storage bucket is in a different project from the app,
    * you should grant 'storage.objects.create' permission to the CES service
    * agent 'service-@gcp-sa-ces.iam.gserviceaccount.com'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#gcs_bucket CesApp#gcs_bucket}
    */
    readonly gcsBucket?: string;
    /**
    * The Cloud Storage path prefix for audio recordings.
    * This prefix can include the following placeholders, which will be
    * dynamically substituted at serving time:
    * - $project:   project ID
    * - $location:  app location
    * - $app:       app ID
    * - $date:      session date in YYYY-MM-DD format
    * - $session:   session ID
    * If the path prefix is not specified, the default prefix
    * '$project/$location/$app/$date/$session/' will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#gcs_path_prefix CesApp#gcs_path_prefix}
    */
    readonly gcsPathPrefix?: string;
}
export declare function cesAppLoggingSettingsAudioRecordingConfigToTerraform(struct?: CesAppLoggingSettingsAudioRecordingConfigOutputReference | CesAppLoggingSettingsAudioRecordingConfig): any;
export declare function cesAppLoggingSettingsAudioRecordingConfigToHclTerraform(struct?: CesAppLoggingSettingsAudioRecordingConfigOutputReference | CesAppLoggingSettingsAudioRecordingConfig): any;
export declare class CesAppLoggingSettingsAudioRecordingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppLoggingSettingsAudioRecordingConfig | undefined;
    set internalValue(value: CesAppLoggingSettingsAudioRecordingConfig | undefined);
    private _gcsBucket?;
    get gcsBucket(): string;
    set gcsBucket(value: string);
    resetGcsBucket(): void;
    get gcsBucketInput(): string | undefined;
    private _gcsPathPrefix?;
    get gcsPathPrefix(): string;
    set gcsPathPrefix(value: string);
    resetGcsPathPrefix(): void;
    get gcsPathPrefixInput(): string | undefined;
}
export interface CesAppLoggingSettingsBigqueryExportSettings {
    /**
    * The BigQuery dataset to export the data to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#dataset CesApp#dataset}
    */
    readonly dataset?: string;
    /**
    * Indicates whether the BigQuery export is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#enabled CesApp#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The project ID of the BigQuery dataset to export the data to.
    * Note: If the BigQuery dataset is in a different project from the app, you should grant
    * roles/bigquery.admin role to the CES service agent service-<PROJECT-
    * NUMBER>@gcp-sa-ces.iam.gserviceaccount.com.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#project CesApp#project}
    */
    readonly project?: string;
}
export declare function cesAppLoggingSettingsBigqueryExportSettingsToTerraform(struct?: CesAppLoggingSettingsBigqueryExportSettingsOutputReference | CesAppLoggingSettingsBigqueryExportSettings): any;
export declare function cesAppLoggingSettingsBigqueryExportSettingsToHclTerraform(struct?: CesAppLoggingSettingsBigqueryExportSettingsOutputReference | CesAppLoggingSettingsBigqueryExportSettings): any;
export declare class CesAppLoggingSettingsBigqueryExportSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppLoggingSettingsBigqueryExportSettings | undefined;
    set internalValue(value: CesAppLoggingSettingsBigqueryExportSettings | undefined);
    private _dataset?;
    get dataset(): string;
    set dataset(value: string);
    resetDataset(): void;
    get datasetInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
}
export interface CesAppLoggingSettingsCloudLoggingSettings {
    /**
    * Whether to enable Cloud Logging for the sessions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#enable_cloud_logging CesApp#enable_cloud_logging}
    */
    readonly enableCloudLogging?: boolean | cdktn.IResolvable;
}
export declare function cesAppLoggingSettingsCloudLoggingSettingsToTerraform(struct?: CesAppLoggingSettingsCloudLoggingSettingsOutputReference | CesAppLoggingSettingsCloudLoggingSettings): any;
export declare function cesAppLoggingSettingsCloudLoggingSettingsToHclTerraform(struct?: CesAppLoggingSettingsCloudLoggingSettingsOutputReference | CesAppLoggingSettingsCloudLoggingSettings): any;
export declare class CesAppLoggingSettingsCloudLoggingSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppLoggingSettingsCloudLoggingSettings | undefined;
    set internalValue(value: CesAppLoggingSettingsCloudLoggingSettings | undefined);
    private _enableCloudLogging?;
    get enableCloudLogging(): boolean | cdktn.IResolvable;
    set enableCloudLogging(value: boolean | cdktn.IResolvable);
    resetEnableCloudLogging(): void;
    get enableCloudLoggingInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CesAppLoggingSettingsConversationLoggingSettings {
    /**
    * Whether to disable conversation logging for the sessions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#disable_conversation_logging CesApp#disable_conversation_logging}
    */
    readonly disableConversationLogging?: boolean | cdktn.IResolvable;
    /**
    * Controls the retention window for the conversation.
    * If not set, the conversation will be retained for 365 days.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#retention_window CesApp#retention_window}
    */
    readonly retentionWindow?: string;
}
export declare function cesAppLoggingSettingsConversationLoggingSettingsToTerraform(struct?: CesAppLoggingSettingsConversationLoggingSettingsOutputReference | CesAppLoggingSettingsConversationLoggingSettings): any;
export declare function cesAppLoggingSettingsConversationLoggingSettingsToHclTerraform(struct?: CesAppLoggingSettingsConversationLoggingSettingsOutputReference | CesAppLoggingSettingsConversationLoggingSettings): any;
export declare class CesAppLoggingSettingsConversationLoggingSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppLoggingSettingsConversationLoggingSettings | undefined;
    set internalValue(value: CesAppLoggingSettingsConversationLoggingSettings | undefined);
    private _disableConversationLogging?;
    get disableConversationLogging(): boolean | cdktn.IResolvable;
    set disableConversationLogging(value: boolean | cdktn.IResolvable);
    resetDisableConversationLogging(): void;
    get disableConversationLoggingInput(): boolean | cdktn.IResolvable | undefined;
    private _retentionWindow?;
    get retentionWindow(): string;
    set retentionWindow(value: string);
    resetRetentionWindow(): void;
    get retentionWindowInput(): string | undefined;
}
export interface CesAppLoggingSettingsMetricAnalysisSettings {
    /**
    * Whether to collect conversation data for llm analysis metrics. If true,
    * conversation data will not be collected for llm analysis metrics;
    * otherwise, conversation data will be collected.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#llm_metrics_opted_out CesApp#llm_metrics_opted_out}
    */
    readonly llmMetricsOptedOut?: boolean | cdktn.IResolvable;
}
export declare function cesAppLoggingSettingsMetricAnalysisSettingsToTerraform(struct?: CesAppLoggingSettingsMetricAnalysisSettingsOutputReference | CesAppLoggingSettingsMetricAnalysisSettings): any;
export declare function cesAppLoggingSettingsMetricAnalysisSettingsToHclTerraform(struct?: CesAppLoggingSettingsMetricAnalysisSettingsOutputReference | CesAppLoggingSettingsMetricAnalysisSettings): any;
export declare class CesAppLoggingSettingsMetricAnalysisSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppLoggingSettingsMetricAnalysisSettings | undefined;
    set internalValue(value: CesAppLoggingSettingsMetricAnalysisSettings | undefined);
    private _llmMetricsOptedOut?;
    get llmMetricsOptedOut(): boolean | cdktn.IResolvable;
    set llmMetricsOptedOut(value: boolean | cdktn.IResolvable);
    resetLlmMetricsOptedOut(): void;
    get llmMetricsOptedOutInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CesAppLoggingSettingsRedactionConfig {
    /**
    * [DLP](https://cloud.google.com/dlp/docs) deidentify template name to
    * instruct on how to de-identify content.
    * Format:
    * 'projects/{project}/locations/{location}/deidentifyTemplates/{deidentify_template}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#deidentify_template CesApp#deidentify_template}
    */
    readonly deidentifyTemplate?: string;
    /**
    * If true, redaction will be applied in various logging scenarios, including
    * conversation history, Cloud Logging and audio recording.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#enable_redaction CesApp#enable_redaction}
    */
    readonly enableRedaction?: boolean | cdktn.IResolvable;
    /**
    * [DLP](https://cloud.google.com/dlp/docs) inspect template name to configure
    * detection of sensitive data types.
    * Format:
    * 'projects/{project}/locations/{location}/inspectTemplates/{inspect_template}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#inspect_template CesApp#inspect_template}
    */
    readonly inspectTemplate?: string;
}
export declare function cesAppLoggingSettingsRedactionConfigToTerraform(struct?: CesAppLoggingSettingsRedactionConfigOutputReference | CesAppLoggingSettingsRedactionConfig): any;
export declare function cesAppLoggingSettingsRedactionConfigToHclTerraform(struct?: CesAppLoggingSettingsRedactionConfigOutputReference | CesAppLoggingSettingsRedactionConfig): any;
export declare class CesAppLoggingSettingsRedactionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppLoggingSettingsRedactionConfig | undefined;
    set internalValue(value: CesAppLoggingSettingsRedactionConfig | undefined);
    private _deidentifyTemplate?;
    get deidentifyTemplate(): string;
    set deidentifyTemplate(value: string);
    resetDeidentifyTemplate(): void;
    get deidentifyTemplateInput(): string | undefined;
    private _enableRedaction?;
    get enableRedaction(): boolean | cdktn.IResolvable;
    set enableRedaction(value: boolean | cdktn.IResolvable);
    resetEnableRedaction(): void;
    get enableRedactionInput(): boolean | cdktn.IResolvable | undefined;
    private _inspectTemplate?;
    get inspectTemplate(): string;
    set inspectTemplate(value: string);
    resetInspectTemplate(): void;
    get inspectTemplateInput(): string | undefined;
}
export interface CesAppLoggingSettings {
    /**
    * audio_recording_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#audio_recording_config CesApp#audio_recording_config}
    */
    readonly audioRecordingConfig?: CesAppLoggingSettingsAudioRecordingConfig;
    /**
    * bigquery_export_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#bigquery_export_settings CesApp#bigquery_export_settings}
    */
    readonly bigqueryExportSettings?: CesAppLoggingSettingsBigqueryExportSettings;
    /**
    * cloud_logging_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#cloud_logging_settings CesApp#cloud_logging_settings}
    */
    readonly cloudLoggingSettings?: CesAppLoggingSettingsCloudLoggingSettings;
    /**
    * conversation_logging_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#conversation_logging_settings CesApp#conversation_logging_settings}
    */
    readonly conversationLoggingSettings?: CesAppLoggingSettingsConversationLoggingSettings;
    /**
    * metric_analysis_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#metric_analysis_settings CesApp#metric_analysis_settings}
    */
    readonly metricAnalysisSettings?: CesAppLoggingSettingsMetricAnalysisSettings;
    /**
    * redaction_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#redaction_config CesApp#redaction_config}
    */
    readonly redactionConfig?: CesAppLoggingSettingsRedactionConfig;
}
export declare function cesAppLoggingSettingsToTerraform(struct?: CesAppLoggingSettingsOutputReference | CesAppLoggingSettings): any;
export declare function cesAppLoggingSettingsToHclTerraform(struct?: CesAppLoggingSettingsOutputReference | CesAppLoggingSettings): any;
export declare class CesAppLoggingSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppLoggingSettings | undefined;
    set internalValue(value: CesAppLoggingSettings | undefined);
    private _audioRecordingConfig;
    get audioRecordingConfig(): CesAppLoggingSettingsAudioRecordingConfigOutputReference;
    putAudioRecordingConfig(value: CesAppLoggingSettingsAudioRecordingConfig): void;
    resetAudioRecordingConfig(): void;
    get audioRecordingConfigInput(): CesAppLoggingSettingsAudioRecordingConfig | undefined;
    private _bigqueryExportSettings;
    get bigqueryExportSettings(): CesAppLoggingSettingsBigqueryExportSettingsOutputReference;
    putBigqueryExportSettings(value: CesAppLoggingSettingsBigqueryExportSettings): void;
    resetBigqueryExportSettings(): void;
    get bigqueryExportSettingsInput(): CesAppLoggingSettingsBigqueryExportSettings | undefined;
    private _cloudLoggingSettings;
    get cloudLoggingSettings(): CesAppLoggingSettingsCloudLoggingSettingsOutputReference;
    putCloudLoggingSettings(value: CesAppLoggingSettingsCloudLoggingSettings): void;
    resetCloudLoggingSettings(): void;
    get cloudLoggingSettingsInput(): CesAppLoggingSettingsCloudLoggingSettings | undefined;
    private _conversationLoggingSettings;
    get conversationLoggingSettings(): CesAppLoggingSettingsConversationLoggingSettingsOutputReference;
    putConversationLoggingSettings(value: CesAppLoggingSettingsConversationLoggingSettings): void;
    resetConversationLoggingSettings(): void;
    get conversationLoggingSettingsInput(): CesAppLoggingSettingsConversationLoggingSettings | undefined;
    private _metricAnalysisSettings;
    get metricAnalysisSettings(): CesAppLoggingSettingsMetricAnalysisSettingsOutputReference;
    putMetricAnalysisSettings(value: CesAppLoggingSettingsMetricAnalysisSettings): void;
    resetMetricAnalysisSettings(): void;
    get metricAnalysisSettingsInput(): CesAppLoggingSettingsMetricAnalysisSettings | undefined;
    private _redactionConfig;
    get redactionConfig(): CesAppLoggingSettingsRedactionConfigOutputReference;
    putRedactionConfig(value: CesAppLoggingSettingsRedactionConfig): void;
    resetRedactionConfig(): void;
    get redactionConfigInput(): CesAppLoggingSettingsRedactionConfig | undefined;
}
export interface CesAppModelSettings {
    /**
    * The LLM model that the agent should use.
    * If not set, the agent will inherit the model from its parent agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#model CesApp#model}
    */
    readonly model?: string;
    /**
    * If set, this temperature will be used for the LLM model. Temperature
    * controls the randomness of the model's responses. Lower temperatures
    * produce responses that are more predictable. Higher temperatures produce
    * responses that are more creative.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#temperature CesApp#temperature}
    */
    readonly temperature?: number;
    /**
    * The thinking level of the model. Possible values: ["DEFAULT", "LOW", "MEDIUM", "HIGH"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#thinking_level CesApp#thinking_level}
    */
    readonly thinkingLevel?: string;
}
export declare function cesAppModelSettingsToTerraform(struct?: CesAppModelSettingsOutputReference | CesAppModelSettings): any;
export declare function cesAppModelSettingsToHclTerraform(struct?: CesAppModelSettingsOutputReference | CesAppModelSettings): any;
export declare class CesAppModelSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppModelSettings | undefined;
    set internalValue(value: CesAppModelSettings | undefined);
    private _model?;
    get model(): string;
    set model(value: string);
    resetModel(): void;
    get modelInput(): string | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _thinkingLevel?;
    get thinkingLevel(): string;
    set thinkingLevel(value: string);
    resetThinkingLevel(): void;
    get thinkingLevelInput(): string | undefined;
}
export interface CesAppTimeZoneSettings {
    /**
    * The time zone of the app from the time zone database, e.g., America/Los_Angeles, Europe/Paris.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#time_zone CesApp#time_zone}
    */
    readonly timeZone?: string;
}
export declare function cesAppTimeZoneSettingsToTerraform(struct?: CesAppTimeZoneSettingsOutputReference | CesAppTimeZoneSettings): any;
export declare function cesAppTimeZoneSettingsToHclTerraform(struct?: CesAppTimeZoneSettingsOutputReference | CesAppTimeZoneSettings): any;
export declare class CesAppTimeZoneSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppTimeZoneSettings | undefined;
    set internalValue(value: CesAppTimeZoneSettings | undefined);
    private _timeZone?;
    get timeZone(): string;
    set timeZone(value: string);
    resetTimeZone(): void;
    get timeZoneInput(): string | undefined;
}
export interface CesAppTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#create CesApp#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#delete CesApp#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#update CesApp#update}
    */
    readonly update?: string;
}
export declare function cesAppTimeoutsToTerraform(struct?: CesAppTimeouts | cdktn.IResolvable): any;
export declare function cesAppTimeoutsToHclTerraform(struct?: CesAppTimeouts | cdktn.IResolvable): any;
export declare class CesAppTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CesAppTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface CesAppVariableDeclarationsSchema {
    /**
    * Optional. Defines the schema for additional properties allowed in an object.
    * The value must be a valid JSON string representing the Schema object.
    * (Note: OpenAPI also allows a boolean, this definition expects a Schema JSON).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#additional_properties CesApp#additional_properties}
    */
    readonly additionalProperties?: string;
    /**
    * Optional. The instance value should be valid against at least one of the schemas in this list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#any_of CesApp#any_of}
    */
    readonly anyOf?: string;
    /**
    * Optional. Default value of the data. Represents a dynamically typed value
    * which can be either null, a number, a string, a boolean, a struct,
    * or a list of values. The provided default value must be encoded as a JSON string.
    * Use 'jsonencode' in Terraform HCL to encode the default value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#default CesApp#default}
    */
    readonly default?: string;
    /**
    * A map of definitions for use by ref. Only allowed at the root of the schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#defs CesApp#defs}
    */
    readonly defs?: string;
    /**
    * The description of the data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#description CesApp#description}
    */
    readonly description?: string;
    /**
    * Possible values of the element of primitive type with enum format.
    * Examples:
    * 1. We can define direction as :
    * {type:STRING, format:enum, enum:["EAST", NORTH", "SOUTH", "WEST"]}
    * 2. We can define apartment number as :
    * {type:INTEGER, format:enum, enum:["101", "201", "301"]}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#enum CesApp#enum}
    */
    readonly enum?: string[];
    /**
    * Schema of the elements of Type.ARRAY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#items CesApp#items}
    */
    readonly items?: string;
    /**
    * Indicates if the value may be null.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#nullable CesApp#nullable}
    */
    readonly nullable?: boolean | cdktn.IResolvable;
    /**
    * Optional. Schemas of initial elements of Type.ARRAY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#prefix_items CesApp#prefix_items}
    */
    readonly prefixItems?: string;
    /**
    * Properties of Type.OBJECT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#properties CesApp#properties}
    */
    readonly properties?: string;
    /**
    * Allows indirect references between schema nodes. The value should be a
    * valid reference to a child of the root 'defs'.
    * For example, the following schema defines a reference to a schema node
    * named "Pet":
    * type: object
    * properties:
    *   pet:
    *     ref: #/defs/Pet
    * defs:
    *   Pet:
    *     type: object
    *     properties:
    *       name:
    *         type: string
    * The value of the "pet" property is a reference to the schema node
    * named "Pet".
    * See details in
    * https://json-schema.org/understanding-json-schema/structuring.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#ref CesApp#ref}
    */
    readonly ref?: string;
    /**
    * Required properties of Type.OBJECT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#required CesApp#required}
    */
    readonly required?: string[];
    /**
    * The title of the schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#title CesApp#title}
    */
    readonly title?: string;
    /**
    * The type of the data.
    * Possible values:
    * STRING
    * INTEGER
    * NUMBER
    * BOOLEAN
    * OBJECT
    * ARRAY
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#type CesApp#type}
    */
    readonly type: string;
    /**
    * Indicate the items in the array must be unique. Only applies to TYPE.ARRAY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#unique_items CesApp#unique_items}
    */
    readonly uniqueItems?: boolean | cdktn.IResolvable;
}
export declare function cesAppVariableDeclarationsSchemaToTerraform(struct?: CesAppVariableDeclarationsSchemaOutputReference | CesAppVariableDeclarationsSchema): any;
export declare function cesAppVariableDeclarationsSchemaToHclTerraform(struct?: CesAppVariableDeclarationsSchemaOutputReference | CesAppVariableDeclarationsSchema): any;
export declare class CesAppVariableDeclarationsSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppVariableDeclarationsSchema | undefined;
    set internalValue(value: CesAppVariableDeclarationsSchema | undefined);
    private _additionalProperties?;
    get additionalProperties(): string;
    set additionalProperties(value: string);
    resetAdditionalProperties(): void;
    get additionalPropertiesInput(): string | undefined;
    private _anyOf?;
    get anyOf(): string;
    set anyOf(value: string);
    resetAnyOf(): void;
    get anyOfInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _defs?;
    get defs(): string;
    set defs(value: string);
    resetDefs(): void;
    get defsInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enum?;
    get enum(): string[];
    set enum(value: string[]);
    resetEnum(): void;
    get enumInput(): string[] | undefined;
    private _items?;
    get items(): string;
    set items(value: string);
    resetItems(): void;
    get itemsInput(): string | undefined;
    private _nullable?;
    get nullable(): boolean | cdktn.IResolvable;
    set nullable(value: boolean | cdktn.IResolvable);
    resetNullable(): void;
    get nullableInput(): boolean | cdktn.IResolvable | undefined;
    private _prefixItems?;
    get prefixItems(): string;
    set prefixItems(value: string);
    resetPrefixItems(): void;
    get prefixItemsInput(): string | undefined;
    private _properties?;
    get properties(): string;
    set properties(value: string);
    resetProperties(): void;
    get propertiesInput(): string | undefined;
    private _ref?;
    get ref(): string;
    set ref(value: string);
    resetRef(): void;
    get refInput(): string | undefined;
    private _required?;
    get required(): string[];
    set required(value: string[]);
    resetRequired(): void;
    get requiredInput(): string[] | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _uniqueItems?;
    get uniqueItems(): boolean | cdktn.IResolvable;
    set uniqueItems(value: boolean | cdktn.IResolvable);
    resetUniqueItems(): void;
    get uniqueItemsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CesAppVariableDeclarations {
    /**
    * The description of the variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#description CesApp#description}
    */
    readonly description: string;
    /**
    * The name of the variable. The name must start with a letter or underscore
    * and contain only letters, numbers, or underscores.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#name CesApp#name}
    */
    readonly name: string;
    /**
    * schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#schema CesApp#schema}
    */
    readonly schema: CesAppVariableDeclarationsSchema;
}
export declare function cesAppVariableDeclarationsToTerraform(struct?: CesAppVariableDeclarations | cdktn.IResolvable): any;
export declare function cesAppVariableDeclarationsToHclTerraform(struct?: CesAppVariableDeclarations | cdktn.IResolvable): any;
export declare class CesAppVariableDeclarationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CesAppVariableDeclarations | cdktn.IResolvable | undefined;
    set internalValue(value: CesAppVariableDeclarations | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _schema;
    get schema(): CesAppVariableDeclarationsSchemaOutputReference;
    putSchema(value: CesAppVariableDeclarationsSchema): void;
    get schemaInput(): CesAppVariableDeclarationsSchema | undefined;
}
export declare class CesAppVariableDeclarationsList extends cdktn.ComplexList {
    internalValue?: CesAppVariableDeclarations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CesAppVariableDeclarationsOutputReference;
}
export interface CesAppVpcScSettings {
    /**
    * The allowed HTTP(s) origins that OpenAPI tools in the App are
    * able to directly call when VPC Service Controls are enabled. These strings
    * must match the origin exactly, including the port if specified. For
    * example, "https://example.com" or "https://example.com:443". This list does
    * not yet apply to Python tools that may make direct HTTP calls.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#allowed_origins CesApp#allowed_origins}
    */
    readonly allowedOrigins?: string[];
}
export declare function cesAppVpcScSettingsToTerraform(struct?: CesAppVpcScSettingsOutputReference | CesAppVpcScSettings): any;
export declare function cesAppVpcScSettingsToHclTerraform(struct?: CesAppVpcScSettingsOutputReference | CesAppVpcScSettings): any;
export declare class CesAppVpcScSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesAppVpcScSettings | undefined;
    set internalValue(value: CesAppVpcScSettings | undefined);
    private _allowedOrigins?;
    get allowedOrigins(): string[];
    set allowedOrigins(value: string[]);
    resetAllowedOrigins(): void;
    get allowedOriginsInput(): string[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app google_ces_app}
*/
export declare class CesApp extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_ces_app";
    /**
    * Generates CDKTN code for importing a CesApp resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CesApp to import
    * @param importFromId The id of the existing CesApp that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CesApp to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_app google_ces_app} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CesAppConfig
    */
    constructor(scope: Construct, id: string, config: CesAppConfig);
    private _appId?;
    get appId(): string;
    set appId(value: string);
    get appIdInput(): string | undefined;
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    get deploymentCount(): number;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get etag(): string;
    private _globalInstruction?;
    get globalInstruction(): string;
    set globalInstruction(value: string);
    resetGlobalInstruction(): void;
    get globalInstructionInput(): string | undefined;
    private _guardrails?;
    get guardrails(): string[];
    set guardrails(value: string[]);
    resetGuardrails(): void;
    get guardrailsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _locked?;
    get locked(): boolean | cdktn.IResolvable;
    set locked(value: boolean | cdktn.IResolvable);
    resetLocked(): void;
    get lockedInput(): boolean | cdktn.IResolvable | undefined;
    private _metadata?;
    get metadata(): {
        [key: string]: string;
    };
    set metadata(value: {
        [key: string]: string;
    });
    resetMetadata(): void;
    get metadataInput(): {
        [key: string]: string;
    } | undefined;
    get name(): string;
    private _pinned?;
    get pinned(): boolean | cdktn.IResolvable;
    set pinned(value: boolean | cdktn.IResolvable);
    resetPinned(): void;
    get pinnedInput(): boolean | cdktn.IResolvable | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _rootAgent?;
    get rootAgent(): string;
    set rootAgent(value: string);
    resetRootAgent(): void;
    get rootAgentInput(): string | undefined;
    private _toolExecutionMode?;
    get toolExecutionMode(): string;
    set toolExecutionMode(value: string);
    resetToolExecutionMode(): void;
    get toolExecutionModeInput(): string | undefined;
    get updateTime(): string;
    private _audioProcessingConfig;
    get audioProcessingConfig(): CesAppAudioProcessingConfigOutputReference;
    putAudioProcessingConfig(value: CesAppAudioProcessingConfig): void;
    resetAudioProcessingConfig(): void;
    get audioProcessingConfigInput(): CesAppAudioProcessingConfig | undefined;
    private _clientCertificateSettings;
    get clientCertificateSettings(): CesAppClientCertificateSettingsOutputReference;
    putClientCertificateSettings(value: CesAppClientCertificateSettings): void;
    resetClientCertificateSettings(): void;
    get clientCertificateSettingsInput(): CesAppClientCertificateSettings | undefined;
    private _dataStoreSettings;
    get dataStoreSettings(): CesAppDataStoreSettingsOutputReference;
    putDataStoreSettings(value: CesAppDataStoreSettings): void;
    resetDataStoreSettings(): void;
    get dataStoreSettingsInput(): CesAppDataStoreSettings | undefined;
    private _defaultChannelProfile;
    get defaultChannelProfile(): CesAppDefaultChannelProfileOutputReference;
    putDefaultChannelProfile(value: CesAppDefaultChannelProfile): void;
    resetDefaultChannelProfile(): void;
    get defaultChannelProfileInput(): CesAppDefaultChannelProfile | undefined;
    private _errorHandlingSettings;
    get errorHandlingSettings(): CesAppErrorHandlingSettingsOutputReference;
    putErrorHandlingSettings(value: CesAppErrorHandlingSettings): void;
    resetErrorHandlingSettings(): void;
    get errorHandlingSettingsInput(): CesAppErrorHandlingSettings | undefined;
    private _evaluationMetricsThresholds;
    get evaluationMetricsThresholds(): CesAppEvaluationMetricsThresholdsOutputReference;
    putEvaluationMetricsThresholds(value: CesAppEvaluationMetricsThresholds): void;
    resetEvaluationMetricsThresholds(): void;
    get evaluationMetricsThresholdsInput(): CesAppEvaluationMetricsThresholds | undefined;
    private _languageSettings;
    get languageSettings(): CesAppLanguageSettingsOutputReference;
    putLanguageSettings(value: CesAppLanguageSettings): void;
    resetLanguageSettings(): void;
    get languageSettingsInput(): CesAppLanguageSettings | undefined;
    private _loggingSettings;
    get loggingSettings(): CesAppLoggingSettingsOutputReference;
    putLoggingSettings(value: CesAppLoggingSettings): void;
    resetLoggingSettings(): void;
    get loggingSettingsInput(): CesAppLoggingSettings | undefined;
    private _modelSettings;
    get modelSettings(): CesAppModelSettingsOutputReference;
    putModelSettings(value: CesAppModelSettings): void;
    resetModelSettings(): void;
    get modelSettingsInput(): CesAppModelSettings | undefined;
    private _timeZoneSettings;
    get timeZoneSettings(): CesAppTimeZoneSettingsOutputReference;
    putTimeZoneSettings(value: CesAppTimeZoneSettings): void;
    resetTimeZoneSettings(): void;
    get timeZoneSettingsInput(): CesAppTimeZoneSettings | undefined;
    private _timeouts;
    get timeouts(): CesAppTimeoutsOutputReference;
    putTimeouts(value: CesAppTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CesAppTimeouts | undefined;
    private _variableDeclarations;
    get variableDeclarations(): CesAppVariableDeclarationsList;
    putVariableDeclarations(value: CesAppVariableDeclarations[] | cdktn.IResolvable): void;
    resetVariableDeclarations(): void;
    get variableDeclarationsInput(): cdktn.IResolvable | CesAppVariableDeclarations[] | undefined;
    private _vpcScSettings;
    get vpcScSettings(): CesAppVpcScSettingsOutputReference;
    putVpcScSettings(value: CesAppVpcScSettings): void;
    resetVpcScSettings(): void;
    get vpcScSettingsInput(): CesAppVpcScSettings | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
