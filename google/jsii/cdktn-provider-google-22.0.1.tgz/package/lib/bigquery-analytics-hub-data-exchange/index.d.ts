/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BigqueryAnalyticsHubDataExchangeConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the data exchange. Must contain only Unicode letters, numbers (0-9), underscores (_). Should not use characters that require URL-escaping, or characters outside of ASCII, spaces.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_analytics_hub_data_exchange#data_exchange_id BigqueryAnalyticsHubDataExchange#data_exchange_id}
    */
    readonly dataExchangeId: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_analytics_hub_data_exchange#deletion_policy BigqueryAnalyticsHubDataExchange#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Description of the data exchange.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_analytics_hub_data_exchange#description BigqueryAnalyticsHubDataExchange#description}
    */
    readonly description?: string;
    /**
    * Type of discovery on the discovery page for all the listings under this exchange. Cannot be set for a Data Clean Room. Updating this field also updates (overwrites) the discoveryType field for all the listings under this exchange. Possible values: ["DISCOVERY_TYPE_PRIVATE", "DISCOVERY_TYPE_PUBLIC"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_analytics_hub_data_exchange#discovery_type BigqueryAnalyticsHubDataExchange#discovery_type}
    */
    readonly discoveryType?: string;
    /**
    * Human-readable display name of the data exchange. The display name must contain only Unicode letters, numbers (0-9), underscores (_), dashes (-), spaces ( ), and must not start or end with spaces.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_analytics_hub_data_exchange#display_name BigqueryAnalyticsHubDataExchange#display_name}
    */
    readonly displayName: string;
    /**
    * Documentation describing the data exchange.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_analytics_hub_data_exchange#documentation BigqueryAnalyticsHubDataExchange#documentation}
    */
    readonly documentation?: string;
    /**
    * Base64 encoded image representing the data exchange.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_analytics_hub_data_exchange#icon BigqueryAnalyticsHubDataExchange#icon}
    */
    readonly icon?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_analytics_hub_data_exchange#id BigqueryAnalyticsHubDataExchange#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the location this data exchange.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_analytics_hub_data_exchange#location BigqueryAnalyticsHubDataExchange#location}
    */
    readonly location: string;
    /**
    * If true, subscriber email logging is enabled and all queries on the linked dataset will log the email address of the querying user. Once enabled, this setting cannot be turned off.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_analytics_hub_data_exchange#log_linked_dataset_query_user_email BigqueryAnalyticsHubDataExchange#log_linked_dataset_query_user_email}
    */
    readonly logLinkedDatasetQueryUserEmail?: boolean | cdktn.IResolvable;
    /**
    * Email or URL of the primary point of contact of the data exchange.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_analytics_hub_data_exchange#primary_contact BigqueryAnalyticsHubDataExchange#primary_contact}
    */
    readonly primaryContact?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_analytics_hub_data_exchange#project BigqueryAnalyticsHubDataExchange#project}
    */
    readonly project?: string;
    /**
    * sharing_environment_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_analytics_hub_data_exchange#sharing_environment_config BigqueryAnalyticsHubDataExchange#sharing_environment_config}
    */
    readonly sharingEnvironmentConfig?: BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_analytics_hub_data_exchange#timeouts BigqueryAnalyticsHubDataExchange#timeouts}
    */
    readonly timeouts?: BigqueryAnalyticsHubDataExchangeTimeouts;
}
export interface BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDcrExchangeConfig {
}
export declare function bigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDcrExchangeConfigToTerraform(struct?: BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDcrExchangeConfigOutputReference | BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDcrExchangeConfig): any;
export declare function bigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDcrExchangeConfigToHclTerraform(struct?: BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDcrExchangeConfigOutputReference | BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDcrExchangeConfig): any;
export declare class BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDcrExchangeConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDcrExchangeConfig | undefined;
    set internalValue(value: BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDcrExchangeConfig | undefined);
}
export interface BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDefaultExchangeConfig {
}
export declare function bigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDefaultExchangeConfigToTerraform(struct?: BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDefaultExchangeConfigOutputReference | BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDefaultExchangeConfig): any;
export declare function bigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDefaultExchangeConfigToHclTerraform(struct?: BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDefaultExchangeConfigOutputReference | BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDefaultExchangeConfig): any;
export declare class BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDefaultExchangeConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDefaultExchangeConfig | undefined;
    set internalValue(value: BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDefaultExchangeConfig | undefined);
}
export interface BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfig {
    /**
    * dcr_exchange_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_analytics_hub_data_exchange#dcr_exchange_config BigqueryAnalyticsHubDataExchange#dcr_exchange_config}
    */
    readonly dcrExchangeConfig?: BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDcrExchangeConfig;
    /**
    * default_exchange_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_analytics_hub_data_exchange#default_exchange_config BigqueryAnalyticsHubDataExchange#default_exchange_config}
    */
    readonly defaultExchangeConfig?: BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDefaultExchangeConfig;
}
export declare function bigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigToTerraform(struct?: BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigOutputReference | BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfig): any;
export declare function bigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigToHclTerraform(struct?: BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigOutputReference | BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfig): any;
export declare class BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfig | undefined;
    set internalValue(value: BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfig | undefined);
    private _dcrExchangeConfig;
    get dcrExchangeConfig(): BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDcrExchangeConfigOutputReference;
    putDcrExchangeConfig(value: BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDcrExchangeConfig): void;
    resetDcrExchangeConfig(): void;
    get dcrExchangeConfigInput(): BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDcrExchangeConfig | undefined;
    private _defaultExchangeConfig;
    get defaultExchangeConfig(): BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDefaultExchangeConfigOutputReference;
    putDefaultExchangeConfig(value: BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDefaultExchangeConfig): void;
    resetDefaultExchangeConfig(): void;
    get defaultExchangeConfigInput(): BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigDefaultExchangeConfig | undefined;
}
export interface BigqueryAnalyticsHubDataExchangeTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_analytics_hub_data_exchange#create BigqueryAnalyticsHubDataExchange#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_analytics_hub_data_exchange#delete BigqueryAnalyticsHubDataExchange#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_analytics_hub_data_exchange#update BigqueryAnalyticsHubDataExchange#update}
    */
    readonly update?: string;
}
export declare function bigqueryAnalyticsHubDataExchangeTimeoutsToTerraform(struct?: BigqueryAnalyticsHubDataExchangeTimeouts | cdktn.IResolvable): any;
export declare function bigqueryAnalyticsHubDataExchangeTimeoutsToHclTerraform(struct?: BigqueryAnalyticsHubDataExchangeTimeouts | cdktn.IResolvable): any;
export declare class BigqueryAnalyticsHubDataExchangeTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryAnalyticsHubDataExchangeTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BigqueryAnalyticsHubDataExchangeTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_analytics_hub_data_exchange google_bigquery_analytics_hub_data_exchange}
*/
export declare class BigqueryAnalyticsHubDataExchange extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_bigquery_analytics_hub_data_exchange";
    /**
    * Generates CDKTN code for importing a BigqueryAnalyticsHubDataExchange resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BigqueryAnalyticsHubDataExchange to import
    * @param importFromId The id of the existing BigqueryAnalyticsHubDataExchange that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_analytics_hub_data_exchange#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BigqueryAnalyticsHubDataExchange to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_analytics_hub_data_exchange google_bigquery_analytics_hub_data_exchange} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BigqueryAnalyticsHubDataExchangeConfig
    */
    constructor(scope: Construct, id: string, config: BigqueryAnalyticsHubDataExchangeConfig);
    private _dataExchangeId?;
    get dataExchangeId(): string;
    set dataExchangeId(value: string);
    get dataExchangeIdInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _discoveryType?;
    get discoveryType(): string;
    set discoveryType(value: string);
    resetDiscoveryType(): void;
    get discoveryTypeInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _documentation?;
    get documentation(): string;
    set documentation(value: string);
    resetDocumentation(): void;
    get documentationInput(): string | undefined;
    private _icon?;
    get icon(): string;
    set icon(value: string);
    resetIcon(): void;
    get iconInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get listingCount(): number;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _logLinkedDatasetQueryUserEmail?;
    get logLinkedDatasetQueryUserEmail(): boolean | cdktn.IResolvable;
    set logLinkedDatasetQueryUserEmail(value: boolean | cdktn.IResolvable);
    resetLogLinkedDatasetQueryUserEmail(): void;
    get logLinkedDatasetQueryUserEmailInput(): boolean | cdktn.IResolvable | undefined;
    get name(): string;
    private _primaryContact?;
    get primaryContact(): string;
    set primaryContact(value: string);
    resetPrimaryContact(): void;
    get primaryContactInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _sharingEnvironmentConfig;
    get sharingEnvironmentConfig(): BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfigOutputReference;
    putSharingEnvironmentConfig(value: BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfig): void;
    resetSharingEnvironmentConfig(): void;
    get sharingEnvironmentConfigInput(): BigqueryAnalyticsHubDataExchangeSharingEnvironmentConfig | undefined;
    private _timeouts;
    get timeouts(): BigqueryAnalyticsHubDataExchangeTimeoutsOutputReference;
    putTimeouts(value: BigqueryAnalyticsHubDataExchangeTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BigqueryAnalyticsHubDataExchangeTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
