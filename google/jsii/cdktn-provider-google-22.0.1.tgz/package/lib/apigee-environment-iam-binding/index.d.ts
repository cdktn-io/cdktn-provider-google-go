/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigeeEnvironmentIamBindingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_environment_iam_binding#env_id ApigeeEnvironmentIamBinding#env_id}
    */
    readonly envId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_environment_iam_binding#id ApigeeEnvironmentIamBinding#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_environment_iam_binding#members ApigeeEnvironmentIamBinding#members}
    */
    readonly members: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_environment_iam_binding#org_id ApigeeEnvironmentIamBinding#org_id}
    */
    readonly orgId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_environment_iam_binding#role ApigeeEnvironmentIamBinding#role}
    */
    readonly role: string;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_environment_iam_binding#condition ApigeeEnvironmentIamBinding#condition}
    */
    readonly condition?: ApigeeEnvironmentIamBindingCondition;
}
export interface ApigeeEnvironmentIamBindingCondition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_environment_iam_binding#description ApigeeEnvironmentIamBinding#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_environment_iam_binding#expression ApigeeEnvironmentIamBinding#expression}
    */
    readonly expression: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_environment_iam_binding#title ApigeeEnvironmentIamBinding#title}
    */
    readonly title: string;
}
export declare function apigeeEnvironmentIamBindingConditionToTerraform(struct?: ApigeeEnvironmentIamBindingConditionOutputReference | ApigeeEnvironmentIamBindingCondition): any;
export declare function apigeeEnvironmentIamBindingConditionToHclTerraform(struct?: ApigeeEnvironmentIamBindingConditionOutputReference | ApigeeEnvironmentIamBindingCondition): any;
export declare class ApigeeEnvironmentIamBindingConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeEnvironmentIamBindingCondition | undefined;
    set internalValue(value: ApigeeEnvironmentIamBindingCondition | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_environment_iam_binding google_apigee_environment_iam_binding}
*/
export declare class ApigeeEnvironmentIamBinding extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apigee_environment_iam_binding";
    /**
    * Generates CDKTN code for importing a ApigeeEnvironmentIamBinding resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigeeEnvironmentIamBinding to import
    * @param importFromId The id of the existing ApigeeEnvironmentIamBinding that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_environment_iam_binding#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigeeEnvironmentIamBinding to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_environment_iam_binding google_apigee_environment_iam_binding} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigeeEnvironmentIamBindingConfig
    */
    constructor(scope: Construct, id: string, config: ApigeeEnvironmentIamBindingConfig);
    private _envId?;
    get envId(): string;
    set envId(value: string);
    get envIdInput(): string | undefined;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _members?;
    get members(): string[];
    set members(value: string[]);
    get membersInput(): string[] | undefined;
    private _orgId?;
    get orgId(): string;
    set orgId(value: string);
    get orgIdInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _condition;
    get condition(): ApigeeEnvironmentIamBindingConditionOutputReference;
    putCondition(value: ApigeeEnvironmentIamBindingCondition): void;
    resetCondition(): void;
    get conditionInput(): ApigeeEnvironmentIamBindingCondition | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
