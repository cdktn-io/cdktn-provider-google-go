/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ClouddeployAutomationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Optional. User annotations. These attributes can only be set and used by the user, and not by Cloud Deploy. Annotations must meet the following constraints: * Annotations are key/value pairs. * Valid annotation keys have two segments: an optional prefix and name, separated by a slash ('/'). * The name segment is required and must be 63 characters or less, beginning and ending with an alphanumeric character ('[a-z0-9A-Z]') with dashes ('-'), underscores ('_'), dots ('.'), and alphanumerics between. * The prefix is optional. If specified, the prefix must be a DNS subdomain: a series of DNS labels separated by dots('.'), not longer than 253 characters in total, followed by a slash ('/'). See https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/#syntax-and-character-set for more details.
    *
    * **Note**: This field is non-authoritative, and will only manage the annotations present in your configuration.
    * Please refer to the field 'effective_annotations' for all of the annotations present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#annotations ClouddeployAutomation#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#deletion_policy ClouddeployAutomation#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The delivery_pipeline for the resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#delivery_pipeline ClouddeployAutomation#delivery_pipeline}
    */
    readonly deliveryPipeline: string;
    /**
    * Optional. Description of the 'Automation'. Max length is 255 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#description ClouddeployAutomation#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#id ClouddeployAutomation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Optional. Labels are attributes that can be set and used by both the user and by Cloud Deploy. Labels must meet the following constraints: * Keys and values can contain only lowercase letters, numeric characters, underscores, and dashes. * All characters must use UTF-8 encoding, and international characters are allowed. * Keys must start with a lowercase letter or international character. * Each resource is limited to a maximum of 64 labels. Both keys and values are additionally constrained to be <= 63 characters.
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#labels ClouddeployAutomation#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The location for the resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#location ClouddeployAutomation#location}
    */
    readonly location: string;
    /**
    * Name of the 'Automation'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#name ClouddeployAutomation#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#project ClouddeployAutomation#project}
    */
    readonly project?: string;
    /**
    * Required. Email address of the user-managed IAM service account that creates Cloud Deploy release and rollout resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#service_account ClouddeployAutomation#service_account}
    */
    readonly serviceAccount: string;
    /**
    * Optional. When Suspended, automation is deactivated from execution.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#suspended ClouddeployAutomation#suspended}
    */
    readonly suspended?: boolean | cdktn.IResolvable;
    /**
    * rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#rules ClouddeployAutomation#rules}
    */
    readonly rules: ClouddeployAutomationRules[] | cdktn.IResolvable;
    /**
    * selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#selector ClouddeployAutomation#selector}
    */
    readonly selector: ClouddeployAutomationSelector;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#timeouts ClouddeployAutomation#timeouts}
    */
    readonly timeouts?: ClouddeployAutomationTimeouts;
}
export interface ClouddeployAutomationRulesAdvanceRolloutRule {
    /**
    * Required. ID of the rule. This id must be unique in the 'Automation' resource to which this rule belongs. The format is 'a-z{0,62}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#id ClouddeployAutomation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Optional. Proceeds only after phase name matched any one in the list. This value must consist of lower-case letters, numbers, and hyphens, start with a letter and end with a letter or a number, and have a max length of 63 characters. In other words, it must match the following regex: '^[a-z]([a-z0-9-]{0,61}[a-z0-9])?$'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#source_phases ClouddeployAutomation#source_phases}
    */
    readonly sourcePhases?: string[];
    /**
    * Optional. How long to wait after a rollout is finished.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#wait ClouddeployAutomation#wait}
    */
    readonly wait?: string;
}
export declare function clouddeployAutomationRulesAdvanceRolloutRuleToTerraform(struct?: ClouddeployAutomationRulesAdvanceRolloutRuleOutputReference | ClouddeployAutomationRulesAdvanceRolloutRule): any;
export declare function clouddeployAutomationRulesAdvanceRolloutRuleToHclTerraform(struct?: ClouddeployAutomationRulesAdvanceRolloutRuleOutputReference | ClouddeployAutomationRulesAdvanceRolloutRule): any;
export declare class ClouddeployAutomationRulesAdvanceRolloutRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddeployAutomationRulesAdvanceRolloutRule | undefined;
    set internalValue(value: ClouddeployAutomationRulesAdvanceRolloutRule | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _sourcePhases?;
    get sourcePhases(): string[];
    set sourcePhases(value: string[]);
    resetSourcePhases(): void;
    get sourcePhasesInput(): string[] | undefined;
    private _wait?;
    get wait(): string;
    set wait(value: string);
    resetWait(): void;
    get waitInput(): string | undefined;
}
export interface ClouddeployAutomationRulesPromoteReleaseRule {
    /**
    * Optional. The starting phase of the rollout created by this operation. Default to the first phase.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#destination_phase ClouddeployAutomation#destination_phase}
    */
    readonly destinationPhase?: string;
    /**
    * Optional. The ID of the stage in the pipeline to which this 'Release' is deploying. If unspecified, default it to the next stage in the promotion flow. The value of this field could be one of the following: * The last segment of a target name. It only needs the ID to determine if the target is one of the stages in the promotion sequence defined in the pipeline. * "@next", the next target in the promotion sequence.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#destination_target_id ClouddeployAutomation#destination_target_id}
    */
    readonly destinationTargetId?: string;
    /**
    * Required. ID of the rule. This id must be unique in the 'Automation' resource to which this rule belongs. The format is 'a-z{0,62}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#id ClouddeployAutomation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Optional. How long the release need to be paused until being promoted to the next target.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#wait ClouddeployAutomation#wait}
    */
    readonly wait?: string;
}
export declare function clouddeployAutomationRulesPromoteReleaseRuleToTerraform(struct?: ClouddeployAutomationRulesPromoteReleaseRuleOutputReference | ClouddeployAutomationRulesPromoteReleaseRule): any;
export declare function clouddeployAutomationRulesPromoteReleaseRuleToHclTerraform(struct?: ClouddeployAutomationRulesPromoteReleaseRuleOutputReference | ClouddeployAutomationRulesPromoteReleaseRule): any;
export declare class ClouddeployAutomationRulesPromoteReleaseRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddeployAutomationRulesPromoteReleaseRule | undefined;
    set internalValue(value: ClouddeployAutomationRulesPromoteReleaseRule | undefined);
    private _destinationPhase?;
    get destinationPhase(): string;
    set destinationPhase(value: string);
    resetDestinationPhase(): void;
    get destinationPhaseInput(): string | undefined;
    private _destinationTargetId?;
    get destinationTargetId(): string;
    set destinationTargetId(value: string);
    resetDestinationTargetId(): void;
    get destinationTargetIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _wait?;
    get wait(): string;
    set wait(value: string);
    resetWait(): void;
    get waitInput(): string | undefined;
}
export interface ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesRetry {
    /**
    * Required. Total number of retries. Retry is skipped if set to 0; The minimum value is 1, and the maximum value is 10.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#attempts ClouddeployAutomation#attempts}
    */
    readonly attempts: string;
    /**
    * Optional. The pattern of how wait time will be increased. Default is linear. Backoff mode will be ignored if wait is 0. Possible values: ["BACKOFF_MODE_UNSPECIFIED", "BACKOFF_MODE_LINEAR", "BACKOFF_MODE_EXPONENTIAL"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#backoff_mode ClouddeployAutomation#backoff_mode}
    */
    readonly backoffMode?: string;
    /**
    * Optional. How long to wait for the first retry. Default is 0, and the maximum value is 14d. A duration in seconds with up to nine fractional digits, ending with 's'. Example: '3.5s'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#wait ClouddeployAutomation#wait}
    */
    readonly wait?: string;
}
export declare function clouddeployAutomationRulesRepairRolloutRuleRepairPhasesRetryToTerraform(struct?: ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesRetryOutputReference | ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesRetry): any;
export declare function clouddeployAutomationRulesRepairRolloutRuleRepairPhasesRetryToHclTerraform(struct?: ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesRetryOutputReference | ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesRetry): any;
export declare class ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesRetryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesRetry | undefined;
    set internalValue(value: ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesRetry | undefined);
    private _attempts?;
    get attempts(): string;
    set attempts(value: string);
    get attemptsInput(): string | undefined;
    private _backoffMode?;
    get backoffMode(): string;
    set backoffMode(value: string);
    resetBackoffMode(): void;
    get backoffModeInput(): string | undefined;
    private _wait?;
    get wait(): string;
    set wait(value: string);
    resetWait(): void;
    get waitInput(): string | undefined;
}
export interface ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesRollback {
    /**
    * Optional. The starting phase ID for the Rollout. If unspecified, the Rollout will start in the stable phase.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#destination_phase ClouddeployAutomation#destination_phase}
    */
    readonly destinationPhase?: string;
    /**
    * Optional. If pending rollout exists on the target, the rollback operation will be aborted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#disable_rollback_if_rollout_pending ClouddeployAutomation#disable_rollback_if_rollout_pending}
    */
    readonly disableRollbackIfRolloutPending?: boolean | cdktn.IResolvable;
}
export declare function clouddeployAutomationRulesRepairRolloutRuleRepairPhasesRollbackToTerraform(struct?: ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesRollbackOutputReference | ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesRollback): any;
export declare function clouddeployAutomationRulesRepairRolloutRuleRepairPhasesRollbackToHclTerraform(struct?: ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesRollbackOutputReference | ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesRollback): any;
export declare class ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesRollbackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesRollback | undefined;
    set internalValue(value: ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesRollback | undefined);
    private _destinationPhase?;
    get destinationPhase(): string;
    set destinationPhase(value: string);
    resetDestinationPhase(): void;
    get destinationPhaseInput(): string | undefined;
    private _disableRollbackIfRolloutPending?;
    get disableRollbackIfRolloutPending(): boolean | cdktn.IResolvable;
    set disableRollbackIfRolloutPending(value: boolean | cdktn.IResolvable);
    resetDisableRollbackIfRolloutPending(): void;
    get disableRollbackIfRolloutPendingInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ClouddeployAutomationRulesRepairRolloutRuleRepairPhases {
    /**
    * retry block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#retry ClouddeployAutomation#retry}
    */
    readonly retry?: ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesRetry;
    /**
    * rollback block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#rollback ClouddeployAutomation#rollback}
    */
    readonly rollback?: ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesRollback;
}
export declare function clouddeployAutomationRulesRepairRolloutRuleRepairPhasesToTerraform(struct?: ClouddeployAutomationRulesRepairRolloutRuleRepairPhases | cdktn.IResolvable): any;
export declare function clouddeployAutomationRulesRepairRolloutRuleRepairPhasesToHclTerraform(struct?: ClouddeployAutomationRulesRepairRolloutRuleRepairPhases | cdktn.IResolvable): any;
export declare class ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ClouddeployAutomationRulesRepairRolloutRuleRepairPhases | cdktn.IResolvable | undefined;
    set internalValue(value: ClouddeployAutomationRulesRepairRolloutRuleRepairPhases | cdktn.IResolvable | undefined);
    private _retry;
    get retry(): ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesRetryOutputReference;
    putRetry(value: ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesRetry): void;
    resetRetry(): void;
    get retryInput(): ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesRetry | undefined;
    private _rollback;
    get rollback(): ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesRollbackOutputReference;
    putRollback(value: ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesRollback): void;
    resetRollback(): void;
    get rollbackInput(): ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesRollback | undefined;
}
export declare class ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesList extends cdktn.ComplexList {
    internalValue?: ClouddeployAutomationRulesRepairRolloutRuleRepairPhases[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesOutputReference;
}
export interface ClouddeployAutomationRulesRepairRolloutRule {
    /**
    * Required. ID of the rule. This id must be unique in the 'Automation' resource to which this rule belongs. The format is 'a-z{0,62}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#id ClouddeployAutomation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Optional. Jobs to repair. Proceeds only after job name matched any one in the list, or for all jobs if unspecified or empty. The phase that includes the job must match the phase ID specified in sourcePhase. This value must consist of lower-case letters, numbers, and hyphens, start with a letter and end with a letter or a number, and have a max length of 63 characters. In other words, it must match the following regex: ^[a-z]([a-z0-9-]{0,61}[a-z0-9])?$.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#jobs ClouddeployAutomation#jobs}
    */
    readonly jobs?: string[];
    /**
    * Optional. Phases within which jobs are subject to automatic repair actions on failure. Proceeds only after phase name matched any one in the list, or for all phases if unspecified. This value must consist of lower-case letters, numbers, and hyphens, start with a letter and end with a letter or a number, and have a max length of 63 characters. In other words, it must match the following regex: ^[a-z]([a-z0-9-]{0,61}[a-z0-9])?$.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#phases ClouddeployAutomation#phases}
    */
    readonly phases?: string[];
    /**
    * repair_phases block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#repair_phases ClouddeployAutomation#repair_phases}
    */
    readonly repairPhases?: ClouddeployAutomationRulesRepairRolloutRuleRepairPhases[] | cdktn.IResolvable;
}
export declare function clouddeployAutomationRulesRepairRolloutRuleToTerraform(struct?: ClouddeployAutomationRulesRepairRolloutRuleOutputReference | ClouddeployAutomationRulesRepairRolloutRule): any;
export declare function clouddeployAutomationRulesRepairRolloutRuleToHclTerraform(struct?: ClouddeployAutomationRulesRepairRolloutRuleOutputReference | ClouddeployAutomationRulesRepairRolloutRule): any;
export declare class ClouddeployAutomationRulesRepairRolloutRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddeployAutomationRulesRepairRolloutRule | undefined;
    set internalValue(value: ClouddeployAutomationRulesRepairRolloutRule | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _jobs?;
    get jobs(): string[];
    set jobs(value: string[]);
    resetJobs(): void;
    get jobsInput(): string[] | undefined;
    private _phases?;
    get phases(): string[];
    set phases(value: string[]);
    resetPhases(): void;
    get phasesInput(): string[] | undefined;
    private _repairPhases;
    get repairPhases(): ClouddeployAutomationRulesRepairRolloutRuleRepairPhasesList;
    putRepairPhases(value: ClouddeployAutomationRulesRepairRolloutRuleRepairPhases[] | cdktn.IResolvable): void;
    resetRepairPhases(): void;
    get repairPhasesInput(): cdktn.IResolvable | ClouddeployAutomationRulesRepairRolloutRuleRepairPhases[] | undefined;
}
export interface ClouddeployAutomationRulesTimedPromoteReleaseRule {
    /**
    * Optional. The starting phase of the rollout created by this rule. Default to the first phase.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#destination_phase ClouddeployAutomation#destination_phase}
    */
    readonly destinationPhase?: string;
    /**
    * Optional. The ID of the stage in the pipeline to which this Release is deploying. If unspecified, default it to the next stage in the promotion flow. The value of this field could be one of the following:
    *   - The last segment of a target name
    *   - "@next", the next target in the promotion sequence"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#destination_target_id ClouddeployAutomation#destination_target_id}
    */
    readonly destinationTargetId?: string;
    /**
    * Required. ID of the rule. This id must be unique in the 'Automation' resource to which this rule belongs. The format is 'a-z{0,62}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#id ClouddeployAutomation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Required. Schedule in crontab format. e.g. '0 9 * * 1' for every Monday at 9am.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#schedule ClouddeployAutomation#schedule}
    */
    readonly schedule: string;
    /**
    * Required. The time zone in IANA format IANA Time Zone Database (e.g. America/New_York).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#time_zone ClouddeployAutomation#time_zone}
    */
    readonly timeZone: string;
}
export declare function clouddeployAutomationRulesTimedPromoteReleaseRuleToTerraform(struct?: ClouddeployAutomationRulesTimedPromoteReleaseRuleOutputReference | ClouddeployAutomationRulesTimedPromoteReleaseRule): any;
export declare function clouddeployAutomationRulesTimedPromoteReleaseRuleToHclTerraform(struct?: ClouddeployAutomationRulesTimedPromoteReleaseRuleOutputReference | ClouddeployAutomationRulesTimedPromoteReleaseRule): any;
export declare class ClouddeployAutomationRulesTimedPromoteReleaseRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddeployAutomationRulesTimedPromoteReleaseRule | undefined;
    set internalValue(value: ClouddeployAutomationRulesTimedPromoteReleaseRule | undefined);
    private _destinationPhase?;
    get destinationPhase(): string;
    set destinationPhase(value: string);
    resetDestinationPhase(): void;
    get destinationPhaseInput(): string | undefined;
    private _destinationTargetId?;
    get destinationTargetId(): string;
    set destinationTargetId(value: string);
    resetDestinationTargetId(): void;
    get destinationTargetIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _schedule?;
    get schedule(): string;
    set schedule(value: string);
    get scheduleInput(): string | undefined;
    private _timeZone?;
    get timeZone(): string;
    set timeZone(value: string);
    get timeZoneInput(): string | undefined;
}
export interface ClouddeployAutomationRules {
    /**
    * advance_rollout_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#advance_rollout_rule ClouddeployAutomation#advance_rollout_rule}
    */
    readonly advanceRolloutRule?: ClouddeployAutomationRulesAdvanceRolloutRule;
    /**
    * promote_release_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#promote_release_rule ClouddeployAutomation#promote_release_rule}
    */
    readonly promoteReleaseRule?: ClouddeployAutomationRulesPromoteReleaseRule;
    /**
    * repair_rollout_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#repair_rollout_rule ClouddeployAutomation#repair_rollout_rule}
    */
    readonly repairRolloutRule?: ClouddeployAutomationRulesRepairRolloutRule;
    /**
    * timed_promote_release_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#timed_promote_release_rule ClouddeployAutomation#timed_promote_release_rule}
    */
    readonly timedPromoteReleaseRule?: ClouddeployAutomationRulesTimedPromoteReleaseRule;
}
export declare function clouddeployAutomationRulesToTerraform(struct?: ClouddeployAutomationRules | cdktn.IResolvable): any;
export declare function clouddeployAutomationRulesToHclTerraform(struct?: ClouddeployAutomationRules | cdktn.IResolvable): any;
export declare class ClouddeployAutomationRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ClouddeployAutomationRules | cdktn.IResolvable | undefined;
    set internalValue(value: ClouddeployAutomationRules | cdktn.IResolvable | undefined);
    private _advanceRolloutRule;
    get advanceRolloutRule(): ClouddeployAutomationRulesAdvanceRolloutRuleOutputReference;
    putAdvanceRolloutRule(value: ClouddeployAutomationRulesAdvanceRolloutRule): void;
    resetAdvanceRolloutRule(): void;
    get advanceRolloutRuleInput(): ClouddeployAutomationRulesAdvanceRolloutRule | undefined;
    private _promoteReleaseRule;
    get promoteReleaseRule(): ClouddeployAutomationRulesPromoteReleaseRuleOutputReference;
    putPromoteReleaseRule(value: ClouddeployAutomationRulesPromoteReleaseRule): void;
    resetPromoteReleaseRule(): void;
    get promoteReleaseRuleInput(): ClouddeployAutomationRulesPromoteReleaseRule | undefined;
    private _repairRolloutRule;
    get repairRolloutRule(): ClouddeployAutomationRulesRepairRolloutRuleOutputReference;
    putRepairRolloutRule(value: ClouddeployAutomationRulesRepairRolloutRule): void;
    resetRepairRolloutRule(): void;
    get repairRolloutRuleInput(): ClouddeployAutomationRulesRepairRolloutRule | undefined;
    private _timedPromoteReleaseRule;
    get timedPromoteReleaseRule(): ClouddeployAutomationRulesTimedPromoteReleaseRuleOutputReference;
    putTimedPromoteReleaseRule(value: ClouddeployAutomationRulesTimedPromoteReleaseRule): void;
    resetTimedPromoteReleaseRule(): void;
    get timedPromoteReleaseRuleInput(): ClouddeployAutomationRulesTimedPromoteReleaseRule | undefined;
}
export declare class ClouddeployAutomationRulesList extends cdktn.ComplexList {
    internalValue?: ClouddeployAutomationRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ClouddeployAutomationRulesOutputReference;
}
export interface ClouddeployAutomationSelectorTargets {
    /**
    * ID of the 'Target'. The value of this field could be one of the following: * The last segment of a target name. It only needs the ID to determine which target is being referred to * "*", all targets in a location.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#id ClouddeployAutomation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Target labels.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#labels ClouddeployAutomation#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
}
export declare function clouddeployAutomationSelectorTargetsToTerraform(struct?: ClouddeployAutomationSelectorTargets | cdktn.IResolvable): any;
export declare function clouddeployAutomationSelectorTargetsToHclTerraform(struct?: ClouddeployAutomationSelectorTargets | cdktn.IResolvable): any;
export declare class ClouddeployAutomationSelectorTargetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ClouddeployAutomationSelectorTargets | cdktn.IResolvable | undefined;
    set internalValue(value: ClouddeployAutomationSelectorTargets | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
}
export declare class ClouddeployAutomationSelectorTargetsList extends cdktn.ComplexList {
    internalValue?: ClouddeployAutomationSelectorTargets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ClouddeployAutomationSelectorTargetsOutputReference;
}
export interface ClouddeployAutomationSelector {
    /**
    * targets block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#targets ClouddeployAutomation#targets}
    */
    readonly targets: ClouddeployAutomationSelectorTargets[] | cdktn.IResolvable;
}
export declare function clouddeployAutomationSelectorToTerraform(struct?: ClouddeployAutomationSelectorOutputReference | ClouddeployAutomationSelector): any;
export declare function clouddeployAutomationSelectorToHclTerraform(struct?: ClouddeployAutomationSelectorOutputReference | ClouddeployAutomationSelector): any;
export declare class ClouddeployAutomationSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddeployAutomationSelector | undefined;
    set internalValue(value: ClouddeployAutomationSelector | undefined);
    private _targets;
    get targets(): ClouddeployAutomationSelectorTargetsList;
    putTargets(value: ClouddeployAutomationSelectorTargets[] | cdktn.IResolvable): void;
    get targetsInput(): cdktn.IResolvable | ClouddeployAutomationSelectorTargets[] | undefined;
}
export interface ClouddeployAutomationTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#create ClouddeployAutomation#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#delete ClouddeployAutomation#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#update ClouddeployAutomation#update}
    */
    readonly update?: string;
}
export declare function clouddeployAutomationTimeoutsToTerraform(struct?: ClouddeployAutomationTimeouts | cdktn.IResolvable): any;
export declare function clouddeployAutomationTimeoutsToHclTerraform(struct?: ClouddeployAutomationTimeouts | cdktn.IResolvable): any;
export declare class ClouddeployAutomationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddeployAutomationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ClouddeployAutomationTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation google_clouddeploy_automation}
*/
export declare class ClouddeployAutomation extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_clouddeploy_automation";
    /**
    * Generates CDKTN code for importing a ClouddeployAutomation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ClouddeployAutomation to import
    * @param importFromId The id of the existing ClouddeployAutomation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ClouddeployAutomation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_automation google_clouddeploy_automation} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ClouddeployAutomationConfig
    */
    constructor(scope: Construct, id: string, config: ClouddeployAutomationConfig);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _deliveryPipeline?;
    get deliveryPipeline(): string;
    set deliveryPipeline(value: string);
    get deliveryPipelineInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _effectiveAnnotations;
    get effectiveAnnotations(): cdktn.StringMap;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _serviceAccount?;
    get serviceAccount(): string;
    set serviceAccount(value: string);
    get serviceAccountInput(): string | undefined;
    private _suspended?;
    get suspended(): boolean | cdktn.IResolvable;
    set suspended(value: boolean | cdktn.IResolvable);
    resetSuspended(): void;
    get suspendedInput(): boolean | cdktn.IResolvable | undefined;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get uid(): string;
    get updateTime(): string;
    private _rules;
    get rules(): ClouddeployAutomationRulesList;
    putRules(value: ClouddeployAutomationRules[] | cdktn.IResolvable): void;
    get rulesInput(): cdktn.IResolvable | ClouddeployAutomationRules[] | undefined;
    private _selector;
    get selector(): ClouddeployAutomationSelectorOutputReference;
    putSelector(value: ClouddeployAutomationSelector): void;
    get selectorInput(): ClouddeployAutomationSelector | undefined;
    private _timeouts;
    get timeouts(): ClouddeployAutomationTimeoutsOutputReference;
    putTimeouts(value: ClouddeployAutomationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ClouddeployAutomationTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
