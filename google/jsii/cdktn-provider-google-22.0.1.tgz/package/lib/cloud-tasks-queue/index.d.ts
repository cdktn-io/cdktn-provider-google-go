/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudTasksQueueConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#deletion_policy CloudTasksQueue#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The desired state of the queue. Use this to pause and resume the queue.
    *
    * * RUNNING: The queue is running. Tasks can be dispatched.
    * * PAUSED: The queue is paused. Tasks are not dispatched but can be added to the queue. Default value: "RUNNING" Possible values: ["RUNNING", "PAUSED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#desired_state CloudTasksQueue#desired_state}
    */
    readonly desiredState?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#id CloudTasksQueue#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the queue
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#location CloudTasksQueue#location}
    */
    readonly location: string;
    /**
    * The queue name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#name CloudTasksQueue#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#project CloudTasksQueue#project}
    */
    readonly project?: string;
    /**
    * app_engine_routing_override block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#app_engine_routing_override CloudTasksQueue#app_engine_routing_override}
    */
    readonly appEngineRoutingOverride?: CloudTasksQueueAppEngineRoutingOverride;
    /**
    * http_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#http_target CloudTasksQueue#http_target}
    */
    readonly httpTarget?: CloudTasksQueueHttpTarget;
    /**
    * rate_limits block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#rate_limits CloudTasksQueue#rate_limits}
    */
    readonly rateLimits?: CloudTasksQueueRateLimits;
    /**
    * retry_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#retry_config CloudTasksQueue#retry_config}
    */
    readonly retryConfig?: CloudTasksQueueRetryConfig;
    /**
    * stackdriver_logging_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#stackdriver_logging_config CloudTasksQueue#stackdriver_logging_config}
    */
    readonly stackdriverLoggingConfig?: CloudTasksQueueStackdriverLoggingConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#timeouts CloudTasksQueue#timeouts}
    */
    readonly timeouts?: CloudTasksQueueTimeouts;
}
export interface CloudTasksQueueAppEngineRoutingOverride {
    /**
    * App instance.
    *
    * By default, the task is sent to an instance which is available when the task is attempted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#instance CloudTasksQueue#instance}
    */
    readonly instance?: string;
    /**
    * App service.
    *
    * By default, the task is sent to the service which is the default service when the task is attempted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#service CloudTasksQueue#service}
    */
    readonly service?: string;
    /**
    * App version.
    *
    * By default, the task is sent to the version which is the default version when the task is attempted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#version CloudTasksQueue#version}
    */
    readonly version?: string;
}
export declare function cloudTasksQueueAppEngineRoutingOverrideToTerraform(struct?: CloudTasksQueueAppEngineRoutingOverrideOutputReference | CloudTasksQueueAppEngineRoutingOverride): any;
export declare function cloudTasksQueueAppEngineRoutingOverrideToHclTerraform(struct?: CloudTasksQueueAppEngineRoutingOverrideOutputReference | CloudTasksQueueAppEngineRoutingOverride): any;
export declare class CloudTasksQueueAppEngineRoutingOverrideOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudTasksQueueAppEngineRoutingOverride | undefined;
    set internalValue(value: CloudTasksQueueAppEngineRoutingOverride | undefined);
    get host(): string;
    private _instance?;
    get instance(): string;
    set instance(value: string);
    resetInstance(): void;
    get instanceInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export interface CloudTasksQueueHttpTargetHeaderOverridesHeader {
    /**
    * The Key of the header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#key CloudTasksQueue#key}
    */
    readonly key: string;
    /**
    * The Value of the header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#value CloudTasksQueue#value}
    */
    readonly value: string;
}
export declare function cloudTasksQueueHttpTargetHeaderOverridesHeaderToTerraform(struct?: CloudTasksQueueHttpTargetHeaderOverridesHeaderOutputReference | CloudTasksQueueHttpTargetHeaderOverridesHeader): any;
export declare function cloudTasksQueueHttpTargetHeaderOverridesHeaderToHclTerraform(struct?: CloudTasksQueueHttpTargetHeaderOverridesHeaderOutputReference | CloudTasksQueueHttpTargetHeaderOverridesHeader): any;
export declare class CloudTasksQueueHttpTargetHeaderOverridesHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudTasksQueueHttpTargetHeaderOverridesHeader | undefined;
    set internalValue(value: CloudTasksQueueHttpTargetHeaderOverridesHeader | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export interface CloudTasksQueueHttpTargetHeaderOverrides {
    /**
    * header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#header CloudTasksQueue#header}
    */
    readonly header: CloudTasksQueueHttpTargetHeaderOverridesHeader;
}
export declare function cloudTasksQueueHttpTargetHeaderOverridesToTerraform(struct?: CloudTasksQueueHttpTargetHeaderOverrides | cdktn.IResolvable): any;
export declare function cloudTasksQueueHttpTargetHeaderOverridesToHclTerraform(struct?: CloudTasksQueueHttpTargetHeaderOverrides | cdktn.IResolvable): any;
export declare class CloudTasksQueueHttpTargetHeaderOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudTasksQueueHttpTargetHeaderOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: CloudTasksQueueHttpTargetHeaderOverrides | cdktn.IResolvable | undefined);
    private _header;
    get header(): CloudTasksQueueHttpTargetHeaderOverridesHeaderOutputReference;
    putHeader(value: CloudTasksQueueHttpTargetHeaderOverridesHeader): void;
    get headerInput(): CloudTasksQueueHttpTargetHeaderOverridesHeader | undefined;
}
export declare class CloudTasksQueueHttpTargetHeaderOverridesList extends cdktn.ComplexList {
    internalValue?: CloudTasksQueueHttpTargetHeaderOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudTasksQueueHttpTargetHeaderOverridesOutputReference;
}
export interface CloudTasksQueueHttpTargetOauthToken {
    /**
    * OAuth scope to be used for generating OAuth access token.
    * If not specified, "https://www.googleapis.com/auth/cloud-platform" will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#scope CloudTasksQueue#scope}
    */
    readonly scope?: string;
    /**
    * Service account email to be used for generating OAuth token.
    * The service account must be within the same project as the queue.
    * The caller must have iam.serviceAccounts.actAs permission for the service account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#service_account_email CloudTasksQueue#service_account_email}
    */
    readonly serviceAccountEmail: string;
}
export declare function cloudTasksQueueHttpTargetOauthTokenToTerraform(struct?: CloudTasksQueueHttpTargetOauthTokenOutputReference | CloudTasksQueueHttpTargetOauthToken): any;
export declare function cloudTasksQueueHttpTargetOauthTokenToHclTerraform(struct?: CloudTasksQueueHttpTargetOauthTokenOutputReference | CloudTasksQueueHttpTargetOauthToken): any;
export declare class CloudTasksQueueHttpTargetOauthTokenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudTasksQueueHttpTargetOauthToken | undefined;
    set internalValue(value: CloudTasksQueueHttpTargetOauthToken | undefined);
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
    private _serviceAccountEmail?;
    get serviceAccountEmail(): string;
    set serviceAccountEmail(value: string);
    get serviceAccountEmailInput(): string | undefined;
}
export interface CloudTasksQueueHttpTargetOidcToken {
    /**
    * Audience to be used when generating OIDC token. If not specified, the URI specified in target will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#audience CloudTasksQueue#audience}
    */
    readonly audience?: string;
    /**
    * Service account email to be used for generating OIDC token.
    * The service account must be within the same project as the queue.
    * The caller must have iam.serviceAccounts.actAs permission for the service account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#service_account_email CloudTasksQueue#service_account_email}
    */
    readonly serviceAccountEmail: string;
}
export declare function cloudTasksQueueHttpTargetOidcTokenToTerraform(struct?: CloudTasksQueueHttpTargetOidcTokenOutputReference | CloudTasksQueueHttpTargetOidcToken): any;
export declare function cloudTasksQueueHttpTargetOidcTokenToHclTerraform(struct?: CloudTasksQueueHttpTargetOidcTokenOutputReference | CloudTasksQueueHttpTargetOidcToken): any;
export declare class CloudTasksQueueHttpTargetOidcTokenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudTasksQueueHttpTargetOidcToken | undefined;
    set internalValue(value: CloudTasksQueueHttpTargetOidcToken | undefined);
    private _audience?;
    get audience(): string;
    set audience(value: string);
    resetAudience(): void;
    get audienceInput(): string | undefined;
    private _serviceAccountEmail?;
    get serviceAccountEmail(): string;
    set serviceAccountEmail(value: string);
    get serviceAccountEmailInput(): string | undefined;
}
export interface CloudTasksQueueHttpTargetUriOverridePathOverride {
    /**
    * The URI path (e.g., /users/1234). Default is an empty string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#path CloudTasksQueue#path}
    */
    readonly path?: string;
}
export declare function cloudTasksQueueHttpTargetUriOverridePathOverrideToTerraform(struct?: CloudTasksQueueHttpTargetUriOverridePathOverrideOutputReference | CloudTasksQueueHttpTargetUriOverridePathOverride): any;
export declare function cloudTasksQueueHttpTargetUriOverridePathOverrideToHclTerraform(struct?: CloudTasksQueueHttpTargetUriOverridePathOverrideOutputReference | CloudTasksQueueHttpTargetUriOverridePathOverride): any;
export declare class CloudTasksQueueHttpTargetUriOverridePathOverrideOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudTasksQueueHttpTargetUriOverridePathOverride | undefined;
    set internalValue(value: CloudTasksQueueHttpTargetUriOverridePathOverride | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export interface CloudTasksQueueHttpTargetUriOverrideQueryOverride {
    /**
    * The query parameters (e.g., qparam1=123&qparam2=456). Default is an empty string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#query_params CloudTasksQueue#query_params}
    */
    readonly queryParams?: string;
}
export declare function cloudTasksQueueHttpTargetUriOverrideQueryOverrideToTerraform(struct?: CloudTasksQueueHttpTargetUriOverrideQueryOverrideOutputReference | CloudTasksQueueHttpTargetUriOverrideQueryOverride): any;
export declare function cloudTasksQueueHttpTargetUriOverrideQueryOverrideToHclTerraform(struct?: CloudTasksQueueHttpTargetUriOverrideQueryOverrideOutputReference | CloudTasksQueueHttpTargetUriOverrideQueryOverride): any;
export declare class CloudTasksQueueHttpTargetUriOverrideQueryOverrideOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudTasksQueueHttpTargetUriOverrideQueryOverride | undefined;
    set internalValue(value: CloudTasksQueueHttpTargetUriOverrideQueryOverride | undefined);
    private _queryParams?;
    get queryParams(): string;
    set queryParams(value: string);
    resetQueryParams(): void;
    get queryParamsInput(): string | undefined;
}
export interface CloudTasksQueueHttpTargetUriOverride {
    /**
    * Host override.
    *
    * When specified, replaces the host part of the task URL.
    * For example, if the task URL is "https://www.google.com", and host value
    * is set to "example.net", the overridden URI will be changed to "https://example.net".
    * Host value cannot be an empty string (INVALID_ARGUMENT).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#host CloudTasksQueue#host}
    */
    readonly host?: string;
    /**
    * Port override.
    *
    * When specified, replaces the port part of the task URI.
    * For instance, for a URI http://www.google.com/foo and port=123, the overridden URI becomes http://www.google.com:123/foo.
    * Note that the port value must be a positive integer.
    * Setting the port to 0 (Zero) clears the URI port.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#port CloudTasksQueue#port}
    */
    readonly port?: string;
    /**
    * Scheme override.
    *
    * When specified, the task URI scheme is replaced by the provided value (HTTP or HTTPS). Possible values: ["HTTP", "HTTPS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#scheme CloudTasksQueue#scheme}
    */
    readonly scheme?: string;
    /**
    * URI Override Enforce Mode
    *
    * When specified, determines the Target UriOverride mode. If not specified, it defaults to ALWAYS. Possible values: ["ALWAYS", "IF_NOT_EXISTS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#uri_override_enforce_mode CloudTasksQueue#uri_override_enforce_mode}
    */
    readonly uriOverrideEnforceMode?: string;
    /**
    * path_override block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#path_override CloudTasksQueue#path_override}
    */
    readonly pathOverride?: CloudTasksQueueHttpTargetUriOverridePathOverride;
    /**
    * query_override block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#query_override CloudTasksQueue#query_override}
    */
    readonly queryOverride?: CloudTasksQueueHttpTargetUriOverrideQueryOverride;
}
export declare function cloudTasksQueueHttpTargetUriOverrideToTerraform(struct?: CloudTasksQueueHttpTargetUriOverrideOutputReference | CloudTasksQueueHttpTargetUriOverride): any;
export declare function cloudTasksQueueHttpTargetUriOverrideToHclTerraform(struct?: CloudTasksQueueHttpTargetUriOverrideOutputReference | CloudTasksQueueHttpTargetUriOverride): any;
export declare class CloudTasksQueueHttpTargetUriOverrideOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudTasksQueueHttpTargetUriOverride | undefined;
    set internalValue(value: CloudTasksQueueHttpTargetUriOverride | undefined);
    private _host?;
    get host(): string;
    set host(value: string);
    resetHost(): void;
    get hostInput(): string | undefined;
    private _port?;
    get port(): string;
    set port(value: string);
    resetPort(): void;
    get portInput(): string | undefined;
    private _scheme?;
    get scheme(): string;
    set scheme(value: string);
    resetScheme(): void;
    get schemeInput(): string | undefined;
    private _uriOverrideEnforceMode?;
    get uriOverrideEnforceMode(): string;
    set uriOverrideEnforceMode(value: string);
    resetUriOverrideEnforceMode(): void;
    get uriOverrideEnforceModeInput(): string | undefined;
    private _pathOverride;
    get pathOverride(): CloudTasksQueueHttpTargetUriOverridePathOverrideOutputReference;
    putPathOverride(value: CloudTasksQueueHttpTargetUriOverridePathOverride): void;
    resetPathOverride(): void;
    get pathOverrideInput(): CloudTasksQueueHttpTargetUriOverridePathOverride | undefined;
    private _queryOverride;
    get queryOverride(): CloudTasksQueueHttpTargetUriOverrideQueryOverrideOutputReference;
    putQueryOverride(value: CloudTasksQueueHttpTargetUriOverrideQueryOverride): void;
    resetQueryOverride(): void;
    get queryOverrideInput(): CloudTasksQueueHttpTargetUriOverrideQueryOverride | undefined;
}
export interface CloudTasksQueueHttpTarget {
    /**
    * The HTTP method to use for the request.
    *
    * When specified, it overrides HttpRequest for the task.
    * Note that if the value is set to GET the body of the task will be ignored at execution time. Possible values: ["HTTP_METHOD_UNSPECIFIED", "POST", "GET", "HEAD", "PUT", "DELETE", "PATCH", "OPTIONS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#http_method CloudTasksQueue#http_method}
    */
    readonly httpMethod?: string;
    /**
    * header_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#header_overrides CloudTasksQueue#header_overrides}
    */
    readonly headerOverrides?: CloudTasksQueueHttpTargetHeaderOverrides[] | cdktn.IResolvable;
    /**
    * oauth_token block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#oauth_token CloudTasksQueue#oauth_token}
    */
    readonly oauthToken?: CloudTasksQueueHttpTargetOauthToken;
    /**
    * oidc_token block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#oidc_token CloudTasksQueue#oidc_token}
    */
    readonly oidcToken?: CloudTasksQueueHttpTargetOidcToken;
    /**
    * uri_override block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#uri_override CloudTasksQueue#uri_override}
    */
    readonly uriOverride?: CloudTasksQueueHttpTargetUriOverride;
}
export declare function cloudTasksQueueHttpTargetToTerraform(struct?: CloudTasksQueueHttpTargetOutputReference | CloudTasksQueueHttpTarget): any;
export declare function cloudTasksQueueHttpTargetToHclTerraform(struct?: CloudTasksQueueHttpTargetOutputReference | CloudTasksQueueHttpTarget): any;
export declare class CloudTasksQueueHttpTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudTasksQueueHttpTarget | undefined;
    set internalValue(value: CloudTasksQueueHttpTarget | undefined);
    private _httpMethod?;
    get httpMethod(): string;
    set httpMethod(value: string);
    resetHttpMethod(): void;
    get httpMethodInput(): string | undefined;
    private _headerOverrides;
    get headerOverrides(): CloudTasksQueueHttpTargetHeaderOverridesList;
    putHeaderOverrides(value: CloudTasksQueueHttpTargetHeaderOverrides[] | cdktn.IResolvable): void;
    resetHeaderOverrides(): void;
    get headerOverridesInput(): cdktn.IResolvable | CloudTasksQueueHttpTargetHeaderOverrides[] | undefined;
    private _oauthToken;
    get oauthToken(): CloudTasksQueueHttpTargetOauthTokenOutputReference;
    putOauthToken(value: CloudTasksQueueHttpTargetOauthToken): void;
    resetOauthToken(): void;
    get oauthTokenInput(): CloudTasksQueueHttpTargetOauthToken | undefined;
    private _oidcToken;
    get oidcToken(): CloudTasksQueueHttpTargetOidcTokenOutputReference;
    putOidcToken(value: CloudTasksQueueHttpTargetOidcToken): void;
    resetOidcToken(): void;
    get oidcTokenInput(): CloudTasksQueueHttpTargetOidcToken | undefined;
    private _uriOverride;
    get uriOverride(): CloudTasksQueueHttpTargetUriOverrideOutputReference;
    putUriOverride(value: CloudTasksQueueHttpTargetUriOverride): void;
    resetUriOverride(): void;
    get uriOverrideInput(): CloudTasksQueueHttpTargetUriOverride | undefined;
}
export interface CloudTasksQueueRateLimits {
    /**
    * The maximum number of concurrent tasks that Cloud Tasks allows to
    * be dispatched for this queue. After this threshold has been
    * reached, Cloud Tasks stops dispatching tasks until the number of
    * concurrent requests decreases.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#max_concurrent_dispatches CloudTasksQueue#max_concurrent_dispatches}
    */
    readonly maxConcurrentDispatches?: number;
    /**
    * The maximum rate at which tasks are dispatched from this queue.
    *
    * If unspecified when the queue is created, Cloud Tasks will pick the default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#max_dispatches_per_second CloudTasksQueue#max_dispatches_per_second}
    */
    readonly maxDispatchesPerSecond?: number;
}
export declare function cloudTasksQueueRateLimitsToTerraform(struct?: CloudTasksQueueRateLimitsOutputReference | CloudTasksQueueRateLimits): any;
export declare function cloudTasksQueueRateLimitsToHclTerraform(struct?: CloudTasksQueueRateLimitsOutputReference | CloudTasksQueueRateLimits): any;
export declare class CloudTasksQueueRateLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudTasksQueueRateLimits | undefined;
    set internalValue(value: CloudTasksQueueRateLimits | undefined);
    get maxBurstSize(): number;
    private _maxConcurrentDispatches?;
    get maxConcurrentDispatches(): number;
    set maxConcurrentDispatches(value: number);
    resetMaxConcurrentDispatches(): void;
    get maxConcurrentDispatchesInput(): number | undefined;
    private _maxDispatchesPerSecond?;
    get maxDispatchesPerSecond(): number;
    set maxDispatchesPerSecond(value: number);
    resetMaxDispatchesPerSecond(): void;
    get maxDispatchesPerSecondInput(): number | undefined;
}
export interface CloudTasksQueueRetryConfig {
    /**
    * Number of attempts per task.
    *
    * Cloud Tasks will attempt the task maxAttempts times (that is, if
    * the first attempt fails, then there will be maxAttempts - 1
    * retries). Must be >= -1.
    *
    * If unspecified when the queue is created, Cloud Tasks will pick
    * the default.
    *
    * -1 indicates unlimited attempts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#max_attempts CloudTasksQueue#max_attempts}
    */
    readonly maxAttempts?: number;
    /**
    * A task will be scheduled for retry between minBackoff and
    * maxBackoff duration after it fails, if the queue's RetryConfig
    * specifies that the task should be retried.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#max_backoff CloudTasksQueue#max_backoff}
    */
    readonly maxBackoff?: string;
    /**
    * The time between retries will double maxDoublings times.
    *
    * A task's retry interval starts at minBackoff, then doubles maxDoublings times,
    * then increases linearly, and finally retries retries at intervals of maxBackoff
    * up to maxAttempts times.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#max_doublings CloudTasksQueue#max_doublings}
    */
    readonly maxDoublings?: number;
    /**
    * If positive, maxRetryDuration specifies the time limit for
    * retrying a failed task, measured from when the task was first
    * attempted. Once maxRetryDuration time has passed and the task has
    * been attempted maxAttempts times, no further attempts will be
    * made and the task will be deleted.
    *
    * If zero, then the task age is unlimited.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#max_retry_duration CloudTasksQueue#max_retry_duration}
    */
    readonly maxRetryDuration?: string;
    /**
    * A task will be scheduled for retry between minBackoff and
    * maxBackoff duration after it fails, if the queue's RetryConfig
    * specifies that the task should be retried.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#min_backoff CloudTasksQueue#min_backoff}
    */
    readonly minBackoff?: string;
}
export declare function cloudTasksQueueRetryConfigToTerraform(struct?: CloudTasksQueueRetryConfigOutputReference | CloudTasksQueueRetryConfig): any;
export declare function cloudTasksQueueRetryConfigToHclTerraform(struct?: CloudTasksQueueRetryConfigOutputReference | CloudTasksQueueRetryConfig): any;
export declare class CloudTasksQueueRetryConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudTasksQueueRetryConfig | undefined;
    set internalValue(value: CloudTasksQueueRetryConfig | undefined);
    private _maxAttempts?;
    get maxAttempts(): number;
    set maxAttempts(value: number);
    resetMaxAttempts(): void;
    get maxAttemptsInput(): number | undefined;
    private _maxBackoff?;
    get maxBackoff(): string;
    set maxBackoff(value: string);
    resetMaxBackoff(): void;
    get maxBackoffInput(): string | undefined;
    private _maxDoublings?;
    get maxDoublings(): number;
    set maxDoublings(value: number);
    resetMaxDoublings(): void;
    get maxDoublingsInput(): number | undefined;
    private _maxRetryDuration?;
    get maxRetryDuration(): string;
    set maxRetryDuration(value: string);
    resetMaxRetryDuration(): void;
    get maxRetryDurationInput(): string | undefined;
    private _minBackoff?;
    get minBackoff(): string;
    set minBackoff(value: string);
    resetMinBackoff(): void;
    get minBackoffInput(): string | undefined;
}
export interface CloudTasksQueueStackdriverLoggingConfig {
    /**
    * Specifies the fraction of operations to write to Stackdriver Logging.
    * This field may contain any value between 0.0 and 1.0, inclusive. 0.0 is the
    * default and means that no operations are logged.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#sampling_ratio CloudTasksQueue#sampling_ratio}
    */
    readonly samplingRatio: number;
}
export declare function cloudTasksQueueStackdriverLoggingConfigToTerraform(struct?: CloudTasksQueueStackdriverLoggingConfigOutputReference | CloudTasksQueueStackdriverLoggingConfig): any;
export declare function cloudTasksQueueStackdriverLoggingConfigToHclTerraform(struct?: CloudTasksQueueStackdriverLoggingConfigOutputReference | CloudTasksQueueStackdriverLoggingConfig): any;
export declare class CloudTasksQueueStackdriverLoggingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudTasksQueueStackdriverLoggingConfig | undefined;
    set internalValue(value: CloudTasksQueueStackdriverLoggingConfig | undefined);
    private _samplingRatio?;
    get samplingRatio(): number;
    set samplingRatio(value: number);
    get samplingRatioInput(): number | undefined;
}
export interface CloudTasksQueueTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#create CloudTasksQueue#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#delete CloudTasksQueue#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#update CloudTasksQueue#update}
    */
    readonly update?: string;
}
export declare function cloudTasksQueueTimeoutsToTerraform(struct?: CloudTasksQueueTimeouts | cdktn.IResolvable): any;
export declare function cloudTasksQueueTimeoutsToHclTerraform(struct?: CloudTasksQueueTimeouts | cdktn.IResolvable): any;
export declare class CloudTasksQueueTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudTasksQueueTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CloudTasksQueueTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue google_cloud_tasks_queue}
*/
export declare class CloudTasksQueue extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_cloud_tasks_queue";
    /**
    * Generates CDKTN code for importing a CloudTasksQueue resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudTasksQueue to import
    * @param importFromId The id of the existing CloudTasksQueue that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudTasksQueue to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_tasks_queue google_cloud_tasks_queue} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudTasksQueueConfig
    */
    constructor(scope: Construct, id: string, config: CloudTasksQueueConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _desiredState?;
    get desiredState(): string;
    set desiredState(value: string);
    resetDesiredState(): void;
    get desiredStateInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get state(): string;
    private _appEngineRoutingOverride;
    get appEngineRoutingOverride(): CloudTasksQueueAppEngineRoutingOverrideOutputReference;
    putAppEngineRoutingOverride(value: CloudTasksQueueAppEngineRoutingOverride): void;
    resetAppEngineRoutingOverride(): void;
    get appEngineRoutingOverrideInput(): CloudTasksQueueAppEngineRoutingOverride | undefined;
    private _httpTarget;
    get httpTarget(): CloudTasksQueueHttpTargetOutputReference;
    putHttpTarget(value: CloudTasksQueueHttpTarget): void;
    resetHttpTarget(): void;
    get httpTargetInput(): CloudTasksQueueHttpTarget | undefined;
    private _rateLimits;
    get rateLimits(): CloudTasksQueueRateLimitsOutputReference;
    putRateLimits(value: CloudTasksQueueRateLimits): void;
    resetRateLimits(): void;
    get rateLimitsInput(): CloudTasksQueueRateLimits | undefined;
    private _retryConfig;
    get retryConfig(): CloudTasksQueueRetryConfigOutputReference;
    putRetryConfig(value: CloudTasksQueueRetryConfig): void;
    resetRetryConfig(): void;
    get retryConfigInput(): CloudTasksQueueRetryConfig | undefined;
    private _stackdriverLoggingConfig;
    get stackdriverLoggingConfig(): CloudTasksQueueStackdriverLoggingConfigOutputReference;
    putStackdriverLoggingConfig(value: CloudTasksQueueStackdriverLoggingConfig): void;
    resetStackdriverLoggingConfig(): void;
    get stackdriverLoggingConfigInput(): CloudTasksQueueStackdriverLoggingConfig | undefined;
    private _timeouts;
    get timeouts(): CloudTasksQueueTimeoutsOutputReference;
    putTimeouts(value: CloudTasksQueueTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CloudTasksQueueTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
