/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeNodeTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * CPU overcommit. Default value: "NONE" Possible values: ["ENABLED", "NONE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_node_template#cpu_overcommit_type ComputeNodeTemplate#cpu_overcommit_type}
    */
    readonly cpuOvercommitType?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_node_template#deletion_policy ComputeNodeTemplate#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional textual description of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_node_template#description ComputeNodeTemplate#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_node_template#id ComputeNodeTemplate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_node_template#name ComputeNodeTemplate#name}
    */
    readonly name: string;
    /**
    * Labels to use for node affinity, which will be used in
    * instance scheduling.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_node_template#node_affinity_labels ComputeNodeTemplate#node_affinity_labels}
    */
    readonly nodeAffinityLabels?: {
        [key: string]: string;
    };
    /**
    * Node type to use for nodes group that are created from this template.
    * Only one of nodeTypeFlexibility and nodeType can be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_node_template#node_type ComputeNodeTemplate#node_type}
    */
    readonly nodeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_node_template#project ComputeNodeTemplate#project}
    */
    readonly project?: string;
    /**
    * Region where nodes using the node template will be created.
    * If it is not provided, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_node_template#region ComputeNodeTemplate#region}
    */
    readonly region?: string;
    /**
    * accelerators block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_node_template#accelerators ComputeNodeTemplate#accelerators}
    */
    readonly accelerators?: ComputeNodeTemplateAccelerators[] | cdktn.IResolvable;
    /**
    * disks block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_node_template#disks ComputeNodeTemplate#disks}
    */
    readonly disks?: ComputeNodeTemplateDisks[] | cdktn.IResolvable;
    /**
    * node_type_flexibility block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_node_template#node_type_flexibility ComputeNodeTemplate#node_type_flexibility}
    */
    readonly nodeTypeFlexibility?: ComputeNodeTemplateNodeTypeFlexibility;
    /**
    * server_binding block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_node_template#server_binding ComputeNodeTemplate#server_binding}
    */
    readonly serverBinding?: ComputeNodeTemplateServerBinding;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_node_template#timeouts ComputeNodeTemplate#timeouts}
    */
    readonly timeouts?: ComputeNodeTemplateTimeouts;
}
export interface ComputeNodeTemplateAccelerators {
    /**
    * The number of the guest accelerator cards exposed to this
    * node template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_node_template#accelerator_count ComputeNodeTemplate#accelerator_count}
    */
    readonly acceleratorCount?: number;
    /**
    * Full or partial URL of the accelerator type resource to expose
    * to this node template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_node_template#accelerator_type ComputeNodeTemplate#accelerator_type}
    */
    readonly acceleratorType?: string;
}
export declare function computeNodeTemplateAcceleratorsToTerraform(struct?: ComputeNodeTemplateAccelerators | cdktn.IResolvable): any;
export declare function computeNodeTemplateAcceleratorsToHclTerraform(struct?: ComputeNodeTemplateAccelerators | cdktn.IResolvable): any;
export declare class ComputeNodeTemplateAcceleratorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeNodeTemplateAccelerators | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeNodeTemplateAccelerators | cdktn.IResolvable | undefined);
    private _acceleratorCount?;
    get acceleratorCount(): number;
    set acceleratorCount(value: number);
    resetAcceleratorCount(): void;
    get acceleratorCountInput(): number | undefined;
    private _acceleratorType?;
    get acceleratorType(): string;
    set acceleratorType(value: string);
    resetAcceleratorType(): void;
    get acceleratorTypeInput(): string | undefined;
}
export declare class ComputeNodeTemplateAcceleratorsList extends cdktn.ComplexList {
    internalValue?: ComputeNodeTemplateAccelerators[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeNodeTemplateAcceleratorsOutputReference;
}
export interface ComputeNodeTemplateDisks {
    /**
    * Specifies the number of such disks.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_node_template#disk_count ComputeNodeTemplate#disk_count}
    */
    readonly diskCount?: number;
    /**
    * Specifies the size of the disk in base-2 GB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_node_template#disk_size_gb ComputeNodeTemplate#disk_size_gb}
    */
    readonly diskSizeGb?: number;
    /**
    * Specifies the desired disk type on the node. This disk type must be a local storage type (e.g.: local-ssd). Note that for nodeTemplates, this should be the name of the disk type and not its URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_node_template#disk_type ComputeNodeTemplate#disk_type}
    */
    readonly diskType?: string;
}
export declare function computeNodeTemplateDisksToTerraform(struct?: ComputeNodeTemplateDisks | cdktn.IResolvable): any;
export declare function computeNodeTemplateDisksToHclTerraform(struct?: ComputeNodeTemplateDisks | cdktn.IResolvable): any;
export declare class ComputeNodeTemplateDisksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeNodeTemplateDisks | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeNodeTemplateDisks | cdktn.IResolvable | undefined);
    private _diskCount?;
    get diskCount(): number;
    set diskCount(value: number);
    resetDiskCount(): void;
    get diskCountInput(): number | undefined;
    private _diskSizeGb?;
    get diskSizeGb(): number;
    set diskSizeGb(value: number);
    resetDiskSizeGb(): void;
    get diskSizeGbInput(): number | undefined;
    private _diskType?;
    get diskType(): string;
    set diskType(value: string);
    resetDiskType(): void;
    get diskTypeInput(): string | undefined;
}
export declare class ComputeNodeTemplateDisksList extends cdktn.ComplexList {
    internalValue?: ComputeNodeTemplateDisks[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeNodeTemplateDisksOutputReference;
}
export interface ComputeNodeTemplateNodeTypeFlexibility {
    /**
    * Number of virtual CPUs to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_node_template#cpus ComputeNodeTemplate#cpus}
    */
    readonly cpus?: string;
    /**
    * Physical memory available to the node, defined in MB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_node_template#memory ComputeNodeTemplate#memory}
    */
    readonly memory?: string;
}
export declare function computeNodeTemplateNodeTypeFlexibilityToTerraform(struct?: ComputeNodeTemplateNodeTypeFlexibilityOutputReference | ComputeNodeTemplateNodeTypeFlexibility): any;
export declare function computeNodeTemplateNodeTypeFlexibilityToHclTerraform(struct?: ComputeNodeTemplateNodeTypeFlexibilityOutputReference | ComputeNodeTemplateNodeTypeFlexibility): any;
export declare class ComputeNodeTemplateNodeTypeFlexibilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeNodeTemplateNodeTypeFlexibility | undefined;
    set internalValue(value: ComputeNodeTemplateNodeTypeFlexibility | undefined);
    private _cpus?;
    get cpus(): string;
    set cpus(value: string);
    resetCpus(): void;
    get cpusInput(): string | undefined;
    get localSsd(): string;
    private _memory?;
    get memory(): string;
    set memory(value: string);
    resetMemory(): void;
    get memoryInput(): string | undefined;
}
export interface ComputeNodeTemplateServerBinding {
    /**
    * Type of server binding policy. If 'RESTART_NODE_ON_ANY_SERVER',
    * nodes using this template will restart on any physical server
    * following a maintenance event.
    *
    * If 'RESTART_NODE_ON_MINIMAL_SERVER', nodes using this template
    * will restart on the same physical server following a maintenance
    * event, instead of being live migrated to or restarted on a new
    * physical server. This option may be useful if you are using
    * software licenses tied to the underlying server characteristics
    * such as physical sockets or cores, to avoid the need for
    * additional licenses when maintenance occurs. However, VMs on such
    * nodes will experience outages while maintenance is applied. Possible values: ["RESTART_NODE_ON_ANY_SERVER", "RESTART_NODE_ON_MINIMAL_SERVERS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_node_template#type ComputeNodeTemplate#type}
    */
    readonly type: string;
}
export declare function computeNodeTemplateServerBindingToTerraform(struct?: ComputeNodeTemplateServerBindingOutputReference | ComputeNodeTemplateServerBinding): any;
export declare function computeNodeTemplateServerBindingToHclTerraform(struct?: ComputeNodeTemplateServerBindingOutputReference | ComputeNodeTemplateServerBinding): any;
export declare class ComputeNodeTemplateServerBindingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeNodeTemplateServerBinding | undefined;
    set internalValue(value: ComputeNodeTemplateServerBinding | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface ComputeNodeTemplateTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_node_template#create ComputeNodeTemplate#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_node_template#delete ComputeNodeTemplate#delete}
    */
    readonly delete?: string;
}
export declare function computeNodeTemplateTimeoutsToTerraform(struct?: ComputeNodeTemplateTimeouts | cdktn.IResolvable): any;
export declare function computeNodeTemplateTimeoutsToHclTerraform(struct?: ComputeNodeTemplateTimeouts | cdktn.IResolvable): any;
export declare class ComputeNodeTemplateTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeNodeTemplateTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeNodeTemplateTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_node_template google_compute_node_template}
*/
export declare class ComputeNodeTemplate extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_node_template";
    /**
    * Generates CDKTN code for importing a ComputeNodeTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeNodeTemplate to import
    * @param importFromId The id of the existing ComputeNodeTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_node_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeNodeTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_node_template google_compute_node_template} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeNodeTemplateConfig
    */
    constructor(scope: Construct, id: string, config: ComputeNodeTemplateConfig);
    private _cpuOvercommitType?;
    get cpuOvercommitType(): string;
    set cpuOvercommitType(value: string);
    resetCpuOvercommitType(): void;
    get cpuOvercommitTypeInput(): string | undefined;
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nodeAffinityLabels?;
    get nodeAffinityLabels(): {
        [key: string]: string;
    };
    set nodeAffinityLabels(value: {
        [key: string]: string;
    });
    resetNodeAffinityLabels(): void;
    get nodeAffinityLabelsInput(): {
        [key: string]: string;
    } | undefined;
    private _nodeType?;
    get nodeType(): string;
    set nodeType(value: string);
    resetNodeType(): void;
    get nodeTypeInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get selfLink(): string;
    private _accelerators;
    get accelerators(): ComputeNodeTemplateAcceleratorsList;
    putAccelerators(value: ComputeNodeTemplateAccelerators[] | cdktn.IResolvable): void;
    resetAccelerators(): void;
    get acceleratorsInput(): cdktn.IResolvable | ComputeNodeTemplateAccelerators[] | undefined;
    private _disks;
    get disks(): ComputeNodeTemplateDisksList;
    putDisks(value: ComputeNodeTemplateDisks[] | cdktn.IResolvable): void;
    resetDisks(): void;
    get disksInput(): cdktn.IResolvable | ComputeNodeTemplateDisks[] | undefined;
    private _nodeTypeFlexibility;
    get nodeTypeFlexibility(): ComputeNodeTemplateNodeTypeFlexibilityOutputReference;
    putNodeTypeFlexibility(value: ComputeNodeTemplateNodeTypeFlexibility): void;
    resetNodeTypeFlexibility(): void;
    get nodeTypeFlexibilityInput(): ComputeNodeTemplateNodeTypeFlexibility | undefined;
    private _serverBinding;
    get serverBinding(): ComputeNodeTemplateServerBindingOutputReference;
    putServerBinding(value: ComputeNodeTemplateServerBinding): void;
    resetServerBinding(): void;
    get serverBindingInput(): ComputeNodeTemplateServerBinding | undefined;
    private _timeouts;
    get timeouts(): ComputeNodeTemplateTimeoutsOutputReference;
    putTimeouts(value: ComputeNodeTemplateTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeNodeTemplateTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
