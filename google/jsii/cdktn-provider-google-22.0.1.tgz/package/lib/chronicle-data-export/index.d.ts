/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChronicleDataExportConfig extends cdktn.TerraformMetaArguments {
    /**
    * Last, exclusive time from the range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_export#end_time ChronicleDataExport#end_time}
    */
    readonly endTime: string;
    /**
    * Link to the destination Cloud Storage bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_export#gcs_bucket ChronicleDataExport#gcs_bucket}
    */
    readonly gcsBucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_export#id ChronicleDataExport#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The specific log types to include in the Data Export request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_export#include_log_types ChronicleDataExport#include_log_types}
    */
    readonly includeLogTypes?: string[];
    /**
    * The unique identifier for the Chronicle instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_export#instance ChronicleDataExport#instance}
    */
    readonly instance: string;
    /**
    * The location of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_export#location ChronicleDataExport#location}
    */
    readonly location: string;
    /**
    * The namespaces used to filter the export.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_export#namespaces ChronicleDataExport#namespaces}
    */
    readonly namespaces?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_export#project ChronicleDataExport#project}
    */
    readonly project?: string;
    /**
    * Start, inclusive time from the range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_export#start_time ChronicleDataExport#start_time}
    */
    readonly startTime: string;
    /**
    * ingestion_labels block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_export#ingestion_labels ChronicleDataExport#ingestion_labels}
    */
    readonly ingestionLabels?: ChronicleDataExportIngestionLabels[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_export#timeouts ChronicleDataExport#timeouts}
    */
    readonly timeouts?: ChronicleDataExportTimeouts;
}
export interface ChronicleDataExportDataExportStatus {
}
export declare function chronicleDataExportDataExportStatusToTerraform(struct?: ChronicleDataExportDataExportStatus): any;
export declare function chronicleDataExportDataExportStatusToHclTerraform(struct?: ChronicleDataExportDataExportStatus): any;
export declare class ChronicleDataExportDataExportStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleDataExportDataExportStatus | undefined;
    set internalValue(value: ChronicleDataExportDataExportStatus | undefined);
    get dataRbacFiltered(): cdktn.IResolvable;
    get error(): string;
    get exportedGlobPatterns(): string[];
    get stage(): string;
}
export declare class ChronicleDataExportDataExportStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleDataExportDataExportStatusOutputReference;
}
export interface ChronicleDataExportIngestionLabels {
    /**
    * The key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_export#key ChronicleDataExport#key}
    */
    readonly key: string;
    /**
    * The value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_export#value ChronicleDataExport#value}
    */
    readonly value: string;
}
export declare function chronicleDataExportIngestionLabelsToTerraform(struct?: ChronicleDataExportIngestionLabels | cdktn.IResolvable): any;
export declare function chronicleDataExportIngestionLabelsToHclTerraform(struct?: ChronicleDataExportIngestionLabels | cdktn.IResolvable): any;
export declare class ChronicleDataExportIngestionLabelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleDataExportIngestionLabels | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleDataExportIngestionLabels | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ChronicleDataExportIngestionLabelsList extends cdktn.ComplexList {
    internalValue?: ChronicleDataExportIngestionLabels[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleDataExportIngestionLabelsOutputReference;
}
export interface ChronicleDataExportTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_export#create ChronicleDataExport#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_export#delete ChronicleDataExport#delete}
    */
    readonly delete?: string;
}
export declare function chronicleDataExportTimeoutsToTerraform(struct?: ChronicleDataExportTimeouts | cdktn.IResolvable): any;
export declare function chronicleDataExportTimeoutsToHclTerraform(struct?: ChronicleDataExportTimeouts | cdktn.IResolvable): any;
export declare class ChronicleDataExportTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDataExportTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleDataExportTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_export google_chronicle_data_export}
*/
export declare class ChronicleDataExport extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_chronicle_data_export";
    /**
    * Generates CDKTN code for importing a ChronicleDataExport resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChronicleDataExport to import
    * @param importFromId The id of the existing ChronicleDataExport that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_export#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChronicleDataExport to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_data_export google_chronicle_data_export} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChronicleDataExportConfig
    */
    constructor(scope: Construct, id: string, config: ChronicleDataExportConfig);
    get createTime(): string;
    get dataExportId(): string;
    private _dataExportStatus;
    get dataExportStatus(): ChronicleDataExportDataExportStatusList;
    private _endTime?;
    get endTime(): string;
    set endTime(value: string);
    get endTimeInput(): string | undefined;
    get estimatedVolume(): number;
    get exportedVolume(): number;
    private _gcsBucket?;
    get gcsBucket(): string;
    set gcsBucket(value: string);
    get gcsBucketInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _includeLogTypes?;
    get includeLogTypes(): string[];
    set includeLogTypes(value: string[]);
    resetIncludeLogTypes(): void;
    get includeLogTypesInput(): string[] | undefined;
    private _instance?;
    get instance(): string;
    set instance(value: string);
    get instanceInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _namespaces?;
    get namespaces(): string[];
    set namespaces(value: string[]);
    resetNamespaces(): void;
    get namespacesInput(): string[] | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    get startTimeInput(): string | undefined;
    get updateTime(): string;
    private _ingestionLabels;
    get ingestionLabels(): ChronicleDataExportIngestionLabelsList;
    putIngestionLabels(value: ChronicleDataExportIngestionLabels[] | cdktn.IResolvable): void;
    resetIngestionLabels(): void;
    get ingestionLabelsInput(): cdktn.IResolvable | ChronicleDataExportIngestionLabels[] | undefined;
    private _timeouts;
    get timeouts(): ChronicleDataExportTimeoutsOutputReference;
    putTimeouts(value: ChronicleDataExportTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ChronicleDataExportTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
