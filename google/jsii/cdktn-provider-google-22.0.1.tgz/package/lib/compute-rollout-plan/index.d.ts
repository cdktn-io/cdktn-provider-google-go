/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeRolloutPlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#deletion_policy ComputeRolloutPlan#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#description ComputeRolloutPlan#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#id ComputeRolloutPlan#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location scope of the rollout plan. Possible values: ["LOCATION_SCOPE_UNSPECIFIED", "ZONAL", "REGIONAL"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#location_scope ComputeRolloutPlan#location_scope}
    */
    readonly locationScope?: string;
    /**
    * Name of the resource. Provided by the client when the resource is created.
    * The name must be 1-63 characters long, and comply with RFC1035.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#name ComputeRolloutPlan#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#project ComputeRolloutPlan#project}
    */
    readonly project?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#timeouts ComputeRolloutPlan#timeouts}
    */
    readonly timeouts?: ComputeRolloutPlanTimeouts;
    /**
    * waves block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#waves ComputeRolloutPlan#waves}
    */
    readonly waves: ComputeRolloutPlanWaves[] | cdktn.IResolvable;
}
export interface ComputeRolloutPlanTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#create ComputeRolloutPlan#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#delete ComputeRolloutPlan#delete}
    */
    readonly delete?: string;
}
export declare function computeRolloutPlanTimeoutsToTerraform(struct?: ComputeRolloutPlanTimeouts | cdktn.IResolvable): any;
export declare function computeRolloutPlanTimeoutsToHclTerraform(struct?: ComputeRolloutPlanTimeouts | cdktn.IResolvable): any;
export declare class ComputeRolloutPlanTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRolloutPlanTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRolloutPlanTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
export interface ComputeRolloutPlanWavesOrchestrationOptionsDelays {
    /**
    * Controls whether the delay should only be added between batches of projects corresponding to different locations, or also between batches of projects corresponding to the same location. Possible values: ["DELIMITER_UNSPECIFIED", "DELIMITER_LOCATION", "DELIMITER_BATCH"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#delimiter ComputeRolloutPlan#delimiter}
    */
    readonly delimiter?: string;
    /**
    * The duration of the delay, if any, to be added between batches of projects.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#duration ComputeRolloutPlan#duration}
    */
    readonly duration?: string;
    /**
    * Controls whether the specified duration is to be added at the end of each batch, or if the total processing time for each batch will be padded if needed to meet the specified duration. Possible values: ["TYPE_UNSPECIFIED", "TYPE_OFFSET", "TYPE_MINIMUM"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#type ComputeRolloutPlan#type}
    */
    readonly type?: string;
}
export declare function computeRolloutPlanWavesOrchestrationOptionsDelaysToTerraform(struct?: ComputeRolloutPlanWavesOrchestrationOptionsDelays | cdktn.IResolvable): any;
export declare function computeRolloutPlanWavesOrchestrationOptionsDelaysToHclTerraform(struct?: ComputeRolloutPlanWavesOrchestrationOptionsDelays | cdktn.IResolvable): any;
export declare class ComputeRolloutPlanWavesOrchestrationOptionsDelaysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRolloutPlanWavesOrchestrationOptionsDelays | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRolloutPlanWavesOrchestrationOptionsDelays | cdktn.IResolvable | undefined);
    private _delimiter?;
    get delimiter(): string;
    set delimiter(value: string);
    resetDelimiter(): void;
    get delimiterInput(): string | undefined;
    private _duration?;
    get duration(): string;
    set duration(value: string);
    resetDuration(): void;
    get durationInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class ComputeRolloutPlanWavesOrchestrationOptionsDelaysList extends cdktn.ComplexList {
    internalValue?: ComputeRolloutPlanWavesOrchestrationOptionsDelays[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRolloutPlanWavesOrchestrationOptionsDelaysOutputReference;
}
export interface ComputeRolloutPlanWavesOrchestrationOptions {
    /**
    * Maximum number of locations to be orchestrated in parallel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#max_concurrent_locations ComputeRolloutPlan#max_concurrent_locations}
    */
    readonly maxConcurrentLocations?: number;
    /**
    * Maximum number of resources to be orchestrated per location in parallel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#max_concurrent_resources_per_location ComputeRolloutPlan#max_concurrent_resources_per_location}
    */
    readonly maxConcurrentResourcesPerLocation?: number;
    /**
    * delays block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#delays ComputeRolloutPlan#delays}
    */
    readonly delays?: ComputeRolloutPlanWavesOrchestrationOptionsDelays[] | cdktn.IResolvable;
}
export declare function computeRolloutPlanWavesOrchestrationOptionsToTerraform(struct?: ComputeRolloutPlanWavesOrchestrationOptionsOutputReference | ComputeRolloutPlanWavesOrchestrationOptions): any;
export declare function computeRolloutPlanWavesOrchestrationOptionsToHclTerraform(struct?: ComputeRolloutPlanWavesOrchestrationOptionsOutputReference | ComputeRolloutPlanWavesOrchestrationOptions): any;
export declare class ComputeRolloutPlanWavesOrchestrationOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRolloutPlanWavesOrchestrationOptions | undefined;
    set internalValue(value: ComputeRolloutPlanWavesOrchestrationOptions | undefined);
    private _maxConcurrentLocations?;
    get maxConcurrentLocations(): number;
    set maxConcurrentLocations(value: number);
    resetMaxConcurrentLocations(): void;
    get maxConcurrentLocationsInput(): number | undefined;
    private _maxConcurrentResourcesPerLocation?;
    get maxConcurrentResourcesPerLocation(): number;
    set maxConcurrentResourcesPerLocation(value: number);
    resetMaxConcurrentResourcesPerLocation(): void;
    get maxConcurrentResourcesPerLocationInput(): number | undefined;
    private _delays;
    get delays(): ComputeRolloutPlanWavesOrchestrationOptionsDelaysList;
    putDelays(value: ComputeRolloutPlanWavesOrchestrationOptionsDelays[] | cdktn.IResolvable): void;
    resetDelays(): void;
    get delaysInput(): cdktn.IResolvable | ComputeRolloutPlanWavesOrchestrationOptionsDelays[] | undefined;
}
export interface ComputeRolloutPlanWavesSelectorsLocationSelector {
    /**
    * Example: "us-central1-a"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#included_locations ComputeRolloutPlan#included_locations}
    */
    readonly includedLocations?: string[];
}
export declare function computeRolloutPlanWavesSelectorsLocationSelectorToTerraform(struct?: ComputeRolloutPlanWavesSelectorsLocationSelectorOutputReference | ComputeRolloutPlanWavesSelectorsLocationSelector): any;
export declare function computeRolloutPlanWavesSelectorsLocationSelectorToHclTerraform(struct?: ComputeRolloutPlanWavesSelectorsLocationSelectorOutputReference | ComputeRolloutPlanWavesSelectorsLocationSelector): any;
export declare class ComputeRolloutPlanWavesSelectorsLocationSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRolloutPlanWavesSelectorsLocationSelector | undefined;
    set internalValue(value: ComputeRolloutPlanWavesSelectorsLocationSelector | undefined);
    private _includedLocations?;
    get includedLocations(): string[];
    set includedLocations(value: string[]);
    resetIncludedLocations(): void;
    get includedLocationsInput(): string[] | undefined;
}
export interface ComputeRolloutPlanWavesSelectorsResourceHierarchySelector {
    /**
    * Format: "folders/{folder_id}"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#included_folders ComputeRolloutPlan#included_folders}
    */
    readonly includedFolders?: string[];
    /**
    * Format: "organizations/{organization_id}"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#included_organizations ComputeRolloutPlan#included_organizations}
    */
    readonly includedOrganizations?: string[];
    /**
    * Format: "projects/{project_id}"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#included_projects ComputeRolloutPlan#included_projects}
    */
    readonly includedProjects?: string[];
}
export declare function computeRolloutPlanWavesSelectorsResourceHierarchySelectorToTerraform(struct?: ComputeRolloutPlanWavesSelectorsResourceHierarchySelectorOutputReference | ComputeRolloutPlanWavesSelectorsResourceHierarchySelector): any;
export declare function computeRolloutPlanWavesSelectorsResourceHierarchySelectorToHclTerraform(struct?: ComputeRolloutPlanWavesSelectorsResourceHierarchySelectorOutputReference | ComputeRolloutPlanWavesSelectorsResourceHierarchySelector): any;
export declare class ComputeRolloutPlanWavesSelectorsResourceHierarchySelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRolloutPlanWavesSelectorsResourceHierarchySelector | undefined;
    set internalValue(value: ComputeRolloutPlanWavesSelectorsResourceHierarchySelector | undefined);
    private _includedFolders?;
    get includedFolders(): string[];
    set includedFolders(value: string[]);
    resetIncludedFolders(): void;
    get includedFoldersInput(): string[] | undefined;
    private _includedOrganizations?;
    get includedOrganizations(): string[];
    set includedOrganizations(value: string[]);
    resetIncludedOrganizations(): void;
    get includedOrganizationsInput(): string[] | undefined;
    private _includedProjects?;
    get includedProjects(): string[];
    set includedProjects(value: string[]);
    resetIncludedProjects(): void;
    get includedProjectsInput(): string[] | undefined;
}
export interface ComputeRolloutPlanWavesSelectors {
    /**
    * location_selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#location_selector ComputeRolloutPlan#location_selector}
    */
    readonly locationSelector?: ComputeRolloutPlanWavesSelectorsLocationSelector;
    /**
    * resource_hierarchy_selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#resource_hierarchy_selector ComputeRolloutPlan#resource_hierarchy_selector}
    */
    readonly resourceHierarchySelector?: ComputeRolloutPlanWavesSelectorsResourceHierarchySelector;
}
export declare function computeRolloutPlanWavesSelectorsToTerraform(struct?: ComputeRolloutPlanWavesSelectors | cdktn.IResolvable): any;
export declare function computeRolloutPlanWavesSelectorsToHclTerraform(struct?: ComputeRolloutPlanWavesSelectors | cdktn.IResolvable): any;
export declare class ComputeRolloutPlanWavesSelectorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRolloutPlanWavesSelectors | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRolloutPlanWavesSelectors | cdktn.IResolvable | undefined);
    private _locationSelector;
    get locationSelector(): ComputeRolloutPlanWavesSelectorsLocationSelectorOutputReference;
    putLocationSelector(value: ComputeRolloutPlanWavesSelectorsLocationSelector): void;
    resetLocationSelector(): void;
    get locationSelectorInput(): ComputeRolloutPlanWavesSelectorsLocationSelector | undefined;
    private _resourceHierarchySelector;
    get resourceHierarchySelector(): ComputeRolloutPlanWavesSelectorsResourceHierarchySelectorOutputReference;
    putResourceHierarchySelector(value: ComputeRolloutPlanWavesSelectorsResourceHierarchySelector): void;
    resetResourceHierarchySelector(): void;
    get resourceHierarchySelectorInput(): ComputeRolloutPlanWavesSelectorsResourceHierarchySelector | undefined;
}
export declare class ComputeRolloutPlanWavesSelectorsList extends cdktn.ComplexList {
    internalValue?: ComputeRolloutPlanWavesSelectors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRolloutPlanWavesSelectorsOutputReference;
}
export interface ComputeRolloutPlanWavesValidationTimeBasedValidationMetadata {
    /**
    * The duration that the system waits in between waves. This wait starts
    * after all changes in the wave are rolled out.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#wait_duration ComputeRolloutPlan#wait_duration}
    */
    readonly waitDuration?: string;
}
export declare function computeRolloutPlanWavesValidationTimeBasedValidationMetadataToTerraform(struct?: ComputeRolloutPlanWavesValidationTimeBasedValidationMetadataOutputReference | ComputeRolloutPlanWavesValidationTimeBasedValidationMetadata): any;
export declare function computeRolloutPlanWavesValidationTimeBasedValidationMetadataToHclTerraform(struct?: ComputeRolloutPlanWavesValidationTimeBasedValidationMetadataOutputReference | ComputeRolloutPlanWavesValidationTimeBasedValidationMetadata): any;
export declare class ComputeRolloutPlanWavesValidationTimeBasedValidationMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRolloutPlanWavesValidationTimeBasedValidationMetadata | undefined;
    set internalValue(value: ComputeRolloutPlanWavesValidationTimeBasedValidationMetadata | undefined);
    private _waitDuration?;
    get waitDuration(): string;
    set waitDuration(value: string);
    resetWaitDuration(): void;
    get waitDurationInput(): string | undefined;
}
export interface ComputeRolloutPlanWavesValidation {
    /**
    * The type of the validation. Possible values:
    * "manual": The system waits for an end-user approval API before progressing to the next wave.
    * "time": The system waits for a user specified duration before progressing to the next wave.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#type ComputeRolloutPlan#type}
    */
    readonly type: string;
    /**
    * time_based_validation_metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#time_based_validation_metadata ComputeRolloutPlan#time_based_validation_metadata}
    */
    readonly timeBasedValidationMetadata?: ComputeRolloutPlanWavesValidationTimeBasedValidationMetadata;
}
export declare function computeRolloutPlanWavesValidationToTerraform(struct?: ComputeRolloutPlanWavesValidationOutputReference | ComputeRolloutPlanWavesValidation): any;
export declare function computeRolloutPlanWavesValidationToHclTerraform(struct?: ComputeRolloutPlanWavesValidationOutputReference | ComputeRolloutPlanWavesValidation): any;
export declare class ComputeRolloutPlanWavesValidationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRolloutPlanWavesValidation | undefined;
    set internalValue(value: ComputeRolloutPlanWavesValidation | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _timeBasedValidationMetadata;
    get timeBasedValidationMetadata(): ComputeRolloutPlanWavesValidationTimeBasedValidationMetadataOutputReference;
    putTimeBasedValidationMetadata(value: ComputeRolloutPlanWavesValidationTimeBasedValidationMetadata): void;
    resetTimeBasedValidationMetadata(): void;
    get timeBasedValidationMetadataInput(): ComputeRolloutPlanWavesValidationTimeBasedValidationMetadata | undefined;
}
export interface ComputeRolloutPlanWaves {
    /**
    * The display name of this wave of the rollout plan.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#display_name ComputeRolloutPlan#display_name}
    */
    readonly displayName?: string;
    /**
    * orchestration_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#orchestration_options ComputeRolloutPlan#orchestration_options}
    */
    readonly orchestrationOptions?: ComputeRolloutPlanWavesOrchestrationOptions;
    /**
    * selectors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#selectors ComputeRolloutPlan#selectors}
    */
    readonly selectors: ComputeRolloutPlanWavesSelectors[] | cdktn.IResolvable;
    /**
    * validation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#validation ComputeRolloutPlan#validation}
    */
    readonly validation: ComputeRolloutPlanWavesValidation;
}
export declare function computeRolloutPlanWavesToTerraform(struct?: ComputeRolloutPlanWaves | cdktn.IResolvable): any;
export declare function computeRolloutPlanWavesToHclTerraform(struct?: ComputeRolloutPlanWaves | cdktn.IResolvable): any;
export declare class ComputeRolloutPlanWavesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRolloutPlanWaves | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRolloutPlanWaves | cdktn.IResolvable | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    get number(): number;
    private _orchestrationOptions;
    get orchestrationOptions(): ComputeRolloutPlanWavesOrchestrationOptionsOutputReference;
    putOrchestrationOptions(value: ComputeRolloutPlanWavesOrchestrationOptions): void;
    resetOrchestrationOptions(): void;
    get orchestrationOptionsInput(): ComputeRolloutPlanWavesOrchestrationOptions | undefined;
    private _selectors;
    get selectors(): ComputeRolloutPlanWavesSelectorsList;
    putSelectors(value: ComputeRolloutPlanWavesSelectors[] | cdktn.IResolvable): void;
    get selectorsInput(): cdktn.IResolvable | ComputeRolloutPlanWavesSelectors[] | undefined;
    private _validation;
    get validation(): ComputeRolloutPlanWavesValidationOutputReference;
    putValidation(value: ComputeRolloutPlanWavesValidation): void;
    get validationInput(): ComputeRolloutPlanWavesValidation | undefined;
}
export declare class ComputeRolloutPlanWavesList extends cdktn.ComplexList {
    internalValue?: ComputeRolloutPlanWaves[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRolloutPlanWavesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan google_compute_rollout_plan}
*/
export declare class ComputeRolloutPlan extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_rollout_plan";
    /**
    * Generates CDKTN code for importing a ComputeRolloutPlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeRolloutPlan to import
    * @param importFromId The id of the existing ComputeRolloutPlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeRolloutPlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_rollout_plan google_compute_rollout_plan} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeRolloutPlanConfig
    */
    constructor(scope: Construct, id: string, config: ComputeRolloutPlanConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _locationScope?;
    get locationScope(): string;
    set locationScope(value: string);
    resetLocationScope(): void;
    get locationScopeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get selfLink(): string;
    private _timeouts;
    get timeouts(): ComputeRolloutPlanTimeoutsOutputReference;
    putTimeouts(value: ComputeRolloutPlanTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeRolloutPlanTimeouts | undefined;
    private _waves;
    get waves(): ComputeRolloutPlanWavesList;
    putWaves(value: ComputeRolloutPlanWaves[] | cdktn.IResolvable): void;
    get wavesInput(): cdktn.IResolvable | ComputeRolloutPlanWaves[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
