/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BigqueryReservationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Maximum number of queries that are allowed to run concurrently in this reservation. This is a soft limit due to asynchronous nature of the system and various optimizations for small queries. Default value is 0 which means that concurrency will be automatically set based on the reservation size.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_reservation#concurrency BigqueryReservation#concurrency}
    */
    readonly concurrency?: number;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_reservation#deletion_policy BigqueryReservation#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The edition type. Valid values are STANDARD, ENTERPRISE, ENTERPRISE_PLUS
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_reservation#edition BigqueryReservation#edition}
    */
    readonly edition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_reservation#id BigqueryReservation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * If false, any query using this reservation will use idle slots from other reservations within
    * the same admin project. If true, a query using this reservation will execute with the slot
    * capacity specified above at most.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_reservation#ignore_idle_slots BigqueryReservation#ignore_idle_slots}
    */
    readonly ignoreIdleSlots?: boolean | cdktn.IResolvable;
    /**
    * The labels associated with this reservation. You can use these to
    * organize and group your reservations.
    *
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_reservation#labels BigqueryReservation#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The geographic location where the transfer config should reside.
    * Examples: US, EU, asia-northeast1. The default value is US.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_reservation#location BigqueryReservation#location}
    */
    readonly location?: string;
    /**
    * The name of the reservation. This field must only contain alphanumeric characters or dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_reservation#name BigqueryReservation#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_reservation#project BigqueryReservation#project}
    */
    readonly project?: string;
    /**
    * The reservation group that this reservation belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_reservation#reservation_group BigqueryReservation#reservation_group}
    */
    readonly reservationGroup?: string;
    /**
    * The current location of the reservation's secondary replica. This field is only set for
    * reservations using the managed disaster recovery feature. Users can set this in create
    * reservation calls to create a failover reservation or in update reservation calls to convert
    * a non-failover reservation to a failover reservation(or vice versa).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_reservation#secondary_location BigqueryReservation#secondary_location}
    */
    readonly secondaryLocation?: string;
    /**
    * Minimum slots available to this reservation. A slot is a unit of computational power in BigQuery, and serves as the
    * unit of parallelism. Queries using this reservation might use more slots during runtime if ignoreIdleSlots is set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_reservation#slot_capacity BigqueryReservation#slot_capacity}
    */
    readonly slotCapacity: number;
    /**
    * autoscale block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_reservation#autoscale BigqueryReservation#autoscale}
    */
    readonly autoscale?: BigqueryReservationAutoscale;
    /**
    * scheduling_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_reservation#scheduling_policy BigqueryReservation#scheduling_policy}
    */
    readonly schedulingPolicy?: BigqueryReservationSchedulingPolicy;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_reservation#timeouts BigqueryReservation#timeouts}
    */
    readonly timeouts?: BigqueryReservationTimeouts;
}
export interface BigqueryReservationReplicationStatusError {
}
export declare function bigqueryReservationReplicationStatusErrorToTerraform(struct?: BigqueryReservationReplicationStatusError): any;
export declare function bigqueryReservationReplicationStatusErrorToHclTerraform(struct?: BigqueryReservationReplicationStatusError): any;
export declare class BigqueryReservationReplicationStatusErrorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BigqueryReservationReplicationStatusError | undefined;
    set internalValue(value: BigqueryReservationReplicationStatusError | undefined);
    get code(): number;
    get message(): string;
}
export declare class BigqueryReservationReplicationStatusErrorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BigqueryReservationReplicationStatusErrorOutputReference;
}
export interface BigqueryReservationReplicationStatus {
}
export declare function bigqueryReservationReplicationStatusToTerraform(struct?: BigqueryReservationReplicationStatus): any;
export declare function bigqueryReservationReplicationStatusToHclTerraform(struct?: BigqueryReservationReplicationStatus): any;
export declare class BigqueryReservationReplicationStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BigqueryReservationReplicationStatus | undefined;
    set internalValue(value: BigqueryReservationReplicationStatus | undefined);
    private _error;
    get error(): BigqueryReservationReplicationStatusErrorList;
    get lastErrorTime(): string;
    get lastReplicationTime(): string;
}
export declare class BigqueryReservationReplicationStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BigqueryReservationReplicationStatusOutputReference;
}
export interface BigqueryReservationAutoscale {
    /**
    * Number of slots to be scaled when needed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_reservation#max_slots BigqueryReservation#max_slots}
    */
    readonly maxSlots?: number;
}
export declare function bigqueryReservationAutoscaleToTerraform(struct?: BigqueryReservationAutoscaleOutputReference | BigqueryReservationAutoscale): any;
export declare function bigqueryReservationAutoscaleToHclTerraform(struct?: BigqueryReservationAutoscaleOutputReference | BigqueryReservationAutoscale): any;
export declare class BigqueryReservationAutoscaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryReservationAutoscale | undefined;
    set internalValue(value: BigqueryReservationAutoscale | undefined);
    get currentSlots(): number;
    private _maxSlots?;
    get maxSlots(): number;
    set maxSlots(value: number);
    resetMaxSlots(): void;
    get maxSlotsInput(): number | undefined;
}
export interface BigqueryReservationSchedulingPolicy {
    /**
    * If present and > 0, the reservation will attempt to limit the concurrency
    * of jobs running for any particular project within it to the given value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_reservation#concurrency BigqueryReservation#concurrency}
    */
    readonly concurrency?: number;
    /**
    * If present and > 0, the reservation will attempt to limit the slot
    * consumption of queries running for any particular project within it to
    * the given value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_reservation#max_slots BigqueryReservation#max_slots}
    */
    readonly maxSlots?: number;
}
export declare function bigqueryReservationSchedulingPolicyToTerraform(struct?: BigqueryReservationSchedulingPolicyOutputReference | BigqueryReservationSchedulingPolicy): any;
export declare function bigqueryReservationSchedulingPolicyToHclTerraform(struct?: BigqueryReservationSchedulingPolicyOutputReference | BigqueryReservationSchedulingPolicy): any;
export declare class BigqueryReservationSchedulingPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryReservationSchedulingPolicy | undefined;
    set internalValue(value: BigqueryReservationSchedulingPolicy | undefined);
    private _concurrency?;
    get concurrency(): number;
    set concurrency(value: number);
    resetConcurrency(): void;
    get concurrencyInput(): number | undefined;
    private _maxSlots?;
    get maxSlots(): number;
    set maxSlots(value: number);
    resetMaxSlots(): void;
    get maxSlotsInput(): number | undefined;
}
export interface BigqueryReservationTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_reservation#create BigqueryReservation#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_reservation#delete BigqueryReservation#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_reservation#update BigqueryReservation#update}
    */
    readonly update?: string;
}
export declare function bigqueryReservationTimeoutsToTerraform(struct?: BigqueryReservationTimeouts | cdktn.IResolvable): any;
export declare function bigqueryReservationTimeoutsToHclTerraform(struct?: BigqueryReservationTimeouts | cdktn.IResolvable): any;
export declare class BigqueryReservationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryReservationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BigqueryReservationTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_reservation google_bigquery_reservation}
*/
export declare class BigqueryReservation extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_bigquery_reservation";
    /**
    * Generates CDKTN code for importing a BigqueryReservation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BigqueryReservation to import
    * @param importFromId The id of the existing BigqueryReservation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_reservation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BigqueryReservation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_reservation google_bigquery_reservation} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BigqueryReservationConfig
    */
    constructor(scope: Construct, id: string, config: BigqueryReservationConfig);
    private _concurrency?;
    get concurrency(): number;
    set concurrency(value: number);
    resetConcurrency(): void;
    get concurrencyInput(): number | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _edition?;
    get edition(): string;
    set edition(value: string);
    resetEdition(): void;
    get editionInput(): string | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ignoreIdleSlots?;
    get ignoreIdleSlots(): boolean | cdktn.IResolvable;
    set ignoreIdleSlots(value: boolean | cdktn.IResolvable);
    resetIgnoreIdleSlots(): void;
    get ignoreIdleSlotsInput(): boolean | cdktn.IResolvable | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get originalPrimaryLocation(): string;
    get primaryLocation(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _replicationStatus;
    get replicationStatus(): BigqueryReservationReplicationStatusList;
    private _reservationGroup?;
    get reservationGroup(): string;
    set reservationGroup(value: string);
    resetReservationGroup(): void;
    get reservationGroupInput(): string | undefined;
    private _secondaryLocation?;
    get secondaryLocation(): string;
    set secondaryLocation(value: string);
    resetSecondaryLocation(): void;
    get secondaryLocationInput(): string | undefined;
    private _slotCapacity?;
    get slotCapacity(): number;
    set slotCapacity(value: number);
    get slotCapacityInput(): number | undefined;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _autoscale;
    get autoscale(): BigqueryReservationAutoscaleOutputReference;
    putAutoscale(value: BigqueryReservationAutoscale): void;
    resetAutoscale(): void;
    get autoscaleInput(): BigqueryReservationAutoscale | undefined;
    private _schedulingPolicy;
    get schedulingPolicy(): BigqueryReservationSchedulingPolicyOutputReference;
    putSchedulingPolicy(value: BigqueryReservationSchedulingPolicy): void;
    resetSchedulingPolicy(): void;
    get schedulingPolicyInput(): BigqueryReservationSchedulingPolicy | undefined;
    private _timeouts;
    get timeouts(): BigqueryReservationTimeoutsOutputReference;
    putTimeouts(value: BigqueryReservationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BigqueryReservationTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
