/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigeeAddonsConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_addons_config#deletion_policy ApigeeAddonsConfig#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_addons_config#id ApigeeAddonsConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the Apigee organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_addons_config#org ApigeeAddonsConfig#org}
    */
    readonly org: string;
    /**
    * addons_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_addons_config#addons_config ApigeeAddonsConfig#addons_config}
    */
    readonly addonsConfig?: ApigeeAddonsConfigAddonsConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_addons_config#timeouts ApigeeAddonsConfig#timeouts}
    */
    readonly timeouts?: ApigeeAddonsConfigTimeouts;
}
export interface ApigeeAddonsConfigAddonsConfigAdvancedApiOpsConfig {
    /**
    * Flag that specifies whether the Advanced API Ops add-on is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_addons_config#enabled ApigeeAddonsConfig#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function apigeeAddonsConfigAddonsConfigAdvancedApiOpsConfigToTerraform(struct?: ApigeeAddonsConfigAddonsConfigAdvancedApiOpsConfigOutputReference | ApigeeAddonsConfigAddonsConfigAdvancedApiOpsConfig): any;
export declare function apigeeAddonsConfigAddonsConfigAdvancedApiOpsConfigToHclTerraform(struct?: ApigeeAddonsConfigAddonsConfigAdvancedApiOpsConfigOutputReference | ApigeeAddonsConfigAddonsConfigAdvancedApiOpsConfig): any;
export declare class ApigeeAddonsConfigAddonsConfigAdvancedApiOpsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeAddonsConfigAddonsConfigAdvancedApiOpsConfig | undefined;
    set internalValue(value: ApigeeAddonsConfigAddonsConfigAdvancedApiOpsConfig | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ApigeeAddonsConfigAddonsConfigApiSecurityConfig {
    /**
    * Flag that specifies whether the API security add-on is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_addons_config#enabled ApigeeAddonsConfig#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function apigeeAddonsConfigAddonsConfigApiSecurityConfigToTerraform(struct?: ApigeeAddonsConfigAddonsConfigApiSecurityConfigOutputReference | ApigeeAddonsConfigAddonsConfigApiSecurityConfig): any;
export declare function apigeeAddonsConfigAddonsConfigApiSecurityConfigToHclTerraform(struct?: ApigeeAddonsConfigAddonsConfigApiSecurityConfigOutputReference | ApigeeAddonsConfigAddonsConfigApiSecurityConfig): any;
export declare class ApigeeAddonsConfigAddonsConfigApiSecurityConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeAddonsConfigAddonsConfigApiSecurityConfig | undefined;
    set internalValue(value: ApigeeAddonsConfigAddonsConfigApiSecurityConfig | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get expiresAt(): string;
}
export interface ApigeeAddonsConfigAddonsConfigConnectorsPlatformConfig {
    /**
    * Flag that specifies whether the Connectors Platform add-on is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_addons_config#enabled ApigeeAddonsConfig#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function apigeeAddonsConfigAddonsConfigConnectorsPlatformConfigToTerraform(struct?: ApigeeAddonsConfigAddonsConfigConnectorsPlatformConfigOutputReference | ApigeeAddonsConfigAddonsConfigConnectorsPlatformConfig): any;
export declare function apigeeAddonsConfigAddonsConfigConnectorsPlatformConfigToHclTerraform(struct?: ApigeeAddonsConfigAddonsConfigConnectorsPlatformConfigOutputReference | ApigeeAddonsConfigAddonsConfigConnectorsPlatformConfig): any;
export declare class ApigeeAddonsConfigAddonsConfigConnectorsPlatformConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeAddonsConfigAddonsConfigConnectorsPlatformConfig | undefined;
    set internalValue(value: ApigeeAddonsConfigAddonsConfigConnectorsPlatformConfig | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get expiresAt(): string;
}
export interface ApigeeAddonsConfigAddonsConfigIntegrationConfig {
    /**
    * Flag that specifies whether the Integration add-on is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_addons_config#enabled ApigeeAddonsConfig#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function apigeeAddonsConfigAddonsConfigIntegrationConfigToTerraform(struct?: ApigeeAddonsConfigAddonsConfigIntegrationConfigOutputReference | ApigeeAddonsConfigAddonsConfigIntegrationConfig): any;
export declare function apigeeAddonsConfigAddonsConfigIntegrationConfigToHclTerraform(struct?: ApigeeAddonsConfigAddonsConfigIntegrationConfigOutputReference | ApigeeAddonsConfigAddonsConfigIntegrationConfig): any;
export declare class ApigeeAddonsConfigAddonsConfigIntegrationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeAddonsConfigAddonsConfigIntegrationConfig | undefined;
    set internalValue(value: ApigeeAddonsConfigAddonsConfigIntegrationConfig | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ApigeeAddonsConfigAddonsConfigMonetizationConfig {
    /**
    * Flag that specifies whether the Monetization add-on is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_addons_config#enabled ApigeeAddonsConfig#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function apigeeAddonsConfigAddonsConfigMonetizationConfigToTerraform(struct?: ApigeeAddonsConfigAddonsConfigMonetizationConfigOutputReference | ApigeeAddonsConfigAddonsConfigMonetizationConfig): any;
export declare function apigeeAddonsConfigAddonsConfigMonetizationConfigToHclTerraform(struct?: ApigeeAddonsConfigAddonsConfigMonetizationConfigOutputReference | ApigeeAddonsConfigAddonsConfigMonetizationConfig): any;
export declare class ApigeeAddonsConfigAddonsConfigMonetizationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeAddonsConfigAddonsConfigMonetizationConfig | undefined;
    set internalValue(value: ApigeeAddonsConfigAddonsConfigMonetizationConfig | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ApigeeAddonsConfigAddonsConfig {
    /**
    * advanced_api_ops_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_addons_config#advanced_api_ops_config ApigeeAddonsConfig#advanced_api_ops_config}
    */
    readonly advancedApiOpsConfig?: ApigeeAddonsConfigAddonsConfigAdvancedApiOpsConfig;
    /**
    * api_security_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_addons_config#api_security_config ApigeeAddonsConfig#api_security_config}
    */
    readonly apiSecurityConfig?: ApigeeAddonsConfigAddonsConfigApiSecurityConfig;
    /**
    * connectors_platform_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_addons_config#connectors_platform_config ApigeeAddonsConfig#connectors_platform_config}
    */
    readonly connectorsPlatformConfig?: ApigeeAddonsConfigAddonsConfigConnectorsPlatformConfig;
    /**
    * integration_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_addons_config#integration_config ApigeeAddonsConfig#integration_config}
    */
    readonly integrationConfig?: ApigeeAddonsConfigAddonsConfigIntegrationConfig;
    /**
    * monetization_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_addons_config#monetization_config ApigeeAddonsConfig#monetization_config}
    */
    readonly monetizationConfig?: ApigeeAddonsConfigAddonsConfigMonetizationConfig;
}
export declare function apigeeAddonsConfigAddonsConfigToTerraform(struct?: ApigeeAddonsConfigAddonsConfigOutputReference | ApigeeAddonsConfigAddonsConfig): any;
export declare function apigeeAddonsConfigAddonsConfigToHclTerraform(struct?: ApigeeAddonsConfigAddonsConfigOutputReference | ApigeeAddonsConfigAddonsConfig): any;
export declare class ApigeeAddonsConfigAddonsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeAddonsConfigAddonsConfig | undefined;
    set internalValue(value: ApigeeAddonsConfigAddonsConfig | undefined);
    private _advancedApiOpsConfig;
    get advancedApiOpsConfig(): ApigeeAddonsConfigAddonsConfigAdvancedApiOpsConfigOutputReference;
    putAdvancedApiOpsConfig(value: ApigeeAddonsConfigAddonsConfigAdvancedApiOpsConfig): void;
    resetAdvancedApiOpsConfig(): void;
    get advancedApiOpsConfigInput(): ApigeeAddonsConfigAddonsConfigAdvancedApiOpsConfig | undefined;
    private _apiSecurityConfig;
    get apiSecurityConfig(): ApigeeAddonsConfigAddonsConfigApiSecurityConfigOutputReference;
    putApiSecurityConfig(value: ApigeeAddonsConfigAddonsConfigApiSecurityConfig): void;
    resetApiSecurityConfig(): void;
    get apiSecurityConfigInput(): ApigeeAddonsConfigAddonsConfigApiSecurityConfig | undefined;
    private _connectorsPlatformConfig;
    get connectorsPlatformConfig(): ApigeeAddonsConfigAddonsConfigConnectorsPlatformConfigOutputReference;
    putConnectorsPlatformConfig(value: ApigeeAddonsConfigAddonsConfigConnectorsPlatformConfig): void;
    resetConnectorsPlatformConfig(): void;
    get connectorsPlatformConfigInput(): ApigeeAddonsConfigAddonsConfigConnectorsPlatformConfig | undefined;
    private _integrationConfig;
    get integrationConfig(): ApigeeAddonsConfigAddonsConfigIntegrationConfigOutputReference;
    putIntegrationConfig(value: ApigeeAddonsConfigAddonsConfigIntegrationConfig): void;
    resetIntegrationConfig(): void;
    get integrationConfigInput(): ApigeeAddonsConfigAddonsConfigIntegrationConfig | undefined;
    private _monetizationConfig;
    get monetizationConfig(): ApigeeAddonsConfigAddonsConfigMonetizationConfigOutputReference;
    putMonetizationConfig(value: ApigeeAddonsConfigAddonsConfigMonetizationConfig): void;
    resetMonetizationConfig(): void;
    get monetizationConfigInput(): ApigeeAddonsConfigAddonsConfigMonetizationConfig | undefined;
}
export interface ApigeeAddonsConfigTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_addons_config#create ApigeeAddonsConfig#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_addons_config#delete ApigeeAddonsConfig#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_addons_config#update ApigeeAddonsConfig#update}
    */
    readonly update?: string;
}
export declare function apigeeAddonsConfigTimeoutsToTerraform(struct?: ApigeeAddonsConfigTimeouts | cdktn.IResolvable): any;
export declare function apigeeAddonsConfigTimeoutsToHclTerraform(struct?: ApigeeAddonsConfigTimeouts | cdktn.IResolvable): any;
export declare class ApigeeAddonsConfigTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeAddonsConfigTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeAddonsConfigTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_addons_config google_apigee_addons_config}
*/
export declare class ApigeeAddonsConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apigee_addons_config";
    /**
    * Generates CDKTN code for importing a ApigeeAddonsConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigeeAddonsConfig to import
    * @param importFromId The id of the existing ApigeeAddonsConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_addons_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigeeAddonsConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_addons_config google_apigee_addons_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigeeAddonsConfigConfig
    */
    constructor(scope: Construct, id: string, config: ApigeeAddonsConfigConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _org?;
    get org(): string;
    set org(value: string);
    get orgInput(): string | undefined;
    private _addonsConfig;
    get addonsConfig(): ApigeeAddonsConfigAddonsConfigOutputReference;
    putAddonsConfig(value: ApigeeAddonsConfigAddonsConfig): void;
    resetAddonsConfig(): void;
    get addonsConfigInput(): ApigeeAddonsConfigAddonsConfig | undefined;
    private _timeouts;
    get timeouts(): ApigeeAddonsConfigTimeoutsOutputReference;
    putTimeouts(value: ApigeeAddonsConfigTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApigeeAddonsConfigTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
