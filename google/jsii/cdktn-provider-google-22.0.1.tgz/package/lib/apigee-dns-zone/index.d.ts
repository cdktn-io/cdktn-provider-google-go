/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigeeDnsZoneConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_dns_zone#deletion_policy ApigeeDnsZone#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Description for the zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_dns_zone#description ApigeeDnsZone#description}
    */
    readonly description: string;
    /**
    * ID of the dns zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_dns_zone#dns_zone_id ApigeeDnsZone#dns_zone_id}
    */
    readonly dnsZoneId: string;
    /**
    * Doamin for the zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_dns_zone#domain ApigeeDnsZone#domain}
    */
    readonly domain: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_dns_zone#id ApigeeDnsZone#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The Apigee Organization associated with the Apigee instance,
    * in the format 'organizations/{{org_name}}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_dns_zone#org_id ApigeeDnsZone#org_id}
    */
    readonly orgId: string;
    /**
    * peering_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_dns_zone#peering_config ApigeeDnsZone#peering_config}
    */
    readonly peeringConfig: ApigeeDnsZonePeeringConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_dns_zone#timeouts ApigeeDnsZone#timeouts}
    */
    readonly timeouts?: ApigeeDnsZoneTimeouts;
}
export interface ApigeeDnsZonePeeringConfig {
    /**
    * The name of the producer VPC network.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_dns_zone#target_network_id ApigeeDnsZone#target_network_id}
    */
    readonly targetNetworkId: string;
    /**
    * The ID of the project that contains the producer VPC network.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_dns_zone#target_project_id ApigeeDnsZone#target_project_id}
    */
    readonly targetProjectId: string;
}
export declare function apigeeDnsZonePeeringConfigToTerraform(struct?: ApigeeDnsZonePeeringConfigOutputReference | ApigeeDnsZonePeeringConfig): any;
export declare function apigeeDnsZonePeeringConfigToHclTerraform(struct?: ApigeeDnsZonePeeringConfigOutputReference | ApigeeDnsZonePeeringConfig): any;
export declare class ApigeeDnsZonePeeringConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeDnsZonePeeringConfig | undefined;
    set internalValue(value: ApigeeDnsZonePeeringConfig | undefined);
    private _targetNetworkId?;
    get targetNetworkId(): string;
    set targetNetworkId(value: string);
    get targetNetworkIdInput(): string | undefined;
    private _targetProjectId?;
    get targetProjectId(): string;
    set targetProjectId(value: string);
    get targetProjectIdInput(): string | undefined;
}
export interface ApigeeDnsZoneTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_dns_zone#create ApigeeDnsZone#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_dns_zone#delete ApigeeDnsZone#delete}
    */
    readonly delete?: string;
}
export declare function apigeeDnsZoneTimeoutsToTerraform(struct?: ApigeeDnsZoneTimeouts | cdktn.IResolvable): any;
export declare function apigeeDnsZoneTimeoutsToHclTerraform(struct?: ApigeeDnsZoneTimeouts | cdktn.IResolvable): any;
export declare class ApigeeDnsZoneTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeDnsZoneTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeDnsZoneTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_dns_zone google_apigee_dns_zone}
*/
export declare class ApigeeDnsZone extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apigee_dns_zone";
    /**
    * Generates CDKTN code for importing a ApigeeDnsZone resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigeeDnsZone to import
    * @param importFromId The id of the existing ApigeeDnsZone that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_dns_zone#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigeeDnsZone to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apigee_dns_zone google_apigee_dns_zone} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigeeDnsZoneConfig
    */
    constructor(scope: Construct, id: string, config: ApigeeDnsZoneConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _dnsZoneId?;
    get dnsZoneId(): string;
    set dnsZoneId(value: string);
    get dnsZoneIdInput(): string | undefined;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    get domainInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _orgId?;
    get orgId(): string;
    set orgId(value: string);
    get orgIdInput(): string | undefined;
    private _peeringConfig;
    get peeringConfig(): ApigeeDnsZonePeeringConfigOutputReference;
    putPeeringConfig(value: ApigeeDnsZonePeeringConfig): void;
    get peeringConfigInput(): ApigeeDnsZonePeeringConfig | undefined;
    private _timeouts;
    get timeouts(): ApigeeDnsZoneTimeoutsOutputReference;
    putTimeouts(value: ApigeeDnsZoneTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApigeeDnsZoneTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
