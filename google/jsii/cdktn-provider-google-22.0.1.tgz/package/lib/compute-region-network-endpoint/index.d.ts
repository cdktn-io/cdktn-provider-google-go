/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeRegionNetworkEndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Client destination port for the 'GCE_VM_IP_PORTMAP' NEG.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_network_endpoint#client_destination_port ComputeRegionNetworkEndpoint#client_destination_port}
    */
    readonly clientDestinationPort?: number;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_network_endpoint#deletion_policy ComputeRegionNetworkEndpoint#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Fully qualified domain name of network endpoint.
    *
    * This can only be specified when network_endpoint_type of the NEG is INTERNET_FQDN_PORT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_network_endpoint#fqdn ComputeRegionNetworkEndpoint#fqdn}
    */
    readonly fqdn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_network_endpoint#id ComputeRegionNetworkEndpoint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name for a specific VM instance that the IP address belongs to.
    * This is required for network endpoints of type GCE_VM_IP_PORTMAP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_network_endpoint#instance ComputeRegionNetworkEndpoint#instance}
    */
    readonly instance?: string;
    /**
    * IPv4 address external endpoint.
    *
    * This can only be specified when network_endpoint_type of the NEG is INTERNET_IP_PORT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_network_endpoint#ip_address ComputeRegionNetworkEndpoint#ip_address}
    */
    readonly ipAddress?: string;
    /**
    * Port number of network endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_network_endpoint#port ComputeRegionNetworkEndpoint#port}
    */
    readonly port: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_network_endpoint#project ComputeRegionNetworkEndpoint#project}
    */
    readonly project?: string;
    /**
    * Region where the containing network endpoint group is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_network_endpoint#region ComputeRegionNetworkEndpoint#region}
    */
    readonly region?: string;
    /**
    * The network endpoint group this endpoint is part of.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_network_endpoint#region_network_endpoint_group ComputeRegionNetworkEndpoint#region_network_endpoint_group}
    */
    readonly regionNetworkEndpointGroup: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_network_endpoint#timeouts ComputeRegionNetworkEndpoint#timeouts}
    */
    readonly timeouts?: ComputeRegionNetworkEndpointTimeouts;
}
export interface ComputeRegionNetworkEndpointTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_network_endpoint#create ComputeRegionNetworkEndpoint#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_network_endpoint#delete ComputeRegionNetworkEndpoint#delete}
    */
    readonly delete?: string;
}
export declare function computeRegionNetworkEndpointTimeoutsToTerraform(struct?: ComputeRegionNetworkEndpointTimeouts | cdktn.IResolvable): any;
export declare function computeRegionNetworkEndpointTimeoutsToHclTerraform(struct?: ComputeRegionNetworkEndpointTimeouts | cdktn.IResolvable): any;
export declare class ComputeRegionNetworkEndpointTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionNetworkEndpointTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionNetworkEndpointTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_network_endpoint google_compute_region_network_endpoint}
*/
export declare class ComputeRegionNetworkEndpoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_region_network_endpoint";
    /**
    * Generates CDKTN code for importing a ComputeRegionNetworkEndpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeRegionNetworkEndpoint to import
    * @param importFromId The id of the existing ComputeRegionNetworkEndpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_network_endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeRegionNetworkEndpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_network_endpoint google_compute_region_network_endpoint} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeRegionNetworkEndpointConfig
    */
    constructor(scope: Construct, id: string, config: ComputeRegionNetworkEndpointConfig);
    private _clientDestinationPort?;
    get clientDestinationPort(): number;
    set clientDestinationPort(value: number);
    resetClientDestinationPort(): void;
    get clientDestinationPortInput(): number | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _fqdn?;
    get fqdn(): string;
    set fqdn(value: string);
    resetFqdn(): void;
    get fqdnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instance?;
    get instance(): string;
    set instance(value: string);
    resetInstance(): void;
    get instanceInput(): string | undefined;
    private _ipAddress?;
    get ipAddress(): string;
    set ipAddress(value: string);
    resetIpAddress(): void;
    get ipAddressInput(): string | undefined;
    get networkEndpointId(): number;
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _regionNetworkEndpointGroup?;
    get regionNetworkEndpointGroup(): string;
    set regionNetworkEndpointGroup(value: string);
    get regionNetworkEndpointGroupInput(): string | undefined;
    private _timeouts;
    get timeouts(): ComputeRegionNetworkEndpointTimeoutsOutputReference;
    putTimeouts(value: ComputeRegionNetworkEndpointTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeRegionNetworkEndpointTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
