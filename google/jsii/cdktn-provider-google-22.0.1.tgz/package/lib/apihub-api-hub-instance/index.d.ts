/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApihubApiHubInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Optional. Identifier to assign to the Api Hub instance. Must be unique within
    * scope of the parent resource. If the field is not provided,
    * system generated id will be used.
    *
    * This value should be 4-40 characters, and valid characters
    * are '/a-z[0-9]-_/'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_api_hub_instance#api_hub_instance_id ApihubApiHubInstance#api_hub_instance_id}
    */
    readonly apiHubInstanceId?: string;
    /**
    * Optional. Description of the ApiHub instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_api_hub_instance#description ApihubApiHubInstance#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_api_hub_instance#id ApihubApiHubInstance#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Optional. Instance labels to represent user-provided metadata.
    * Refer to cloud documentation on labels for more details.
    * https://cloud.google.com/compute/docs/labeling-resources
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_api_hub_instance#labels ApihubApiHubInstance#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_api_hub_instance#location ApihubApiHubInstance#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_api_hub_instance#project ApihubApiHubInstance#project}
    */
    readonly project?: string;
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_api_hub_instance#config ApihubApiHubInstance#config}
    */
    readonly config: ApihubApiHubInstanceConfigA;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_api_hub_instance#timeouts ApihubApiHubInstance#timeouts}
    */
    readonly timeouts?: ApihubApiHubInstanceTimeouts;
}
export interface ApihubApiHubInstanceConfigA {
    /**
    * Optional. The Customer Managed Encryption Key (CMEK) used for data encryption.
    * The CMEK name should follow the format of
    * 'projects/([^/]+)/locations/([^/]+)/keyRings/([^/]+)/cryptoKeys/([^/]+)',
    * where the location must match the instance location.
    * If the CMEK is not provided, a GMEK will be created for the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_api_hub_instance#cmek_key_name ApihubApiHubInstance#cmek_key_name}
    */
    readonly cmekKeyName?: string;
    /**
    * Optional. If true, the search will be disabled for the instance. The default value
    * is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_api_hub_instance#disable_search ApihubApiHubInstance#disable_search}
    */
    readonly disableSearch?: boolean | cdktn.IResolvable;
    /**
    * Optional. Encryption type for the region. If the encryption type is CMEK, the
    * cmek_key_name must be provided. If no encryption type is provided,
    * GMEK will be used.
    * Possible values:
    * ENCRYPTION_TYPE_UNSPECIFIED
    * GMEK
    * CMEK
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_api_hub_instance#encryption_type ApihubApiHubInstance#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Optional. The name of the Vertex AI location where the data store is stored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_api_hub_instance#vertex_location ApihubApiHubInstance#vertex_location}
    */
    readonly vertexLocation?: string;
}
export declare function apihubApiHubInstanceConfigAToTerraform(struct?: ApihubApiHubInstanceConfigAOutputReference | ApihubApiHubInstanceConfigA): any;
export declare function apihubApiHubInstanceConfigAToHclTerraform(struct?: ApihubApiHubInstanceConfigAOutputReference | ApihubApiHubInstanceConfigA): any;
export declare class ApihubApiHubInstanceConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApihubApiHubInstanceConfigA | undefined;
    set internalValue(value: ApihubApiHubInstanceConfigA | undefined);
    private _cmekKeyName?;
    get cmekKeyName(): string;
    set cmekKeyName(value: string);
    resetCmekKeyName(): void;
    get cmekKeyNameInput(): string | undefined;
    private _disableSearch?;
    get disableSearch(): boolean | cdktn.IResolvable;
    set disableSearch(value: boolean | cdktn.IResolvable);
    resetDisableSearch(): void;
    get disableSearchInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _vertexLocation?;
    get vertexLocation(): string;
    set vertexLocation(value: string);
    resetVertexLocation(): void;
    get vertexLocationInput(): string | undefined;
}
export interface ApihubApiHubInstanceTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_api_hub_instance#create ApihubApiHubInstance#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_api_hub_instance#delete ApihubApiHubInstance#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_api_hub_instance#update ApihubApiHubInstance#update}
    */
    readonly update?: string;
}
export declare function apihubApiHubInstanceTimeoutsToTerraform(struct?: ApihubApiHubInstanceTimeouts | cdktn.IResolvable): any;
export declare function apihubApiHubInstanceTimeoutsToHclTerraform(struct?: ApihubApiHubInstanceTimeouts | cdktn.IResolvable): any;
export declare class ApihubApiHubInstanceTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApihubApiHubInstanceTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApihubApiHubInstanceTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_api_hub_instance google_apihub_api_hub_instance}
*/
export declare class ApihubApiHubInstance extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apihub_api_hub_instance";
    /**
    * Generates CDKTN code for importing a ApihubApiHubInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApihubApiHubInstance to import
    * @param importFromId The id of the existing ApihubApiHubInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_api_hub_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApihubApiHubInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/apihub_api_hub_instance google_apihub_api_hub_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApihubApiHubInstanceConfig
    */
    constructor(scope: Construct, id: string, config: ApihubApiHubInstanceConfig);
    private _apiHubInstanceId?;
    get apiHubInstanceId(): string;
    set apiHubInstanceId(value: string);
    resetApiHubInstanceId(): void;
    get apiHubInstanceIdInput(): string | undefined;
    get createTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get state(): string;
    get stateMessage(): string;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get updateTime(): string;
    private _config;
    get config(): ApihubApiHubInstanceConfigAOutputReference;
    putConfig(value: ApihubApiHubInstanceConfigA): void;
    get configInput(): ApihubApiHubInstanceConfigA | undefined;
    private _timeouts;
    get timeouts(): ApihubApiHubInstanceTimeoutsOutputReference;
    putTimeouts(value: ApihubApiHubInstanceTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApihubApiHubInstanceTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
