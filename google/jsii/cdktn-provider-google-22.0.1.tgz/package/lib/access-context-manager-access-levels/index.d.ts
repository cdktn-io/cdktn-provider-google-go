/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccessContextManagerAccessLevelsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#deletion_policy AccessContextManagerAccessLevels#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#id AccessContextManagerAccessLevels#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The AccessPolicy this AccessLevel lives in.
    * Format: accessPolicies/{policy_id}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#parent AccessContextManagerAccessLevels#parent}
    */
    readonly parent: string;
    /**
    * access_levels block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#access_levels AccessContextManagerAccessLevels#access_levels}
    */
    readonly accessLevels?: AccessContextManagerAccessLevelsAccessLevels[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#timeouts AccessContextManagerAccessLevels#timeouts}
    */
    readonly timeouts?: AccessContextManagerAccessLevelsTimeouts;
}
export interface AccessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicyOsConstraints {
    /**
    * The minimum allowed OS version. If not set, any version
    * of this OS satisfies the constraint.
    * Format: "major.minor.patch" such as "10.5.301", "9.2.1".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#minimum_version AccessContextManagerAccessLevels#minimum_version}
    */
    readonly minimumVersion?: string;
    /**
    * The operating system type of the device. Possible values: ["OS_UNSPECIFIED", "DESKTOP_MAC", "DESKTOP_WINDOWS", "DESKTOP_LINUX", "DESKTOP_CHROME_OS", "ANDROID", "IOS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#os_type AccessContextManagerAccessLevels#os_type}
    */
    readonly osType: string;
}
export declare function accessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicyOsConstraintsToTerraform(struct?: AccessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicyOsConstraints | cdktn.IResolvable): any;
export declare function accessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicyOsConstraintsToHclTerraform(struct?: AccessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicyOsConstraints | cdktn.IResolvable): any;
export declare class AccessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicyOsConstraintsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicyOsConstraints | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicyOsConstraints | cdktn.IResolvable | undefined);
    private _minimumVersion?;
    get minimumVersion(): string;
    set minimumVersion(value: string);
    resetMinimumVersion(): void;
    get minimumVersionInput(): string | undefined;
    private _osType?;
    get osType(): string;
    set osType(value: string);
    get osTypeInput(): string | undefined;
}
export declare class AccessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicyOsConstraintsList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicyOsConstraints[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicyOsConstraintsOutputReference;
}
export interface AccessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicy {
    /**
    * A list of allowed device management levels.
    * An empty list allows all management levels. Possible values: ["MANAGEMENT_UNSPECIFIED", "NONE", "BASIC", "COMPLETE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#allowed_device_management_levels AccessContextManagerAccessLevels#allowed_device_management_levels}
    */
    readonly allowedDeviceManagementLevels?: string[];
    /**
    * A list of allowed encryptions statuses.
    * An empty list allows all statuses. Possible values: ["ENCRYPTION_UNSPECIFIED", "ENCRYPTION_UNSUPPORTED", "UNENCRYPTED", "ENCRYPTED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#allowed_encryption_statuses AccessContextManagerAccessLevels#allowed_encryption_statuses}
    */
    readonly allowedEncryptionStatuses?: string[];
    /**
    * Whether the device needs to be approved by the customer admin.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#require_admin_approval AccessContextManagerAccessLevels#require_admin_approval}
    */
    readonly requireAdminApproval?: boolean | cdktn.IResolvable;
    /**
    * Whether the device needs to be corp owned.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#require_corp_owned AccessContextManagerAccessLevels#require_corp_owned}
    */
    readonly requireCorpOwned?: boolean | cdktn.IResolvable;
    /**
    * Whether or not screenlock is required for the DevicePolicy
    * to be true. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#require_screen_lock AccessContextManagerAccessLevels#require_screen_lock}
    */
    readonly requireScreenLock?: boolean | cdktn.IResolvable;
    /**
    * os_constraints block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#os_constraints AccessContextManagerAccessLevels#os_constraints}
    */
    readonly osConstraints?: AccessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicyOsConstraints[] | cdktn.IResolvable;
}
export declare function accessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicyToTerraform(struct?: AccessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicyOutputReference | AccessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicy): any;
export declare function accessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicyToHclTerraform(struct?: AccessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicyOutputReference | AccessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicy): any;
export declare class AccessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicy | undefined;
    set internalValue(value: AccessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicy | undefined);
    private _allowedDeviceManagementLevels?;
    get allowedDeviceManagementLevels(): string[];
    set allowedDeviceManagementLevels(value: string[]);
    resetAllowedDeviceManagementLevels(): void;
    get allowedDeviceManagementLevelsInput(): string[] | undefined;
    private _allowedEncryptionStatuses?;
    get allowedEncryptionStatuses(): string[];
    set allowedEncryptionStatuses(value: string[]);
    resetAllowedEncryptionStatuses(): void;
    get allowedEncryptionStatusesInput(): string[] | undefined;
    private _requireAdminApproval?;
    get requireAdminApproval(): boolean | cdktn.IResolvable;
    set requireAdminApproval(value: boolean | cdktn.IResolvable);
    resetRequireAdminApproval(): void;
    get requireAdminApprovalInput(): boolean | cdktn.IResolvable | undefined;
    private _requireCorpOwned?;
    get requireCorpOwned(): boolean | cdktn.IResolvable;
    set requireCorpOwned(value: boolean | cdktn.IResolvable);
    resetRequireCorpOwned(): void;
    get requireCorpOwnedInput(): boolean | cdktn.IResolvable | undefined;
    private _requireScreenLock?;
    get requireScreenLock(): boolean | cdktn.IResolvable;
    set requireScreenLock(value: boolean | cdktn.IResolvable);
    resetRequireScreenLock(): void;
    get requireScreenLockInput(): boolean | cdktn.IResolvable | undefined;
    private _osConstraints;
    get osConstraints(): AccessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicyOsConstraintsList;
    putOsConstraints(value: AccessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicyOsConstraints[] | cdktn.IResolvable): void;
    resetOsConstraints(): void;
    get osConstraintsInput(): cdktn.IResolvable | AccessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicyOsConstraints[] | undefined;
}
export interface AccessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSourcesVpcSubnetwork {
    /**
    * Required. Network name to be allowed by this Access Level. Networks of foreign organizations requires 'compute.network.get' permission to be granted to caller.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#network AccessContextManagerAccessLevels#network}
    */
    readonly network: string;
    /**
    * CIDR block IP subnetwork specification. Must be IPv4.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#vpc_ip_subnetworks AccessContextManagerAccessLevels#vpc_ip_subnetworks}
    */
    readonly vpcIpSubnetworks?: string[];
}
export declare function accessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSourcesVpcSubnetworkToTerraform(struct?: AccessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSourcesVpcSubnetworkOutputReference | AccessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSourcesVpcSubnetwork): any;
export declare function accessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSourcesVpcSubnetworkToHclTerraform(struct?: AccessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSourcesVpcSubnetworkOutputReference | AccessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSourcesVpcSubnetwork): any;
export declare class AccessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSourcesVpcSubnetworkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSourcesVpcSubnetwork | undefined;
    set internalValue(value: AccessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSourcesVpcSubnetwork | undefined);
    private _network?;
    get network(): string;
    set network(value: string);
    get networkInput(): string | undefined;
    private _vpcIpSubnetworks?;
    get vpcIpSubnetworks(): string[];
    set vpcIpSubnetworks(value: string[]);
    resetVpcIpSubnetworks(): void;
    get vpcIpSubnetworksInput(): string[] | undefined;
}
export interface AccessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSources {
    /**
    * vpc_subnetwork block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#vpc_subnetwork AccessContextManagerAccessLevels#vpc_subnetwork}
    */
    readonly vpcSubnetwork?: AccessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSourcesVpcSubnetwork;
}
export declare function accessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSourcesToTerraform(struct?: AccessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSources | cdktn.IResolvable): any;
export declare function accessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSourcesToHclTerraform(struct?: AccessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSources | cdktn.IResolvable): any;
export declare class AccessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSources | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSources | cdktn.IResolvable | undefined);
    private _vpcSubnetwork;
    get vpcSubnetwork(): AccessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSourcesVpcSubnetworkOutputReference;
    putVpcSubnetwork(value: AccessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSourcesVpcSubnetwork): void;
    resetVpcSubnetwork(): void;
    get vpcSubnetworkInput(): AccessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSourcesVpcSubnetwork | undefined;
}
export declare class AccessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSourcesList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSourcesOutputReference;
}
export interface AccessContextManagerAccessLevelsAccessLevelsBasicConditions {
    /**
    * A list of CIDR block IP subnetwork specification. May be IPv4
    * or IPv6.
    * Note that for a CIDR IP address block, the specified IP address
    * portion must be properly truncated (i.e. all the host bits must
    * be zero) or the input is considered malformed. For example,
    * "192.0.2.0/24" is accepted but "192.0.2.1/24" is not. Similarly,
    * for IPv6, "2001:db8::/32" is accepted whereas "2001:db8::1/32"
    * is not. The originating IP of a request must be in one of the
    * listed subnets in order for this Condition to be true.
    * If empty, all IP addresses are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#ip_subnetworks AccessContextManagerAccessLevels#ip_subnetworks}
    */
    readonly ipSubnetworks?: string[];
    /**
    * An allowed list of members (users, service accounts).
    * Using groups is not supported yet.
    *
    * The signed-in user originating the request must be a part of one
    * of the provided members. If not specified, a request may come
    * from any user (logged in/not logged in, not present in any
    * groups, etc.).
    * Formats: 'user:{emailid}', 'serviceAccount:{emailid}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#members AccessContextManagerAccessLevels#members}
    */
    readonly members?: string[];
    /**
    * Whether to negate the Condition. If true, the Condition becomes
    * a NAND over its non-empty fields, each field must be false for
    * the Condition overall to be satisfied. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#negate AccessContextManagerAccessLevels#negate}
    */
    readonly negate?: boolean | cdktn.IResolvable;
    /**
    * The request must originate from one of the provided
    * countries/regions.
    * Format: A valid ISO 3166-1 alpha-2 code.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#regions AccessContextManagerAccessLevels#regions}
    */
    readonly regions?: string[];
    /**
    * A list of other access levels defined in the same Policy,
    * referenced by resource name. Referencing an AccessLevel which
    * does not exist is an error. All access levels listed must be
    * granted for the Condition to be true.
    * Format: accessPolicies/{policy_id}/accessLevels/{short_name}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#required_access_levels AccessContextManagerAccessLevels#required_access_levels}
    */
    readonly requiredAccessLevels?: string[];
    /**
    * device_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#device_policy AccessContextManagerAccessLevels#device_policy}
    */
    readonly devicePolicy?: AccessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicy;
    /**
    * vpc_network_sources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#vpc_network_sources AccessContextManagerAccessLevels#vpc_network_sources}
    */
    readonly vpcNetworkSources?: AccessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSources[] | cdktn.IResolvable;
}
export declare function accessContextManagerAccessLevelsAccessLevelsBasicConditionsToTerraform(struct?: AccessContextManagerAccessLevelsAccessLevelsBasicConditions | cdktn.IResolvable): any;
export declare function accessContextManagerAccessLevelsAccessLevelsBasicConditionsToHclTerraform(struct?: AccessContextManagerAccessLevelsAccessLevelsBasicConditions | cdktn.IResolvable): any;
export declare class AccessContextManagerAccessLevelsAccessLevelsBasicConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerAccessLevelsAccessLevelsBasicConditions | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerAccessLevelsAccessLevelsBasicConditions | cdktn.IResolvable | undefined);
    private _ipSubnetworks?;
    get ipSubnetworks(): string[];
    set ipSubnetworks(value: string[]);
    resetIpSubnetworks(): void;
    get ipSubnetworksInput(): string[] | undefined;
    private _members?;
    get members(): string[];
    set members(value: string[]);
    resetMembers(): void;
    get membersInput(): string[] | undefined;
    private _negate?;
    get negate(): boolean | cdktn.IResolvable;
    set negate(value: boolean | cdktn.IResolvable);
    resetNegate(): void;
    get negateInput(): boolean | cdktn.IResolvable | undefined;
    private _regions?;
    get regions(): string[];
    set regions(value: string[]);
    resetRegions(): void;
    get regionsInput(): string[] | undefined;
    private _requiredAccessLevels?;
    get requiredAccessLevels(): string[];
    set requiredAccessLevels(value: string[]);
    resetRequiredAccessLevels(): void;
    get requiredAccessLevelsInput(): string[] | undefined;
    private _devicePolicy;
    get devicePolicy(): AccessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicyOutputReference;
    putDevicePolicy(value: AccessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicy): void;
    resetDevicePolicy(): void;
    get devicePolicyInput(): AccessContextManagerAccessLevelsAccessLevelsBasicConditionsDevicePolicy | undefined;
    private _vpcNetworkSources;
    get vpcNetworkSources(): AccessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSourcesList;
    putVpcNetworkSources(value: AccessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSources[] | cdktn.IResolvable): void;
    resetVpcNetworkSources(): void;
    get vpcNetworkSourcesInput(): cdktn.IResolvable | AccessContextManagerAccessLevelsAccessLevelsBasicConditionsVpcNetworkSources[] | undefined;
}
export declare class AccessContextManagerAccessLevelsAccessLevelsBasicConditionsList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerAccessLevelsAccessLevelsBasicConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerAccessLevelsAccessLevelsBasicConditionsOutputReference;
}
export interface AccessContextManagerAccessLevelsAccessLevelsBasic {
    /**
    * How the conditions list should be combined to determine if a request
    * is granted this AccessLevel. If AND is used, each Condition in
    * conditions must be satisfied for the AccessLevel to be applied. If
    * OR is used, at least one Condition in conditions must be satisfied
    * for the AccessLevel to be applied. Default value: "AND" Possible values: ["AND", "OR"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#combining_function AccessContextManagerAccessLevels#combining_function}
    */
    readonly combiningFunction?: string;
    /**
    * conditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#conditions AccessContextManagerAccessLevels#conditions}
    */
    readonly conditions: AccessContextManagerAccessLevelsAccessLevelsBasicConditions[] | cdktn.IResolvable;
}
export declare function accessContextManagerAccessLevelsAccessLevelsBasicToTerraform(struct?: AccessContextManagerAccessLevelsAccessLevelsBasicOutputReference | AccessContextManagerAccessLevelsAccessLevelsBasic): any;
export declare function accessContextManagerAccessLevelsAccessLevelsBasicToHclTerraform(struct?: AccessContextManagerAccessLevelsAccessLevelsBasicOutputReference | AccessContextManagerAccessLevelsAccessLevelsBasic): any;
export declare class AccessContextManagerAccessLevelsAccessLevelsBasicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerAccessLevelsAccessLevelsBasic | undefined;
    set internalValue(value: AccessContextManagerAccessLevelsAccessLevelsBasic | undefined);
    private _combiningFunction?;
    get combiningFunction(): string;
    set combiningFunction(value: string);
    resetCombiningFunction(): void;
    get combiningFunctionInput(): string | undefined;
    private _conditions;
    get conditions(): AccessContextManagerAccessLevelsAccessLevelsBasicConditionsList;
    putConditions(value: AccessContextManagerAccessLevelsAccessLevelsBasicConditions[] | cdktn.IResolvable): void;
    get conditionsInput(): cdktn.IResolvable | AccessContextManagerAccessLevelsAccessLevelsBasicConditions[] | undefined;
}
export interface AccessContextManagerAccessLevelsAccessLevelsCustomExpr {
    /**
    * Description of the expression
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#description AccessContextManagerAccessLevels#description}
    */
    readonly description?: string;
    /**
    * Textual representation of an expression in Common Expression Language syntax.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#expression AccessContextManagerAccessLevels#expression}
    */
    readonly expression: string;
    /**
    * String indicating the location of the expression for error reporting, e.g. a file name and a position in the file
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#location AccessContextManagerAccessLevels#location}
    */
    readonly location?: string;
    /**
    * Title for the expression, i.e. a short string describing its purpose.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#title AccessContextManagerAccessLevels#title}
    */
    readonly title?: string;
}
export declare function accessContextManagerAccessLevelsAccessLevelsCustomExprToTerraform(struct?: AccessContextManagerAccessLevelsAccessLevelsCustomExprOutputReference | AccessContextManagerAccessLevelsAccessLevelsCustomExpr): any;
export declare function accessContextManagerAccessLevelsAccessLevelsCustomExprToHclTerraform(struct?: AccessContextManagerAccessLevelsAccessLevelsCustomExprOutputReference | AccessContextManagerAccessLevelsAccessLevelsCustomExpr): any;
export declare class AccessContextManagerAccessLevelsAccessLevelsCustomExprOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerAccessLevelsAccessLevelsCustomExpr | undefined;
    set internalValue(value: AccessContextManagerAccessLevelsAccessLevelsCustomExpr | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
}
export interface AccessContextManagerAccessLevelsAccessLevelsCustom {
    /**
    * expr block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#expr AccessContextManagerAccessLevels#expr}
    */
    readonly expr: AccessContextManagerAccessLevelsAccessLevelsCustomExpr;
}
export declare function accessContextManagerAccessLevelsAccessLevelsCustomToTerraform(struct?: AccessContextManagerAccessLevelsAccessLevelsCustomOutputReference | AccessContextManagerAccessLevelsAccessLevelsCustom): any;
export declare function accessContextManagerAccessLevelsAccessLevelsCustomToHclTerraform(struct?: AccessContextManagerAccessLevelsAccessLevelsCustomOutputReference | AccessContextManagerAccessLevelsAccessLevelsCustom): any;
export declare class AccessContextManagerAccessLevelsAccessLevelsCustomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerAccessLevelsAccessLevelsCustom | undefined;
    set internalValue(value: AccessContextManagerAccessLevelsAccessLevelsCustom | undefined);
    private _expr;
    get expr(): AccessContextManagerAccessLevelsAccessLevelsCustomExprOutputReference;
    putExpr(value: AccessContextManagerAccessLevelsAccessLevelsCustomExpr): void;
    get exprInput(): AccessContextManagerAccessLevelsAccessLevelsCustomExpr | undefined;
}
export interface AccessContextManagerAccessLevelsAccessLevels {
    /**
    * Description of the AccessLevel and its use. Does not affect behavior.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#description AccessContextManagerAccessLevels#description}
    */
    readonly description?: string;
    /**
    * Resource name for the Access Level. The short_name component must begin
    * with a letter and only include alphanumeric and '_'.
    * Format: accessPolicies/{policy_id}/accessLevels/{short_name}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#name AccessContextManagerAccessLevels#name}
    */
    readonly name: string;
    /**
    * Human readable title. Must be unique within the Policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#title AccessContextManagerAccessLevels#title}
    */
    readonly title: string;
    /**
    * basic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#basic AccessContextManagerAccessLevels#basic}
    */
    readonly basic?: AccessContextManagerAccessLevelsAccessLevelsBasic;
    /**
    * custom block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#custom AccessContextManagerAccessLevels#custom}
    */
    readonly custom?: AccessContextManagerAccessLevelsAccessLevelsCustom;
}
export declare function accessContextManagerAccessLevelsAccessLevelsToTerraform(struct?: AccessContextManagerAccessLevelsAccessLevels | cdktn.IResolvable): any;
export declare function accessContextManagerAccessLevelsAccessLevelsToHclTerraform(struct?: AccessContextManagerAccessLevelsAccessLevels | cdktn.IResolvable): any;
export declare class AccessContextManagerAccessLevelsAccessLevelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerAccessLevelsAccessLevels | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerAccessLevelsAccessLevels | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    private _basic;
    get basic(): AccessContextManagerAccessLevelsAccessLevelsBasicOutputReference;
    putBasic(value: AccessContextManagerAccessLevelsAccessLevelsBasic): void;
    resetBasic(): void;
    get basicInput(): AccessContextManagerAccessLevelsAccessLevelsBasic | undefined;
    private _custom;
    get custom(): AccessContextManagerAccessLevelsAccessLevelsCustomOutputReference;
    putCustom(value: AccessContextManagerAccessLevelsAccessLevelsCustom): void;
    resetCustom(): void;
    get customInput(): AccessContextManagerAccessLevelsAccessLevelsCustom | undefined;
}
export declare class AccessContextManagerAccessLevelsAccessLevelsList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerAccessLevelsAccessLevels[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerAccessLevelsAccessLevelsOutputReference;
}
export interface AccessContextManagerAccessLevelsTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#create AccessContextManagerAccessLevels#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#delete AccessContextManagerAccessLevels#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#update AccessContextManagerAccessLevels#update}
    */
    readonly update?: string;
}
export declare function accessContextManagerAccessLevelsTimeoutsToTerraform(struct?: AccessContextManagerAccessLevelsTimeouts | cdktn.IResolvable): any;
export declare function accessContextManagerAccessLevelsTimeoutsToHclTerraform(struct?: AccessContextManagerAccessLevelsTimeouts | cdktn.IResolvable): any;
export declare class AccessContextManagerAccessLevelsTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerAccessLevelsTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerAccessLevelsTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels google_access_context_manager_access_levels}
*/
export declare class AccessContextManagerAccessLevels extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_access_context_manager_access_levels";
    /**
    * Generates CDKTN code for importing a AccessContextManagerAccessLevels resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessContextManagerAccessLevels to import
    * @param importFromId The id of the existing AccessContextManagerAccessLevels that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessContextManagerAccessLevels to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_access_levels google_access_context_manager_access_levels} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessContextManagerAccessLevelsConfig
    */
    constructor(scope: Construct, id: string, config: AccessContextManagerAccessLevelsConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _accessLevels;
    get accessLevels(): AccessContextManagerAccessLevelsAccessLevelsList;
    putAccessLevels(value: AccessContextManagerAccessLevelsAccessLevels[] | cdktn.IResolvable): void;
    resetAccessLevels(): void;
    get accessLevelsInput(): cdktn.IResolvable | AccessContextManagerAccessLevelsAccessLevels[] | undefined;
    private _timeouts;
    get timeouts(): AccessContextManagerAccessLevelsTimeoutsOutputReference;
    putTimeouts(value: AccessContextManagerAccessLevelsTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AccessContextManagerAccessLevelsTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
