/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeAddressConfig extends cdktn.TerraformMetaArguments {
    /**
    * The static external IP address represented by this resource.
    * The IP address must be inside the specified subnetwork,
    * if any. Set by the API if undefined.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_address#address ComputeAddress#address}
    */
    readonly address?: string;
    /**
    * The type of address to reserve.
    * Note: if you set this argument's value as 'INTERNAL' you need to leave the 'network_tier' argument unset in that resource block. Default value: "EXTERNAL" Possible values: ["INTERNAL", "EXTERNAL"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_address#address_type ComputeAddress#address_type}
    */
    readonly addressType?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_address#deletion_policy ComputeAddress#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_address#description ComputeAddress#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_address#id ComputeAddress#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Reference to the source of external IPv4/IPv6 addresses, like a PublicDelegatedPrefix(PDP) for BYOIP.
    * If an IPv4 PDP is used, the PDP must support enhanced IPv4 allocations.
    * If an IPv6 PDP is used, the PDP must be in EXTERNAL_IPV6_FORWARDING_RULE_CREATION mode.
    * Use one of the following formats to specify a PDP when reserving an external IPv4 address using BYOIP.
    * Full resource URL, as in:
    *   * 'https://www.googleapis.com/compute/v1/projects/{{projectId}}/regions/{{region}}/publicDelegatedPrefixes/{{pdp-name}}'
    * Partial URL, as in:
    *   * 'projects/{{projectId}}/regions/region/publicDelegatedPrefixes/{{pdp-name}}'
    *   * 'regions/{{region}}/publicDelegatedPrefixes/{{pdp-name}}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_address#ip_collection ComputeAddress#ip_collection}
    */
    readonly ipCollection?: string;
    /**
    * The IP Version that will be used by this address. The default value is 'IPV4'. Possible values: ["IPV4", "IPV6"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_address#ip_version ComputeAddress#ip_version}
    */
    readonly ipVersion?: string;
    /**
    * The endpoint type of this address, which should be VM or NETLB. This is
    * used for deciding which type of endpoint this address can be used after
    * the external IPv6 address reservation. Possible values: ["VM", "NETLB"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_address#ipv6_endpoint_type ComputeAddress#ipv6_endpoint_type}
    */
    readonly ipv6EndpointType?: string;
    /**
    * Labels to apply to this address.  A list of key->value pairs.
    *
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_address#labels ComputeAddress#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the resource. The name must be 1-63 characters long, and
    * comply with RFC1035. Specifically, the name must be 1-63 characters
    * long and match the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?'
    * which means the first character must be a lowercase letter, and all
    * following characters must be a dash, lowercase letter, or digit,
    * except the last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_address#name ComputeAddress#name}
    */
    readonly name: string;
    /**
    * The URL of the network in which to reserve the address. This field
    * can only be used with INTERNAL type with the VPC_PEERING and
    * IPSEC_INTERCONNECT purposes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_address#network ComputeAddress#network}
    */
    readonly network?: string;
    /**
    * The networking tier used for configuring this address. If this field is not
    * specified, it is assumed to be PREMIUM.
    * This argument should not be used when configuring Internal addresses, because [network tier cannot be set for internal traffic; it's always Premium](https://cloud.google.com/network-tiers/docs/overview). Possible values: ["PREMIUM", "STANDARD"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_address#network_tier ComputeAddress#network_tier}
    */
    readonly networkTier?: string;
    /**
    * The prefix length if the resource represents an IP range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_address#prefix_length ComputeAddress#prefix_length}
    */
    readonly prefixLength?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_address#project ComputeAddress#project}
    */
    readonly project?: string;
    /**
    * The purpose of this resource, which can be one of the following values.
    *
    * * GCE_ENDPOINT for addresses that are used by VM instances, alias IP
    * ranges, load balancers, and similar resources.
    *
    * * SHARED_LOADBALANCER_VIP for an address that can be used by multiple
    * internal load balancers.
    *
    * * VPC_PEERING for addresses that are reserved for VPC peer networks.
    *
    * * IPSEC_INTERCONNECT for addresses created from a private IP range that
    * are reserved for a VLAN attachment in an HA VPN over Cloud Interconnect
    * configuration. These addresses are regional resources.
    *
    * * PRIVATE_SERVICE_CONNECT for a private network address that is used to
    * configure Private Service Connect. Only global internal addresses can use
    * this purpose.
    *
    * * SYSTEM_MANAGED for regional internal IP address that is reserved and
    * managed internally. It can not be assigned to compute resources such as
    * VM and internal load balancer.
    *
    * This should only be set when using an Internal address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_address#purpose ComputeAddress#purpose}
    */
    readonly purpose?: string;
    /**
    * The Region in which the created address should reside.
    * If it is not provided, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_address#region ComputeAddress#region}
    */
    readonly region?: string;
    /**
    * The URL of the subnetwork in which to reserve the address. If an IP
    * address is specified, it must be within the subnetwork's IP range.
    * This field can only be used with INTERNAL type with
    * GCE_ENDPOINT/DNS_RESOLVER purposes, or with EXTERNAL type IPv6 addresses
    * when 'ipv6_endpoint_type' is 'VM' or 'NETLB'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_address#subnetwork ComputeAddress#subnetwork}
    */
    readonly subnetwork?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_address#timeouts ComputeAddress#timeouts}
    */
    readonly timeouts?: ComputeAddressTimeouts;
}
export interface ComputeAddressTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_address#create ComputeAddress#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_address#delete ComputeAddress#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_address#update ComputeAddress#update}
    */
    readonly update?: string;
}
export declare function computeAddressTimeoutsToTerraform(struct?: ComputeAddressTimeouts | cdktn.IResolvable): any;
export declare function computeAddressTimeoutsToHclTerraform(struct?: ComputeAddressTimeouts | cdktn.IResolvable): any;
export declare class ComputeAddressTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeAddressTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeAddressTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_address google_compute_address}
*/
export declare class ComputeAddress extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_address";
    /**
    * Generates CDKTN code for importing a ComputeAddress resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeAddress to import
    * @param importFromId The id of the existing ComputeAddress that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_address#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeAddress to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_address google_compute_address} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeAddressConfig
    */
    constructor(scope: Construct, id: string, config: ComputeAddressConfig);
    private _address?;
    get address(): string;
    set address(value: string);
    resetAddress(): void;
    get addressInput(): string | undefined;
    get addressId(): string;
    private _addressType?;
    get addressType(): string;
    set addressType(value: string);
    resetAddressType(): void;
    get addressTypeInput(): string | undefined;
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipCollection?;
    get ipCollection(): string;
    set ipCollection(value: string);
    resetIpCollection(): void;
    get ipCollectionInput(): string | undefined;
    private _ipVersion?;
    get ipVersion(): string;
    set ipVersion(value: string);
    resetIpVersion(): void;
    get ipVersionInput(): string | undefined;
    private _ipv6EndpointType?;
    get ipv6EndpointType(): string;
    set ipv6EndpointType(value: string);
    resetIpv6EndpointType(): void;
    get ipv6EndpointTypeInput(): string | undefined;
    get labelFingerprint(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _network?;
    get network(): string;
    set network(value: string);
    resetNetwork(): void;
    get networkInput(): string | undefined;
    private _networkTier?;
    get networkTier(): string;
    set networkTier(value: string);
    resetNetworkTier(): void;
    get networkTierInput(): string | undefined;
    private _prefixLength?;
    get prefixLength(): number;
    set prefixLength(value: number);
    resetPrefixLength(): void;
    get prefixLengthInput(): number | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _purpose?;
    get purpose(): string;
    set purpose(value: string);
    resetPurpose(): void;
    get purposeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get selfLink(): string;
    private _subnetwork?;
    get subnetwork(): string;
    set subnetwork(value: string);
    resetSubnetwork(): void;
    get subnetworkInput(): string | undefined;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get users(): string[];
    private _timeouts;
    get timeouts(): ComputeAddressTimeoutsOutputReference;
    putTimeouts(value: ComputeAddressTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeAddressTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
