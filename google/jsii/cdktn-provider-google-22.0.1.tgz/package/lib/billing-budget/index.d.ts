/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BillingBudgetConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the billing account to set a budget on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#billing_account BillingBudget#billing_account}
    */
    readonly billingAccount: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#deletion_policy BillingBudget#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * User data for display name in UI. Must be <= 60 chars.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#display_name BillingBudget#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#id BillingBudget#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ownership scope of the budget. The ownership scope and users'
    * IAM permissions determine who has full access to the budget's data. Possible values: ["OWNERSHIP_SCOPE_UNSPECIFIED", "ALL_USERS", "BILLING_ACCOUNT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#ownership_scope BillingBudget#ownership_scope}
    */
    readonly ownershipScope?: string;
    /**
    * all_updates_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#all_updates_rule BillingBudget#all_updates_rule}
    */
    readonly allUpdatesRule?: BillingBudgetAllUpdatesRule;
    /**
    * amount block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#amount BillingBudget#amount}
    */
    readonly amount: BillingBudgetAmount;
    /**
    * budget_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#budget_filter BillingBudget#budget_filter}
    */
    readonly budgetFilter?: BillingBudgetBudgetFilter;
    /**
    * threshold_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#threshold_rules BillingBudget#threshold_rules}
    */
    readonly thresholdRules?: BillingBudgetThresholdRules[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#timeouts BillingBudget#timeouts}
    */
    readonly timeouts?: BillingBudgetTimeouts;
}
export interface BillingBudgetAllUpdatesRule {
    /**
    * Boolean. When set to true, disables default notifications sent
    * when a threshold is exceeded. Default recipients are
    * those with Billing Account Administrators and Billing
    * Account Users IAM roles for the target account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#disable_default_iam_recipients BillingBudget#disable_default_iam_recipients}
    */
    readonly disableDefaultIamRecipients?: boolean | cdktn.IResolvable;
    /**
    * When set to true, and when the budget has a single project configured,
    * notifications will be sent to project level recipients of that project.
    * This field will be ignored if the budget has multiple or no project configured.
    *
    * Currently, project level recipients are the users with Owner role on a cloud project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#enable_project_level_recipients BillingBudget#enable_project_level_recipients}
    */
    readonly enableProjectLevelRecipients?: boolean | cdktn.IResolvable;
    /**
    * The full resource name of a monitoring notification
    * channel in the form
    * projects/{project_id}/notificationChannels/{channel_id}.
    * A maximum of 5 channels are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#monitoring_notification_channels BillingBudget#monitoring_notification_channels}
    */
    readonly monitoringNotificationChannels?: string[];
    /**
    * The name of the Cloud Pub/Sub topic where budget related
    * messages will be published, in the form
    * projects/{project_id}/topics/{topic_id}. Updates are sent
    * at regular intervals to the topic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#pubsub_topic BillingBudget#pubsub_topic}
    */
    readonly pubsubTopic?: string;
    /**
    * The schema version of the notification. Only "1.0" is
    * accepted. It represents the JSON schema as defined in
    * https://cloud.google.com/billing/docs/how-to/budgets#notification_format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#schema_version BillingBudget#schema_version}
    */
    readonly schemaVersion?: string;
}
export declare function billingBudgetAllUpdatesRuleToTerraform(struct?: BillingBudgetAllUpdatesRuleOutputReference | BillingBudgetAllUpdatesRule): any;
export declare function billingBudgetAllUpdatesRuleToHclTerraform(struct?: BillingBudgetAllUpdatesRuleOutputReference | BillingBudgetAllUpdatesRule): any;
export declare class BillingBudgetAllUpdatesRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BillingBudgetAllUpdatesRule | undefined;
    set internalValue(value: BillingBudgetAllUpdatesRule | undefined);
    private _disableDefaultIamRecipients?;
    get disableDefaultIamRecipients(): boolean | cdktn.IResolvable;
    set disableDefaultIamRecipients(value: boolean | cdktn.IResolvable);
    resetDisableDefaultIamRecipients(): void;
    get disableDefaultIamRecipientsInput(): boolean | cdktn.IResolvable | undefined;
    private _enableProjectLevelRecipients?;
    get enableProjectLevelRecipients(): boolean | cdktn.IResolvable;
    set enableProjectLevelRecipients(value: boolean | cdktn.IResolvable);
    resetEnableProjectLevelRecipients(): void;
    get enableProjectLevelRecipientsInput(): boolean | cdktn.IResolvable | undefined;
    private _monitoringNotificationChannels?;
    get monitoringNotificationChannels(): string[];
    set monitoringNotificationChannels(value: string[]);
    resetMonitoringNotificationChannels(): void;
    get monitoringNotificationChannelsInput(): string[] | undefined;
    private _pubsubTopic?;
    get pubsubTopic(): string;
    set pubsubTopic(value: string);
    resetPubsubTopic(): void;
    get pubsubTopicInput(): string | undefined;
    private _schemaVersion?;
    get schemaVersion(): string;
    set schemaVersion(value: string);
    resetSchemaVersion(): void;
    get schemaVersionInput(): string | undefined;
}
export interface BillingBudgetAmountSpecifiedAmount {
    /**
    * The 3-letter currency code defined in ISO 4217.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#currency_code BillingBudget#currency_code}
    */
    readonly currencyCode?: string;
    /**
    * Number of nano (10^-9) units of the amount.
    * The value must be between -999,999,999 and +999,999,999
    * inclusive. If units is positive, nanos must be positive or
    * zero. If units is zero, nanos can be positive, zero, or
    * negative. If units is negative, nanos must be negative or
    * zero. For example $-1.75 is represented as units=-1 and
    * nanos=-750,000,000.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#nanos BillingBudget#nanos}
    */
    readonly nanos?: number;
    /**
    * The whole units of the amount. For example if currencyCode
    * is "USD", then 1 unit is one US dollar.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#units BillingBudget#units}
    */
    readonly units?: string;
}
export declare function billingBudgetAmountSpecifiedAmountToTerraform(struct?: BillingBudgetAmountSpecifiedAmountOutputReference | BillingBudgetAmountSpecifiedAmount): any;
export declare function billingBudgetAmountSpecifiedAmountToHclTerraform(struct?: BillingBudgetAmountSpecifiedAmountOutputReference | BillingBudgetAmountSpecifiedAmount): any;
export declare class BillingBudgetAmountSpecifiedAmountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BillingBudgetAmountSpecifiedAmount | undefined;
    set internalValue(value: BillingBudgetAmountSpecifiedAmount | undefined);
    private _currencyCode?;
    get currencyCode(): string;
    set currencyCode(value: string);
    resetCurrencyCode(): void;
    get currencyCodeInput(): string | undefined;
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _units?;
    get units(): string;
    set units(value: string);
    resetUnits(): void;
    get unitsInput(): string | undefined;
}
export interface BillingBudgetAmount {
    /**
    * Configures a budget amount that is automatically set to 100% of
    * last period's spend.
    * Boolean. Set value to true to use. Do not set to false, instead
    * use the 'specified_amount' block.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#last_period_amount BillingBudget#last_period_amount}
    */
    readonly lastPeriodAmount?: boolean | cdktn.IResolvable;
    /**
    * specified_amount block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#specified_amount BillingBudget#specified_amount}
    */
    readonly specifiedAmount?: BillingBudgetAmountSpecifiedAmount;
}
export declare function billingBudgetAmountToTerraform(struct?: BillingBudgetAmountOutputReference | BillingBudgetAmount): any;
export declare function billingBudgetAmountToHclTerraform(struct?: BillingBudgetAmountOutputReference | BillingBudgetAmount): any;
export declare class BillingBudgetAmountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BillingBudgetAmount | undefined;
    set internalValue(value: BillingBudgetAmount | undefined);
    private _lastPeriodAmount?;
    get lastPeriodAmount(): boolean | cdktn.IResolvable;
    set lastPeriodAmount(value: boolean | cdktn.IResolvable);
    resetLastPeriodAmount(): void;
    get lastPeriodAmountInput(): boolean | cdktn.IResolvable | undefined;
    private _specifiedAmount;
    get specifiedAmount(): BillingBudgetAmountSpecifiedAmountOutputReference;
    putSpecifiedAmount(value: BillingBudgetAmountSpecifiedAmount): void;
    resetSpecifiedAmount(): void;
    get specifiedAmountInput(): BillingBudgetAmountSpecifiedAmount | undefined;
}
export interface BillingBudgetBudgetFilterCustomPeriodEndDate {
    /**
    * Day of a month. Must be from 1 to 31 and valid for the year and month.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#day BillingBudget#day}
    */
    readonly day: number;
    /**
    * Month of a year. Must be from 1 to 12.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#month BillingBudget#month}
    */
    readonly month: number;
    /**
    * Year of the date. Must be from 1 to 9999.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#year BillingBudget#year}
    */
    readonly year: number;
}
export declare function billingBudgetBudgetFilterCustomPeriodEndDateToTerraform(struct?: BillingBudgetBudgetFilterCustomPeriodEndDateOutputReference | BillingBudgetBudgetFilterCustomPeriodEndDate): any;
export declare function billingBudgetBudgetFilterCustomPeriodEndDateToHclTerraform(struct?: BillingBudgetBudgetFilterCustomPeriodEndDateOutputReference | BillingBudgetBudgetFilterCustomPeriodEndDate): any;
export declare class BillingBudgetBudgetFilterCustomPeriodEndDateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BillingBudgetBudgetFilterCustomPeriodEndDate | undefined;
    set internalValue(value: BillingBudgetBudgetFilterCustomPeriodEndDate | undefined);
    private _day?;
    get day(): number;
    set day(value: number);
    get dayInput(): number | undefined;
    private _month?;
    get month(): number;
    set month(value: number);
    get monthInput(): number | undefined;
    private _year?;
    get year(): number;
    set year(value: number);
    get yearInput(): number | undefined;
}
export interface BillingBudgetBudgetFilterCustomPeriodStartDate {
    /**
    * Day of a month. Must be from 1 to 31 and valid for the year and month.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#day BillingBudget#day}
    */
    readonly day: number;
    /**
    * Month of a year. Must be from 1 to 12.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#month BillingBudget#month}
    */
    readonly month: number;
    /**
    * Year of the date. Must be from 1 to 9999.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#year BillingBudget#year}
    */
    readonly year: number;
}
export declare function billingBudgetBudgetFilterCustomPeriodStartDateToTerraform(struct?: BillingBudgetBudgetFilterCustomPeriodStartDateOutputReference | BillingBudgetBudgetFilterCustomPeriodStartDate): any;
export declare function billingBudgetBudgetFilterCustomPeriodStartDateToHclTerraform(struct?: BillingBudgetBudgetFilterCustomPeriodStartDateOutputReference | BillingBudgetBudgetFilterCustomPeriodStartDate): any;
export declare class BillingBudgetBudgetFilterCustomPeriodStartDateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BillingBudgetBudgetFilterCustomPeriodStartDate | undefined;
    set internalValue(value: BillingBudgetBudgetFilterCustomPeriodStartDate | undefined);
    private _day?;
    get day(): number;
    set day(value: number);
    get dayInput(): number | undefined;
    private _month?;
    get month(): number;
    set month(value: number);
    get monthInput(): number | undefined;
    private _year?;
    get year(): number;
    set year(value: number);
    get yearInput(): number | undefined;
}
export interface BillingBudgetBudgetFilterCustomPeriod {
    /**
    * end_date block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#end_date BillingBudget#end_date}
    */
    readonly endDate?: BillingBudgetBudgetFilterCustomPeriodEndDate;
    /**
    * start_date block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#start_date BillingBudget#start_date}
    */
    readonly startDate: BillingBudgetBudgetFilterCustomPeriodStartDate;
}
export declare function billingBudgetBudgetFilterCustomPeriodToTerraform(struct?: BillingBudgetBudgetFilterCustomPeriodOutputReference | BillingBudgetBudgetFilterCustomPeriod): any;
export declare function billingBudgetBudgetFilterCustomPeriodToHclTerraform(struct?: BillingBudgetBudgetFilterCustomPeriodOutputReference | BillingBudgetBudgetFilterCustomPeriod): any;
export declare class BillingBudgetBudgetFilterCustomPeriodOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BillingBudgetBudgetFilterCustomPeriod | undefined;
    set internalValue(value: BillingBudgetBudgetFilterCustomPeriod | undefined);
    private _endDate;
    get endDate(): BillingBudgetBudgetFilterCustomPeriodEndDateOutputReference;
    putEndDate(value: BillingBudgetBudgetFilterCustomPeriodEndDate): void;
    resetEndDate(): void;
    get endDateInput(): BillingBudgetBudgetFilterCustomPeriodEndDate | undefined;
    private _startDate;
    get startDate(): BillingBudgetBudgetFilterCustomPeriodStartDateOutputReference;
    putStartDate(value: BillingBudgetBudgetFilterCustomPeriodStartDate): void;
    get startDateInput(): BillingBudgetBudgetFilterCustomPeriodStartDate | undefined;
}
export interface BillingBudgetBudgetFilter {
    /**
    * A CalendarPeriod represents the abstract concept of a recurring time period that has a
    * canonical start. Grammatically, "the start of the current CalendarPeriod".
    * All calendar times begin at 12 AM US and Canadian Pacific Time (UTC-8).
    *
    * Exactly one of 'calendar_period', 'custom_period' must be provided. Possible values: ["MONTH", "QUARTER", "YEAR", "CALENDAR_PERIOD_UNSPECIFIED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#calendar_period BillingBudget#calendar_period}
    */
    readonly calendarPeriod?: string;
    /**
    * Optional. If creditTypesTreatment is INCLUDE_SPECIFIED_CREDITS,
    * this is a list of credit types to be subtracted from gross cost to determine the spend for threshold calculations. See a list of acceptable credit type values.
    * If creditTypesTreatment is not INCLUDE_SPECIFIED_CREDITS, this field must be empty.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#credit_types BillingBudget#credit_types}
    */
    readonly creditTypes?: string[];
    /**
    * Specifies how credits should be treated when determining spend
    * for threshold calculations. Default value: "INCLUDE_ALL_CREDITS" Possible values: ["INCLUDE_ALL_CREDITS", "EXCLUDE_ALL_CREDITS", "INCLUDE_SPECIFIED_CREDITS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#credit_types_treatment BillingBudget#credit_types_treatment}
    */
    readonly creditTypesTreatment?: string;
    /**
    * A single label and value pair specifying that usage from only
    * this set of labeled resources should be included in the budget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#labels BillingBudget#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * A set of projects of the form projects/{project_number},
    * specifying that usage from only this set of projects should be
    * included in the budget. If omitted, the report will include
    * all usage for the billing account, regardless of which project
    * the usage occurred on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#projects BillingBudget#projects}
    */
    readonly projects?: string[];
    /**
    * A set of folder and organization names of the form folders/{folderId} or organizations/{organizationId},
    * specifying that usage from only this set of folders and organizations should be included in the budget.
    * If omitted, the budget includes all usage that the billing account pays for. If the folder or organization
    * contains projects that are paid for by a different Cloud Billing account, the budget doesn't apply to those projects.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#resource_ancestors BillingBudget#resource_ancestors}
    */
    readonly resourceAncestors?: string[];
    /**
    * A set of services of the form services/{service_id},
    * specifying that usage from only this set of services should be
    * included in the budget. If omitted, the report will include
    * usage for all the services. The service names are available
    * through the Catalog API:
    * https://cloud.google.com/billing/v1/how-tos/catalog-api.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#services BillingBudget#services}
    */
    readonly services?: string[];
    /**
    * A set of subaccounts of the form billingAccounts/{account_id},
    * specifying that usage from only this set of subaccounts should
    * be included in the budget. If a subaccount is set to the name of
    * the parent account, usage from the parent account will be included.
    * If the field is omitted, the report will include usage from the parent
    * account and all subaccounts, if they exist.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#subaccounts BillingBudget#subaccounts}
    */
    readonly subaccounts?: string[];
    /**
    * custom_period block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#custom_period BillingBudget#custom_period}
    */
    readonly customPeriod?: BillingBudgetBudgetFilterCustomPeriod;
}
export declare function billingBudgetBudgetFilterToTerraform(struct?: BillingBudgetBudgetFilterOutputReference | BillingBudgetBudgetFilter): any;
export declare function billingBudgetBudgetFilterToHclTerraform(struct?: BillingBudgetBudgetFilterOutputReference | BillingBudgetBudgetFilter): any;
export declare class BillingBudgetBudgetFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BillingBudgetBudgetFilter | undefined;
    set internalValue(value: BillingBudgetBudgetFilter | undefined);
    private _calendarPeriod?;
    get calendarPeriod(): string;
    set calendarPeriod(value: string);
    resetCalendarPeriod(): void;
    get calendarPeriodInput(): string | undefined;
    private _creditTypes?;
    get creditTypes(): string[];
    set creditTypes(value: string[]);
    resetCreditTypes(): void;
    get creditTypesInput(): string[] | undefined;
    private _creditTypesTreatment?;
    get creditTypesTreatment(): string;
    set creditTypesTreatment(value: string);
    resetCreditTypesTreatment(): void;
    get creditTypesTreatmentInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _projects?;
    get projects(): string[];
    set projects(value: string[]);
    resetProjects(): void;
    get projectsInput(): string[] | undefined;
    private _resourceAncestors?;
    get resourceAncestors(): string[];
    set resourceAncestors(value: string[]);
    resetResourceAncestors(): void;
    get resourceAncestorsInput(): string[] | undefined;
    private _services?;
    get services(): string[];
    set services(value: string[]);
    resetServices(): void;
    get servicesInput(): string[] | undefined;
    private _subaccounts?;
    get subaccounts(): string[];
    set subaccounts(value: string[]);
    resetSubaccounts(): void;
    get subaccountsInput(): string[] | undefined;
    private _customPeriod;
    get customPeriod(): BillingBudgetBudgetFilterCustomPeriodOutputReference;
    putCustomPeriod(value: BillingBudgetBudgetFilterCustomPeriod): void;
    resetCustomPeriod(): void;
    get customPeriodInput(): BillingBudgetBudgetFilterCustomPeriod | undefined;
}
export interface BillingBudgetThresholdRules {
    /**
    * The type of basis used to determine if spend has passed
    * the threshold. Default value: "CURRENT_SPEND" Possible values: ["CURRENT_SPEND", "FORECASTED_SPEND"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#spend_basis BillingBudget#spend_basis}
    */
    readonly spendBasis?: string;
    /**
    * Send an alert when this threshold is exceeded. This is a
    * 1.0-based percentage, so 0.5 = 50%. Must be >= 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#threshold_percent BillingBudget#threshold_percent}
    */
    readonly thresholdPercent: number;
}
export declare function billingBudgetThresholdRulesToTerraform(struct?: BillingBudgetThresholdRules | cdktn.IResolvable): any;
export declare function billingBudgetThresholdRulesToHclTerraform(struct?: BillingBudgetThresholdRules | cdktn.IResolvable): any;
export declare class BillingBudgetThresholdRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BillingBudgetThresholdRules | cdktn.IResolvable | undefined;
    set internalValue(value: BillingBudgetThresholdRules | cdktn.IResolvable | undefined);
    private _spendBasis?;
    get spendBasis(): string;
    set spendBasis(value: string);
    resetSpendBasis(): void;
    get spendBasisInput(): string | undefined;
    private _thresholdPercent?;
    get thresholdPercent(): number;
    set thresholdPercent(value: number);
    get thresholdPercentInput(): number | undefined;
}
export declare class BillingBudgetThresholdRulesList extends cdktn.ComplexList {
    internalValue?: BillingBudgetThresholdRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BillingBudgetThresholdRulesOutputReference;
}
export interface BillingBudgetTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#create BillingBudget#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#delete BillingBudget#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#update BillingBudget#update}
    */
    readonly update?: string;
}
export declare function billingBudgetTimeoutsToTerraform(struct?: BillingBudgetTimeouts | cdktn.IResolvable): any;
export declare function billingBudgetTimeoutsToHclTerraform(struct?: BillingBudgetTimeouts | cdktn.IResolvable): any;
export declare class BillingBudgetTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BillingBudgetTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BillingBudgetTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget google_billing_budget}
*/
export declare class BillingBudget extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_billing_budget";
    /**
    * Generates CDKTN code for importing a BillingBudget resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BillingBudget to import
    * @param importFromId The id of the existing BillingBudget that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BillingBudget to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/billing_budget google_billing_budget} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BillingBudgetConfig
    */
    constructor(scope: Construct, id: string, config: BillingBudgetConfig);
    private _billingAccount?;
    get billingAccount(): string;
    set billingAccount(value: string);
    get billingAccountInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _ownershipScope?;
    get ownershipScope(): string;
    set ownershipScope(value: string);
    resetOwnershipScope(): void;
    get ownershipScopeInput(): string | undefined;
    private _allUpdatesRule;
    get allUpdatesRule(): BillingBudgetAllUpdatesRuleOutputReference;
    putAllUpdatesRule(value: BillingBudgetAllUpdatesRule): void;
    resetAllUpdatesRule(): void;
    get allUpdatesRuleInput(): BillingBudgetAllUpdatesRule | undefined;
    private _amount;
    get amount(): BillingBudgetAmountOutputReference;
    putAmount(value: BillingBudgetAmount): void;
    get amountInput(): BillingBudgetAmount | undefined;
    private _budgetFilter;
    get budgetFilter(): BillingBudgetBudgetFilterOutputReference;
    putBudgetFilter(value: BillingBudgetBudgetFilter): void;
    resetBudgetFilter(): void;
    get budgetFilterInput(): BillingBudgetBudgetFilter | undefined;
    private _thresholdRules;
    get thresholdRules(): BillingBudgetThresholdRulesList;
    putThresholdRules(value: BillingBudgetThresholdRules[] | cdktn.IResolvable): void;
    resetThresholdRules(): void;
    get thresholdRulesInput(): cdktn.IResolvable | BillingBudgetThresholdRules[] | undefined;
    private _timeouts;
    get timeouts(): BillingBudgetTimeoutsOutputReference;
    putTimeouts(value: BillingBudgetTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BillingBudgetTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
