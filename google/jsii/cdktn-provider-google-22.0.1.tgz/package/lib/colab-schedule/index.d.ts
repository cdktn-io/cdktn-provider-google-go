/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ColabScheduleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether new scheduled runs can be queued when max_concurrent_runs limit is reached. If set to true, new runs will be queued instead of skipped. Default to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#allow_queueing ColabSchedule#allow_queueing}
    */
    readonly allowQueueing?: boolean | cdktn.IResolvable;
    /**
    * Cron schedule (https://en.wikipedia.org/wiki/Cron) to launch scheduled runs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#cron ColabSchedule#cron}
    */
    readonly cron: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#deletion_policy ColabSchedule#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Desired state of the Colab Schedule. Set this field to 'ACTIVE' to start/resume the schedule, and 'PAUSED' to pause the schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#desired_state ColabSchedule#desired_state}
    */
    readonly desiredState?: string;
    /**
    * Required. The display name of the Schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#display_name ColabSchedule#display_name}
    */
    readonly displayName: string;
    /**
    * Timestamp after which no new runs can be scheduled. If specified, the schedule will be completed when either end_time is reached or when scheduled_run_count >= max_run_count. Must be in the RFC 3339 (https://www.ietf.org/rfc/rfc3339.txt) format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#end_time ColabSchedule#end_time}
    */
    readonly endTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#id ColabSchedule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location for the resource: https://cloud.google.com/colab/docs/locations
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#location ColabSchedule#location}
    */
    readonly location: string;
    /**
    * Specifies the maximum number of active runs that can be executed concurrently for this Schedule. This limits the number of runs that can be in a non-terminal state at the same time. Currently, this field is only supported for requests of type CreatePipelineJobRequest.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#max_concurrent_active_run_count ColabSchedule#max_concurrent_active_run_count}
    */
    readonly maxConcurrentActiveRunCount?: string;
    /**
    * Maximum number of runs that can be started concurrently for this Schedule. This is the limit for starting the scheduled requests and not the execution of the notebook execution jobs created by the requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#max_concurrent_run_count ColabSchedule#max_concurrent_run_count}
    */
    readonly maxConcurrentRunCount: string;
    /**
    * Maximum run count of the schedule. If specified, The schedule will be completed when either startedRunCount >= maxRunCount or when endTime is reached. If not specified, new runs will keep getting scheduled until this Schedule is paused or deleted. Already scheduled runs will be allowed to complete. Unset if not specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#max_run_count ColabSchedule#max_run_count}
    */
    readonly maxRunCount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#project ColabSchedule#project}
    */
    readonly project?: string;
    /**
    * The timestamp after which the first run can be scheduled. Defaults to the schedule creation time. Must be in the RFC 3339 (https://www.ietf.org/rfc/rfc3339.txt) format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#start_time ColabSchedule#start_time}
    */
    readonly startTime?: string;
    /**
    * create_notebook_execution_job_request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#create_notebook_execution_job_request ColabSchedule#create_notebook_execution_job_request}
    */
    readonly createNotebookExecutionJobRequest?: ColabScheduleCreateNotebookExecutionJobRequest;
    /**
    * create_pipeline_job_request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#create_pipeline_job_request ColabSchedule#create_pipeline_job_request}
    */
    readonly createPipelineJobRequest?: ColabScheduleCreatePipelineJobRequest;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#timeouts ColabSchedule#timeouts}
    */
    readonly timeouts?: ColabScheduleTimeouts;
}
export interface ColabScheduleLastScheduledRunResponse {
}
export declare function colabScheduleLastScheduledRunResponseToTerraform(struct?: ColabScheduleLastScheduledRunResponse): any;
export declare function colabScheduleLastScheduledRunResponseToHclTerraform(struct?: ColabScheduleLastScheduledRunResponse): any;
export declare class ColabScheduleLastScheduledRunResponseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ColabScheduleLastScheduledRunResponse | undefined;
    set internalValue(value: ColabScheduleLastScheduledRunResponse | undefined);
    get runResponse(): string;
    get scheduledRunTime(): string;
}
export declare class ColabScheduleLastScheduledRunResponseList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ColabScheduleLastScheduledRunResponseOutputReference;
}
export interface ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpecReservationAffinity {
    /**
    * Corresponds to the label key of a reservation resource. To target a SPECIFIC_RESERVATION by name, use 'compute.googleapis.com/reservation-name' as the key and specify the name of your reservation as its value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#key ColabSchedule#key}
    */
    readonly key?: string;
    /**
    * Specifies the reservation affinity type. Possible values: NO_RESERVATION ANY_RESERVATION SPECIFIC_RESERVATION SPECIFIC_THEN_ANY_RESERVATION SPECIFIC_THEN_NO_RESERVATION
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#reservation_affinity_type ColabSchedule#reservation_affinity_type}
    */
    readonly reservationAffinityType: string;
    /**
    * When set to true, resources will be drawn from go/cloud-ai-gcp-pool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#use_reservation_pool ColabSchedule#use_reservation_pool}
    */
    readonly useReservationPool?: boolean | cdktn.IResolvable;
    /**
    * Corresponds to the label values of a reservation resource. This must be the full resource name of the reservation or reservation block.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#values ColabSchedule#values}
    */
    readonly values?: string[];
}
export declare function colabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpecReservationAffinityToTerraform(struct?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpecReservationAffinityOutputReference | ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpecReservationAffinity): any;
export declare function colabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpecReservationAffinityToHclTerraform(struct?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpecReservationAffinityOutputReference | ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpecReservationAffinity): any;
export declare class ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpecReservationAffinityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpecReservationAffinity | undefined;
    set internalValue(value: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpecReservationAffinity | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _reservationAffinityType?;
    get reservationAffinityType(): string;
    set reservationAffinityType(value: string);
    get reservationAffinityTypeInput(): string | undefined;
    private _useReservationPool?;
    get useReservationPool(): boolean | cdktn.IResolvable;
    set useReservationPool(value: boolean | cdktn.IResolvable);
    resetUseReservationPool(): void;
    get useReservationPoolInput(): boolean | cdktn.IResolvable | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpec {
    /**
    * The number of accelerators to attach to the machine. For accelerator optimized machine types (https://cloud.google.com/compute/docs/accelerator-optimized-machines), One may set the accelerator_count from 1 to N for machine with N GPUs. If accelerator_count is less than or equal to N / 2, Vertex will co-schedule the replicas of the model into the same VM to save cost. For example, if the machine type is a3-highgpu-8g, which has 8 H100 GPUs, one can set accelerator_count to 1 to 8. If accelerator_count is 1, 2, 3, or 4, Vertex will co-schedule 8, 4, 2, or 2 replicas of the model into the same VM to save cost. When co-scheduling, CPU, memory and storage on the VM will be distributed to replicas on the VM. For example, one can expect a co-scheduled replica requesting 2 GPUs out of a 8-GPU VM will receive 25% of the CPU, memory and storage of the VM. Note that the feature is not compatible with multihost_gpu_node_count. When multihost_gpu_node_count is set, the co-scheduling will not be enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#accelerator_count ColabSchedule#accelerator_count}
    */
    readonly acceleratorCount?: number;
    /**
    * Possible values: NVIDIA_TESLA_K80 NVIDIA_TESLA_P100 NVIDIA_TESLA_V100 NVIDIA_TESLA_P4 NVIDIA_TESLA_T4 NVIDIA_TESLA_A100 NVIDIA_A100_80GB NVIDIA_L4 NVIDIA_H100_80GB NVIDIA_H100_MEGA_80GB NVIDIA_H200_141GB NVIDIA_B200 NVIDIA_GB200 NVIDIA_RTX_PRO_6000 TPU_V2 TPU_V3 TPU_V4_POD TPU_V5_LITEPOD
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#accelerator_type ColabSchedule#accelerator_type}
    */
    readonly acceleratorType?: string;
    /**
    * The Nvidia GPU partition size. When specified, the requested accelerators will be partitioned into smaller GPU partitions. For example, if the request is for 8 units of NVIDIA A100 GPUs, and gpu_partition_size="1g.10gb", the service will create 8 * 7 = 56 partitioned MIG instances. The partition size must be a value supported by the requested accelerator. Refer to [Nvidia GPU Partitioning](https://cloud.google.com/kubernetes-engine/docs/how-to/gpus-multi#multi-instance_gpu_partitions) for the available partition sizes. If set, the accelerator_count should be set to 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#gpu_partition_size ColabSchedule#gpu_partition_size}
    */
    readonly gpuPartitionSize?: string;
    /**
    * The type of the machine. See the [list of machine types supported for prediction](https://cloud.google.com/vertex-ai/docs/predictions/configure-compute#machine-types) See the [list of machine types supported for custom training](https://cloud.google.com/vertex-ai/docs/training/configure-compute#machine-types). For DeployedModel this field is optional, and the default value is 'n1-standard-2'. For BatchPredictionJob or as part of WorkerPoolSpec this field is required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#machine_type ColabSchedule#machine_type}
    */
    readonly machineType?: string;
    /**
    * The topology of the TPUs. Corresponds to the TPU topologies available from GKE. (Example: tpu_topology: "2x2x1").
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#tpu_topology ColabSchedule#tpu_topology}
    */
    readonly tpuTopology?: string;
    /**
    * reservation_affinity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#reservation_affinity ColabSchedule#reservation_affinity}
    */
    readonly reservationAffinity?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpecReservationAffinity;
}
export declare function colabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpecToTerraform(struct?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpecOutputReference | ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpec): any;
export declare function colabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpecToHclTerraform(struct?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpecOutputReference | ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpec): any;
export declare class ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpec | undefined;
    set internalValue(value: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpec | undefined);
    private _acceleratorCount?;
    get acceleratorCount(): number;
    set acceleratorCount(value: number);
    resetAcceleratorCount(): void;
    get acceleratorCountInput(): number | undefined;
    private _acceleratorType?;
    get acceleratorType(): string;
    set acceleratorType(value: string);
    resetAcceleratorType(): void;
    get acceleratorTypeInput(): string | undefined;
    private _gpuPartitionSize?;
    get gpuPartitionSize(): string;
    set gpuPartitionSize(value: string);
    resetGpuPartitionSize(): void;
    get gpuPartitionSizeInput(): string | undefined;
    private _machineType?;
    get machineType(): string;
    set machineType(value: string);
    resetMachineType(): void;
    get machineTypeInput(): string | undefined;
    private _tpuTopology?;
    get tpuTopology(): string;
    set tpuTopology(value: string);
    resetTpuTopology(): void;
    get tpuTopologyInput(): string | undefined;
    private _reservationAffinity;
    get reservationAffinity(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpecReservationAffinityOutputReference;
    putReservationAffinity(value: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpecReservationAffinity): void;
    resetReservationAffinity(): void;
    get reservationAffinityInput(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpecReservationAffinity | undefined;
}
export interface ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecNetworkSpec {
    /**
    * Whether to enable public internet access. Default false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#enable_internet_access ColabSchedule#enable_internet_access}
    */
    readonly enableInternetAccess?: boolean | cdktn.IResolvable;
    /**
    * The full name of the Google Compute Engine [network](https://cloud.google.com//compute/docs/networks-and-firewalls#networks)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#network ColabSchedule#network}
    */
    readonly network?: string;
    /**
    * The name of the subnet that this instance is in. Format: 'projects/{project_id_or_number}/regions/{region}/subnetworks/{subnetwork_id}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#subnetwork ColabSchedule#subnetwork}
    */
    readonly subnetwork?: string;
}
export declare function colabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecNetworkSpecToTerraform(struct?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecNetworkSpecOutputReference | ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecNetworkSpec): any;
export declare function colabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecNetworkSpecToHclTerraform(struct?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecNetworkSpecOutputReference | ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecNetworkSpec): any;
export declare class ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecNetworkSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecNetworkSpec | undefined;
    set internalValue(value: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecNetworkSpec | undefined);
    private _enableInternetAccess?;
    get enableInternetAccess(): boolean | cdktn.IResolvable;
    set enableInternetAccess(value: boolean | cdktn.IResolvable);
    resetEnableInternetAccess(): void;
    get enableInternetAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _network?;
    get network(): string;
    set network(value: string);
    resetNetwork(): void;
    get networkInput(): string | undefined;
    private _subnetwork?;
    get subnetwork(): string;
    set subnetwork(value: string);
    resetSubnetwork(): void;
    get subnetworkInput(): string | undefined;
}
export interface ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecPersistentDiskSpec {
    /**
    * Size in GB of the disk (default is 100GB).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#disk_size_gb ColabSchedule#disk_size_gb}
    */
    readonly diskSizeGb?: string;
    /**
    * Type of the disk (default is "pd-standard"). Valid values: "pd-ssd" (Persistent Disk Solid State Drive) "pd-standard" (Persistent Disk Hard Disk Drive) "pd-balanced" (Balanced Persistent Disk) "pd-extreme" (Extreme Persistent Disk)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#disk_type ColabSchedule#disk_type}
    */
    readonly diskType?: string;
}
export declare function colabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecPersistentDiskSpecToTerraform(struct?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecPersistentDiskSpecOutputReference | ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecPersistentDiskSpec): any;
export declare function colabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecPersistentDiskSpecToHclTerraform(struct?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecPersistentDiskSpecOutputReference | ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecPersistentDiskSpec): any;
export declare class ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecPersistentDiskSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecPersistentDiskSpec | undefined;
    set internalValue(value: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecPersistentDiskSpec | undefined);
    private _diskSizeGb?;
    get diskSizeGb(): string;
    set diskSizeGb(value: string);
    resetDiskSizeGb(): void;
    get diskSizeGbInput(): string | undefined;
    private _diskType?;
    get diskType(): string;
    set diskType(value: string);
    resetDiskType(): void;
    get diskTypeInput(): string | undefined;
}
export interface ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpec {
    /**
    * machine_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#machine_spec ColabSchedule#machine_spec}
    */
    readonly machineSpec?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpec;
    /**
    * network_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#network_spec ColabSchedule#network_spec}
    */
    readonly networkSpec?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecNetworkSpec;
    /**
    * persistent_disk_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#persistent_disk_spec ColabSchedule#persistent_disk_spec}
    */
    readonly persistentDiskSpec?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecPersistentDiskSpec;
}
export declare function colabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecToTerraform(struct?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecOutputReference | ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpec): any;
export declare function colabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecToHclTerraform(struct?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecOutputReference | ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpec): any;
export declare class ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpec | undefined;
    set internalValue(value: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpec | undefined);
    private _machineSpec;
    get machineSpec(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpecOutputReference;
    putMachineSpec(value: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpec): void;
    resetMachineSpec(): void;
    get machineSpecInput(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecMachineSpec | undefined;
    private _networkSpec;
    get networkSpec(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecNetworkSpecOutputReference;
    putNetworkSpec(value: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecNetworkSpec): void;
    resetNetworkSpec(): void;
    get networkSpecInput(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecNetworkSpec | undefined;
    private _persistentDiskSpec;
    get persistentDiskSpec(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecPersistentDiskSpecOutputReference;
    putPersistentDiskSpec(value: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecPersistentDiskSpec): void;
    resetPersistentDiskSpec(): void;
    get persistentDiskSpecInput(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecPersistentDiskSpec | undefined;
}
export interface ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobDataformRepositorySource {
    /**
    * The commit SHA to read repository with. If unset, the file will be read at HEAD.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#commit_sha ColabSchedule#commit_sha}
    */
    readonly commitSha?: string;
    /**
    * The resource name of the Dataform Repository. Format: 'projects/{project_id}/locations/{location}/repositories/{repository_id}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#dataform_repository_resource_name ColabSchedule#dataform_repository_resource_name}
    */
    readonly dataformRepositoryResourceName: string;
}
export declare function colabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobDataformRepositorySourceToTerraform(struct?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobDataformRepositorySourceOutputReference | ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobDataformRepositorySource): any;
export declare function colabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobDataformRepositorySourceToHclTerraform(struct?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobDataformRepositorySourceOutputReference | ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobDataformRepositorySource): any;
export declare class ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobDataformRepositorySourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobDataformRepositorySource | undefined;
    set internalValue(value: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobDataformRepositorySource | undefined);
    private _commitSha?;
    get commitSha(): string;
    set commitSha(value: string);
    resetCommitSha(): void;
    get commitShaInput(): string | undefined;
    private _dataformRepositoryResourceName?;
    get dataformRepositoryResourceName(): string;
    set dataformRepositoryResourceName(value: string);
    get dataformRepositoryResourceNameInput(): string | undefined;
}
export interface ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobEncryptionSpec {
    /**
    * Resource name of the Cloud KMS key used to protect the resource. The Cloud KMS key must be in the same region as the resource. It must have the format 'projects/{project}/locations/{location}/keyRings/{key_ring}/cryptoKeys/{crypto_key}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#kms_key_name ColabSchedule#kms_key_name}
    */
    readonly kmsKeyName: string;
}
export declare function colabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobEncryptionSpecToTerraform(struct?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobEncryptionSpecOutputReference | ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobEncryptionSpec): any;
export declare function colabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobEncryptionSpecToHclTerraform(struct?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobEncryptionSpecOutputReference | ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobEncryptionSpec): any;
export declare class ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobEncryptionSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobEncryptionSpec | undefined;
    set internalValue(value: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobEncryptionSpec | undefined);
    private _kmsKeyName?;
    get kmsKeyName(): string;
    set kmsKeyName(value: string);
    get kmsKeyNameInput(): string | undefined;
}
export interface ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobGcsNotebookSource {
    /**
    * The version of the Cloud Storage object to read. If unset, the current version of the object is read. See https://cloud.google.com/storage/docs/metadata#generation-number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#generation ColabSchedule#generation}
    */
    readonly generation?: string;
    /**
    * The Cloud Storage uri pointing to the ipynb file. Format: gs://bucket/notebook_file.ipynb
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#uri ColabSchedule#uri}
    */
    readonly uri: string;
}
export declare function colabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobGcsNotebookSourceToTerraform(struct?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobGcsNotebookSourceOutputReference | ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobGcsNotebookSource): any;
export declare function colabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobGcsNotebookSourceToHclTerraform(struct?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobGcsNotebookSourceOutputReference | ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobGcsNotebookSource): any;
export declare class ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobGcsNotebookSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobGcsNotebookSource | undefined;
    set internalValue(value: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobGcsNotebookSource | undefined);
    private _generation?;
    get generation(): string;
    set generation(value: string);
    resetGeneration(): void;
    get generationInput(): string | undefined;
    private _uri?;
    get uri(): string;
    set uri(value: string);
    get uriInput(): string | undefined;
}
export interface ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobWorkbenchRuntime {
}
export declare function colabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobWorkbenchRuntimeToTerraform(struct?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobWorkbenchRuntimeOutputReference | ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobWorkbenchRuntime): any;
export declare function colabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobWorkbenchRuntimeToHclTerraform(struct?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobWorkbenchRuntimeOutputReference | ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobWorkbenchRuntime): any;
export declare class ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobWorkbenchRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobWorkbenchRuntime | undefined;
    set internalValue(value: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobWorkbenchRuntime | undefined);
}
export interface ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJob {
    /**
    * Required. The display name of the Notebook Execution.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#display_name ColabSchedule#display_name}
    */
    readonly displayName: string;
    /**
    * Max running time of the execution job in seconds (default 86400s / 24 hrs). A duration in seconds with up to nine fractional digits, ending with "s". Example: "3.5s".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#execution_timeout ColabSchedule#execution_timeout}
    */
    readonly executionTimeout?: string;
    /**
    * The user email to run the execution as.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#execution_user ColabSchedule#execution_user}
    */
    readonly executionUser?: string;
    /**
    * The Cloud Storage location to upload the result to. Format:'gs://bucket-name'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#gcs_output_uri ColabSchedule#gcs_output_uri}
    */
    readonly gcsOutputUri: string;
    /**
    * The name of the kernel to use during notebook execution. If unset, the default kernel is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#kernel_name ColabSchedule#kernel_name}
    */
    readonly kernelName?: string;
    /**
    * The labels with user-defined metadata to organize NotebookExecutionJobs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#labels ColabSchedule#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The NotebookRuntimeTemplate to source compute configuration from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#notebook_runtime_template_resource_name ColabSchedule#notebook_runtime_template_resource_name}
    */
    readonly notebookRuntimeTemplateResourceName?: string;
    /**
    * The service account to run the execution as.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#service_account ColabSchedule#service_account}
    */
    readonly serviceAccount?: string;
    /**
    * custom_environment_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#custom_environment_spec ColabSchedule#custom_environment_spec}
    */
    readonly customEnvironmentSpec?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpec;
    /**
    * dataform_repository_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#dataform_repository_source ColabSchedule#dataform_repository_source}
    */
    readonly dataformRepositorySource?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobDataformRepositorySource;
    /**
    * encryption_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#encryption_spec ColabSchedule#encryption_spec}
    */
    readonly encryptionSpec?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobEncryptionSpec;
    /**
    * gcs_notebook_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#gcs_notebook_source ColabSchedule#gcs_notebook_source}
    */
    readonly gcsNotebookSource?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobGcsNotebookSource;
    /**
    * workbench_runtime block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#workbench_runtime ColabSchedule#workbench_runtime}
    */
    readonly workbenchRuntime?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobWorkbenchRuntime;
}
export declare function colabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobToTerraform(struct?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobOutputReference | ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJob): any;
export declare function colabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobToHclTerraform(struct?: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobOutputReference | ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJob): any;
export declare class ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJob | undefined;
    set internalValue(value: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJob | undefined);
    get createTime(): string;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _executionTimeout?;
    get executionTimeout(): string;
    set executionTimeout(value: string);
    resetExecutionTimeout(): void;
    get executionTimeoutInput(): string | undefined;
    private _executionUser?;
    get executionUser(): string;
    set executionUser(value: string);
    resetExecutionUser(): void;
    get executionUserInput(): string | undefined;
    private _gcsOutputUri?;
    get gcsOutputUri(): string;
    set gcsOutputUri(value: string);
    get gcsOutputUriInput(): string | undefined;
    get jobState(): string;
    private _kernelName?;
    get kernelName(): string;
    set kernelName(value: string);
    resetKernelName(): void;
    get kernelNameInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    get name(): string;
    private _notebookRuntimeTemplateResourceName?;
    get notebookRuntimeTemplateResourceName(): string;
    set notebookRuntimeTemplateResourceName(value: string);
    resetNotebookRuntimeTemplateResourceName(): void;
    get notebookRuntimeTemplateResourceNameInput(): string | undefined;
    get scheduleResourceName(): string;
    private _serviceAccount?;
    get serviceAccount(): string;
    set serviceAccount(value: string);
    resetServiceAccount(): void;
    get serviceAccountInput(): string | undefined;
    get updateTime(): string;
    private _customEnvironmentSpec;
    get customEnvironmentSpec(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpecOutputReference;
    putCustomEnvironmentSpec(value: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpec): void;
    resetCustomEnvironmentSpec(): void;
    get customEnvironmentSpecInput(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobCustomEnvironmentSpec | undefined;
    private _dataformRepositorySource;
    get dataformRepositorySource(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobDataformRepositorySourceOutputReference;
    putDataformRepositorySource(value: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobDataformRepositorySource): void;
    resetDataformRepositorySource(): void;
    get dataformRepositorySourceInput(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobDataformRepositorySource | undefined;
    private _encryptionSpec;
    get encryptionSpec(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobEncryptionSpecOutputReference;
    putEncryptionSpec(value: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobEncryptionSpec): void;
    resetEncryptionSpec(): void;
    get encryptionSpecInput(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobEncryptionSpec | undefined;
    private _gcsNotebookSource;
    get gcsNotebookSource(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobGcsNotebookSourceOutputReference;
    putGcsNotebookSource(value: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobGcsNotebookSource): void;
    resetGcsNotebookSource(): void;
    get gcsNotebookSourceInput(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobGcsNotebookSource | undefined;
    private _workbenchRuntime;
    get workbenchRuntime(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobWorkbenchRuntimeOutputReference;
    putWorkbenchRuntime(value: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobWorkbenchRuntime): void;
    resetWorkbenchRuntime(): void;
    get workbenchRuntimeInput(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobWorkbenchRuntime | undefined;
}
export interface ColabScheduleCreateNotebookExecutionJobRequest {
    /**
    * The resource name of the Location to create the NotebookExecutionJob. Format: 'projects/{project}/locations/{location}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#parent ColabSchedule#parent}
    */
    readonly parent?: string;
    /**
    * notebook_execution_job block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#notebook_execution_job ColabSchedule#notebook_execution_job}
    */
    readonly notebookExecutionJob: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJob;
}
export declare function colabScheduleCreateNotebookExecutionJobRequestToTerraform(struct?: ColabScheduleCreateNotebookExecutionJobRequestOutputReference | ColabScheduleCreateNotebookExecutionJobRequest): any;
export declare function colabScheduleCreateNotebookExecutionJobRequestToHclTerraform(struct?: ColabScheduleCreateNotebookExecutionJobRequestOutputReference | ColabScheduleCreateNotebookExecutionJobRequest): any;
export declare class ColabScheduleCreateNotebookExecutionJobRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabScheduleCreateNotebookExecutionJobRequest | undefined;
    set internalValue(value: ColabScheduleCreateNotebookExecutionJobRequest | undefined);
    get notebookExecutionJobId(): string;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    resetParent(): void;
    get parentInput(): string | undefined;
    private _notebookExecutionJob;
    get notebookExecutionJob(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJobOutputReference;
    putNotebookExecutionJob(value: ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJob): void;
    get notebookExecutionJobInput(): ColabScheduleCreateNotebookExecutionJobRequestNotebookExecutionJob | undefined;
}
export interface ColabScheduleCreatePipelineJobRequestPipelineJobTemplateMetadata {
}
export declare function colabScheduleCreatePipelineJobRequestPipelineJobTemplateMetadataToTerraform(struct?: ColabScheduleCreatePipelineJobRequestPipelineJobTemplateMetadata): any;
export declare function colabScheduleCreatePipelineJobRequestPipelineJobTemplateMetadataToHclTerraform(struct?: ColabScheduleCreatePipelineJobRequestPipelineJobTemplateMetadata): any;
export declare class ColabScheduleCreatePipelineJobRequestPipelineJobTemplateMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ColabScheduleCreatePipelineJobRequestPipelineJobTemplateMetadata | undefined;
    set internalValue(value: ColabScheduleCreatePipelineJobRequestPipelineJobTemplateMetadata | undefined);
    get version(): string;
}
export declare class ColabScheduleCreatePipelineJobRequestPipelineJobTemplateMetadataList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ColabScheduleCreatePipelineJobRequestPipelineJobTemplateMetadataOutputReference;
}
export interface ColabScheduleCreatePipelineJobRequestPipelineJobEncryptionSpec {
    /**
    * Resource name of the Cloud KMS key used to protect the resource. The Cloud KMS key must be in the same region as the resource. It must have the format 'projects/{project}/locations/{location}/keyRings/{key_ring}/cryptoKeys/{crypto_key}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#kms_key_name ColabSchedule#kms_key_name}
    */
    readonly kmsKeyName: string;
}
export declare function colabScheduleCreatePipelineJobRequestPipelineJobEncryptionSpecToTerraform(struct?: ColabScheduleCreatePipelineJobRequestPipelineJobEncryptionSpecOutputReference | ColabScheduleCreatePipelineJobRequestPipelineJobEncryptionSpec): any;
export declare function colabScheduleCreatePipelineJobRequestPipelineJobEncryptionSpecToHclTerraform(struct?: ColabScheduleCreatePipelineJobRequestPipelineJobEncryptionSpecOutputReference | ColabScheduleCreatePipelineJobRequestPipelineJobEncryptionSpec): any;
export declare class ColabScheduleCreatePipelineJobRequestPipelineJobEncryptionSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabScheduleCreatePipelineJobRequestPipelineJobEncryptionSpec | undefined;
    set internalValue(value: ColabScheduleCreatePipelineJobRequestPipelineJobEncryptionSpec | undefined);
    private _kmsKeyName?;
    get kmsKeyName(): string;
    set kmsKeyName(value: string);
    get kmsKeyNameInput(): string | undefined;
}
export interface ColabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfigDnsPeeringConfigs {
    /**
    * The DNS name suffix of the zone being peered to, e.g., "my-internal-domain.corp.". Must end with a dot.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#domain ColabSchedule#domain}
    */
    readonly domain: string;
    /**
    * The VPC network name in the target_project where the DNS zone specified by 'domain' is visible.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#target_network ColabSchedule#target_network}
    */
    readonly targetNetwork: string;
    /**
    * The project ID hosting the Cloud DNS managed zone that contains the 'domain'. The Vertex AI Service Agent requires the dns.peer role on this project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#target_project ColabSchedule#target_project}
    */
    readonly targetProject: string;
}
export declare function colabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfigDnsPeeringConfigsToTerraform(struct?: ColabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfigDnsPeeringConfigs | cdktn.IResolvable): any;
export declare function colabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfigDnsPeeringConfigsToHclTerraform(struct?: ColabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfigDnsPeeringConfigs | cdktn.IResolvable): any;
export declare class ColabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfigDnsPeeringConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ColabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfigDnsPeeringConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: ColabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfigDnsPeeringConfigs | cdktn.IResolvable | undefined);
    private _domain?;
    get domain(): string;
    set domain(value: string);
    get domainInput(): string | undefined;
    private _targetNetwork?;
    get targetNetwork(): string;
    set targetNetwork(value: string);
    get targetNetworkInput(): string | undefined;
    private _targetProject?;
    get targetProject(): string;
    set targetProject(value: string);
    get targetProjectInput(): string | undefined;
}
export declare class ColabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfigDnsPeeringConfigsList extends cdktn.ComplexList {
    internalValue?: ColabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfigDnsPeeringConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ColabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfigDnsPeeringConfigsOutputReference;
}
export interface ColabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfig {
    /**
    * The name of the Compute Engine [network attachment](https://cloud.google.com/vpc/docs/about-network-attachments) to attach to the resource within the region and user project. To specify this field, you must have already [created a network attachment] (https://cloud.google.com/vpc/docs/create-manage-network-attachments#create-network-attachments). This field is only used for resources using PSC-I.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#network_attachment ColabSchedule#network_attachment}
    */
    readonly networkAttachment?: string;
    /**
    * dns_peering_configs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#dns_peering_configs ColabSchedule#dns_peering_configs}
    */
    readonly dnsPeeringConfigs?: ColabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfigDnsPeeringConfigs[] | cdktn.IResolvable;
}
export declare function colabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfigToTerraform(struct?: ColabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfigOutputReference | ColabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfig): any;
export declare function colabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfigToHclTerraform(struct?: ColabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfigOutputReference | ColabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfig): any;
export declare class ColabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfig | undefined;
    set internalValue(value: ColabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfig | undefined);
    private _networkAttachment?;
    get networkAttachment(): string;
    set networkAttachment(value: string);
    resetNetworkAttachment(): void;
    get networkAttachmentInput(): string | undefined;
    private _dnsPeeringConfigs;
    get dnsPeeringConfigs(): ColabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfigDnsPeeringConfigsList;
    putDnsPeeringConfigs(value: ColabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfigDnsPeeringConfigs[] | cdktn.IResolvable): void;
    resetDnsPeeringConfigs(): void;
    get dnsPeeringConfigsInput(): cdktn.IResolvable | ColabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfigDnsPeeringConfigs[] | undefined;
}
export interface ColabScheduleCreatePipelineJobRequestPipelineJobRuntimeConfig {
    /**
    * Possible values: PIPELINE_FAILURE_POLICY_FAIL_SLOW PIPELINE_FAILURE_POLICY_FAIL_FAST
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#failure_policy ColabSchedule#failure_policy}
    */
    readonly failurePolicy?: string;
    /**
    * A path in a Cloud Storage bucket, which will be treated as the root output directory of the pipeline. It is used by the system to generate the paths of output artifacts. The artifact paths are generated with a sub-path pattern '{job_id}/{task_id}/{output_key}' under the specified output directory. The service account specified in this pipeline must have the 'storage.objects.get' and 'storage.objects.create' permissions for this bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#gcs_output_directory ColabSchedule#gcs_output_directory}
    */
    readonly gcsOutputDirectory: string;
    /**
    * The runtime parameters of the PipelineJob. The parameters will be passed into PipelineJob.pipeline_spec to replace the placeholders at runtime. This field is used by pipelines built using 'PipelineJob.pipeline_spec.schema_version' 2.1.0, such as pipelines built using Kubeflow Pipelines SDK 1.9 or higher and the v2 DSL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#parameter_values ColabSchedule#parameter_values}
    */
    readonly parameterValues?: {
        [key: string]: string;
    };
}
export declare function colabScheduleCreatePipelineJobRequestPipelineJobRuntimeConfigToTerraform(struct?: ColabScheduleCreatePipelineJobRequestPipelineJobRuntimeConfigOutputReference | ColabScheduleCreatePipelineJobRequestPipelineJobRuntimeConfig): any;
export declare function colabScheduleCreatePipelineJobRequestPipelineJobRuntimeConfigToHclTerraform(struct?: ColabScheduleCreatePipelineJobRequestPipelineJobRuntimeConfigOutputReference | ColabScheduleCreatePipelineJobRequestPipelineJobRuntimeConfig): any;
export declare class ColabScheduleCreatePipelineJobRequestPipelineJobRuntimeConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabScheduleCreatePipelineJobRequestPipelineJobRuntimeConfig | undefined;
    set internalValue(value: ColabScheduleCreatePipelineJobRequestPipelineJobRuntimeConfig | undefined);
    private _failurePolicy?;
    get failurePolicy(): string;
    set failurePolicy(value: string);
    resetFailurePolicy(): void;
    get failurePolicyInput(): string | undefined;
    private _gcsOutputDirectory?;
    get gcsOutputDirectory(): string;
    set gcsOutputDirectory(value: string);
    get gcsOutputDirectoryInput(): string | undefined;
    private _parameterValues?;
    get parameterValues(): {
        [key: string]: string;
    };
    set parameterValues(value: {
        [key: string]: string;
    });
    resetParameterValues(): void;
    get parameterValuesInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ColabScheduleCreatePipelineJobRequestPipelineJob {
    /**
    * The display name of the Pipeline. The name can be up to 128 characters long and can consist of any UTF-8 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#display_name ColabSchedule#display_name}
    */
    readonly displayName?: string;
    /**
    * The labels with user-defined metadata to organize PipelineJob. Label keys and values can be no longer than 64 characters (Unicode codepoints), can only contain lowercase letters, numeric characters, underscores and dashes. International characters are allowed. See https://goo.gl/xmQnxf for more information and examples of labels. Note there is some reserved label key for Vertex AI Pipelines. - 'vertex-ai-pipelines-run-billing-id', user set value will get overrided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#labels ColabSchedule#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The full name of the Compute Engine [network](/compute/docs/networks-and-firewalls#networks) to which the Pipeline Job's workload should be peered. For example, 'projects/12345/global/networks/myVPC'. [Format](/compute/docs/reference/rest/v1/networks/insert) is of the form 'projects/{project}/global/networks/{network}'. Where {project} is a project number, as in '12345', and {network} is a network name. Private services access must already be configured for the network. Pipeline job will apply the network configuration to the Google Cloud resources being launched, if applied, such as Vertex AI Training or Dataflow job. If left unspecified, the workload is not peered with any network.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#network ColabSchedule#network}
    */
    readonly network?: string;
    /**
    * A compiled definition of a pipeline, represented as a 'JSON' object. Defines the structure of the pipeline, including its components, tasks, and parameters. This specification is generated by compiling a pipeline function defined in 'Python' using the 'Kubeflow Pipelines SDK'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#pipeline_spec ColabSchedule#pipeline_spec}
    */
    readonly pipelineSpec?: string;
    /**
    * Whether to do component level validations before job creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#preflight_validations ColabSchedule#preflight_validations}
    */
    readonly preflightValidations?: boolean | cdktn.IResolvable;
    /**
    * A list of names for the reserved ip ranges under the VPC network that can be used for this Pipeline Job's workload. If set, we will deploy the Pipeline Job's workload within the provided ip ranges. Otherwise, the job will be deployed to any ip ranges under the provided VPC network. Example: ['vertex-ai-ip-range'].
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#reserved_ip_ranges ColabSchedule#reserved_ip_ranges}
    */
    readonly reservedIpRanges?: string[];
    /**
    * The service account that the pipeline workload runs as. If not specified, the Compute Engine default service account in the project will be used. See https://cloud.google.com/compute/docs/access/service-accounts#default_service_account Users starting the pipeline must have the 'iam.serviceAccounts.actAs' permission on this service account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#service_account ColabSchedule#service_account}
    */
    readonly serviceAccount?: string;
    /**
    * A template uri from where the PipelineJob.pipeline_spec, if empty, will be downloaded. Currently, only uri from Vertex Template Registry & Gallery is supported. Reference to https://cloud.google.com/vertex-ai/docs/pipelines/create-pipeline-template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#template_uri ColabSchedule#template_uri}
    */
    readonly templateUri?: string;
    /**
    * encryption_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#encryption_spec ColabSchedule#encryption_spec}
    */
    readonly encryptionSpec?: ColabScheduleCreatePipelineJobRequestPipelineJobEncryptionSpec;
    /**
    * psc_interface_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#psc_interface_config ColabSchedule#psc_interface_config}
    */
    readonly pscInterfaceConfig?: ColabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfig;
    /**
    * runtime_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#runtime_config ColabSchedule#runtime_config}
    */
    readonly runtimeConfig?: ColabScheduleCreatePipelineJobRequestPipelineJobRuntimeConfig;
}
export declare function colabScheduleCreatePipelineJobRequestPipelineJobToTerraform(struct?: ColabScheduleCreatePipelineJobRequestPipelineJobOutputReference | ColabScheduleCreatePipelineJobRequestPipelineJob): any;
export declare function colabScheduleCreatePipelineJobRequestPipelineJobToHclTerraform(struct?: ColabScheduleCreatePipelineJobRequestPipelineJobOutputReference | ColabScheduleCreatePipelineJobRequestPipelineJob): any;
export declare class ColabScheduleCreatePipelineJobRequestPipelineJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabScheduleCreatePipelineJobRequestPipelineJob | undefined;
    set internalValue(value: ColabScheduleCreatePipelineJobRequestPipelineJob | undefined);
    get createTime(): string;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    get endTime(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    get name(): string;
    private _network?;
    get network(): string;
    set network(value: string);
    resetNetwork(): void;
    get networkInput(): string | undefined;
    private _pipelineSpec?;
    get pipelineSpec(): string;
    set pipelineSpec(value: string);
    resetPipelineSpec(): void;
    get pipelineSpecInput(): string | undefined;
    private _preflightValidations?;
    get preflightValidations(): boolean | cdktn.IResolvable;
    set preflightValidations(value: boolean | cdktn.IResolvable);
    resetPreflightValidations(): void;
    get preflightValidationsInput(): boolean | cdktn.IResolvable | undefined;
    private _reservedIpRanges?;
    get reservedIpRanges(): string[];
    set reservedIpRanges(value: string[]);
    resetReservedIpRanges(): void;
    get reservedIpRangesInput(): string[] | undefined;
    get scheduleName(): string;
    private _serviceAccount?;
    get serviceAccount(): string;
    set serviceAccount(value: string);
    resetServiceAccount(): void;
    get serviceAccountInput(): string | undefined;
    get startTime(): string;
    get state(): string;
    private _templateMetadata;
    get templateMetadata(): ColabScheduleCreatePipelineJobRequestPipelineJobTemplateMetadataList;
    private _templateUri?;
    get templateUri(): string;
    set templateUri(value: string);
    resetTemplateUri(): void;
    get templateUriInput(): string | undefined;
    get updateTime(): string;
    private _encryptionSpec;
    get encryptionSpec(): ColabScheduleCreatePipelineJobRequestPipelineJobEncryptionSpecOutputReference;
    putEncryptionSpec(value: ColabScheduleCreatePipelineJobRequestPipelineJobEncryptionSpec): void;
    resetEncryptionSpec(): void;
    get encryptionSpecInput(): ColabScheduleCreatePipelineJobRequestPipelineJobEncryptionSpec | undefined;
    private _pscInterfaceConfig;
    get pscInterfaceConfig(): ColabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfigOutputReference;
    putPscInterfaceConfig(value: ColabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfig): void;
    resetPscInterfaceConfig(): void;
    get pscInterfaceConfigInput(): ColabScheduleCreatePipelineJobRequestPipelineJobPscInterfaceConfig | undefined;
    private _runtimeConfig;
    get runtimeConfig(): ColabScheduleCreatePipelineJobRequestPipelineJobRuntimeConfigOutputReference;
    putRuntimeConfig(value: ColabScheduleCreatePipelineJobRequestPipelineJobRuntimeConfig): void;
    resetRuntimeConfig(): void;
    get runtimeConfigInput(): ColabScheduleCreatePipelineJobRequestPipelineJobRuntimeConfig | undefined;
}
export interface ColabScheduleCreatePipelineJobRequest {
    /**
    * The resource name of the Location to create the PipelineJob in. Format: 'projects/{project}/locations/{location}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#parent ColabSchedule#parent}
    */
    readonly parent?: string;
    /**
    * pipeline_job block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#pipeline_job ColabSchedule#pipeline_job}
    */
    readonly pipelineJob: ColabScheduleCreatePipelineJobRequestPipelineJob;
}
export declare function colabScheduleCreatePipelineJobRequestToTerraform(struct?: ColabScheduleCreatePipelineJobRequestOutputReference | ColabScheduleCreatePipelineJobRequest): any;
export declare function colabScheduleCreatePipelineJobRequestToHclTerraform(struct?: ColabScheduleCreatePipelineJobRequestOutputReference | ColabScheduleCreatePipelineJobRequest): any;
export declare class ColabScheduleCreatePipelineJobRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabScheduleCreatePipelineJobRequest | undefined;
    set internalValue(value: ColabScheduleCreatePipelineJobRequest | undefined);
    private _parent?;
    get parent(): string;
    set parent(value: string);
    resetParent(): void;
    get parentInput(): string | undefined;
    get pipelineJobId(): string;
    private _pipelineJob;
    get pipelineJob(): ColabScheduleCreatePipelineJobRequestPipelineJobOutputReference;
    putPipelineJob(value: ColabScheduleCreatePipelineJobRequestPipelineJob): void;
    get pipelineJobInput(): ColabScheduleCreatePipelineJobRequestPipelineJob | undefined;
}
export interface ColabScheduleTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#create ColabSchedule#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#delete ColabSchedule#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#update ColabSchedule#update}
    */
    readonly update?: string;
}
export declare function colabScheduleTimeoutsToTerraform(struct?: ColabScheduleTimeouts | cdktn.IResolvable): any;
export declare function colabScheduleTimeoutsToHclTerraform(struct?: ColabScheduleTimeouts | cdktn.IResolvable): any;
export declare class ColabScheduleTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabScheduleTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ColabScheduleTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule google_colab_schedule}
*/
export declare class ColabSchedule extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_colab_schedule";
    /**
    * Generates CDKTN code for importing a ColabSchedule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ColabSchedule to import
    * @param importFromId The id of the existing ColabSchedule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ColabSchedule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_schedule google_colab_schedule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ColabScheduleConfig
    */
    constructor(scope: Construct, id: string, config: ColabScheduleConfig);
    private _allowQueueing?;
    get allowQueueing(): boolean | cdktn.IResolvable;
    set allowQueueing(value: boolean | cdktn.IResolvable);
    resetAllowQueueing(): void;
    get allowQueueingInput(): boolean | cdktn.IResolvable | undefined;
    get catchUp(): cdktn.IResolvable;
    get createTime(): string;
    private _cron?;
    get cron(): string;
    set cron(value: string);
    get cronInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _desiredState?;
    get desiredState(): string;
    set desiredState(value: string);
    resetDesiredState(): void;
    get desiredStateInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _endTime?;
    get endTime(): string;
    set endTime(value: string);
    resetEndTime(): void;
    get endTimeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastPauseTime(): string;
    get lastResumeTime(): string;
    private _lastScheduledRunResponse;
    get lastScheduledRunResponse(): ColabScheduleLastScheduledRunResponseList;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _maxConcurrentActiveRunCount?;
    get maxConcurrentActiveRunCount(): string;
    set maxConcurrentActiveRunCount(value: string);
    resetMaxConcurrentActiveRunCount(): void;
    get maxConcurrentActiveRunCountInput(): string | undefined;
    private _maxConcurrentRunCount?;
    get maxConcurrentRunCount(): string;
    set maxConcurrentRunCount(value: string);
    get maxConcurrentRunCountInput(): string | undefined;
    private _maxRunCount?;
    get maxRunCount(): string;
    set maxRunCount(value: string);
    resetMaxRunCount(): void;
    get maxRunCountInput(): string | undefined;
    get name(): string;
    get nextRunTime(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    resetStartTime(): void;
    get startTimeInput(): string | undefined;
    get startedRunCount(): string;
    get state(): string;
    get updateTime(): string;
    private _createNotebookExecutionJobRequest;
    get createNotebookExecutionJobRequest(): ColabScheduleCreateNotebookExecutionJobRequestOutputReference;
    putCreateNotebookExecutionJobRequest(value: ColabScheduleCreateNotebookExecutionJobRequest): void;
    resetCreateNotebookExecutionJobRequest(): void;
    get createNotebookExecutionJobRequestInput(): ColabScheduleCreateNotebookExecutionJobRequest | undefined;
    private _createPipelineJobRequest;
    get createPipelineJobRequest(): ColabScheduleCreatePipelineJobRequestOutputReference;
    putCreatePipelineJobRequest(value: ColabScheduleCreatePipelineJobRequest): void;
    resetCreatePipelineJobRequest(): void;
    get createPipelineJobRequestInput(): ColabScheduleCreatePipelineJobRequest | undefined;
    private _timeouts;
    get timeouts(): ColabScheduleTimeoutsOutputReference;
    putTimeouts(value: ColabScheduleTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ColabScheduleTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
