/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeSslPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Profile specifies the set of SSL features that can be used by the
    * load balancer when negotiating SSL with clients. This can be one of
    * 'COMPATIBLE', 'MODERN', 'RESTRICTED', or 'CUSTOM'. If using 'CUSTOM',
    * the set of SSL features to enable must be specified in the
    * 'customFeatures' field.
    *
    * See the [official documentation](https://cloud.google.com/compute/docs/load-balancing/ssl-policies#profilefeaturesupport)
    * for which ciphers are available to use. **Note**: this argument
    * *must* be present when using the 'CUSTOM' profile. This argument
    * *must not* be present when using any other profile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_ssl_policy#custom_features ComputeSslPolicy#custom_features}
    */
    readonly customFeatures?: string[];
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_ssl_policy#deletion_policy ComputeSslPolicy#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_ssl_policy#description ComputeSslPolicy#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_ssl_policy#id ComputeSslPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The minimum version of SSL protocol that can be used by the clients
    * to establish a connection with the load balancer. When set to'
    * TLS_1_3', the profile field must be set to 'RESTRICTED'. Default value: "TLS_1_0" Possible values: ["TLS_1_0", "TLS_1_1", "TLS_1_2", "TLS_1_3"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_ssl_policy#min_tls_version ComputeSslPolicy#min_tls_version}
    */
    readonly minTlsVersion?: string;
    /**
    * Name of the resource. Provided by the client when the resource is
    * created. The name must be 1-63 characters long, and comply with
    * RFC1035. Specifically, the name must be 1-63 characters long and match
    * the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the
    * first character must be a lowercase letter, and all following
    * characters must be a dash, lowercase letter, or digit, except the last
    * character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_ssl_policy#name ComputeSslPolicy#name}
    */
    readonly name: string;
    /**
    * One of 'DEFAULT', 'ENABLED', or 'DEFERRED'. Controls whether the load balancer
    * negotiates X25519MLKEM768 key exchange when clients advertise support for it.
    * When set to 'DEFAULT', or if no SSL Policy is attached to
    * the target proxy, the load balancer disallows X25519MLKEM768 key
    * exchange before October 2026, and allows it afterward. When set to
    * 'ENABLED', the load balancer allows X25519MLKEM768 key
    * exchange. When set to 'DEFERRED', the load balancer
    * disallows X25519MLKEM768 key exchange until October 2027, and allows
    * it afterward. Possible values: ["DEFAULT", "ENABLED", "DEFERRED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_ssl_policy#post_quantum_key_exchange ComputeSslPolicy#post_quantum_key_exchange}
    */
    readonly postQuantumKeyExchange?: string;
    /**
    * Profile specifies the set of SSL features that can be used by the
    * load balancer when negotiating SSL with clients. If using 'CUSTOM',
    * the set of SSL features to enable must be specified in the
    * 'customFeatures' field.
    *
    * See the [official documentation](https://cloud.google.com/compute/docs/load-balancing/ssl-policies#profilefeaturesupport)
    * for information on what cipher suites each profile provides. If
    * 'CUSTOM' is used, the 'custom_features' attribute **must be set**.
    * If set to 'FIPS_202205', 'minTlsVersion' must also be set to
    * 'TLS_1_2'. Default value: "COMPATIBLE" Possible values: ["COMPATIBLE", "MODERN", "RESTRICTED", "CUSTOM", "FIPS_202205"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_ssl_policy#profile ComputeSslPolicy#profile}
    */
    readonly profile?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_ssl_policy#project ComputeSslPolicy#project}
    */
    readonly project?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_ssl_policy#timeouts ComputeSslPolicy#timeouts}
    */
    readonly timeouts?: ComputeSslPolicyTimeouts;
}
export interface ComputeSslPolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_ssl_policy#create ComputeSslPolicy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_ssl_policy#delete ComputeSslPolicy#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_ssl_policy#update ComputeSslPolicy#update}
    */
    readonly update?: string;
}
export declare function computeSslPolicyTimeoutsToTerraform(struct?: ComputeSslPolicyTimeouts | cdktn.IResolvable): any;
export declare function computeSslPolicyTimeoutsToHclTerraform(struct?: ComputeSslPolicyTimeouts | cdktn.IResolvable): any;
export declare class ComputeSslPolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSslPolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeSslPolicyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_ssl_policy google_compute_ssl_policy}
*/
export declare class ComputeSslPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_ssl_policy";
    /**
    * Generates CDKTN code for importing a ComputeSslPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeSslPolicy to import
    * @param importFromId The id of the existing ComputeSslPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_ssl_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeSslPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_ssl_policy google_compute_ssl_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeSslPolicyConfig
    */
    constructor(scope: Construct, id: string, config: ComputeSslPolicyConfig);
    get creationTimestamp(): string;
    private _customFeatures?;
    get customFeatures(): string[];
    set customFeatures(value: string[]);
    resetCustomFeatures(): void;
    get customFeaturesInput(): string[] | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get enabledFeatures(): string[];
    get fingerprint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _minTlsVersion?;
    get minTlsVersion(): string;
    set minTlsVersion(value: string);
    resetMinTlsVersion(): void;
    get minTlsVersionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _postQuantumKeyExchange?;
    get postQuantumKeyExchange(): string;
    set postQuantumKeyExchange(value: string);
    resetPostQuantumKeyExchange(): void;
    get postQuantumKeyExchangeInput(): string | undefined;
    private _profile?;
    get profile(): string;
    set profile(value: string);
    resetProfile(): void;
    get profileInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get selfLink(): string;
    private _timeouts;
    get timeouts(): ComputeSslPolicyTimeoutsOutputReference;
    putTimeouts(value: ComputeSslPolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeSslPolicyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
