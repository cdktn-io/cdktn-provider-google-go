/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BigtableMemoryLayerConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the cluster to enable the memory layer on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_memory_layer#cluster BigtableMemoryLayer#cluster}
    */
    readonly cluster: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_memory_layer#deletion_policy BigtableMemoryLayer#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_memory_layer#id BigtableMemoryLayer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the instance to enable the memory layer within.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_memory_layer#instance BigtableMemoryLayer#instance}
    */
    readonly instance: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_memory_layer#project BigtableMemoryLayer#project}
    */
    readonly project?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_memory_layer#timeouts BigtableMemoryLayer#timeouts}
    */
    readonly timeouts?: BigtableMemoryLayerTimeouts;
}
export interface BigtableMemoryLayerMemoryConfig {
}
export declare function bigtableMemoryLayerMemoryConfigToTerraform(struct?: BigtableMemoryLayerMemoryConfig): any;
export declare function bigtableMemoryLayerMemoryConfigToHclTerraform(struct?: BigtableMemoryLayerMemoryConfig): any;
export declare class BigtableMemoryLayerMemoryConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BigtableMemoryLayerMemoryConfig | undefined;
    set internalValue(value: BigtableMemoryLayerMemoryConfig | undefined);
    get storageSizeGib(): number;
}
export declare class BigtableMemoryLayerMemoryConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BigtableMemoryLayerMemoryConfigOutputReference;
}
export interface BigtableMemoryLayerTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_memory_layer#create BigtableMemoryLayer#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_memory_layer#delete BigtableMemoryLayer#delete}
    */
    readonly delete?: string;
}
export declare function bigtableMemoryLayerTimeoutsToTerraform(struct?: BigtableMemoryLayerTimeouts | cdktn.IResolvable): any;
export declare function bigtableMemoryLayerTimeoutsToHclTerraform(struct?: BigtableMemoryLayerTimeouts | cdktn.IResolvable): any;
export declare class BigtableMemoryLayerTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigtableMemoryLayerTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BigtableMemoryLayerTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_memory_layer google_bigtable_memory_layer}
*/
export declare class BigtableMemoryLayer extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_bigtable_memory_layer";
    /**
    * Generates CDKTN code for importing a BigtableMemoryLayer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BigtableMemoryLayer to import
    * @param importFromId The id of the existing BigtableMemoryLayer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_memory_layer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BigtableMemoryLayer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_memory_layer google_bigtable_memory_layer} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BigtableMemoryLayerConfig
    */
    constructor(scope: Construct, id: string, config: BigtableMemoryLayerConfig);
    private _cluster?;
    get cluster(): string;
    set cluster(value: string);
    get clusterInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instance?;
    get instance(): string;
    set instance(value: string);
    get instanceInput(): string | undefined;
    private _memoryConfig;
    get memoryConfig(): BigtableMemoryLayerMemoryConfigList;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get state(): string;
    private _timeouts;
    get timeouts(): BigtableMemoryLayerTimeoutsOutputReference;
    putTimeouts(value: BigtableMemoryLayerTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BigtableMemoryLayerTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
