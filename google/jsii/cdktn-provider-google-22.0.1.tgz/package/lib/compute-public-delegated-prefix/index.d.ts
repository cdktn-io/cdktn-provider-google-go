/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputePublicDelegatedPrefixConfig extends cdktn.TerraformMetaArguments {
    /**
    * The allocatable prefix length supported by this public delegated prefix. This field is optional and cannot be set for prefixes in DELEGATION mode. It cannot be set for IPv4 prefixes either, and it always defaults to 32.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_public_delegated_prefix#allocatable_prefix_length ComputePublicDelegatedPrefix#allocatable_prefix_length}
    */
    readonly allocatablePrefixLength?: number;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_public_delegated_prefix#deletion_policy ComputePublicDelegatedPrefix#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_public_delegated_prefix#description ComputePublicDelegatedPrefix#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_public_delegated_prefix#id ComputePublicDelegatedPrefix#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The IP address range, in CIDR format, represented by this public delegated prefix.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_public_delegated_prefix#ip_cidr_range ComputePublicDelegatedPrefix#ip_cidr_range}
    */
    readonly ipCidrRange: string;
    /**
    * If true, the prefix will be live migrated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_public_delegated_prefix#is_live_migration ComputePublicDelegatedPrefix#is_live_migration}
    */
    readonly isLiveMigration?: boolean | cdktn.IResolvable;
    /**
    * Specifies the mode of this IPv6 PDP. MODE must be one of:
    *   * DELEGATION
    *   * EXTERNAL_IPV6_FORWARDING_RULE_CREATION
    *   * EXTERNAL_IPV6_SUBNETWORK_CREATION
    *   * INTERNAL_IPV6_SUBNETWORK_CREATION Possible values: ["DELEGATION", "EXTERNAL_IPV6_FORWARDING_RULE_CREATION", "EXTERNAL_IPV6_SUBNETWORK_CREATION", "INTERNAL_IPV6_SUBNETWORK_CREATION"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_public_delegated_prefix#mode ComputePublicDelegatedPrefix#mode}
    */
    readonly mode?: string;
    /**
    * Name of the resource. The name must be 1-63 characters long, and
    * comply with RFC1035. Specifically, the name must be 1-63 characters
    * long and match the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?'
    * which means the first character must be a lowercase letter, and all
    * following characters must be a dash, lowercase letter, or digit,
    * except the last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_public_delegated_prefix#name ComputePublicDelegatedPrefix#name}
    */
    readonly name: string;
    /**
    * The URL of parent prefix. Either PublicAdvertisedPrefix or PublicDelegatedPrefix.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_public_delegated_prefix#parent_prefix ComputePublicDelegatedPrefix#parent_prefix}
    */
    readonly parentPrefix: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_public_delegated_prefix#project ComputePublicDelegatedPrefix#project}
    */
    readonly project?: string;
    /**
    * A region where the prefix will reside.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_public_delegated_prefix#region ComputePublicDelegatedPrefix#region}
    */
    readonly region: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_public_delegated_prefix#timeouts ComputePublicDelegatedPrefix#timeouts}
    */
    readonly timeouts?: ComputePublicDelegatedPrefixTimeouts;
}
export interface ComputePublicDelegatedPrefixPublicDelegatedSubPrefixs {
}
export declare function computePublicDelegatedPrefixPublicDelegatedSubPrefixsToTerraform(struct?: ComputePublicDelegatedPrefixPublicDelegatedSubPrefixs): any;
export declare function computePublicDelegatedPrefixPublicDelegatedSubPrefixsToHclTerraform(struct?: ComputePublicDelegatedPrefixPublicDelegatedSubPrefixs): any;
export declare class ComputePublicDelegatedPrefixPublicDelegatedSubPrefixsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputePublicDelegatedPrefixPublicDelegatedSubPrefixs | undefined;
    set internalValue(value: ComputePublicDelegatedPrefixPublicDelegatedSubPrefixs | undefined);
    get allocatablePrefixLength(): number;
    get delegateeProject(): string;
    get description(): string;
    get enableEnhancedIpv4Allocation(): cdktn.IResolvable;
    get ipCidrRange(): string;
    get ipv6AccessType(): string;
    get isAddress(): cdktn.IResolvable;
    get mode(): string;
    get name(): string;
    get region(): string;
    get status(): string;
}
export declare class ComputePublicDelegatedPrefixPublicDelegatedSubPrefixsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputePublicDelegatedPrefixPublicDelegatedSubPrefixsOutputReference;
}
export interface ComputePublicDelegatedPrefixTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_public_delegated_prefix#create ComputePublicDelegatedPrefix#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_public_delegated_prefix#delete ComputePublicDelegatedPrefix#delete}
    */
    readonly delete?: string;
}
export declare function computePublicDelegatedPrefixTimeoutsToTerraform(struct?: ComputePublicDelegatedPrefixTimeouts | cdktn.IResolvable): any;
export declare function computePublicDelegatedPrefixTimeoutsToHclTerraform(struct?: ComputePublicDelegatedPrefixTimeouts | cdktn.IResolvable): any;
export declare class ComputePublicDelegatedPrefixTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputePublicDelegatedPrefixTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputePublicDelegatedPrefixTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_public_delegated_prefix google_compute_public_delegated_prefix}
*/
export declare class ComputePublicDelegatedPrefix extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_public_delegated_prefix";
    /**
    * Generates CDKTN code for importing a ComputePublicDelegatedPrefix resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputePublicDelegatedPrefix to import
    * @param importFromId The id of the existing ComputePublicDelegatedPrefix that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_public_delegated_prefix#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputePublicDelegatedPrefix to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_public_delegated_prefix google_compute_public_delegated_prefix} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputePublicDelegatedPrefixConfig
    */
    constructor(scope: Construct, id: string, config: ComputePublicDelegatedPrefixConfig);
    private _allocatablePrefixLength?;
    get allocatablePrefixLength(): number;
    set allocatablePrefixLength(value: number);
    resetAllocatablePrefixLength(): void;
    get allocatablePrefixLengthInput(): number | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get enableEnhancedIpv4Allocation(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipCidrRange?;
    get ipCidrRange(): string;
    set ipCidrRange(value: string);
    get ipCidrRangeInput(): string | undefined;
    get ipv6AccessType(): string;
    private _isLiveMigration?;
    get isLiveMigration(): boolean | cdktn.IResolvable;
    set isLiveMigration(value: boolean | cdktn.IResolvable);
    resetIsLiveMigration(): void;
    get isLiveMigrationInput(): boolean | cdktn.IResolvable | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parentPrefix?;
    get parentPrefix(): string;
    set parentPrefix(value: string);
    get parentPrefixInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _publicDelegatedSubPrefixs;
    get publicDelegatedSubPrefixs(): ComputePublicDelegatedPrefixPublicDelegatedSubPrefixsList;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    get selfLink(): string;
    private _timeouts;
    get timeouts(): ComputePublicDelegatedPrefixTimeoutsOutputReference;
    putTimeouts(value: ComputePublicDelegatedPrefixTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputePublicDelegatedPrefixTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
