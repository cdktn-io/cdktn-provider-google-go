/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ColabRuntimeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Triggers an upgrade anytime the runtime is started if it is upgradable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_runtime#auto_upgrade ColabRuntime#auto_upgrade}
    */
    readonly autoUpgrade?: boolean | cdktn.IResolvable;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_runtime#deletion_policy ColabRuntime#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The description of the Runtime.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_runtime#description ColabRuntime#description}
    */
    readonly description?: string;
    /**
    * Desired state of the Colab Runtime. Set this field to 'RUNNING' to start the runtime, and 'STOPPED' to stop it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_runtime#desired_state ColabRuntime#desired_state}
    */
    readonly desiredState?: string;
    /**
    * Required. The display name of the Runtime.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_runtime#display_name ColabRuntime#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_runtime#id ColabRuntime#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location for the resource: https://cloud.google.com/colab/docs/locations
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_runtime#location ColabRuntime#location}
    */
    readonly location: string;
    /**
    * The resource name of the Runtime
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_runtime#name ColabRuntime#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_runtime#project ColabRuntime#project}
    */
    readonly project?: string;
    /**
    * The user email of the NotebookRuntime.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_runtime#runtime_user ColabRuntime#runtime_user}
    */
    readonly runtimeUser: string;
    /**
    * notebook_runtime_template_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_runtime#notebook_runtime_template_ref ColabRuntime#notebook_runtime_template_ref}
    */
    readonly notebookRuntimeTemplateRef?: ColabRuntimeNotebookRuntimeTemplateRef;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_runtime#timeouts ColabRuntime#timeouts}
    */
    readonly timeouts?: ColabRuntimeTimeouts;
}
export interface ColabRuntimeNotebookRuntimeTemplateRef {
    /**
    * The resource name of the NotebookRuntimeTemplate based on which a NotebookRuntime will be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_runtime#notebook_runtime_template ColabRuntime#notebook_runtime_template}
    */
    readonly notebookRuntimeTemplate: string;
}
export declare function colabRuntimeNotebookRuntimeTemplateRefToTerraform(struct?: ColabRuntimeNotebookRuntimeTemplateRefOutputReference | ColabRuntimeNotebookRuntimeTemplateRef): any;
export declare function colabRuntimeNotebookRuntimeTemplateRefToHclTerraform(struct?: ColabRuntimeNotebookRuntimeTemplateRefOutputReference | ColabRuntimeNotebookRuntimeTemplateRef): any;
export declare class ColabRuntimeNotebookRuntimeTemplateRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabRuntimeNotebookRuntimeTemplateRef | undefined;
    set internalValue(value: ColabRuntimeNotebookRuntimeTemplateRef | undefined);
    private _notebookRuntimeTemplate?;
    get notebookRuntimeTemplate(): string;
    set notebookRuntimeTemplate(value: string);
    get notebookRuntimeTemplateInput(): string | undefined;
}
export interface ColabRuntimeTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_runtime#create ColabRuntime#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_runtime#delete ColabRuntime#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_runtime#update ColabRuntime#update}
    */
    readonly update?: string;
}
export declare function colabRuntimeTimeoutsToTerraform(struct?: ColabRuntimeTimeouts | cdktn.IResolvable): any;
export declare function colabRuntimeTimeoutsToHclTerraform(struct?: ColabRuntimeTimeouts | cdktn.IResolvable): any;
export declare class ColabRuntimeTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabRuntimeTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ColabRuntimeTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_runtime google_colab_runtime}
*/
export declare class ColabRuntime extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_colab_runtime";
    /**
    * Generates CDKTN code for importing a ColabRuntime resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ColabRuntime to import
    * @param importFromId The id of the existing ColabRuntime that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_runtime#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ColabRuntime to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/colab_runtime google_colab_runtime} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ColabRuntimeConfig
    */
    constructor(scope: Construct, id: string, config: ColabRuntimeConfig);
    private _autoUpgrade?;
    get autoUpgrade(): boolean | cdktn.IResolvable;
    set autoUpgrade(value: boolean | cdktn.IResolvable);
    resetAutoUpgrade(): void;
    get autoUpgradeInput(): boolean | cdktn.IResolvable | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _desiredState?;
    get desiredState(): string;
    set desiredState(value: string);
    resetDesiredState(): void;
    get desiredStateInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get expirationTime(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get isUpgradable(): cdktn.IResolvable;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get notebookRuntimeType(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _runtimeUser?;
    get runtimeUser(): string;
    set runtimeUser(value: string);
    get runtimeUserInput(): string | undefined;
    get state(): string;
    private _notebookRuntimeTemplateRef;
    get notebookRuntimeTemplateRef(): ColabRuntimeNotebookRuntimeTemplateRefOutputReference;
    putNotebookRuntimeTemplateRef(value: ColabRuntimeNotebookRuntimeTemplateRef): void;
    resetNotebookRuntimeTemplateRef(): void;
    get notebookRuntimeTemplateRefInput(): ColabRuntimeNotebookRuntimeTemplateRef | undefined;
    private _timeouts;
    get timeouts(): ColabRuntimeTimeoutsOutputReference;
    putTimeouts(value: ColabRuntimeTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ColabRuntimeTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
