/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BigqueryDatapolicyv2DataPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * User-assigned (human readable) ID of the data policy that needs to be
    * unique within a project. Used as {data_policy_id} in part of the resource
    * name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_datapolicyv2_data_policy#data_policy_id BigqueryDatapolicyv2DataPolicy#data_policy_id}
    */
    readonly dataPolicyId: string;
    /**
    * Type of data policy.
    * Possible values:
    * DATA_MASKING_POLICY
    * RAW_DATA_ACCESS_POLICY
    * COLUMN_LEVEL_SECURITY_POLICY
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_datapolicyv2_data_policy#data_policy_type BigqueryDatapolicyv2DataPolicy#data_policy_type}
    */
    readonly dataPolicyType: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_datapolicyv2_data_policy#deletion_policy BigqueryDatapolicyv2DataPolicy#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The etag for this Data Policy.
    * This field is used for UpdateDataPolicy calls. If Data Policy exists, this
    * field is required and must match the server's etag. It will also be
    * populated in the response of GetDataPolicy, CreateDataPolicy, and
    * UpdateDataPolicy calls.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_datapolicyv2_data_policy#etag BigqueryDatapolicyv2DataPolicy#etag}
    */
    readonly etag?: string;
    /**
    * The list of IAM principals that have Fine Grained Access to the underlying
    * data goverened by this data policy.
    *
    * Uses the [IAM V2 principal
    * syntax](https://cloud.google.com/iam/docs/principal-identifiers#v2) Only
    * supports principal types users, groups, serviceaccounts, cloudidentity.
    * This field is supported in V2 Data Policy only. In case of V1 data policies
    * (i.e. verion = 1 and policy_tag is set), this field is not populated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_datapolicyv2_data_policy#grantees BigqueryDatapolicyv2DataPolicy#grantees}
    */
    readonly grantees?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_datapolicyv2_data_policy#id BigqueryDatapolicyv2DataPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_datapolicyv2_data_policy#location BigqueryDatapolicyv2DataPolicy#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_datapolicyv2_data_policy#project BigqueryDatapolicyv2DataPolicy#project}
    */
    readonly project?: string;
    /**
    * data_governance_tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_datapolicyv2_data_policy#data_governance_tag BigqueryDatapolicyv2DataPolicy#data_governance_tag}
    */
    readonly dataGovernanceTag?: BigqueryDatapolicyv2DataPolicyDataGovernanceTag;
    /**
    * data_masking_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_datapolicyv2_data_policy#data_masking_policy BigqueryDatapolicyv2DataPolicy#data_masking_policy}
    */
    readonly dataMaskingPolicy?: BigqueryDatapolicyv2DataPolicyDataMaskingPolicy;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_datapolicyv2_data_policy#timeouts BigqueryDatapolicyv2DataPolicy#timeouts}
    */
    readonly timeouts?: BigqueryDatapolicyv2DataPolicyTimeouts;
}
export interface BigqueryDatapolicyv2DataPolicyDataGovernanceTag {
    /**
    * Tag keys are globally unique. Tag key is expected to be in the namespaced format, for example "parent-id/pii" where "parent-id" is the ID of the parent organization or project resource for this tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_datapolicyv2_data_policy#key BigqueryDatapolicyv2DataPolicy#key}
    */
    readonly key?: string;
    /**
    * Tag value is expected to be the short name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_datapolicyv2_data_policy#value BigqueryDatapolicyv2DataPolicy#value}
    */
    readonly value?: string;
}
export declare function bigqueryDatapolicyv2DataPolicyDataGovernanceTagToTerraform(struct?: BigqueryDatapolicyv2DataPolicyDataGovernanceTagOutputReference | BigqueryDatapolicyv2DataPolicyDataGovernanceTag): any;
export declare function bigqueryDatapolicyv2DataPolicyDataGovernanceTagToHclTerraform(struct?: BigqueryDatapolicyv2DataPolicyDataGovernanceTagOutputReference | BigqueryDatapolicyv2DataPolicyDataGovernanceTag): any;
export declare class BigqueryDatapolicyv2DataPolicyDataGovernanceTagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryDatapolicyv2DataPolicyDataGovernanceTag | undefined;
    set internalValue(value: BigqueryDatapolicyv2DataPolicyDataGovernanceTag | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface BigqueryDatapolicyv2DataPolicyDataMaskingPolicy {
    /**
    * A predefined masking expression.
    * Possible values:
    * SHA256
    * ALWAYS_NULL
    * DEFAULT_MASKING_VALUE
    * LAST_FOUR_CHARACTERS
    * FIRST_FOUR_CHARACTERS
    * EMAIL_MASK
    * DATE_YEAR_MASK
    * RANDOM_HASH
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_datapolicyv2_data_policy#predefined_expression BigqueryDatapolicyv2DataPolicy#predefined_expression}
    */
    readonly predefinedExpression?: string;
    /**
    * The name of the BigQuery routine that contains the custom masking
    * routine, in the format of
    * 'projects/{project_number}/datasets/{dataset_id}/routines/{routine_id}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_datapolicyv2_data_policy#routine BigqueryDatapolicyv2DataPolicy#routine}
    */
    readonly routine?: string;
}
export declare function bigqueryDatapolicyv2DataPolicyDataMaskingPolicyToTerraform(struct?: BigqueryDatapolicyv2DataPolicyDataMaskingPolicyOutputReference | BigqueryDatapolicyv2DataPolicyDataMaskingPolicy): any;
export declare function bigqueryDatapolicyv2DataPolicyDataMaskingPolicyToHclTerraform(struct?: BigqueryDatapolicyv2DataPolicyDataMaskingPolicyOutputReference | BigqueryDatapolicyv2DataPolicyDataMaskingPolicy): any;
export declare class BigqueryDatapolicyv2DataPolicyDataMaskingPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryDatapolicyv2DataPolicyDataMaskingPolicy | undefined;
    set internalValue(value: BigqueryDatapolicyv2DataPolicyDataMaskingPolicy | undefined);
    private _predefinedExpression?;
    get predefinedExpression(): string;
    set predefinedExpression(value: string);
    resetPredefinedExpression(): void;
    get predefinedExpressionInput(): string | undefined;
    private _routine?;
    get routine(): string;
    set routine(value: string);
    resetRoutine(): void;
    get routineInput(): string | undefined;
}
export interface BigqueryDatapolicyv2DataPolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_datapolicyv2_data_policy#create BigqueryDatapolicyv2DataPolicy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_datapolicyv2_data_policy#delete BigqueryDatapolicyv2DataPolicy#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_datapolicyv2_data_policy#update BigqueryDatapolicyv2DataPolicy#update}
    */
    readonly update?: string;
}
export declare function bigqueryDatapolicyv2DataPolicyTimeoutsToTerraform(struct?: BigqueryDatapolicyv2DataPolicyTimeouts | cdktn.IResolvable): any;
export declare function bigqueryDatapolicyv2DataPolicyTimeoutsToHclTerraform(struct?: BigqueryDatapolicyv2DataPolicyTimeouts | cdktn.IResolvable): any;
export declare class BigqueryDatapolicyv2DataPolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryDatapolicyv2DataPolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BigqueryDatapolicyv2DataPolicyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_datapolicyv2_data_policy google_bigquery_datapolicyv2_data_policy}
*/
export declare class BigqueryDatapolicyv2DataPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_bigquery_datapolicyv2_data_policy";
    /**
    * Generates CDKTN code for importing a BigqueryDatapolicyv2DataPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BigqueryDatapolicyv2DataPolicy to import
    * @param importFromId The id of the existing BigqueryDatapolicyv2DataPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_datapolicyv2_data_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BigqueryDatapolicyv2DataPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigquery_datapolicyv2_data_policy google_bigquery_datapolicyv2_data_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BigqueryDatapolicyv2DataPolicyConfig
    */
    constructor(scope: Construct, id: string, config: BigqueryDatapolicyv2DataPolicyConfig);
    private _dataPolicyId?;
    get dataPolicyId(): string;
    set dataPolicyId(value: string);
    get dataPolicyIdInput(): string | undefined;
    private _dataPolicyType?;
    get dataPolicyType(): string;
    set dataPolicyType(value: string);
    get dataPolicyTypeInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _etag?;
    get etag(): string;
    set etag(value: string);
    resetEtag(): void;
    get etagInput(): string | undefined;
    private _grantees?;
    get grantees(): string[];
    set grantees(value: string[]);
    resetGrantees(): void;
    get granteesInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    get policyTag(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get version(): string;
    private _dataGovernanceTag;
    get dataGovernanceTag(): BigqueryDatapolicyv2DataPolicyDataGovernanceTagOutputReference;
    putDataGovernanceTag(value: BigqueryDatapolicyv2DataPolicyDataGovernanceTag): void;
    resetDataGovernanceTag(): void;
    get dataGovernanceTagInput(): BigqueryDatapolicyv2DataPolicyDataGovernanceTag | undefined;
    private _dataMaskingPolicy;
    get dataMaskingPolicy(): BigqueryDatapolicyv2DataPolicyDataMaskingPolicyOutputReference;
    putDataMaskingPolicy(value: BigqueryDatapolicyv2DataPolicyDataMaskingPolicy): void;
    resetDataMaskingPolicy(): void;
    get dataMaskingPolicyInput(): BigqueryDatapolicyv2DataPolicyDataMaskingPolicy | undefined;
    private _timeouts;
    get timeouts(): BigqueryDatapolicyv2DataPolicyTimeoutsOutputReference;
    putTimeouts(value: BigqueryDatapolicyv2DataPolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BigqueryDatapolicyv2DataPolicyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
