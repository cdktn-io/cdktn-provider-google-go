/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeOrganizationSecurityPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_organization_security_policy#deletion_policy ComputeOrganizationSecurityPolicy#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * A textual description for the organization security policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_organization_security_policy#description ComputeOrganizationSecurityPolicy#description}
    */
    readonly description?: string;
    /**
    * User-provided name of the organization security policy. The name should be unique in the organization in which the security policy is created. This should only be used when SecurityPolicyType is FIREWALL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_organization_security_policy#display_name ComputeOrganizationSecurityPolicy#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_organization_security_policy#id ComputeOrganizationSecurityPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The parent of this OrganizationSecurityPolicy in the Cloud Resource Hierarchy.
    * Format: organizations/{organization_id} or folders/{folder_id}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_organization_security_policy#parent ComputeOrganizationSecurityPolicy#parent}
    */
    readonly parent: string;
    /**
    * User-provided name of the organization security policy. The name should be unique in the organization in which the security policy is created. This should only be used when SecurityPolicyType is CLOUD_ARMOR.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_organization_security_policy#short_name ComputeOrganizationSecurityPolicy#short_name}
    */
    readonly shortName?: string;
    /**
    * The type indicates the intended use of the security policy. This field can be set only at resource creation time.
    *
    * **NOTE** : 'FIREWALL' type is deprecated and will be removed in a future major release. Please use 'google_compute_firewall_policy' instead." Possible values: ["FIREWALL", "CLOUD_ARMOR", "CLOUD_ARMOR_EDGE", "CLOUD_ARMOR_INTERNAL_SERVICE", "CLOUD_ARMOR_NETWORK"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_organization_security_policy#type ComputeOrganizationSecurityPolicy#type}
    */
    readonly type?: string;
    /**
    * advanced_options_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_organization_security_policy#advanced_options_config ComputeOrganizationSecurityPolicy#advanced_options_config}
    */
    readonly advancedOptionsConfig?: ComputeOrganizationSecurityPolicyAdvancedOptionsConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_organization_security_policy#timeouts ComputeOrganizationSecurityPolicy#timeouts}
    */
    readonly timeouts?: ComputeOrganizationSecurityPolicyTimeouts;
}
export interface ComputeOrganizationSecurityPolicyAdvancedOptionsConfigJsonCustomConfig {
    /**
    * A list of content types to be parsed as JSON.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_organization_security_policy#content_types ComputeOrganizationSecurityPolicy#content_types}
    */
    readonly contentTypes: string[];
}
export declare function computeOrganizationSecurityPolicyAdvancedOptionsConfigJsonCustomConfigToTerraform(struct?: ComputeOrganizationSecurityPolicyAdvancedOptionsConfigJsonCustomConfigOutputReference | ComputeOrganizationSecurityPolicyAdvancedOptionsConfigJsonCustomConfig): any;
export declare function computeOrganizationSecurityPolicyAdvancedOptionsConfigJsonCustomConfigToHclTerraform(struct?: ComputeOrganizationSecurityPolicyAdvancedOptionsConfigJsonCustomConfigOutputReference | ComputeOrganizationSecurityPolicyAdvancedOptionsConfigJsonCustomConfig): any;
export declare class ComputeOrganizationSecurityPolicyAdvancedOptionsConfigJsonCustomConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeOrganizationSecurityPolicyAdvancedOptionsConfigJsonCustomConfig | undefined;
    set internalValue(value: ComputeOrganizationSecurityPolicyAdvancedOptionsConfigJsonCustomConfig | undefined);
    private _contentTypes?;
    get contentTypes(): string[];
    set contentTypes(value: string[]);
    get contentTypesInput(): string[] | undefined;
}
export interface ComputeOrganizationSecurityPolicyAdvancedOptionsConfig {
    /**
    * JSON body parsing. Supported values include: "DISABLED", "STANDARD", "STANDARD_WITH_GRAPHQL". Possible values: ["DISABLED", "STANDARD", "STANDARD_WITH_GRAPHQL"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_organization_security_policy#json_parsing ComputeOrganizationSecurityPolicy#json_parsing}
    */
    readonly jsonParsing?: string;
    /**
    * Logging level. Supported values include: "NORMAL", "VERBOSE". Possible values: ["NORMAL", "VERBOSE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_organization_security_policy#log_level ComputeOrganizationSecurityPolicy#log_level}
    */
    readonly logLevel?: string;
    /**
    * The maximum request size chosen by the customer with Waf enabled. Values supported are "8KB", "16KB", "32KB", "48KB" and "64KB".
    * Values are case insensitive. Possible values: ["8KB", "16KB", "32KB", "48KB", "64KB"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_organization_security_policy#request_body_inspection_size ComputeOrganizationSecurityPolicy#request_body_inspection_size}
    */
    readonly requestBodyInspectionSize?: string;
    /**
    * An optional list of case-insensitive request header names to use for resolving the client source IP address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_organization_security_policy#user_ip_request_headers ComputeOrganizationSecurityPolicy#user_ip_request_headers}
    */
    readonly userIpRequestHeaders?: string[];
    /**
    * json_custom_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_organization_security_policy#json_custom_config ComputeOrganizationSecurityPolicy#json_custom_config}
    */
    readonly jsonCustomConfig?: ComputeOrganizationSecurityPolicyAdvancedOptionsConfigJsonCustomConfig;
}
export declare function computeOrganizationSecurityPolicyAdvancedOptionsConfigToTerraform(struct?: ComputeOrganizationSecurityPolicyAdvancedOptionsConfigOutputReference | ComputeOrganizationSecurityPolicyAdvancedOptionsConfig): any;
export declare function computeOrganizationSecurityPolicyAdvancedOptionsConfigToHclTerraform(struct?: ComputeOrganizationSecurityPolicyAdvancedOptionsConfigOutputReference | ComputeOrganizationSecurityPolicyAdvancedOptionsConfig): any;
export declare class ComputeOrganizationSecurityPolicyAdvancedOptionsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeOrganizationSecurityPolicyAdvancedOptionsConfig | undefined;
    set internalValue(value: ComputeOrganizationSecurityPolicyAdvancedOptionsConfig | undefined);
    private _jsonParsing?;
    get jsonParsing(): string;
    set jsonParsing(value: string);
    resetJsonParsing(): void;
    get jsonParsingInput(): string | undefined;
    private _logLevel?;
    get logLevel(): string;
    set logLevel(value: string);
    resetLogLevel(): void;
    get logLevelInput(): string | undefined;
    private _requestBodyInspectionSize?;
    get requestBodyInspectionSize(): string;
    set requestBodyInspectionSize(value: string);
    resetRequestBodyInspectionSize(): void;
    get requestBodyInspectionSizeInput(): string | undefined;
    private _userIpRequestHeaders?;
    get userIpRequestHeaders(): string[];
    set userIpRequestHeaders(value: string[]);
    resetUserIpRequestHeaders(): void;
    get userIpRequestHeadersInput(): string[] | undefined;
    private _jsonCustomConfig;
    get jsonCustomConfig(): ComputeOrganizationSecurityPolicyAdvancedOptionsConfigJsonCustomConfigOutputReference;
    putJsonCustomConfig(value: ComputeOrganizationSecurityPolicyAdvancedOptionsConfigJsonCustomConfig): void;
    resetJsonCustomConfig(): void;
    get jsonCustomConfigInput(): ComputeOrganizationSecurityPolicyAdvancedOptionsConfigJsonCustomConfig | undefined;
}
export interface ComputeOrganizationSecurityPolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_organization_security_policy#create ComputeOrganizationSecurityPolicy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_organization_security_policy#delete ComputeOrganizationSecurityPolicy#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_organization_security_policy#update ComputeOrganizationSecurityPolicy#update}
    */
    readonly update?: string;
}
export declare function computeOrganizationSecurityPolicyTimeoutsToTerraform(struct?: ComputeOrganizationSecurityPolicyTimeouts | cdktn.IResolvable): any;
export declare function computeOrganizationSecurityPolicyTimeoutsToHclTerraform(struct?: ComputeOrganizationSecurityPolicyTimeouts | cdktn.IResolvable): any;
export declare class ComputeOrganizationSecurityPolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeOrganizationSecurityPolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeOrganizationSecurityPolicyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_organization_security_policy google_compute_organization_security_policy}
*/
export declare class ComputeOrganizationSecurityPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_organization_security_policy";
    /**
    * Generates CDKTN code for importing a ComputeOrganizationSecurityPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeOrganizationSecurityPolicy to import
    * @param importFromId The id of the existing ComputeOrganizationSecurityPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_organization_security_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeOrganizationSecurityPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_organization_security_policy google_compute_organization_security_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeOrganizationSecurityPolicyConfig
    */
    constructor(scope: Construct, id: string, config: ComputeOrganizationSecurityPolicyConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    get fingerprint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    get policyId(): string;
    private _shortName?;
    get shortName(): string;
    set shortName(value: string);
    resetShortName(): void;
    get shortNameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _advancedOptionsConfig;
    get advancedOptionsConfig(): ComputeOrganizationSecurityPolicyAdvancedOptionsConfigOutputReference;
    putAdvancedOptionsConfig(value: ComputeOrganizationSecurityPolicyAdvancedOptionsConfig): void;
    resetAdvancedOptionsConfig(): void;
    get advancedOptionsConfigInput(): ComputeOrganizationSecurityPolicyAdvancedOptionsConfig | undefined;
    private _timeouts;
    get timeouts(): ComputeOrganizationSecurityPolicyTimeoutsOutputReference;
    putTimeouts(value: ComputeOrganizationSecurityPolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeOrganizationSecurityPolicyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
