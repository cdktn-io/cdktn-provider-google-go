/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BigtableAuthorizedViewConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_authorized_view#deletion_policy BigtableAuthorizedView#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * A field to make the authorized view protected against data loss i.e. when set to PROTECTED, deleting the authorized view, the table containing the authorized view, and the instance containing the authorized view would be prohibited.
    * If not provided, currently deletion protection will be set to UNPROTECTED as it is the API default value. Note this field configs the deletion protection provided by the API in the backend, and should not be confused with Terraform-side deletion protection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_authorized_view#deletion_protection BigtableAuthorizedView#deletion_protection}
    */
    readonly deletionProtection?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_authorized_view#id BigtableAuthorizedView#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the Bigtable instance in which the authorized view belongs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_authorized_view#instance_name BigtableAuthorizedView#instance_name}
    */
    readonly instanceName: string;
    /**
    * The name of the authorized view. Must be 1-50 characters and must only contain hyphens, underscores, periods, letters and numbers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_authorized_view#name BigtableAuthorizedView#name}
    */
    readonly name: string;
    /**
    * The ID of the project in which the resource belongs. If it is not provided, the provider project is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_authorized_view#project BigtableAuthorizedView#project}
    */
    readonly project?: string;
    /**
    * The name of the Bigtable table in which the authorized view belongs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_authorized_view#table_name BigtableAuthorizedView#table_name}
    */
    readonly tableName: string;
    /**
    * subset_view block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_authorized_view#subset_view BigtableAuthorizedView#subset_view}
    */
    readonly subsetView?: BigtableAuthorizedViewSubsetView;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_authorized_view#timeouts BigtableAuthorizedView#timeouts}
    */
    readonly timeouts?: BigtableAuthorizedViewTimeouts;
}
export interface BigtableAuthorizedViewSubsetViewFamilySubsets {
    /**
    * Name of the column family to be included in the authorized view.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_authorized_view#family_name BigtableAuthorizedView#family_name}
    */
    readonly familyName: string;
    /**
    * Base64-encoded prefixes for qualifiers of the column family to be included in the authorized view. Every qualifier starting with one of these prefixes is included in the authorized view. To provide access to all qualifiers, include the empty string as a prefix ("").
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_authorized_view#qualifier_prefixes BigtableAuthorizedView#qualifier_prefixes}
    */
    readonly qualifierPrefixes?: string[];
    /**
    * Base64-encoded individual exact column qualifiers of the column family to be included in the authorized view.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_authorized_view#qualifiers BigtableAuthorizedView#qualifiers}
    */
    readonly qualifiers?: string[];
}
export declare function bigtableAuthorizedViewSubsetViewFamilySubsetsToTerraform(struct?: BigtableAuthorizedViewSubsetViewFamilySubsets | cdktn.IResolvable): any;
export declare function bigtableAuthorizedViewSubsetViewFamilySubsetsToHclTerraform(struct?: BigtableAuthorizedViewSubsetViewFamilySubsets | cdktn.IResolvable): any;
export declare class BigtableAuthorizedViewSubsetViewFamilySubsetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BigtableAuthorizedViewSubsetViewFamilySubsets | cdktn.IResolvable | undefined;
    set internalValue(value: BigtableAuthorizedViewSubsetViewFamilySubsets | cdktn.IResolvable | undefined);
    private _familyName?;
    get familyName(): string;
    set familyName(value: string);
    get familyNameInput(): string | undefined;
    private _qualifierPrefixes?;
    get qualifierPrefixes(): string[];
    set qualifierPrefixes(value: string[]);
    resetQualifierPrefixes(): void;
    get qualifierPrefixesInput(): string[] | undefined;
    private _qualifiers?;
    get qualifiers(): string[];
    set qualifiers(value: string[]);
    resetQualifiers(): void;
    get qualifiersInput(): string[] | undefined;
}
export declare class BigtableAuthorizedViewSubsetViewFamilySubsetsList extends cdktn.ComplexList {
    internalValue?: BigtableAuthorizedViewSubsetViewFamilySubsets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BigtableAuthorizedViewSubsetViewFamilySubsetsOutputReference;
}
export interface BigtableAuthorizedViewSubsetView {
    /**
    * Base64-encoded row prefixes to be included in the authorized view. To provide access to all rows, include the empty string as a prefix ("").
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_authorized_view#row_prefixes BigtableAuthorizedView#row_prefixes}
    */
    readonly rowPrefixes?: string[];
    /**
    * family_subsets block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_authorized_view#family_subsets BigtableAuthorizedView#family_subsets}
    */
    readonly familySubsets?: BigtableAuthorizedViewSubsetViewFamilySubsets[] | cdktn.IResolvable;
}
export declare function bigtableAuthorizedViewSubsetViewToTerraform(struct?: BigtableAuthorizedViewSubsetViewOutputReference | BigtableAuthorizedViewSubsetView): any;
export declare function bigtableAuthorizedViewSubsetViewToHclTerraform(struct?: BigtableAuthorizedViewSubsetViewOutputReference | BigtableAuthorizedViewSubsetView): any;
export declare class BigtableAuthorizedViewSubsetViewOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigtableAuthorizedViewSubsetView | undefined;
    set internalValue(value: BigtableAuthorizedViewSubsetView | undefined);
    private _rowPrefixes?;
    get rowPrefixes(): string[];
    set rowPrefixes(value: string[]);
    resetRowPrefixes(): void;
    get rowPrefixesInput(): string[] | undefined;
    private _familySubsets;
    get familySubsets(): BigtableAuthorizedViewSubsetViewFamilySubsetsList;
    putFamilySubsets(value: BigtableAuthorizedViewSubsetViewFamilySubsets[] | cdktn.IResolvable): void;
    resetFamilySubsets(): void;
    get familySubsetsInput(): cdktn.IResolvable | BigtableAuthorizedViewSubsetViewFamilySubsets[] | undefined;
}
export interface BigtableAuthorizedViewTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_authorized_view#create BigtableAuthorizedView#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_authorized_view#update BigtableAuthorizedView#update}
    */
    readonly update?: string;
}
export declare function bigtableAuthorizedViewTimeoutsToTerraform(struct?: BigtableAuthorizedViewTimeouts | cdktn.IResolvable): any;
export declare function bigtableAuthorizedViewTimeoutsToHclTerraform(struct?: BigtableAuthorizedViewTimeouts | cdktn.IResolvable): any;
export declare class BigtableAuthorizedViewTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigtableAuthorizedViewTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BigtableAuthorizedViewTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_authorized_view google_bigtable_authorized_view}
*/
export declare class BigtableAuthorizedView extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_bigtable_authorized_view";
    /**
    * Generates CDKTN code for importing a BigtableAuthorizedView resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BigtableAuthorizedView to import
    * @param importFromId The id of the existing BigtableAuthorizedView that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_authorized_view#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BigtableAuthorizedView to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/bigtable_authorized_view google_bigtable_authorized_view} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BigtableAuthorizedViewConfig
    */
    constructor(scope: Construct, id: string, config: BigtableAuthorizedViewConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _deletionProtection?;
    get deletionProtection(): string;
    set deletionProtection(value: string);
    resetDeletionProtection(): void;
    get deletionProtectionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceName?;
    get instanceName(): string;
    set instanceName(value: string);
    get instanceNameInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
    private _subsetView;
    get subsetView(): BigtableAuthorizedViewSubsetViewOutputReference;
    putSubsetView(value: BigtableAuthorizedViewSubsetView): void;
    resetSubsetView(): void;
    get subsetViewInput(): BigtableAuthorizedViewSubsetView | undefined;
    private _timeouts;
    get timeouts(): BigtableAuthorizedViewTimeoutsOutputReference;
    putTimeouts(value: BigtableAuthorizedViewTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BigtableAuthorizedViewTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
