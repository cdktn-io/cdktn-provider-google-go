/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeRouterNatAddressConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_router_nat_address#deletion_policy ComputeRouterNatAddress#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * A list of URLs of the IP resources to be drained. These IPs must be
    * valid static external IPs that have been assigned to the NAT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_router_nat_address#drain_nat_ips ComputeRouterNatAddress#drain_nat_ips}
    */
    readonly drainNatIps?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_router_nat_address#id ComputeRouterNatAddress#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Self-links of NAT IPs to be used in a Nat service. Only valid if the referenced RouterNat
    * natIpAllocateOption is set to MANUAL_ONLY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_router_nat_address#nat_ips ComputeRouterNatAddress#nat_ips}
    */
    readonly natIps: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_router_nat_address#project ComputeRouterNatAddress#project}
    */
    readonly project?: string;
    /**
    * Region where the NAT service reside.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_router_nat_address#region ComputeRouterNatAddress#region}
    */
    readonly region?: string;
    /**
    * The name of the Cloud Router in which the referenced NAT service is configured.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_router_nat_address#router ComputeRouterNatAddress#router}
    */
    readonly router: string;
    /**
    * The name of the Nat service in which this address will be configured.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_router_nat_address#router_nat ComputeRouterNatAddress#router_nat}
    */
    readonly routerNat: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_router_nat_address#timeouts ComputeRouterNatAddress#timeouts}
    */
    readonly timeouts?: ComputeRouterNatAddressTimeouts;
}
export interface ComputeRouterNatAddressTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_router_nat_address#create ComputeRouterNatAddress#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_router_nat_address#delete ComputeRouterNatAddress#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_router_nat_address#update ComputeRouterNatAddress#update}
    */
    readonly update?: string;
}
export declare function computeRouterNatAddressTimeoutsToTerraform(struct?: ComputeRouterNatAddressTimeouts | cdktn.IResolvable): any;
export declare function computeRouterNatAddressTimeoutsToHclTerraform(struct?: ComputeRouterNatAddressTimeouts | cdktn.IResolvable): any;
export declare class ComputeRouterNatAddressTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRouterNatAddressTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRouterNatAddressTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_router_nat_address google_compute_router_nat_address}
*/
export declare class ComputeRouterNatAddress extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_router_nat_address";
    /**
    * Generates CDKTN code for importing a ComputeRouterNatAddress resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeRouterNatAddress to import
    * @param importFromId The id of the existing ComputeRouterNatAddress that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_router_nat_address#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeRouterNatAddress to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_router_nat_address google_compute_router_nat_address} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeRouterNatAddressConfig
    */
    constructor(scope: Construct, id: string, config: ComputeRouterNatAddressConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _drainNatIps?;
    get drainNatIps(): string[];
    set drainNatIps(value: string[]);
    resetDrainNatIps(): void;
    get drainNatIpsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _natIps?;
    get natIps(): string[];
    set natIps(value: string[]);
    get natIpsInput(): string[] | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _router?;
    get router(): string;
    set router(value: string);
    get routerInput(): string | undefined;
    private _routerNat?;
    get routerNat(): string;
    set routerNat(value: string);
    get routerNatInput(): string | undefined;
    private _timeouts;
    get timeouts(): ComputeRouterNatAddressTimeoutsOutputReference;
    putTimeouts(value: ComputeRouterNatAddressTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeRouterNatAddressTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
