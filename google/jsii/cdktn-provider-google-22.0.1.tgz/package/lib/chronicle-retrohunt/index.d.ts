/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChronicleRetrohuntConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_retrohunt#id ChronicleRetrohunt#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The unique identifier for the Chronicle instance, which is the same as the customer ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_retrohunt#instance ChronicleRetrohunt#instance}
    */
    readonly instance: string;
    /**
    * The location of the resource. This is the geographical region where the Chronicle instance resides, such as "us" or "europe-west2".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_retrohunt#location ChronicleRetrohunt#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_retrohunt#project ChronicleRetrohunt#project}
    */
    readonly project?: string;
    /**
    * The retrohunt ID of the Retrohunt. A retrohunt is an execution of a Rule over a time range in the past.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_retrohunt#retrohunt ChronicleRetrohunt#retrohunt}
    */
    readonly retrohunt?: string;
    /**
    * The Rule ID of the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_retrohunt#rule ChronicleRetrohunt#rule}
    */
    readonly rule: string;
    /**
    * process_interval block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_retrohunt#process_interval ChronicleRetrohunt#process_interval}
    */
    readonly processInterval: ChronicleRetrohuntProcessInterval;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_retrohunt#timeouts ChronicleRetrohunt#timeouts}
    */
    readonly timeouts?: ChronicleRetrohuntTimeouts;
}
export interface ChronicleRetrohuntExecutionInterval {
}
export declare function chronicleRetrohuntExecutionIntervalToTerraform(struct?: ChronicleRetrohuntExecutionInterval): any;
export declare function chronicleRetrohuntExecutionIntervalToHclTerraform(struct?: ChronicleRetrohuntExecutionInterval): any;
export declare class ChronicleRetrohuntExecutionIntervalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleRetrohuntExecutionInterval | undefined;
    set internalValue(value: ChronicleRetrohuntExecutionInterval | undefined);
    get endTime(): string;
    get startTime(): string;
}
export declare class ChronicleRetrohuntExecutionIntervalList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleRetrohuntExecutionIntervalOutputReference;
}
export interface ChronicleRetrohuntProcessInterval {
    /**
    * Exclusive end of the interval.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_retrohunt#end_time ChronicleRetrohunt#end_time}
    */
    readonly endTime: string;
    /**
    * Inclusive start of the interval.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_retrohunt#start_time ChronicleRetrohunt#start_time}
    */
    readonly startTime: string;
}
export declare function chronicleRetrohuntProcessIntervalToTerraform(struct?: ChronicleRetrohuntProcessIntervalOutputReference | ChronicleRetrohuntProcessInterval): any;
export declare function chronicleRetrohuntProcessIntervalToHclTerraform(struct?: ChronicleRetrohuntProcessIntervalOutputReference | ChronicleRetrohuntProcessInterval): any;
export declare class ChronicleRetrohuntProcessIntervalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleRetrohuntProcessInterval | undefined;
    set internalValue(value: ChronicleRetrohuntProcessInterval | undefined);
    private _endTime?;
    get endTime(): string;
    set endTime(value: string);
    get endTimeInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    get startTimeInput(): string | undefined;
}
export interface ChronicleRetrohuntTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_retrohunt#create ChronicleRetrohunt#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_retrohunt#delete ChronicleRetrohunt#delete}
    */
    readonly delete?: string;
}
export declare function chronicleRetrohuntTimeoutsToTerraform(struct?: ChronicleRetrohuntTimeouts | cdktn.IResolvable): any;
export declare function chronicleRetrohuntTimeoutsToHclTerraform(struct?: ChronicleRetrohuntTimeouts | cdktn.IResolvable): any;
export declare class ChronicleRetrohuntTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleRetrohuntTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleRetrohuntTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_retrohunt google_chronicle_retrohunt}
*/
export declare class ChronicleRetrohunt extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_chronicle_retrohunt";
    /**
    * Generates CDKTN code for importing a ChronicleRetrohunt resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChronicleRetrohunt to import
    * @param importFromId The id of the existing ChronicleRetrohunt that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_retrohunt#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChronicleRetrohunt to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_retrohunt google_chronicle_retrohunt} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChronicleRetrohuntConfig
    */
    constructor(scope: Construct, id: string, config: ChronicleRetrohuntConfig);
    private _executionInterval;
    get executionInterval(): ChronicleRetrohuntExecutionIntervalList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instance?;
    get instance(): string;
    set instance(value: string);
    get instanceInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    get progressPercentage(): number;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _retrohunt?;
    get retrohunt(): string;
    set retrohunt(value: string);
    resetRetrohunt(): void;
    get retrohuntInput(): string | undefined;
    private _rule?;
    get rule(): string;
    set rule(value: string);
    get ruleInput(): string | undefined;
    get state(): string;
    private _processInterval;
    get processInterval(): ChronicleRetrohuntProcessIntervalOutputReference;
    putProcessInterval(value: ChronicleRetrohuntProcessInterval): void;
    get processIntervalInput(): ChronicleRetrohuntProcessInterval | undefined;
    private _timeouts;
    get timeouts(): ChronicleRetrohuntTimeoutsOutputReference;
    putTimeouts(value: ChronicleRetrohuntTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ChronicleRetrohuntTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
