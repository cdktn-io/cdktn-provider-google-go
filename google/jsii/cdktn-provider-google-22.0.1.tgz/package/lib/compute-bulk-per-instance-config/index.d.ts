/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeBulkPerInstanceConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_bulk_per_instance_config#deletion_policy ComputeBulkPerInstanceConfig#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_bulk_per_instance_config#id ComputeBulkPerInstanceConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The instance group manager this instance config is part of.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_bulk_per_instance_config#instance_group_manager ComputeBulkPerInstanceConfig#instance_group_manager}
    */
    readonly instanceGroupManager: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_bulk_per_instance_config#project ComputeBulkPerInstanceConfig#project}
    */
    readonly project?: string;
    /**
    * Zone where the containing instance group manager is located
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_bulk_per_instance_config#zone ComputeBulkPerInstanceConfig#zone}
    */
    readonly zone?: string;
    /**
    * instances block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_bulk_per_instance_config#instances ComputeBulkPerInstanceConfig#instances}
    */
    readonly instances?: ComputeBulkPerInstanceConfigInstances[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_bulk_per_instance_config#timeouts ComputeBulkPerInstanceConfig#timeouts}
    */
    readonly timeouts?: ComputeBulkPerInstanceConfigTimeouts;
}
export interface ComputeBulkPerInstanceConfigInstances {
    /**
    * The name for this per-instance config and its corresponding instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_bulk_per_instance_config#name ComputeBulkPerInstanceConfig#name}
    */
    readonly name: string;
}
export declare function computeBulkPerInstanceConfigInstancesToTerraform(struct?: ComputeBulkPerInstanceConfigInstances | cdktn.IResolvable): any;
export declare function computeBulkPerInstanceConfigInstancesToHclTerraform(struct?: ComputeBulkPerInstanceConfigInstances | cdktn.IResolvable): any;
export declare class ComputeBulkPerInstanceConfigInstancesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeBulkPerInstanceConfigInstances | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeBulkPerInstanceConfigInstances | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class ComputeBulkPerInstanceConfigInstancesList extends cdktn.ComplexList {
    internalValue?: ComputeBulkPerInstanceConfigInstances[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeBulkPerInstanceConfigInstancesOutputReference;
}
export interface ComputeBulkPerInstanceConfigTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_bulk_per_instance_config#create ComputeBulkPerInstanceConfig#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_bulk_per_instance_config#delete ComputeBulkPerInstanceConfig#delete}
    */
    readonly delete?: string;
}
export declare function computeBulkPerInstanceConfigTimeoutsToTerraform(struct?: ComputeBulkPerInstanceConfigTimeouts | cdktn.IResolvable): any;
export declare function computeBulkPerInstanceConfigTimeoutsToHclTerraform(struct?: ComputeBulkPerInstanceConfigTimeouts | cdktn.IResolvable): any;
export declare class ComputeBulkPerInstanceConfigTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeBulkPerInstanceConfigTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeBulkPerInstanceConfigTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_bulk_per_instance_config google_compute_bulk_per_instance_config}
*/
export declare class ComputeBulkPerInstanceConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_bulk_per_instance_config";
    /**
    * Generates CDKTN code for importing a ComputeBulkPerInstanceConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeBulkPerInstanceConfig to import
    * @param importFromId The id of the existing ComputeBulkPerInstanceConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_bulk_per_instance_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeBulkPerInstanceConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_bulk_per_instance_config google_compute_bulk_per_instance_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeBulkPerInstanceConfigConfig
    */
    constructor(scope: Construct, id: string, config: ComputeBulkPerInstanceConfigConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceGroupManager?;
    get instanceGroupManager(): string;
    set instanceGroupManager(value: string);
    get instanceGroupManagerInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    resetZone(): void;
    get zoneInput(): string | undefined;
    private _instances;
    get instances(): ComputeBulkPerInstanceConfigInstancesList;
    putInstances(value: ComputeBulkPerInstanceConfigInstances[] | cdktn.IResolvable): void;
    resetInstances(): void;
    get instancesInput(): cdktn.IResolvable | ComputeBulkPerInstanceConfigInstances[] | undefined;
    private _timeouts;
    get timeouts(): ComputeBulkPerInstanceConfigTimeoutsOutputReference;
    putTimeouts(value: ComputeBulkPerInstanceConfigTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeBulkPerInstanceConfigTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
