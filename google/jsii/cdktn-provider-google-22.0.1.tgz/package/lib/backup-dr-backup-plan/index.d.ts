/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BackupDrBackupPlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the backup plan
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#backup_plan_id BackupDrBackupPlan#backup_plan_id}
    */
    readonly backupPlanId: string;
    /**
    * Backup vault where the backups gets stored using this Backup plan.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#backup_vault BackupDrBackupPlan#backup_vault}
    */
    readonly backupVault: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#deletion_policy BackupDrBackupPlan#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The description allows for additional details about 'BackupPlan' and its use cases to be provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#description BackupDrBackupPlan#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#id BackupDrBackupPlan#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * This collection of key/value pairs allows for custom labels to be supplied by the user.
    *
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#labels BackupDrBackupPlan#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The location for the backup plan
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#location BackupDrBackupPlan#location}
    */
    readonly location: string;
    /**
    * This is only applicable for CloudSql resource. Days for which logs will be stored. This value should be greater than or equal to minimum enforced log retention duration of the backup vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#log_retention_days BackupDrBackupPlan#log_retention_days}
    */
    readonly logRetentionDays?: number;
    /**
    * The maximum number of days for which an on-demand backup taken with custom retention can be retained.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#max_custom_on_demand_retention_days BackupDrBackupPlan#max_custom_on_demand_retention_days}
    */
    readonly maxCustomOnDemandRetentionDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#project BackupDrBackupPlan#project}
    */
    readonly project?: string;
    /**
    * The resource type to which the 'BackupPlan' will be applied.
    * Examples include, "compute.googleapis.com/Instance", "compute.googleapis.com/Disk", "sqladmin.googleapis.com/Instance", "alloydb.googleapis.com/Cluster", "file.googleapis.com/Instance", "netapp.googleapis.com/Volume" and "storage.googleapis.com/Bucket".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#resource_type BackupDrBackupPlan#resource_type}
    */
    readonly resourceType: string;
    /**
    * backup_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#backup_rules BackupDrBackupPlan#backup_rules}
    */
    readonly backupRules?: BackupDrBackupPlanBackupRules[] | cdktn.IResolvable;
    /**
    * compute_instance_backup_plan_properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#compute_instance_backup_plan_properties BackupDrBackupPlan#compute_instance_backup_plan_properties}
    */
    readonly computeInstanceBackupPlanProperties?: BackupDrBackupPlanComputeInstanceBackupPlanProperties;
    /**
    * disk_backup_plan_properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#disk_backup_plan_properties BackupDrBackupPlan#disk_backup_plan_properties}
    */
    readonly diskBackupPlanProperties?: BackupDrBackupPlanDiskBackupPlanProperties;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#timeouts BackupDrBackupPlan#timeouts}
    */
    readonly timeouts?: BackupDrBackupPlanTimeouts;
}
export interface BackupDrBackupPlanBackupRulesStandardScheduleBackupWindow {
    /**
    * The hour of the day (1-24) when the window ends, for example, if the value of end hour of the day is 10, that means the backup window end time is 10:00.
    * The end hour of the day should be greater than the start
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#end_hour_of_day BackupDrBackupPlan#end_hour_of_day}
    */
    readonly endHourOfDay?: number;
    /**
    * The hour of the day (0-23) when the window starts, for example, if the value of the start hour of the day is 6, that means the backup window starts at 6:00.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#start_hour_of_day BackupDrBackupPlan#start_hour_of_day}
    */
    readonly startHourOfDay: number;
}
export declare function backupDrBackupPlanBackupRulesStandardScheduleBackupWindowToTerraform(struct?: BackupDrBackupPlanBackupRulesStandardScheduleBackupWindowOutputReference | BackupDrBackupPlanBackupRulesStandardScheduleBackupWindow): any;
export declare function backupDrBackupPlanBackupRulesStandardScheduleBackupWindowToHclTerraform(struct?: BackupDrBackupPlanBackupRulesStandardScheduleBackupWindowOutputReference | BackupDrBackupPlanBackupRulesStandardScheduleBackupWindow): any;
export declare class BackupDrBackupPlanBackupRulesStandardScheduleBackupWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrBackupPlanBackupRulesStandardScheduleBackupWindow | undefined;
    set internalValue(value: BackupDrBackupPlanBackupRulesStandardScheduleBackupWindow | undefined);
    private _endHourOfDay?;
    get endHourOfDay(): number;
    set endHourOfDay(value: number);
    resetEndHourOfDay(): void;
    get endHourOfDayInput(): number | undefined;
    private _startHourOfDay?;
    get startHourOfDay(): number;
    set startHourOfDay(value: number);
    get startHourOfDayInput(): number | undefined;
}
export interface BackupDrBackupPlanBackupRulesStandardScheduleWeekDayOfMonth {
    /**
    * Specifies the day of the week. Possible values: ["DAY_OF_WEEK_UNSPECIFIED", "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY", "SUNDAY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#day_of_week BackupDrBackupPlan#day_of_week}
    */
    readonly dayOfWeek: string;
    /**
    * WeekOfMonth enumerates possible weeks in the month, e.g. the first, third, or last week of the month. Possible values: ["WEEK_OF_MONTH_UNSPECIFIED", "FIRST", "SECOND", "THIRD", "FOURTH", "LAST"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#week_of_month BackupDrBackupPlan#week_of_month}
    */
    readonly weekOfMonth: string;
}
export declare function backupDrBackupPlanBackupRulesStandardScheduleWeekDayOfMonthToTerraform(struct?: BackupDrBackupPlanBackupRulesStandardScheduleWeekDayOfMonthOutputReference | BackupDrBackupPlanBackupRulesStandardScheduleWeekDayOfMonth): any;
export declare function backupDrBackupPlanBackupRulesStandardScheduleWeekDayOfMonthToHclTerraform(struct?: BackupDrBackupPlanBackupRulesStandardScheduleWeekDayOfMonthOutputReference | BackupDrBackupPlanBackupRulesStandardScheduleWeekDayOfMonth): any;
export declare class BackupDrBackupPlanBackupRulesStandardScheduleWeekDayOfMonthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrBackupPlanBackupRulesStandardScheduleWeekDayOfMonth | undefined;
    set internalValue(value: BackupDrBackupPlanBackupRulesStandardScheduleWeekDayOfMonth | undefined);
    private _dayOfWeek?;
    get dayOfWeek(): string;
    set dayOfWeek(value: string);
    get dayOfWeekInput(): string | undefined;
    private _weekOfMonth?;
    get weekOfMonth(): string;
    set weekOfMonth(value: string);
    get weekOfMonthInput(): string | undefined;
}
export interface BackupDrBackupPlanBackupRulesStandardSchedule {
    /**
    * Specifies days of months like 1, 5, or 14 on which jobs will run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#days_of_month BackupDrBackupPlan#days_of_month}
    */
    readonly daysOfMonth?: number[];
    /**
    * Specifies days of week like MONDAY or TUESDAY, on which jobs will run. This is required for 'recurrence_type', 'WEEKLY' and is not applicable otherwise. Possible values: ["DAY_OF_WEEK_UNSPECIFIED", "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY", "SUNDAY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#days_of_week BackupDrBackupPlan#days_of_week}
    */
    readonly daysOfWeek?: string[];
    /**
    * Specifies frequency for hourly backups. An hourly frequency of 2 means jobs will run every 2 hours from start time till end time defined.
    * This is required for 'recurrence_type', 'HOURLY' and is not applicable otherwise.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#hourly_frequency BackupDrBackupPlan#hourly_frequency}
    */
    readonly hourlyFrequency?: number;
    /**
    * Specifies values of months Possible values: ["MONTH_UNSPECIFIED", "JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#months BackupDrBackupPlan#months}
    */
    readonly months?: string[];
    /**
    * RecurrenceType enumerates the applicable periodicity for the schedule. Possible values: ["HOURLY", "DAILY", "WEEKLY", "MONTHLY", "YEARLY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#recurrence_type BackupDrBackupPlan#recurrence_type}
    */
    readonly recurrenceType: string;
    /**
    * The time zone to be used when interpreting the schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#time_zone BackupDrBackupPlan#time_zone}
    */
    readonly timeZone: string;
    /**
    * backup_window block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#backup_window BackupDrBackupPlan#backup_window}
    */
    readonly backupWindow?: BackupDrBackupPlanBackupRulesStandardScheduleBackupWindow;
    /**
    * week_day_of_month block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#week_day_of_month BackupDrBackupPlan#week_day_of_month}
    */
    readonly weekDayOfMonth?: BackupDrBackupPlanBackupRulesStandardScheduleWeekDayOfMonth;
}
export declare function backupDrBackupPlanBackupRulesStandardScheduleToTerraform(struct?: BackupDrBackupPlanBackupRulesStandardScheduleOutputReference | BackupDrBackupPlanBackupRulesStandardSchedule): any;
export declare function backupDrBackupPlanBackupRulesStandardScheduleToHclTerraform(struct?: BackupDrBackupPlanBackupRulesStandardScheduleOutputReference | BackupDrBackupPlanBackupRulesStandardSchedule): any;
export declare class BackupDrBackupPlanBackupRulesStandardScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrBackupPlanBackupRulesStandardSchedule | undefined;
    set internalValue(value: BackupDrBackupPlanBackupRulesStandardSchedule | undefined);
    private _daysOfMonth?;
    get daysOfMonth(): number[];
    set daysOfMonth(value: number[]);
    resetDaysOfMonth(): void;
    get daysOfMonthInput(): number[] | undefined;
    private _daysOfWeek?;
    get daysOfWeek(): string[];
    set daysOfWeek(value: string[]);
    resetDaysOfWeek(): void;
    get daysOfWeekInput(): string[] | undefined;
    private _hourlyFrequency?;
    get hourlyFrequency(): number;
    set hourlyFrequency(value: number);
    resetHourlyFrequency(): void;
    get hourlyFrequencyInput(): number | undefined;
    private _months?;
    get months(): string[];
    set months(value: string[]);
    resetMonths(): void;
    get monthsInput(): string[] | undefined;
    private _recurrenceType?;
    get recurrenceType(): string;
    set recurrenceType(value: string);
    get recurrenceTypeInput(): string | undefined;
    private _timeZone?;
    get timeZone(): string;
    set timeZone(value: string);
    get timeZoneInput(): string | undefined;
    private _backupWindow;
    get backupWindow(): BackupDrBackupPlanBackupRulesStandardScheduleBackupWindowOutputReference;
    putBackupWindow(value: BackupDrBackupPlanBackupRulesStandardScheduleBackupWindow): void;
    resetBackupWindow(): void;
    get backupWindowInput(): BackupDrBackupPlanBackupRulesStandardScheduleBackupWindow | undefined;
    private _weekDayOfMonth;
    get weekDayOfMonth(): BackupDrBackupPlanBackupRulesStandardScheduleWeekDayOfMonthOutputReference;
    putWeekDayOfMonth(value: BackupDrBackupPlanBackupRulesStandardScheduleWeekDayOfMonth): void;
    resetWeekDayOfMonth(): void;
    get weekDayOfMonthInput(): BackupDrBackupPlanBackupRulesStandardScheduleWeekDayOfMonth | undefined;
}
export interface BackupDrBackupPlanBackupRules {
    /**
    * Configures the duration for which backup data will be kept. The value should be greater than or equal to minimum enforced retention of the backup vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#backup_retention_days BackupDrBackupPlan#backup_retention_days}
    */
    readonly backupRetentionDays: number;
    /**
    * The unique ID of this 'BackupRule'. The 'rule_id' is unique per 'BackupPlan'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#rule_id BackupDrBackupPlan#rule_id}
    */
    readonly ruleId: string;
    /**
    * standard_schedule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#standard_schedule BackupDrBackupPlan#standard_schedule}
    */
    readonly standardSchedule: BackupDrBackupPlanBackupRulesStandardSchedule;
}
export declare function backupDrBackupPlanBackupRulesToTerraform(struct?: BackupDrBackupPlanBackupRules | cdktn.IResolvable): any;
export declare function backupDrBackupPlanBackupRulesToHclTerraform(struct?: BackupDrBackupPlanBackupRules | cdktn.IResolvable): any;
export declare class BackupDrBackupPlanBackupRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupDrBackupPlanBackupRules | cdktn.IResolvable | undefined;
    set internalValue(value: BackupDrBackupPlanBackupRules | cdktn.IResolvable | undefined);
    private _backupRetentionDays?;
    get backupRetentionDays(): number;
    set backupRetentionDays(value: number);
    get backupRetentionDaysInput(): number | undefined;
    private _ruleId?;
    get ruleId(): string;
    set ruleId(value: string);
    get ruleIdInput(): string | undefined;
    private _standardSchedule;
    get standardSchedule(): BackupDrBackupPlanBackupRulesStandardScheduleOutputReference;
    putStandardSchedule(value: BackupDrBackupPlanBackupRulesStandardSchedule): void;
    get standardScheduleInput(): BackupDrBackupPlanBackupRulesStandardSchedule | undefined;
}
export declare class BackupDrBackupPlanBackupRulesList extends cdktn.ComplexList {
    internalValue?: BackupDrBackupPlanBackupRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupDrBackupPlanBackupRulesOutputReference;
}
export interface BackupDrBackupPlanComputeInstanceBackupPlanProperties {
    /**
    * Indicates whether to perform a guest flush operation before taking a
    * compute instance backup. When set to true, the system will attempt
    * to ensure application-consistent backups.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#guest_flush BackupDrBackupPlan#guest_flush}
    */
    readonly guestFlush: boolean | cdktn.IResolvable;
}
export declare function backupDrBackupPlanComputeInstanceBackupPlanPropertiesToTerraform(struct?: BackupDrBackupPlanComputeInstanceBackupPlanPropertiesOutputReference | BackupDrBackupPlanComputeInstanceBackupPlanProperties): any;
export declare function backupDrBackupPlanComputeInstanceBackupPlanPropertiesToHclTerraform(struct?: BackupDrBackupPlanComputeInstanceBackupPlanPropertiesOutputReference | BackupDrBackupPlanComputeInstanceBackupPlanProperties): any;
export declare class BackupDrBackupPlanComputeInstanceBackupPlanPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrBackupPlanComputeInstanceBackupPlanProperties | undefined;
    set internalValue(value: BackupDrBackupPlanComputeInstanceBackupPlanProperties | undefined);
    private _guestFlush?;
    get guestFlush(): boolean | cdktn.IResolvable;
    set guestFlush(value: boolean | cdktn.IResolvable);
    get guestFlushInput(): boolean | cdktn.IResolvable | undefined;
}
export interface BackupDrBackupPlanDiskBackupPlanProperties {
    /**
    * Indicates whether to perform a guest flush operation before taking a disk
    * backup. When set to true, the system will attempt to ensure
    * application-consistent backups. When set to false, the system will
    * create crash-consistent backups.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#guest_flush BackupDrBackupPlan#guest_flush}
    */
    readonly guestFlush: boolean | cdktn.IResolvable;
}
export declare function backupDrBackupPlanDiskBackupPlanPropertiesToTerraform(struct?: BackupDrBackupPlanDiskBackupPlanPropertiesOutputReference | BackupDrBackupPlanDiskBackupPlanProperties): any;
export declare function backupDrBackupPlanDiskBackupPlanPropertiesToHclTerraform(struct?: BackupDrBackupPlanDiskBackupPlanPropertiesOutputReference | BackupDrBackupPlanDiskBackupPlanProperties): any;
export declare class BackupDrBackupPlanDiskBackupPlanPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrBackupPlanDiskBackupPlanProperties | undefined;
    set internalValue(value: BackupDrBackupPlanDiskBackupPlanProperties | undefined);
    private _guestFlush?;
    get guestFlush(): boolean | cdktn.IResolvable;
    set guestFlush(value: boolean | cdktn.IResolvable);
    get guestFlushInput(): boolean | cdktn.IResolvable | undefined;
}
export interface BackupDrBackupPlanTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#create BackupDrBackupPlan#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#delete BackupDrBackupPlan#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#update BackupDrBackupPlan#update}
    */
    readonly update?: string;
}
export declare function backupDrBackupPlanTimeoutsToTerraform(struct?: BackupDrBackupPlanTimeouts | cdktn.IResolvable): any;
export declare function backupDrBackupPlanTimeoutsToHclTerraform(struct?: BackupDrBackupPlanTimeouts | cdktn.IResolvable): any;
export declare class BackupDrBackupPlanTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrBackupPlanTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BackupDrBackupPlanTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan google_backup_dr_backup_plan}
*/
export declare class BackupDrBackupPlan extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_backup_dr_backup_plan";
    /**
    * Generates CDKTN code for importing a BackupDrBackupPlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BackupDrBackupPlan to import
    * @param importFromId The id of the existing BackupDrBackupPlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BackupDrBackupPlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/backup_dr_backup_plan google_backup_dr_backup_plan} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BackupDrBackupPlanConfig
    */
    constructor(scope: Construct, id: string, config: BackupDrBackupPlanConfig);
    private _backupPlanId?;
    get backupPlanId(): string;
    set backupPlanId(value: string);
    get backupPlanIdInput(): string | undefined;
    private _backupVault?;
    get backupVault(): string;
    set backupVault(value: string);
    get backupVaultInput(): string | undefined;
    get backupVaultServiceAccount(): string;
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _logRetentionDays?;
    get logRetentionDays(): number;
    set logRetentionDays(value: number);
    resetLogRetentionDays(): void;
    get logRetentionDaysInput(): number | undefined;
    private _maxCustomOnDemandRetentionDays?;
    get maxCustomOnDemandRetentionDays(): number;
    set maxCustomOnDemandRetentionDays(value: number);
    resetMaxCustomOnDemandRetentionDays(): void;
    get maxCustomOnDemandRetentionDaysInput(): number | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    get resourceTypeInput(): string | undefined;
    get supportedResourceTypes(): string[];
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get updateTime(): string;
    private _backupRules;
    get backupRules(): BackupDrBackupPlanBackupRulesList;
    putBackupRules(value: BackupDrBackupPlanBackupRules[] | cdktn.IResolvable): void;
    resetBackupRules(): void;
    get backupRulesInput(): cdktn.IResolvable | BackupDrBackupPlanBackupRules[] | undefined;
    private _computeInstanceBackupPlanProperties;
    get computeInstanceBackupPlanProperties(): BackupDrBackupPlanComputeInstanceBackupPlanPropertiesOutputReference;
    putComputeInstanceBackupPlanProperties(value: BackupDrBackupPlanComputeInstanceBackupPlanProperties): void;
    resetComputeInstanceBackupPlanProperties(): void;
    get computeInstanceBackupPlanPropertiesInput(): BackupDrBackupPlanComputeInstanceBackupPlanProperties | undefined;
    private _diskBackupPlanProperties;
    get diskBackupPlanProperties(): BackupDrBackupPlanDiskBackupPlanPropertiesOutputReference;
    putDiskBackupPlanProperties(value: BackupDrBackupPlanDiskBackupPlanProperties): void;
    resetDiskBackupPlanProperties(): void;
    get diskBackupPlanPropertiesInput(): BackupDrBackupPlanDiskBackupPlanProperties | undefined;
    private _timeouts;
    get timeouts(): BackupDrBackupPlanTimeoutsOutputReference;
    putTimeouts(value: BackupDrBackupPlanTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BackupDrBackupPlanTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
