/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccessContextManagerServicePerimeterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#deletion_policy AccessContextManagerServicePerimeter#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Description of the ServicePerimeter and its use. Does not affect
    * behavior.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#description AccessContextManagerServicePerimeter#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#id AccessContextManagerServicePerimeter#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource name for the ServicePerimeter. The short_name component must
    * begin with a letter and only include alphanumeric and '_'.
    * Format: accessPolicies/{policy_id}/servicePerimeters/{short_name}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#name AccessContextManagerServicePerimeter#name}
    */
    readonly name: string;
    /**
    * The AccessPolicy this ServicePerimeter lives in.
    * Format: accessPolicies/{policy_id}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#parent AccessContextManagerServicePerimeter#parent}
    */
    readonly parent: string;
    /**
    * Specifies the type of the Perimeter. There are two types: regular and
    * bridge. Regular Service Perimeter contains resources, access levels,
    * and restricted services. Every resource can be in at most
    * ONE regular Service Perimeter.
    *
    * In addition to being in a regular service perimeter, a resource can also
    * be in zero or more perimeter bridges. A perimeter bridge only contains
    * resources. Cross project operations are permitted if all effected
    * resources share some perimeter (whether bridge or regular). Perimeter
    * Bridge does not contain access levels or services: those are governed
    * entirely by the regular perimeter that resource is in.
    *
    * Perimeter Bridges are typically useful when building more complex
    * topologies with many independent perimeters that need to share some data
    * with a common perimeter, but should not be able to share data among
    * themselves. Default value: "PERIMETER_TYPE_REGULAR" Possible values: ["PERIMETER_TYPE_REGULAR", "PERIMETER_TYPE_BRIDGE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#perimeter_type AccessContextManagerServicePerimeter#perimeter_type}
    */
    readonly perimeterType?: string;
    /**
    * Human readable title. Must be unique within the Policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#title AccessContextManagerServicePerimeter#title}
    */
    readonly title: string;
    /**
    * Use explicit dry run spec flag. Ordinarily, a dry-run spec implicitly exists
    * for all Service Perimeters, and that spec is identical to the status for those
    * Service Perimeters. When this flag is set, it inhibits the generation of the
    * implicit spec, thereby allowing the user to explicitly provide a
    * configuration ("spec") to use in a dry-run version of the Service Perimeter.
    * This allows the user to test changes to the enforced config ("status") without
    * actually enforcing them. This testing is done through analyzing the differences
    * between currently enforced and suggested restrictions. useExplicitDryRunSpec must
    * bet set to True if any of the fields in the spec are set to non-default values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#use_explicit_dry_run_spec AccessContextManagerServicePerimeter#use_explicit_dry_run_spec}
    */
    readonly useExplicitDryRunSpec?: boolean | cdktn.IResolvable;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#spec AccessContextManagerServicePerimeter#spec}
    */
    readonly spec?: AccessContextManagerServicePerimeterSpec;
    /**
    * status block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#status AccessContextManagerServicePerimeter#status}
    */
    readonly status?: AccessContextManagerServicePerimeterStatus;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#timeouts AccessContextManagerServicePerimeter#timeouts}
    */
    readonly timeouts?: AccessContextManagerServicePerimeterTimeouts;
}
export interface AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSourcesPscEndpoint {
    /**
    * The full resource name of the global forwarding rule that identifies a Private Service Connect endpoint.
    * Forwarding rule format: '//compute.googleapis.com/projects/{PROJECT_ID}/global/forwardingRules/{FORWARDING_RULE_ID}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#forwarding_rule AccessContextManagerServicePerimeter#forwarding_rule}
    */
    readonly forwardingRule?: string;
}
export declare function accessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSourcesPscEndpointToTerraform(struct?: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSourcesPscEndpointOutputReference | AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSourcesPscEndpoint): any;
export declare function accessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSourcesPscEndpointToHclTerraform(struct?: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSourcesPscEndpointOutputReference | AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSourcesPscEndpoint): any;
export declare class AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSourcesPscEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSourcesPscEndpoint | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSourcesPscEndpoint | undefined);
    private _forwardingRule?;
    get forwardingRule(): string;
    set forwardingRule(value: string);
    resetForwardingRule(): void;
    get forwardingRuleInput(): string | undefined;
}
export interface AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSources {
    /**
    * An AccessLevel resource name that allows resources outside the ServicePerimeter to be accessed from the inside.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#access_level AccessContextManagerServicePerimeter#access_level}
    */
    readonly accessLevel?: string;
    /**
    * A Google Cloud resource that is allowed to egress the perimeter.
    * Requests from these resources are allowed to access data outside the perimeter.
    * Projects, folders, and organizations are allowed.
    * Project format: 'projects/{project_number}'
    * Folder format: 'folders/{folder_number}'
    * Organization format: 'organizations/{organization_number}'
    * The resource may be in any Google Cloud organization, not just the
    * organization that the perimeter is defined in. '*' is not allowed, the
    * case of allowing all Google Cloud resources only is not supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#resource AccessContextManagerServicePerimeter#resource}
    */
    readonly resource?: string;
    /**
    * psc_endpoint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#psc_endpoint AccessContextManagerServicePerimeter#psc_endpoint}
    */
    readonly pscEndpoint?: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSourcesPscEndpoint;
}
export declare function accessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSourcesToTerraform(struct?: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSources | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSourcesToHclTerraform(struct?: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSources | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSources | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSources | cdktn.IResolvable | undefined);
    private _accessLevel?;
    get accessLevel(): string;
    set accessLevel(value: string);
    resetAccessLevel(): void;
    get accessLevelInput(): string | undefined;
    private _resource?;
    get resource(): string;
    set resource(value: string);
    resetResource(): void;
    get resourceInput(): string | undefined;
    private _pscEndpoint;
    get pscEndpoint(): AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSourcesPscEndpointOutputReference;
    putPscEndpoint(value: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSourcesPscEndpoint): void;
    resetPscEndpoint(): void;
    get pscEndpointInput(): AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSourcesPscEndpoint | undefined;
}
export declare class AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSourcesList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSourcesOutputReference;
}
export interface AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFrom {
    /**
    * A list of identities that are allowed access through this 'EgressPolicy'.
    * Should be in the format of email address. The email address should
    * represent individual user or service account only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#identities AccessContextManagerServicePerimeter#identities}
    */
    readonly identities?: string[];
    /**
    * Specifies the type of identities that are allowed access to outside the
    * perimeter. If left unspecified, then members of 'identities' field will
    * be allowed access. Possible values: ["IDENTITY_TYPE_UNSPECIFIED", "ANY_IDENTITY", "ANY_USER_ACCOUNT", "ANY_SERVICE_ACCOUNT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#identity_type AccessContextManagerServicePerimeter#identity_type}
    */
    readonly identityType?: string;
    /**
    * Whether to enforce traffic restrictions based on 'sources' field. If the 'sources' field is non-empty, then this field must be set to 'SOURCE_RESTRICTION_ENABLED'. Possible values: ["SOURCE_RESTRICTION_UNSPECIFIED", "SOURCE_RESTRICTION_ENABLED", "SOURCE_RESTRICTION_DISABLED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#source_restriction AccessContextManagerServicePerimeter#source_restriction}
    */
    readonly sourceRestriction?: string;
    /**
    * sources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#sources AccessContextManagerServicePerimeter#sources}
    */
    readonly sources?: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSources[] | cdktn.IResolvable;
}
export declare function accessContextManagerServicePerimeterSpecEgressPoliciesEgressFromToTerraform(struct?: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromOutputReference | AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFrom): any;
export declare function accessContextManagerServicePerimeterSpecEgressPoliciesEgressFromToHclTerraform(struct?: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromOutputReference | AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFrom): any;
export declare class AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFrom | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFrom | undefined);
    private _identities?;
    get identities(): string[];
    set identities(value: string[]);
    resetIdentities(): void;
    get identitiesInput(): string[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
    private _sourceRestriction?;
    get sourceRestriction(): string;
    set sourceRestriction(value: string);
    resetSourceRestriction(): void;
    get sourceRestrictionInput(): string | undefined;
    private _sources;
    get sources(): AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSourcesList;
    putSources(value: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSources[] | cdktn.IResolvable): void;
    resetSources(): void;
    get sourcesInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromSources[] | undefined;
}
export interface AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperationsMethodSelectors {
    /**
    * Value for 'method' should be a valid method name for the corresponding
    * 'serviceName' in 'ApiOperation'. If '*' used as value for method,
    * then ALL methods and permissions are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#method AccessContextManagerServicePerimeter#method}
    */
    readonly method?: string;
    /**
    * Value for permission should be a valid Cloud IAM permission for the
    * corresponding 'serviceName' in 'ApiOperation'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#permission AccessContextManagerServicePerimeter#permission}
    */
    readonly permission?: string;
}
export declare function accessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperationsMethodSelectorsToTerraform(struct?: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperationsMethodSelectors | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperationsMethodSelectorsToHclTerraform(struct?: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperationsMethodSelectors | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperationsMethodSelectorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperationsMethodSelectors | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperationsMethodSelectors | cdktn.IResolvable | undefined);
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    resetPermission(): void;
    get permissionInput(): string | undefined;
}
export declare class AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperationsMethodSelectorsList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperationsMethodSelectors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperationsMethodSelectorsOutputReference;
}
export interface AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperations {
    /**
    * The name of the API whose methods or permissions the 'IngressPolicy' or
    * 'EgressPolicy' want to allow. A single 'ApiOperation' with serviceName
    * field set to '*' will allow all methods AND permissions for all services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#service_name AccessContextManagerServicePerimeter#service_name}
    */
    readonly serviceName?: string;
    /**
    * method_selectors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#method_selectors AccessContextManagerServicePerimeter#method_selectors}
    */
    readonly methodSelectors?: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperationsMethodSelectors[] | cdktn.IResolvable;
}
export declare function accessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperationsToTerraform(struct?: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperations | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperationsToHclTerraform(struct?: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperations | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperations | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperations | cdktn.IResolvable | undefined);
    private _serviceName?;
    get serviceName(): string;
    set serviceName(value: string);
    resetServiceName(): void;
    get serviceNameInput(): string | undefined;
    private _methodSelectors;
    get methodSelectors(): AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperationsMethodSelectorsList;
    putMethodSelectors(value: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperationsMethodSelectors[] | cdktn.IResolvable): void;
    resetMethodSelectors(): void;
    get methodSelectorsInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperationsMethodSelectors[] | undefined;
}
export declare class AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperationsList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperationsOutputReference;
}
export interface AccessContextManagerServicePerimeterSpecEgressPoliciesEgressTo {
    /**
    * A list of external resources that are allowed to be accessed. A request
    * matches if it contains an external resource in this list (Example:
    * s3://bucket/path). Currently '*' is not allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#external_resources AccessContextManagerServicePerimeter#external_resources}
    */
    readonly externalResources?: string[];
    /**
    * A list of resources, in the form 'projects/{project_number}',
    * 'folders/{folder_number}', or 'organizations/{organization_number}',
    * that match this to stanza. A request matches
    * if it contains a resource in this list. If * is specified for resources,
    * then this 'EgressTo' rule will authorize access to all resources outside
    * the perimeter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#resources AccessContextManagerServicePerimeter#resources}
    */
    readonly resources?: string[];
    /**
    * A list of IAM roles that represent the set of operations that the sources
    * specified in the corresponding 'EgressFrom'
    * are allowed to perform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#roles AccessContextManagerServicePerimeter#roles}
    */
    readonly roles?: string[];
    /**
    * operations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#operations AccessContextManagerServicePerimeter#operations}
    */
    readonly operations?: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperations[] | cdktn.IResolvable;
}
export declare function accessContextManagerServicePerimeterSpecEgressPoliciesEgressToToTerraform(struct?: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOutputReference | AccessContextManagerServicePerimeterSpecEgressPoliciesEgressTo): any;
export declare function accessContextManagerServicePerimeterSpecEgressPoliciesEgressToToHclTerraform(struct?: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOutputReference | AccessContextManagerServicePerimeterSpecEgressPoliciesEgressTo): any;
export declare class AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterSpecEgressPoliciesEgressTo | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressTo | undefined);
    private _externalResources?;
    get externalResources(): string[];
    set externalResources(value: string[]);
    resetExternalResources(): void;
    get externalResourcesInput(): string[] | undefined;
    private _resources?;
    get resources(): string[];
    set resources(value: string[]);
    resetResources(): void;
    get resourcesInput(): string[] | undefined;
    private _roles?;
    get roles(): string[];
    set roles(value: string[]);
    resetRoles(): void;
    get rolesInput(): string[] | undefined;
    private _operations;
    get operations(): AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperationsList;
    putOperations(value: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperations[] | cdktn.IResolvable): void;
    resetOperations(): void;
    get operationsInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOperations[] | undefined;
}
export interface AccessContextManagerServicePerimeterSpecEgressPolicies {
    /**
    * Human readable title. Must be unique within the perimeter. Does not affect behavior.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#title AccessContextManagerServicePerimeter#title}
    */
    readonly title?: string;
    /**
    * egress_from block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#egress_from AccessContextManagerServicePerimeter#egress_from}
    */
    readonly egressFrom?: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFrom;
    /**
    * egress_to block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#egress_to AccessContextManagerServicePerimeter#egress_to}
    */
    readonly egressTo?: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressTo;
}
export declare function accessContextManagerServicePerimeterSpecEgressPoliciesToTerraform(struct?: AccessContextManagerServicePerimeterSpecEgressPolicies | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterSpecEgressPoliciesToHclTerraform(struct?: AccessContextManagerServicePerimeterSpecEgressPolicies | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterSpecEgressPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterSpecEgressPolicies | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterSpecEgressPolicies | cdktn.IResolvable | undefined);
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _egressFrom;
    get egressFrom(): AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFromOutputReference;
    putEgressFrom(value: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFrom): void;
    resetEgressFrom(): void;
    get egressFromInput(): AccessContextManagerServicePerimeterSpecEgressPoliciesEgressFrom | undefined;
    private _egressTo;
    get egressTo(): AccessContextManagerServicePerimeterSpecEgressPoliciesEgressToOutputReference;
    putEgressTo(value: AccessContextManagerServicePerimeterSpecEgressPoliciesEgressTo): void;
    resetEgressTo(): void;
    get egressToInput(): AccessContextManagerServicePerimeterSpecEgressPoliciesEgressTo | undefined;
}
export declare class AccessContextManagerServicePerimeterSpecEgressPoliciesList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterSpecEgressPolicies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterSpecEgressPoliciesOutputReference;
}
export interface AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSourcesPscEndpoint {
    /**
    * The full resource name of the global forwarding rule that identifies a Private Service Connect endpoint.
    * Forwarding rule format: '//compute.googleapis.com/projects/{PROJECT_ID}/global/forwardingRules/{FORWARDING_RULE_ID}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#forwarding_rule AccessContextManagerServicePerimeter#forwarding_rule}
    */
    readonly forwardingRule?: string;
}
export declare function accessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSourcesPscEndpointToTerraform(struct?: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSourcesPscEndpointOutputReference | AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSourcesPscEndpoint): any;
export declare function accessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSourcesPscEndpointToHclTerraform(struct?: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSourcesPscEndpointOutputReference | AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSourcesPscEndpoint): any;
export declare class AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSourcesPscEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSourcesPscEndpoint | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSourcesPscEndpoint | undefined);
    private _forwardingRule?;
    get forwardingRule(): string;
    set forwardingRule(value: string);
    resetForwardingRule(): void;
    get forwardingRuleInput(): string | undefined;
}
export interface AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSources {
    /**
    * An 'AccessLevel' resource name that allow resources within the
    * 'ServicePerimeters' to be accessed from the internet. 'AccessLevels' listed
    * must be in the same policy as this 'ServicePerimeter'. Referencing a nonexistent
    * 'AccessLevel' will cause an error. If no 'AccessLevel' names are listed,
    * resources within the perimeter can only be accessed via Google Cloud calls
    * with request origins within the perimeter.
    * Example 'accessPolicies/MY_POLICY/accessLevels/MY_LEVEL.'
    * If * is specified, then all IngressSources will be allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#access_level AccessContextManagerServicePerimeter#access_level}
    */
    readonly accessLevel?: string;
    /**
    * A Google Cloud resource that is allowed to ingress the perimeter.
    * Requests from these resources will be allowed to access perimeter data.
    * Projects, folders, organizations, and VPC networks are allowed.
    * Project format: 'projects/{project_number}'
    * Folder format: 'folders/{folder_number}'
    * Organization format: 'organizations/{organization_number}'
    * VPC network format: '//compute.googleapis.com/projects/{PROJECT_ID}/global/networks/{NAME}'
    * The resource may be in any Google Cloud organization, not just the
    * organization that the perimeter is defined in. '*' is not allowed, the case
    * of allowing all Google Cloud resources only is not supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#resource AccessContextManagerServicePerimeter#resource}
    */
    readonly resource?: string;
    /**
    * psc_endpoint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#psc_endpoint AccessContextManagerServicePerimeter#psc_endpoint}
    */
    readonly pscEndpoint?: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSourcesPscEndpoint;
}
export declare function accessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSourcesToTerraform(struct?: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSources | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSourcesToHclTerraform(struct?: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSources | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSources | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSources | cdktn.IResolvable | undefined);
    private _accessLevel?;
    get accessLevel(): string;
    set accessLevel(value: string);
    resetAccessLevel(): void;
    get accessLevelInput(): string | undefined;
    private _resource?;
    get resource(): string;
    set resource(value: string);
    resetResource(): void;
    get resourceInput(): string | undefined;
    private _pscEndpoint;
    get pscEndpoint(): AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSourcesPscEndpointOutputReference;
    putPscEndpoint(value: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSourcesPscEndpoint): void;
    resetPscEndpoint(): void;
    get pscEndpointInput(): AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSourcesPscEndpoint | undefined;
}
export declare class AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSourcesList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSourcesOutputReference;
}
export interface AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFrom {
    /**
    * A list of identities that are allowed access through this ingress policy.
    * Should be in the format of email address. The email address should represent
    * individual user or service account only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#identities AccessContextManagerServicePerimeter#identities}
    */
    readonly identities?: string[];
    /**
    * Specifies the type of identities that are allowed access from outside the
    * perimeter. If left unspecified, then members of 'identities' field will be
    * allowed access. Possible values: ["IDENTITY_TYPE_UNSPECIFIED", "ANY_IDENTITY", "ANY_USER_ACCOUNT", "ANY_SERVICE_ACCOUNT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#identity_type AccessContextManagerServicePerimeter#identity_type}
    */
    readonly identityType?: string;
    /**
    * sources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#sources AccessContextManagerServicePerimeter#sources}
    */
    readonly sources?: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSources[] | cdktn.IResolvable;
}
export declare function accessContextManagerServicePerimeterSpecIngressPoliciesIngressFromToTerraform(struct?: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromOutputReference | AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFrom): any;
export declare function accessContextManagerServicePerimeterSpecIngressPoliciesIngressFromToHclTerraform(struct?: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromOutputReference | AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFrom): any;
export declare class AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFrom | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFrom | undefined);
    private _identities?;
    get identities(): string[];
    set identities(value: string[]);
    resetIdentities(): void;
    get identitiesInput(): string[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
    private _sources;
    get sources(): AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSourcesList;
    putSources(value: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSources[] | cdktn.IResolvable): void;
    resetSources(): void;
    get sourcesInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromSources[] | undefined;
}
export interface AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperationsMethodSelectors {
    /**
    * Value for method should be a valid method name for the corresponding
    * serviceName in 'ApiOperation'. If '*' used as value for 'method', then
    * ALL methods and permissions are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#method AccessContextManagerServicePerimeter#method}
    */
    readonly method?: string;
    /**
    * Value for permission should be a valid Cloud IAM permission for the
    * corresponding 'serviceName' in 'ApiOperation'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#permission AccessContextManagerServicePerimeter#permission}
    */
    readonly permission?: string;
}
export declare function accessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperationsMethodSelectorsToTerraform(struct?: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperationsMethodSelectors | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperationsMethodSelectorsToHclTerraform(struct?: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperationsMethodSelectors | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperationsMethodSelectorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperationsMethodSelectors | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperationsMethodSelectors | cdktn.IResolvable | undefined);
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    resetPermission(): void;
    get permissionInput(): string | undefined;
}
export declare class AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperationsMethodSelectorsList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperationsMethodSelectors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperationsMethodSelectorsOutputReference;
}
export interface AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperations {
    /**
    * The name of the API whose methods or permissions the 'IngressPolicy' or
    * 'EgressPolicy' want to allow. A single 'ApiOperation' with 'serviceName'
    * field set to '*' will allow all methods AND permissions for all services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#service_name AccessContextManagerServicePerimeter#service_name}
    */
    readonly serviceName?: string;
    /**
    * method_selectors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#method_selectors AccessContextManagerServicePerimeter#method_selectors}
    */
    readonly methodSelectors?: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperationsMethodSelectors[] | cdktn.IResolvable;
}
export declare function accessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperationsToTerraform(struct?: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperations | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperationsToHclTerraform(struct?: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperations | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperations | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperations | cdktn.IResolvable | undefined);
    private _serviceName?;
    get serviceName(): string;
    set serviceName(value: string);
    resetServiceName(): void;
    get serviceNameInput(): string | undefined;
    private _methodSelectors;
    get methodSelectors(): AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperationsMethodSelectorsList;
    putMethodSelectors(value: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperationsMethodSelectors[] | cdktn.IResolvable): void;
    resetMethodSelectors(): void;
    get methodSelectorsInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperationsMethodSelectors[] | undefined;
}
export declare class AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperationsList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperationsOutputReference;
}
export interface AccessContextManagerServicePerimeterSpecIngressPoliciesIngressTo {
    /**
    * A list of resources protected by this 'ServicePerimeter', in the form
    * 'projects/{project_number}', 'folders/{folder_number}', or
    * 'organizations/{organization_number}',
    * that are allowed to be accessed by sources defined in the
    * corresponding 'IngressFrom'. A request matches if it contains
    * a resource in this list. If '*' is specified for resources,
    * then this 'IngressTo' rule will authorize access to all
    * resources inside the perimeter, provided that the request
    * also matches the 'operations' field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#resources AccessContextManagerServicePerimeter#resources}
    */
    readonly resources?: string[];
    /**
    * A list of IAM roles that represent the set of operations that the sources
    * specified in the corresponding 'IngressFrom'
    * are allowed to perform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#roles AccessContextManagerServicePerimeter#roles}
    */
    readonly roles?: string[];
    /**
    * operations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#operations AccessContextManagerServicePerimeter#operations}
    */
    readonly operations?: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperations[] | cdktn.IResolvable;
}
export declare function accessContextManagerServicePerimeterSpecIngressPoliciesIngressToToTerraform(struct?: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOutputReference | AccessContextManagerServicePerimeterSpecIngressPoliciesIngressTo): any;
export declare function accessContextManagerServicePerimeterSpecIngressPoliciesIngressToToHclTerraform(struct?: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOutputReference | AccessContextManagerServicePerimeterSpecIngressPoliciesIngressTo): any;
export declare class AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterSpecIngressPoliciesIngressTo | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressTo | undefined);
    private _resources?;
    get resources(): string[];
    set resources(value: string[]);
    resetResources(): void;
    get resourcesInput(): string[] | undefined;
    private _roles?;
    get roles(): string[];
    set roles(value: string[]);
    resetRoles(): void;
    get rolesInput(): string[] | undefined;
    private _operations;
    get operations(): AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperationsList;
    putOperations(value: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperations[] | cdktn.IResolvable): void;
    resetOperations(): void;
    get operationsInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOperations[] | undefined;
}
export interface AccessContextManagerServicePerimeterSpecIngressPolicies {
    /**
    * Human readable title. Must be unique within the perimeter. Does not affect behavior.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#title AccessContextManagerServicePerimeter#title}
    */
    readonly title?: string;
    /**
    * ingress_from block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#ingress_from AccessContextManagerServicePerimeter#ingress_from}
    */
    readonly ingressFrom?: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFrom;
    /**
    * ingress_to block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#ingress_to AccessContextManagerServicePerimeter#ingress_to}
    */
    readonly ingressTo?: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressTo;
}
export declare function accessContextManagerServicePerimeterSpecIngressPoliciesToTerraform(struct?: AccessContextManagerServicePerimeterSpecIngressPolicies | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterSpecIngressPoliciesToHclTerraform(struct?: AccessContextManagerServicePerimeterSpecIngressPolicies | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterSpecIngressPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterSpecIngressPolicies | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterSpecIngressPolicies | cdktn.IResolvable | undefined);
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _ingressFrom;
    get ingressFrom(): AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFromOutputReference;
    putIngressFrom(value: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFrom): void;
    resetIngressFrom(): void;
    get ingressFromInput(): AccessContextManagerServicePerimeterSpecIngressPoliciesIngressFrom | undefined;
    private _ingressTo;
    get ingressTo(): AccessContextManagerServicePerimeterSpecIngressPoliciesIngressToOutputReference;
    putIngressTo(value: AccessContextManagerServicePerimeterSpecIngressPoliciesIngressTo): void;
    resetIngressTo(): void;
    get ingressToInput(): AccessContextManagerServicePerimeterSpecIngressPoliciesIngressTo | undefined;
}
export declare class AccessContextManagerServicePerimeterSpecIngressPoliciesList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterSpecIngressPolicies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterSpecIngressPoliciesOutputReference;
}
export interface AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeader {
    /**
    * HTTP header key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#key AccessContextManagerServicePerimeter#key}
    */
    readonly key: string;
    /**
    * HTTP header value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#value AccessContextManagerServicePerimeter#value}
    */
    readonly value: string;
}
export declare function accessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeaderToTerraform(struct?: AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeaderOutputReference | AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeader): any;
export declare function accessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeaderToHclTerraform(struct?: AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeaderOutputReference | AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeader): any;
export declare class AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeader | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeader | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export interface AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiers {
    /**
    * add_request_header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#add_request_header AccessContextManagerServicePerimeter#add_request_header}
    */
    readonly addRequestHeader?: AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeader;
}
export declare function accessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiersToTerraform(struct?: AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiers | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiersToHclTerraform(struct?: AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiers | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiers | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiers | cdktn.IResolvable | undefined);
    private _addRequestHeader;
    get addRequestHeader(): AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeaderOutputReference;
    putAddRequestHeader(value: AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeader): void;
    resetAddRequestHeader(): void;
    get addRequestHeaderInput(): AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeader | undefined;
}
export declare class AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiersList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiersOutputReference;
}
export interface AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatterns {
    /**
    * URL pattern to allow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#pattern AccessContextManagerServicePerimeter#pattern}
    */
    readonly pattern?: string;
    /**
    * Supported service to allow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#service AccessContextManagerServicePerimeter#service}
    */
    readonly service?: string;
    /**
    * modifiers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#modifiers AccessContextManagerServicePerimeter#modifiers}
    */
    readonly modifiers?: AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiers[] | cdktn.IResolvable;
}
export declare function accessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsToTerraform(struct?: AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatterns | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsToHclTerraform(struct?: AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatterns | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatterns | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatterns | cdktn.IResolvable | undefined);
    private _pattern?;
    get pattern(): string;
    set pattern(value: string);
    resetPattern(): void;
    get patternInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
    private _modifiers;
    get modifiers(): AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiersList;
    putModifiers(value: AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiers[] | cdktn.IResolvable): void;
    resetModifiers(): void;
    get modifiersInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsModifiers[] | undefined;
}
export declare class AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatterns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsOutputReference;
}
export interface AccessContextManagerServicePerimeterSpecVpcAccessibleServices {
    /**
    * The list of APIs usable within the Service Perimeter.
    * Must be empty unless 'enableRestriction' is True.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#allowed_services AccessContextManagerServicePerimeter#allowed_services}
    */
    readonly allowedServices?: string[];
    /**
    * Whether to restrict API calls within the Service Perimeter to the
    * list of APIs specified in 'allowedServices'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#enable_restriction AccessContextManagerServicePerimeter#enable_restriction}
    */
    readonly enableRestriction?: boolean | cdktn.IResolvable;
    /**
    * Defines the enforcement scopes of service patterns. Possible values: ["GOOGLE_APIS_VIA_PRIVATE_PATH"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#service_patterns_enforcement_scopes AccessContextManagerServicePerimeter#service_patterns_enforcement_scopes}
    */
    readonly servicePatternsEnforcementScopes?: string[];
    /**
    * allowed_service_patterns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#allowed_service_patterns AccessContextManagerServicePerimeter#allowed_service_patterns}
    */
    readonly allowedServicePatterns?: AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatterns[] | cdktn.IResolvable;
}
export declare function accessContextManagerServicePerimeterSpecVpcAccessibleServicesToTerraform(struct?: AccessContextManagerServicePerimeterSpecVpcAccessibleServicesOutputReference | AccessContextManagerServicePerimeterSpecVpcAccessibleServices): any;
export declare function accessContextManagerServicePerimeterSpecVpcAccessibleServicesToHclTerraform(struct?: AccessContextManagerServicePerimeterSpecVpcAccessibleServicesOutputReference | AccessContextManagerServicePerimeterSpecVpcAccessibleServices): any;
export declare class AccessContextManagerServicePerimeterSpecVpcAccessibleServicesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterSpecVpcAccessibleServices | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterSpecVpcAccessibleServices | undefined);
    private _allowedServices?;
    get allowedServices(): string[];
    set allowedServices(value: string[]);
    resetAllowedServices(): void;
    get allowedServicesInput(): string[] | undefined;
    private _enableRestriction?;
    get enableRestriction(): boolean | cdktn.IResolvable;
    set enableRestriction(value: boolean | cdktn.IResolvable);
    resetEnableRestriction(): void;
    get enableRestrictionInput(): boolean | cdktn.IResolvable | undefined;
    private _servicePatternsEnforcementScopes?;
    get servicePatternsEnforcementScopes(): string[];
    set servicePatternsEnforcementScopes(value: string[]);
    resetServicePatternsEnforcementScopes(): void;
    get servicePatternsEnforcementScopesInput(): string[] | undefined;
    private _allowedServicePatterns;
    get allowedServicePatterns(): AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatternsList;
    putAllowedServicePatterns(value: AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatterns[] | cdktn.IResolvable): void;
    resetAllowedServicePatterns(): void;
    get allowedServicePatternsInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterSpecVpcAccessibleServicesAllowedServicePatterns[] | undefined;
}
export interface AccessContextManagerServicePerimeterSpec {
    /**
    * A list of AccessLevel resource names that allow resources within
    * the ServicePerimeter to be accessed from the internet.
    * AccessLevels listed must be in the same policy as this
    * ServicePerimeter. Referencing a nonexistent AccessLevel is a
    * syntax error. If no AccessLevel names are listed, resources within
    * the perimeter can only be accessed via GCP calls with request
    * origins within the perimeter. For Service Perimeter Bridge, must
    * be empty.
    *
    * Format: accessPolicies/{policy_id}/accessLevels/{access_level_name}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#access_levels AccessContextManagerServicePerimeter#access_levels}
    */
    readonly accessLevels?: string[];
    /**
    * A list of GCP resources that are inside of the service perimeter.
    * Projects, folders, and VPC networks are allowed.
    * Project format: 'projects/{project_number}'
    * Folder format: 'folders/{folder_number}'
    * VPC network format: '//compute.googleapis.com/projects/{PROJECT_ID}/global/networks/{NAME}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#resources AccessContextManagerServicePerimeter#resources}
    */
    readonly resources?: string[];
    /**
    * GCP services that are subject to the Service Perimeter
    * restrictions. Must contain a list of services. For example, if
    * 'storage.googleapis.com' is specified, access to the storage
    * buckets inside the perimeter must meet the perimeter's access
    * restrictions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#restricted_services AccessContextManagerServicePerimeter#restricted_services}
    */
    readonly restrictedServices?: string[];
    /**
    * egress_policies block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#egress_policies AccessContextManagerServicePerimeter#egress_policies}
    */
    readonly egressPolicies?: AccessContextManagerServicePerimeterSpecEgressPolicies[] | cdktn.IResolvable;
    /**
    * ingress_policies block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#ingress_policies AccessContextManagerServicePerimeter#ingress_policies}
    */
    readonly ingressPolicies?: AccessContextManagerServicePerimeterSpecIngressPolicies[] | cdktn.IResolvable;
    /**
    * vpc_accessible_services block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#vpc_accessible_services AccessContextManagerServicePerimeter#vpc_accessible_services}
    */
    readonly vpcAccessibleServices?: AccessContextManagerServicePerimeterSpecVpcAccessibleServices;
}
export declare function accessContextManagerServicePerimeterSpecToTerraform(struct?: AccessContextManagerServicePerimeterSpecOutputReference | AccessContextManagerServicePerimeterSpec): any;
export declare function accessContextManagerServicePerimeterSpecToHclTerraform(struct?: AccessContextManagerServicePerimeterSpecOutputReference | AccessContextManagerServicePerimeterSpec): any;
export declare class AccessContextManagerServicePerimeterSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterSpec | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterSpec | undefined);
    private _accessLevels?;
    get accessLevels(): string[];
    set accessLevels(value: string[]);
    resetAccessLevels(): void;
    get accessLevelsInput(): string[] | undefined;
    private _resources?;
    get resources(): string[];
    set resources(value: string[]);
    resetResources(): void;
    get resourcesInput(): string[] | undefined;
    private _restrictedServices?;
    get restrictedServices(): string[];
    set restrictedServices(value: string[]);
    resetRestrictedServices(): void;
    get restrictedServicesInput(): string[] | undefined;
    private _egressPolicies;
    get egressPolicies(): AccessContextManagerServicePerimeterSpecEgressPoliciesList;
    putEgressPolicies(value: AccessContextManagerServicePerimeterSpecEgressPolicies[] | cdktn.IResolvable): void;
    resetEgressPolicies(): void;
    get egressPoliciesInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterSpecEgressPolicies[] | undefined;
    private _ingressPolicies;
    get ingressPolicies(): AccessContextManagerServicePerimeterSpecIngressPoliciesList;
    putIngressPolicies(value: AccessContextManagerServicePerimeterSpecIngressPolicies[] | cdktn.IResolvable): void;
    resetIngressPolicies(): void;
    get ingressPoliciesInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterSpecIngressPolicies[] | undefined;
    private _vpcAccessibleServices;
    get vpcAccessibleServices(): AccessContextManagerServicePerimeterSpecVpcAccessibleServicesOutputReference;
    putVpcAccessibleServices(value: AccessContextManagerServicePerimeterSpecVpcAccessibleServices): void;
    resetVpcAccessibleServices(): void;
    get vpcAccessibleServicesInput(): AccessContextManagerServicePerimeterSpecVpcAccessibleServices | undefined;
}
export interface AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSourcesPscEndpoint {
    /**
    * The full resource name of the global forwarding rule that identifies a Private Service Connect endpoint.
    * Forwarding rule format: '//compute.googleapis.com/projects/{PROJECT_ID}/global/forwardingRules/{FORWARDING_RULE_ID}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#forwarding_rule AccessContextManagerServicePerimeter#forwarding_rule}
    */
    readonly forwardingRule?: string;
}
export declare function accessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSourcesPscEndpointToTerraform(struct?: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSourcesPscEndpointOutputReference | AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSourcesPscEndpoint): any;
export declare function accessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSourcesPscEndpointToHclTerraform(struct?: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSourcesPscEndpointOutputReference | AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSourcesPscEndpoint): any;
export declare class AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSourcesPscEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSourcesPscEndpoint | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSourcesPscEndpoint | undefined);
    private _forwardingRule?;
    get forwardingRule(): string;
    set forwardingRule(value: string);
    resetForwardingRule(): void;
    get forwardingRuleInput(): string | undefined;
}
export interface AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSources {
    /**
    * An AccessLevel resource name that allows resources outside the ServicePerimeter to be accessed from the inside.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#access_level AccessContextManagerServicePerimeter#access_level}
    */
    readonly accessLevel?: string;
    /**
    * A Google Cloud resource that is allowed to egress the perimeter.
    * Requests from these resources are allowed to access data outside the perimeter.
    * Projects, folders, and organizations are allowed.
    * Project format: 'projects/{project_number}'
    * Folder format: 'folders/{folder_number}'
    * Organization format: 'organizations/{organization_number}'
    * The resource may be in any Google Cloud organization, not just the
    * organization that the perimeter is defined in. '*' is not allowed, the
    * case of allowing all Google Cloud resources only is not supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#resource AccessContextManagerServicePerimeter#resource}
    */
    readonly resource?: string;
    /**
    * psc_endpoint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#psc_endpoint AccessContextManagerServicePerimeter#psc_endpoint}
    */
    readonly pscEndpoint?: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSourcesPscEndpoint;
}
export declare function accessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSourcesToTerraform(struct?: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSources | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSourcesToHclTerraform(struct?: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSources | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSources | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSources | cdktn.IResolvable | undefined);
    private _accessLevel?;
    get accessLevel(): string;
    set accessLevel(value: string);
    resetAccessLevel(): void;
    get accessLevelInput(): string | undefined;
    private _resource?;
    get resource(): string;
    set resource(value: string);
    resetResource(): void;
    get resourceInput(): string | undefined;
    private _pscEndpoint;
    get pscEndpoint(): AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSourcesPscEndpointOutputReference;
    putPscEndpoint(value: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSourcesPscEndpoint): void;
    resetPscEndpoint(): void;
    get pscEndpointInput(): AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSourcesPscEndpoint | undefined;
}
export declare class AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSourcesList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSourcesOutputReference;
}
export interface AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFrom {
    /**
    * Identities can be an individual user, service account, Google group,
    * or third-party identity. For third-party identity, only single identities
    * are supported and other identity types are not supported.The v1 identities
    * that have the prefix user, group and serviceAccount in
    * https://cloud.google.com/iam/docs/principal-identifiers#v1 are supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#identities AccessContextManagerServicePerimeter#identities}
    */
    readonly identities?: string[];
    /**
    * Specifies the type of identities that are allowed access to outside the
    * perimeter. If left unspecified, then members of 'identities' field will
    * be allowed access. Possible values: ["IDENTITY_TYPE_UNSPECIFIED", "ANY_IDENTITY", "ANY_USER_ACCOUNT", "ANY_SERVICE_ACCOUNT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#identity_type AccessContextManagerServicePerimeter#identity_type}
    */
    readonly identityType?: string;
    /**
    * Whether to enforce traffic restrictions based on 'sources' field. If the 'sources' field is non-empty, then this field must be set to 'SOURCE_RESTRICTION_ENABLED'. Possible values: ["SOURCE_RESTRICTION_UNSPECIFIED", "SOURCE_RESTRICTION_ENABLED", "SOURCE_RESTRICTION_DISABLED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#source_restriction AccessContextManagerServicePerimeter#source_restriction}
    */
    readonly sourceRestriction?: string;
    /**
    * sources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#sources AccessContextManagerServicePerimeter#sources}
    */
    readonly sources?: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSources[] | cdktn.IResolvable;
}
export declare function accessContextManagerServicePerimeterStatusEgressPoliciesEgressFromToTerraform(struct?: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromOutputReference | AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFrom): any;
export declare function accessContextManagerServicePerimeterStatusEgressPoliciesEgressFromToHclTerraform(struct?: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromOutputReference | AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFrom): any;
export declare class AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFrom | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFrom | undefined);
    private _identities?;
    get identities(): string[];
    set identities(value: string[]);
    resetIdentities(): void;
    get identitiesInput(): string[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
    private _sourceRestriction?;
    get sourceRestriction(): string;
    set sourceRestriction(value: string);
    resetSourceRestriction(): void;
    get sourceRestrictionInput(): string | undefined;
    private _sources;
    get sources(): AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSourcesList;
    putSources(value: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSources[] | cdktn.IResolvable): void;
    resetSources(): void;
    get sourcesInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromSources[] | undefined;
}
export interface AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperationsMethodSelectors {
    /**
    * Value for 'method' should be a valid method name for the corresponding
    * 'serviceName' in 'ApiOperation'. If '*' used as value for method,
    * then ALL methods and permissions are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#method AccessContextManagerServicePerimeter#method}
    */
    readonly method?: string;
    /**
    * Value for permission should be a valid Cloud IAM permission for the
    * corresponding 'serviceName' in 'ApiOperation'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#permission AccessContextManagerServicePerimeter#permission}
    */
    readonly permission?: string;
}
export declare function accessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperationsMethodSelectorsToTerraform(struct?: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperationsMethodSelectors | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperationsMethodSelectorsToHclTerraform(struct?: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperationsMethodSelectors | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperationsMethodSelectorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperationsMethodSelectors | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperationsMethodSelectors | cdktn.IResolvable | undefined);
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    resetPermission(): void;
    get permissionInput(): string | undefined;
}
export declare class AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperationsMethodSelectorsList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperationsMethodSelectors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperationsMethodSelectorsOutputReference;
}
export interface AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperations {
    /**
    * The name of the API whose methods or permissions the 'IngressPolicy' or
    * 'EgressPolicy' want to allow. A single 'ApiOperation' with serviceName
    * field set to '*' will allow all methods AND permissions for all services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#service_name AccessContextManagerServicePerimeter#service_name}
    */
    readonly serviceName?: string;
    /**
    * method_selectors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#method_selectors AccessContextManagerServicePerimeter#method_selectors}
    */
    readonly methodSelectors?: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperationsMethodSelectors[] | cdktn.IResolvable;
}
export declare function accessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperationsToTerraform(struct?: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperations | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperationsToHclTerraform(struct?: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperations | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperations | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperations | cdktn.IResolvable | undefined);
    private _serviceName?;
    get serviceName(): string;
    set serviceName(value: string);
    resetServiceName(): void;
    get serviceNameInput(): string | undefined;
    private _methodSelectors;
    get methodSelectors(): AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperationsMethodSelectorsList;
    putMethodSelectors(value: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperationsMethodSelectors[] | cdktn.IResolvable): void;
    resetMethodSelectors(): void;
    get methodSelectorsInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperationsMethodSelectors[] | undefined;
}
export declare class AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperationsList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperationsOutputReference;
}
export interface AccessContextManagerServicePerimeterStatusEgressPoliciesEgressTo {
    /**
    * A list of external resources that are allowed to be accessed. A request
    * matches if it contains an external resource in this list (Example:
    * s3://bucket/path). Currently '*' is not allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#external_resources AccessContextManagerServicePerimeter#external_resources}
    */
    readonly externalResources?: string[];
    /**
    * A list of resources, in the form 'projects/{project_number}',
    * 'folders/{folder_number}', or 'organizations/{organization_number}',
    * that match this to stanza. A request matches
    * if it contains a resource in this list. If * is specified for resources,
    * then this 'EgressTo' rule will authorize access to all resources outside
    * the perimeter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#resources AccessContextManagerServicePerimeter#resources}
    */
    readonly resources?: string[];
    /**
    * A list of IAM roles that represent the set of operations that the sources
    * specified in the corresponding 'EgressFrom'
    * are allowed to perform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#roles AccessContextManagerServicePerimeter#roles}
    */
    readonly roles?: string[];
    /**
    * operations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#operations AccessContextManagerServicePerimeter#operations}
    */
    readonly operations?: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperations[] | cdktn.IResolvable;
}
export declare function accessContextManagerServicePerimeterStatusEgressPoliciesEgressToToTerraform(struct?: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOutputReference | AccessContextManagerServicePerimeterStatusEgressPoliciesEgressTo): any;
export declare function accessContextManagerServicePerimeterStatusEgressPoliciesEgressToToHclTerraform(struct?: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOutputReference | AccessContextManagerServicePerimeterStatusEgressPoliciesEgressTo): any;
export declare class AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterStatusEgressPoliciesEgressTo | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressTo | undefined);
    private _externalResources?;
    get externalResources(): string[];
    set externalResources(value: string[]);
    resetExternalResources(): void;
    get externalResourcesInput(): string[] | undefined;
    private _resources?;
    get resources(): string[];
    set resources(value: string[]);
    resetResources(): void;
    get resourcesInput(): string[] | undefined;
    private _roles?;
    get roles(): string[];
    set roles(value: string[]);
    resetRoles(): void;
    get rolesInput(): string[] | undefined;
    private _operations;
    get operations(): AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperationsList;
    putOperations(value: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperations[] | cdktn.IResolvable): void;
    resetOperations(): void;
    get operationsInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOperations[] | undefined;
}
export interface AccessContextManagerServicePerimeterStatusEgressPolicies {
    /**
    * Human readable title. Must be unique within the perimeter. Does not affect behavior.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#title AccessContextManagerServicePerimeter#title}
    */
    readonly title?: string;
    /**
    * egress_from block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#egress_from AccessContextManagerServicePerimeter#egress_from}
    */
    readonly egressFrom?: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFrom;
    /**
    * egress_to block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#egress_to AccessContextManagerServicePerimeter#egress_to}
    */
    readonly egressTo?: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressTo;
}
export declare function accessContextManagerServicePerimeterStatusEgressPoliciesToTerraform(struct?: AccessContextManagerServicePerimeterStatusEgressPolicies | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterStatusEgressPoliciesToHclTerraform(struct?: AccessContextManagerServicePerimeterStatusEgressPolicies | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterStatusEgressPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterStatusEgressPolicies | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterStatusEgressPolicies | cdktn.IResolvable | undefined);
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _egressFrom;
    get egressFrom(): AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFromOutputReference;
    putEgressFrom(value: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFrom): void;
    resetEgressFrom(): void;
    get egressFromInput(): AccessContextManagerServicePerimeterStatusEgressPoliciesEgressFrom | undefined;
    private _egressTo;
    get egressTo(): AccessContextManagerServicePerimeterStatusEgressPoliciesEgressToOutputReference;
    putEgressTo(value: AccessContextManagerServicePerimeterStatusEgressPoliciesEgressTo): void;
    resetEgressTo(): void;
    get egressToInput(): AccessContextManagerServicePerimeterStatusEgressPoliciesEgressTo | undefined;
}
export declare class AccessContextManagerServicePerimeterStatusEgressPoliciesList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterStatusEgressPolicies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterStatusEgressPoliciesOutputReference;
}
export interface AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSourcesPscEndpoint {
    /**
    * The full resource name of the global forwarding rule that identifies a Private Service Connect endpoint.
    * Forwarding rule format: '//compute.googleapis.com/projects/{PROJECT_ID}/global/forwardingRules/{FORWARDING_RULE_ID}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#forwarding_rule AccessContextManagerServicePerimeter#forwarding_rule}
    */
    readonly forwardingRule?: string;
}
export declare function accessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSourcesPscEndpointToTerraform(struct?: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSourcesPscEndpointOutputReference | AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSourcesPscEndpoint): any;
export declare function accessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSourcesPscEndpointToHclTerraform(struct?: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSourcesPscEndpointOutputReference | AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSourcesPscEndpoint): any;
export declare class AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSourcesPscEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSourcesPscEndpoint | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSourcesPscEndpoint | undefined);
    private _forwardingRule?;
    get forwardingRule(): string;
    set forwardingRule(value: string);
    resetForwardingRule(): void;
    get forwardingRuleInput(): string | undefined;
}
export interface AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSources {
    /**
    * An 'AccessLevel' resource name that allow resources within the
    * 'ServicePerimeters' to be accessed from the internet. 'AccessLevels' listed
    * must be in the same policy as this 'ServicePerimeter'. Referencing a nonexistent
    * 'AccessLevel' will cause an error. If no 'AccessLevel' names are listed,
    * resources within the perimeter can only be accessed via Google Cloud calls
    * with request origins within the perimeter.
    * Example 'accessPolicies/MY_POLICY/accessLevels/MY_LEVEL.'
    * If * is specified, then all IngressSources will be allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#access_level AccessContextManagerServicePerimeter#access_level}
    */
    readonly accessLevel?: string;
    /**
    * A Google Cloud resource that is allowed to ingress the perimeter.
    * Requests from these resources will be allowed to access perimeter data.
    * Projects, folders, organizations, and VPC networks are allowed.
    * Project format: 'projects/{project_number}'
    * Folder format: 'folders/{folder_number}'
    * Organization format: 'organizations/{organization_number}'
    * VPC network format: '//compute.googleapis.com/projects/{PROJECT_ID}/global/networks/{NAME}'.
    * The resource may be in any Google Cloud organization, not just the
    * organization that the perimeter is defined in. '*' is not allowed, the case
    * of allowing all Google Cloud resources only is not supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#resource AccessContextManagerServicePerimeter#resource}
    */
    readonly resource?: string;
    /**
    * psc_endpoint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#psc_endpoint AccessContextManagerServicePerimeter#psc_endpoint}
    */
    readonly pscEndpoint?: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSourcesPscEndpoint;
}
export declare function accessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSourcesToTerraform(struct?: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSources | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSourcesToHclTerraform(struct?: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSources | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSources | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSources | cdktn.IResolvable | undefined);
    private _accessLevel?;
    get accessLevel(): string;
    set accessLevel(value: string);
    resetAccessLevel(): void;
    get accessLevelInput(): string | undefined;
    private _resource?;
    get resource(): string;
    set resource(value: string);
    resetResource(): void;
    get resourceInput(): string | undefined;
    private _pscEndpoint;
    get pscEndpoint(): AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSourcesPscEndpointOutputReference;
    putPscEndpoint(value: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSourcesPscEndpoint): void;
    resetPscEndpoint(): void;
    get pscEndpointInput(): AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSourcesPscEndpoint | undefined;
}
export declare class AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSourcesList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSourcesOutputReference;
}
export interface AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFrom {
    /**
    * Identities can be an individual user, service account, Google group,
    * or third-party identity. For third-party identity, only single identities
    * are supported and other identity types are not supported.The v1 identities
    * that have the prefix user, group and serviceAccount in
    * https://cloud.google.com/iam/docs/principal-identifiers#v1 are supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#identities AccessContextManagerServicePerimeter#identities}
    */
    readonly identities?: string[];
    /**
    * Specifies the type of identities that are allowed access from outside the
    * perimeter. If left unspecified, then members of 'identities' field will be
    * allowed access. Possible values: ["IDENTITY_TYPE_UNSPECIFIED", "ANY_IDENTITY", "ANY_USER_ACCOUNT", "ANY_SERVICE_ACCOUNT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#identity_type AccessContextManagerServicePerimeter#identity_type}
    */
    readonly identityType?: string;
    /**
    * sources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#sources AccessContextManagerServicePerimeter#sources}
    */
    readonly sources?: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSources[] | cdktn.IResolvable;
}
export declare function accessContextManagerServicePerimeterStatusIngressPoliciesIngressFromToTerraform(struct?: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromOutputReference | AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFrom): any;
export declare function accessContextManagerServicePerimeterStatusIngressPoliciesIngressFromToHclTerraform(struct?: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromOutputReference | AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFrom): any;
export declare class AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFrom | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFrom | undefined);
    private _identities?;
    get identities(): string[];
    set identities(value: string[]);
    resetIdentities(): void;
    get identitiesInput(): string[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
    private _sources;
    get sources(): AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSourcesList;
    putSources(value: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSources[] | cdktn.IResolvable): void;
    resetSources(): void;
    get sourcesInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromSources[] | undefined;
}
export interface AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperationsMethodSelectors {
    /**
    * Value for method should be a valid method name for the corresponding
    * serviceName in 'ApiOperation'. If '*' used as value for 'method', then
    * ALL methods and permissions are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#method AccessContextManagerServicePerimeter#method}
    */
    readonly method?: string;
    /**
    * Value for permission should be a valid Cloud IAM permission for the
    * corresponding 'serviceName' in 'ApiOperation'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#permission AccessContextManagerServicePerimeter#permission}
    */
    readonly permission?: string;
}
export declare function accessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperationsMethodSelectorsToTerraform(struct?: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperationsMethodSelectors | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperationsMethodSelectorsToHclTerraform(struct?: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperationsMethodSelectors | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperationsMethodSelectorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperationsMethodSelectors | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperationsMethodSelectors | cdktn.IResolvable | undefined);
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    resetPermission(): void;
    get permissionInput(): string | undefined;
}
export declare class AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperationsMethodSelectorsList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperationsMethodSelectors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperationsMethodSelectorsOutputReference;
}
export interface AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperations {
    /**
    * The name of the API whose methods or permissions the 'IngressPolicy' or
    * 'EgressPolicy' want to allow. A single 'ApiOperation' with 'serviceName'
    * field set to '*' will allow all methods AND permissions for all services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#service_name AccessContextManagerServicePerimeter#service_name}
    */
    readonly serviceName?: string;
    /**
    * method_selectors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#method_selectors AccessContextManagerServicePerimeter#method_selectors}
    */
    readonly methodSelectors?: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperationsMethodSelectors[] | cdktn.IResolvable;
}
export declare function accessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperationsToTerraform(struct?: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperations | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperationsToHclTerraform(struct?: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperations | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperations | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperations | cdktn.IResolvable | undefined);
    private _serviceName?;
    get serviceName(): string;
    set serviceName(value: string);
    resetServiceName(): void;
    get serviceNameInput(): string | undefined;
    private _methodSelectors;
    get methodSelectors(): AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperationsMethodSelectorsList;
    putMethodSelectors(value: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperationsMethodSelectors[] | cdktn.IResolvable): void;
    resetMethodSelectors(): void;
    get methodSelectorsInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperationsMethodSelectors[] | undefined;
}
export declare class AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperationsList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperationsOutputReference;
}
export interface AccessContextManagerServicePerimeterStatusIngressPoliciesIngressTo {
    /**
    * A list of resources protected by this 'ServicePerimeter', in the form
    * 'projects/{project_number}', 'folders/{folder_number}', or
    * 'organizations/{organization_number}',
    * that are allowed to be accessed by sources defined in the
    * corresponding 'IngressFrom'. A request matches if it contains
    * a resource in this list. If '*' is specified for resources,
    * then this 'IngressTo' rule will authorize access to all
    * resources inside the perimeter, provided that the request
    * also matches the 'operations' field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#resources AccessContextManagerServicePerimeter#resources}
    */
    readonly resources?: string[];
    /**
    * A list of IAM roles that represent the set of operations that the sources
    * specified in the corresponding 'IngressFrom'
    * are allowed to perform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#roles AccessContextManagerServicePerimeter#roles}
    */
    readonly roles?: string[];
    /**
    * operations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#operations AccessContextManagerServicePerimeter#operations}
    */
    readonly operations?: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperations[] | cdktn.IResolvable;
}
export declare function accessContextManagerServicePerimeterStatusIngressPoliciesIngressToToTerraform(struct?: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOutputReference | AccessContextManagerServicePerimeterStatusIngressPoliciesIngressTo): any;
export declare function accessContextManagerServicePerimeterStatusIngressPoliciesIngressToToHclTerraform(struct?: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOutputReference | AccessContextManagerServicePerimeterStatusIngressPoliciesIngressTo): any;
export declare class AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterStatusIngressPoliciesIngressTo | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressTo | undefined);
    private _resources?;
    get resources(): string[];
    set resources(value: string[]);
    resetResources(): void;
    get resourcesInput(): string[] | undefined;
    private _roles?;
    get roles(): string[];
    set roles(value: string[]);
    resetRoles(): void;
    get rolesInput(): string[] | undefined;
    private _operations;
    get operations(): AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperationsList;
    putOperations(value: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperations[] | cdktn.IResolvable): void;
    resetOperations(): void;
    get operationsInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOperations[] | undefined;
}
export interface AccessContextManagerServicePerimeterStatusIngressPolicies {
    /**
    * Human readable title. Must be unique within the perimeter. Does not affect behavior.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#title AccessContextManagerServicePerimeter#title}
    */
    readonly title?: string;
    /**
    * ingress_from block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#ingress_from AccessContextManagerServicePerimeter#ingress_from}
    */
    readonly ingressFrom?: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFrom;
    /**
    * ingress_to block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#ingress_to AccessContextManagerServicePerimeter#ingress_to}
    */
    readonly ingressTo?: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressTo;
}
export declare function accessContextManagerServicePerimeterStatusIngressPoliciesToTerraform(struct?: AccessContextManagerServicePerimeterStatusIngressPolicies | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterStatusIngressPoliciesToHclTerraform(struct?: AccessContextManagerServicePerimeterStatusIngressPolicies | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterStatusIngressPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterStatusIngressPolicies | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterStatusIngressPolicies | cdktn.IResolvable | undefined);
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _ingressFrom;
    get ingressFrom(): AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFromOutputReference;
    putIngressFrom(value: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFrom): void;
    resetIngressFrom(): void;
    get ingressFromInput(): AccessContextManagerServicePerimeterStatusIngressPoliciesIngressFrom | undefined;
    private _ingressTo;
    get ingressTo(): AccessContextManagerServicePerimeterStatusIngressPoliciesIngressToOutputReference;
    putIngressTo(value: AccessContextManagerServicePerimeterStatusIngressPoliciesIngressTo): void;
    resetIngressTo(): void;
    get ingressToInput(): AccessContextManagerServicePerimeterStatusIngressPoliciesIngressTo | undefined;
}
export declare class AccessContextManagerServicePerimeterStatusIngressPoliciesList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterStatusIngressPolicies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterStatusIngressPoliciesOutputReference;
}
export interface AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeader {
    /**
    * HTTP header key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#key AccessContextManagerServicePerimeter#key}
    */
    readonly key: string;
    /**
    * HTTP header value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#value AccessContextManagerServicePerimeter#value}
    */
    readonly value: string;
}
export declare function accessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeaderToTerraform(struct?: AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeaderOutputReference | AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeader): any;
export declare function accessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeaderToHclTerraform(struct?: AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeaderOutputReference | AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeader): any;
export declare class AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeader | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeader | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export interface AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiers {
    /**
    * add_request_header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#add_request_header AccessContextManagerServicePerimeter#add_request_header}
    */
    readonly addRequestHeader?: AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeader;
}
export declare function accessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiersToTerraform(struct?: AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiers | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiersToHclTerraform(struct?: AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiers | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiers | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiers | cdktn.IResolvable | undefined);
    private _addRequestHeader;
    get addRequestHeader(): AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeaderOutputReference;
    putAddRequestHeader(value: AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeader): void;
    resetAddRequestHeader(): void;
    get addRequestHeaderInput(): AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiersAddRequestHeader | undefined;
}
export declare class AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiersList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiersOutputReference;
}
export interface AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatterns {
    /**
    * URL pattern to allow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#pattern AccessContextManagerServicePerimeter#pattern}
    */
    readonly pattern?: string;
    /**
    * Supported service to allow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#service AccessContextManagerServicePerimeter#service}
    */
    readonly service?: string;
    /**
    * modifiers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#modifiers AccessContextManagerServicePerimeter#modifiers}
    */
    readonly modifiers?: AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiers[] | cdktn.IResolvable;
}
export declare function accessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsToTerraform(struct?: AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatterns | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsToHclTerraform(struct?: AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatterns | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatterns | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatterns | cdktn.IResolvable | undefined);
    private _pattern?;
    get pattern(): string;
    set pattern(value: string);
    resetPattern(): void;
    get patternInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
    private _modifiers;
    get modifiers(): AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiersList;
    putModifiers(value: AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiers[] | cdktn.IResolvable): void;
    resetModifiers(): void;
    get modifiersInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsModifiers[] | undefined;
}
export declare class AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatterns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsOutputReference;
}
export interface AccessContextManagerServicePerimeterStatusVpcAccessibleServices {
    /**
    * The list of APIs usable within the Service Perimeter.
    * Must be empty unless 'enableRestriction' is True.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#allowed_services AccessContextManagerServicePerimeter#allowed_services}
    */
    readonly allowedServices?: string[];
    /**
    * Whether to restrict API calls within the Service Perimeter to the
    * list of APIs specified in 'allowedServices'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#enable_restriction AccessContextManagerServicePerimeter#enable_restriction}
    */
    readonly enableRestriction?: boolean | cdktn.IResolvable;
    /**
    * Defines the enforcement scopes of service patterns. Possible values: ["GOOGLE_APIS_VIA_PRIVATE_PATH"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#service_patterns_enforcement_scopes AccessContextManagerServicePerimeter#service_patterns_enforcement_scopes}
    */
    readonly servicePatternsEnforcementScopes?: string[];
    /**
    * allowed_service_patterns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#allowed_service_patterns AccessContextManagerServicePerimeter#allowed_service_patterns}
    */
    readonly allowedServicePatterns?: AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatterns[] | cdktn.IResolvable;
}
export declare function accessContextManagerServicePerimeterStatusVpcAccessibleServicesToTerraform(struct?: AccessContextManagerServicePerimeterStatusVpcAccessibleServicesOutputReference | AccessContextManagerServicePerimeterStatusVpcAccessibleServices): any;
export declare function accessContextManagerServicePerimeterStatusVpcAccessibleServicesToHclTerraform(struct?: AccessContextManagerServicePerimeterStatusVpcAccessibleServicesOutputReference | AccessContextManagerServicePerimeterStatusVpcAccessibleServices): any;
export declare class AccessContextManagerServicePerimeterStatusVpcAccessibleServicesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterStatusVpcAccessibleServices | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterStatusVpcAccessibleServices | undefined);
    private _allowedServices?;
    get allowedServices(): string[];
    set allowedServices(value: string[]);
    resetAllowedServices(): void;
    get allowedServicesInput(): string[] | undefined;
    private _enableRestriction?;
    get enableRestriction(): boolean | cdktn.IResolvable;
    set enableRestriction(value: boolean | cdktn.IResolvable);
    resetEnableRestriction(): void;
    get enableRestrictionInput(): boolean | cdktn.IResolvable | undefined;
    private _servicePatternsEnforcementScopes?;
    get servicePatternsEnforcementScopes(): string[];
    set servicePatternsEnforcementScopes(value: string[]);
    resetServicePatternsEnforcementScopes(): void;
    get servicePatternsEnforcementScopesInput(): string[] | undefined;
    private _allowedServicePatterns;
    get allowedServicePatterns(): AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatternsList;
    putAllowedServicePatterns(value: AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatterns[] | cdktn.IResolvable): void;
    resetAllowedServicePatterns(): void;
    get allowedServicePatternsInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterStatusVpcAccessibleServicesAllowedServicePatterns[] | undefined;
}
export interface AccessContextManagerServicePerimeterStatus {
    /**
    * A list of AccessLevel resource names that allow resources within
    * the ServicePerimeter to be accessed from the internet.
    * AccessLevels listed must be in the same policy as this
    * ServicePerimeter. Referencing a nonexistent AccessLevel is a
    * syntax error. If no AccessLevel names are listed, resources within
    * the perimeter can only be accessed via GCP calls with request
    * origins within the perimeter. For Service Perimeter Bridge, must
    * be empty.
    *
    * Format: accessPolicies/{policy_id}/accessLevels/{access_level_name}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#access_levels AccessContextManagerServicePerimeter#access_levels}
    */
    readonly accessLevels?: string[];
    /**
    * A list of GCP resources that are inside of the service perimeter.
    * Projects, folders, and VPC networks are allowed.
    * Project format: 'projects/{project_number}'
    * Folder format: 'folders/{folder_number}'
    * VPC network format: '//compute.googleapis.com/projects/{PROJECT_ID}/global/networks/{NAME}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#resources AccessContextManagerServicePerimeter#resources}
    */
    readonly resources?: string[];
    /**
    * GCP services that are subject to the Service Perimeter
    * restrictions. Must contain a list of services. For example, if
    * 'storage.googleapis.com' is specified, access to the storage
    * buckets inside the perimeter must meet the perimeter's access
    * restrictions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#restricted_services AccessContextManagerServicePerimeter#restricted_services}
    */
    readonly restrictedServices?: string[];
    /**
    * egress_policies block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#egress_policies AccessContextManagerServicePerimeter#egress_policies}
    */
    readonly egressPolicies?: AccessContextManagerServicePerimeterStatusEgressPolicies[] | cdktn.IResolvable;
    /**
    * ingress_policies block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#ingress_policies AccessContextManagerServicePerimeter#ingress_policies}
    */
    readonly ingressPolicies?: AccessContextManagerServicePerimeterStatusIngressPolicies[] | cdktn.IResolvable;
    /**
    * vpc_accessible_services block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#vpc_accessible_services AccessContextManagerServicePerimeter#vpc_accessible_services}
    */
    readonly vpcAccessibleServices?: AccessContextManagerServicePerimeterStatusVpcAccessibleServices;
}
export declare function accessContextManagerServicePerimeterStatusToTerraform(struct?: AccessContextManagerServicePerimeterStatusOutputReference | AccessContextManagerServicePerimeterStatus): any;
export declare function accessContextManagerServicePerimeterStatusToHclTerraform(struct?: AccessContextManagerServicePerimeterStatusOutputReference | AccessContextManagerServicePerimeterStatus): any;
export declare class AccessContextManagerServicePerimeterStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterStatus | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterStatus | undefined);
    private _accessLevels?;
    get accessLevels(): string[];
    set accessLevels(value: string[]);
    resetAccessLevels(): void;
    get accessLevelsInput(): string[] | undefined;
    private _resources?;
    get resources(): string[];
    set resources(value: string[]);
    resetResources(): void;
    get resourcesInput(): string[] | undefined;
    private _restrictedServices?;
    get restrictedServices(): string[];
    set restrictedServices(value: string[]);
    resetRestrictedServices(): void;
    get restrictedServicesInput(): string[] | undefined;
    private _egressPolicies;
    get egressPolicies(): AccessContextManagerServicePerimeterStatusEgressPoliciesList;
    putEgressPolicies(value: AccessContextManagerServicePerimeterStatusEgressPolicies[] | cdktn.IResolvable): void;
    resetEgressPolicies(): void;
    get egressPoliciesInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterStatusEgressPolicies[] | undefined;
    private _ingressPolicies;
    get ingressPolicies(): AccessContextManagerServicePerimeterStatusIngressPoliciesList;
    putIngressPolicies(value: AccessContextManagerServicePerimeterStatusIngressPolicies[] | cdktn.IResolvable): void;
    resetIngressPolicies(): void;
    get ingressPoliciesInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterStatusIngressPolicies[] | undefined;
    private _vpcAccessibleServices;
    get vpcAccessibleServices(): AccessContextManagerServicePerimeterStatusVpcAccessibleServicesOutputReference;
    putVpcAccessibleServices(value: AccessContextManagerServicePerimeterStatusVpcAccessibleServices): void;
    resetVpcAccessibleServices(): void;
    get vpcAccessibleServicesInput(): AccessContextManagerServicePerimeterStatusVpcAccessibleServices | undefined;
}
export interface AccessContextManagerServicePerimeterTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#create AccessContextManagerServicePerimeter#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#delete AccessContextManagerServicePerimeter#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#update AccessContextManagerServicePerimeter#update}
    */
    readonly update?: string;
}
export declare function accessContextManagerServicePerimeterTimeoutsToTerraform(struct?: AccessContextManagerServicePerimeterTimeouts | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterTimeoutsToHclTerraform(struct?: AccessContextManagerServicePerimeterTimeouts | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter google_access_context_manager_service_perimeter}
*/
export declare class AccessContextManagerServicePerimeter extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_access_context_manager_service_perimeter";
    /**
    * Generates CDKTN code for importing a AccessContextManagerServicePerimeter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessContextManagerServicePerimeter to import
    * @param importFromId The id of the existing AccessContextManagerServicePerimeter that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessContextManagerServicePerimeter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter google_access_context_manager_service_perimeter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessContextManagerServicePerimeterConfig
    */
    constructor(scope: Construct, id: string, config: AccessContextManagerServicePerimeterConfig);
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _perimeterType?;
    get perimeterType(): string;
    set perimeterType(value: string);
    resetPerimeterType(): void;
    get perimeterTypeInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    get updateTime(): string;
    private _useExplicitDryRunSpec?;
    get useExplicitDryRunSpec(): boolean | cdktn.IResolvable;
    set useExplicitDryRunSpec(value: boolean | cdktn.IResolvable);
    resetUseExplicitDryRunSpec(): void;
    get useExplicitDryRunSpecInput(): boolean | cdktn.IResolvable | undefined;
    private _spec;
    get spec(): AccessContextManagerServicePerimeterSpecOutputReference;
    putSpec(value: AccessContextManagerServicePerimeterSpec): void;
    resetSpec(): void;
    get specInput(): AccessContextManagerServicePerimeterSpec | undefined;
    private _status;
    get status(): AccessContextManagerServicePerimeterStatusOutputReference;
    putStatus(value: AccessContextManagerServicePerimeterStatus): void;
    resetStatus(): void;
    get statusInput(): AccessContextManagerServicePerimeterStatus | undefined;
    private _timeouts;
    get timeouts(): AccessContextManagerServicePerimeterTimeoutsOutputReference;
    putTimeouts(value: AccessContextManagerServicePerimeterTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
