/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppEngineApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The domain to authenticate users with when using App Engine's User API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/app_engine_application#auth_domain AppEngineApplication#auth_domain}
    */
    readonly authDomain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/app_engine_application#database_type AppEngineApplication#database_type}
    */
    readonly databaseType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/app_engine_application#id AppEngineApplication#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location to serve the app from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/app_engine_application#location_id AppEngineApplication#location_id}
    */
    readonly locationId: string;
    /**
    * The project ID to create the application under.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/app_engine_application#project AppEngineApplication#project}
    */
    readonly project?: string;
    /**
    * The serving status of the app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/app_engine_application#serving_status AppEngineApplication#serving_status}
    */
    readonly servingStatus?: string;
    /**
    * The SSL policy that will be applied to the application. If set to Modern it will restrict traffic with TLS \u003c 1.2 and allow only Modern Ciphers suite
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/app_engine_application#ssl_policy AppEngineApplication#ssl_policy}
    */
    readonly sslPolicy?: string;
    /**
    * feature_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/app_engine_application#feature_settings AppEngineApplication#feature_settings}
    */
    readonly featureSettings?: AppEngineApplicationFeatureSettings;
    /**
    * iap block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/app_engine_application#iap AppEngineApplication#iap}
    */
    readonly iap?: AppEngineApplicationIap;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/app_engine_application#timeouts AppEngineApplication#timeouts}
    */
    readonly timeouts?: AppEngineApplicationTimeouts;
}
export interface AppEngineApplicationUrlDispatchRule {
}
export declare function appEngineApplicationUrlDispatchRuleToTerraform(struct?: AppEngineApplicationUrlDispatchRule): any;
export declare function appEngineApplicationUrlDispatchRuleToHclTerraform(struct?: AppEngineApplicationUrlDispatchRule): any;
export declare class AppEngineApplicationUrlDispatchRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppEngineApplicationUrlDispatchRule | undefined;
    set internalValue(value: AppEngineApplicationUrlDispatchRule | undefined);
    get domain(): string;
    get path(): string;
    get service(): string;
}
export declare class AppEngineApplicationUrlDispatchRuleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppEngineApplicationUrlDispatchRuleOutputReference;
}
export interface AppEngineApplicationFeatureSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/app_engine_application#split_health_checks AppEngineApplication#split_health_checks}
    */
    readonly splitHealthChecks: boolean | cdktn.IResolvable;
}
export declare function appEngineApplicationFeatureSettingsToTerraform(struct?: AppEngineApplicationFeatureSettingsOutputReference | AppEngineApplicationFeatureSettings): any;
export declare function appEngineApplicationFeatureSettingsToHclTerraform(struct?: AppEngineApplicationFeatureSettingsOutputReference | AppEngineApplicationFeatureSettings): any;
export declare class AppEngineApplicationFeatureSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppEngineApplicationFeatureSettings | undefined;
    set internalValue(value: AppEngineApplicationFeatureSettings | undefined);
    private _splitHealthChecks?;
    get splitHealthChecks(): boolean | cdktn.IResolvable;
    set splitHealthChecks(value: boolean | cdktn.IResolvable);
    get splitHealthChecksInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AppEngineApplicationIap {
    /**
    * Adapted for use with the app
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/app_engine_application#enabled AppEngineApplication#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * OAuth2 client ID to use for the authentication flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/app_engine_application#oauth2_client_id AppEngineApplication#oauth2_client_id}
    */
    readonly oauth2ClientId: string;
    /**
    * OAuth2 client secret to use for the authentication flow. The SHA-256 hash of the value is returned in the oauth2ClientSecretSha256 field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/app_engine_application#oauth2_client_secret AppEngineApplication#oauth2_client_secret}
    */
    readonly oauth2ClientSecret?: string;
    /**
    * OAuth2 client secret to use for the authentication flow. The SHA-256 hash of the value is returned in the oauth2ClientSecretSha256 field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/app_engine_application#oauth2_client_secret_wo AppEngineApplication#oauth2_client_secret_wo}
    */
    readonly oauth2ClientSecretWo?: string;
    /**
    * Triggers update of `oauth2_client_secret_wo` write-only. Increment this value when an update to `oauth2_client_secret_wo` is needed. For more info see [updating write-only arguments](/docs/providers/google/guides/using_write_only_arguments.html#updating-write-only-arguments)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/app_engine_application#oauth2_client_secret_wo_version AppEngineApplication#oauth2_client_secret_wo_version}
    */
    readonly oauth2ClientSecretWoVersion?: string;
}
export declare function appEngineApplicationIapToTerraform(struct?: AppEngineApplicationIapOutputReference | AppEngineApplicationIap): any;
export declare function appEngineApplicationIapToHclTerraform(struct?: AppEngineApplicationIapOutputReference | AppEngineApplicationIap): any;
export declare class AppEngineApplicationIapOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppEngineApplicationIap | undefined;
    set internalValue(value: AppEngineApplicationIap | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _oauth2ClientId?;
    get oauth2ClientId(): string;
    set oauth2ClientId(value: string);
    get oauth2ClientIdInput(): string | undefined;
    private _oauth2ClientSecret?;
    get oauth2ClientSecret(): string;
    set oauth2ClientSecret(value: string);
    resetOauth2ClientSecret(): void;
    get oauth2ClientSecretInput(): string | undefined;
    get oauth2ClientSecretSha256(): string;
    private _oauth2ClientSecretWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get oauth2ClientSecretWo(): string;
    set oauth2ClientSecretWo(value: string);
    resetOauth2ClientSecretWo(): void;
    get oauth2ClientSecretWoInput(): string | undefined;
    private _oauth2ClientSecretWoVersion?;
    get oauth2ClientSecretWoVersion(): string;
    set oauth2ClientSecretWoVersion(value: string);
    resetOauth2ClientSecretWoVersion(): void;
    get oauth2ClientSecretWoVersionInput(): string | undefined;
}
export interface AppEngineApplicationTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/app_engine_application#create AppEngineApplication#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/app_engine_application#update AppEngineApplication#update}
    */
    readonly update?: string;
}
export declare function appEngineApplicationTimeoutsToTerraform(struct?: AppEngineApplicationTimeouts | cdktn.IResolvable): any;
export declare function appEngineApplicationTimeoutsToHclTerraform(struct?: AppEngineApplicationTimeouts | cdktn.IResolvable): any;
export declare class AppEngineApplicationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppEngineApplicationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AppEngineApplicationTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/app_engine_application google_app_engine_application}
*/
export declare class AppEngineApplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_app_engine_application";
    /**
    * Generates CDKTN code for importing a AppEngineApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppEngineApplication to import
    * @param importFromId The id of the existing AppEngineApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/app_engine_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppEngineApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/app_engine_application google_app_engine_application} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppEngineApplicationConfig
    */
    constructor(scope: Construct, id: string, config: AppEngineApplicationConfig);
    get appId(): string;
    private _authDomain?;
    get authDomain(): string;
    set authDomain(value: string);
    resetAuthDomain(): void;
    get authDomainInput(): string | undefined;
    get codeBucket(): string;
    private _databaseType?;
    get databaseType(): string;
    set databaseType(value: string);
    resetDatabaseType(): void;
    get databaseTypeInput(): string | undefined;
    get defaultBucket(): string;
    get defaultHostname(): string;
    get gcrDomain(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _locationId?;
    get locationId(): string;
    set locationId(value: string);
    get locationIdInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _servingStatus?;
    get servingStatus(): string;
    set servingStatus(value: string);
    resetServingStatus(): void;
    get servingStatusInput(): string | undefined;
    private _sslPolicy?;
    get sslPolicy(): string;
    set sslPolicy(value: string);
    resetSslPolicy(): void;
    get sslPolicyInput(): string | undefined;
    private _urlDispatchRule;
    get urlDispatchRule(): AppEngineApplicationUrlDispatchRuleList;
    private _featureSettings;
    get featureSettings(): AppEngineApplicationFeatureSettingsOutputReference;
    putFeatureSettings(value: AppEngineApplicationFeatureSettings): void;
    resetFeatureSettings(): void;
    get featureSettingsInput(): AppEngineApplicationFeatureSettings | undefined;
    private _iap;
    get iap(): AppEngineApplicationIapOutputReference;
    putIap(value: AppEngineApplicationIap): void;
    resetIap(): void;
    get iapInput(): AppEngineApplicationIap | undefined;
    private _timeouts;
    get timeouts(): AppEngineApplicationTimeoutsOutputReference;
    putTimeouts(value: AppEngineApplicationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AppEngineApplicationTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
