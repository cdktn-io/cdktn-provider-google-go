/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CesDeploymentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#app CesDeployment#app}
    */
    readonly app: string;
    /**
    * The resource name of the app version to deploy.
    * Format:
    * projects/{project}/locations/{location}/apps/{app}/versions/{version}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#app_version CesDeployment#app_version}
    */
    readonly appVersion: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#deletion_policy CesDeployment#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Display name of the deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#display_name CesDeployment#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#id CesDeployment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#location CesDeployment#location}
    */
    readonly location: string;
    /**
    * The modality of the deployment. Possible values: ["MODALITY_TEXT", "MODALITY_VOICE", "MODALITY_VIDEO"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#modality CesDeployment#modality}
    */
    readonly modality?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#project CesDeployment#project}
    */
    readonly project?: string;
    /**
    * channel_profile block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#channel_profile CesDeployment#channel_profile}
    */
    readonly channelProfile: CesDeploymentChannelProfile;
    /**
    * instagram_credentials block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#instagram_credentials CesDeployment#instagram_credentials}
    */
    readonly instagramCredentials?: CesDeploymentInstagramCredentials;
    /**
    * model_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#model_settings CesDeployment#model_settings}
    */
    readonly modelSettings?: CesDeploymentModelSettings;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#timeouts CesDeployment#timeouts}
    */
    readonly timeouts?: CesDeploymentTimeouts;
    /**
    * whatsapp_credentials block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#whatsapp_credentials CesDeployment#whatsapp_credentials}
    */
    readonly whatsappCredentials?: CesDeploymentWhatsappCredentials;
}
export interface CesDeploymentChannelProfilePersonaProperty {
    /**
    * The persona of the channel.
    * Possible values:
    * UNKNOWN
    * CONCISE
    * CHATTY
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#persona CesDeployment#persona}
    */
    readonly persona?: string;
}
export declare function cesDeploymentChannelProfilePersonaPropertyToTerraform(struct?: CesDeploymentChannelProfilePersonaPropertyOutputReference | CesDeploymentChannelProfilePersonaProperty): any;
export declare function cesDeploymentChannelProfilePersonaPropertyToHclTerraform(struct?: CesDeploymentChannelProfilePersonaPropertyOutputReference | CesDeploymentChannelProfilePersonaProperty): any;
export declare class CesDeploymentChannelProfilePersonaPropertyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesDeploymentChannelProfilePersonaProperty | undefined;
    set internalValue(value: CesDeploymentChannelProfilePersonaProperty | undefined);
    private _persona?;
    get persona(): string;
    set persona(value: string);
    resetPersona(): void;
    get personaInput(): string | undefined;
}
export interface CesDeploymentChannelProfileWebWidgetConfigSecuritySettings {
    /**
    * The origins that are allowed to host the web widget. An origin is defined by RFC 6454. If empty, all origins are allowed. A maximum of 100 origins is allowed. Example: "https://example.com"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#allowed_origins CesDeployment#allowed_origins}
    */
    readonly allowedOrigins?: string[];
    /**
    * Indicates whether origin check for the web widget is enabled. If true, the web widget will check the origin of the website that loads the web widget and only allow it to be loaded in the same origin or any of the allowed origins.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#enable_origin_check CesDeployment#enable_origin_check}
    */
    readonly enableOriginCheck?: boolean | cdktn.IResolvable;
    /**
    * Indicates whether public access to the web widget is enabled. If true, the web widget will be publicly accessible. If false, the web widget must be integrated with your own authentication and authorization system to return valid credentials for accessing the CES agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#enable_public_access CesDeployment#enable_public_access}
    */
    readonly enablePublicAccess?: boolean | cdktn.IResolvable;
    /**
    * Indicates whether reCAPTCHA verification for the web widget is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#enable_recaptcha CesDeployment#enable_recaptcha}
    */
    readonly enableRecaptcha?: boolean | cdktn.IResolvable;
}
export declare function cesDeploymentChannelProfileWebWidgetConfigSecuritySettingsToTerraform(struct?: CesDeploymentChannelProfileWebWidgetConfigSecuritySettingsOutputReference | CesDeploymentChannelProfileWebWidgetConfigSecuritySettings): any;
export declare function cesDeploymentChannelProfileWebWidgetConfigSecuritySettingsToHclTerraform(struct?: CesDeploymentChannelProfileWebWidgetConfigSecuritySettingsOutputReference | CesDeploymentChannelProfileWebWidgetConfigSecuritySettings): any;
export declare class CesDeploymentChannelProfileWebWidgetConfigSecuritySettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesDeploymentChannelProfileWebWidgetConfigSecuritySettings | undefined;
    set internalValue(value: CesDeploymentChannelProfileWebWidgetConfigSecuritySettings | undefined);
    private _allowedOrigins?;
    get allowedOrigins(): string[];
    set allowedOrigins(value: string[]);
    resetAllowedOrigins(): void;
    get allowedOriginsInput(): string[] | undefined;
    private _enableOriginCheck?;
    get enableOriginCheck(): boolean | cdktn.IResolvable;
    set enableOriginCheck(value: boolean | cdktn.IResolvable);
    resetEnableOriginCheck(): void;
    get enableOriginCheckInput(): boolean | cdktn.IResolvable | undefined;
    private _enablePublicAccess?;
    get enablePublicAccess(): boolean | cdktn.IResolvable;
    set enablePublicAccess(value: boolean | cdktn.IResolvable);
    resetEnablePublicAccess(): void;
    get enablePublicAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _enableRecaptcha?;
    get enableRecaptcha(): boolean | cdktn.IResolvable;
    set enableRecaptcha(value: boolean | cdktn.IResolvable);
    resetEnableRecaptcha(): void;
    get enableRecaptchaInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CesDeploymentChannelProfileWebWidgetConfig {
    /**
    * The modality of the web widget.
    * Possible values:
    * MODALITY_UNSPECIFIED
    * CHAT_AND_VOICE
    * VOICE_ONLY
    * CHAT_ONLY
    * CHAT_VOICE_AND_VIDEO
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#modality CesDeployment#modality}
    */
    readonly modality?: string;
    /**
    * The theme of the web widget.
    * Possible values:
    * THEME_UNSPECIFIED
    * LIGHT
    * DARK
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#theme CesDeployment#theme}
    */
    readonly theme?: string;
    /**
    * The title of the web widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#web_widget_title CesDeployment#web_widget_title}
    */
    readonly webWidgetTitle?: string;
    /**
    * security_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#security_settings CesDeployment#security_settings}
    */
    readonly securitySettings?: CesDeploymentChannelProfileWebWidgetConfigSecuritySettings;
}
export declare function cesDeploymentChannelProfileWebWidgetConfigToTerraform(struct?: CesDeploymentChannelProfileWebWidgetConfigOutputReference | CesDeploymentChannelProfileWebWidgetConfig): any;
export declare function cesDeploymentChannelProfileWebWidgetConfigToHclTerraform(struct?: CesDeploymentChannelProfileWebWidgetConfigOutputReference | CesDeploymentChannelProfileWebWidgetConfig): any;
export declare class CesDeploymentChannelProfileWebWidgetConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesDeploymentChannelProfileWebWidgetConfig | undefined;
    set internalValue(value: CesDeploymentChannelProfileWebWidgetConfig | undefined);
    private _modality?;
    get modality(): string;
    set modality(value: string);
    resetModality(): void;
    get modalityInput(): string | undefined;
    private _theme?;
    get theme(): string;
    set theme(value: string);
    resetTheme(): void;
    get themeInput(): string | undefined;
    private _webWidgetTitle?;
    get webWidgetTitle(): string;
    set webWidgetTitle(value: string);
    resetWebWidgetTitle(): void;
    get webWidgetTitleInput(): string | undefined;
    private _securitySettings;
    get securitySettings(): CesDeploymentChannelProfileWebWidgetConfigSecuritySettingsOutputReference;
    putSecuritySettings(value: CesDeploymentChannelProfileWebWidgetConfigSecuritySettings): void;
    resetSecuritySettings(): void;
    get securitySettingsInput(): CesDeploymentChannelProfileWebWidgetConfigSecuritySettings | undefined;
}
export interface CesDeploymentChannelProfileWhatsappConfig {
    /**
    * Optional. The phone number in E.164 format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#phone_number CesDeployment#phone_number}
    */
    readonly phoneNumber?: string;
    /**
    * Required. The Meta phone number ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#phone_number_id CesDeployment#phone_number_id}
    */
    readonly phoneNumberId: string;
    /**
    * Required. The WhatsApp Business Account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#waba_id CesDeployment#waba_id}
    */
    readonly wabaId: string;
}
export declare function cesDeploymentChannelProfileWhatsappConfigToTerraform(struct?: CesDeploymentChannelProfileWhatsappConfigOutputReference | CesDeploymentChannelProfileWhatsappConfig): any;
export declare function cesDeploymentChannelProfileWhatsappConfigToHclTerraform(struct?: CesDeploymentChannelProfileWhatsappConfigOutputReference | CesDeploymentChannelProfileWhatsappConfig): any;
export declare class CesDeploymentChannelProfileWhatsappConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesDeploymentChannelProfileWhatsappConfig | undefined;
    set internalValue(value: CesDeploymentChannelProfileWhatsappConfig | undefined);
    get description(): string;
    get displayName(): string;
    private _phoneNumber?;
    get phoneNumber(): string;
    set phoneNumber(value: string);
    resetPhoneNumber(): void;
    get phoneNumberInput(): string | undefined;
    private _phoneNumberId?;
    get phoneNumberId(): string;
    set phoneNumberId(value: string);
    get phoneNumberIdInput(): string | undefined;
    get thumbnailUrl(): string;
    private _wabaId?;
    get wabaId(): string;
    set wabaId(value: string);
    get wabaIdInput(): string | undefined;
}
export interface CesDeploymentChannelProfile {
    /**
    * The type of the channel profile.
    * Possible values:
    * UNKNOWN
    * WEB_UI
    * API
    * TWILIO
    * GOOGLE_TELEPHONY_PLATFORM
    * CONTACT_CENTER_AS_A_SERVICE
    * FIVE9
    * CONTACT_CENTER_INTEGRATION
    * WHATSAPP
    * INSTAGRAM
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#channel_type CesDeployment#channel_type}
    */
    readonly channelType?: string;
    /**
    * Whether to disable user barge-in control in the conversation.
    * - **true**: User interruptions are disabled while the agent is speaking.
    * - **false**: The agent retains automatic control over when the user can
    * interrupt.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#disable_barge_in_control CesDeployment#disable_barge_in_control}
    */
    readonly disableBargeInControl?: boolean | cdktn.IResolvable;
    /**
    * Whether to disable DTMF (dual-tone multi-frequency).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#disable_dtmf CesDeployment#disable_dtmf}
    */
    readonly disableDtmf?: boolean | cdktn.IResolvable;
    /**
    * The unique identifier of the channel profile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#profile_id CesDeployment#profile_id}
    */
    readonly profileId?: string;
    /**
    * persona_property block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#persona_property CesDeployment#persona_property}
    */
    readonly personaProperty?: CesDeploymentChannelProfilePersonaProperty;
    /**
    * web_widget_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#web_widget_config CesDeployment#web_widget_config}
    */
    readonly webWidgetConfig?: CesDeploymentChannelProfileWebWidgetConfig;
    /**
    * whatsapp_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#whatsapp_config CesDeployment#whatsapp_config}
    */
    readonly whatsappConfig?: CesDeploymentChannelProfileWhatsappConfig;
}
export declare function cesDeploymentChannelProfileToTerraform(struct?: CesDeploymentChannelProfileOutputReference | CesDeploymentChannelProfile): any;
export declare function cesDeploymentChannelProfileToHclTerraform(struct?: CesDeploymentChannelProfileOutputReference | CesDeploymentChannelProfile): any;
export declare class CesDeploymentChannelProfileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesDeploymentChannelProfile | undefined;
    set internalValue(value: CesDeploymentChannelProfile | undefined);
    private _channelType?;
    get channelType(): string;
    set channelType(value: string);
    resetChannelType(): void;
    get channelTypeInput(): string | undefined;
    private _disableBargeInControl?;
    get disableBargeInControl(): boolean | cdktn.IResolvable;
    set disableBargeInControl(value: boolean | cdktn.IResolvable);
    resetDisableBargeInControl(): void;
    get disableBargeInControlInput(): boolean | cdktn.IResolvable | undefined;
    private _disableDtmf?;
    get disableDtmf(): boolean | cdktn.IResolvable;
    set disableDtmf(value: boolean | cdktn.IResolvable);
    resetDisableDtmf(): void;
    get disableDtmfInput(): boolean | cdktn.IResolvable | undefined;
    private _profileId?;
    get profileId(): string;
    set profileId(value: string);
    resetProfileId(): void;
    get profileIdInput(): string | undefined;
    private _personaProperty;
    get personaProperty(): CesDeploymentChannelProfilePersonaPropertyOutputReference;
    putPersonaProperty(value: CesDeploymentChannelProfilePersonaProperty): void;
    resetPersonaProperty(): void;
    get personaPropertyInput(): CesDeploymentChannelProfilePersonaProperty | undefined;
    private _webWidgetConfig;
    get webWidgetConfig(): CesDeploymentChannelProfileWebWidgetConfigOutputReference;
    putWebWidgetConfig(value: CesDeploymentChannelProfileWebWidgetConfig): void;
    resetWebWidgetConfig(): void;
    get webWidgetConfigInput(): CesDeploymentChannelProfileWebWidgetConfig | undefined;
    private _whatsappConfig;
    get whatsappConfig(): CesDeploymentChannelProfileWhatsappConfigOutputReference;
    putWhatsappConfig(value: CesDeploymentChannelProfileWhatsappConfig): void;
    resetWhatsappConfig(): void;
    get whatsappConfigInput(): CesDeploymentChannelProfileWhatsappConfig | undefined;
}
export interface CesDeploymentInstagramCredentials {
    /**
    * The Meta auth code provided by the embedded signup flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#auth_code CesDeployment#auth_code}
    */
    readonly authCode?: string;
    /**
    * The Meta auth code provided by the embedded signup flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#auth_code_wo CesDeployment#auth_code_wo}
    */
    readonly authCodeWo?: string;
    /**
    * Triggers update of 'auth_code_wo' write-only. Increment this value when an update to 'auth_code_wo' is needed. For more info see [updating write-only arguments](/docs/providers/google/guides/using_write_only_arguments.html#updating-write-only-arguments)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#auth_code_wo_version CesDeployment#auth_code_wo_version}
    */
    readonly authCodeWoVersion?: string;
    /**
    * The Conversation Profile ID to use for the deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#conversation_profile_id CesDeployment#conversation_profile_id}
    */
    readonly conversationProfileId?: string;
}
export declare function cesDeploymentInstagramCredentialsToTerraform(struct?: CesDeploymentInstagramCredentialsOutputReference | CesDeploymentInstagramCredentials): any;
export declare function cesDeploymentInstagramCredentialsToHclTerraform(struct?: CesDeploymentInstagramCredentialsOutputReference | CesDeploymentInstagramCredentials): any;
export declare class CesDeploymentInstagramCredentialsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesDeploymentInstagramCredentials | undefined;
    set internalValue(value: CesDeploymentInstagramCredentials | undefined);
    private _authCode?;
    get authCode(): string;
    set authCode(value: string);
    resetAuthCode(): void;
    get authCodeInput(): string | undefined;
    private _authCodeWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get authCodeWo(): string;
    set authCodeWo(value: string);
    resetAuthCodeWo(): void;
    get authCodeWoInput(): string | undefined;
    private _authCodeWoVersion?;
    get authCodeWoVersion(): string;
    set authCodeWoVersion(value: string);
    resetAuthCodeWoVersion(): void;
    get authCodeWoVersionInput(): string | undefined;
    private _conversationProfileId?;
    get conversationProfileId(): string;
    set conversationProfileId(value: string);
    resetConversationProfileId(): void;
    get conversationProfileIdInput(): string | undefined;
}
export interface CesDeploymentModelSettings {
    /**
    * The LLM model that the agent should use.
    * If not set, the agent will inherit the model from its parent agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#model CesDeployment#model}
    */
    readonly model?: string;
    /**
    * If set, this temperature will be used for the LLM model. Temperature
    * controls the randomness of the model's responses. Lower temperatures
    * produce responses that are more predictable. Higher temperatures produce
    * responses that are more creative.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#temperature CesDeployment#temperature}
    */
    readonly temperature?: number;
    /**
    * The thinking level of the model. Possible values: ["DEFAULT", "LOW", "MEDIUM", "HIGH"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#thinking_level CesDeployment#thinking_level}
    */
    readonly thinkingLevel?: string;
}
export declare function cesDeploymentModelSettingsToTerraform(struct?: CesDeploymentModelSettingsOutputReference | CesDeploymentModelSettings): any;
export declare function cesDeploymentModelSettingsToHclTerraform(struct?: CesDeploymentModelSettingsOutputReference | CesDeploymentModelSettings): any;
export declare class CesDeploymentModelSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesDeploymentModelSettings | undefined;
    set internalValue(value: CesDeploymentModelSettings | undefined);
    private _model?;
    get model(): string;
    set model(value: string);
    resetModel(): void;
    get modelInput(): string | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _thinkingLevel?;
    get thinkingLevel(): string;
    set thinkingLevel(value: string);
    resetThinkingLevel(): void;
    get thinkingLevelInput(): string | undefined;
}
export interface CesDeploymentTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#create CesDeployment#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#delete CesDeployment#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#update CesDeployment#update}
    */
    readonly update?: string;
}
export declare function cesDeploymentTimeoutsToTerraform(struct?: CesDeploymentTimeouts | cdktn.IResolvable): any;
export declare function cesDeploymentTimeoutsToHclTerraform(struct?: CesDeploymentTimeouts | cdktn.IResolvable): any;
export declare class CesDeploymentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesDeploymentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CesDeploymentTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface CesDeploymentWhatsappCredentials {
    /**
    * The Meta auth code provided by the embedded signup flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#auth_code CesDeployment#auth_code}
    */
    readonly authCode?: string;
    /**
    * The Meta auth code provided by the embedded signup flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#auth_code_wo CesDeployment#auth_code_wo}
    */
    readonly authCodeWo?: string;
    /**
    * Triggers update of 'auth_code_wo' write-only. Increment this value when an update to 'auth_code_wo' is needed. For more info see [updating write-only arguments](/docs/providers/google/guides/using_write_only_arguments.html#updating-write-only-arguments)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#auth_code_wo_version CesDeployment#auth_code_wo_version}
    */
    readonly authCodeWoVersion?: string;
    /**
    * The Business Account ID to use for the phone number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#business_account_id CesDeployment#business_account_id}
    */
    readonly businessAccountId: string;
    /**
    * The Conversation Profile ID to use for the deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#conversation_profile_id CesDeployment#conversation_profile_id}
    */
    readonly conversationProfileId?: string;
    /**
    * The phone number to register with WhatsApp.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#phone_number CesDeployment#phone_number}
    */
    readonly phoneNumber: string;
    /**
    * The 6-digit PIN created by the user for two-step verification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#pin CesDeployment#pin}
    */
    readonly pin?: string;
    /**
    * The 6-digit PIN created by the user for two-step verification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#pin_wo CesDeployment#pin_wo}
    */
    readonly pinWo?: string;
    /**
    * Triggers update of 'pin_wo' write-only. Increment this value when an update to 'pin_wo' is needed. For more info see [updating write-only arguments](/docs/providers/google/guides/using_write_only_arguments.html#updating-write-only-arguments)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#pin_wo_version CesDeployment#pin_wo_version}
    */
    readonly pinWoVersion?: string;
    /**
    * The WhatsApp Business Account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#waba_id CesDeployment#waba_id}
    */
    readonly wabaId: string;
}
export declare function cesDeploymentWhatsappCredentialsToTerraform(struct?: CesDeploymentWhatsappCredentialsOutputReference | CesDeploymentWhatsappCredentials): any;
export declare function cesDeploymentWhatsappCredentialsToHclTerraform(struct?: CesDeploymentWhatsappCredentialsOutputReference | CesDeploymentWhatsappCredentials): any;
export declare class CesDeploymentWhatsappCredentialsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CesDeploymentWhatsappCredentials | undefined;
    set internalValue(value: CesDeploymentWhatsappCredentials | undefined);
    private _authCode?;
    get authCode(): string;
    set authCode(value: string);
    resetAuthCode(): void;
    get authCodeInput(): string | undefined;
    private _authCodeWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get authCodeWo(): string;
    set authCodeWo(value: string);
    resetAuthCodeWo(): void;
    get authCodeWoInput(): string | undefined;
    private _authCodeWoVersion?;
    get authCodeWoVersion(): string;
    set authCodeWoVersion(value: string);
    resetAuthCodeWoVersion(): void;
    get authCodeWoVersionInput(): string | undefined;
    private _businessAccountId?;
    get businessAccountId(): string;
    set businessAccountId(value: string);
    get businessAccountIdInput(): string | undefined;
    private _conversationProfileId?;
    get conversationProfileId(): string;
    set conversationProfileId(value: string);
    resetConversationProfileId(): void;
    get conversationProfileIdInput(): string | undefined;
    private _phoneNumber?;
    get phoneNumber(): string;
    set phoneNumber(value: string);
    get phoneNumberInput(): string | undefined;
    private _pin?;
    get pin(): string;
    set pin(value: string);
    resetPin(): void;
    get pinInput(): string | undefined;
    private _pinWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get pinWo(): string;
    set pinWo(value: string);
    resetPinWo(): void;
    get pinWoInput(): string | undefined;
    private _pinWoVersion?;
    get pinWoVersion(): string;
    set pinWoVersion(value: string);
    resetPinWoVersion(): void;
    get pinWoVersionInput(): string | undefined;
    private _wabaId?;
    get wabaId(): string;
    set wabaId(value: string);
    get wabaIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment google_ces_deployment}
*/
export declare class CesDeployment extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_ces_deployment";
    /**
    * Generates CDKTN code for importing a CesDeployment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CesDeployment to import
    * @param importFromId The id of the existing CesDeployment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CesDeployment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/ces_deployment google_ces_deployment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CesDeploymentConfig
    */
    constructor(scope: Construct, id: string, config: CesDeploymentConfig);
    private _app?;
    get app(): string;
    set app(value: string);
    get appInput(): string | undefined;
    private _appVersion?;
    get appVersion(): string;
    set appVersion(value: string);
    get appVersionInput(): string | undefined;
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _modality?;
    get modality(): string;
    set modality(value: string);
    resetModality(): void;
    get modalityInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get updateTime(): string;
    private _channelProfile;
    get channelProfile(): CesDeploymentChannelProfileOutputReference;
    putChannelProfile(value: CesDeploymentChannelProfile): void;
    get channelProfileInput(): CesDeploymentChannelProfile | undefined;
    private _instagramCredentials;
    get instagramCredentials(): CesDeploymentInstagramCredentialsOutputReference;
    putInstagramCredentials(value: CesDeploymentInstagramCredentials): void;
    resetInstagramCredentials(): void;
    get instagramCredentialsInput(): CesDeploymentInstagramCredentials | undefined;
    private _modelSettings;
    get modelSettings(): CesDeploymentModelSettingsOutputReference;
    putModelSettings(value: CesDeploymentModelSettings): void;
    resetModelSettings(): void;
    get modelSettingsInput(): CesDeploymentModelSettings | undefined;
    private _timeouts;
    get timeouts(): CesDeploymentTimeoutsOutputReference;
    putTimeouts(value: CesDeploymentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CesDeploymentTimeouts | undefined;
    private _whatsappCredentials;
    get whatsappCredentials(): CesDeploymentWhatsappCredentialsOutputReference;
    putWhatsappCredentials(value: CesDeploymentWhatsappCredentials): void;
    resetWhatsappCredentials(): void;
    get whatsappCredentialsInput(): CesDeploymentWhatsappCredentials | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
