/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeBackendServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Lifetime of cookies in seconds if session_affinity is
    * GENERATED_COOKIE. If set to 0, the cookie is non-persistent and lasts
    * only until the end of the browser session (or equivalent). The
    * maximum allowed value for TTL is one day.
    *
    * When the load balancing scheme is INTERNAL, this field is not used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#affinity_cookie_ttl_sec ComputeBackendService#affinity_cookie_ttl_sec}
    */
    readonly affinityCookieTtlSec?: number;
    /**
    * Compress text responses using Brotli or gzip compression, based on the client's Accept-Encoding header. Possible values: ["AUTOMATIC", "DISABLED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#compression_mode ComputeBackendService#compression_mode}
    */
    readonly compressionMode?: string;
    /**
    * Time for which instance will be drained (not accept new
    * connections, but still work to finish started).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#connection_draining_timeout_sec ComputeBackendService#connection_draining_timeout_sec}
    */
    readonly connectionDrainingTimeoutSec?: number;
    /**
    * Headers that the HTTP/S load balancer should add to proxied
    * requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#custom_request_headers ComputeBackendService#custom_request_headers}
    */
    readonly customRequestHeaders?: string[];
    /**
    * Headers that the HTTP/S load balancer should add to proxied
    * responses.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#custom_response_headers ComputeBackendService#custom_response_headers}
    */
    readonly customResponseHeaders?: string[];
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#deletion_policy ComputeBackendService#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#description ComputeBackendService#description}
    */
    readonly description?: string;
    /**
    * The resource URL for the edge security policy associated with this backend service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#edge_security_policy ComputeBackendService#edge_security_policy}
    */
    readonly edgeSecurityPolicy?: string;
    /**
    * If true, enable Cloud CDN for this BackendService.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#enable_cdn ComputeBackendService#enable_cdn}
    */
    readonly enableCdn?: boolean | cdktn.IResolvable;
    /**
    * Specifies the canary migration state. Possible values are PREPARE, TEST_BY_PERCENTAGE, and
    * TEST_ALL_TRAFFIC.
    *
    * To begin the migration from EXTERNAL to EXTERNAL_MANAGED, the state must be changed to
    * PREPARE. The state must be changed to TEST_ALL_TRAFFIC before the loadBalancingScheme can be
    * changed to EXTERNAL_MANAGED. Optionally, the TEST_BY_PERCENTAGE state can be used to migrate
    * traffic by percentage using externalManagedMigrationTestingPercentage.
    *
    * Rolling back a migration requires the states to be set in reverse order. So changing the
    * scheme from EXTERNAL_MANAGED to EXTERNAL requires the state to be set to TEST_ALL_TRAFFIC at
    * the same time. Optionally, the TEST_BY_PERCENTAGE state can be used to migrate some traffic
    * back to EXTERNAL or PREPARE can be used to migrate all traffic back to EXTERNAL. Possible values: ["PREPARE", "TEST_BY_PERCENTAGE", "TEST_ALL_TRAFFIC"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#external_managed_migration_state ComputeBackendService#external_managed_migration_state}
    */
    readonly externalManagedMigrationState?: string;
    /**
    * Determines the fraction of requests that should be processed by the Global external
    * Application Load Balancer.
    *
    * The value of this field must be in the range [0, 100].
    *
    * Session affinity options will slightly affect this routing behavior, for more details,
    * see: Session Affinity.
    *
    * This value can only be set if the loadBalancingScheme in the backend service is set to
    * EXTERNAL (when using the Classic ALB) and the migration state is TEST_BY_PERCENTAGE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#external_managed_migration_testing_percentage ComputeBackendService#external_managed_migration_testing_percentage}
    */
    readonly externalManagedMigrationTestingPercentage?: number;
    /**
    * The set of URLs to the HttpHealthCheck or HttpsHealthCheck resource
    * for health checking this BackendService. Currently at most one health
    * check can be specified.
    *
    * A health check must be specified unless the backend service uses an internet
    * or serverless NEG as a backend.
    *
    * For internal load balancing, a URL to a HealthCheck resource must be specified instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#health_checks ComputeBackendService#health_checks}
    */
    readonly healthChecks?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#id ComputeBackendService#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies preference of traffic to the backend (from the proxy and from the client for proxyless gRPC). Possible values: ["IPV4_ONLY", "PREFER_IPV6", "IPV6_ONLY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#ip_address_selection_policy ComputeBackendService#ip_address_selection_policy}
    */
    readonly ipAddressSelectionPolicy?: string;
    /**
    * Indicates whether the backend service will be used with internal or
    * external load balancing. A backend service created for one type of
    * load balancing cannot be used with the other. For more information, refer to
    * [Choosing a load balancer](https://cloud.google.com/load-balancing/docs/backend-service). Default value: "EXTERNAL_MANAGED" Possible values: ["EXTERNAL", "INTERNAL_SELF_MANAGED", "INTERNAL_MANAGED", "EXTERNAL_MANAGED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#load_balancing_scheme ComputeBackendService#load_balancing_scheme}
    */
    readonly loadBalancingScheme?: string;
    /**
    * The load balancing algorithm used within the scope of the locality.
    * The possible values are:
    *
    * * 'ROUND_ROBIN': This is a simple policy in which each healthy backend
    *                  is selected in round robin order.
    *
    * * 'LEAST_REQUEST': An O(1) algorithm which selects two random healthy
    *                    hosts and picks the host which has fewer active requests.
    *
    * * 'RING_HASH': The ring/modulo hash load balancer implements consistent
    *                hashing to backends. The algorithm has the property that the
    *                addition/removal of a host from a set of N hosts only affects
    *                1/N of the requests.
    *
    * * 'RANDOM': The load balancer selects a random healthy host.
    *
    * * 'ORIGINAL_DESTINATION': Backend host is selected based on the client
    *                           connection metadata, i.e., connections are opened
    *                           to the same address as the destination address of
    *                           the incoming connection before the connection
    *                           was redirected to the load balancer.
    *
    * * 'MAGLEV': used as a drop in replacement for the ring hash load balancer.
    *             Maglev is not as stable as ring hash but has faster table lookup
    *             build times and host selection times. For more information about
    *             Maglev, refer to https://ai.google/research/pubs/pub44824
    *
    * * 'WEIGHTED_MAGLEV': Per-instance weighted Load Balancing via health check
    *                      reported weights. Only applicable to loadBalancingScheme
    *                      EXTERNAL. If set, the Backend Service must
    *                      configure a non legacy HTTP-based Health Check, and
    *                      health check replies are expected to contain
    *                      non-standard HTTP response header field
    *                      X-Load-Balancing-Endpoint-Weight to specify the
    *                      per-instance weights. If set, Load Balancing is weight
    *                      based on the per-instance weights reported in the last
    *                      processed health check replies, as long as every
    *                      instance either reported a valid weight or had
    *                      UNAVAILABLE_WEIGHT. Otherwise, Load Balancing remains
    *                      equal-weight.
    *
    * * 'WEIGHTED_ROUND_ROBIN': Per-endpoint weighted round-robin Load Balancing using weights computed
    *                           from Backend reported Custom Metrics. If set, the Backend Service
    *                           responses are expected to contain non-standard HTTP response header field
    *                           X-Endpoint-Load-Metrics. The reported metrics
    *                           to use for computing the weights are specified via the
    *                           backends[].customMetrics fields.
    *
    * locality_lb_policy is applicable to either:
    *
    * * A regional backend service with the service_protocol set to HTTP, HTTPS, HTTP2 or H2C,
    *   and loadBalancingScheme set to INTERNAL_MANAGED.
    * * A global backend service with the load_balancing_scheme set to INTERNAL_SELF_MANAGED.
    * * A regional backend service with loadBalancingScheme set to EXTERNAL (External Network
    *   Load Balancing). Only MAGLEV and WEIGHTED_MAGLEV values are possible for External
    *   Network Load Balancing. The default is MAGLEV.
    *
    * If session_affinity is not NONE, and locality_lb_policy is not set to MAGLEV, WEIGHTED_MAGLEV,
    * or RING_HASH, session affinity settings will not take effect.
    *
    * Only ROUND_ROBIN and RING_HASH are supported when the backend service is referenced
    * by a URL map that is bound to target gRPC proxy that has validate_for_proxyless
    * field set to true. Possible values: ["ROUND_ROBIN", "LEAST_REQUEST", "RING_HASH", "RANDOM", "ORIGINAL_DESTINATION", "MAGLEV", "WEIGHTED_MAGLEV", "WEIGHTED_ROUND_ROBIN"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#locality_lb_policy ComputeBackendService#locality_lb_policy}
    */
    readonly localityLbPolicy?: string;
    /**
    * Name of the resource. Provided by the client when the resource is
    * created. The name must be 1-63 characters long, and comply with
    * RFC1035. Specifically, the name must be 1-63 characters long and match
    * the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the
    * first character must be a lowercase letter, and all following
    * characters must be a dash, lowercase letter, or digit, except the last
    * character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#name ComputeBackendService#name}
    */
    readonly name: string;
    /**
    * Name of backend port. The same name should appear in the instance
    * groups referenced by this service. Required when the load balancing
    * scheme is EXTERNAL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#port_name ComputeBackendService#port_name}
    */
    readonly portName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#project ComputeBackendService#project}
    */
    readonly project?: string;
    /**
    * The protocol this BackendService uses to communicate with backends.
    * The default is HTTP. Possible values are HTTP, HTTPS, HTTP2, H2C, TCP, SSL, UDP
    * or GRPC. Refer to the documentation for the load balancers or for Traffic Director
    * for more information. Must be set to GRPC when the backend service is referenced
    * by a URL map that is bound to target gRPC proxy. Possible values: ["HTTP", "HTTPS", "HTTP2", "TCP", "SSL", "UDP", "GRPC", "UNSPECIFIED", "H2C"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#protocol ComputeBackendService#protocol}
    */
    readonly protocol?: string;
    /**
    * The security policy associated with this backend service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#security_policy ComputeBackendService#security_policy}
    */
    readonly securityPolicy?: string;
    /**
    * URL to networkservices.ServiceLbPolicy resource.
    * Can only be set if load balancing scheme is EXTERNAL_MANAGED, INTERNAL_MANAGED or INTERNAL_SELF_MANAGED. For a global backend service, the service lb policy must be global. For a regional backend service, the service lb policy must be regional and in the same region.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#service_lb_policy ComputeBackendService#service_lb_policy}
    */
    readonly serviceLbPolicy?: string;
    /**
    * Type of session affinity to use. The default is NONE. Session affinity is
    * not applicable if the protocol is UDP. Possible values: ["NONE", "CLIENT_IP", "CLIENT_IP_PORT_PROTO", "CLIENT_IP_PROTO", "GENERATED_COOKIE", "HEADER_FIELD", "HTTP_COOKIE", "STRONG_COOKIE_AFFINITY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#session_affinity ComputeBackendService#session_affinity}
    */
    readonly sessionAffinity?: string;
    /**
    * The backend service timeout has a different meaning depending on the type of load balancer.
    * For more information see, [Backend service settings](https://cloud.google.com/compute/docs/reference/rest/v1/backendServices).
    * The default is 30 seconds.
    * The full range of timeout values allowed goes from 1 through 2,147,483,647 seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#timeout_sec ComputeBackendService#timeout_sec}
    */
    readonly timeoutSec?: number;
    /**
    * backend block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#backend ComputeBackendService#backend}
    */
    readonly backend?: ComputeBackendServiceBackend[] | cdktn.IResolvable;
    /**
    * cdn_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#cdn_policy ComputeBackendService#cdn_policy}
    */
    readonly cdnPolicy?: ComputeBackendServiceCdnPolicy;
    /**
    * circuit_breakers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#circuit_breakers ComputeBackendService#circuit_breakers}
    */
    readonly circuitBreakers?: ComputeBackendServiceCircuitBreakers;
    /**
    * consistent_hash block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#consistent_hash ComputeBackendService#consistent_hash}
    */
    readonly consistentHash?: ComputeBackendServiceConsistentHash;
    /**
    * custom_metrics block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#custom_metrics ComputeBackendService#custom_metrics}
    */
    readonly customMetrics?: ComputeBackendServiceCustomMetrics[] | cdktn.IResolvable;
    /**
    * iap block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#iap ComputeBackendService#iap}
    */
    readonly iap?: ComputeBackendServiceIap;
    /**
    * locality_lb_policies block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#locality_lb_policies ComputeBackendService#locality_lb_policies}
    */
    readonly localityLbPolicies?: ComputeBackendServiceLocalityLbPolicies[] | cdktn.IResolvable;
    /**
    * log_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#log_config ComputeBackendService#log_config}
    */
    readonly logConfig?: ComputeBackendServiceLogConfig;
    /**
    * max_stream_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#max_stream_duration ComputeBackendService#max_stream_duration}
    */
    readonly maxStreamDuration?: ComputeBackendServiceMaxStreamDuration;
    /**
    * outlier_detection block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#outlier_detection ComputeBackendService#outlier_detection}
    */
    readonly outlierDetection?: ComputeBackendServiceOutlierDetection;
    /**
    * params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#params ComputeBackendService#params}
    */
    readonly params?: ComputeBackendServiceParams;
    /**
    * security_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#security_settings ComputeBackendService#security_settings}
    */
    readonly securitySettings?: ComputeBackendServiceSecuritySettings;
    /**
    * strong_session_affinity_cookie block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#strong_session_affinity_cookie ComputeBackendService#strong_session_affinity_cookie}
    */
    readonly strongSessionAffinityCookie?: ComputeBackendServiceStrongSessionAffinityCookie;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#timeouts ComputeBackendService#timeouts}
    */
    readonly timeouts?: ComputeBackendServiceTimeouts;
    /**
    * tls_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#tls_settings ComputeBackendService#tls_settings}
    */
    readonly tlsSettings?: ComputeBackendServiceTlsSettings;
}
export interface ComputeBackendServiceBackendCustomMetrics {
    /**
    * If true, the metric data is collected and reported to Cloud
    * Monitoring, but is not used for load balancing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#dry_run ComputeBackendService#dry_run}
    */
    readonly dryRun: boolean | cdktn.IResolvable;
    /**
    * Optional parameter to define a target utilization for the Custom Metrics
    * balancing mode. The valid range is <code>[0.0, 1.0]</code>.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#max_utilization ComputeBackendService#max_utilization}
    */
    readonly maxUtilization?: number;
    /**
    * Name of a custom utilization signal. The name must be 1-64 characters
    * long and match the regular expression [a-z]([-_.a-z0-9]*[a-z0-9])? which
    * means the first character must be a lowercase letter, and all following
    * characters must be a dash, period, underscore, lowercase letter, or
    * digit, except the last character, which cannot be a dash, period, or
    * underscore. For usage guidelines, see Custom Metrics balancing mode. This
    * field can only be used for a global or regional backend service with the
    * loadBalancingScheme set to <code>EXTERNAL_MANAGED</code>,
    * <code>INTERNAL_MANAGED</code> <code>INTERNAL_SELF_MANAGED</code>.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#name ComputeBackendService#name}
    */
    readonly name: string;
}
export declare function computeBackendServiceBackendCustomMetricsToTerraform(struct?: ComputeBackendServiceBackendCustomMetrics | cdktn.IResolvable): any;
export declare function computeBackendServiceBackendCustomMetricsToHclTerraform(struct?: ComputeBackendServiceBackendCustomMetrics | cdktn.IResolvable): any;
export declare class ComputeBackendServiceBackendCustomMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeBackendServiceBackendCustomMetrics | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeBackendServiceBackendCustomMetrics | cdktn.IResolvable | undefined);
    private _dryRun?;
    get dryRun(): boolean | cdktn.IResolvable;
    set dryRun(value: boolean | cdktn.IResolvable);
    get dryRunInput(): boolean | cdktn.IResolvable | undefined;
    private _maxUtilization?;
    get maxUtilization(): number;
    set maxUtilization(value: number);
    resetMaxUtilization(): void;
    get maxUtilizationInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class ComputeBackendServiceBackendCustomMetricsList extends cdktn.ComplexList {
    internalValue?: ComputeBackendServiceBackendCustomMetrics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeBackendServiceBackendCustomMetricsOutputReference;
}
export interface ComputeBackendServiceBackend {
    /**
    * Specifies the balancing mode for this backend.
    *
    * For global HTTP(S) or TCP/SSL load balancing, the default is
    * UTILIZATION. Valid values are UTILIZATION, RATE (for HTTP(S)),
    * CUSTOM_METRICS (for HTTP(s)) and CONNECTION (for TCP/SSL).
    *
    * See the [Backend Services Overview](https://cloud.google.com/load-balancing/docs/backend-service#balancing-mode)
    * for an explanation of load balancing modes. Default value: "UTILIZATION" Possible values: ["UTILIZATION", "RATE", "CONNECTION", "CUSTOM_METRICS", "IN_FLIGHT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#balancing_mode ComputeBackendService#balancing_mode}
    */
    readonly balancingMode?: string;
    /**
    * A multiplier applied to the group's maximum servicing capacity
    * (based on UTILIZATION, RATE or CONNECTION).
    *
    * Default value is 1, which means the group will serve up to 100%
    * of its configured capacity (depending on balancingMode). A
    * setting of 0 means the group is completely drained, offering
    * 0% of its available Capacity. Valid range is [0.0,1.0].
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#capacity_scaler ComputeBackendService#capacity_scaler}
    */
    readonly capacityScaler?: number;
    /**
    * An optional description of this resource.
    * Provide this property when you create the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#description ComputeBackendService#description}
    */
    readonly description?: string;
    /**
    * The fully-qualified URL of an Instance Group or Network Endpoint
    * Group resource. In case of instance group this defines the list
    * of instances that serve traffic. Member virtual machine
    * instances from each instance group must live in the same zone as
    * the instance group itself. No two backends in a backend service
    * are allowed to use same Instance Group resource.
    *
    * For Network Endpoint Groups this defines list of endpoints. All
    * endpoints of Network Endpoint Group must be hosted on instances
    * located in the same zone as the Network Endpoint Group.
    *
    * Backend services cannot mix Instance Group and
    * Network Endpoint Group backends.
    *
    * Note that you must specify an Instance Group or Network Endpoint
    * Group resource using the fully-qualified URL, rather than a
    * partial URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#group ComputeBackendService#group}
    */
    readonly group: string;
    /**
    * The max number of simultaneous connections for the group. Can
    * be used with either CONNECTION or UTILIZATION balancing modes.
    *
    * For CONNECTION mode, either maxConnections or one
    * of maxConnectionsPerInstance or maxConnectionsPerEndpoint,
    * as appropriate for group type, must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#max_connections ComputeBackendService#max_connections}
    */
    readonly maxConnections?: number;
    /**
    * The max number of simultaneous connections that a single backend
    * network endpoint can handle. This is used to calculate the
    * capacity of the group. Can be used in either CONNECTION or
    * UTILIZATION balancing modes.
    *
    * For CONNECTION mode, either
    * maxConnections or maxConnectionsPerEndpoint must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#max_connections_per_endpoint ComputeBackendService#max_connections_per_endpoint}
    */
    readonly maxConnectionsPerEndpoint?: number;
    /**
    * The max number of simultaneous connections that a single
    * backend instance can handle. This is used to calculate the
    * capacity of the group. Can be used in either CONNECTION or
    * UTILIZATION balancing modes.
    *
    * For CONNECTION mode, either maxConnections or
    * maxConnectionsPerInstance must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#max_connections_per_instance ComputeBackendService#max_connections_per_instance}
    */
    readonly maxConnectionsPerInstance?: number;
    /**
    * The max requests per second (RPS) of the group.
    *
    * Can be used with either RATE or UTILIZATION balancing modes,
    * but required if RATE mode. For RATE mode, either maxRate or one
    * of maxRatePerInstance or maxRatePerEndpoint, as appropriate for
    * group type, must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#max_rate ComputeBackendService#max_rate}
    */
    readonly maxRate?: number;
    /**
    * The max requests per second (RPS) that a single backend network
    * endpoint can handle. This is used to calculate the capacity of
    * the group. Can be used in either balancing mode. For RATE mode,
    * either maxRate or maxRatePerEndpoint must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#max_rate_per_endpoint ComputeBackendService#max_rate_per_endpoint}
    */
    readonly maxRatePerEndpoint?: number;
    /**
    * The max requests per second (RPS) that a single backend
    * instance can handle. This is used to calculate the capacity of
    * the group. Can be used in either balancing mode. For RATE mode,
    * either maxRate or maxRatePerInstance must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#max_rate_per_instance ComputeBackendService#max_rate_per_instance}
    */
    readonly maxRatePerInstance?: number;
    /**
    * Used when balancingMode is UTILIZATION. This ratio defines the
    * CPU utilization target for the group. Valid range is [0.0, 1.0].
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#max_utilization ComputeBackendService#max_utilization}
    */
    readonly maxUtilization?: number;
    /**
    * This field indicates whether this backend should be fully utilized before sending traffic to backends
    * with default preference. This field cannot be set when loadBalancingScheme is set to 'EXTERNAL'. The possible values are:
    *   - PREFERRED: Backends with this preference level will be filled up to their capacity limits first,
    *     based on RTT.
    *   - DEFAULT: If preferred backends don't have enough capacity, backends in this layer would be used and
    *     traffic would be assigned based on the load balancing algorithm you use. This is the default Possible values: ["PREFERRED", "DEFAULT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#preference ComputeBackendService#preference}
    */
    readonly preference?: string;
    /**
    * custom_metrics block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#custom_metrics ComputeBackendService#custom_metrics}
    */
    readonly customMetrics?: ComputeBackendServiceBackendCustomMetrics[] | cdktn.IResolvable;
}
export declare function computeBackendServiceBackendToTerraform(struct?: ComputeBackendServiceBackend | cdktn.IResolvable): any;
export declare function computeBackendServiceBackendToHclTerraform(struct?: ComputeBackendServiceBackend | cdktn.IResolvable): any;
export declare class ComputeBackendServiceBackendOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeBackendServiceBackend | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeBackendServiceBackend | cdktn.IResolvable | undefined);
    private _balancingMode?;
    get balancingMode(): string;
    set balancingMode(value: string);
    resetBalancingMode(): void;
    get balancingModeInput(): string | undefined;
    private _capacityScaler?;
    get capacityScaler(): number;
    set capacityScaler(value: number);
    resetCapacityScaler(): void;
    get capacityScalerInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _group?;
    get group(): string;
    set group(value: string);
    get groupInput(): string | undefined;
    private _maxConnections?;
    get maxConnections(): number;
    set maxConnections(value: number);
    resetMaxConnections(): void;
    get maxConnectionsInput(): number | undefined;
    private _maxConnectionsPerEndpoint?;
    get maxConnectionsPerEndpoint(): number;
    set maxConnectionsPerEndpoint(value: number);
    resetMaxConnectionsPerEndpoint(): void;
    get maxConnectionsPerEndpointInput(): number | undefined;
    private _maxConnectionsPerInstance?;
    get maxConnectionsPerInstance(): number;
    set maxConnectionsPerInstance(value: number);
    resetMaxConnectionsPerInstance(): void;
    get maxConnectionsPerInstanceInput(): number | undefined;
    private _maxRate?;
    get maxRate(): number;
    set maxRate(value: number);
    resetMaxRate(): void;
    get maxRateInput(): number | undefined;
    private _maxRatePerEndpoint?;
    get maxRatePerEndpoint(): number;
    set maxRatePerEndpoint(value: number);
    resetMaxRatePerEndpoint(): void;
    get maxRatePerEndpointInput(): number | undefined;
    private _maxRatePerInstance?;
    get maxRatePerInstance(): number;
    set maxRatePerInstance(value: number);
    resetMaxRatePerInstance(): void;
    get maxRatePerInstanceInput(): number | undefined;
    private _maxUtilization?;
    get maxUtilization(): number;
    set maxUtilization(value: number);
    resetMaxUtilization(): void;
    get maxUtilizationInput(): number | undefined;
    private _preference?;
    get preference(): string;
    set preference(value: string);
    resetPreference(): void;
    get preferenceInput(): string | undefined;
    private _customMetrics;
    get customMetrics(): ComputeBackendServiceBackendCustomMetricsList;
    putCustomMetrics(value: ComputeBackendServiceBackendCustomMetrics[] | cdktn.IResolvable): void;
    resetCustomMetrics(): void;
    get customMetricsInput(): cdktn.IResolvable | ComputeBackendServiceBackendCustomMetrics[] | undefined;
}
export declare class ComputeBackendServiceBackendList extends cdktn.ComplexList {
    internalValue?: ComputeBackendServiceBackend[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeBackendServiceBackendOutputReference;
}
export interface ComputeBackendServiceCdnPolicyBypassCacheOnRequestHeaders {
    /**
    * The header field name to match on when bypassing cache. Values are case-insensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#header_name ComputeBackendService#header_name}
    */
    readonly headerName: string;
}
export declare function computeBackendServiceCdnPolicyBypassCacheOnRequestHeadersToTerraform(struct?: ComputeBackendServiceCdnPolicyBypassCacheOnRequestHeaders | cdktn.IResolvable): any;
export declare function computeBackendServiceCdnPolicyBypassCacheOnRequestHeadersToHclTerraform(struct?: ComputeBackendServiceCdnPolicyBypassCacheOnRequestHeaders | cdktn.IResolvable): any;
export declare class ComputeBackendServiceCdnPolicyBypassCacheOnRequestHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeBackendServiceCdnPolicyBypassCacheOnRequestHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeBackendServiceCdnPolicyBypassCacheOnRequestHeaders | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    get headerNameInput(): string | undefined;
}
export declare class ComputeBackendServiceCdnPolicyBypassCacheOnRequestHeadersList extends cdktn.ComplexList {
    internalValue?: ComputeBackendServiceCdnPolicyBypassCacheOnRequestHeaders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeBackendServiceCdnPolicyBypassCacheOnRequestHeadersOutputReference;
}
export interface ComputeBackendServiceCdnPolicyCacheKeyPolicy {
    /**
    * If true requests to different hosts will be cached separately.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#include_host ComputeBackendService#include_host}
    */
    readonly includeHost?: boolean | cdktn.IResolvable;
    /**
    * Allows HTTP request headers (by name) to be used in the
    * cache key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#include_http_headers ComputeBackendService#include_http_headers}
    */
    readonly includeHttpHeaders?: string[];
    /**
    * Names of cookies to include in cache keys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#include_named_cookies ComputeBackendService#include_named_cookies}
    */
    readonly includeNamedCookies?: string[];
    /**
    * If true, http and https requests will be cached separately.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#include_protocol ComputeBackendService#include_protocol}
    */
    readonly includeProtocol?: boolean | cdktn.IResolvable;
    /**
    * If true, include query string parameters in the cache key
    * according to query_string_whitelist and
    * query_string_blacklist. If neither is set, the entire query
    * string will be included.
    *
    * If false, the query string will be excluded from the cache
    * key entirely.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#include_query_string ComputeBackendService#include_query_string}
    */
    readonly includeQueryString?: boolean | cdktn.IResolvable;
    /**
    * Names of query string parameters to exclude in cache keys.
    *
    * All other parameters will be included. Either specify
    * query_string_whitelist or query_string_blacklist, not both.
    * '&' and '=' will be percent encoded and not treated as
    * delimiters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#query_string_blacklist ComputeBackendService#query_string_blacklist}
    */
    readonly queryStringBlacklist?: string[];
    /**
    * Names of query string parameters to include in cache keys.
    *
    * All other parameters will be excluded. Either specify
    * query_string_whitelist or query_string_blacklist, not both.
    * '&' and '=' will be percent encoded and not treated as
    * delimiters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#query_string_whitelist ComputeBackendService#query_string_whitelist}
    */
    readonly queryStringWhitelist?: string[];
}
export declare function computeBackendServiceCdnPolicyCacheKeyPolicyToTerraform(struct?: ComputeBackendServiceCdnPolicyCacheKeyPolicyOutputReference | ComputeBackendServiceCdnPolicyCacheKeyPolicy): any;
export declare function computeBackendServiceCdnPolicyCacheKeyPolicyToHclTerraform(struct?: ComputeBackendServiceCdnPolicyCacheKeyPolicyOutputReference | ComputeBackendServiceCdnPolicyCacheKeyPolicy): any;
export declare class ComputeBackendServiceCdnPolicyCacheKeyPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeBackendServiceCdnPolicyCacheKeyPolicy | undefined;
    set internalValue(value: ComputeBackendServiceCdnPolicyCacheKeyPolicy | undefined);
    private _includeHost?;
    get includeHost(): boolean | cdktn.IResolvable;
    set includeHost(value: boolean | cdktn.IResolvable);
    resetIncludeHost(): void;
    get includeHostInput(): boolean | cdktn.IResolvable | undefined;
    private _includeHttpHeaders?;
    get includeHttpHeaders(): string[];
    set includeHttpHeaders(value: string[]);
    resetIncludeHttpHeaders(): void;
    get includeHttpHeadersInput(): string[] | undefined;
    private _includeNamedCookies?;
    get includeNamedCookies(): string[];
    set includeNamedCookies(value: string[]);
    resetIncludeNamedCookies(): void;
    get includeNamedCookiesInput(): string[] | undefined;
    private _includeProtocol?;
    get includeProtocol(): boolean | cdktn.IResolvable;
    set includeProtocol(value: boolean | cdktn.IResolvable);
    resetIncludeProtocol(): void;
    get includeProtocolInput(): boolean | cdktn.IResolvable | undefined;
    private _includeQueryString?;
    get includeQueryString(): boolean | cdktn.IResolvable;
    set includeQueryString(value: boolean | cdktn.IResolvable);
    resetIncludeQueryString(): void;
    get includeQueryStringInput(): boolean | cdktn.IResolvable | undefined;
    private _queryStringBlacklist?;
    get queryStringBlacklist(): string[];
    set queryStringBlacklist(value: string[]);
    resetQueryStringBlacklist(): void;
    get queryStringBlacklistInput(): string[] | undefined;
    private _queryStringWhitelist?;
    get queryStringWhitelist(): string[];
    set queryStringWhitelist(value: string[]);
    resetQueryStringWhitelist(): void;
    get queryStringWhitelistInput(): string[] | undefined;
}
export interface ComputeBackendServiceCdnPolicyNegativeCachingPolicy {
    /**
    * The HTTP status code to define a TTL against. Only HTTP status codes 300, 301, 308, 404, 405, 410, 421, 451 and 501
    * can be specified as values, and you cannot specify a status code more than once.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#code ComputeBackendService#code}
    */
    readonly code?: number;
    /**
    * The TTL (in seconds) for which to cache responses with the corresponding status code. The maximum allowed value is 1800s
    * (30 minutes), noting that infrequently accessed objects may be evicted from the cache before the defined TTL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#ttl ComputeBackendService#ttl}
    */
    readonly ttl?: number;
}
export declare function computeBackendServiceCdnPolicyNegativeCachingPolicyToTerraform(struct?: ComputeBackendServiceCdnPolicyNegativeCachingPolicy | cdktn.IResolvable): any;
export declare function computeBackendServiceCdnPolicyNegativeCachingPolicyToHclTerraform(struct?: ComputeBackendServiceCdnPolicyNegativeCachingPolicy | cdktn.IResolvable): any;
export declare class ComputeBackendServiceCdnPolicyNegativeCachingPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeBackendServiceCdnPolicyNegativeCachingPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeBackendServiceCdnPolicyNegativeCachingPolicy | cdktn.IResolvable | undefined);
    private _code?;
    get code(): number;
    set code(value: number);
    resetCode(): void;
    get codeInput(): number | undefined;
    private _ttl?;
    get ttl(): number;
    set ttl(value: number);
    resetTtl(): void;
    get ttlInput(): number | undefined;
}
export declare class ComputeBackendServiceCdnPolicyNegativeCachingPolicyList extends cdktn.ComplexList {
    internalValue?: ComputeBackendServiceCdnPolicyNegativeCachingPolicy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeBackendServiceCdnPolicyNegativeCachingPolicyOutputReference;
}
export interface ComputeBackendServiceCdnPolicy {
    /**
    * Specifies the cache setting for all responses from this backend.
    * The possible values are: USE_ORIGIN_HEADERS, FORCE_CACHE_ALL and CACHE_ALL_STATIC Possible values: ["USE_ORIGIN_HEADERS", "FORCE_CACHE_ALL", "CACHE_ALL_STATIC"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#cache_mode ComputeBackendService#cache_mode}
    */
    readonly cacheMode?: string;
    /**
    * Specifies the maximum allowed TTL for cached content served by this origin.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#client_ttl ComputeBackendService#client_ttl}
    */
    readonly clientTtl?: number;
    /**
    * Specifies the default TTL for cached content served by this origin for responses
    * that do not have an existing valid TTL (max-age or s-max-age).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#default_ttl ComputeBackendService#default_ttl}
    */
    readonly defaultTtl?: number;
    /**
    * Specifies the maximum allowed TTL for cached content served by this origin.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#max_ttl ComputeBackendService#max_ttl}
    */
    readonly maxTtl?: number;
    /**
    * Negative caching allows per-status code TTLs to be set, in order to apply fine-grained caching for common errors or redirects.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#negative_caching ComputeBackendService#negative_caching}
    */
    readonly negativeCaching?: boolean | cdktn.IResolvable;
    /**
    * If true then Cloud CDN will combine multiple concurrent cache fill requests into a small number of requests
    * to the origin.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#request_coalescing ComputeBackendService#request_coalescing}
    */
    readonly requestCoalescing?: boolean | cdktn.IResolvable;
    /**
    * Serve existing content from the cache (if available) when revalidating content with the origin, or when an error is encountered when refreshing the cache.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#serve_while_stale ComputeBackendService#serve_while_stale}
    */
    readonly serveWhileStale?: number;
    /**
    * Maximum number of seconds the response to a signed URL request
    * will be considered fresh, defaults to 1hr (3600s). After this
    * time period, the response will be revalidated before
    * being served.
    *
    * When serving responses to signed URL requests, Cloud CDN will
    * internally behave as though all responses from this backend had a
    * "Cache-Control: public, max-age=[TTL]" header, regardless of any
    * existing Cache-Control header. The actual headers served in
    * responses will not be altered.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#signed_url_cache_max_age_sec ComputeBackendService#signed_url_cache_max_age_sec}
    */
    readonly signedUrlCacheMaxAgeSec?: number;
    /**
    * bypass_cache_on_request_headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#bypass_cache_on_request_headers ComputeBackendService#bypass_cache_on_request_headers}
    */
    readonly bypassCacheOnRequestHeaders?: ComputeBackendServiceCdnPolicyBypassCacheOnRequestHeaders[] | cdktn.IResolvable;
    /**
    * cache_key_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#cache_key_policy ComputeBackendService#cache_key_policy}
    */
    readonly cacheKeyPolicy?: ComputeBackendServiceCdnPolicyCacheKeyPolicy;
    /**
    * negative_caching_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#negative_caching_policy ComputeBackendService#negative_caching_policy}
    */
    readonly negativeCachingPolicy?: ComputeBackendServiceCdnPolicyNegativeCachingPolicy[] | cdktn.IResolvable;
}
export declare function computeBackendServiceCdnPolicyToTerraform(struct?: ComputeBackendServiceCdnPolicyOutputReference | ComputeBackendServiceCdnPolicy): any;
export declare function computeBackendServiceCdnPolicyToHclTerraform(struct?: ComputeBackendServiceCdnPolicyOutputReference | ComputeBackendServiceCdnPolicy): any;
export declare class ComputeBackendServiceCdnPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeBackendServiceCdnPolicy | undefined;
    set internalValue(value: ComputeBackendServiceCdnPolicy | undefined);
    private _cacheMode?;
    get cacheMode(): string;
    set cacheMode(value: string);
    resetCacheMode(): void;
    get cacheModeInput(): string | undefined;
    private _clientTtl?;
    get clientTtl(): number;
    set clientTtl(value: number);
    resetClientTtl(): void;
    get clientTtlInput(): number | undefined;
    private _defaultTtl?;
    get defaultTtl(): number;
    set defaultTtl(value: number);
    resetDefaultTtl(): void;
    get defaultTtlInput(): number | undefined;
    private _maxTtl?;
    get maxTtl(): number;
    set maxTtl(value: number);
    resetMaxTtl(): void;
    get maxTtlInput(): number | undefined;
    private _negativeCaching?;
    get negativeCaching(): boolean | cdktn.IResolvable;
    set negativeCaching(value: boolean | cdktn.IResolvable);
    resetNegativeCaching(): void;
    get negativeCachingInput(): boolean | cdktn.IResolvable | undefined;
    private _requestCoalescing?;
    get requestCoalescing(): boolean | cdktn.IResolvable;
    set requestCoalescing(value: boolean | cdktn.IResolvable);
    resetRequestCoalescing(): void;
    get requestCoalescingInput(): boolean | cdktn.IResolvable | undefined;
    private _serveWhileStale?;
    get serveWhileStale(): number;
    set serveWhileStale(value: number);
    resetServeWhileStale(): void;
    get serveWhileStaleInput(): number | undefined;
    private _signedUrlCacheMaxAgeSec?;
    get signedUrlCacheMaxAgeSec(): number;
    set signedUrlCacheMaxAgeSec(value: number);
    resetSignedUrlCacheMaxAgeSec(): void;
    get signedUrlCacheMaxAgeSecInput(): number | undefined;
    private _bypassCacheOnRequestHeaders;
    get bypassCacheOnRequestHeaders(): ComputeBackendServiceCdnPolicyBypassCacheOnRequestHeadersList;
    putBypassCacheOnRequestHeaders(value: ComputeBackendServiceCdnPolicyBypassCacheOnRequestHeaders[] | cdktn.IResolvable): void;
    resetBypassCacheOnRequestHeaders(): void;
    get bypassCacheOnRequestHeadersInput(): cdktn.IResolvable | ComputeBackendServiceCdnPolicyBypassCacheOnRequestHeaders[] | undefined;
    private _cacheKeyPolicy;
    get cacheKeyPolicy(): ComputeBackendServiceCdnPolicyCacheKeyPolicyOutputReference;
    putCacheKeyPolicy(value: ComputeBackendServiceCdnPolicyCacheKeyPolicy): void;
    resetCacheKeyPolicy(): void;
    get cacheKeyPolicyInput(): ComputeBackendServiceCdnPolicyCacheKeyPolicy | undefined;
    private _negativeCachingPolicy;
    get negativeCachingPolicy(): ComputeBackendServiceCdnPolicyNegativeCachingPolicyList;
    putNegativeCachingPolicy(value: ComputeBackendServiceCdnPolicyNegativeCachingPolicy[] | cdktn.IResolvable): void;
    resetNegativeCachingPolicy(): void;
    get negativeCachingPolicyInput(): cdktn.IResolvable | ComputeBackendServiceCdnPolicyNegativeCachingPolicy[] | undefined;
}
export interface ComputeBackendServiceCircuitBreakers {
    /**
    * The maximum number of connections to the backend cluster.
    * Defaults to 1024.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#max_connections ComputeBackendService#max_connections}
    */
    readonly maxConnections?: number;
    /**
    * The maximum number of pending requests to the backend cluster.
    * Defaults to 1024.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#max_pending_requests ComputeBackendService#max_pending_requests}
    */
    readonly maxPendingRequests?: number;
    /**
    * The maximum number of parallel requests to the backend cluster.
    * Defaults to 1024.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#max_requests ComputeBackendService#max_requests}
    */
    readonly maxRequests?: number;
    /**
    * Maximum requests for a single backend connection. This parameter
    * is respected by both the HTTP/1.1 and HTTP/2 implementations. If
    * not specified, there is no limit. Setting this parameter to 1
    * will effectively disable keep alive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#max_requests_per_connection ComputeBackendService#max_requests_per_connection}
    */
    readonly maxRequestsPerConnection?: number;
    /**
    * The maximum number of parallel retries to the backend cluster.
    * Defaults to 3.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#max_retries ComputeBackendService#max_retries}
    */
    readonly maxRetries?: number;
}
export declare function computeBackendServiceCircuitBreakersToTerraform(struct?: ComputeBackendServiceCircuitBreakersOutputReference | ComputeBackendServiceCircuitBreakers): any;
export declare function computeBackendServiceCircuitBreakersToHclTerraform(struct?: ComputeBackendServiceCircuitBreakersOutputReference | ComputeBackendServiceCircuitBreakers): any;
export declare class ComputeBackendServiceCircuitBreakersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeBackendServiceCircuitBreakers | undefined;
    set internalValue(value: ComputeBackendServiceCircuitBreakers | undefined);
    private _maxConnections?;
    get maxConnections(): number;
    set maxConnections(value: number);
    resetMaxConnections(): void;
    get maxConnectionsInput(): number | undefined;
    private _maxPendingRequests?;
    get maxPendingRequests(): number;
    set maxPendingRequests(value: number);
    resetMaxPendingRequests(): void;
    get maxPendingRequestsInput(): number | undefined;
    private _maxRequests?;
    get maxRequests(): number;
    set maxRequests(value: number);
    resetMaxRequests(): void;
    get maxRequestsInput(): number | undefined;
    private _maxRequestsPerConnection?;
    get maxRequestsPerConnection(): number;
    set maxRequestsPerConnection(value: number);
    resetMaxRequestsPerConnection(): void;
    get maxRequestsPerConnectionInput(): number | undefined;
    private _maxRetries?;
    get maxRetries(): number;
    set maxRetries(value: number);
    resetMaxRetries(): void;
    get maxRetriesInput(): number | undefined;
}
export interface ComputeBackendServiceConsistentHashHttpCookieTtl {
    /**
    * Span of time that's a fraction of a second at nanosecond
    * resolution. Durations less than one second are represented
    * with a 0 seconds field and a positive nanos field. Must
    * be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#nanos ComputeBackendService#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second.
    * Must be from 0 to 315,576,000,000 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#seconds ComputeBackendService#seconds}
    */
    readonly seconds: number;
}
export declare function computeBackendServiceConsistentHashHttpCookieTtlToTerraform(struct?: ComputeBackendServiceConsistentHashHttpCookieTtlOutputReference | ComputeBackendServiceConsistentHashHttpCookieTtl): any;
export declare function computeBackendServiceConsistentHashHttpCookieTtlToHclTerraform(struct?: ComputeBackendServiceConsistentHashHttpCookieTtlOutputReference | ComputeBackendServiceConsistentHashHttpCookieTtl): any;
export declare class ComputeBackendServiceConsistentHashHttpCookieTtlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeBackendServiceConsistentHashHttpCookieTtl | undefined;
    set internalValue(value: ComputeBackendServiceConsistentHashHttpCookieTtl | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): number;
    set seconds(value: number);
    get secondsInput(): number | undefined;
}
export interface ComputeBackendServiceConsistentHashHttpCookie {
    /**
    * Name of the cookie.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#name ComputeBackendService#name}
    */
    readonly name?: string;
    /**
    * Path to set for the cookie.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#path ComputeBackendService#path}
    */
    readonly path?: string;
    /**
    * ttl block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#ttl ComputeBackendService#ttl}
    */
    readonly ttl?: ComputeBackendServiceConsistentHashHttpCookieTtl;
}
export declare function computeBackendServiceConsistentHashHttpCookieToTerraform(struct?: ComputeBackendServiceConsistentHashHttpCookieOutputReference | ComputeBackendServiceConsistentHashHttpCookie): any;
export declare function computeBackendServiceConsistentHashHttpCookieToHclTerraform(struct?: ComputeBackendServiceConsistentHashHttpCookieOutputReference | ComputeBackendServiceConsistentHashHttpCookie): any;
export declare class ComputeBackendServiceConsistentHashHttpCookieOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeBackendServiceConsistentHashHttpCookie | undefined;
    set internalValue(value: ComputeBackendServiceConsistentHashHttpCookie | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _ttl;
    get ttl(): ComputeBackendServiceConsistentHashHttpCookieTtlOutputReference;
    putTtl(value: ComputeBackendServiceConsistentHashHttpCookieTtl): void;
    resetTtl(): void;
    get ttlInput(): ComputeBackendServiceConsistentHashHttpCookieTtl | undefined;
}
export interface ComputeBackendServiceConsistentHash {
    /**
    * The hash based on the value of the specified header field.
    * This field is applicable if the sessionAffinity is set to HEADER_FIELD.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#http_header_name ComputeBackendService#http_header_name}
    */
    readonly httpHeaderName?: string;
    /**
    * The minimum number of virtual nodes to use for the hash ring.
    * Larger ring sizes result in more granular load
    * distributions. If the number of hosts in the load balancing pool
    * is larger than the ring size, each host will be assigned a single
    * virtual node.
    * Defaults to 1024.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#minimum_ring_size ComputeBackendService#minimum_ring_size}
    */
    readonly minimumRingSize?: number;
    /**
    * http_cookie block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#http_cookie ComputeBackendService#http_cookie}
    */
    readonly httpCookie?: ComputeBackendServiceConsistentHashHttpCookie;
}
export declare function computeBackendServiceConsistentHashToTerraform(struct?: ComputeBackendServiceConsistentHashOutputReference | ComputeBackendServiceConsistentHash): any;
export declare function computeBackendServiceConsistentHashToHclTerraform(struct?: ComputeBackendServiceConsistentHashOutputReference | ComputeBackendServiceConsistentHash): any;
export declare class ComputeBackendServiceConsistentHashOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeBackendServiceConsistentHash | undefined;
    set internalValue(value: ComputeBackendServiceConsistentHash | undefined);
    private _httpHeaderName?;
    get httpHeaderName(): string;
    set httpHeaderName(value: string);
    resetHttpHeaderName(): void;
    get httpHeaderNameInput(): string | undefined;
    private _minimumRingSize?;
    get minimumRingSize(): number;
    set minimumRingSize(value: number);
    resetMinimumRingSize(): void;
    get minimumRingSizeInput(): number | undefined;
    private _httpCookie;
    get httpCookie(): ComputeBackendServiceConsistentHashHttpCookieOutputReference;
    putHttpCookie(value: ComputeBackendServiceConsistentHashHttpCookie): void;
    resetHttpCookie(): void;
    get httpCookieInput(): ComputeBackendServiceConsistentHashHttpCookie | undefined;
}
export interface ComputeBackendServiceCustomMetrics {
    /**
    * If true, the metric data is not used for load balancing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#dry_run ComputeBackendService#dry_run}
    */
    readonly dryRun: boolean | cdktn.IResolvable;
    /**
    * Name of a custom utilization signal. The name must be 1-64 characters
    * long and match the regular expression [a-z]([-_.a-z0-9]*[a-z0-9])? which
    * means the first character must be a lowercase letter, and all following
    * characters must be a dash, period, underscore, lowercase letter, or
    * digit, except the last character, which cannot be a dash, period, or
    * underscore. For usage guidelines, see Custom Metrics balancing mode. This
    * field can only be used for a global or regional backend service with the
    * loadBalancingScheme set to <code>EXTERNAL_MANAGED</code>,
    * <code>INTERNAL_MANAGED</code> <code>INTERNAL_SELF_MANAGED</code>.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#name ComputeBackendService#name}
    */
    readonly name: string;
}
export declare function computeBackendServiceCustomMetricsToTerraform(struct?: ComputeBackendServiceCustomMetrics | cdktn.IResolvable): any;
export declare function computeBackendServiceCustomMetricsToHclTerraform(struct?: ComputeBackendServiceCustomMetrics | cdktn.IResolvable): any;
export declare class ComputeBackendServiceCustomMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeBackendServiceCustomMetrics | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeBackendServiceCustomMetrics | cdktn.IResolvable | undefined);
    private _dryRun?;
    get dryRun(): boolean | cdktn.IResolvable;
    set dryRun(value: boolean | cdktn.IResolvable);
    get dryRunInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class ComputeBackendServiceCustomMetricsList extends cdktn.ComplexList {
    internalValue?: ComputeBackendServiceCustomMetrics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeBackendServiceCustomMetricsOutputReference;
}
export interface ComputeBackendServiceIap {
    /**
    * Whether the serving infrastructure will authenticate and authorize all incoming requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#enabled ComputeBackendService#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * OAuth2 Client ID for IAP
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#oauth2_client_id ComputeBackendService#oauth2_client_id}
    */
    readonly oauth2ClientId?: string;
    /**
    * OAuth2 Client ID for IAP
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#oauth2_client_id_wo ComputeBackendService#oauth2_client_id_wo}
    */
    readonly oauth2ClientIdWo?: string;
    /**
    * Triggers update of 'oauth2_client_id_wo' write-only. Increment this value when an update to 'oauth2_client_id_wo' is needed. For more info see [updating write-only arguments](/docs/providers/google/guides/using_write_only_arguments.html#updating-write-only-arguments)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#oauth2_client_id_wo_version ComputeBackendService#oauth2_client_id_wo_version}
    */
    readonly oauth2ClientIdWoVersion?: string;
    /**
    * OAuth2 Client Secret for IAP
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#oauth2_client_secret ComputeBackendService#oauth2_client_secret}
    */
    readonly oauth2ClientSecret?: string;
    /**
    * OAuth2 Client Secret for IAP
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#oauth2_client_secret_wo ComputeBackendService#oauth2_client_secret_wo}
    */
    readonly oauth2ClientSecretWo?: string;
    /**
    * Triggers update of 'oauth2_client_secret_wo' write-only. Increment this value when an update to 'oauth2_client_secret_wo' is needed. For more info see [updating write-only arguments](/docs/providers/google/guides/using_write_only_arguments.html#updating-write-only-arguments)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#oauth2_client_secret_wo_version ComputeBackendService#oauth2_client_secret_wo_version}
    */
    readonly oauth2ClientSecretWoVersion?: string;
}
export declare function computeBackendServiceIapToTerraform(struct?: ComputeBackendServiceIapOutputReference | ComputeBackendServiceIap): any;
export declare function computeBackendServiceIapToHclTerraform(struct?: ComputeBackendServiceIapOutputReference | ComputeBackendServiceIap): any;
export declare class ComputeBackendServiceIapOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeBackendServiceIap | undefined;
    set internalValue(value: ComputeBackendServiceIap | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _oauth2ClientId?;
    get oauth2ClientId(): string;
    set oauth2ClientId(value: string);
    resetOauth2ClientId(): void;
    get oauth2ClientIdInput(): string | undefined;
    private _oauth2ClientIdWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get oauth2ClientIdWo(): string;
    set oauth2ClientIdWo(value: string);
    resetOauth2ClientIdWo(): void;
    get oauth2ClientIdWoInput(): string | undefined;
    private _oauth2ClientIdWoVersion?;
    get oauth2ClientIdWoVersion(): string;
    set oauth2ClientIdWoVersion(value: string);
    resetOauth2ClientIdWoVersion(): void;
    get oauth2ClientIdWoVersionInput(): string | undefined;
    private _oauth2ClientSecret?;
    get oauth2ClientSecret(): string;
    set oauth2ClientSecret(value: string);
    resetOauth2ClientSecret(): void;
    get oauth2ClientSecretInput(): string | undefined;
    get oauth2ClientSecretSha256(): string;
    private _oauth2ClientSecretWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get oauth2ClientSecretWo(): string;
    set oauth2ClientSecretWo(value: string);
    resetOauth2ClientSecretWo(): void;
    get oauth2ClientSecretWoInput(): string | undefined;
    private _oauth2ClientSecretWoVersion?;
    get oauth2ClientSecretWoVersion(): string;
    set oauth2ClientSecretWoVersion(value: string);
    resetOauth2ClientSecretWoVersion(): void;
    get oauth2ClientSecretWoVersionInput(): string | undefined;
}
export interface ComputeBackendServiceLocalityLbPoliciesCustomPolicy {
    /**
    * An optional, arbitrary JSON object with configuration data, understood
    * by a locally installed custom policy implementation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#data ComputeBackendService#data}
    */
    readonly data?: string;
    /**
    * Identifies the custom policy.
    *
    * The value should match the type the custom implementation is registered
    * with on the gRPC clients. It should follow protocol buffer
    * message naming conventions and include the full path (e.g.
    * myorg.CustomLbPolicy). The maximum length is 256 characters.
    *
    * Note that specifying the same custom policy more than once for a
    * backend is not a valid configuration and will be rejected.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#name ComputeBackendService#name}
    */
    readonly name: string;
}
export declare function computeBackendServiceLocalityLbPoliciesCustomPolicyToTerraform(struct?: ComputeBackendServiceLocalityLbPoliciesCustomPolicyOutputReference | ComputeBackendServiceLocalityLbPoliciesCustomPolicy): any;
export declare function computeBackendServiceLocalityLbPoliciesCustomPolicyToHclTerraform(struct?: ComputeBackendServiceLocalityLbPoliciesCustomPolicyOutputReference | ComputeBackendServiceLocalityLbPoliciesCustomPolicy): any;
export declare class ComputeBackendServiceLocalityLbPoliciesCustomPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeBackendServiceLocalityLbPoliciesCustomPolicy | undefined;
    set internalValue(value: ComputeBackendServiceLocalityLbPoliciesCustomPolicy | undefined);
    private _data?;
    get data(): string;
    set data(value: string);
    resetData(): void;
    get dataInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface ComputeBackendServiceLocalityLbPoliciesPolicy {
    /**
    * The name of a locality load balancer policy to be used. The value
    * should be one of the predefined ones as supported by localityLbPolicy,
    * although at the moment only ROUND_ROBIN is supported.
    *
    * This field should only be populated when the customPolicy field is not
    * used.
    *
    * Note that specifying the same policy more than once for a backend is
    * not a valid configuration and will be rejected.
    *
    * The possible values are:
    *
    * * 'ROUND_ROBIN': This is a simple policy in which each healthy backend
    *                 is selected in round robin order.
    *
    * * 'LEAST_REQUEST': An O(1) algorithm which selects two random healthy
    *                   hosts and picks the host which has fewer active requests.
    *
    * * 'RING_HASH': The ring/modulo hash load balancer implements consistent
    *               hashing to backends. The algorithm has the property that the
    *               addition/removal of a host from a set of N hosts only affects
    *               1/N of the requests.
    *
    * * 'RANDOM': The load balancer selects a random healthy host.
    *
    * * 'ORIGINAL_DESTINATION': Backend host is selected based on the client
    *                           connection metadata, i.e., connections are opened
    *                           to the same address as the destination address of
    *                           the incoming connection before the connection
    *                           was redirected to the load balancer.
    *
    * * 'MAGLEV': used as a drop in replacement for the ring hash load balancer.
    *             Maglev is not as stable as ring hash but has faster table lookup
    *             build times and host selection times. For more information about
    *             Maglev, refer to https://ai.google/research/pubs/pub44824 Possible values: ["ROUND_ROBIN", "LEAST_REQUEST", "RING_HASH", "RANDOM", "ORIGINAL_DESTINATION", "MAGLEV"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#name ComputeBackendService#name}
    */
    readonly name: string;
}
export declare function computeBackendServiceLocalityLbPoliciesPolicyToTerraform(struct?: ComputeBackendServiceLocalityLbPoliciesPolicyOutputReference | ComputeBackendServiceLocalityLbPoliciesPolicy): any;
export declare function computeBackendServiceLocalityLbPoliciesPolicyToHclTerraform(struct?: ComputeBackendServiceLocalityLbPoliciesPolicyOutputReference | ComputeBackendServiceLocalityLbPoliciesPolicy): any;
export declare class ComputeBackendServiceLocalityLbPoliciesPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeBackendServiceLocalityLbPoliciesPolicy | undefined;
    set internalValue(value: ComputeBackendServiceLocalityLbPoliciesPolicy | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface ComputeBackendServiceLocalityLbPolicies {
    /**
    * custom_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#custom_policy ComputeBackendService#custom_policy}
    */
    readonly customPolicy?: ComputeBackendServiceLocalityLbPoliciesCustomPolicy;
    /**
    * policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#policy ComputeBackendService#policy}
    */
    readonly policy?: ComputeBackendServiceLocalityLbPoliciesPolicy;
}
export declare function computeBackendServiceLocalityLbPoliciesToTerraform(struct?: ComputeBackendServiceLocalityLbPolicies | cdktn.IResolvable): any;
export declare function computeBackendServiceLocalityLbPoliciesToHclTerraform(struct?: ComputeBackendServiceLocalityLbPolicies | cdktn.IResolvable): any;
export declare class ComputeBackendServiceLocalityLbPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeBackendServiceLocalityLbPolicies | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeBackendServiceLocalityLbPolicies | cdktn.IResolvable | undefined);
    private _customPolicy;
    get customPolicy(): ComputeBackendServiceLocalityLbPoliciesCustomPolicyOutputReference;
    putCustomPolicy(value: ComputeBackendServiceLocalityLbPoliciesCustomPolicy): void;
    resetCustomPolicy(): void;
    get customPolicyInput(): ComputeBackendServiceLocalityLbPoliciesCustomPolicy | undefined;
    private _policy;
    get policy(): ComputeBackendServiceLocalityLbPoliciesPolicyOutputReference;
    putPolicy(value: ComputeBackendServiceLocalityLbPoliciesPolicy): void;
    resetPolicy(): void;
    get policyInput(): ComputeBackendServiceLocalityLbPoliciesPolicy | undefined;
}
export declare class ComputeBackendServiceLocalityLbPoliciesList extends cdktn.ComplexList {
    internalValue?: ComputeBackendServiceLocalityLbPolicies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeBackendServiceLocalityLbPoliciesOutputReference;
}
export interface ComputeBackendServiceLogConfigRequestHeaders {
    /**
    * The header name to match on for logging.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#header_name ComputeBackendService#header_name}
    */
    readonly headerName: string;
}
export declare function computeBackendServiceLogConfigRequestHeadersToTerraform(struct?: ComputeBackendServiceLogConfigRequestHeaders | cdktn.IResolvable): any;
export declare function computeBackendServiceLogConfigRequestHeadersToHclTerraform(struct?: ComputeBackendServiceLogConfigRequestHeaders | cdktn.IResolvable): any;
export declare class ComputeBackendServiceLogConfigRequestHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeBackendServiceLogConfigRequestHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeBackendServiceLogConfigRequestHeaders | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    get headerNameInput(): string | undefined;
}
export declare class ComputeBackendServiceLogConfigRequestHeadersList extends cdktn.ComplexList {
    internalValue?: ComputeBackendServiceLogConfigRequestHeaders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeBackendServiceLogConfigRequestHeadersOutputReference;
}
export interface ComputeBackendServiceLogConfigResponseHeaders {
    /**
    * The header name to match on for logging.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#header_name ComputeBackendService#header_name}
    */
    readonly headerName: string;
}
export declare function computeBackendServiceLogConfigResponseHeadersToTerraform(struct?: ComputeBackendServiceLogConfigResponseHeaders | cdktn.IResolvable): any;
export declare function computeBackendServiceLogConfigResponseHeadersToHclTerraform(struct?: ComputeBackendServiceLogConfigResponseHeaders | cdktn.IResolvable): any;
export declare class ComputeBackendServiceLogConfigResponseHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeBackendServiceLogConfigResponseHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeBackendServiceLogConfigResponseHeaders | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    get headerNameInput(): string | undefined;
}
export declare class ComputeBackendServiceLogConfigResponseHeadersList extends cdktn.ComplexList {
    internalValue?: ComputeBackendServiceLogConfigResponseHeaders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeBackendServiceLogConfigResponseHeadersOutputReference;
}
export interface ComputeBackendServiceLogConfig {
    /**
    * Whether to enable logging for the load balancer traffic served by this backend service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#enable ComputeBackendService#enable}
    */
    readonly enable?: boolean | cdktn.IResolvable;
    /**
    * This field can only be specified if logging is enabled for this backend service and "logConfig.optionalMode"
    * was set to CUSTOM. Contains a list of optional fields you want to include in the logs.
    * For example: serverInstance, serverGkeDetails.cluster, serverGkeDetails.pod.podNamespace
    * For example: orca_load_report, tls.protocol
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#optional_fields ComputeBackendService#optional_fields}
    */
    readonly optionalFields?: string[];
    /**
    * Specifies the optional logging mode for the load balancer traffic.
    * Supported values: INCLUDE_ALL_OPTIONAL, EXCLUDE_ALL_OPTIONAL, CUSTOM. Possible values: ["INCLUDE_ALL_OPTIONAL", "EXCLUDE_ALL_OPTIONAL", "CUSTOM"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#optional_mode ComputeBackendService#optional_mode}
    */
    readonly optionalMode?: string;
    /**
    * This field can only be specified if logging is enabled for this backend service. The value of
    * the field must be in [0, 1]. This configures the sampling rate of requests to the load balancer
    * where 1.0 means all logged requests are reported and 0.0 means no logged requests are reported.
    * The default value is 1.0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#sample_rate ComputeBackendService#sample_rate}
    */
    readonly sampleRate?: number;
    /**
    * request_headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#request_headers ComputeBackendService#request_headers}
    */
    readonly requestHeaders?: ComputeBackendServiceLogConfigRequestHeaders[] | cdktn.IResolvable;
    /**
    * response_headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#response_headers ComputeBackendService#response_headers}
    */
    readonly responseHeaders?: ComputeBackendServiceLogConfigResponseHeaders[] | cdktn.IResolvable;
}
export declare function computeBackendServiceLogConfigToTerraform(struct?: ComputeBackendServiceLogConfigOutputReference | ComputeBackendServiceLogConfig): any;
export declare function computeBackendServiceLogConfigToHclTerraform(struct?: ComputeBackendServiceLogConfigOutputReference | ComputeBackendServiceLogConfig): any;
export declare class ComputeBackendServiceLogConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeBackendServiceLogConfig | undefined;
    set internalValue(value: ComputeBackendServiceLogConfig | undefined);
    private _enable?;
    get enable(): boolean | cdktn.IResolvable;
    set enable(value: boolean | cdktn.IResolvable);
    resetEnable(): void;
    get enableInput(): boolean | cdktn.IResolvable | undefined;
    private _optionalFields?;
    get optionalFields(): string[];
    set optionalFields(value: string[]);
    resetOptionalFields(): void;
    get optionalFieldsInput(): string[] | undefined;
    private _optionalMode?;
    get optionalMode(): string;
    set optionalMode(value: string);
    resetOptionalMode(): void;
    get optionalModeInput(): string | undefined;
    private _sampleRate?;
    get sampleRate(): number;
    set sampleRate(value: number);
    resetSampleRate(): void;
    get sampleRateInput(): number | undefined;
    private _requestHeaders;
    get requestHeaders(): ComputeBackendServiceLogConfigRequestHeadersList;
    putRequestHeaders(value: ComputeBackendServiceLogConfigRequestHeaders[] | cdktn.IResolvable): void;
    resetRequestHeaders(): void;
    get requestHeadersInput(): cdktn.IResolvable | ComputeBackendServiceLogConfigRequestHeaders[] | undefined;
    private _responseHeaders;
    get responseHeaders(): ComputeBackendServiceLogConfigResponseHeadersList;
    putResponseHeaders(value: ComputeBackendServiceLogConfigResponseHeaders[] | cdktn.IResolvable): void;
    resetResponseHeaders(): void;
    get responseHeadersInput(): cdktn.IResolvable | ComputeBackendServiceLogConfigResponseHeaders[] | undefined;
}
export interface ComputeBackendServiceMaxStreamDuration {
    /**
    * Span of time that's a fraction of a second at nanosecond resolution.
    * Durations less than one second are represented with a 0 seconds field and a positive nanos field.
    * Must be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#nanos ComputeBackendService#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second. Must be from 0 to 315,576,000,000 inclusive. (int64 format)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#seconds ComputeBackendService#seconds}
    */
    readonly seconds: string;
}
export declare function computeBackendServiceMaxStreamDurationToTerraform(struct?: ComputeBackendServiceMaxStreamDurationOutputReference | ComputeBackendServiceMaxStreamDuration): any;
export declare function computeBackendServiceMaxStreamDurationToHclTerraform(struct?: ComputeBackendServiceMaxStreamDurationOutputReference | ComputeBackendServiceMaxStreamDuration): any;
export declare class ComputeBackendServiceMaxStreamDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeBackendServiceMaxStreamDuration | undefined;
    set internalValue(value: ComputeBackendServiceMaxStreamDuration | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): string;
    set seconds(value: string);
    get secondsInput(): string | undefined;
}
export interface ComputeBackendServiceOutlierDetectionBaseEjectionTime {
    /**
    * Span of time that's a fraction of a second at nanosecond resolution. Durations
    * less than one second are represented with a 0 'seconds' field and a positive
    * 'nanos' field. Must be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#nanos ComputeBackendService#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second. Must be from 0 to 315,576,000,000
    * inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#seconds ComputeBackendService#seconds}
    */
    readonly seconds: number;
}
export declare function computeBackendServiceOutlierDetectionBaseEjectionTimeToTerraform(struct?: ComputeBackendServiceOutlierDetectionBaseEjectionTimeOutputReference | ComputeBackendServiceOutlierDetectionBaseEjectionTime): any;
export declare function computeBackendServiceOutlierDetectionBaseEjectionTimeToHclTerraform(struct?: ComputeBackendServiceOutlierDetectionBaseEjectionTimeOutputReference | ComputeBackendServiceOutlierDetectionBaseEjectionTime): any;
export declare class ComputeBackendServiceOutlierDetectionBaseEjectionTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeBackendServiceOutlierDetectionBaseEjectionTime | undefined;
    set internalValue(value: ComputeBackendServiceOutlierDetectionBaseEjectionTime | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): number;
    set seconds(value: number);
    get secondsInput(): number | undefined;
}
export interface ComputeBackendServiceOutlierDetectionInterval {
    /**
    * Span of time that's a fraction of a second at nanosecond resolution. Durations
    * less than one second are represented with a 0 'seconds' field and a positive
    * 'nanos' field. Must be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#nanos ComputeBackendService#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second. Must be from 0 to 315,576,000,000
    * inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#seconds ComputeBackendService#seconds}
    */
    readonly seconds: number;
}
export declare function computeBackendServiceOutlierDetectionIntervalToTerraform(struct?: ComputeBackendServiceOutlierDetectionIntervalOutputReference | ComputeBackendServiceOutlierDetectionInterval): any;
export declare function computeBackendServiceOutlierDetectionIntervalToHclTerraform(struct?: ComputeBackendServiceOutlierDetectionIntervalOutputReference | ComputeBackendServiceOutlierDetectionInterval): any;
export declare class ComputeBackendServiceOutlierDetectionIntervalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeBackendServiceOutlierDetectionInterval | undefined;
    set internalValue(value: ComputeBackendServiceOutlierDetectionInterval | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): number;
    set seconds(value: number);
    get secondsInput(): number | undefined;
}
export interface ComputeBackendServiceOutlierDetection {
    /**
    * Number of errors before a host is ejected from the connection pool. When the
    * backend host is accessed over HTTP, a 5xx return code qualifies as an error.
    * Defaults to 5.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#consecutive_errors ComputeBackendService#consecutive_errors}
    */
    readonly consecutiveErrors?: number;
    /**
    * The number of consecutive gateway failures (502, 503, 504 status or connection
    * errors that are mapped to one of those status codes) before a consecutive
    * gateway failure ejection occurs. Defaults to 5.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#consecutive_gateway_failure ComputeBackendService#consecutive_gateway_failure}
    */
    readonly consecutiveGatewayFailure?: number;
    /**
    * The percentage chance that a host will be actually ejected when an outlier
    * status is detected through consecutive 5xx. This setting can be used to disable
    * ejection or to ramp it up slowly. Defaults to 100.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#enforcing_consecutive_errors ComputeBackendService#enforcing_consecutive_errors}
    */
    readonly enforcingConsecutiveErrors?: number;
    /**
    * The percentage chance that a host will be actually ejected when an outlier
    * status is detected through consecutive gateway failures. This setting can be
    * used to disable ejection or to ramp it up slowly. Defaults to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#enforcing_consecutive_gateway_failure ComputeBackendService#enforcing_consecutive_gateway_failure}
    */
    readonly enforcingConsecutiveGatewayFailure?: number;
    /**
    * The percentage chance that a host will be actually ejected when an outlier
    * status is detected through success rate statistics. This setting can be used to
    * disable ejection or to ramp it up slowly. Defaults to 100.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#enforcing_success_rate ComputeBackendService#enforcing_success_rate}
    */
    readonly enforcingSuccessRate?: number;
    /**
    * Maximum percentage of hosts in the load balancing pool for the backend service
    * that can be ejected. Defaults to 10%.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#max_ejection_percent ComputeBackendService#max_ejection_percent}
    */
    readonly maxEjectionPercent?: number;
    /**
    * The number of hosts in a cluster that must have enough request volume to detect
    * success rate outliers. If the number of hosts is less than this setting, outlier
    * detection via success rate statistics is not performed for any host in the
    * cluster. Defaults to 5.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#success_rate_minimum_hosts ComputeBackendService#success_rate_minimum_hosts}
    */
    readonly successRateMinimumHosts?: number;
    /**
    * The minimum number of total requests that must be collected in one interval (as
    * defined by the interval duration above) to include this host in success rate
    * based outlier detection. If the volume is lower than this setting, outlier
    * detection via success rate statistics is not performed for that host. Defaults
    * to 100.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#success_rate_request_volume ComputeBackendService#success_rate_request_volume}
    */
    readonly successRateRequestVolume?: number;
    /**
    * This factor is used to determine the ejection threshold for success rate outlier
    * ejection. The ejection threshold is the difference between the mean success
    * rate, and the product of this factor and the standard deviation of the mean
    * success rate: mean - (stdev * success_rate_stdev_factor). This factor is divided
    * by a thousand to get a double. That is, if the desired factor is 1.9, the
    * runtime value should be 1900. Defaults to 1900.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#success_rate_stdev_factor ComputeBackendService#success_rate_stdev_factor}
    */
    readonly successRateStdevFactor?: number;
    /**
    * base_ejection_time block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#base_ejection_time ComputeBackendService#base_ejection_time}
    */
    readonly baseEjectionTime?: ComputeBackendServiceOutlierDetectionBaseEjectionTime;
    /**
    * interval block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#interval ComputeBackendService#interval}
    */
    readonly interval?: ComputeBackendServiceOutlierDetectionInterval;
}
export declare function computeBackendServiceOutlierDetectionToTerraform(struct?: ComputeBackendServiceOutlierDetectionOutputReference | ComputeBackendServiceOutlierDetection): any;
export declare function computeBackendServiceOutlierDetectionToHclTerraform(struct?: ComputeBackendServiceOutlierDetectionOutputReference | ComputeBackendServiceOutlierDetection): any;
export declare class ComputeBackendServiceOutlierDetectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeBackendServiceOutlierDetection | undefined;
    set internalValue(value: ComputeBackendServiceOutlierDetection | undefined);
    private _consecutiveErrors?;
    get consecutiveErrors(): number;
    set consecutiveErrors(value: number);
    resetConsecutiveErrors(): void;
    get consecutiveErrorsInput(): number | undefined;
    private _consecutiveGatewayFailure?;
    get consecutiveGatewayFailure(): number;
    set consecutiveGatewayFailure(value: number);
    resetConsecutiveGatewayFailure(): void;
    get consecutiveGatewayFailureInput(): number | undefined;
    private _enforcingConsecutiveErrors?;
    get enforcingConsecutiveErrors(): number;
    set enforcingConsecutiveErrors(value: number);
    resetEnforcingConsecutiveErrors(): void;
    get enforcingConsecutiveErrorsInput(): number | undefined;
    private _enforcingConsecutiveGatewayFailure?;
    get enforcingConsecutiveGatewayFailure(): number;
    set enforcingConsecutiveGatewayFailure(value: number);
    resetEnforcingConsecutiveGatewayFailure(): void;
    get enforcingConsecutiveGatewayFailureInput(): number | undefined;
    private _enforcingSuccessRate?;
    get enforcingSuccessRate(): number;
    set enforcingSuccessRate(value: number);
    resetEnforcingSuccessRate(): void;
    get enforcingSuccessRateInput(): number | undefined;
    private _maxEjectionPercent?;
    get maxEjectionPercent(): number;
    set maxEjectionPercent(value: number);
    resetMaxEjectionPercent(): void;
    get maxEjectionPercentInput(): number | undefined;
    private _successRateMinimumHosts?;
    get successRateMinimumHosts(): number;
    set successRateMinimumHosts(value: number);
    resetSuccessRateMinimumHosts(): void;
    get successRateMinimumHostsInput(): number | undefined;
    private _successRateRequestVolume?;
    get successRateRequestVolume(): number;
    set successRateRequestVolume(value: number);
    resetSuccessRateRequestVolume(): void;
    get successRateRequestVolumeInput(): number | undefined;
    private _successRateStdevFactor?;
    get successRateStdevFactor(): number;
    set successRateStdevFactor(value: number);
    resetSuccessRateStdevFactor(): void;
    get successRateStdevFactorInput(): number | undefined;
    private _baseEjectionTime;
    get baseEjectionTime(): ComputeBackendServiceOutlierDetectionBaseEjectionTimeOutputReference;
    putBaseEjectionTime(value: ComputeBackendServiceOutlierDetectionBaseEjectionTime): void;
    resetBaseEjectionTime(): void;
    get baseEjectionTimeInput(): ComputeBackendServiceOutlierDetectionBaseEjectionTime | undefined;
    private _interval;
    get interval(): ComputeBackendServiceOutlierDetectionIntervalOutputReference;
    putInterval(value: ComputeBackendServiceOutlierDetectionInterval): void;
    resetInterval(): void;
    get intervalInput(): ComputeBackendServiceOutlierDetectionInterval | undefined;
}
export interface ComputeBackendServiceParams {
    /**
    * Resource manager tags to be bound to the backend service. Tag keys and values have the
    * same definition as resource manager tags. Keys must be in the format tagKeys/{tag_key_id},
    * and values are in the format tagValues/456.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#resource_manager_tags ComputeBackendService#resource_manager_tags}
    */
    readonly resourceManagerTags?: {
        [key: string]: string;
    };
}
export declare function computeBackendServiceParamsToTerraform(struct?: ComputeBackendServiceParamsOutputReference | ComputeBackendServiceParams): any;
export declare function computeBackendServiceParamsToHclTerraform(struct?: ComputeBackendServiceParamsOutputReference | ComputeBackendServiceParams): any;
export declare class ComputeBackendServiceParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeBackendServiceParams | undefined;
    set internalValue(value: ComputeBackendServiceParams | undefined);
    private _resourceManagerTags?;
    get resourceManagerTags(): {
        [key: string]: string;
    };
    set resourceManagerTags(value: {
        [key: string]: string;
    });
    resetResourceManagerTags(): void;
    get resourceManagerTagsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ComputeBackendServiceSecuritySettingsAwsV4Authentication {
    /**
    * The access key used for s3 bucket authentication.
    * Required for updating or creating a backend that uses AWS v4 signature authentication, but will not be returned as part of the configuration when queried with a REST API GET request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#access_key ComputeBackendService#access_key}
    */
    readonly accessKey?: string;
    /**
    * The identifier of an access key used for s3 bucket authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#access_key_id ComputeBackendService#access_key_id}
    */
    readonly accessKeyId?: string;
    /**
    * The optional version identifier for the access key. You can use this to keep track of different iterations of your access key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#access_key_version ComputeBackendService#access_key_version}
    */
    readonly accessKeyVersion?: string;
    /**
    * The name of the cloud region of your origin. This is a free-form field with the name of the region your cloud uses to host your origin.
    * For example, "us-east-1" for AWS or "us-ashburn-1" for OCI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#origin_region ComputeBackendService#origin_region}
    */
    readonly originRegion?: string;
}
export declare function computeBackendServiceSecuritySettingsAwsV4AuthenticationToTerraform(struct?: ComputeBackendServiceSecuritySettingsAwsV4AuthenticationOutputReference | ComputeBackendServiceSecuritySettingsAwsV4Authentication): any;
export declare function computeBackendServiceSecuritySettingsAwsV4AuthenticationToHclTerraform(struct?: ComputeBackendServiceSecuritySettingsAwsV4AuthenticationOutputReference | ComputeBackendServiceSecuritySettingsAwsV4Authentication): any;
export declare class ComputeBackendServiceSecuritySettingsAwsV4AuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeBackendServiceSecuritySettingsAwsV4Authentication | undefined;
    set internalValue(value: ComputeBackendServiceSecuritySettingsAwsV4Authentication | undefined);
    private _accessKey?;
    get accessKey(): string;
    set accessKey(value: string);
    resetAccessKey(): void;
    get accessKeyInput(): string | undefined;
    private _accessKeyId?;
    get accessKeyId(): string;
    set accessKeyId(value: string);
    resetAccessKeyId(): void;
    get accessKeyIdInput(): string | undefined;
    private _accessKeyVersion?;
    get accessKeyVersion(): string;
    set accessKeyVersion(value: string);
    resetAccessKeyVersion(): void;
    get accessKeyVersionInput(): string | undefined;
    private _originRegion?;
    get originRegion(): string;
    set originRegion(value: string);
    resetOriginRegion(): void;
    get originRegionInput(): string | undefined;
}
export interface ComputeBackendServiceSecuritySettings {
    /**
    * ClientTlsPolicy is a resource that specifies how a client should authenticate
    * connections to backends of a service. This resource itself does not affect
    * configuration unless it is attached to a backend service resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#client_tls_policy ComputeBackendService#client_tls_policy}
    */
    readonly clientTlsPolicy?: string;
    /**
    * A list of alternate names to verify the subject identity in the certificate.
    * If specified, the client will verify that the server certificate's subject
    * alt name matches one of the specified values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#subject_alt_names ComputeBackendService#subject_alt_names}
    */
    readonly subjectAltNames?: string[];
    /**
    * aws_v4_authentication block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#aws_v4_authentication ComputeBackendService#aws_v4_authentication}
    */
    readonly awsV4Authentication?: ComputeBackendServiceSecuritySettingsAwsV4Authentication;
}
export declare function computeBackendServiceSecuritySettingsToTerraform(struct?: ComputeBackendServiceSecuritySettingsOutputReference | ComputeBackendServiceSecuritySettings): any;
export declare function computeBackendServiceSecuritySettingsToHclTerraform(struct?: ComputeBackendServiceSecuritySettingsOutputReference | ComputeBackendServiceSecuritySettings): any;
export declare class ComputeBackendServiceSecuritySettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeBackendServiceSecuritySettings | undefined;
    set internalValue(value: ComputeBackendServiceSecuritySettings | undefined);
    private _clientTlsPolicy?;
    get clientTlsPolicy(): string;
    set clientTlsPolicy(value: string);
    resetClientTlsPolicy(): void;
    get clientTlsPolicyInput(): string | undefined;
    private _subjectAltNames?;
    get subjectAltNames(): string[];
    set subjectAltNames(value: string[]);
    resetSubjectAltNames(): void;
    get subjectAltNamesInput(): string[] | undefined;
    private _awsV4Authentication;
    get awsV4Authentication(): ComputeBackendServiceSecuritySettingsAwsV4AuthenticationOutputReference;
    putAwsV4Authentication(value: ComputeBackendServiceSecuritySettingsAwsV4Authentication): void;
    resetAwsV4Authentication(): void;
    get awsV4AuthenticationInput(): ComputeBackendServiceSecuritySettingsAwsV4Authentication | undefined;
}
export interface ComputeBackendServiceStrongSessionAffinityCookieTtl {
    /**
    * Span of time that's a fraction of a second at nanosecond
    * resolution. Durations less than one second are represented
    * with a 0 seconds field and a positive nanos field. Must
    * be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#nanos ComputeBackendService#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second.
    * Must be from 0 to 315,576,000,000 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#seconds ComputeBackendService#seconds}
    */
    readonly seconds: number;
}
export declare function computeBackendServiceStrongSessionAffinityCookieTtlToTerraform(struct?: ComputeBackendServiceStrongSessionAffinityCookieTtlOutputReference | ComputeBackendServiceStrongSessionAffinityCookieTtl): any;
export declare function computeBackendServiceStrongSessionAffinityCookieTtlToHclTerraform(struct?: ComputeBackendServiceStrongSessionAffinityCookieTtlOutputReference | ComputeBackendServiceStrongSessionAffinityCookieTtl): any;
export declare class ComputeBackendServiceStrongSessionAffinityCookieTtlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeBackendServiceStrongSessionAffinityCookieTtl | undefined;
    set internalValue(value: ComputeBackendServiceStrongSessionAffinityCookieTtl | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): number;
    set seconds(value: number);
    get secondsInput(): number | undefined;
}
export interface ComputeBackendServiceStrongSessionAffinityCookie {
    /**
    * Name of the cookie.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#name ComputeBackendService#name}
    */
    readonly name?: string;
    /**
    * Path to set for the cookie.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#path ComputeBackendService#path}
    */
    readonly path?: string;
    /**
    * ttl block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#ttl ComputeBackendService#ttl}
    */
    readonly ttl?: ComputeBackendServiceStrongSessionAffinityCookieTtl;
}
export declare function computeBackendServiceStrongSessionAffinityCookieToTerraform(struct?: ComputeBackendServiceStrongSessionAffinityCookieOutputReference | ComputeBackendServiceStrongSessionAffinityCookie): any;
export declare function computeBackendServiceStrongSessionAffinityCookieToHclTerraform(struct?: ComputeBackendServiceStrongSessionAffinityCookieOutputReference | ComputeBackendServiceStrongSessionAffinityCookie): any;
export declare class ComputeBackendServiceStrongSessionAffinityCookieOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeBackendServiceStrongSessionAffinityCookie | undefined;
    set internalValue(value: ComputeBackendServiceStrongSessionAffinityCookie | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _ttl;
    get ttl(): ComputeBackendServiceStrongSessionAffinityCookieTtlOutputReference;
    putTtl(value: ComputeBackendServiceStrongSessionAffinityCookieTtl): void;
    resetTtl(): void;
    get ttlInput(): ComputeBackendServiceStrongSessionAffinityCookieTtl | undefined;
}
export interface ComputeBackendServiceTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#create ComputeBackendService#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#delete ComputeBackendService#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#update ComputeBackendService#update}
    */
    readonly update?: string;
}
export declare function computeBackendServiceTimeoutsToTerraform(struct?: ComputeBackendServiceTimeouts | cdktn.IResolvable): any;
export declare function computeBackendServiceTimeoutsToHclTerraform(struct?: ComputeBackendServiceTimeouts | cdktn.IResolvable): any;
export declare class ComputeBackendServiceTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeBackendServiceTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeBackendServiceTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface ComputeBackendServiceTlsSettingsSubjectAltNames {
    /**
    * The SAN specified as a DNS Name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#dns_name ComputeBackendService#dns_name}
    */
    readonly dnsName?: string;
    /**
    * The SAN specified as a URI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#uniform_resource_identifier ComputeBackendService#uniform_resource_identifier}
    */
    readonly uniformResourceIdentifier?: string;
}
export declare function computeBackendServiceTlsSettingsSubjectAltNamesToTerraform(struct?: ComputeBackendServiceTlsSettingsSubjectAltNames | cdktn.IResolvable): any;
export declare function computeBackendServiceTlsSettingsSubjectAltNamesToHclTerraform(struct?: ComputeBackendServiceTlsSettingsSubjectAltNames | cdktn.IResolvable): any;
export declare class ComputeBackendServiceTlsSettingsSubjectAltNamesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeBackendServiceTlsSettingsSubjectAltNames | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeBackendServiceTlsSettingsSubjectAltNames | cdktn.IResolvable | undefined);
    private _dnsName?;
    get dnsName(): string;
    set dnsName(value: string);
    resetDnsName(): void;
    get dnsNameInput(): string | undefined;
    private _uniformResourceIdentifier?;
    get uniformResourceIdentifier(): string;
    set uniformResourceIdentifier(value: string);
    resetUniformResourceIdentifier(): void;
    get uniformResourceIdentifierInput(): string | undefined;
}
export declare class ComputeBackendServiceTlsSettingsSubjectAltNamesList extends cdktn.ComplexList {
    internalValue?: ComputeBackendServiceTlsSettingsSubjectAltNames[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeBackendServiceTlsSettingsSubjectAltNamesOutputReference;
}
export interface ComputeBackendServiceTlsSettings {
    /**
    * Reference to the BackendAuthenticationConfig resource from the networksecurity.googleapis.com namespace.
    * Can be used in authenticating TLS connections to the backend, as specified by the authenticationMode field.
    * Can only be specified if authenticationMode is not NONE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#authentication_config ComputeBackendService#authentication_config}
    */
    readonly authenticationConfig?: string;
    /**
    * The fully-specified SPIFFE ID without the spiffe:// scheme. Must be in the format //<trust_domain>/ns/<namespace>/sa/<subject>.
    * The load balancer uses certificates and roots of trust provisioned by the Managed Workload Identity system for this identity.
    * The Trust Domain within the identity must refer to a valid Workload Identity Pool, from which the TrustConfig and CertificateIssuanceConfig are inherited.
    * If set, you cannot configure sni, subjectAltNames, or authenticationConfig manually.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#identity ComputeBackendService#identity}
    */
    readonly identity?: string;
    /**
    * Server Name Indication - see RFC3546 section 3.1. If set, the load balancer sends this string as the SNI hostname in the
    * TLS connection to the backend, and requires that this string match a Subject Alternative Name (SAN) in the backend's
    * server certificate. With a Regional Internet NEG backend, if the SNI is specified here, the load balancer uses it
    * regardless of whether the Regional Internet NEG is specified with FQDN or IP address and port.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#sni ComputeBackendService#sni}
    */
    readonly sni?: string;
    /**
    * subject_alt_names block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#subject_alt_names ComputeBackendService#subject_alt_names}
    */
    readonly subjectAltNames?: ComputeBackendServiceTlsSettingsSubjectAltNames[] | cdktn.IResolvable;
}
export declare function computeBackendServiceTlsSettingsToTerraform(struct?: ComputeBackendServiceTlsSettingsOutputReference | ComputeBackendServiceTlsSettings): any;
export declare function computeBackendServiceTlsSettingsToHclTerraform(struct?: ComputeBackendServiceTlsSettingsOutputReference | ComputeBackendServiceTlsSettings): any;
export declare class ComputeBackendServiceTlsSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeBackendServiceTlsSettings | undefined;
    set internalValue(value: ComputeBackendServiceTlsSettings | undefined);
    private _authenticationConfig?;
    get authenticationConfig(): string;
    set authenticationConfig(value: string);
    resetAuthenticationConfig(): void;
    get authenticationConfigInput(): string | undefined;
    private _identity?;
    get identity(): string;
    set identity(value: string);
    resetIdentity(): void;
    get identityInput(): string | undefined;
    private _sni?;
    get sni(): string;
    set sni(value: string);
    resetSni(): void;
    get sniInput(): string | undefined;
    private _subjectAltNames;
    get subjectAltNames(): ComputeBackendServiceTlsSettingsSubjectAltNamesList;
    putSubjectAltNames(value: ComputeBackendServiceTlsSettingsSubjectAltNames[] | cdktn.IResolvable): void;
    resetSubjectAltNames(): void;
    get subjectAltNamesInput(): cdktn.IResolvable | ComputeBackendServiceTlsSettingsSubjectAltNames[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service google_compute_backend_service}
*/
export declare class ComputeBackendService extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_backend_service";
    /**
    * Generates CDKTN code for importing a ComputeBackendService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeBackendService to import
    * @param importFromId The id of the existing ComputeBackendService that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeBackendService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_backend_service google_compute_backend_service} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeBackendServiceConfig
    */
    constructor(scope: Construct, id: string, config: ComputeBackendServiceConfig);
    private _affinityCookieTtlSec?;
    get affinityCookieTtlSec(): number;
    set affinityCookieTtlSec(value: number);
    resetAffinityCookieTtlSec(): void;
    get affinityCookieTtlSecInput(): number | undefined;
    private _compressionMode?;
    get compressionMode(): string;
    set compressionMode(value: string);
    resetCompressionMode(): void;
    get compressionModeInput(): string | undefined;
    private _connectionDrainingTimeoutSec?;
    get connectionDrainingTimeoutSec(): number;
    set connectionDrainingTimeoutSec(value: number);
    resetConnectionDrainingTimeoutSec(): void;
    get connectionDrainingTimeoutSecInput(): number | undefined;
    get creationTimestamp(): string;
    private _customRequestHeaders?;
    get customRequestHeaders(): string[];
    set customRequestHeaders(value: string[]);
    resetCustomRequestHeaders(): void;
    get customRequestHeadersInput(): string[] | undefined;
    private _customResponseHeaders?;
    get customResponseHeaders(): string[];
    set customResponseHeaders(value: string[]);
    resetCustomResponseHeaders(): void;
    get customResponseHeadersInput(): string[] | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _edgeSecurityPolicy?;
    get edgeSecurityPolicy(): string;
    set edgeSecurityPolicy(value: string);
    resetEdgeSecurityPolicy(): void;
    get edgeSecurityPolicyInput(): string | undefined;
    private _enableCdn?;
    get enableCdn(): boolean | cdktn.IResolvable;
    set enableCdn(value: boolean | cdktn.IResolvable);
    resetEnableCdn(): void;
    get enableCdnInput(): boolean | cdktn.IResolvable | undefined;
    private _externalManagedMigrationState?;
    get externalManagedMigrationState(): string;
    set externalManagedMigrationState(value: string);
    resetExternalManagedMigrationState(): void;
    get externalManagedMigrationStateInput(): string | undefined;
    private _externalManagedMigrationTestingPercentage?;
    get externalManagedMigrationTestingPercentage(): number;
    set externalManagedMigrationTestingPercentage(value: number);
    resetExternalManagedMigrationTestingPercentage(): void;
    get externalManagedMigrationTestingPercentageInput(): number | undefined;
    get fingerprint(): string;
    get generatedId(): number;
    private _healthChecks?;
    get healthChecks(): string[];
    set healthChecks(value: string[]);
    resetHealthChecks(): void;
    get healthChecksInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipAddressSelectionPolicy?;
    get ipAddressSelectionPolicy(): string;
    set ipAddressSelectionPolicy(value: string);
    resetIpAddressSelectionPolicy(): void;
    get ipAddressSelectionPolicyInput(): string | undefined;
    private _loadBalancingScheme?;
    get loadBalancingScheme(): string;
    set loadBalancingScheme(value: string);
    resetLoadBalancingScheme(): void;
    get loadBalancingSchemeInput(): string | undefined;
    private _localityLbPolicy?;
    get localityLbPolicy(): string;
    set localityLbPolicy(value: string);
    resetLocalityLbPolicy(): void;
    get localityLbPolicyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _portName?;
    get portName(): string;
    set portName(value: string);
    resetPortName(): void;
    get portNameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    resetProtocol(): void;
    get protocolInput(): string | undefined;
    private _securityPolicy?;
    get securityPolicy(): string;
    set securityPolicy(value: string);
    resetSecurityPolicy(): void;
    get securityPolicyInput(): string | undefined;
    get selfLink(): string;
    private _serviceLbPolicy?;
    get serviceLbPolicy(): string;
    set serviceLbPolicy(value: string);
    resetServiceLbPolicy(): void;
    get serviceLbPolicyInput(): string | undefined;
    private _sessionAffinity?;
    get sessionAffinity(): string;
    set sessionAffinity(value: string);
    resetSessionAffinity(): void;
    get sessionAffinityInput(): string | undefined;
    private _timeoutSec?;
    get timeoutSec(): number;
    set timeoutSec(value: number);
    resetTimeoutSec(): void;
    get timeoutSecInput(): number | undefined;
    private _backend;
    get backend(): ComputeBackendServiceBackendList;
    putBackend(value: ComputeBackendServiceBackend[] | cdktn.IResolvable): void;
    resetBackend(): void;
    get backendInput(): cdktn.IResolvable | ComputeBackendServiceBackend[] | undefined;
    private _cdnPolicy;
    get cdnPolicy(): ComputeBackendServiceCdnPolicyOutputReference;
    putCdnPolicy(value: ComputeBackendServiceCdnPolicy): void;
    resetCdnPolicy(): void;
    get cdnPolicyInput(): ComputeBackendServiceCdnPolicy | undefined;
    private _circuitBreakers;
    get circuitBreakers(): ComputeBackendServiceCircuitBreakersOutputReference;
    putCircuitBreakers(value: ComputeBackendServiceCircuitBreakers): void;
    resetCircuitBreakers(): void;
    get circuitBreakersInput(): ComputeBackendServiceCircuitBreakers | undefined;
    private _consistentHash;
    get consistentHash(): ComputeBackendServiceConsistentHashOutputReference;
    putConsistentHash(value: ComputeBackendServiceConsistentHash): void;
    resetConsistentHash(): void;
    get consistentHashInput(): ComputeBackendServiceConsistentHash | undefined;
    private _customMetrics;
    get customMetrics(): ComputeBackendServiceCustomMetricsList;
    putCustomMetrics(value: ComputeBackendServiceCustomMetrics[] | cdktn.IResolvable): void;
    resetCustomMetrics(): void;
    get customMetricsInput(): cdktn.IResolvable | ComputeBackendServiceCustomMetrics[] | undefined;
    private _iap;
    get iap(): ComputeBackendServiceIapOutputReference;
    putIap(value: ComputeBackendServiceIap): void;
    resetIap(): void;
    get iapInput(): ComputeBackendServiceIap | undefined;
    private _localityLbPolicies;
    get localityLbPolicies(): ComputeBackendServiceLocalityLbPoliciesList;
    putLocalityLbPolicies(value: ComputeBackendServiceLocalityLbPolicies[] | cdktn.IResolvable): void;
    resetLocalityLbPolicies(): void;
    get localityLbPoliciesInput(): cdktn.IResolvable | ComputeBackendServiceLocalityLbPolicies[] | undefined;
    private _logConfig;
    get logConfig(): ComputeBackendServiceLogConfigOutputReference;
    putLogConfig(value: ComputeBackendServiceLogConfig): void;
    resetLogConfig(): void;
    get logConfigInput(): ComputeBackendServiceLogConfig | undefined;
    private _maxStreamDuration;
    get maxStreamDuration(): ComputeBackendServiceMaxStreamDurationOutputReference;
    putMaxStreamDuration(value: ComputeBackendServiceMaxStreamDuration): void;
    resetMaxStreamDuration(): void;
    get maxStreamDurationInput(): ComputeBackendServiceMaxStreamDuration | undefined;
    private _outlierDetection;
    get outlierDetection(): ComputeBackendServiceOutlierDetectionOutputReference;
    putOutlierDetection(value: ComputeBackendServiceOutlierDetection): void;
    resetOutlierDetection(): void;
    get outlierDetectionInput(): ComputeBackendServiceOutlierDetection | undefined;
    private _params;
    get params(): ComputeBackendServiceParamsOutputReference;
    putParams(value: ComputeBackendServiceParams): void;
    resetParams(): void;
    get paramsInput(): ComputeBackendServiceParams | undefined;
    private _securitySettings;
    get securitySettings(): ComputeBackendServiceSecuritySettingsOutputReference;
    putSecuritySettings(value: ComputeBackendServiceSecuritySettings): void;
    resetSecuritySettings(): void;
    get securitySettingsInput(): ComputeBackendServiceSecuritySettings | undefined;
    private _strongSessionAffinityCookie;
    get strongSessionAffinityCookie(): ComputeBackendServiceStrongSessionAffinityCookieOutputReference;
    putStrongSessionAffinityCookie(value: ComputeBackendServiceStrongSessionAffinityCookie): void;
    resetStrongSessionAffinityCookie(): void;
    get strongSessionAffinityCookieInput(): ComputeBackendServiceStrongSessionAffinityCookie | undefined;
    private _timeouts;
    get timeouts(): ComputeBackendServiceTimeoutsOutputReference;
    putTimeouts(value: ComputeBackendServiceTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeBackendServiceTimeouts | undefined;
    private _tlsSettings;
    get tlsSettings(): ComputeBackendServiceTlsSettingsOutputReference;
    putTlsSettings(value: ComputeBackendServiceTlsSettings): void;
    resetTlsSettings(): void;
    get tlsSettingsInput(): ComputeBackendServiceTlsSettings | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
