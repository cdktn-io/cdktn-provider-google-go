/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeForwardingRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The 'ports', 'portRange', and 'allPorts' fields are mutually exclusive.
    * Only packets addressed to ports in the specified range will be forwarded
    * to the backends configured with this forwarding rule.
    *
    * The 'allPorts' field has the following limitations:
    * * It requires that the forwarding rule 'IPProtocol' be TCP, UDP, SCTP, or
    * L3_DEFAULT.
    * * It's applicable only to the following products: internal passthrough
    * Network Load Balancers, backend service-based external passthrough Network
    * Load Balancers, and internal and external protocol forwarding.
    * * Set this field to true to allow packets addressed to any port or packets
    * lacking destination port information (for example, UDP fragments after the
    * first fragment) to be forwarded to the backends configured with this
    * forwarding rule. The L3_DEFAULT protocol requires 'allPorts' be set to
    * true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#all_ports ComputeForwardingRule#all_ports}
    */
    readonly allPorts?: boolean | cdktn.IResolvable;
    /**
    * This field is used along with the 'backend_service' field for
    * internal load balancing or with the 'target' field for internal
    * TargetInstance.
    *
    * If the field is set to 'TRUE', clients can access ILB from all
    * regions.
    *
    * Otherwise only allows access from clients in the same region as the
    * internal load balancer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#allow_global_access ComputeForwardingRule#allow_global_access}
    */
    readonly allowGlobalAccess?: boolean | cdktn.IResolvable;
    /**
    * This is used in PSC consumer ForwardingRule to control whether the PSC endpoint can be accessed from another region.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#allow_psc_global_access ComputeForwardingRule#allow_psc_global_access}
    */
    readonly allowPscGlobalAccess?: boolean | cdktn.IResolvable;
    /**
    * Identifies the backend service to which the forwarding rule sends traffic.
    *
    * Required for Internal TCP/UDP Load Balancing and Network Load Balancing;
    * must be omitted for all other load balancer types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#backend_service ComputeForwardingRule#backend_service}
    */
    readonly backendService?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#deletion_policy ComputeForwardingRule#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource. Provide this property when
    * you create the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#description ComputeForwardingRule#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#id ComputeForwardingRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * IP address for which this forwarding rule accepts traffic. When a client
    * sends traffic to this IP address, the forwarding rule directs the traffic
    * to the referenced 'target' or 'backendService'.
    *
    * While creating a forwarding rule, specifying an 'IPAddress' is
    * required under the following circumstances:
    *
    * * When the 'target' is set to 'targetGrpcProxy' and
    * 'validateForProxyless' is set to 'true', the
    * 'IPAddress' should be set to '0.0.0.0'.
    * * When the 'target' is a Private Service Connect Google APIs
    * bundle, you must specify an 'IPAddress'.
    *
    * Otherwise, you can optionally specify an IP address that references an
    * existing static (reserved) IP address resource. When omitted, Google Cloud
    * assigns an ephemeral IP address.
    *
    * Use one of the following formats to specify an IP address while creating a
    * forwarding rule:
    *
    * * IP address number, as in '100.1.2.3'
    * * IPv6 address range, as in '2600:1234::/96'
    * * Full resource URL, as in
    * 'https://www.googleapis.com/compute/v1/projects/project_id/regions/region/addresses/address-name'
    * * Partial URL or by name, as in:
    *   * 'projects/project_id/regions/region/addresses/address-name'
    *   * 'regions/region/addresses/address-name'
    *   * 'global/addresses/address-name'
    *   * 'address-name'
    *
    * The forwarding rule's 'target' or 'backendService',
    * and in most cases, also the 'loadBalancingScheme', determine the
    * type of IP address that you can use. For detailed information, see
    * [IP address
    * specifications](https://cloud.google.com/load-balancing/docs/forwarding-rule-concepts#ip_address_specifications).
    *
    * When reading an 'IPAddress', the API always returns the IP
    * address number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#ip_address ComputeForwardingRule#ip_address}
    */
    readonly ipAddress?: string;
    /**
    * Resource reference of a PublicDelegatedPrefix. The PDP must be a sub-PDP
    * in EXTERNAL_IPV6_FORWARDING_RULE_CREATION mode.
    * Use one of the following formats to specify a sub-PDP when creating an
    * IPv6 NetLB forwarding rule using BYOIP:
    * Full resource URL, as in:
    *   * 'https://www.googleapis.com/compute/v1/projects/{{projectId}}/regions/{{region}}/publicDelegatedPrefixes/{{sub-pdp-name}}'
    * Partial URL, as in:
    *   * 'projects/{{projectId}}/regions/region/publicDelegatedPrefixes/{{sub-pdp-name}}'
    *   * 'regions/{{region}}/publicDelegatedPrefixes/{{sub-pdp-name}}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#ip_collection ComputeForwardingRule#ip_collection}
    */
    readonly ipCollection?: string;
    /**
    * The IP protocol to which this rule applies.
    *
    * For protocol forwarding, valid
    * options are 'TCP', 'UDP', 'ESP',
    * 'AH', 'SCTP', 'ICMP' and
    * 'L3_DEFAULT'.
    *
    * The valid IP protocols are different for different load balancing products
    * as described in [Load balancing
    * features](https://cloud.google.com/load-balancing/docs/features#protocols_from_the_load_balancer_to_the_backends).
    *
    * A Forwarding Rule with protocol L3_DEFAULT can attach with target instance or
    * backend service with UNSPECIFIED protocol.
    * A forwarding rule with "L3_DEFAULT" IPProtocal cannot be attached to a backend service with TCP or UDP. Possible values: ["TCP", "UDP", "ESP", "AH", "SCTP", "ICMP", "L3_DEFAULT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#ip_protocol ComputeForwardingRule#ip_protocol}
    */
    readonly ipProtocol?: string;
    /**
    * The IP address version that will be used by this forwarding rule.
    * Valid options are IPV4 and IPV6.
    *
    * If not set, the IPv4 address will be used by default. Possible values: ["IPV4", "IPV6"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#ip_version ComputeForwardingRule#ip_version}
    */
    readonly ipVersion?: string;
    /**
    * Indicates whether or not this load balancer can be used as a collector for
    * packet mirroring. To prevent mirroring loops, instances behind this
    * load balancer will not have their traffic mirrored even if a
    * 'PacketMirroring' rule applies to them.
    *
    * This can only be set to true for load balancers that have their
    * 'loadBalancingScheme' set to 'INTERNAL'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#is_mirroring_collector ComputeForwardingRule#is_mirroring_collector}
    */
    readonly isMirroringCollector?: boolean | cdktn.IResolvable;
    /**
    * Labels to apply to this forwarding rule.  A list of key->value pairs.
    *
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#labels ComputeForwardingRule#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Specifies the forwarding rule type.
    *
    * Note that an empty string value ('""') is also supported for some use
    * cases, for example PSC (private service connection) regional forwarding
    * rules.
    *
    * For more information about forwarding rules, refer to
    * [Forwarding rule concepts](https://cloud.google.com/load-balancing/docs/forwarding-rule-concepts). Default value: "EXTERNAL" Possible values: ["EXTERNAL", "EXTERNAL_MANAGED", "INTERNAL", "INTERNAL_MANAGED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#load_balancing_scheme ComputeForwardingRule#load_balancing_scheme}
    */
    readonly loadBalancingScheme?: string;
    /**
    * Name of the resource; provided by the client when the resource is created.
    * The name must be 1-63 characters long, and comply with
    * [RFC1035](https://www.ietf.org/rfc/rfc1035.txt).
    *
    * Specifically, the name must be 1-63 characters long and match the regular
    * expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the first
    * character must be a lowercase letter, and all following characters must
    * be a dash, lowercase letter, or digit, except the last character, which
    * cannot be a dash.
    *
    * For Private Service Connect forwarding rules that forward traffic to Google
    * APIs, the forwarding rule name must be a 1-20 characters string with
    * lowercase letters and numbers and must start with a letter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#name ComputeForwardingRule#name}
    */
    readonly name: string;
    /**
    * This field is not used for global external load balancing.
    *
    * For Internal TCP/UDP Load Balancing and Regional External Load Balancing ('EXTERNAL_MANAGED'),
    * this field identifies the network that the load balanced IP should belong to
    * for this Forwarding Rule.
    * If the subnetwork is specified, the network of the subnetwork will be used.
    * If neither subnetwork nor this field is specified, the default network will
    * be used.
    *
    * For Private Service Connect forwarding rules that forward traffic to Google
    * APIs, a network must be provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#network ComputeForwardingRule#network}
    */
    readonly network?: string;
    /**
    * This signifies the networking tier used for configuring
    * this load balancer and can only take the following values:
    * 'PREMIUM', 'STANDARD'.
    *
    * For regional ForwardingRule, the valid values are 'PREMIUM' and
    * 'STANDARD'. For GlobalForwardingRule, the valid value is
    * 'PREMIUM'.
    *
    * If this field is not specified, it is assumed to be 'PREMIUM'.
    * If 'IPAddress' is specified, this value must be equal to the
    * networkTier of the Address. Possible values: ["PREMIUM", "STANDARD"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#network_tier ComputeForwardingRule#network_tier}
    */
    readonly networkTier?: string;
    /**
    * This is used in PSC consumer ForwardingRule to control whether it should try to auto-generate a DNS zone or not. Non-PSC forwarding rules do not use this field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#no_automate_dns_zone ComputeForwardingRule#no_automate_dns_zone}
    */
    readonly noAutomateDnsZone?: boolean | cdktn.IResolvable;
    /**
    * The 'ports', 'portRange', and 'allPorts' fields are mutually exclusive.
    * Only packets addressed to ports in the specified range will be forwarded
    * to the backends configured with this forwarding rule.
    *
    * The 'portRange' field has the following limitations:
    * * It requires that the forwarding rule 'IPProtocol' be TCP, UDP, or SCTP,
    * and
    * * It's applicable only to the following products: external passthrough
    * Network Load Balancers, internal and external proxy Network Load
    * Balancers, internal and external Application Load Balancers, external
    * protocol forwarding, and Classic VPN.
    * * Some products have restrictions on what ports can be used. See
    * [port specifications](https://cloud.google.com/load-balancing/docs/forwarding-rule-concepts#port_specifications)
    * for details.
    *
    * For external forwarding rules, two or more forwarding rules cannot use the
    * same '[IPAddress, IPProtocol]' pair, and cannot have overlapping
    * 'portRange's.
    *
    * For internal forwarding rules within the same VPC network, two or more
    * forwarding rules cannot use the same '[IPAddress, IPProtocol]' pair, and
    * cannot have overlapping 'portRange's.
    *
    * @pattern: \d+(?:-\d+)?
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#port_range ComputeForwardingRule#port_range}
    */
    readonly portRange?: string;
    /**
    * The 'ports', 'portRange', and 'allPorts' fields are mutually exclusive.
    * Only packets addressed to ports in the specified range will be forwarded
    * to the backends configured with this forwarding rule.
    *
    * The 'ports' field has the following limitations:
    * * It requires that the forwarding rule 'IPProtocol' be TCP, UDP, or SCTP,
    * and
    * * It's applicable only to the following products: internal passthrough
    * Network Load Balancers, backend service-based external passthrough Network
    * Load Balancers, and internal protocol forwarding.
    * * You can specify a list of up to five ports by number, separated by
    * commas. The ports can be contiguous or discontiguous.
    *
    * For external forwarding rules, two or more forwarding rules cannot use the
    * same '[IPAddress, IPProtocol]' pair if they share at least one port
    * number.
    *
    * For internal forwarding rules within the same VPC network, two or more
    * forwarding rules cannot use the same '[IPAddress, IPProtocol]' pair if
    * they share at least one port number.
    *
    * @pattern: \d+(?:-\d+)?
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#ports ComputeForwardingRule#ports}
    */
    readonly ports?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#project ComputeForwardingRule#project}
    */
    readonly project?: string;
    /**
    * This is used in PSC consumer ForwardingRule to make terraform recreate the ForwardingRule when the status is closed
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#recreate_closed_psc ComputeForwardingRule#recreate_closed_psc}
    */
    readonly recreateClosedPsc?: boolean | cdktn.IResolvable;
    /**
    * A reference to the region where the regional forwarding rule resides.
    *
    * This field is not applicable to global forwarding rules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#region ComputeForwardingRule#region}
    */
    readonly region?: string;
    /**
    * An optional prefix to the service name for this Forwarding Rule.
    * If specified, will be the first label of the fully qualified service
    * name.
    *
    * The label must be 1-63 characters long, and comply with RFC1035.
    * Specifically, the label must be 1-63 characters long and match the
    * regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the first
    * character must be a lowercase letter, and all following characters
    * must be a dash, lowercase letter, or digit, except the last
    * character, which cannot be a dash.
    *
    * This field is only used for INTERNAL load balancing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#service_label ComputeForwardingRule#service_label}
    */
    readonly serviceLabel?: string;
    /**
    * If not empty, this Forwarding Rule will only forward the traffic when the source IP address matches one of the IP addresses or CIDR ranges set here. Note that a Forwarding Rule can only have up to 64 source IP ranges, and this field can only be used with a regional Forwarding Rule whose scheme is EXTERNAL. Each sourceIpRange entry should be either an IP address (for example, 1.2.3.4) or a CIDR range (for example, 1.2.3.0/24).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#source_ip_ranges ComputeForwardingRule#source_ip_ranges}
    */
    readonly sourceIpRanges?: string[];
    /**
    * This field identifies the subnetwork that the load balanced IP should
    * belong to for this Forwarding Rule, used in internal load balancing,
    * network load balancing with IPv6, and regional external ('EXTERNAL_MANAGED')
    * load balancing with IPv6.
    *
    * If the network specified is in auto subnet mode, this field is optional.
    * However, a subnetwork must be specified if the network is in custom subnet
    * mode or when creating external forwarding rule with IPv6.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#subnetwork ComputeForwardingRule#subnetwork}
    */
    readonly subnetwork?: string;
    /**
    * The URL of the target resource to receive the matched traffic.  For
    * regional forwarding rules, this target must be in the same region as the
    * forwarding rule. For global forwarding rules, this target must be a global
    * load balancing resource.
    *
    * The forwarded traffic must be of a type appropriate to the target object.
    * *  For load balancers, see the "Target" column in [Port specifications](https://cloud.google.com/load-balancing/docs/forwarding-rule-concepts#ip_address_specifications).
    *
    * For Private Service Connect forwarding rules that forward traffic to managed services, the target must be a service attachment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#target ComputeForwardingRule#target}
    */
    readonly target?: string;
    /**
    * service_directory_registrations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#service_directory_registrations ComputeForwardingRule#service_directory_registrations}
    */
    readonly serviceDirectoryRegistrations?: ComputeForwardingRuleServiceDirectoryRegistrations;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#timeouts ComputeForwardingRule#timeouts}
    */
    readonly timeouts?: ComputeForwardingRuleTimeouts;
}
export interface ComputeForwardingRuleServiceDirectoryRegistrations {
    /**
    * Service Directory namespace to register the forwarding rule under.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#namespace ComputeForwardingRule#namespace}
    */
    readonly namespace?: string;
    /**
    * Service Directory service to register the forwarding rule under.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#service ComputeForwardingRule#service}
    */
    readonly service?: string;
}
export declare function computeForwardingRuleServiceDirectoryRegistrationsToTerraform(struct?: ComputeForwardingRuleServiceDirectoryRegistrationsOutputReference | ComputeForwardingRuleServiceDirectoryRegistrations): any;
export declare function computeForwardingRuleServiceDirectoryRegistrationsToHclTerraform(struct?: ComputeForwardingRuleServiceDirectoryRegistrationsOutputReference | ComputeForwardingRuleServiceDirectoryRegistrations): any;
export declare class ComputeForwardingRuleServiceDirectoryRegistrationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeForwardingRuleServiceDirectoryRegistrations | undefined;
    set internalValue(value: ComputeForwardingRuleServiceDirectoryRegistrations | undefined);
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
}
export interface ComputeForwardingRuleTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#create ComputeForwardingRule#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#delete ComputeForwardingRule#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#update ComputeForwardingRule#update}
    */
    readonly update?: string;
}
export declare function computeForwardingRuleTimeoutsToTerraform(struct?: ComputeForwardingRuleTimeouts | cdktn.IResolvable): any;
export declare function computeForwardingRuleTimeoutsToHclTerraform(struct?: ComputeForwardingRuleTimeouts | cdktn.IResolvable): any;
export declare class ComputeForwardingRuleTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeForwardingRuleTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeForwardingRuleTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule google_compute_forwarding_rule}
*/
export declare class ComputeForwardingRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_forwarding_rule";
    /**
    * Generates CDKTN code for importing a ComputeForwardingRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeForwardingRule to import
    * @param importFromId The id of the existing ComputeForwardingRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeForwardingRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_forwarding_rule google_compute_forwarding_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeForwardingRuleConfig
    */
    constructor(scope: Construct, id: string, config: ComputeForwardingRuleConfig);
    private _allPorts?;
    get allPorts(): boolean | cdktn.IResolvable;
    set allPorts(value: boolean | cdktn.IResolvable);
    resetAllPorts(): void;
    get allPortsInput(): boolean | cdktn.IResolvable | undefined;
    private _allowGlobalAccess?;
    get allowGlobalAccess(): boolean | cdktn.IResolvable;
    set allowGlobalAccess(value: boolean | cdktn.IResolvable);
    resetAllowGlobalAccess(): void;
    get allowGlobalAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _allowPscGlobalAccess?;
    get allowPscGlobalAccess(): boolean | cdktn.IResolvable;
    set allowPscGlobalAccess(value: boolean | cdktn.IResolvable);
    resetAllowPscGlobalAccess(): void;
    get allowPscGlobalAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _backendService?;
    get backendService(): string;
    set backendService(value: string);
    resetBackendService(): void;
    get backendServiceInput(): string | undefined;
    get baseForwardingRule(): string;
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get forwardingRuleId(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipAddress?;
    get ipAddress(): string;
    set ipAddress(value: string);
    resetIpAddress(): void;
    get ipAddressInput(): string | undefined;
    private _ipCollection?;
    get ipCollection(): string;
    set ipCollection(value: string);
    resetIpCollection(): void;
    get ipCollectionInput(): string | undefined;
    private _ipProtocol?;
    get ipProtocol(): string;
    set ipProtocol(value: string);
    resetIpProtocol(): void;
    get ipProtocolInput(): string | undefined;
    private _ipVersion?;
    get ipVersion(): string;
    set ipVersion(value: string);
    resetIpVersion(): void;
    get ipVersionInput(): string | undefined;
    private _isMirroringCollector?;
    get isMirroringCollector(): boolean | cdktn.IResolvable;
    set isMirroringCollector(value: boolean | cdktn.IResolvable);
    resetIsMirroringCollector(): void;
    get isMirroringCollectorInput(): boolean | cdktn.IResolvable | undefined;
    get labelFingerprint(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _loadBalancingScheme?;
    get loadBalancingScheme(): string;
    set loadBalancingScheme(value: string);
    resetLoadBalancingScheme(): void;
    get loadBalancingSchemeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _network?;
    get network(): string;
    set network(value: string);
    resetNetwork(): void;
    get networkInput(): string | undefined;
    private _networkTier?;
    get networkTier(): string;
    set networkTier(value: string);
    resetNetworkTier(): void;
    get networkTierInput(): string | undefined;
    private _noAutomateDnsZone?;
    get noAutomateDnsZone(): boolean | cdktn.IResolvable;
    set noAutomateDnsZone(value: boolean | cdktn.IResolvable);
    resetNoAutomateDnsZone(): void;
    get noAutomateDnsZoneInput(): boolean | cdktn.IResolvable | undefined;
    private _portRange?;
    get portRange(): string;
    set portRange(value: string);
    resetPortRange(): void;
    get portRangeInput(): string | undefined;
    private _ports?;
    get ports(): string[];
    set ports(value: string[]);
    resetPorts(): void;
    get portsInput(): string[] | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get pscConnectionId(): string;
    get pscConnectionStatus(): string;
    private _recreateClosedPsc?;
    get recreateClosedPsc(): boolean | cdktn.IResolvable;
    set recreateClosedPsc(value: boolean | cdktn.IResolvable);
    resetRecreateClosedPsc(): void;
    get recreateClosedPscInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get selfLink(): string;
    private _serviceLabel?;
    get serviceLabel(): string;
    set serviceLabel(value: string);
    resetServiceLabel(): void;
    get serviceLabelInput(): string | undefined;
    get serviceName(): string;
    private _sourceIpRanges?;
    get sourceIpRanges(): string[];
    set sourceIpRanges(value: string[]);
    resetSourceIpRanges(): void;
    get sourceIpRangesInput(): string[] | undefined;
    private _subnetwork?;
    get subnetwork(): string;
    set subnetwork(value: string);
    resetSubnetwork(): void;
    get subnetworkInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    resetTarget(): void;
    get targetInput(): string | undefined;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _serviceDirectoryRegistrations;
    get serviceDirectoryRegistrations(): ComputeForwardingRuleServiceDirectoryRegistrationsOutputReference;
    putServiceDirectoryRegistrations(value: ComputeForwardingRuleServiceDirectoryRegistrations): void;
    resetServiceDirectoryRegistrations(): void;
    get serviceDirectoryRegistrationsInput(): ComputeForwardingRuleServiceDirectoryRegistrations | undefined;
    private _timeouts;
    get timeouts(): ComputeForwardingRuleTimeoutsOutputReference;
    putTimeouts(value: ComputeForwardingRuleTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeForwardingRuleTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
