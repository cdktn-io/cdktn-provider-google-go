/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudIdentityGroupMembershipConfig extends cdktn.TerraformMetaArguments {
    /**
    * If set to true, skip group member creation if a membership with the same name already exists. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_identity_group_membership#create_ignore_already_exists CloudIdentityGroupMembership#create_ignore_already_exists}
    */
    readonly createIgnoreAlreadyExists?: boolean | cdktn.IResolvable;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_identity_group_membership#deletion_policy CloudIdentityGroupMembership#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The name of the Group to create this membership in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_identity_group_membership#group CloudIdentityGroupMembership#group}
    */
    readonly group: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_identity_group_membership#id CloudIdentityGroupMembership#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * preferred_member_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_identity_group_membership#preferred_member_key CloudIdentityGroupMembership#preferred_member_key}
    */
    readonly preferredMemberKey?: CloudIdentityGroupMembershipPreferredMemberKey;
    /**
    * roles block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_identity_group_membership#roles CloudIdentityGroupMembership#roles}
    */
    readonly roles: CloudIdentityGroupMembershipRoles[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_identity_group_membership#timeouts CloudIdentityGroupMembership#timeouts}
    */
    readonly timeouts?: CloudIdentityGroupMembershipTimeouts;
}
export interface CloudIdentityGroupMembershipPreferredMemberKey {
    /**
    * The ID of the entity.
    *
    * For Google-managed entities, the id must be the email address of an existing
    * group or user.
    *
    * For external-identity-mapped entities, the id must be a string conforming
    * to the Identity Source's requirements.
    *
    * Must be unique within a namespace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_identity_group_membership#id CloudIdentityGroupMembership#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * The namespace in which the entity exists.
    *
    * If not specified, the EntityKey represents a Google-managed entity
    * such as a Google user or a Google Group.
    *
    * If specified, the EntityKey represents an external-identity-mapped group.
    * The namespace must correspond to an identity source created in Admin Console
    * and must be in the form of 'identitysources/{identity_source_id}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_identity_group_membership#namespace CloudIdentityGroupMembership#namespace}
    */
    readonly namespace?: string;
}
export declare function cloudIdentityGroupMembershipPreferredMemberKeyToTerraform(struct?: CloudIdentityGroupMembershipPreferredMemberKeyOutputReference | CloudIdentityGroupMembershipPreferredMemberKey): any;
export declare function cloudIdentityGroupMembershipPreferredMemberKeyToHclTerraform(struct?: CloudIdentityGroupMembershipPreferredMemberKeyOutputReference | CloudIdentityGroupMembershipPreferredMemberKey): any;
export declare class CloudIdentityGroupMembershipPreferredMemberKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudIdentityGroupMembershipPreferredMemberKey | undefined;
    set internalValue(value: CloudIdentityGroupMembershipPreferredMemberKey | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface CloudIdentityGroupMembershipRolesExpiryDetail {
    /**
    * The time at which the MembershipRole will expire.
    *
    * A timestamp in RFC3339 UTC "Zulu" format, with nanosecond
    * resolution and up to nine fractional digits.
    *
    * Examples: "2014-10-02T15:01:23Z" and "2014-10-02T15:01:23.045123456Z".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_identity_group_membership#expire_time CloudIdentityGroupMembership#expire_time}
    */
    readonly expireTime: string;
}
export declare function cloudIdentityGroupMembershipRolesExpiryDetailToTerraform(struct?: CloudIdentityGroupMembershipRolesExpiryDetailOutputReference | CloudIdentityGroupMembershipRolesExpiryDetail): any;
export declare function cloudIdentityGroupMembershipRolesExpiryDetailToHclTerraform(struct?: CloudIdentityGroupMembershipRolesExpiryDetailOutputReference | CloudIdentityGroupMembershipRolesExpiryDetail): any;
export declare class CloudIdentityGroupMembershipRolesExpiryDetailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudIdentityGroupMembershipRolesExpiryDetail | undefined;
    set internalValue(value: CloudIdentityGroupMembershipRolesExpiryDetail | undefined);
    private _expireTime?;
    get expireTime(): string;
    set expireTime(value: string);
    get expireTimeInput(): string | undefined;
}
export interface CloudIdentityGroupMembershipRoles {
    /**
    * The name of the MembershipRole. Must be one of OWNER, MANAGER, MEMBER. Possible values: ["OWNER", "MANAGER", "MEMBER"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_identity_group_membership#name CloudIdentityGroupMembership#name}
    */
    readonly name: string;
    /**
    * expiry_detail block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_identity_group_membership#expiry_detail CloudIdentityGroupMembership#expiry_detail}
    */
    readonly expiryDetail?: CloudIdentityGroupMembershipRolesExpiryDetail;
}
export declare function cloudIdentityGroupMembershipRolesToTerraform(struct?: CloudIdentityGroupMembershipRoles | cdktn.IResolvable): any;
export declare function cloudIdentityGroupMembershipRolesToHclTerraform(struct?: CloudIdentityGroupMembershipRoles | cdktn.IResolvable): any;
export declare class CloudIdentityGroupMembershipRolesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudIdentityGroupMembershipRoles | cdktn.IResolvable | undefined;
    set internalValue(value: CloudIdentityGroupMembershipRoles | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _expiryDetail;
    get expiryDetail(): CloudIdentityGroupMembershipRolesExpiryDetailOutputReference;
    putExpiryDetail(value: CloudIdentityGroupMembershipRolesExpiryDetail): void;
    resetExpiryDetail(): void;
    get expiryDetailInput(): CloudIdentityGroupMembershipRolesExpiryDetail | undefined;
}
export declare class CloudIdentityGroupMembershipRolesList extends cdktn.ComplexList {
    internalValue?: CloudIdentityGroupMembershipRoles[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudIdentityGroupMembershipRolesOutputReference;
}
export interface CloudIdentityGroupMembershipTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_identity_group_membership#create CloudIdentityGroupMembership#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_identity_group_membership#delete CloudIdentityGroupMembership#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_identity_group_membership#update CloudIdentityGroupMembership#update}
    */
    readonly update?: string;
}
export declare function cloudIdentityGroupMembershipTimeoutsToTerraform(struct?: CloudIdentityGroupMembershipTimeouts | cdktn.IResolvable): any;
export declare function cloudIdentityGroupMembershipTimeoutsToHclTerraform(struct?: CloudIdentityGroupMembershipTimeouts | cdktn.IResolvable): any;
export declare class CloudIdentityGroupMembershipTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudIdentityGroupMembershipTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CloudIdentityGroupMembershipTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_identity_group_membership google_cloud_identity_group_membership}
*/
export declare class CloudIdentityGroupMembership extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_cloud_identity_group_membership";
    /**
    * Generates CDKTN code for importing a CloudIdentityGroupMembership resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudIdentityGroupMembership to import
    * @param importFromId The id of the existing CloudIdentityGroupMembership that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_identity_group_membership#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudIdentityGroupMembership to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_identity_group_membership google_cloud_identity_group_membership} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudIdentityGroupMembershipConfig
    */
    constructor(scope: Construct, id: string, config: CloudIdentityGroupMembershipConfig);
    private _createIgnoreAlreadyExists?;
    get createIgnoreAlreadyExists(): boolean | cdktn.IResolvable;
    set createIgnoreAlreadyExists(value: boolean | cdktn.IResolvable);
    resetCreateIgnoreAlreadyExists(): void;
    get createIgnoreAlreadyExistsInput(): boolean | cdktn.IResolvable | undefined;
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _group?;
    get group(): string;
    set group(value: string);
    get groupInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    get type(): string;
    get updateTime(): string;
    private _preferredMemberKey;
    get preferredMemberKey(): CloudIdentityGroupMembershipPreferredMemberKeyOutputReference;
    putPreferredMemberKey(value: CloudIdentityGroupMembershipPreferredMemberKey): void;
    resetPreferredMemberKey(): void;
    get preferredMemberKeyInput(): CloudIdentityGroupMembershipPreferredMemberKey | undefined;
    private _roles;
    get roles(): CloudIdentityGroupMembershipRolesList;
    putRoles(value: CloudIdentityGroupMembershipRoles[] | cdktn.IResolvable): void;
    get rolesInput(): cdktn.IResolvable | CloudIdentityGroupMembershipRoles[] | undefined;
    private _timeouts;
    get timeouts(): CloudIdentityGroupMembershipTimeoutsOutputReference;
    putTimeouts(value: CloudIdentityGroupMembershipTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CloudIdentityGroupMembershipTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
