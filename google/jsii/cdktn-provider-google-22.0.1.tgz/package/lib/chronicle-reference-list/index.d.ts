/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChronicleReferenceListConfig extends cdktn.TerraformMetaArguments {
    /**
    * Required. A user-provided description of the reference list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_reference_list#description ChronicleReferenceList#description}
    */
    readonly description: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_reference_list#id ChronicleReferenceList#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The unique identifier for the Chronicle instance, which is the same as the customer ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_reference_list#instance ChronicleReferenceList#instance}
    */
    readonly instance: string;
    /**
    * The location of the resource. This is the geographical region where the Chronicle instance resides, such as "us" or "europe-west2".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_reference_list#location ChronicleReferenceList#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_reference_list#project ChronicleReferenceList#project}
    */
    readonly project?: string;
    /**
    * Required. The ID to use for the reference list. This is also the display name for
    * the reference list. It must satisfy the following requirements:
    * - Starts with letter.
    * - Contains only letters, numbers and underscore.
    * - Has length < 256.
    * - Must be unique.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_reference_list#reference_list_id ChronicleReferenceList#reference_list_id}
    */
    readonly referenceListId: string;
    /**
    * Possible values:
    * REFERENCE_LIST_SYNTAX_TYPE_PLAIN_TEXT_STRING
    * REFERENCE_LIST_SYNTAX_TYPE_REGEX
    * REFERENCE_LIST_SYNTAX_TYPE_CIDR
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_reference_list#syntax_type ChronicleReferenceList#syntax_type}
    */
    readonly syntaxType: string;
    /**
    * entries block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_reference_list#entries ChronicleReferenceList#entries}
    */
    readonly entries: ChronicleReferenceListEntries[] | cdktn.IResolvable;
    /**
    * scope_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_reference_list#scope_info ChronicleReferenceList#scope_info}
    */
    readonly scopeInfo?: ChronicleReferenceListScopeInfo;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_reference_list#timeouts ChronicleReferenceList#timeouts}
    */
    readonly timeouts?: ChronicleReferenceListTimeouts;
}
export interface ChronicleReferenceListEntries {
    /**
    * Required. The value of the entry. Maximum length is 512 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_reference_list#value ChronicleReferenceList#value}
    */
    readonly value: string;
}
export declare function chronicleReferenceListEntriesToTerraform(struct?: ChronicleReferenceListEntries | cdktn.IResolvable): any;
export declare function chronicleReferenceListEntriesToHclTerraform(struct?: ChronicleReferenceListEntries | cdktn.IResolvable): any;
export declare class ChronicleReferenceListEntriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleReferenceListEntries | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleReferenceListEntries | cdktn.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ChronicleReferenceListEntriesList extends cdktn.ComplexList {
    internalValue?: ChronicleReferenceListEntries[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleReferenceListEntriesOutputReference;
}
export interface ChronicleReferenceListScopeInfoReferenceListScope {
    /**
    * Optional. The list of scope names of the reference list. The scope names should be
    * full resource names and should be of the format:
    * "projects/{project}/locations/{location}/instances/{instance}/dataAccessScopes/{scope_name}".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_reference_list#scope_names ChronicleReferenceList#scope_names}
    */
    readonly scopeNames?: string[];
}
export declare function chronicleReferenceListScopeInfoReferenceListScopeToTerraform(struct?: ChronicleReferenceListScopeInfoReferenceListScopeOutputReference | ChronicleReferenceListScopeInfoReferenceListScope): any;
export declare function chronicleReferenceListScopeInfoReferenceListScopeToHclTerraform(struct?: ChronicleReferenceListScopeInfoReferenceListScopeOutputReference | ChronicleReferenceListScopeInfoReferenceListScope): any;
export declare class ChronicleReferenceListScopeInfoReferenceListScopeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleReferenceListScopeInfoReferenceListScope | undefined;
    set internalValue(value: ChronicleReferenceListScopeInfoReferenceListScope | undefined);
    private _scopeNames?;
    get scopeNames(): string[];
    set scopeNames(value: string[]);
    resetScopeNames(): void;
    get scopeNamesInput(): string[] | undefined;
}
export interface ChronicleReferenceListScopeInfo {
    /**
    * reference_list_scope block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_reference_list#reference_list_scope ChronicleReferenceList#reference_list_scope}
    */
    readonly referenceListScope?: ChronicleReferenceListScopeInfoReferenceListScope;
}
export declare function chronicleReferenceListScopeInfoToTerraform(struct?: ChronicleReferenceListScopeInfoOutputReference | ChronicleReferenceListScopeInfo): any;
export declare function chronicleReferenceListScopeInfoToHclTerraform(struct?: ChronicleReferenceListScopeInfoOutputReference | ChronicleReferenceListScopeInfo): any;
export declare class ChronicleReferenceListScopeInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleReferenceListScopeInfo | undefined;
    set internalValue(value: ChronicleReferenceListScopeInfo | undefined);
    private _referenceListScope;
    get referenceListScope(): ChronicleReferenceListScopeInfoReferenceListScopeOutputReference;
    putReferenceListScope(value: ChronicleReferenceListScopeInfoReferenceListScope): void;
    resetReferenceListScope(): void;
    get referenceListScopeInput(): ChronicleReferenceListScopeInfoReferenceListScope | undefined;
}
export interface ChronicleReferenceListTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_reference_list#create ChronicleReferenceList#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_reference_list#delete ChronicleReferenceList#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_reference_list#update ChronicleReferenceList#update}
    */
    readonly update?: string;
}
export declare function chronicleReferenceListTimeoutsToTerraform(struct?: ChronicleReferenceListTimeouts | cdktn.IResolvable): any;
export declare function chronicleReferenceListTimeoutsToHclTerraform(struct?: ChronicleReferenceListTimeouts | cdktn.IResolvable): any;
export declare class ChronicleReferenceListTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleReferenceListTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleReferenceListTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_reference_list google_chronicle_reference_list}
*/
export declare class ChronicleReferenceList extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_chronicle_reference_list";
    /**
    * Generates CDKTN code for importing a ChronicleReferenceList resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChronicleReferenceList to import
    * @param importFromId The id of the existing ChronicleReferenceList that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_reference_list#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChronicleReferenceList to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_reference_list google_chronicle_reference_list} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChronicleReferenceListConfig
    */
    constructor(scope: Construct, id: string, config: ChronicleReferenceListConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    get displayName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instance?;
    get instance(): string;
    set instance(value: string);
    get instanceInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _referenceListId?;
    get referenceListId(): string;
    set referenceListId(value: string);
    get referenceListIdInput(): string | undefined;
    get revisionCreateTime(): string;
    get ruleAssociationsCount(): number;
    get rules(): string[];
    private _syntaxType?;
    get syntaxType(): string;
    set syntaxType(value: string);
    get syntaxTypeInput(): string | undefined;
    private _entries;
    get entries(): ChronicleReferenceListEntriesList;
    putEntries(value: ChronicleReferenceListEntries[] | cdktn.IResolvable): void;
    get entriesInput(): cdktn.IResolvable | ChronicleReferenceListEntries[] | undefined;
    private _scopeInfo;
    get scopeInfo(): ChronicleReferenceListScopeInfoOutputReference;
    putScopeInfo(value: ChronicleReferenceListScopeInfo): void;
    resetScopeInfo(): void;
    get scopeInfoInput(): ChronicleReferenceListScopeInfo | undefined;
    private _timeouts;
    get timeouts(): ChronicleReferenceListTimeoutsOutputReference;
    putTimeouts(value: ChronicleReferenceListTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ChronicleReferenceListTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
