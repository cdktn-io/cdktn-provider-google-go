/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AlloydbInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * 'Specifies whether an instance needs to spin up. Once the instance is
    * active, the activation policy can be updated to the 'NEVER' to stop the
    * instance. Likewise, the activation policy can be updated to 'ALWAYS' to
    * start the instance.
    * There are restrictions around when an instance can/cannot be activated (for
    * example, a read pool instance should be stopped before stopping primary
    * etc.). Please refer to the API documentation for more details.
    * Possible values are: 'ACTIVATION_POLICY_UNSPECIFIED', 'ALWAYS', 'NEVER'.' Possible values: ["ACTIVATION_POLICY_UNSPECIFIED", "ALWAYS", "NEVER"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#activation_policy AlloydbInstance#activation_policy}
    */
    readonly activationPolicy?: string;
    /**
    * Annotations to allow client tools to store small amount of arbitrary data. This is distinct from labels.
    *
    * **Note**: This field is non-authoritative, and will only manage the annotations present in your configuration.
    * Please refer to the field 'effective_annotations' for all of the annotations present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#annotations AlloydbInstance#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * 'Availability type of a primary Instance. Defaults to REGIONAL.
    * Primary instances can be either ZONAL or REGIONAL. Read Pool instances
    * derive their availability from 'read_pool_config.node_count': a pool
    * with one node is ZONAL, while a pool with two or more nodes is REGIONAL.
    * Read Pool instances do not support setting this field directly.
    * Possible values are: 'AVAILABILITY_TYPE_UNSPECIFIED', 'ZONAL', 'REGIONAL'.' Possible values: ["AVAILABILITY_TYPE_UNSPECIFIED", "ZONAL", "REGIONAL"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#availability_type AlloydbInstance#availability_type}
    */
    readonly availabilityType?: string;
    /**
    * Identifies the alloydb cluster. Must be in the format
    * 'projects/{project}/locations/{location}/clusters/{cluster_id}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#cluster AlloydbInstance#cluster}
    */
    readonly cluster: string;
    /**
    * Database flags. Set at instance level. * They are copied from primary instance on read instance creation. * Read instances can set new or override existing flags that are relevant for reads, e.g. for enabling columnar cache on a read instance. Flags set on read instance may or may not be present on primary.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#database_flags AlloydbInstance#database_flags}
    */
    readonly databaseFlags?: {
        [key: string]: string;
    };
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#deletion_policy AlloydbInstance#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * User-settable and human-readable display name for the Instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#display_name AlloydbInstance#display_name}
    */
    readonly displayName?: string;
    /**
    * The Compute Engine zone that the instance should serve from, per https://cloud.google.com/compute/docs/regions-zones This can ONLY be specified for ZONAL instances. If present for a REGIONAL instance, an error will be thrown. If this is absent for a ZONAL instance, instance is created in a random zone with available capacity.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#gce_zone AlloydbInstance#gce_zone}
    */
    readonly gceZone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#id AlloydbInstance#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the alloydb instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#instance_id AlloydbInstance#instance_id}
    */
    readonly instanceId: string;
    /**
    * The type of the instance.
    * If the instance type is READ_POOL, provide the associated PRIMARY/SECONDARY instance in the 'depends_on' meta-data attribute.
    * If the instance type is SECONDARY, point to the cluster_type of the associated secondary cluster instead of mentioning SECONDARY.
    * Example: {instance_type = google_alloydb_cluster.<secondary_cluster_name>.cluster_type} instead of {instance_type = SECONDARY}
    * If the instance type is SECONDARY, the terraform delete instance operation does not delete the secondary instance but abandons it instead.
    * Use deletion_policy = "FORCE" in the associated secondary cluster and delete the cluster forcefully to delete the secondary cluster as well its associated secondary instance.
    * Users can undo the delete secondary instance action by importing the deleted secondary instance by calling terraform import. Possible values: ["PRIMARY", "READ_POOL", "SECONDARY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#instance_type AlloydbInstance#instance_type}
    */
    readonly instanceType: string;
    /**
    * User-defined labels for the alloydb instance.
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#labels AlloydbInstance#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * client_connection_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#client_connection_config AlloydbInstance#client_connection_config}
    */
    readonly clientConnectionConfig?: AlloydbInstanceClientConnectionConfig;
    /**
    * connection_pool_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#connection_pool_config AlloydbInstance#connection_pool_config}
    */
    readonly connectionPoolConfig?: AlloydbInstanceConnectionPoolConfig;
    /**
    * machine_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#machine_config AlloydbInstance#machine_config}
    */
    readonly machineConfig?: AlloydbInstanceMachineConfig;
    /**
    * network_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#network_config AlloydbInstance#network_config}
    */
    readonly networkConfig?: AlloydbInstanceNetworkConfig;
    /**
    * psc_instance_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#psc_instance_config AlloydbInstance#psc_instance_config}
    */
    readonly pscInstanceConfig?: AlloydbInstancePscInstanceConfig;
    /**
    * query_insights_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#query_insights_config AlloydbInstance#query_insights_config}
    */
    readonly queryInsightsConfig?: AlloydbInstanceQueryInsightsConfig;
    /**
    * read_pool_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#read_pool_config AlloydbInstance#read_pool_config}
    */
    readonly readPoolConfig?: AlloydbInstanceReadPoolConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#timeouts AlloydbInstance#timeouts}
    */
    readonly timeouts?: AlloydbInstanceTimeouts;
}
export interface AlloydbInstanceClientConnectionConfigSslConfig {
    /**
    * SSL mode. Specifies client-server SSL/TLS connection behavior. Possible values: ["ENCRYPTED_ONLY", "ALLOW_UNENCRYPTED_AND_ENCRYPTED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#ssl_mode AlloydbInstance#ssl_mode}
    */
    readonly sslMode?: string;
}
export declare function alloydbInstanceClientConnectionConfigSslConfigToTerraform(struct?: AlloydbInstanceClientConnectionConfigSslConfigOutputReference | AlloydbInstanceClientConnectionConfigSslConfig): any;
export declare function alloydbInstanceClientConnectionConfigSslConfigToHclTerraform(struct?: AlloydbInstanceClientConnectionConfigSslConfigOutputReference | AlloydbInstanceClientConnectionConfigSslConfig): any;
export declare class AlloydbInstanceClientConnectionConfigSslConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbInstanceClientConnectionConfigSslConfig | undefined;
    set internalValue(value: AlloydbInstanceClientConnectionConfigSslConfig | undefined);
    private _sslMode?;
    get sslMode(): string;
    set sslMode(value: string);
    resetSslMode(): void;
    get sslModeInput(): string | undefined;
}
export interface AlloydbInstanceClientConnectionConfig {
    /**
    * Configuration to enforce connectors only (ex: AuthProxy) connections to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#require_connectors AlloydbInstance#require_connectors}
    */
    readonly requireConnectors?: boolean | cdktn.IResolvable;
    /**
    * ssl_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#ssl_config AlloydbInstance#ssl_config}
    */
    readonly sslConfig?: AlloydbInstanceClientConnectionConfigSslConfig;
}
export declare function alloydbInstanceClientConnectionConfigToTerraform(struct?: AlloydbInstanceClientConnectionConfigOutputReference | AlloydbInstanceClientConnectionConfig): any;
export declare function alloydbInstanceClientConnectionConfigToHclTerraform(struct?: AlloydbInstanceClientConnectionConfigOutputReference | AlloydbInstanceClientConnectionConfig): any;
export declare class AlloydbInstanceClientConnectionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbInstanceClientConnectionConfig | undefined;
    set internalValue(value: AlloydbInstanceClientConnectionConfig | undefined);
    private _requireConnectors?;
    get requireConnectors(): boolean | cdktn.IResolvable;
    set requireConnectors(value: boolean | cdktn.IResolvable);
    resetRequireConnectors(): void;
    get requireConnectorsInput(): boolean | cdktn.IResolvable | undefined;
    private _sslConfig;
    get sslConfig(): AlloydbInstanceClientConnectionConfigSslConfigOutputReference;
    putSslConfig(value: AlloydbInstanceClientConnectionConfigSslConfig): void;
    resetSslConfig(): void;
    get sslConfigInput(): AlloydbInstanceClientConnectionConfigSslConfig | undefined;
}
export interface AlloydbInstanceConnectionPoolConfig {
    /**
    * Whether to enabled Managed Connection Pool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#enabled AlloydbInstance#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Flags for configuring managed connection pooling when it is enabled.
    * These flags will only be set if 'connection_pool_config.enabled' is
    * true.
    * Please see
    * https://cloud.google.com/alloydb/docs/configure-managed-connection-pooling#configuration-options
    * for a comprehensive list of flags that can be set. To specify the flags
    * in Terraform, please remove the "connection-pooling-" prefix and use
    * underscores instead of dashes in the name. For example,
    * "connection-pooling-pool-mode" would be "pool_mode".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#flags AlloydbInstance#flags}
    */
    readonly flags?: {
        [key: string]: string;
    };
}
export declare function alloydbInstanceConnectionPoolConfigToTerraform(struct?: AlloydbInstanceConnectionPoolConfigOutputReference | AlloydbInstanceConnectionPoolConfig): any;
export declare function alloydbInstanceConnectionPoolConfigToHclTerraform(struct?: AlloydbInstanceConnectionPoolConfigOutputReference | AlloydbInstanceConnectionPoolConfig): any;
export declare class AlloydbInstanceConnectionPoolConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbInstanceConnectionPoolConfig | undefined;
    set internalValue(value: AlloydbInstanceConnectionPoolConfig | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _flags?;
    get flags(): {
        [key: string]: string;
    };
    set flags(value: {
        [key: string]: string;
    });
    resetFlags(): void;
    get flagsInput(): {
        [key: string]: string;
    } | undefined;
    get poolerCount(): number;
}
export interface AlloydbInstanceMachineConfig {
    /**
    * The number of CPUs in the VM instance. For read pool instances, this
    * value is applied to the instances in the pool and is not replaced by
    * a fixed default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#cpu_count AlloydbInstance#cpu_count}
    */
    readonly cpuCount?: number;
    /**
    * Machine type of the VM instance.
    * E.g. "n2-highmem-4", "n2-highmem-8", "c4a-highmem-4-lssd".
    * 'cpu_count' must match the number of vCPUs in the machine type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#machine_type AlloydbInstance#machine_type}
    */
    readonly machineType?: string;
}
export declare function alloydbInstanceMachineConfigToTerraform(struct?: AlloydbInstanceMachineConfigOutputReference | AlloydbInstanceMachineConfig): any;
export declare function alloydbInstanceMachineConfigToHclTerraform(struct?: AlloydbInstanceMachineConfigOutputReference | AlloydbInstanceMachineConfig): any;
export declare class AlloydbInstanceMachineConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbInstanceMachineConfig | undefined;
    set internalValue(value: AlloydbInstanceMachineConfig | undefined);
    private _cpuCount?;
    get cpuCount(): number;
    set cpuCount(value: number);
    resetCpuCount(): void;
    get cpuCountInput(): number | undefined;
    private _machineType?;
    get machineType(): string;
    set machineType(value: string);
    resetMachineType(): void;
    get machineTypeInput(): string | undefined;
}
export interface AlloydbInstanceNetworkConfigAuthorizedExternalNetworks {
    /**
    * CIDR range for one authorized network of the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#cidr_range AlloydbInstance#cidr_range}
    */
    readonly cidrRange?: string;
}
export declare function alloydbInstanceNetworkConfigAuthorizedExternalNetworksToTerraform(struct?: AlloydbInstanceNetworkConfigAuthorizedExternalNetworks | cdktn.IResolvable): any;
export declare function alloydbInstanceNetworkConfigAuthorizedExternalNetworksToHclTerraform(struct?: AlloydbInstanceNetworkConfigAuthorizedExternalNetworks | cdktn.IResolvable): any;
export declare class AlloydbInstanceNetworkConfigAuthorizedExternalNetworksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlloydbInstanceNetworkConfigAuthorizedExternalNetworks | cdktn.IResolvable | undefined;
    set internalValue(value: AlloydbInstanceNetworkConfigAuthorizedExternalNetworks | cdktn.IResolvable | undefined);
    private _cidrRange?;
    get cidrRange(): string;
    set cidrRange(value: string);
    resetCidrRange(): void;
    get cidrRangeInput(): string | undefined;
}
export declare class AlloydbInstanceNetworkConfigAuthorizedExternalNetworksList extends cdktn.ComplexList {
    internalValue?: AlloydbInstanceNetworkConfigAuthorizedExternalNetworks[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlloydbInstanceNetworkConfigAuthorizedExternalNetworksOutputReference;
}
export interface AlloydbInstanceNetworkConfig {
    /**
    * Name of the allocated IP range for the private IP AlloyDB instance, for example: "google-managed-services-default".
    * If set, the instance IPs will be created from this allocated range and will override the IP range used by the parent cluster.
    * The range name must comply with RFC 1035. Specifically, the name must be 1-63 characters long and match the regular expression [a-z]([-a-z0-9]*[a-z0-9])?.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#allocated_ip_range_override AlloydbInstance#allocated_ip_range_override}
    */
    readonly allocatedIpRangeOverride?: string;
    /**
    * Enabling outbound public ip for the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#enable_outbound_public_ip AlloydbInstance#enable_outbound_public_ip}
    */
    readonly enableOutboundPublicIp?: boolean | cdktn.IResolvable;
    /**
    * Enabling public ip for the instance. If a user wishes to disable this,
    * please also clear the list of the authorized external networks set on
    * the same instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#enable_public_ip AlloydbInstance#enable_public_ip}
    */
    readonly enablePublicIp?: boolean | cdktn.IResolvable;
    /**
    * authorized_external_networks block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#authorized_external_networks AlloydbInstance#authorized_external_networks}
    */
    readonly authorizedExternalNetworks?: AlloydbInstanceNetworkConfigAuthorizedExternalNetworks[] | cdktn.IResolvable;
}
export declare function alloydbInstanceNetworkConfigToTerraform(struct?: AlloydbInstanceNetworkConfigOutputReference | AlloydbInstanceNetworkConfig): any;
export declare function alloydbInstanceNetworkConfigToHclTerraform(struct?: AlloydbInstanceNetworkConfigOutputReference | AlloydbInstanceNetworkConfig): any;
export declare class AlloydbInstanceNetworkConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbInstanceNetworkConfig | undefined;
    set internalValue(value: AlloydbInstanceNetworkConfig | undefined);
    private _allocatedIpRangeOverride?;
    get allocatedIpRangeOverride(): string;
    set allocatedIpRangeOverride(value: string);
    resetAllocatedIpRangeOverride(): void;
    get allocatedIpRangeOverrideInput(): string | undefined;
    private _enableOutboundPublicIp?;
    get enableOutboundPublicIp(): boolean | cdktn.IResolvable;
    set enableOutboundPublicIp(value: boolean | cdktn.IResolvable);
    resetEnableOutboundPublicIp(): void;
    get enableOutboundPublicIpInput(): boolean | cdktn.IResolvable | undefined;
    private _enablePublicIp?;
    get enablePublicIp(): boolean | cdktn.IResolvable;
    set enablePublicIp(value: boolean | cdktn.IResolvable);
    resetEnablePublicIp(): void;
    get enablePublicIpInput(): boolean | cdktn.IResolvable | undefined;
    private _authorizedExternalNetworks;
    get authorizedExternalNetworks(): AlloydbInstanceNetworkConfigAuthorizedExternalNetworksList;
    putAuthorizedExternalNetworks(value: AlloydbInstanceNetworkConfigAuthorizedExternalNetworks[] | cdktn.IResolvable): void;
    resetAuthorizedExternalNetworks(): void;
    get authorizedExternalNetworksInput(): cdktn.IResolvable | AlloydbInstanceNetworkConfigAuthorizedExternalNetworks[] | undefined;
}
export interface AlloydbInstancePscInstanceConfigPscAutoConnections {
    /**
    * The consumer network for the PSC service automation, example:
    * "projects/vpc-host-project/global/networks/default".
    * The consumer network might be hosted a different project than the
    * consumer project. The API expects the consumer project specified to be
    * the project ID (and not the project number)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#consumer_network AlloydbInstance#consumer_network}
    */
    readonly consumerNetwork?: string;
    /**
    * The consumer project to which the PSC service automation endpoint will
    * be created. The API expects the consumer project to be the project ID(
    * and not the project number).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#consumer_project AlloydbInstance#consumer_project}
    */
    readonly consumerProject?: string;
}
export declare function alloydbInstancePscInstanceConfigPscAutoConnectionsToTerraform(struct?: AlloydbInstancePscInstanceConfigPscAutoConnections | cdktn.IResolvable): any;
export declare function alloydbInstancePscInstanceConfigPscAutoConnectionsToHclTerraform(struct?: AlloydbInstancePscInstanceConfigPscAutoConnections | cdktn.IResolvable): any;
export declare class AlloydbInstancePscInstanceConfigPscAutoConnectionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlloydbInstancePscInstanceConfigPscAutoConnections | cdktn.IResolvable | undefined;
    set internalValue(value: AlloydbInstancePscInstanceConfigPscAutoConnections | cdktn.IResolvable | undefined);
    private _consumerNetwork?;
    get consumerNetwork(): string;
    set consumerNetwork(value: string);
    resetConsumerNetwork(): void;
    get consumerNetworkInput(): string | undefined;
    get consumerNetworkStatus(): string;
    private _consumerProject?;
    get consumerProject(): string;
    set consumerProject(value: string);
    resetConsumerProject(): void;
    get consumerProjectInput(): string | undefined;
    get ipAddress(): string;
    get status(): string;
}
export declare class AlloydbInstancePscInstanceConfigPscAutoConnectionsList extends cdktn.ComplexList {
    internalValue?: AlloydbInstancePscInstanceConfigPscAutoConnections[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlloydbInstancePscInstanceConfigPscAutoConnectionsOutputReference;
}
export interface AlloydbInstancePscInstanceConfigPscInterfaceConfigs {
    /**
    * The network attachment resource created in the consumer project to which the PSC interface will be linked.
    * This is of the format: "projects/${CONSUMER_PROJECT}/regions/${REGION}/networkAttachments/${NETWORK_ATTACHMENT_NAME}".
    * The network attachment must be in the same region as the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#network_attachment_resource AlloydbInstance#network_attachment_resource}
    */
    readonly networkAttachmentResource?: string;
}
export declare function alloydbInstancePscInstanceConfigPscInterfaceConfigsToTerraform(struct?: AlloydbInstancePscInstanceConfigPscInterfaceConfigs | cdktn.IResolvable): any;
export declare function alloydbInstancePscInstanceConfigPscInterfaceConfigsToHclTerraform(struct?: AlloydbInstancePscInstanceConfigPscInterfaceConfigs | cdktn.IResolvable): any;
export declare class AlloydbInstancePscInstanceConfigPscInterfaceConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlloydbInstancePscInstanceConfigPscInterfaceConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: AlloydbInstancePscInstanceConfigPscInterfaceConfigs | cdktn.IResolvable | undefined);
    private _networkAttachmentResource?;
    get networkAttachmentResource(): string;
    set networkAttachmentResource(value: string);
    resetNetworkAttachmentResource(): void;
    get networkAttachmentResourceInput(): string | undefined;
}
export declare class AlloydbInstancePscInstanceConfigPscInterfaceConfigsList extends cdktn.ComplexList {
    internalValue?: AlloydbInstancePscInstanceConfigPscInterfaceConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlloydbInstancePscInstanceConfigPscInterfaceConfigsOutputReference;
}
export interface AlloydbInstancePscInstanceConfig {
    /**
    * List of consumer projects that are allowed to create PSC endpoints to service-attachments to this instance.
    * These should be specified as project numbers only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#allowed_consumer_projects AlloydbInstance#allowed_consumer_projects}
    */
    readonly allowedConsumerProjects?: string[];
    /**
    * psc_auto_connections block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#psc_auto_connections AlloydbInstance#psc_auto_connections}
    */
    readonly pscAutoConnections?: AlloydbInstancePscInstanceConfigPscAutoConnections[] | cdktn.IResolvable;
    /**
    * psc_interface_configs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#psc_interface_configs AlloydbInstance#psc_interface_configs}
    */
    readonly pscInterfaceConfigs?: AlloydbInstancePscInstanceConfigPscInterfaceConfigs[] | cdktn.IResolvable;
}
export declare function alloydbInstancePscInstanceConfigToTerraform(struct?: AlloydbInstancePscInstanceConfigOutputReference | AlloydbInstancePscInstanceConfig): any;
export declare function alloydbInstancePscInstanceConfigToHclTerraform(struct?: AlloydbInstancePscInstanceConfigOutputReference | AlloydbInstancePscInstanceConfig): any;
export declare class AlloydbInstancePscInstanceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbInstancePscInstanceConfig | undefined;
    set internalValue(value: AlloydbInstancePscInstanceConfig | undefined);
    private _allowedConsumerProjects?;
    get allowedConsumerProjects(): string[];
    set allowedConsumerProjects(value: string[]);
    resetAllowedConsumerProjects(): void;
    get allowedConsumerProjectsInput(): string[] | undefined;
    get pscDnsName(): string;
    get serviceAttachmentLink(): string;
    private _pscAutoConnections;
    get pscAutoConnections(): AlloydbInstancePscInstanceConfigPscAutoConnectionsList;
    putPscAutoConnections(value: AlloydbInstancePscInstanceConfigPscAutoConnections[] | cdktn.IResolvable): void;
    resetPscAutoConnections(): void;
    get pscAutoConnectionsInput(): cdktn.IResolvable | AlloydbInstancePscInstanceConfigPscAutoConnections[] | undefined;
    private _pscInterfaceConfigs;
    get pscInterfaceConfigs(): AlloydbInstancePscInstanceConfigPscInterfaceConfigsList;
    putPscInterfaceConfigs(value: AlloydbInstancePscInstanceConfigPscInterfaceConfigs[] | cdktn.IResolvable): void;
    resetPscInterfaceConfigs(): void;
    get pscInterfaceConfigsInput(): cdktn.IResolvable | AlloydbInstancePscInstanceConfigPscInterfaceConfigs[] | undefined;
}
export interface AlloydbInstanceQueryInsightsConfig {
    /**
    * Number of query execution plans captured by Insights per minute for all queries combined. The default value is 5. Any integer between 0 and 20 is considered valid.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#query_plans_per_minute AlloydbInstance#query_plans_per_minute}
    */
    readonly queryPlansPerMinute?: number;
    /**
    * Query string length. The default value is 1024. Any integer between 256 and 4500 is considered valid.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#query_string_length AlloydbInstance#query_string_length}
    */
    readonly queryStringLength?: number;
    /**
    * Record application tags for an instance. This flag is turned "on" by default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#record_application_tags AlloydbInstance#record_application_tags}
    */
    readonly recordApplicationTags?: boolean | cdktn.IResolvable;
    /**
    * Record client address for an instance. Client address is PII information. This flag is turned "on" by default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#record_client_address AlloydbInstance#record_client_address}
    */
    readonly recordClientAddress?: boolean | cdktn.IResolvable;
}
export declare function alloydbInstanceQueryInsightsConfigToTerraform(struct?: AlloydbInstanceQueryInsightsConfigOutputReference | AlloydbInstanceQueryInsightsConfig): any;
export declare function alloydbInstanceQueryInsightsConfigToHclTerraform(struct?: AlloydbInstanceQueryInsightsConfigOutputReference | AlloydbInstanceQueryInsightsConfig): any;
export declare class AlloydbInstanceQueryInsightsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbInstanceQueryInsightsConfig | undefined;
    set internalValue(value: AlloydbInstanceQueryInsightsConfig | undefined);
    private _queryPlansPerMinute?;
    get queryPlansPerMinute(): number;
    set queryPlansPerMinute(value: number);
    resetQueryPlansPerMinute(): void;
    get queryPlansPerMinuteInput(): number | undefined;
    private _queryStringLength?;
    get queryStringLength(): number;
    set queryStringLength(value: number);
    resetQueryStringLength(): void;
    get queryStringLengthInput(): number | undefined;
    private _recordApplicationTags?;
    get recordApplicationTags(): boolean | cdktn.IResolvable;
    set recordApplicationTags(value: boolean | cdktn.IResolvable);
    resetRecordApplicationTags(): void;
    get recordApplicationTagsInput(): boolean | cdktn.IResolvable | undefined;
    private _recordClientAddress?;
    get recordClientAddress(): boolean | cdktn.IResolvable;
    set recordClientAddress(value: boolean | cdktn.IResolvable);
    resetRecordClientAddress(): void;
    get recordClientAddressInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AlloydbInstanceReadPoolConfig {
    /**
    * Read capacity, i.e. number of nodes in a read pool instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#node_count AlloydbInstance#node_count}
    */
    readonly nodeCount?: number;
}
export declare function alloydbInstanceReadPoolConfigToTerraform(struct?: AlloydbInstanceReadPoolConfigOutputReference | AlloydbInstanceReadPoolConfig): any;
export declare function alloydbInstanceReadPoolConfigToHclTerraform(struct?: AlloydbInstanceReadPoolConfigOutputReference | AlloydbInstanceReadPoolConfig): any;
export declare class AlloydbInstanceReadPoolConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbInstanceReadPoolConfig | undefined;
    set internalValue(value: AlloydbInstanceReadPoolConfig | undefined);
    private _nodeCount?;
    get nodeCount(): number;
    set nodeCount(value: number);
    resetNodeCount(): void;
    get nodeCountInput(): number | undefined;
}
export interface AlloydbInstanceTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#create AlloydbInstance#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#delete AlloydbInstance#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#update AlloydbInstance#update}
    */
    readonly update?: string;
}
export declare function alloydbInstanceTimeoutsToTerraform(struct?: AlloydbInstanceTimeouts | cdktn.IResolvable): any;
export declare function alloydbInstanceTimeoutsToHclTerraform(struct?: AlloydbInstanceTimeouts | cdktn.IResolvable): any;
export declare class AlloydbInstanceTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlloydbInstanceTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AlloydbInstanceTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance google_alloydb_instance}
*/
export declare class AlloydbInstance extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_alloydb_instance";
    /**
    * Generates CDKTN code for importing a AlloydbInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AlloydbInstance to import
    * @param importFromId The id of the existing AlloydbInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AlloydbInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/alloydb_instance google_alloydb_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AlloydbInstanceConfig
    */
    constructor(scope: Construct, id: string, config: AlloydbInstanceConfig);
    private _activationPolicy?;
    get activationPolicy(): string;
    set activationPolicy(value: string);
    resetActivationPolicy(): void;
    get activationPolicyInput(): string | undefined;
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _availabilityType?;
    get availabilityType(): string;
    set availabilityType(value: string);
    resetAvailabilityType(): void;
    get availabilityTypeInput(): string | undefined;
    private _cluster?;
    get cluster(): string;
    set cluster(value: string);
    get clusterInput(): string | undefined;
    get createTime(): string;
    private _databaseFlags?;
    get databaseFlags(): {
        [key: string]: string;
    };
    set databaseFlags(value: {
        [key: string]: string;
    });
    resetDatabaseFlags(): void;
    get databaseFlagsInput(): {
        [key: string]: string;
    } | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _effectiveAnnotations;
    get effectiveAnnotations(): cdktn.StringMap;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _gceZone?;
    get gceZone(): string;
    set gceZone(value: string);
    resetGceZone(): void;
    get gceZoneInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _instanceType?;
    get instanceType(): string;
    set instanceType(value: string);
    get instanceTypeInput(): string | undefined;
    get ipAddress(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    get name(): string;
    get outboundPublicIpAddresses(): string[];
    get publicIpAddress(): string;
    get reconciling(): cdktn.IResolvable;
    get state(): string;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get uid(): string;
    get updateTime(): string;
    private _clientConnectionConfig;
    get clientConnectionConfig(): AlloydbInstanceClientConnectionConfigOutputReference;
    putClientConnectionConfig(value: AlloydbInstanceClientConnectionConfig): void;
    resetClientConnectionConfig(): void;
    get clientConnectionConfigInput(): AlloydbInstanceClientConnectionConfig | undefined;
    private _connectionPoolConfig;
    get connectionPoolConfig(): AlloydbInstanceConnectionPoolConfigOutputReference;
    putConnectionPoolConfig(value: AlloydbInstanceConnectionPoolConfig): void;
    resetConnectionPoolConfig(): void;
    get connectionPoolConfigInput(): AlloydbInstanceConnectionPoolConfig | undefined;
    private _machineConfig;
    get machineConfig(): AlloydbInstanceMachineConfigOutputReference;
    putMachineConfig(value: AlloydbInstanceMachineConfig): void;
    resetMachineConfig(): void;
    get machineConfigInput(): AlloydbInstanceMachineConfig | undefined;
    private _networkConfig;
    get networkConfig(): AlloydbInstanceNetworkConfigOutputReference;
    putNetworkConfig(value: AlloydbInstanceNetworkConfig): void;
    resetNetworkConfig(): void;
    get networkConfigInput(): AlloydbInstanceNetworkConfig | undefined;
    private _pscInstanceConfig;
    get pscInstanceConfig(): AlloydbInstancePscInstanceConfigOutputReference;
    putPscInstanceConfig(value: AlloydbInstancePscInstanceConfig): void;
    resetPscInstanceConfig(): void;
    get pscInstanceConfigInput(): AlloydbInstancePscInstanceConfig | undefined;
    private _queryInsightsConfig;
    get queryInsightsConfig(): AlloydbInstanceQueryInsightsConfigOutputReference;
    putQueryInsightsConfig(value: AlloydbInstanceQueryInsightsConfig): void;
    resetQueryInsightsConfig(): void;
    get queryInsightsConfigInput(): AlloydbInstanceQueryInsightsConfig | undefined;
    private _readPoolConfig;
    get readPoolConfig(): AlloydbInstanceReadPoolConfigOutputReference;
    putReadPoolConfig(value: AlloydbInstanceReadPoolConfig): void;
    resetReadPoolConfig(): void;
    get readPoolConfigInput(): AlloydbInstanceReadPoolConfig | undefined;
    private _timeouts;
    get timeouts(): AlloydbInstanceTimeoutsOutputReference;
    putTimeouts(value: AlloydbInstanceTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AlloydbInstanceTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
