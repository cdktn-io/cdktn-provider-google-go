/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChronicleParserConfig extends cdktn.TerraformMetaArguments {
    /**
    * if the parser is built using config
    * documentation:
    * https://cloud.google.com/chronicle/docs/preview/parser-extensions/parsing-overview
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#cbn ChronicleParser#cbn}
    */
    readonly cbn?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#deletion_policy ChronicleParser#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#id ChronicleParser#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#instance ChronicleParser#instance}
    */
    readonly instance: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#location ChronicleParser#location}
    */
    readonly location: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#logtype ChronicleParser#logtype}
    */
    readonly logtype: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#project ChronicleParser#project}
    */
    readonly project?: string;
    /**
    * Flag to bypass parser validation when no logs are found.
    * If enabled, the parser won't be be rejected during the validation
    * phase when no logs are found.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#validated_on_empty_logs ChronicleParser#validated_on_empty_logs}
    */
    readonly validatedOnEmptyLogs?: boolean | cdktn.IResolvable;
    /**
    * If true, bypasses parser validation.
    * If enabled, the parser won't be rejected during the validation
    * phase and validation will be skipped.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#validation_skipped ChronicleParser#validation_skipped}
    */
    readonly validationSkipped?: boolean | cdktn.IResolvable;
    /**
    * low_code block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#low_code ChronicleParser#low_code}
    */
    readonly lowCode?: ChronicleParserLowCode;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#timeouts ChronicleParser#timeouts}
    */
    readonly timeouts?: ChronicleParserTimeouts;
    /**
    * version_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#version_info ChronicleParser#version_info}
    */
    readonly versionInfo?: ChronicleParserVersionInfo;
}
export interface ChronicleParserChangelogsEntries {
}
export declare function chronicleParserChangelogsEntriesToTerraform(struct?: ChronicleParserChangelogsEntries): any;
export declare function chronicleParserChangelogsEntriesToHclTerraform(struct?: ChronicleParserChangelogsEntries): any;
export declare class ChronicleParserChangelogsEntriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleParserChangelogsEntries | undefined;
    set internalValue(value: ChronicleParserChangelogsEntries | undefined);
    get changeMessage(): string;
    get createTime(): string;
    get deleted(): cdktn.IResolvable;
    get parserVersion(): string;
}
export declare class ChronicleParserChangelogsEntriesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleParserChangelogsEntriesOutputReference;
}
export interface ChronicleParserChangelogs {
}
export declare function chronicleParserChangelogsToTerraform(struct?: ChronicleParserChangelogs): any;
export declare function chronicleParserChangelogsToHclTerraform(struct?: ChronicleParserChangelogs): any;
export declare class ChronicleParserChangelogsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleParserChangelogs | undefined;
    set internalValue(value: ChronicleParserChangelogs | undefined);
    private _entries;
    get entries(): ChronicleParserChangelogsEntriesList;
}
export declare class ChronicleParserChangelogsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleParserChangelogsOutputReference;
}
export interface ChronicleParserCreator {
}
export declare function chronicleParserCreatorToTerraform(struct?: ChronicleParserCreator): any;
export declare function chronicleParserCreatorToHclTerraform(struct?: ChronicleParserCreator): any;
export declare class ChronicleParserCreatorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleParserCreator | undefined;
    set internalValue(value: ChronicleParserCreator | undefined);
    get author(): string;
    get customer(): string;
    get source(): string;
}
export declare class ChronicleParserCreatorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleParserCreatorOutputReference;
}
export interface ChronicleParserLowCodeFieldExtractorsExtractors {
    /**
    * Path in generated event which is to be populated. This is required if the
    * FieldExtractor is used to specify the parser extension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#destination_path ChronicleParser#destination_path}
    */
    readonly destinationPath?: string;
    /**
    * Field path could be a json path, xml path or csv column name
    * depending on log format. It refers to a section or substring in raw log.
    * This is required if the FieldExtractor is used to specify the parser
    * extension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#field_path ChronicleParser#field_path}
    */
    readonly fieldPath?: string;
    /**
    * Operator used for precondition.
    * Possible values:
    * EQUALS
    * NOT_EQUALS
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#precondition_op ChronicleParser#precondition_op}
    */
    readonly preconditionOp?: string;
    /**
    * Precondition path could be a json path, xml path or csv column name
    * depending on log format. It refers to a section or substring in raw log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#precondition_path ChronicleParser#precondition_path}
    */
    readonly preconditionPath?: string;
    /**
    * Precondition value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#precondition_value ChronicleParser#precondition_value}
    */
    readonly preconditionValue?: string;
    /**
    * Value to be mapped to the destination path directly.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#value ChronicleParser#value}
    */
    readonly value?: string;
}
export declare function chronicleParserLowCodeFieldExtractorsExtractorsToTerraform(struct?: ChronicleParserLowCodeFieldExtractorsExtractors | cdktn.IResolvable): any;
export declare function chronicleParserLowCodeFieldExtractorsExtractorsToHclTerraform(struct?: ChronicleParserLowCodeFieldExtractorsExtractors | cdktn.IResolvable): any;
export declare class ChronicleParserLowCodeFieldExtractorsExtractorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleParserLowCodeFieldExtractorsExtractors | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleParserLowCodeFieldExtractorsExtractors | cdktn.IResolvable | undefined);
    private _destinationPath?;
    get destinationPath(): string;
    set destinationPath(value: string);
    resetDestinationPath(): void;
    get destinationPathInput(): string | undefined;
    private _fieldPath?;
    get fieldPath(): string;
    set fieldPath(value: string);
    resetFieldPath(): void;
    get fieldPathInput(): string | undefined;
    private _preconditionOp?;
    get preconditionOp(): string;
    set preconditionOp(value: string);
    resetPreconditionOp(): void;
    get preconditionOpInput(): string | undefined;
    private _preconditionPath?;
    get preconditionPath(): string;
    set preconditionPath(value: string);
    resetPreconditionPath(): void;
    get preconditionPathInput(): string | undefined;
    private _preconditionValue?;
    get preconditionValue(): string;
    set preconditionValue(value: string);
    resetPreconditionValue(): void;
    get preconditionValueInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ChronicleParserLowCodeFieldExtractorsExtractorsList extends cdktn.ComplexList {
    internalValue?: ChronicleParserLowCodeFieldExtractorsExtractors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleParserLowCodeFieldExtractorsExtractorsOutputReference;
}
export interface ChronicleParserLowCodeFieldExtractorsPreprocessConfig {
    /**
    * GROK Regex to extract the structured part of the log.
    * syntax documentation:
    * www.elastic.co/guide/en/logstash/current/plugins-filters-grok.html
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#grok_regex ChronicleParser#grok_regex}
    */
    readonly grokRegex?: string;
    /**
    * Target field name for the structured part of the log.
    * This should match a SEMANTIC identifier from the grok expression.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#target ChronicleParser#target}
    */
    readonly target?: string;
}
export declare function chronicleParserLowCodeFieldExtractorsPreprocessConfigToTerraform(struct?: ChronicleParserLowCodeFieldExtractorsPreprocessConfigOutputReference | ChronicleParserLowCodeFieldExtractorsPreprocessConfig): any;
export declare function chronicleParserLowCodeFieldExtractorsPreprocessConfigToHclTerraform(struct?: ChronicleParserLowCodeFieldExtractorsPreprocessConfigOutputReference | ChronicleParserLowCodeFieldExtractorsPreprocessConfig): any;
export declare class ChronicleParserLowCodeFieldExtractorsPreprocessConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleParserLowCodeFieldExtractorsPreprocessConfig | undefined;
    set internalValue(value: ChronicleParserLowCodeFieldExtractorsPreprocessConfig | undefined);
    private _grokRegex?;
    get grokRegex(): string;
    set grokRegex(value: string);
    resetGrokRegex(): void;
    get grokRegexInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    resetTarget(): void;
    get targetInput(): string | undefined;
}
export interface ChronicleParserLowCodeFieldExtractors {
    /**
    * Whether to append repeated fields or not.
    * When false, repeated fields will be replaced.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#append_repeated_fields ChronicleParser#append_repeated_fields}
    */
    readonly appendRepeatedFields?: boolean | cdktn.IResolvable;
    /**
    * Possible values:
    * JSON
    * CSV
    * XML
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#log_format ChronicleParser#log_format}
    */
    readonly logFormat?: string;
    /**
    * extractors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#extractors ChronicleParser#extractors}
    */
    readonly extractors?: ChronicleParserLowCodeFieldExtractorsExtractors[] | cdktn.IResolvable;
    /**
    * preprocess_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#preprocess_config ChronicleParser#preprocess_config}
    */
    readonly preprocessConfig?: ChronicleParserLowCodeFieldExtractorsPreprocessConfig;
}
export declare function chronicleParserLowCodeFieldExtractorsToTerraform(struct?: ChronicleParserLowCodeFieldExtractorsOutputReference | ChronicleParserLowCodeFieldExtractors): any;
export declare function chronicleParserLowCodeFieldExtractorsToHclTerraform(struct?: ChronicleParserLowCodeFieldExtractorsOutputReference | ChronicleParserLowCodeFieldExtractors): any;
export declare class ChronicleParserLowCodeFieldExtractorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleParserLowCodeFieldExtractors | undefined;
    set internalValue(value: ChronicleParserLowCodeFieldExtractors | undefined);
    private _appendRepeatedFields?;
    get appendRepeatedFields(): boolean | cdktn.IResolvable;
    set appendRepeatedFields(value: boolean | cdktn.IResolvable);
    resetAppendRepeatedFields(): void;
    get appendRepeatedFieldsInput(): boolean | cdktn.IResolvable | undefined;
    private _logFormat?;
    get logFormat(): string;
    set logFormat(value: string);
    resetLogFormat(): void;
    get logFormatInput(): string | undefined;
    get transformedCbnSnippet(): string;
    private _extractors;
    get extractors(): ChronicleParserLowCodeFieldExtractorsExtractorsList;
    putExtractors(value: ChronicleParserLowCodeFieldExtractorsExtractors[] | cdktn.IResolvable): void;
    resetExtractors(): void;
    get extractorsInput(): cdktn.IResolvable | ChronicleParserLowCodeFieldExtractorsExtractors[] | undefined;
    private _preprocessConfig;
    get preprocessConfig(): ChronicleParserLowCodeFieldExtractorsPreprocessConfigOutputReference;
    putPreprocessConfig(value: ChronicleParserLowCodeFieldExtractorsPreprocessConfig): void;
    resetPreprocessConfig(): void;
    get preprocessConfigInput(): ChronicleParserLowCodeFieldExtractorsPreprocessConfig | undefined;
}
export interface ChronicleParserLowCode {
    /**
    * The log used to create this low code parser in the UI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#log ChronicleParser#log}
    */
    readonly log?: string;
    /**
    * field_extractors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#field_extractors ChronicleParser#field_extractors}
    */
    readonly fieldExtractors?: ChronicleParserLowCodeFieldExtractors;
}
export declare function chronicleParserLowCodeToTerraform(struct?: ChronicleParserLowCodeOutputReference | ChronicleParserLowCode): any;
export declare function chronicleParserLowCodeToHclTerraform(struct?: ChronicleParserLowCodeOutputReference | ChronicleParserLowCode): any;
export declare class ChronicleParserLowCodeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleParserLowCode | undefined;
    set internalValue(value: ChronicleParserLowCode | undefined);
    private _log?;
    get log(): string;
    set log(value: string);
    resetLog(): void;
    get logInput(): string | undefined;
    private _fieldExtractors;
    get fieldExtractors(): ChronicleParserLowCodeFieldExtractorsOutputReference;
    putFieldExtractors(value: ChronicleParserLowCodeFieldExtractors): void;
    resetFieldExtractors(): void;
    get fieldExtractorsInput(): ChronicleParserLowCodeFieldExtractors | undefined;
}
export interface ChronicleParserTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#create ChronicleParser#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#delete ChronicleParser#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#update ChronicleParser#update}
    */
    readonly update?: string;
}
export declare function chronicleParserTimeoutsToTerraform(struct?: ChronicleParserTimeouts | cdktn.IResolvable): any;
export declare function chronicleParserTimeoutsToHclTerraform(struct?: ChronicleParserTimeouts | cdktn.IResolvable): any;
export declare class ChronicleParserTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleParserTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleParserTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface ChronicleParserVersionInfo {
    /**
    * Signifies if the parser is disabled for auto upgrade. If true, the parser
    * will not be upgraded by the auto upgrade process.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#auto_upgrade_disabled ChronicleParser#auto_upgrade_disabled}
    */
    readonly autoUpgradeDisabled: boolean | cdktn.IResolvable;
}
export declare function chronicleParserVersionInfoToTerraform(struct?: ChronicleParserVersionInfoOutputReference | ChronicleParserVersionInfo): any;
export declare function chronicleParserVersionInfoToHclTerraform(struct?: ChronicleParserVersionInfoOutputReference | ChronicleParserVersionInfo): any;
export declare class ChronicleParserVersionInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleParserVersionInfo | undefined;
    set internalValue(value: ChronicleParserVersionInfo | undefined);
    private _autoUpgradeDisabled?;
    get autoUpgradeDisabled(): boolean | cdktn.IResolvable;
    set autoUpgradeDisabled(value: boolean | cdktn.IResolvable);
    get autoUpgradeDisabledInput(): boolean | cdktn.IResolvable | undefined;
    get latestParser(): string;
    get latestParserVersion(): string;
    get rollbackAvailable(): cdktn.IResolvable;
    get version(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser google_chronicle_parser}
*/
export declare class ChronicleParser extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_chronicle_parser";
    /**
    * Generates CDKTN code for importing a ChronicleParser resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChronicleParser to import
    * @param importFromId The id of the existing ChronicleParser that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChronicleParser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_parser google_chronicle_parser} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChronicleParserConfig
    */
    constructor(scope: Construct, id: string, config: ChronicleParserConfig);
    private _cbn?;
    get cbn(): string;
    set cbn(value: string);
    resetCbn(): void;
    get cbnInput(): string | undefined;
    private _changelogs;
    get changelogs(): ChronicleParserChangelogsList;
    get createTime(): string;
    private _creator;
    get creator(): ChronicleParserCreatorList;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    get dynamicParsingConfig(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instance?;
    get instance(): string;
    set instance(value: string);
    get instanceInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _logtype?;
    get logtype(): string;
    set logtype(value: string);
    get logtypeInput(): string | undefined;
    get name(): string;
    get parser(): string;
    get parserExtension(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get releaseStage(): string;
    get state(): string;
    get type(): string;
    private _validatedOnEmptyLogs?;
    get validatedOnEmptyLogs(): boolean | cdktn.IResolvable;
    set validatedOnEmptyLogs(value: boolean | cdktn.IResolvable);
    resetValidatedOnEmptyLogs(): void;
    get validatedOnEmptyLogsInput(): boolean | cdktn.IResolvable | undefined;
    get validationReport(): string;
    private _validationSkipped?;
    get validationSkipped(): boolean | cdktn.IResolvable;
    set validationSkipped(value: boolean | cdktn.IResolvable);
    resetValidationSkipped(): void;
    get validationSkippedInput(): boolean | cdktn.IResolvable | undefined;
    get validationStage(): string;
    private _lowCode;
    get lowCode(): ChronicleParserLowCodeOutputReference;
    putLowCode(value: ChronicleParserLowCode): void;
    resetLowCode(): void;
    get lowCodeInput(): ChronicleParserLowCode | undefined;
    private _timeouts;
    get timeouts(): ChronicleParserTimeoutsOutputReference;
    putTimeouts(value: ChronicleParserTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ChronicleParserTimeouts | undefined;
    private _versionInfo;
    get versionInfo(): ChronicleParserVersionInfoOutputReference;
    putVersionInfo(value: ChronicleParserVersionInfo): void;
    resetVersionInfo(): void;
    get versionInfoInput(): ChronicleParserVersionInfo | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
