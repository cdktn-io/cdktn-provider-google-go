/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudSchedulerJobConfig extends cdktn.TerraformMetaArguments {
    /**
    * The deadline for job attempts. If the request handler does not respond by this deadline then the request is
    * cancelled and the attempt is marked as a DEADLINE_EXCEEDED failure. The failed attempt can be viewed in
    * execution logs. Cloud Scheduler will retry the job according to the RetryConfig.
    * The allowed duration for this deadline is:
    * * For HTTP targets, between 15 seconds and 30 minutes.
    * * For App Engine HTTP targets, between 15 seconds and 24 hours.
    * * **Note**: For PubSub targets, this field is ignored - setting it will introduce an unresolvable diff.
    * A duration in seconds with up to nine fractional digits, terminated by 's'. Example: "3.5s"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#attempt_deadline CloudSchedulerJob#attempt_deadline}
    */
    readonly attemptDeadline?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#deletion_policy CloudSchedulerJob#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * A human-readable description for the job.
    * This string must not contain more than 500 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#description CloudSchedulerJob#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#id CloudSchedulerJob#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the job.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#name CloudSchedulerJob#name}
    */
    readonly name: string;
    /**
    * Sets the job to a paused state. Jobs default to being enabled when this property is not set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#paused CloudSchedulerJob#paused}
    */
    readonly paused?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#project CloudSchedulerJob#project}
    */
    readonly project?: string;
    /**
    * Region where the scheduler job resides. If it is not provided, Terraform will use the provider default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#region CloudSchedulerJob#region}
    */
    readonly region?: string;
    /**
    * Describes the schedule on which the job will be executed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#schedule CloudSchedulerJob#schedule}
    */
    readonly schedule?: string;
    /**
    * Specifies the time zone to be used in interpreting schedule.
    * The value of this field must be a time zone name from the tz database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#time_zone CloudSchedulerJob#time_zone}
    */
    readonly timeZone?: string;
    /**
    * app_engine_http_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#app_engine_http_target CloudSchedulerJob#app_engine_http_target}
    */
    readonly appEngineHttpTarget?: CloudSchedulerJobAppEngineHttpTarget;
    /**
    * http_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#http_target CloudSchedulerJob#http_target}
    */
    readonly httpTarget?: CloudSchedulerJobHttpTarget;
    /**
    * pubsub_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#pubsub_target CloudSchedulerJob#pubsub_target}
    */
    readonly pubsubTarget?: CloudSchedulerJobPubsubTarget;
    /**
    * retry_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#retry_config CloudSchedulerJob#retry_config}
    */
    readonly retryConfig?: CloudSchedulerJobRetryConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#timeouts CloudSchedulerJob#timeouts}
    */
    readonly timeouts?: CloudSchedulerJobTimeouts;
}
export interface CloudSchedulerJobAppEngineHttpTargetAppEngineRouting {
    /**
    * App instance.
    * By default, the job is sent to an instance which is available when the job is attempted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#instance CloudSchedulerJob#instance}
    */
    readonly instance?: string;
    /**
    * App service.
    * By default, the job is sent to the service which is the default service when the job is attempted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#service CloudSchedulerJob#service}
    */
    readonly service?: string;
    /**
    * App version.
    * By default, the job is sent to the version which is the default version when the job is attempted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#version CloudSchedulerJob#version}
    */
    readonly version?: string;
}
export declare function cloudSchedulerJobAppEngineHttpTargetAppEngineRoutingToTerraform(struct?: CloudSchedulerJobAppEngineHttpTargetAppEngineRoutingOutputReference | CloudSchedulerJobAppEngineHttpTargetAppEngineRouting): any;
export declare function cloudSchedulerJobAppEngineHttpTargetAppEngineRoutingToHclTerraform(struct?: CloudSchedulerJobAppEngineHttpTargetAppEngineRoutingOutputReference | CloudSchedulerJobAppEngineHttpTargetAppEngineRouting): any;
export declare class CloudSchedulerJobAppEngineHttpTargetAppEngineRoutingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudSchedulerJobAppEngineHttpTargetAppEngineRouting | undefined;
    set internalValue(value: CloudSchedulerJobAppEngineHttpTargetAppEngineRouting | undefined);
    private _instance?;
    get instance(): string;
    set instance(value: string);
    resetInstance(): void;
    get instanceInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export interface CloudSchedulerJobAppEngineHttpTarget {
    /**
    * HTTP request body.
    * A request body is allowed only if the HTTP method is POST or PUT.
    * It will result in invalid argument error to set a body on a job with an incompatible HttpMethod.
    *
    * A base64-encoded string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#body CloudSchedulerJob#body}
    */
    readonly body?: string;
    /**
    * HTTP request headers.
    * This map contains the header field names and values.
    * Headers can be set when the job is created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#headers CloudSchedulerJob#headers}
    */
    readonly headers?: {
        [key: string]: string;
    };
    /**
    * Which HTTP method to use for the request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#http_method CloudSchedulerJob#http_method}
    */
    readonly httpMethod?: string;
    /**
    * The relative URI.
    * The relative URL must begin with "/" and must be a valid HTTP relative URL.
    * It can contain a path, query string arguments, and \# fragments.
    * If the relative URL is empty, then the root path "/" will be used.
    * No spaces are allowed, and the maximum length allowed is 2083 characters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#relative_uri CloudSchedulerJob#relative_uri}
    */
    readonly relativeUri: string;
    /**
    * app_engine_routing block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#app_engine_routing CloudSchedulerJob#app_engine_routing}
    */
    readonly appEngineRouting?: CloudSchedulerJobAppEngineHttpTargetAppEngineRouting;
}
export declare function cloudSchedulerJobAppEngineHttpTargetToTerraform(struct?: CloudSchedulerJobAppEngineHttpTargetOutputReference | CloudSchedulerJobAppEngineHttpTarget): any;
export declare function cloudSchedulerJobAppEngineHttpTargetToHclTerraform(struct?: CloudSchedulerJobAppEngineHttpTargetOutputReference | CloudSchedulerJobAppEngineHttpTarget): any;
export declare class CloudSchedulerJobAppEngineHttpTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudSchedulerJobAppEngineHttpTarget | undefined;
    set internalValue(value: CloudSchedulerJobAppEngineHttpTarget | undefined);
    private _body?;
    get body(): string;
    set body(value: string);
    resetBody(): void;
    get bodyInput(): string | undefined;
    private _headers?;
    get headers(): {
        [key: string]: string;
    };
    set headers(value: {
        [key: string]: string;
    });
    resetHeaders(): void;
    get headersInput(): {
        [key: string]: string;
    } | undefined;
    private _httpMethod?;
    get httpMethod(): string;
    set httpMethod(value: string);
    resetHttpMethod(): void;
    get httpMethodInput(): string | undefined;
    private _relativeUri?;
    get relativeUri(): string;
    set relativeUri(value: string);
    get relativeUriInput(): string | undefined;
    private _appEngineRouting;
    get appEngineRouting(): CloudSchedulerJobAppEngineHttpTargetAppEngineRoutingOutputReference;
    putAppEngineRouting(value: CloudSchedulerJobAppEngineHttpTargetAppEngineRouting): void;
    resetAppEngineRouting(): void;
    get appEngineRoutingInput(): CloudSchedulerJobAppEngineHttpTargetAppEngineRouting | undefined;
}
export interface CloudSchedulerJobHttpTargetOauthToken {
    /**
    * OAuth scope to be used for generating OAuth access token. If not specified,
    * "https://www.googleapis.com/auth/cloud-platform" will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#scope CloudSchedulerJob#scope}
    */
    readonly scope?: string;
    /**
    * Service account email to be used for generating OAuth token.
    * The service account must be within the same project as the job.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#service_account_email CloudSchedulerJob#service_account_email}
    */
    readonly serviceAccountEmail: string;
}
export declare function cloudSchedulerJobHttpTargetOauthTokenToTerraform(struct?: CloudSchedulerJobHttpTargetOauthTokenOutputReference | CloudSchedulerJobHttpTargetOauthToken): any;
export declare function cloudSchedulerJobHttpTargetOauthTokenToHclTerraform(struct?: CloudSchedulerJobHttpTargetOauthTokenOutputReference | CloudSchedulerJobHttpTargetOauthToken): any;
export declare class CloudSchedulerJobHttpTargetOauthTokenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudSchedulerJobHttpTargetOauthToken | undefined;
    set internalValue(value: CloudSchedulerJobHttpTargetOauthToken | undefined);
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
    private _serviceAccountEmail?;
    get serviceAccountEmail(): string;
    set serviceAccountEmail(value: string);
    get serviceAccountEmailInput(): string | undefined;
}
export interface CloudSchedulerJobHttpTargetOidcToken {
    /**
    * Audience to be used when generating OIDC token. If not specified,
    * the URI specified in target will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#audience CloudSchedulerJob#audience}
    */
    readonly audience?: string;
    /**
    * Service account email to be used for generating OAuth token.
    * The service account must be within the same project as the job.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#service_account_email CloudSchedulerJob#service_account_email}
    */
    readonly serviceAccountEmail: string;
}
export declare function cloudSchedulerJobHttpTargetOidcTokenToTerraform(struct?: CloudSchedulerJobHttpTargetOidcTokenOutputReference | CloudSchedulerJobHttpTargetOidcToken): any;
export declare function cloudSchedulerJobHttpTargetOidcTokenToHclTerraform(struct?: CloudSchedulerJobHttpTargetOidcTokenOutputReference | CloudSchedulerJobHttpTargetOidcToken): any;
export declare class CloudSchedulerJobHttpTargetOidcTokenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudSchedulerJobHttpTargetOidcToken | undefined;
    set internalValue(value: CloudSchedulerJobHttpTargetOidcToken | undefined);
    private _audience?;
    get audience(): string;
    set audience(value: string);
    resetAudience(): void;
    get audienceInput(): string | undefined;
    private _serviceAccountEmail?;
    get serviceAccountEmail(): string;
    set serviceAccountEmail(value: string);
    get serviceAccountEmailInput(): string | undefined;
}
export interface CloudSchedulerJobHttpTarget {
    /**
    * HTTP request body.
    * A request body is allowed only if the HTTP method is POST, PUT, or PATCH.
    * It is an error to set body on a job with an incompatible HttpMethod.
    *
    * A base64-encoded string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#body CloudSchedulerJob#body}
    */
    readonly body?: string;
    /**
    * This map contains the header field names and values.
    * Repeated headers are not supported, but a header value can contain commas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#headers CloudSchedulerJob#headers}
    */
    readonly headers?: {
        [key: string]: string;
    };
    /**
    * Which HTTP method to use for the request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#http_method CloudSchedulerJob#http_method}
    */
    readonly httpMethod?: string;
    /**
    * The full URI path that the request will be sent to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#uri CloudSchedulerJob#uri}
    */
    readonly uri: string;
    /**
    * oauth_token block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#oauth_token CloudSchedulerJob#oauth_token}
    */
    readonly oauthToken?: CloudSchedulerJobHttpTargetOauthToken;
    /**
    * oidc_token block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#oidc_token CloudSchedulerJob#oidc_token}
    */
    readonly oidcToken?: CloudSchedulerJobHttpTargetOidcToken;
}
export declare function cloudSchedulerJobHttpTargetToTerraform(struct?: CloudSchedulerJobHttpTargetOutputReference | CloudSchedulerJobHttpTarget): any;
export declare function cloudSchedulerJobHttpTargetToHclTerraform(struct?: CloudSchedulerJobHttpTargetOutputReference | CloudSchedulerJobHttpTarget): any;
export declare class CloudSchedulerJobHttpTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudSchedulerJobHttpTarget | undefined;
    set internalValue(value: CloudSchedulerJobHttpTarget | undefined);
    private _body?;
    get body(): string;
    set body(value: string);
    resetBody(): void;
    get bodyInput(): string | undefined;
    private _headers?;
    get headers(): {
        [key: string]: string;
    };
    set headers(value: {
        [key: string]: string;
    });
    resetHeaders(): void;
    get headersInput(): {
        [key: string]: string;
    } | undefined;
    private _httpMethod?;
    get httpMethod(): string;
    set httpMethod(value: string);
    resetHttpMethod(): void;
    get httpMethodInput(): string | undefined;
    private _uri?;
    get uri(): string;
    set uri(value: string);
    get uriInput(): string | undefined;
    private _oauthToken;
    get oauthToken(): CloudSchedulerJobHttpTargetOauthTokenOutputReference;
    putOauthToken(value: CloudSchedulerJobHttpTargetOauthToken): void;
    resetOauthToken(): void;
    get oauthTokenInput(): CloudSchedulerJobHttpTargetOauthToken | undefined;
    private _oidcToken;
    get oidcToken(): CloudSchedulerJobHttpTargetOidcTokenOutputReference;
    putOidcToken(value: CloudSchedulerJobHttpTargetOidcToken): void;
    resetOidcToken(): void;
    get oidcTokenInput(): CloudSchedulerJobHttpTargetOidcToken | undefined;
}
export interface CloudSchedulerJobPubsubTarget {
    /**
    * Attributes for PubsubMessage.
    * Pubsub message must contain either non-empty data, or at least one attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#attributes CloudSchedulerJob#attributes}
    */
    readonly attributes?: {
        [key: string]: string;
    };
    /**
    * The message payload for PubsubMessage.
    * Pubsub message must contain either non-empty data, or at least one attribute.
    *
    *  A base64-encoded string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#data CloudSchedulerJob#data}
    */
    readonly data?: string;
    /**
    * The full resource name for the Cloud Pub/Sub topic to which
    * messages will be published when a job is delivered. ~>**NOTE:**
    * The topic name must be in the same format as required by PubSub's
    * PublishRequest.name, e.g. 'projects/my-project/topics/my-topic'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#topic_name CloudSchedulerJob#topic_name}
    */
    readonly topicName: string;
}
export declare function cloudSchedulerJobPubsubTargetToTerraform(struct?: CloudSchedulerJobPubsubTargetOutputReference | CloudSchedulerJobPubsubTarget): any;
export declare function cloudSchedulerJobPubsubTargetToHclTerraform(struct?: CloudSchedulerJobPubsubTargetOutputReference | CloudSchedulerJobPubsubTarget): any;
export declare class CloudSchedulerJobPubsubTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudSchedulerJobPubsubTarget | undefined;
    set internalValue(value: CloudSchedulerJobPubsubTarget | undefined);
    private _attributes?;
    get attributes(): {
        [key: string]: string;
    };
    set attributes(value: {
        [key: string]: string;
    });
    resetAttributes(): void;
    get attributesInput(): {
        [key: string]: string;
    } | undefined;
    private _data?;
    get data(): string;
    set data(value: string);
    resetData(): void;
    get dataInput(): string | undefined;
    private _topicName?;
    get topicName(): string;
    set topicName(value: string);
    get topicNameInput(): string | undefined;
}
export interface CloudSchedulerJobRetryConfig {
    /**
    * The maximum amount of time to wait before retrying a job after it fails.
    * A duration in seconds with up to nine fractional digits, terminated by 's'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#max_backoff_duration CloudSchedulerJob#max_backoff_duration}
    */
    readonly maxBackoffDuration?: string;
    /**
    * The time between retries will double maxDoublings times.
    * A job's retry interval starts at minBackoffDuration,
    * then doubles maxDoublings times, then increases linearly,
    * and finally retries retries at intervals of maxBackoffDuration up to retryCount times.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#max_doublings CloudSchedulerJob#max_doublings}
    */
    readonly maxDoublings?: number;
    /**
    * The time limit for retrying a failed job, measured from time when an execution was first attempted.
    * If specified with retryCount, the job will be retried until both limits are reached.
    * A duration in seconds with up to nine fractional digits, terminated by 's'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#max_retry_duration CloudSchedulerJob#max_retry_duration}
    */
    readonly maxRetryDuration?: string;
    /**
    * The minimum amount of time to wait before retrying a job after it fails.
    * A duration in seconds with up to nine fractional digits, terminated by 's'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#min_backoff_duration CloudSchedulerJob#min_backoff_duration}
    */
    readonly minBackoffDuration?: string;
    /**
    * The number of attempts that the system will make to run a
    * job using the exponential backoff procedure described by maxDoublings.
    * Values greater than 5 and negative values are not allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#retry_count CloudSchedulerJob#retry_count}
    */
    readonly retryCount?: number;
}
export declare function cloudSchedulerJobRetryConfigToTerraform(struct?: CloudSchedulerJobRetryConfigOutputReference | CloudSchedulerJobRetryConfig): any;
export declare function cloudSchedulerJobRetryConfigToHclTerraform(struct?: CloudSchedulerJobRetryConfigOutputReference | CloudSchedulerJobRetryConfig): any;
export declare class CloudSchedulerJobRetryConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudSchedulerJobRetryConfig | undefined;
    set internalValue(value: CloudSchedulerJobRetryConfig | undefined);
    private _maxBackoffDuration?;
    get maxBackoffDuration(): string;
    set maxBackoffDuration(value: string);
    resetMaxBackoffDuration(): void;
    get maxBackoffDurationInput(): string | undefined;
    private _maxDoublings?;
    get maxDoublings(): number;
    set maxDoublings(value: number);
    resetMaxDoublings(): void;
    get maxDoublingsInput(): number | undefined;
    private _maxRetryDuration?;
    get maxRetryDuration(): string;
    set maxRetryDuration(value: string);
    resetMaxRetryDuration(): void;
    get maxRetryDurationInput(): string | undefined;
    private _minBackoffDuration?;
    get minBackoffDuration(): string;
    set minBackoffDuration(value: string);
    resetMinBackoffDuration(): void;
    get minBackoffDurationInput(): string | undefined;
    private _retryCount?;
    get retryCount(): number;
    set retryCount(value: number);
    resetRetryCount(): void;
    get retryCountInput(): number | undefined;
}
export interface CloudSchedulerJobTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#create CloudSchedulerJob#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#delete CloudSchedulerJob#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#update CloudSchedulerJob#update}
    */
    readonly update?: string;
}
export declare function cloudSchedulerJobTimeoutsToTerraform(struct?: CloudSchedulerJobTimeouts | cdktn.IResolvable): any;
export declare function cloudSchedulerJobTimeoutsToHclTerraform(struct?: CloudSchedulerJobTimeouts | cdktn.IResolvable): any;
export declare class CloudSchedulerJobTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudSchedulerJobTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CloudSchedulerJobTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job google_cloud_scheduler_job}
*/
export declare class CloudSchedulerJob extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_cloud_scheduler_job";
    /**
    * Generates CDKTN code for importing a CloudSchedulerJob resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudSchedulerJob to import
    * @param importFromId The id of the existing CloudSchedulerJob that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudSchedulerJob to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/cloud_scheduler_job google_cloud_scheduler_job} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudSchedulerJobConfig
    */
    constructor(scope: Construct, id: string, config: CloudSchedulerJobConfig);
    private _attemptDeadline?;
    get attemptDeadline(): string;
    set attemptDeadline(value: string);
    resetAttemptDeadline(): void;
    get attemptDeadlineInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _paused?;
    get paused(): boolean | cdktn.IResolvable;
    set paused(value: boolean | cdktn.IResolvable);
    resetPaused(): void;
    get pausedInput(): boolean | cdktn.IResolvable | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _schedule?;
    get schedule(): string;
    set schedule(value: string);
    resetSchedule(): void;
    get scheduleInput(): string | undefined;
    get state(): string;
    private _timeZone?;
    get timeZone(): string;
    set timeZone(value: string);
    resetTimeZone(): void;
    get timeZoneInput(): string | undefined;
    private _appEngineHttpTarget;
    get appEngineHttpTarget(): CloudSchedulerJobAppEngineHttpTargetOutputReference;
    putAppEngineHttpTarget(value: CloudSchedulerJobAppEngineHttpTarget): void;
    resetAppEngineHttpTarget(): void;
    get appEngineHttpTargetInput(): CloudSchedulerJobAppEngineHttpTarget | undefined;
    private _httpTarget;
    get httpTarget(): CloudSchedulerJobHttpTargetOutputReference;
    putHttpTarget(value: CloudSchedulerJobHttpTarget): void;
    resetHttpTarget(): void;
    get httpTargetInput(): CloudSchedulerJobHttpTarget | undefined;
    private _pubsubTarget;
    get pubsubTarget(): CloudSchedulerJobPubsubTargetOutputReference;
    putPubsubTarget(value: CloudSchedulerJobPubsubTarget): void;
    resetPubsubTarget(): void;
    get pubsubTargetInput(): CloudSchedulerJobPubsubTarget | undefined;
    private _retryConfig;
    get retryConfig(): CloudSchedulerJobRetryConfigOutputReference;
    putRetryConfig(value: CloudSchedulerJobRetryConfig): void;
    resetRetryConfig(): void;
    get retryConfigInput(): CloudSchedulerJobRetryConfig | undefined;
    private _timeouts;
    get timeouts(): CloudSchedulerJobTimeoutsOutputReference;
    putTimeouts(value: CloudSchedulerJobTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CloudSchedulerJobTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
