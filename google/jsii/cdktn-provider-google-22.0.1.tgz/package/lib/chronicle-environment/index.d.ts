/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChronicleEnvironmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Environment nicknames.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment#aliases_json ChronicleEnvironment#aliases_json}
    */
    readonly aliasesJson?: string;
    /**
    * Environment icon.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment#base64_image ChronicleEnvironment#base64_image}
    */
    readonly base64Image?: string;
    /**
    * MAX_NAME_LENGTH = 256
    * Name of the contact for the environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment#contact ChronicleEnvironment#contact}
    */
    readonly contact: string;
    /**
    * MAX_NAME_LENGTH = 256
    * Email of the contact for the environment. Multiple emails can be sepereated with the ';' character.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment#contact_emails ChronicleEnvironment#contact_emails}
    */
    readonly contactEmails: string;
    /**
    * MAX_NAME_LENGTH = 256
    * Phone number of the contact for the environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment#contact_phone ChronicleEnvironment#contact_phone}
    */
    readonly contactPhone: string;
    /**
    * data access scopes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment#data_access_scopes_json ChronicleEnvironment#data_access_scopes_json}
    */
    readonly dataAccessScopesJson?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment#deletion_policy ChronicleEnvironment#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Whether Terraform will be prevented from destroying the environment. Deleting an environment will remove all its data and all playbooks, environments, integrations instances, reports and agents related to the environment. Once you delete an environment, it cannot be reversed. Deleting environments via terraform destroy or terraform apply will only succeed if this field is false in the Terraform state.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment#deletion_protection ChronicleEnvironment#deletion_protection}
    */
    readonly deletionProtection?: boolean | cdktn.IResolvable;
    /**
    * MAX_NAME_LENGTH = 256
    * Description of the environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment#description ChronicleEnvironment#description}
    */
    readonly description: string;
    /**
    * Name of the environment
    * MAX_NAME_LENGTH = 256
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment#display_name ChronicleEnvironment#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment#id ChronicleEnvironment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment#instance ChronicleEnvironment#instance}
    */
    readonly instance: string;
    /**
    * URL of the environment. Used to route UI links to the correct SIEM instance
    * when making cross-SecOps requests from SOAR.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment#instance_uri ChronicleEnvironment#instance_uri}
    */
    readonly instanceUri?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment#location ChronicleEnvironment#location}
    */
    readonly location: string;
    /**
    * The optional parallel SIEM instance used as a data source. Used to route
    * API requests to the correct SIEM instance when making cross-SecOps requests
    * from SOAR. For most customers, this is not required, since the parent
    * instance is used as the data source by default.
    * Format:
    * projects/{project}/locations/{location}/instances/{instance}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment#parallel_instance ChronicleEnvironment#parallel_instance}
    */
    readonly parallelInstance?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment#project ChronicleEnvironment#project}
    */
    readonly project?: string;
    /**
    * Environment data retention in months.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment#retention_duration ChronicleEnvironment#retention_duration}
    */
    readonly retentionDuration: number;
    /**
    * The weight of the environment, enabling customers to control distribution
    * of resources between the separate environments in a single instance of
    * Chronicle SOAR.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment#weight ChronicleEnvironment#weight}
    */
    readonly weight?: number;
    /**
    * dynamic_parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment#dynamic_parameters ChronicleEnvironment#dynamic_parameters}
    */
    readonly dynamicParameters?: ChronicleEnvironmentDynamicParameters[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment#timeouts ChronicleEnvironment#timeouts}
    */
    readonly timeouts?: ChronicleEnvironmentTimeouts;
}
export interface ChronicleEnvironmentDynamicParameters {
    /**
    * The ID of the dynamic parameter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment#dynamic_parameter_id ChronicleEnvironment#dynamic_parameter_id}
    */
    readonly dynamicParameterId: number;
    /**
    * The value of the dynamic parameter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment#value ChronicleEnvironment#value}
    */
    readonly value: string;
}
export declare function chronicleEnvironmentDynamicParametersToTerraform(struct?: ChronicleEnvironmentDynamicParameters | cdktn.IResolvable): any;
export declare function chronicleEnvironmentDynamicParametersToHclTerraform(struct?: ChronicleEnvironmentDynamicParameters | cdktn.IResolvable): any;
export declare class ChronicleEnvironmentDynamicParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleEnvironmentDynamicParameters | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleEnvironmentDynamicParameters | cdktn.IResolvable | undefined);
    private _dynamicParameterId?;
    get dynamicParameterId(): number;
    set dynamicParameterId(value: number);
    get dynamicParameterIdInput(): number | undefined;
    get environmentId(): number;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ChronicleEnvironmentDynamicParametersList extends cdktn.ComplexList {
    internalValue?: ChronicleEnvironmentDynamicParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleEnvironmentDynamicParametersOutputReference;
}
export interface ChronicleEnvironmentTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment#create ChronicleEnvironment#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment#delete ChronicleEnvironment#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment#update ChronicleEnvironment#update}
    */
    readonly update?: string;
}
export declare function chronicleEnvironmentTimeoutsToTerraform(struct?: ChronicleEnvironmentTimeouts | cdktn.IResolvable): any;
export declare function chronicleEnvironmentTimeoutsToHclTerraform(struct?: ChronicleEnvironmentTimeouts | cdktn.IResolvable): any;
export declare class ChronicleEnvironmentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleEnvironmentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleEnvironmentTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment google_chronicle_environment}
*/
export declare class ChronicleEnvironment extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_chronicle_environment";
    /**
    * Generates CDKTN code for importing a ChronicleEnvironment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChronicleEnvironment to import
    * @param importFromId The id of the existing ChronicleEnvironment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChronicleEnvironment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/chronicle_environment google_chronicle_environment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChronicleEnvironmentConfig
    */
    constructor(scope: Construct, id: string, config: ChronicleEnvironmentConfig);
    private _aliasesJson?;
    get aliasesJson(): string;
    set aliasesJson(value: string);
    resetAliasesJson(): void;
    get aliasesJsonInput(): string | undefined;
    private _base64Image?;
    get base64Image(): string;
    set base64Image(value: string);
    resetBase64Image(): void;
    get base64ImageInput(): string | undefined;
    private _contact?;
    get contact(): string;
    set contact(value: string);
    get contactInput(): string | undefined;
    private _contactEmails?;
    get contactEmails(): string;
    set contactEmails(value: string);
    get contactEmailsInput(): string | undefined;
    private _contactPhone?;
    get contactPhone(): string;
    set contactPhone(value: string);
    get contactPhoneInput(): string | undefined;
    private _dataAccessScopesJson?;
    get dataAccessScopesJson(): string;
    set dataAccessScopesJson(value: string);
    resetDataAccessScopesJson(): void;
    get dataAccessScopesJsonInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _deletionProtection?;
    get deletionProtection(): boolean | cdktn.IResolvable;
    set deletionProtection(value: boolean | cdktn.IResolvable);
    resetDeletionProtection(): void;
    get deletionProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get environmentId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instance?;
    get instance(): string;
    set instance(value: string);
    get instanceInput(): string | undefined;
    private _instanceUri?;
    get instanceUri(): string;
    set instanceUri(value: string);
    resetInstanceUri(): void;
    get instanceUriInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _parallelInstance?;
    get parallelInstance(): string;
    set parallelInstance(value: string);
    resetParallelInstance(): void;
    get parallelInstanceInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _retentionDuration?;
    get retentionDuration(): number;
    set retentionDuration(value: number);
    get retentionDurationInput(): number | undefined;
    private _weight?;
    get weight(): number;
    set weight(value: number);
    resetWeight(): void;
    get weightInput(): number | undefined;
    private _dynamicParameters;
    get dynamicParameters(): ChronicleEnvironmentDynamicParametersList;
    putDynamicParameters(value: ChronicleEnvironmentDynamicParameters[] | cdktn.IResolvable): void;
    resetDynamicParameters(): void;
    get dynamicParametersInput(): cdktn.IResolvable | ChronicleEnvironmentDynamicParameters[] | undefined;
    private _timeouts;
    get timeouts(): ChronicleEnvironmentTimeoutsOutputReference;
    putTimeouts(value: ChronicleEnvironmentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ChronicleEnvironmentTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
