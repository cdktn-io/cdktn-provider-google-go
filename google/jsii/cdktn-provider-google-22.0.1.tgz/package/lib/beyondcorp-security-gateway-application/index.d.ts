/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BeyondcorpSecurityGatewayApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * User-settable Application resource ID.
    * * Must start with a letter.
    * * Must contain between 4-63 characters from '/a-z-/'.
    * * Must end with a number or letter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#application_id BeyondcorpSecurityGatewayApplication#application_id}
    */
    readonly applicationId: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#deletion_policy BeyondcorpSecurityGatewayApplication#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Optional. An arbitrary user-provided name for the Application resource.
    * Cannot exceed 64 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#display_name BeyondcorpSecurityGatewayApplication#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#id BeyondcorpSecurityGatewayApplication#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#project BeyondcorpSecurityGatewayApplication#project}
    */
    readonly project?: string;
    /**
    * Type of the external application. Possible values: ["PROXY_GATEWAY", "API_GATEWAY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#schema BeyondcorpSecurityGatewayApplication#schema}
    */
    readonly schema?: string;
    /**
    * ID of the Security Gateway resource this belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#security_gateway_id BeyondcorpSecurityGatewayApplication#security_gateway_id}
    */
    readonly securityGatewayId: string;
    /**
    * endpoint_matchers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#endpoint_matchers BeyondcorpSecurityGatewayApplication#endpoint_matchers}
    */
    readonly endpointMatchers?: BeyondcorpSecurityGatewayApplicationEndpointMatchers[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#timeouts BeyondcorpSecurityGatewayApplication#timeouts}
    */
    readonly timeouts?: BeyondcorpSecurityGatewayApplicationTimeouts;
    /**
    * upstreams block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#upstreams BeyondcorpSecurityGatewayApplication#upstreams}
    */
    readonly upstreams?: BeyondcorpSecurityGatewayApplicationUpstreams[] | cdktn.IResolvable;
}
export interface BeyondcorpSecurityGatewayApplicationEndpointMatchers {
    /**
    * Required. Hostname of the application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#hostname BeyondcorpSecurityGatewayApplication#hostname}
    */
    readonly hostname: string;
    /**
    * Optional. Ports of the application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#ports BeyondcorpSecurityGatewayApplication#ports}
    */
    readonly ports: number[];
}
export declare function beyondcorpSecurityGatewayApplicationEndpointMatchersToTerraform(struct?: BeyondcorpSecurityGatewayApplicationEndpointMatchers | cdktn.IResolvable): any;
export declare function beyondcorpSecurityGatewayApplicationEndpointMatchersToHclTerraform(struct?: BeyondcorpSecurityGatewayApplicationEndpointMatchers | cdktn.IResolvable): any;
export declare class BeyondcorpSecurityGatewayApplicationEndpointMatchersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BeyondcorpSecurityGatewayApplicationEndpointMatchers | cdktn.IResolvable | undefined;
    set internalValue(value: BeyondcorpSecurityGatewayApplicationEndpointMatchers | cdktn.IResolvable | undefined);
    private _hostname?;
    get hostname(): string;
    set hostname(value: string);
    get hostnameInput(): string | undefined;
    private _ports?;
    get ports(): number[];
    set ports(value: number[]);
    get portsInput(): number[] | undefined;
}
export declare class BeyondcorpSecurityGatewayApplicationEndpointMatchersList extends cdktn.ComplexList {
    internalValue?: BeyondcorpSecurityGatewayApplicationEndpointMatchers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BeyondcorpSecurityGatewayApplicationEndpointMatchersOutputReference;
}
export interface BeyondcorpSecurityGatewayApplicationTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#create BeyondcorpSecurityGatewayApplication#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#delete BeyondcorpSecurityGatewayApplication#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#update BeyondcorpSecurityGatewayApplication#update}
    */
    readonly update?: string;
}
export declare function beyondcorpSecurityGatewayApplicationTimeoutsToTerraform(struct?: BeyondcorpSecurityGatewayApplicationTimeouts | cdktn.IResolvable): any;
export declare function beyondcorpSecurityGatewayApplicationTimeoutsToHclTerraform(struct?: BeyondcorpSecurityGatewayApplicationTimeouts | cdktn.IResolvable): any;
export declare class BeyondcorpSecurityGatewayApplicationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BeyondcorpSecurityGatewayApplicationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BeyondcorpSecurityGatewayApplicationTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface BeyondcorpSecurityGatewayApplicationUpstreamsEgressPolicy {
    /**
    * Required. List of regions where the application sends traffic to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#regions BeyondcorpSecurityGatewayApplication#regions}
    */
    readonly regions: string[];
}
export declare function beyondcorpSecurityGatewayApplicationUpstreamsEgressPolicyToTerraform(struct?: BeyondcorpSecurityGatewayApplicationUpstreamsEgressPolicyOutputReference | BeyondcorpSecurityGatewayApplicationUpstreamsEgressPolicy): any;
export declare function beyondcorpSecurityGatewayApplicationUpstreamsEgressPolicyToHclTerraform(struct?: BeyondcorpSecurityGatewayApplicationUpstreamsEgressPolicyOutputReference | BeyondcorpSecurityGatewayApplicationUpstreamsEgressPolicy): any;
export declare class BeyondcorpSecurityGatewayApplicationUpstreamsEgressPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BeyondcorpSecurityGatewayApplicationUpstreamsEgressPolicy | undefined;
    set internalValue(value: BeyondcorpSecurityGatewayApplicationUpstreamsEgressPolicy | undefined);
    private _regions?;
    get regions(): string[];
    set regions(value: string[]);
    get regionsInput(): string[] | undefined;
}
export interface BeyondcorpSecurityGatewayApplicationUpstreamsExternalEndpoints {
    /**
    * Hostname of the endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#hostname BeyondcorpSecurityGatewayApplication#hostname}
    */
    readonly hostname: string;
    /**
    * Port of the endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#port BeyondcorpSecurityGatewayApplication#port}
    */
    readonly port: number;
}
export declare function beyondcorpSecurityGatewayApplicationUpstreamsExternalEndpointsToTerraform(struct?: BeyondcorpSecurityGatewayApplicationUpstreamsExternalEndpoints | cdktn.IResolvable): any;
export declare function beyondcorpSecurityGatewayApplicationUpstreamsExternalEndpointsToHclTerraform(struct?: BeyondcorpSecurityGatewayApplicationUpstreamsExternalEndpoints | cdktn.IResolvable): any;
export declare class BeyondcorpSecurityGatewayApplicationUpstreamsExternalEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BeyondcorpSecurityGatewayApplicationUpstreamsExternalEndpoints | cdktn.IResolvable | undefined;
    set internalValue(value: BeyondcorpSecurityGatewayApplicationUpstreamsExternalEndpoints | cdktn.IResolvable | undefined);
    private _hostname?;
    get hostname(): string;
    set hostname(value: string);
    get hostnameInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
}
export declare class BeyondcorpSecurityGatewayApplicationUpstreamsExternalEndpointsList extends cdktn.ComplexList {
    internalValue?: BeyondcorpSecurityGatewayApplicationUpstreamsExternalEndpoints[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BeyondcorpSecurityGatewayApplicationUpstreamsExternalEndpointsOutputReference;
}
export interface BeyondcorpSecurityGatewayApplicationUpstreamsExternal {
    /**
    * endpoints block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#endpoints BeyondcorpSecurityGatewayApplication#endpoints}
    */
    readonly endpoints: BeyondcorpSecurityGatewayApplicationUpstreamsExternalEndpoints[] | cdktn.IResolvable;
}
export declare function beyondcorpSecurityGatewayApplicationUpstreamsExternalToTerraform(struct?: BeyondcorpSecurityGatewayApplicationUpstreamsExternalOutputReference | BeyondcorpSecurityGatewayApplicationUpstreamsExternal): any;
export declare function beyondcorpSecurityGatewayApplicationUpstreamsExternalToHclTerraform(struct?: BeyondcorpSecurityGatewayApplicationUpstreamsExternalOutputReference | BeyondcorpSecurityGatewayApplicationUpstreamsExternal): any;
export declare class BeyondcorpSecurityGatewayApplicationUpstreamsExternalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BeyondcorpSecurityGatewayApplicationUpstreamsExternal | undefined;
    set internalValue(value: BeyondcorpSecurityGatewayApplicationUpstreamsExternal | undefined);
    private _endpoints;
    get endpoints(): BeyondcorpSecurityGatewayApplicationUpstreamsExternalEndpointsList;
    putEndpoints(value: BeyondcorpSecurityGatewayApplicationUpstreamsExternalEndpoints[] | cdktn.IResolvable): void;
    get endpointsInput(): cdktn.IResolvable | BeyondcorpSecurityGatewayApplicationUpstreamsExternalEndpoints[] | undefined;
}
export interface BeyondcorpSecurityGatewayApplicationUpstreamsNetwork {
    /**
    * Required. Network name is of the format:
    * 'projects/{project}/global/networks/{network}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#name BeyondcorpSecurityGatewayApplication#name}
    */
    readonly name: string;
}
export declare function beyondcorpSecurityGatewayApplicationUpstreamsNetworkToTerraform(struct?: BeyondcorpSecurityGatewayApplicationUpstreamsNetworkOutputReference | BeyondcorpSecurityGatewayApplicationUpstreamsNetwork): any;
export declare function beyondcorpSecurityGatewayApplicationUpstreamsNetworkToHclTerraform(struct?: BeyondcorpSecurityGatewayApplicationUpstreamsNetworkOutputReference | BeyondcorpSecurityGatewayApplicationUpstreamsNetwork): any;
export declare class BeyondcorpSecurityGatewayApplicationUpstreamsNetworkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BeyondcorpSecurityGatewayApplicationUpstreamsNetwork | undefined;
    set internalValue(value: BeyondcorpSecurityGatewayApplicationUpstreamsNetwork | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersDeviceInfo {
    /**
    * The output type of the delegated device info. Possible values: ["PROTOBUF", "JSON", "NONE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#output_type BeyondcorpSecurityGatewayApplication#output_type}
    */
    readonly outputType?: string;
}
export declare function beyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersDeviceInfoToTerraform(struct?: BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersDeviceInfoOutputReference | BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersDeviceInfo): any;
export declare function beyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersDeviceInfoToHclTerraform(struct?: BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersDeviceInfoOutputReference | BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersDeviceInfo): any;
export declare class BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersDeviceInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersDeviceInfo | undefined;
    set internalValue(value: BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersDeviceInfo | undefined);
    private _outputType?;
    get outputType(): string;
    set outputType(value: string);
    resetOutputType(): void;
    get outputTypeInput(): string | undefined;
}
export interface BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersGroupInfo {
    /**
    * The output type of the delegated group info. Possible values: ["PROTOBUF", "JSON", "NONE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#output_type BeyondcorpSecurityGatewayApplication#output_type}
    */
    readonly outputType?: string;
}
export declare function beyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersGroupInfoToTerraform(struct?: BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersGroupInfoOutputReference | BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersGroupInfo): any;
export declare function beyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersGroupInfoToHclTerraform(struct?: BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersGroupInfoOutputReference | BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersGroupInfo): any;
export declare class BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersGroupInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersGroupInfo | undefined;
    set internalValue(value: BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersGroupInfo | undefined);
    private _outputType?;
    get outputType(): string;
    set outputType(value: string);
    resetOutputType(): void;
    get outputTypeInput(): string | undefined;
}
export interface BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersUserInfo {
    /**
    * The output type of the delegated user info. Possible values: ["PROTOBUF", "JSON", "NONE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#output_type BeyondcorpSecurityGatewayApplication#output_type}
    */
    readonly outputType?: string;
}
export declare function beyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersUserInfoToTerraform(struct?: BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersUserInfoOutputReference | BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersUserInfo): any;
export declare function beyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersUserInfoToHclTerraform(struct?: BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersUserInfoOutputReference | BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersUserInfo): any;
export declare class BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersUserInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersUserInfo | undefined;
    set internalValue(value: BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersUserInfo | undefined);
    private _outputType?;
    get outputType(): string;
    set outputType(value: string);
    resetOutputType(): void;
    get outputTypeInput(): string | undefined;
}
export interface BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeaders {
    /**
    * Default output type for all enabled headers. Possible values: ["PROTOBUF", "JSON", "NONE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#output_type BeyondcorpSecurityGatewayApplication#output_type}
    */
    readonly outputType?: string;
    /**
    * device_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#device_info BeyondcorpSecurityGatewayApplication#device_info}
    */
    readonly deviceInfo?: BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersDeviceInfo;
    /**
    * group_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#group_info BeyondcorpSecurityGatewayApplication#group_info}
    */
    readonly groupInfo?: BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersGroupInfo;
    /**
    * user_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#user_info BeyondcorpSecurityGatewayApplication#user_info}
    */
    readonly userInfo?: BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersUserInfo;
}
export declare function beyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersToTerraform(struct?: BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersOutputReference | BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeaders): any;
export declare function beyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersToHclTerraform(struct?: BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersOutputReference | BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeaders): any;
export declare class BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeaders | undefined;
    set internalValue(value: BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeaders | undefined);
    private _outputType?;
    get outputType(): string;
    set outputType(value: string);
    resetOutputType(): void;
    get outputTypeInput(): string | undefined;
    private _deviceInfo;
    get deviceInfo(): BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersDeviceInfoOutputReference;
    putDeviceInfo(value: BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersDeviceInfo): void;
    resetDeviceInfo(): void;
    get deviceInfoInput(): BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersDeviceInfo | undefined;
    private _groupInfo;
    get groupInfo(): BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersGroupInfoOutputReference;
    putGroupInfo(value: BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersGroupInfo): void;
    resetGroupInfo(): void;
    get groupInfoInput(): BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersGroupInfo | undefined;
    private _userInfo;
    get userInfo(): BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersUserInfoOutputReference;
    putUserInfo(value: BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersUserInfo): void;
    resetUserInfo(): void;
    get userInfoInput(): BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersUserInfo | undefined;
}
export interface BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocol {
    /**
    * The configuration for the proxy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#allowed_client_headers BeyondcorpSecurityGatewayApplication#allowed_client_headers}
    */
    readonly allowedClientHeaders?: string[];
    /**
    * Client IP configuration. The client IP address is included if true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#client_ip BeyondcorpSecurityGatewayApplication#client_ip}
    */
    readonly clientIp?: boolean | cdktn.IResolvable;
    /**
    * Gateway identity configuration. Possible values: ["RESOURCE_NAME"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#gateway_identity BeyondcorpSecurityGatewayApplication#gateway_identity}
    */
    readonly gatewayIdentity?: string;
    /**
    * Custom resource specific headers along with the values.
    * The names should conform to RFC 9110:
    * > Field names SHOULD constrain themselves to alphanumeric characters, "-",
    *   and ".", and SHOULD begin with a letter.
    * > Field values SHOULD contain only ASCII printable characters and tab.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#metadata_headers BeyondcorpSecurityGatewayApplication#metadata_headers}
    */
    readonly metadataHeaders?: {
        [key: string]: string;
    };
    /**
    * contextual_headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#contextual_headers BeyondcorpSecurityGatewayApplication#contextual_headers}
    */
    readonly contextualHeaders?: BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeaders;
}
export declare function beyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolToTerraform(struct?: BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolOutputReference | BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocol): any;
export declare function beyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolToHclTerraform(struct?: BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolOutputReference | BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocol): any;
export declare class BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocol | undefined;
    set internalValue(value: BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocol | undefined);
    private _allowedClientHeaders?;
    get allowedClientHeaders(): string[];
    set allowedClientHeaders(value: string[]);
    resetAllowedClientHeaders(): void;
    get allowedClientHeadersInput(): string[] | undefined;
    private _clientIp?;
    get clientIp(): boolean | cdktn.IResolvable;
    set clientIp(value: boolean | cdktn.IResolvable);
    resetClientIp(): void;
    get clientIpInput(): boolean | cdktn.IResolvable | undefined;
    private _gatewayIdentity?;
    get gatewayIdentity(): string;
    set gatewayIdentity(value: string);
    resetGatewayIdentity(): void;
    get gatewayIdentityInput(): string | undefined;
    private _metadataHeaders?;
    get metadataHeaders(): {
        [key: string]: string;
    };
    set metadataHeaders(value: {
        [key: string]: string;
    });
    resetMetadataHeaders(): void;
    get metadataHeadersInput(): {
        [key: string]: string;
    } | undefined;
    private _contextualHeaders;
    get contextualHeaders(): BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeadersOutputReference;
    putContextualHeaders(value: BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeaders): void;
    resetContextualHeaders(): void;
    get contextualHeadersInput(): BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolContextualHeaders | undefined;
}
export interface BeyondcorpSecurityGatewayApplicationUpstreams {
    /**
    * egress_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#egress_policy BeyondcorpSecurityGatewayApplication#egress_policy}
    */
    readonly egressPolicy?: BeyondcorpSecurityGatewayApplicationUpstreamsEgressPolicy;
    /**
    * external block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#external BeyondcorpSecurityGatewayApplication#external}
    */
    readonly external?: BeyondcorpSecurityGatewayApplicationUpstreamsExternal;
    /**
    * network block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#network BeyondcorpSecurityGatewayApplication#network}
    */
    readonly network?: BeyondcorpSecurityGatewayApplicationUpstreamsNetwork;
    /**
    * proxy_protocol block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#proxy_protocol BeyondcorpSecurityGatewayApplication#proxy_protocol}
    */
    readonly proxyProtocol?: BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocol;
}
export declare function beyondcorpSecurityGatewayApplicationUpstreamsToTerraform(struct?: BeyondcorpSecurityGatewayApplicationUpstreams | cdktn.IResolvable): any;
export declare function beyondcorpSecurityGatewayApplicationUpstreamsToHclTerraform(struct?: BeyondcorpSecurityGatewayApplicationUpstreams | cdktn.IResolvable): any;
export declare class BeyondcorpSecurityGatewayApplicationUpstreamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BeyondcorpSecurityGatewayApplicationUpstreams | cdktn.IResolvable | undefined;
    set internalValue(value: BeyondcorpSecurityGatewayApplicationUpstreams | cdktn.IResolvable | undefined);
    private _egressPolicy;
    get egressPolicy(): BeyondcorpSecurityGatewayApplicationUpstreamsEgressPolicyOutputReference;
    putEgressPolicy(value: BeyondcorpSecurityGatewayApplicationUpstreamsEgressPolicy): void;
    resetEgressPolicy(): void;
    get egressPolicyInput(): BeyondcorpSecurityGatewayApplicationUpstreamsEgressPolicy | undefined;
    private _external;
    get external(): BeyondcorpSecurityGatewayApplicationUpstreamsExternalOutputReference;
    putExternal(value: BeyondcorpSecurityGatewayApplicationUpstreamsExternal): void;
    resetExternal(): void;
    get externalInput(): BeyondcorpSecurityGatewayApplicationUpstreamsExternal | undefined;
    private _network;
    get network(): BeyondcorpSecurityGatewayApplicationUpstreamsNetworkOutputReference;
    putNetwork(value: BeyondcorpSecurityGatewayApplicationUpstreamsNetwork): void;
    resetNetwork(): void;
    get networkInput(): BeyondcorpSecurityGatewayApplicationUpstreamsNetwork | undefined;
    private _proxyProtocol;
    get proxyProtocol(): BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocolOutputReference;
    putProxyProtocol(value: BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocol): void;
    resetProxyProtocol(): void;
    get proxyProtocolInput(): BeyondcorpSecurityGatewayApplicationUpstreamsProxyProtocol | undefined;
}
export declare class BeyondcorpSecurityGatewayApplicationUpstreamsList extends cdktn.ComplexList {
    internalValue?: BeyondcorpSecurityGatewayApplicationUpstreams[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BeyondcorpSecurityGatewayApplicationUpstreamsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application google_beyondcorp_security_gateway_application}
*/
export declare class BeyondcorpSecurityGatewayApplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_beyondcorp_security_gateway_application";
    /**
    * Generates CDKTN code for importing a BeyondcorpSecurityGatewayApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BeyondcorpSecurityGatewayApplication to import
    * @param importFromId The id of the existing BeyondcorpSecurityGatewayApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BeyondcorpSecurityGatewayApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/beyondcorp_security_gateway_application google_beyondcorp_security_gateway_application} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BeyondcorpSecurityGatewayApplicationConfig
    */
    constructor(scope: Construct, id: string, config: BeyondcorpSecurityGatewayApplicationConfig);
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _securityGatewayId?;
    get securityGatewayId(): string;
    set securityGatewayId(value: string);
    get securityGatewayIdInput(): string | undefined;
    get updateTime(): string;
    private _endpointMatchers;
    get endpointMatchers(): BeyondcorpSecurityGatewayApplicationEndpointMatchersList;
    putEndpointMatchers(value: BeyondcorpSecurityGatewayApplicationEndpointMatchers[] | cdktn.IResolvable): void;
    resetEndpointMatchers(): void;
    get endpointMatchersInput(): cdktn.IResolvable | BeyondcorpSecurityGatewayApplicationEndpointMatchers[] | undefined;
    private _timeouts;
    get timeouts(): BeyondcorpSecurityGatewayApplicationTimeoutsOutputReference;
    putTimeouts(value: BeyondcorpSecurityGatewayApplicationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BeyondcorpSecurityGatewayApplicationTimeouts | undefined;
    private _upstreams;
    get upstreams(): BeyondcorpSecurityGatewayApplicationUpstreamsList;
    putUpstreams(value: BeyondcorpSecurityGatewayApplicationUpstreams[] | cdktn.IResolvable): void;
    resetUpstreams(): void;
    get upstreamsInput(): cdktn.IResolvable | BeyondcorpSecurityGatewayApplicationUpstreams[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
