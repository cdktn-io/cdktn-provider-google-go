/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccessContextManagerGcpUserAccessBindingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Optional. Access level that a user must have to be granted access. Only one access level is supported, not multiple. This repeated field must have exactly one element. Example: "accessPolicies/9522/accessLevels/device_trusted"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#access_levels AccessContextManagerGcpUserAccessBinding#access_levels}
    */
    readonly accessLevels?: string[];
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#deletion_policy AccessContextManagerGcpUserAccessBinding#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Optional. Dry run access level that will be evaluated but will not be enforced. The
    * access denial based on dry run policy will be logged. Only one access
    * level is supported, not multiple. This list must have exactly one element.
    * Example: "accessPolicies/9522/accessLevels/device_trusted"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#dry_run_access_levels AccessContextManagerGcpUserAccessBinding#dry_run_access_levels}
    */
    readonly dryRunAccessLevels?: string[];
    /**
    * Immutable. Google Group id whose members are subject to this binding's restrictions.
    * See "id" in the Google Workspace Directory API's Group Resource (https://developers.google.com/admin-sdk/directory/v1/reference/groups#resource).
    * If a group's email address/alias is changed, this resource will continue to point at the changed group.
    * This field does not accept group email addresses or aliases.
    * Example: "01d520gv4vjcrht"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#group_key AccessContextManagerGcpUserAccessBinding#group_key}
    */
    readonly groupKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#id AccessContextManagerGcpUserAccessBinding#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Required. ID of the parent organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#organization_id AccessContextManagerGcpUserAccessBinding#organization_id}
    */
    readonly organizationId: string;
    /**
    * principal block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#principal AccessContextManagerGcpUserAccessBinding#principal}
    */
    readonly principal?: AccessContextManagerGcpUserAccessBindingPrincipal;
    /**
    * scoped_access_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#scoped_access_settings AccessContextManagerGcpUserAccessBinding#scoped_access_settings}
    */
    readonly scopedAccessSettings?: AccessContextManagerGcpUserAccessBindingScopedAccessSettings[] | cdktn.IResolvable;
    /**
    * session_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#session_settings AccessContextManagerGcpUserAccessBinding#session_settings}
    */
    readonly sessionSettings?: AccessContextManagerGcpUserAccessBindingSessionSettings;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#timeouts AccessContextManagerGcpUserAccessBinding#timeouts}
    */
    readonly timeouts?: AccessContextManagerGcpUserAccessBindingTimeouts;
}
export interface AccessContextManagerGcpUserAccessBindingPrincipal {
    /**
    * Immutable. The IAM principal identifier of the federated workforce or workload to
    * assign the policy to. Examples include the following:
    * * Single principal:
    * 'principal://iam.googleapis.com/projects/{project_number}/locations/global/workloadIdentityPools/{pool_id}/subject/{subject_attribute_value}'
    * * All workloads in a workload identity pool:
    * 'principalSet://iam.googleapis.com/projects/{project_number}/locations/global/workloadIdentityPools/{pool_id}/*'
    * * All Workforce Pools in a Google Cloud organization:
    * 'principalSet://cloudresourcemanager.googleapis.com/organizations/{organization_id}/type/WorkforcePool'
    *
    * Bindings created for all Workforce Pools in a Google Cloud organization
    * support only 'scoped_access_settings' with the 'restricted_project'
    * client scope and active 'session_settings'. No other configurations are
    * allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#federated_principal AccessContextManagerGcpUserAccessBinding#federated_principal}
    */
    readonly federatedPrincipal?: string;
    /**
    * Immutable. Service account email used to assign policies to a single service account.
    * If a service account is subject to multiple policies (e.g., if there is a policy for all
    * service accounts in a project and a policy for the service account), the closest (i.e.
    * the most specific) dry-run policy will be used for the dry-run functionality and the
    * closest policy will be used for the enforcement.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#service_account AccessContextManagerGcpUserAccessBinding#service_account}
    */
    readonly serviceAccount?: string;
    /**
    * Immutable. Cloud project number used to assign policies to all service accounts owned by the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#service_account_project_number AccessContextManagerGcpUserAccessBinding#service_account_project_number}
    */
    readonly serviceAccountProjectNumber?: string;
}
export declare function accessContextManagerGcpUserAccessBindingPrincipalToTerraform(struct?: AccessContextManagerGcpUserAccessBindingPrincipalOutputReference | AccessContextManagerGcpUserAccessBindingPrincipal): any;
export declare function accessContextManagerGcpUserAccessBindingPrincipalToHclTerraform(struct?: AccessContextManagerGcpUserAccessBindingPrincipalOutputReference | AccessContextManagerGcpUserAccessBindingPrincipal): any;
export declare class AccessContextManagerGcpUserAccessBindingPrincipalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerGcpUserAccessBindingPrincipal | undefined;
    set internalValue(value: AccessContextManagerGcpUserAccessBindingPrincipal | undefined);
    private _federatedPrincipal?;
    get federatedPrincipal(): string;
    set federatedPrincipal(value: string);
    resetFederatedPrincipal(): void;
    get federatedPrincipalInput(): string | undefined;
    private _serviceAccount?;
    get serviceAccount(): string;
    set serviceAccount(value: string);
    resetServiceAccount(): void;
    get serviceAccountInput(): string | undefined;
    private _serviceAccountProjectNumber?;
    get serviceAccountProjectNumber(): string;
    set serviceAccountProjectNumber(value: string);
    resetServiceAccountProjectNumber(): void;
    get serviceAccountProjectNumberInput(): string | undefined;
}
export interface AccessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettingsSessionSettings {
    /**
    * Optional. How long a user is allowed to take between actions before a new access token must be issued. Only set for Google Cloud apps.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#max_inactivity AccessContextManagerGcpUserAccessBinding#max_inactivity}
    */
    readonly maxInactivity?: string;
    /**
    * Optional. The session length. Setting this field to zero is equal to disabling session. Also can set infinite session by flipping the enabled bit to false below. If useOidcMaxAge is true, for OIDC apps, the session length will be the minimum of this field and OIDC max_age param.
    * If this field is set to zero, 'session_length_enabled' must be set to false or left unset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#session_length AccessContextManagerGcpUserAccessBinding#session_length}
    */
    readonly sessionLength?: string;
    /**
    * Optional. This field enables or disables Google Cloud session length. When false, all fields set above will be disregarded and the session length is basically infinite.
    * If 'session_length' is set to zero, this field must be false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#session_length_enabled AccessContextManagerGcpUserAccessBinding#session_length_enabled}
    */
    readonly sessionLengthEnabled?: boolean | cdktn.IResolvable;
    /**
    * Optional. The session challenges proposed to users when the Google Cloud session length is up. Possible values: ["LOGIN", "SECURITY_KEY", "PASSWORD"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#session_reauth_method AccessContextManagerGcpUserAccessBinding#session_reauth_method}
    */
    readonly sessionReauthMethod?: string;
    /**
    * Optional. Only useful for OIDC apps. When false, the OIDC max_age param, if passed in the authentication request will be ignored. When true, the re-auth period will be the minimum of the sessionLength field and the max_age OIDC param.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#use_oidc_max_age AccessContextManagerGcpUserAccessBinding#use_oidc_max_age}
    */
    readonly useOidcMaxAge?: boolean | cdktn.IResolvable;
}
export declare function accessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettingsSessionSettingsToTerraform(struct?: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettingsSessionSettingsOutputReference | AccessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettingsSessionSettings): any;
export declare function accessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettingsSessionSettingsToHclTerraform(struct?: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettingsSessionSettingsOutputReference | AccessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettingsSessionSettings): any;
export declare class AccessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettingsSessionSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettingsSessionSettings | undefined;
    set internalValue(value: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettingsSessionSettings | undefined);
    private _maxInactivity?;
    get maxInactivity(): string;
    set maxInactivity(value: string);
    resetMaxInactivity(): void;
    get maxInactivityInput(): string | undefined;
    private _sessionLength?;
    get sessionLength(): string;
    set sessionLength(value: string);
    resetSessionLength(): void;
    get sessionLengthInput(): string | undefined;
    private _sessionLengthEnabled?;
    get sessionLengthEnabled(): boolean | cdktn.IResolvable;
    set sessionLengthEnabled(value: boolean | cdktn.IResolvable);
    resetSessionLengthEnabled(): void;
    get sessionLengthEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _sessionReauthMethod?;
    get sessionReauthMethod(): string;
    set sessionReauthMethod(value: string);
    resetSessionReauthMethod(): void;
    get sessionReauthMethodInput(): string | undefined;
    private _useOidcMaxAge?;
    get useOidcMaxAge(): boolean | cdktn.IResolvable;
    set useOidcMaxAge(value: boolean | cdktn.IResolvable);
    resetUseOidcMaxAge(): void;
    get useOidcMaxAgeInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettings {
    /**
    * Optional. Access level that a user must have to be granted access. Only one access level is supported, not multiple. This repeated field must have exactly one element. Example: "accessPolicies/9522/accessLevels/device_trusted"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#access_levels AccessContextManagerGcpUserAccessBinding#access_levels}
    */
    readonly accessLevels?: string[];
    /**
    * session_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#session_settings AccessContextManagerGcpUserAccessBinding#session_settings}
    */
    readonly sessionSettings?: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettingsSessionSettings;
}
export declare function accessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettingsToTerraform(struct?: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettingsOutputReference | AccessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettings): any;
export declare function accessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettingsToHclTerraform(struct?: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettingsOutputReference | AccessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettings): any;
export declare class AccessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettings | undefined;
    set internalValue(value: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettings | undefined);
    private _accessLevels?;
    get accessLevels(): string[];
    set accessLevels(value: string[]);
    resetAccessLevels(): void;
    get accessLevelsInput(): string[] | undefined;
    private _sessionSettings;
    get sessionSettings(): AccessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettingsSessionSettingsOutputReference;
    putSessionSettings(value: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettingsSessionSettings): void;
    resetSessionSettings(): void;
    get sessionSettingsInput(): AccessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettingsSessionSettings | undefined;
}
export interface AccessContextManagerGcpUserAccessBindingScopedAccessSettingsDryRunSettings {
    /**
    * Optional. Access level that a user must have to be granted access. Only one access level is supported, not multiple. This repeated field must have exactly one element. Example: "accessPolicies/9522/accessLevels/device_trusted"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#access_levels AccessContextManagerGcpUserAccessBinding#access_levels}
    */
    readonly accessLevels?: string[];
}
export declare function accessContextManagerGcpUserAccessBindingScopedAccessSettingsDryRunSettingsToTerraform(struct?: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsDryRunSettingsOutputReference | AccessContextManagerGcpUserAccessBindingScopedAccessSettingsDryRunSettings): any;
export declare function accessContextManagerGcpUserAccessBindingScopedAccessSettingsDryRunSettingsToHclTerraform(struct?: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsDryRunSettingsOutputReference | AccessContextManagerGcpUserAccessBindingScopedAccessSettingsDryRunSettings): any;
export declare class AccessContextManagerGcpUserAccessBindingScopedAccessSettingsDryRunSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerGcpUserAccessBindingScopedAccessSettingsDryRunSettings | undefined;
    set internalValue(value: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsDryRunSettings | undefined);
    private _accessLevels?;
    get accessLevels(): string[];
    set accessLevels(value: string[]);
    resetAccessLevels(): void;
    get accessLevelsInput(): string[] | undefined;
}
export interface AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedClientApplication {
    /**
    * The OAuth client ID of the application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#client_id AccessContextManagerGcpUserAccessBinding#client_id}
    */
    readonly clientId?: string;
    /**
    * The name of the application. Example: "Cloud Console"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#name AccessContextManagerGcpUserAccessBinding#name}
    */
    readonly name?: string;
}
export declare function accessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedClientApplicationToTerraform(struct?: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedClientApplicationOutputReference | AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedClientApplication): any;
export declare function accessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedClientApplicationToHclTerraform(struct?: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedClientApplicationOutputReference | AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedClientApplication): any;
export declare class AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedClientApplicationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedClientApplication | undefined;
    set internalValue(value: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedClientApplication | undefined);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedProject {
    /**
    * The Google Cloud project resource name.
    * Format: 'projects/{project_number}'. Only the project number is supported.
    * Example: 'projects/1234567890'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#name AccessContextManagerGcpUserAccessBinding#name}
    */
    readonly name: string;
}
export declare function accessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedProjectToTerraform(struct?: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedProjectOutputReference | AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedProject): any;
export declare function accessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedProjectToHclTerraform(struct?: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedProjectOutputReference | AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedProject): any;
export declare class AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedProjectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedProject | undefined;
    set internalValue(value: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedProject | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScope {
    /**
    * restricted_client_application block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#restricted_client_application AccessContextManagerGcpUserAccessBinding#restricted_client_application}
    */
    readonly restrictedClientApplication?: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedClientApplication;
    /**
    * restricted_project block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#restricted_project AccessContextManagerGcpUserAccessBinding#restricted_project}
    */
    readonly restrictedProject?: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedProject;
}
export declare function accessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeToTerraform(struct?: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeOutputReference | AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScope): any;
export declare function accessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeToHclTerraform(struct?: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeOutputReference | AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScope): any;
export declare class AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScope | undefined;
    set internalValue(value: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScope | undefined);
    private _restrictedClientApplication;
    get restrictedClientApplication(): AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedClientApplicationOutputReference;
    putRestrictedClientApplication(value: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedClientApplication): void;
    resetRestrictedClientApplication(): void;
    get restrictedClientApplicationInput(): AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedClientApplication | undefined;
    private _restrictedProject;
    get restrictedProject(): AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedProjectOutputReference;
    putRestrictedProject(value: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedProject): void;
    resetRestrictedProject(): void;
    get restrictedProjectInput(): AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeRestrictedProject | undefined;
}
export interface AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScope {
    /**
    * client_scope block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#client_scope AccessContextManagerGcpUserAccessBinding#client_scope}
    */
    readonly clientScope?: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScope;
}
export declare function accessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeToTerraform(struct?: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeOutputReference | AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScope): any;
export declare function accessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeToHclTerraform(struct?: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeOutputReference | AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScope): any;
export declare class AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScope | undefined;
    set internalValue(value: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScope | undefined);
    private _clientScope;
    get clientScope(): AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScopeOutputReference;
    putClientScope(value: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScope): void;
    resetClientScope(): void;
    get clientScopeInput(): AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeClientScope | undefined;
}
export interface AccessContextManagerGcpUserAccessBindingScopedAccessSettings {
    /**
    * active_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#active_settings AccessContextManagerGcpUserAccessBinding#active_settings}
    */
    readonly activeSettings?: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettings;
    /**
    * dry_run_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#dry_run_settings AccessContextManagerGcpUserAccessBinding#dry_run_settings}
    */
    readonly dryRunSettings?: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsDryRunSettings;
    /**
    * scope block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#scope AccessContextManagerGcpUserAccessBinding#scope}
    */
    readonly scope?: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScope;
}
export declare function accessContextManagerGcpUserAccessBindingScopedAccessSettingsToTerraform(struct?: AccessContextManagerGcpUserAccessBindingScopedAccessSettings | cdktn.IResolvable): any;
export declare function accessContextManagerGcpUserAccessBindingScopedAccessSettingsToHclTerraform(struct?: AccessContextManagerGcpUserAccessBindingScopedAccessSettings | cdktn.IResolvable): any;
export declare class AccessContextManagerGcpUserAccessBindingScopedAccessSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerGcpUserAccessBindingScopedAccessSettings | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerGcpUserAccessBindingScopedAccessSettings | cdktn.IResolvable | undefined);
    private _activeSettings;
    get activeSettings(): AccessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettingsOutputReference;
    putActiveSettings(value: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettings): void;
    resetActiveSettings(): void;
    get activeSettingsInput(): AccessContextManagerGcpUserAccessBindingScopedAccessSettingsActiveSettings | undefined;
    private _dryRunSettings;
    get dryRunSettings(): AccessContextManagerGcpUserAccessBindingScopedAccessSettingsDryRunSettingsOutputReference;
    putDryRunSettings(value: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsDryRunSettings): void;
    resetDryRunSettings(): void;
    get dryRunSettingsInput(): AccessContextManagerGcpUserAccessBindingScopedAccessSettingsDryRunSettings | undefined;
    private _scope;
    get scope(): AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScopeOutputReference;
    putScope(value: AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScope): void;
    resetScope(): void;
    get scopeInput(): AccessContextManagerGcpUserAccessBindingScopedAccessSettingsScope | undefined;
}
export declare class AccessContextManagerGcpUserAccessBindingScopedAccessSettingsList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerGcpUserAccessBindingScopedAccessSettings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerGcpUserAccessBindingScopedAccessSettingsOutputReference;
}
export interface AccessContextManagerGcpUserAccessBindingSessionSettings {
    /**
    * Optional. How long a user is allowed to take between actions before a new access token must be issued. Only set for Google Cloud apps.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#max_inactivity AccessContextManagerGcpUserAccessBinding#max_inactivity}
    */
    readonly maxInactivity?: string;
    /**
    * Optional. The session length. Setting this field to zero is equal to disabling session. Also can set infinite session by flipping the enabled bit to false below. If useOidcMaxAge is true, for OIDC apps, the session length will be the minimum of this field and OIDC max_age param.
    * If this field is set to zero, 'session_length_enabled' must be set to false or left unset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#session_length AccessContextManagerGcpUserAccessBinding#session_length}
    */
    readonly sessionLength?: string;
    /**
    * Optional. This field enables or disables Google Cloud session length. When false, all fields set above will be disregarded and the session length is basically infinite.
    * If 'session_length' is set to zero, this field must be false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#session_length_enabled AccessContextManagerGcpUserAccessBinding#session_length_enabled}
    */
    readonly sessionLengthEnabled?: boolean | cdktn.IResolvable;
    /**
    * Optional. The session challenges proposed to users when the Google Cloud session length is up. Possible values: ["LOGIN", "SECURITY_KEY", "PASSWORD"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#session_reauth_method AccessContextManagerGcpUserAccessBinding#session_reauth_method}
    */
    readonly sessionReauthMethod?: string;
    /**
    * Optional. Only useful for OIDC apps. When false, the OIDC max_age param, if passed in the authentication request will be ignored. When true, the re-auth period will be the minimum of the sessionLength field and the max_age OIDC param.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#use_oidc_max_age AccessContextManagerGcpUserAccessBinding#use_oidc_max_age}
    */
    readonly useOidcMaxAge?: boolean | cdktn.IResolvable;
}
export declare function accessContextManagerGcpUserAccessBindingSessionSettingsToTerraform(struct?: AccessContextManagerGcpUserAccessBindingSessionSettingsOutputReference | AccessContextManagerGcpUserAccessBindingSessionSettings): any;
export declare function accessContextManagerGcpUserAccessBindingSessionSettingsToHclTerraform(struct?: AccessContextManagerGcpUserAccessBindingSessionSettingsOutputReference | AccessContextManagerGcpUserAccessBindingSessionSettings): any;
export declare class AccessContextManagerGcpUserAccessBindingSessionSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerGcpUserAccessBindingSessionSettings | undefined;
    set internalValue(value: AccessContextManagerGcpUserAccessBindingSessionSettings | undefined);
    private _maxInactivity?;
    get maxInactivity(): string;
    set maxInactivity(value: string);
    resetMaxInactivity(): void;
    get maxInactivityInput(): string | undefined;
    private _sessionLength?;
    get sessionLength(): string;
    set sessionLength(value: string);
    resetSessionLength(): void;
    get sessionLengthInput(): string | undefined;
    private _sessionLengthEnabled?;
    get sessionLengthEnabled(): boolean | cdktn.IResolvable;
    set sessionLengthEnabled(value: boolean | cdktn.IResolvable);
    resetSessionLengthEnabled(): void;
    get sessionLengthEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _sessionReauthMethod?;
    get sessionReauthMethod(): string;
    set sessionReauthMethod(value: string);
    resetSessionReauthMethod(): void;
    get sessionReauthMethodInput(): string | undefined;
    private _useOidcMaxAge?;
    get useOidcMaxAge(): boolean | cdktn.IResolvable;
    set useOidcMaxAge(value: boolean | cdktn.IResolvable);
    resetUseOidcMaxAge(): void;
    get useOidcMaxAgeInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccessContextManagerGcpUserAccessBindingTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#create AccessContextManagerGcpUserAccessBinding#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#delete AccessContextManagerGcpUserAccessBinding#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#update AccessContextManagerGcpUserAccessBinding#update}
    */
    readonly update?: string;
}
export declare function accessContextManagerGcpUserAccessBindingTimeoutsToTerraform(struct?: AccessContextManagerGcpUserAccessBindingTimeouts | cdktn.IResolvable): any;
export declare function accessContextManagerGcpUserAccessBindingTimeoutsToHclTerraform(struct?: AccessContextManagerGcpUserAccessBindingTimeouts | cdktn.IResolvable): any;
export declare class AccessContextManagerGcpUserAccessBindingTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerGcpUserAccessBindingTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerGcpUserAccessBindingTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding google_access_context_manager_gcp_user_access_binding}
*/
export declare class AccessContextManagerGcpUserAccessBinding extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_access_context_manager_gcp_user_access_binding";
    /**
    * Generates CDKTN code for importing a AccessContextManagerGcpUserAccessBinding resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessContextManagerGcpUserAccessBinding to import
    * @param importFromId The id of the existing AccessContextManagerGcpUserAccessBinding that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessContextManagerGcpUserAccessBinding to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_gcp_user_access_binding google_access_context_manager_gcp_user_access_binding} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessContextManagerGcpUserAccessBindingConfig
    */
    constructor(scope: Construct, id: string, config: AccessContextManagerGcpUserAccessBindingConfig);
    private _accessLevels?;
    get accessLevels(): string[];
    set accessLevels(value: string[]);
    resetAccessLevels(): void;
    get accessLevelsInput(): string[] | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _dryRunAccessLevels?;
    get dryRunAccessLevels(): string[];
    set dryRunAccessLevels(value: string[]);
    resetDryRunAccessLevels(): void;
    get dryRunAccessLevelsInput(): string[] | undefined;
    private _groupKey?;
    get groupKey(): string;
    set groupKey(value: string);
    resetGroupKey(): void;
    get groupKeyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _organizationId?;
    get organizationId(): string;
    set organizationId(value: string);
    get organizationIdInput(): string | undefined;
    private _principal;
    get principal(): AccessContextManagerGcpUserAccessBindingPrincipalOutputReference;
    putPrincipal(value: AccessContextManagerGcpUserAccessBindingPrincipal): void;
    resetPrincipal(): void;
    get principalInput(): AccessContextManagerGcpUserAccessBindingPrincipal | undefined;
    private _scopedAccessSettings;
    get scopedAccessSettings(): AccessContextManagerGcpUserAccessBindingScopedAccessSettingsList;
    putScopedAccessSettings(value: AccessContextManagerGcpUserAccessBindingScopedAccessSettings[] | cdktn.IResolvable): void;
    resetScopedAccessSettings(): void;
    get scopedAccessSettingsInput(): cdktn.IResolvable | AccessContextManagerGcpUserAccessBindingScopedAccessSettings[] | undefined;
    private _sessionSettings;
    get sessionSettings(): AccessContextManagerGcpUserAccessBindingSessionSettingsOutputReference;
    putSessionSettings(value: AccessContextManagerGcpUserAccessBindingSessionSettings): void;
    resetSessionSettings(): void;
    get sessionSettingsInput(): AccessContextManagerGcpUserAccessBindingSessionSettings | undefined;
    private _timeouts;
    get timeouts(): AccessContextManagerGcpUserAccessBindingTimeoutsOutputReference;
    putTimeouts(value: AccessContextManagerGcpUserAccessBindingTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AccessContextManagerGcpUserAccessBindingTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
