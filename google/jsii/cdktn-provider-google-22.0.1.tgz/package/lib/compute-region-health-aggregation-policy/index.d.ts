/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeRegionHealthAggregationPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_health_aggregation_policy#deletion_policy ComputeRegionHealthAggregationPolicy#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource. Provide this property when you
    * create the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_health_aggregation_policy#description ComputeRegionHealthAggregationPolicy#description}
    */
    readonly description?: string;
    /**
    * Can only be set if the 'policyType' field is
    * 'BACKEND_SERVICE_POLICY'. Specifies the threshold (as a
    * percentage) of healthy endpoints required in order to consider the
    * aggregated health result HEALTHY. Defaults to '60'. Must be in
    * range [0, 100]. Not applicable if the 'policyType' field is
    * 'DNB_PUBLIC_IP_POLICY'. Can be mutated. This field is optional,
    * and will be set to the default if unspecified. Note that both this
    * threshold and 'minHealthyThreshold' must be satisfied in order
    * for HEALTHY to be the aggregated result. "Endpoints" refers to network
    * endpoints within a Network Endpoint Group or instances within an Instance
    * Group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_health_aggregation_policy#healthy_percent_threshold ComputeRegionHealthAggregationPolicy#healthy_percent_threshold}
    */
    readonly healthyPercentThreshold?: number;
    /**
    * Can only be set if the 'policyType' field is
    * 'BACKEND_SERVICE_POLICY'. Specifies the minimum number of
    * healthy endpoints required in order to consider the aggregated health
    * result HEALTHY. Defaults to '1'. Must be positive. Not
    * applicable if the 'policyType' field is
    * 'DNB_PUBLIC_IP_POLICY'. Can be mutated. This field is optional,
    * and will be set to the default if unspecified. Note that both this
    * threshold and 'healthyPercentThreshold' must be satisfied in
    * order for HEALTHY to be the aggregated result. "Endpoints" refers to
    * network endpoints within a Network Endpoint Group or instances within an
    * Instance Group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_health_aggregation_policy#min_healthy_threshold ComputeRegionHealthAggregationPolicy#min_healthy_threshold}
    */
    readonly minHealthyThreshold?: number;
    /**
    * Name of the resource. Provided by the client when the resource is created.
    * The name must be 1-63 characters long, and comply with RFC1035.
    * Specifically, the name must be 1-63 characters long and match the regular
    * expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the first
    * character must be a lowercase letter, and all following characters must
    * be a dash, lowercase letter, or digit, except the last character, which
    * cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_health_aggregation_policy#name ComputeRegionHealthAggregationPolicy#name}
    */
    readonly name: string;
    /**
    * Specifies the type of the healthAggregationPolicy. The only allowed value
    * for global resources is 'DNS_PUBLIC_IP_POLICY'. The only allowed
    * value for regional resources is 'BACKEND_SERVICE_POLICY'. Must
    * be specified when the healthAggregationPolicy is created, and cannot be
    * mutated. Default value: "BACKEND_SERVICE_POLICY" Possible values: ["DNS_PUBLIC_IP_POLICY", "BACKEND_SERVICE_POLICY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_health_aggregation_policy#policy_type ComputeRegionHealthAggregationPolicy#policy_type}
    */
    readonly policyType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_health_aggregation_policy#project ComputeRegionHealthAggregationPolicy#project}
    */
    readonly project?: string;
    /**
    * URL of the region where the health aggregation policy resides.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_health_aggregation_policy#region ComputeRegionHealthAggregationPolicy#region}
    */
    readonly region: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_health_aggregation_policy#timeouts ComputeRegionHealthAggregationPolicy#timeouts}
    */
    readonly timeouts?: ComputeRegionHealthAggregationPolicyTimeouts;
}
export interface ComputeRegionHealthAggregationPolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_health_aggregation_policy#create ComputeRegionHealthAggregationPolicy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_health_aggregation_policy#delete ComputeRegionHealthAggregationPolicy#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_health_aggregation_policy#update ComputeRegionHealthAggregationPolicy#update}
    */
    readonly update?: string;
}
export declare function computeRegionHealthAggregationPolicyTimeoutsToTerraform(struct?: ComputeRegionHealthAggregationPolicyTimeouts | cdktn.IResolvable): any;
export declare function computeRegionHealthAggregationPolicyTimeoutsToHclTerraform(struct?: ComputeRegionHealthAggregationPolicyTimeouts | cdktn.IResolvable): any;
export declare class ComputeRegionHealthAggregationPolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionHealthAggregationPolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionHealthAggregationPolicyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_health_aggregation_policy google_compute_region_health_aggregation_policy}
*/
export declare class ComputeRegionHealthAggregationPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_region_health_aggregation_policy";
    /**
    * Generates CDKTN code for importing a ComputeRegionHealthAggregationPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeRegionHealthAggregationPolicy to import
    * @param importFromId The id of the existing ComputeRegionHealthAggregationPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_health_aggregation_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeRegionHealthAggregationPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_health_aggregation_policy google_compute_region_health_aggregation_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeRegionHealthAggregationPolicyConfig
    */
    constructor(scope: Construct, id: string, config: ComputeRegionHealthAggregationPolicyConfig);
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get fingerprint(): string;
    private _healthyPercentThreshold?;
    get healthyPercentThreshold(): number;
    set healthyPercentThreshold(value: number);
    resetHealthyPercentThreshold(): void;
    get healthyPercentThresholdInput(): number | undefined;
    get id(): string;
    private _minHealthyThreshold?;
    get minHealthyThreshold(): number;
    set minHealthyThreshold(value: number);
    resetMinHealthyThreshold(): void;
    get minHealthyThresholdInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _policyType?;
    get policyType(): string;
    set policyType(value: string);
    resetPolicyType(): void;
    get policyTypeInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    get selfLinkWithId(): string;
    private _timeouts;
    get timeouts(): ComputeRegionHealthAggregationPolicyTimeoutsOutputReference;
    putTimeouts(value: ComputeRegionHealthAggregationPolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeRegionHealthAggregationPolicyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
