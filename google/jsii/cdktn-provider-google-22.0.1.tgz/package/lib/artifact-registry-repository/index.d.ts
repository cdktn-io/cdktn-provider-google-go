/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ArtifactRegistryRepositoryConfig extends cdktn.TerraformMetaArguments {
    /**
    * If true, the cleanup pipeline is prevented from deleting versions in this
    * repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#cleanup_policy_dry_run ArtifactRegistryRepository#cleanup_policy_dry_run}
    */
    readonly cleanupPolicyDryRun?: boolean | cdktn.IResolvable;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#deletion_policy ArtifactRegistryRepository#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The user-provided description of the repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#description ArtifactRegistryRepository#description}
    */
    readonly description?: string;
    /**
    * If this is true, an unspecified repo type will be treated as error rather
    * than defaulting to standard.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#disallow_unspecified_mode ArtifactRegistryRepository#disallow_unspecified_mode}
    */
    readonly disallowUnspecifiedMode?: boolean | cdktn.IResolvable;
    /**
    * The format of packages that are stored in the repository. Supported formats
    * can be found [here](https://cloud.google.com/artifact-registry/docs/supported-formats).
    * You can only create alpha formats if you are a member of the
    * [alpha user group](https://cloud.google.com/artifact-registry/docs/supported-formats#alpha-access).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#format ArtifactRegistryRepository#format}
    */
    readonly format: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#id ArtifactRegistryRepository#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The Cloud KMS resource name of the customer managed encryption key that’s
    * used to encrypt the contents of the Repository. Has the form:
    * 'projects/my-project/locations/my-region/keyRings/my-kr/cryptoKeys/my-key'.
    * This value may not be changed after the Repository has been created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#kms_key_name ArtifactRegistryRepository#kms_key_name}
    */
    readonly kmsKeyName?: string;
    /**
    * Labels with user-defined metadata.
    * This field may contain up to 64 entries. Label keys and values may be no
    * longer than 63 characters. Label keys must begin with a lowercase letter
    * and may only contain lowercase letters, numeric characters, underscores,
    * and dashes.
    *
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#labels ArtifactRegistryRepository#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The name of the repository's location. In addition to specific regions,
    * special values for multi-region locations are 'asia', 'europe', and 'us'.
    * See [here](https://cloud.google.com/artifact-registry/docs/repositories/repo-locations),
    * or use the
    * [google_artifact_registry_locations](https://registry.terraform.io/providers/hashicorp/google/latest/docs/data-sources/artifact_registry_locations)
    * data source for possible values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#location ArtifactRegistryRepository#location}
    */
    readonly location?: string;
    /**
    * The mode configures the repository to serve artifacts from different sources. Default value: "STANDARD_REPOSITORY" Possible values: ["STANDARD_REPOSITORY", "VIRTUAL_REPOSITORY", "REMOTE_REPOSITORY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#mode ArtifactRegistryRepository#mode}
    */
    readonly mode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#project ArtifactRegistryRepository#project}
    */
    readonly project?: string;
    /**
    * The last part of the repository name, for example:
    * "repo1"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#repository_id ArtifactRegistryRepository#repository_id}
    */
    readonly repositoryId: string;
    /**
    * cleanup_policies block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#cleanup_policies ArtifactRegistryRepository#cleanup_policies}
    */
    readonly cleanupPolicies?: ArtifactRegistryRepositoryCleanupPolicies[] | cdktn.IResolvable;
    /**
    * docker_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#docker_config ArtifactRegistryRepository#docker_config}
    */
    readonly dockerConfig?: ArtifactRegistryRepositoryDockerConfig;
    /**
    * maven_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#maven_config ArtifactRegistryRepository#maven_config}
    */
    readonly mavenConfig?: ArtifactRegistryRepositoryMavenConfig;
    /**
    * platform_logs_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#platform_logs_config ArtifactRegistryRepository#platform_logs_config}
    */
    readonly platformLogsConfig?: ArtifactRegistryRepositoryPlatformLogsConfig;
    /**
    * remote_repository_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#remote_repository_config ArtifactRegistryRepository#remote_repository_config}
    */
    readonly remoteRepositoryConfig?: ArtifactRegistryRepositoryRemoteRepositoryConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#timeouts ArtifactRegistryRepository#timeouts}
    */
    readonly timeouts?: ArtifactRegistryRepositoryTimeouts;
    /**
    * virtual_repository_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#virtual_repository_config ArtifactRegistryRepository#virtual_repository_config}
    */
    readonly virtualRepositoryConfig?: ArtifactRegistryRepositoryVirtualRepositoryConfig;
    /**
    * vulnerability_scanning_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#vulnerability_scanning_config ArtifactRegistryRepository#vulnerability_scanning_config}
    */
    readonly vulnerabilityScanningConfig?: ArtifactRegistryRepositoryVulnerabilityScanningConfig;
}
export interface ArtifactRegistryRepositoryCleanupPoliciesCondition {
    /**
    * Match versions newer than a duration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#newer_than ArtifactRegistryRepository#newer_than}
    */
    readonly newerThan?: string;
    /**
    * Match versions older than a duration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#older_than ArtifactRegistryRepository#older_than}
    */
    readonly olderThan?: string;
    /**
    * Match versions by package prefix. Applied on any prefix match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#package_name_prefixes ArtifactRegistryRepository#package_name_prefixes}
    */
    readonly packageNamePrefixes?: string[];
    /**
    * Match versions by tag prefix. Applied on any prefix match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#tag_prefixes ArtifactRegistryRepository#tag_prefixes}
    */
    readonly tagPrefixes?: string[];
    /**
    * Match versions by tag status. Default value: "ANY" Possible values: ["TAGGED", "UNTAGGED", "ANY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#tag_state ArtifactRegistryRepository#tag_state}
    */
    readonly tagState?: string;
    /**
    * Match versions by version name prefix. Applied on any prefix match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#version_name_prefixes ArtifactRegistryRepository#version_name_prefixes}
    */
    readonly versionNamePrefixes?: string[];
}
export declare function artifactRegistryRepositoryCleanupPoliciesConditionToTerraform(struct?: ArtifactRegistryRepositoryCleanupPoliciesConditionOutputReference | ArtifactRegistryRepositoryCleanupPoliciesCondition): any;
export declare function artifactRegistryRepositoryCleanupPoliciesConditionToHclTerraform(struct?: ArtifactRegistryRepositoryCleanupPoliciesConditionOutputReference | ArtifactRegistryRepositoryCleanupPoliciesCondition): any;
export declare class ArtifactRegistryRepositoryCleanupPoliciesConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryRepositoryCleanupPoliciesCondition | undefined;
    set internalValue(value: ArtifactRegistryRepositoryCleanupPoliciesCondition | undefined);
    private _newerThan?;
    get newerThan(): string;
    set newerThan(value: string);
    resetNewerThan(): void;
    get newerThanInput(): string | undefined;
    private _olderThan?;
    get olderThan(): string;
    set olderThan(value: string);
    resetOlderThan(): void;
    get olderThanInput(): string | undefined;
    private _packageNamePrefixes?;
    get packageNamePrefixes(): string[];
    set packageNamePrefixes(value: string[]);
    resetPackageNamePrefixes(): void;
    get packageNamePrefixesInput(): string[] | undefined;
    private _tagPrefixes?;
    get tagPrefixes(): string[];
    set tagPrefixes(value: string[]);
    resetTagPrefixes(): void;
    get tagPrefixesInput(): string[] | undefined;
    private _tagState?;
    get tagState(): string;
    set tagState(value: string);
    resetTagState(): void;
    get tagStateInput(): string | undefined;
    private _versionNamePrefixes?;
    get versionNamePrefixes(): string[];
    set versionNamePrefixes(value: string[]);
    resetVersionNamePrefixes(): void;
    get versionNamePrefixesInput(): string[] | undefined;
}
export interface ArtifactRegistryRepositoryCleanupPoliciesMostRecentVersions {
    /**
    * Minimum number of versions to keep.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#keep_count ArtifactRegistryRepository#keep_count}
    */
    readonly keepCount?: number;
    /**
    * Match versions by package prefix. Applied on any prefix match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#package_name_prefixes ArtifactRegistryRepository#package_name_prefixes}
    */
    readonly packageNamePrefixes?: string[];
}
export declare function artifactRegistryRepositoryCleanupPoliciesMostRecentVersionsToTerraform(struct?: ArtifactRegistryRepositoryCleanupPoliciesMostRecentVersionsOutputReference | ArtifactRegistryRepositoryCleanupPoliciesMostRecentVersions): any;
export declare function artifactRegistryRepositoryCleanupPoliciesMostRecentVersionsToHclTerraform(struct?: ArtifactRegistryRepositoryCleanupPoliciesMostRecentVersionsOutputReference | ArtifactRegistryRepositoryCleanupPoliciesMostRecentVersions): any;
export declare class ArtifactRegistryRepositoryCleanupPoliciesMostRecentVersionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryRepositoryCleanupPoliciesMostRecentVersions | undefined;
    set internalValue(value: ArtifactRegistryRepositoryCleanupPoliciesMostRecentVersions | undefined);
    private _keepCount?;
    get keepCount(): number;
    set keepCount(value: number);
    resetKeepCount(): void;
    get keepCountInput(): number | undefined;
    private _packageNamePrefixes?;
    get packageNamePrefixes(): string[];
    set packageNamePrefixes(value: string[]);
    resetPackageNamePrefixes(): void;
    get packageNamePrefixesInput(): string[] | undefined;
}
export interface ArtifactRegistryRepositoryCleanupPolicies {
    /**
    * Policy action. Possible values: ["DELETE", "KEEP"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#action ArtifactRegistryRepository#action}
    */
    readonly action?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#id ArtifactRegistryRepository#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#condition ArtifactRegistryRepository#condition}
    */
    readonly condition?: ArtifactRegistryRepositoryCleanupPoliciesCondition;
    /**
    * most_recent_versions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#most_recent_versions ArtifactRegistryRepository#most_recent_versions}
    */
    readonly mostRecentVersions?: ArtifactRegistryRepositoryCleanupPoliciesMostRecentVersions;
}
export declare function artifactRegistryRepositoryCleanupPoliciesToTerraform(struct?: ArtifactRegistryRepositoryCleanupPolicies | cdktn.IResolvable): any;
export declare function artifactRegistryRepositoryCleanupPoliciesToHclTerraform(struct?: ArtifactRegistryRepositoryCleanupPolicies | cdktn.IResolvable): any;
export declare class ArtifactRegistryRepositoryCleanupPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArtifactRegistryRepositoryCleanupPolicies | cdktn.IResolvable | undefined;
    set internalValue(value: ArtifactRegistryRepositoryCleanupPolicies | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _condition;
    get condition(): ArtifactRegistryRepositoryCleanupPoliciesConditionOutputReference;
    putCondition(value: ArtifactRegistryRepositoryCleanupPoliciesCondition): void;
    resetCondition(): void;
    get conditionInput(): ArtifactRegistryRepositoryCleanupPoliciesCondition | undefined;
    private _mostRecentVersions;
    get mostRecentVersions(): ArtifactRegistryRepositoryCleanupPoliciesMostRecentVersionsOutputReference;
    putMostRecentVersions(value: ArtifactRegistryRepositoryCleanupPoliciesMostRecentVersions): void;
    resetMostRecentVersions(): void;
    get mostRecentVersionsInput(): ArtifactRegistryRepositoryCleanupPoliciesMostRecentVersions | undefined;
}
export declare class ArtifactRegistryRepositoryCleanupPoliciesList extends cdktn.ComplexList {
    internalValue?: ArtifactRegistryRepositoryCleanupPolicies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArtifactRegistryRepositoryCleanupPoliciesOutputReference;
}
export interface ArtifactRegistryRepositoryDockerConfig {
    /**
    * The repository which enabled this flag prevents all tags from being modified, moved or deleted. This does not prevent tags from being created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#immutable_tags ArtifactRegistryRepository#immutable_tags}
    */
    readonly immutableTags?: boolean | cdktn.IResolvable;
}
export declare function artifactRegistryRepositoryDockerConfigToTerraform(struct?: ArtifactRegistryRepositoryDockerConfigOutputReference | ArtifactRegistryRepositoryDockerConfig): any;
export declare function artifactRegistryRepositoryDockerConfigToHclTerraform(struct?: ArtifactRegistryRepositoryDockerConfigOutputReference | ArtifactRegistryRepositoryDockerConfig): any;
export declare class ArtifactRegistryRepositoryDockerConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryRepositoryDockerConfig | undefined;
    set internalValue(value: ArtifactRegistryRepositoryDockerConfig | undefined);
    private _immutableTags?;
    get immutableTags(): boolean | cdktn.IResolvable;
    set immutableTags(value: boolean | cdktn.IResolvable);
    resetImmutableTags(): void;
    get immutableTagsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ArtifactRegistryRepositoryMavenConfig {
    /**
    * The repository with this flag will allow publishing the same
    * snapshot versions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#allow_snapshot_overwrites ArtifactRegistryRepository#allow_snapshot_overwrites}
    */
    readonly allowSnapshotOverwrites?: boolean | cdktn.IResolvable;
    /**
    * Version policy defines the versions that the registry will accept. Default value: "VERSION_POLICY_UNSPECIFIED" Possible values: ["VERSION_POLICY_UNSPECIFIED", "RELEASE", "SNAPSHOT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#version_policy ArtifactRegistryRepository#version_policy}
    */
    readonly versionPolicy?: string;
}
export declare function artifactRegistryRepositoryMavenConfigToTerraform(struct?: ArtifactRegistryRepositoryMavenConfigOutputReference | ArtifactRegistryRepositoryMavenConfig): any;
export declare function artifactRegistryRepositoryMavenConfigToHclTerraform(struct?: ArtifactRegistryRepositoryMavenConfigOutputReference | ArtifactRegistryRepositoryMavenConfig): any;
export declare class ArtifactRegistryRepositoryMavenConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryRepositoryMavenConfig | undefined;
    set internalValue(value: ArtifactRegistryRepositoryMavenConfig | undefined);
    private _allowSnapshotOverwrites?;
    get allowSnapshotOverwrites(): boolean | cdktn.IResolvable;
    set allowSnapshotOverwrites(value: boolean | cdktn.IResolvable);
    resetAllowSnapshotOverwrites(): void;
    get allowSnapshotOverwritesInput(): boolean | cdktn.IResolvable | undefined;
    private _versionPolicy?;
    get versionPolicy(): string;
    set versionPolicy(value: string);
    resetVersionPolicy(): void;
    get versionPolicyInput(): string | undefined;
}
export interface ArtifactRegistryRepositoryPlatformLogsConfig {
    /**
    * The state of the platform logs: enabled or disabled. Possible values: ["ENABLED", "DISABLED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#logging_state ArtifactRegistryRepository#logging_state}
    */
    readonly loggingState?: string;
    /**
    * The severity level for the logs. Logs will be generated if their
    * severity level is >= than the value of the severity level mentioned here. Possible values: ["DEBUG", "INFO", "NOTICE", "WARNING", "ERROR", "CRITICAL", "ALERT", "EMERGENCY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#severity_level ArtifactRegistryRepository#severity_level}
    */
    readonly severityLevel?: string;
}
export declare function artifactRegistryRepositoryPlatformLogsConfigToTerraform(struct?: ArtifactRegistryRepositoryPlatformLogsConfigOutputReference | ArtifactRegistryRepositoryPlatformLogsConfig): any;
export declare function artifactRegistryRepositoryPlatformLogsConfigToHclTerraform(struct?: ArtifactRegistryRepositoryPlatformLogsConfigOutputReference | ArtifactRegistryRepositoryPlatformLogsConfig): any;
export declare class ArtifactRegistryRepositoryPlatformLogsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryRepositoryPlatformLogsConfig | undefined;
    set internalValue(value: ArtifactRegistryRepositoryPlatformLogsConfig | undefined);
    private _loggingState?;
    get loggingState(): string;
    set loggingState(value: string);
    resetLoggingState(): void;
    get loggingStateInput(): string | undefined;
    private _severityLevel?;
    get severityLevel(): string;
    set severityLevel(value: string);
    resetSeverityLevel(): void;
    get severityLevelInput(): string | undefined;
}
export interface ArtifactRegistryRepositoryRemoteRepositoryConfigAptRepositoryPublicRepository {
    /**
    * A common public repository base for Apt, e.g. '"debian/dists/stable"' Possible values: ["DEBIAN", "UBUNTU", "DEBIAN_SNAPSHOT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#repository_base ArtifactRegistryRepository#repository_base}
    */
    readonly repositoryBase: string;
    /**
    * Specific repository from the base.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#repository_path ArtifactRegistryRepository#repository_path}
    */
    readonly repositoryPath: string;
}
export declare function artifactRegistryRepositoryRemoteRepositoryConfigAptRepositoryPublicRepositoryToTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigAptRepositoryPublicRepositoryOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigAptRepositoryPublicRepository): any;
export declare function artifactRegistryRepositoryRemoteRepositoryConfigAptRepositoryPublicRepositoryToHclTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigAptRepositoryPublicRepositoryOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigAptRepositoryPublicRepository): any;
export declare class ArtifactRegistryRepositoryRemoteRepositoryConfigAptRepositoryPublicRepositoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryRepositoryRemoteRepositoryConfigAptRepositoryPublicRepository | undefined;
    set internalValue(value: ArtifactRegistryRepositoryRemoteRepositoryConfigAptRepositoryPublicRepository | undefined);
    private _repositoryBase?;
    get repositoryBase(): string;
    set repositoryBase(value: string);
    get repositoryBaseInput(): string | undefined;
    private _repositoryPath?;
    get repositoryPath(): string;
    set repositoryPath(value: string);
    get repositoryPathInput(): string | undefined;
}
export interface ArtifactRegistryRepositoryRemoteRepositoryConfigAptRepository {
    /**
    * public_repository block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#public_repository ArtifactRegistryRepository#public_repository}
    */
    readonly publicRepository?: ArtifactRegistryRepositoryRemoteRepositoryConfigAptRepositoryPublicRepository;
}
export declare function artifactRegistryRepositoryRemoteRepositoryConfigAptRepositoryToTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigAptRepositoryOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigAptRepository): any;
export declare function artifactRegistryRepositoryRemoteRepositoryConfigAptRepositoryToHclTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigAptRepositoryOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigAptRepository): any;
export declare class ArtifactRegistryRepositoryRemoteRepositoryConfigAptRepositoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryRepositoryRemoteRepositoryConfigAptRepository | undefined;
    set internalValue(value: ArtifactRegistryRepositoryRemoteRepositoryConfigAptRepository | undefined);
    private _publicRepository;
    get publicRepository(): ArtifactRegistryRepositoryRemoteRepositoryConfigAptRepositoryPublicRepositoryOutputReference;
    putPublicRepository(value: ArtifactRegistryRepositoryRemoteRepositoryConfigAptRepositoryPublicRepository): void;
    resetPublicRepository(): void;
    get publicRepositoryInput(): ArtifactRegistryRepositoryRemoteRepositoryConfigAptRepositoryPublicRepository | undefined;
}
export interface ArtifactRegistryRepositoryRemoteRepositoryConfigCommonRepository {
    /**
    * One of:
    * a. Artifact Registry Repository resource, e.g. 'projects/UPSTREAM_PROJECT_ID/locations/REGION/repositories/UPSTREAM_REPOSITORY'
    * b. URI to the registry, e.g. '"https://registry-1.docker.io"'
    * c. URI to Artifact Registry Repository, e.g. '"https://REGION-docker.pkg.dev/UPSTREAM_PROJECT_ID/UPSTREAM_REPOSITORY"'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#uri ArtifactRegistryRepository#uri}
    */
    readonly uri: string;
}
export declare function artifactRegistryRepositoryRemoteRepositoryConfigCommonRepositoryToTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigCommonRepositoryOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigCommonRepository): any;
export declare function artifactRegistryRepositoryRemoteRepositoryConfigCommonRepositoryToHclTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigCommonRepositoryOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigCommonRepository): any;
export declare class ArtifactRegistryRepositoryRemoteRepositoryConfigCommonRepositoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryRepositoryRemoteRepositoryConfigCommonRepository | undefined;
    set internalValue(value: ArtifactRegistryRepositoryRemoteRepositoryConfigCommonRepository | undefined);
    private _uri?;
    get uri(): string;
    set uri(value: string);
    get uriInput(): string | undefined;
}
export interface ArtifactRegistryRepositoryRemoteRepositoryConfigDockerRepositoryCustomRepository {
    /**
    * Specific uri to the registry, e.g. '"https://registry-1.docker.io"'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#uri ArtifactRegistryRepository#uri}
    */
    readonly uri?: string;
}
export declare function artifactRegistryRepositoryRemoteRepositoryConfigDockerRepositoryCustomRepositoryToTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigDockerRepositoryCustomRepositoryOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigDockerRepositoryCustomRepository): any;
export declare function artifactRegistryRepositoryRemoteRepositoryConfigDockerRepositoryCustomRepositoryToHclTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigDockerRepositoryCustomRepositoryOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigDockerRepositoryCustomRepository): any;
export declare class ArtifactRegistryRepositoryRemoteRepositoryConfigDockerRepositoryCustomRepositoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryRepositoryRemoteRepositoryConfigDockerRepositoryCustomRepository | undefined;
    set internalValue(value: ArtifactRegistryRepositoryRemoteRepositoryConfigDockerRepositoryCustomRepository | undefined);
    private _uri?;
    get uri(): string;
    set uri(value: string);
    resetUri(): void;
    get uriInput(): string | undefined;
}
export interface ArtifactRegistryRepositoryRemoteRepositoryConfigDockerRepository {
    /**
    * Address of the remote repository. Possible values: ["DOCKER_HUB"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#public_repository ArtifactRegistryRepository#public_repository}
    */
    readonly publicRepository?: string;
    /**
    * custom_repository block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#custom_repository ArtifactRegistryRepository#custom_repository}
    */
    readonly customRepository?: ArtifactRegistryRepositoryRemoteRepositoryConfigDockerRepositoryCustomRepository;
}
export declare function artifactRegistryRepositoryRemoteRepositoryConfigDockerRepositoryToTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigDockerRepositoryOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigDockerRepository): any;
export declare function artifactRegistryRepositoryRemoteRepositoryConfigDockerRepositoryToHclTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigDockerRepositoryOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigDockerRepository): any;
export declare class ArtifactRegistryRepositoryRemoteRepositoryConfigDockerRepositoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryRepositoryRemoteRepositoryConfigDockerRepository | undefined;
    set internalValue(value: ArtifactRegistryRepositoryRemoteRepositoryConfigDockerRepository | undefined);
    private _publicRepository?;
    get publicRepository(): string;
    set publicRepository(value: string);
    resetPublicRepository(): void;
    get publicRepositoryInput(): string | undefined;
    private _customRepository;
    get customRepository(): ArtifactRegistryRepositoryRemoteRepositoryConfigDockerRepositoryCustomRepositoryOutputReference;
    putCustomRepository(value: ArtifactRegistryRepositoryRemoteRepositoryConfigDockerRepositoryCustomRepository): void;
    resetCustomRepository(): void;
    get customRepositoryInput(): ArtifactRegistryRepositoryRemoteRepositoryConfigDockerRepositoryCustomRepository | undefined;
}
export interface ArtifactRegistryRepositoryRemoteRepositoryConfigMavenRepositoryCustomRepository {
    /**
    * Specific uri to the registry, e.g. '"https://repo.maven.apache.org/maven2"'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#uri ArtifactRegistryRepository#uri}
    */
    readonly uri?: string;
}
export declare function artifactRegistryRepositoryRemoteRepositoryConfigMavenRepositoryCustomRepositoryToTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigMavenRepositoryCustomRepositoryOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigMavenRepositoryCustomRepository): any;
export declare function artifactRegistryRepositoryRemoteRepositoryConfigMavenRepositoryCustomRepositoryToHclTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigMavenRepositoryCustomRepositoryOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigMavenRepositoryCustomRepository): any;
export declare class ArtifactRegistryRepositoryRemoteRepositoryConfigMavenRepositoryCustomRepositoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryRepositoryRemoteRepositoryConfigMavenRepositoryCustomRepository | undefined;
    set internalValue(value: ArtifactRegistryRepositoryRemoteRepositoryConfigMavenRepositoryCustomRepository | undefined);
    private _uri?;
    get uri(): string;
    set uri(value: string);
    resetUri(): void;
    get uriInput(): string | undefined;
}
export interface ArtifactRegistryRepositoryRemoteRepositoryConfigMavenRepository {
    /**
    * Address of the remote repository. Possible values: ["MAVEN_CENTRAL"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#public_repository ArtifactRegistryRepository#public_repository}
    */
    readonly publicRepository?: string;
    /**
    * custom_repository block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#custom_repository ArtifactRegistryRepository#custom_repository}
    */
    readonly customRepository?: ArtifactRegistryRepositoryRemoteRepositoryConfigMavenRepositoryCustomRepository;
}
export declare function artifactRegistryRepositoryRemoteRepositoryConfigMavenRepositoryToTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigMavenRepositoryOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigMavenRepository): any;
export declare function artifactRegistryRepositoryRemoteRepositoryConfigMavenRepositoryToHclTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigMavenRepositoryOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigMavenRepository): any;
export declare class ArtifactRegistryRepositoryRemoteRepositoryConfigMavenRepositoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryRepositoryRemoteRepositoryConfigMavenRepository | undefined;
    set internalValue(value: ArtifactRegistryRepositoryRemoteRepositoryConfigMavenRepository | undefined);
    private _publicRepository?;
    get publicRepository(): string;
    set publicRepository(value: string);
    resetPublicRepository(): void;
    get publicRepositoryInput(): string | undefined;
    private _customRepository;
    get customRepository(): ArtifactRegistryRepositoryRemoteRepositoryConfigMavenRepositoryCustomRepositoryOutputReference;
    putCustomRepository(value: ArtifactRegistryRepositoryRemoteRepositoryConfigMavenRepositoryCustomRepository): void;
    resetCustomRepository(): void;
    get customRepositoryInput(): ArtifactRegistryRepositoryRemoteRepositoryConfigMavenRepositoryCustomRepository | undefined;
}
export interface ArtifactRegistryRepositoryRemoteRepositoryConfigNoCache {
}
export declare function artifactRegistryRepositoryRemoteRepositoryConfigNoCacheToTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigNoCacheOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigNoCache): any;
export declare function artifactRegistryRepositoryRemoteRepositoryConfigNoCacheToHclTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigNoCacheOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigNoCache): any;
export declare class ArtifactRegistryRepositoryRemoteRepositoryConfigNoCacheOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryRepositoryRemoteRepositoryConfigNoCache | undefined;
    set internalValue(value: ArtifactRegistryRepositoryRemoteRepositoryConfigNoCache | undefined);
}
export interface ArtifactRegistryRepositoryRemoteRepositoryConfigNpmRepositoryCustomRepository {
    /**
    * Specific uri to the registry, e.g. '"https://registry.npmjs.org"'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#uri ArtifactRegistryRepository#uri}
    */
    readonly uri?: string;
}
export declare function artifactRegistryRepositoryRemoteRepositoryConfigNpmRepositoryCustomRepositoryToTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigNpmRepositoryCustomRepositoryOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigNpmRepositoryCustomRepository): any;
export declare function artifactRegistryRepositoryRemoteRepositoryConfigNpmRepositoryCustomRepositoryToHclTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigNpmRepositoryCustomRepositoryOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigNpmRepositoryCustomRepository): any;
export declare class ArtifactRegistryRepositoryRemoteRepositoryConfigNpmRepositoryCustomRepositoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryRepositoryRemoteRepositoryConfigNpmRepositoryCustomRepository | undefined;
    set internalValue(value: ArtifactRegistryRepositoryRemoteRepositoryConfigNpmRepositoryCustomRepository | undefined);
    private _uri?;
    get uri(): string;
    set uri(value: string);
    resetUri(): void;
    get uriInput(): string | undefined;
}
export interface ArtifactRegistryRepositoryRemoteRepositoryConfigNpmRepository {
    /**
    * Address of the remote repository. Possible values: ["NPMJS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#public_repository ArtifactRegistryRepository#public_repository}
    */
    readonly publicRepository?: string;
    /**
    * custom_repository block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#custom_repository ArtifactRegistryRepository#custom_repository}
    */
    readonly customRepository?: ArtifactRegistryRepositoryRemoteRepositoryConfigNpmRepositoryCustomRepository;
}
export declare function artifactRegistryRepositoryRemoteRepositoryConfigNpmRepositoryToTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigNpmRepositoryOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigNpmRepository): any;
export declare function artifactRegistryRepositoryRemoteRepositoryConfigNpmRepositoryToHclTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigNpmRepositoryOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigNpmRepository): any;
export declare class ArtifactRegistryRepositoryRemoteRepositoryConfigNpmRepositoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryRepositoryRemoteRepositoryConfigNpmRepository | undefined;
    set internalValue(value: ArtifactRegistryRepositoryRemoteRepositoryConfigNpmRepository | undefined);
    private _publicRepository?;
    get publicRepository(): string;
    set publicRepository(value: string);
    resetPublicRepository(): void;
    get publicRepositoryInput(): string | undefined;
    private _customRepository;
    get customRepository(): ArtifactRegistryRepositoryRemoteRepositoryConfigNpmRepositoryCustomRepositoryOutputReference;
    putCustomRepository(value: ArtifactRegistryRepositoryRemoteRepositoryConfigNpmRepositoryCustomRepository): void;
    resetCustomRepository(): void;
    get customRepositoryInput(): ArtifactRegistryRepositoryRemoteRepositoryConfigNpmRepositoryCustomRepository | undefined;
}
export interface ArtifactRegistryRepositoryRemoteRepositoryConfigPythonRepositoryCustomRepository {
    /**
    * Specific uri to the registry, e.g. '"https://pypi.io"'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#uri ArtifactRegistryRepository#uri}
    */
    readonly uri?: string;
}
export declare function artifactRegistryRepositoryRemoteRepositoryConfigPythonRepositoryCustomRepositoryToTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigPythonRepositoryCustomRepositoryOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigPythonRepositoryCustomRepository): any;
export declare function artifactRegistryRepositoryRemoteRepositoryConfigPythonRepositoryCustomRepositoryToHclTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigPythonRepositoryCustomRepositoryOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigPythonRepositoryCustomRepository): any;
export declare class ArtifactRegistryRepositoryRemoteRepositoryConfigPythonRepositoryCustomRepositoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryRepositoryRemoteRepositoryConfigPythonRepositoryCustomRepository | undefined;
    set internalValue(value: ArtifactRegistryRepositoryRemoteRepositoryConfigPythonRepositoryCustomRepository | undefined);
    private _uri?;
    get uri(): string;
    set uri(value: string);
    resetUri(): void;
    get uriInput(): string | undefined;
}
export interface ArtifactRegistryRepositoryRemoteRepositoryConfigPythonRepository {
    /**
    * Address of the remote repository. Possible values: ["PYPI"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#public_repository ArtifactRegistryRepository#public_repository}
    */
    readonly publicRepository?: string;
    /**
    * custom_repository block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#custom_repository ArtifactRegistryRepository#custom_repository}
    */
    readonly customRepository?: ArtifactRegistryRepositoryRemoteRepositoryConfigPythonRepositoryCustomRepository;
}
export declare function artifactRegistryRepositoryRemoteRepositoryConfigPythonRepositoryToTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigPythonRepositoryOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigPythonRepository): any;
export declare function artifactRegistryRepositoryRemoteRepositoryConfigPythonRepositoryToHclTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigPythonRepositoryOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigPythonRepository): any;
export declare class ArtifactRegistryRepositoryRemoteRepositoryConfigPythonRepositoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryRepositoryRemoteRepositoryConfigPythonRepository | undefined;
    set internalValue(value: ArtifactRegistryRepositoryRemoteRepositoryConfigPythonRepository | undefined);
    private _publicRepository?;
    get publicRepository(): string;
    set publicRepository(value: string);
    resetPublicRepository(): void;
    get publicRepositoryInput(): string | undefined;
    private _customRepository;
    get customRepository(): ArtifactRegistryRepositoryRemoteRepositoryConfigPythonRepositoryCustomRepositoryOutputReference;
    putCustomRepository(value: ArtifactRegistryRepositoryRemoteRepositoryConfigPythonRepositoryCustomRepository): void;
    resetCustomRepository(): void;
    get customRepositoryInput(): ArtifactRegistryRepositoryRemoteRepositoryConfigPythonRepositoryCustomRepository | undefined;
}
export interface ArtifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentialsUsernamePasswordCredentials {
    /**
    * The Secret Manager key version that holds the password to access the
    * remote repository. Must be in the format of
    * 'projects/{project}/secrets/{secret}/versions/{version}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#password_secret_version ArtifactRegistryRepository#password_secret_version}
    */
    readonly passwordSecretVersion?: string;
    /**
    * The username to access the remote repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#username ArtifactRegistryRepository#username}
    */
    readonly username?: string;
}
export declare function artifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentialsUsernamePasswordCredentialsToTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentialsUsernamePasswordCredentialsOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentialsUsernamePasswordCredentials): any;
export declare function artifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentialsUsernamePasswordCredentialsToHclTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentialsUsernamePasswordCredentialsOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentialsUsernamePasswordCredentials): any;
export declare class ArtifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentialsUsernamePasswordCredentialsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentialsUsernamePasswordCredentials | undefined;
    set internalValue(value: ArtifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentialsUsernamePasswordCredentials | undefined);
    private _passwordSecretVersion?;
    get passwordSecretVersion(): string;
    set passwordSecretVersion(value: string);
    resetPasswordSecretVersion(): void;
    get passwordSecretVersionInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
}
export interface ArtifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentials {
    /**
    * username_password_credentials block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#username_password_credentials ArtifactRegistryRepository#username_password_credentials}
    */
    readonly usernamePasswordCredentials?: ArtifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentialsUsernamePasswordCredentials;
}
export declare function artifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentialsToTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentialsOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentials): any;
export declare function artifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentialsToHclTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentialsOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentials): any;
export declare class ArtifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentialsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentials | undefined;
    set internalValue(value: ArtifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentials | undefined);
    private _usernamePasswordCredentials;
    get usernamePasswordCredentials(): ArtifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentialsUsernamePasswordCredentialsOutputReference;
    putUsernamePasswordCredentials(value: ArtifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentialsUsernamePasswordCredentials): void;
    resetUsernamePasswordCredentials(): void;
    get usernamePasswordCredentialsInput(): ArtifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentialsUsernamePasswordCredentials | undefined;
}
export interface ArtifactRegistryRepositoryRemoteRepositoryConfigYumRepositoryPublicRepository {
    /**
    * A common public repository base for Yum. Possible values: ["CENTOS", "CENTOS_DEBUG", "CENTOS_VAULT", "CENTOS_STREAM", "ROCKY", "EPEL"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#repository_base ArtifactRegistryRepository#repository_base}
    */
    readonly repositoryBase: string;
    /**
    * Specific repository from the base, e.g. '"pub/rocky/9/BaseOS/x86_64/os"'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#repository_path ArtifactRegistryRepository#repository_path}
    */
    readonly repositoryPath: string;
}
export declare function artifactRegistryRepositoryRemoteRepositoryConfigYumRepositoryPublicRepositoryToTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigYumRepositoryPublicRepositoryOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigYumRepositoryPublicRepository): any;
export declare function artifactRegistryRepositoryRemoteRepositoryConfigYumRepositoryPublicRepositoryToHclTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigYumRepositoryPublicRepositoryOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigYumRepositoryPublicRepository): any;
export declare class ArtifactRegistryRepositoryRemoteRepositoryConfigYumRepositoryPublicRepositoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryRepositoryRemoteRepositoryConfigYumRepositoryPublicRepository | undefined;
    set internalValue(value: ArtifactRegistryRepositoryRemoteRepositoryConfigYumRepositoryPublicRepository | undefined);
    private _repositoryBase?;
    get repositoryBase(): string;
    set repositoryBase(value: string);
    get repositoryBaseInput(): string | undefined;
    private _repositoryPath?;
    get repositoryPath(): string;
    set repositoryPath(value: string);
    get repositoryPathInput(): string | undefined;
}
export interface ArtifactRegistryRepositoryRemoteRepositoryConfigYumRepository {
    /**
    * public_repository block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#public_repository ArtifactRegistryRepository#public_repository}
    */
    readonly publicRepository?: ArtifactRegistryRepositoryRemoteRepositoryConfigYumRepositoryPublicRepository;
}
export declare function artifactRegistryRepositoryRemoteRepositoryConfigYumRepositoryToTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigYumRepositoryOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigYumRepository): any;
export declare function artifactRegistryRepositoryRemoteRepositoryConfigYumRepositoryToHclTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigYumRepositoryOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfigYumRepository): any;
export declare class ArtifactRegistryRepositoryRemoteRepositoryConfigYumRepositoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryRepositoryRemoteRepositoryConfigYumRepository | undefined;
    set internalValue(value: ArtifactRegistryRepositoryRemoteRepositoryConfigYumRepository | undefined);
    private _publicRepository;
    get publicRepository(): ArtifactRegistryRepositoryRemoteRepositoryConfigYumRepositoryPublicRepositoryOutputReference;
    putPublicRepository(value: ArtifactRegistryRepositoryRemoteRepositoryConfigYumRepositoryPublicRepository): void;
    resetPublicRepository(): void;
    get publicRepositoryInput(): ArtifactRegistryRepositoryRemoteRepositoryConfigYumRepositoryPublicRepository | undefined;
}
export interface ArtifactRegistryRepositoryRemoteRepositoryConfig {
    /**
    * The description of the remote source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#description ArtifactRegistryRepository#description}
    */
    readonly description?: string;
    /**
    * If true, the remote repository upstream and upstream credentials will
    * not be validated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#disable_upstream_validation ArtifactRegistryRepository#disable_upstream_validation}
    */
    readonly disableUpstreamValidation?: boolean | cdktn.IResolvable;
    /**
    * apt_repository block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#apt_repository ArtifactRegistryRepository#apt_repository}
    */
    readonly aptRepository?: ArtifactRegistryRepositoryRemoteRepositoryConfigAptRepository;
    /**
    * common_repository block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#common_repository ArtifactRegistryRepository#common_repository}
    */
    readonly commonRepository?: ArtifactRegistryRepositoryRemoteRepositoryConfigCommonRepository;
    /**
    * docker_repository block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#docker_repository ArtifactRegistryRepository#docker_repository}
    */
    readonly dockerRepository?: ArtifactRegistryRepositoryRemoteRepositoryConfigDockerRepository;
    /**
    * maven_repository block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#maven_repository ArtifactRegistryRepository#maven_repository}
    */
    readonly mavenRepository?: ArtifactRegistryRepositoryRemoteRepositoryConfigMavenRepository;
    /**
    * no_cache block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#no_cache ArtifactRegistryRepository#no_cache}
    */
    readonly noCache?: ArtifactRegistryRepositoryRemoteRepositoryConfigNoCache;
    /**
    * npm_repository block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#npm_repository ArtifactRegistryRepository#npm_repository}
    */
    readonly npmRepository?: ArtifactRegistryRepositoryRemoteRepositoryConfigNpmRepository;
    /**
    * python_repository block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#python_repository ArtifactRegistryRepository#python_repository}
    */
    readonly pythonRepository?: ArtifactRegistryRepositoryRemoteRepositoryConfigPythonRepository;
    /**
    * upstream_credentials block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#upstream_credentials ArtifactRegistryRepository#upstream_credentials}
    */
    readonly upstreamCredentials?: ArtifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentials;
    /**
    * yum_repository block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#yum_repository ArtifactRegistryRepository#yum_repository}
    */
    readonly yumRepository?: ArtifactRegistryRepositoryRemoteRepositoryConfigYumRepository;
}
export declare function artifactRegistryRepositoryRemoteRepositoryConfigToTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfig): any;
export declare function artifactRegistryRepositoryRemoteRepositoryConfigToHclTerraform(struct?: ArtifactRegistryRepositoryRemoteRepositoryConfigOutputReference | ArtifactRegistryRepositoryRemoteRepositoryConfig): any;
export declare class ArtifactRegistryRepositoryRemoteRepositoryConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryRepositoryRemoteRepositoryConfig | undefined;
    set internalValue(value: ArtifactRegistryRepositoryRemoteRepositoryConfig | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disableUpstreamValidation?;
    get disableUpstreamValidation(): boolean | cdktn.IResolvable;
    set disableUpstreamValidation(value: boolean | cdktn.IResolvable);
    resetDisableUpstreamValidation(): void;
    get disableUpstreamValidationInput(): boolean | cdktn.IResolvable | undefined;
    private _aptRepository;
    get aptRepository(): ArtifactRegistryRepositoryRemoteRepositoryConfigAptRepositoryOutputReference;
    putAptRepository(value: ArtifactRegistryRepositoryRemoteRepositoryConfigAptRepository): void;
    resetAptRepository(): void;
    get aptRepositoryInput(): ArtifactRegistryRepositoryRemoteRepositoryConfigAptRepository | undefined;
    private _commonRepository;
    get commonRepository(): ArtifactRegistryRepositoryRemoteRepositoryConfigCommonRepositoryOutputReference;
    putCommonRepository(value: ArtifactRegistryRepositoryRemoteRepositoryConfigCommonRepository): void;
    resetCommonRepository(): void;
    get commonRepositoryInput(): ArtifactRegistryRepositoryRemoteRepositoryConfigCommonRepository | undefined;
    private _dockerRepository;
    get dockerRepository(): ArtifactRegistryRepositoryRemoteRepositoryConfigDockerRepositoryOutputReference;
    putDockerRepository(value: ArtifactRegistryRepositoryRemoteRepositoryConfigDockerRepository): void;
    resetDockerRepository(): void;
    get dockerRepositoryInput(): ArtifactRegistryRepositoryRemoteRepositoryConfigDockerRepository | undefined;
    private _mavenRepository;
    get mavenRepository(): ArtifactRegistryRepositoryRemoteRepositoryConfigMavenRepositoryOutputReference;
    putMavenRepository(value: ArtifactRegistryRepositoryRemoteRepositoryConfigMavenRepository): void;
    resetMavenRepository(): void;
    get mavenRepositoryInput(): ArtifactRegistryRepositoryRemoteRepositoryConfigMavenRepository | undefined;
    private _noCache;
    get noCache(): ArtifactRegistryRepositoryRemoteRepositoryConfigNoCacheOutputReference;
    putNoCache(value: ArtifactRegistryRepositoryRemoteRepositoryConfigNoCache): void;
    resetNoCache(): void;
    get noCacheInput(): ArtifactRegistryRepositoryRemoteRepositoryConfigNoCache | undefined;
    private _npmRepository;
    get npmRepository(): ArtifactRegistryRepositoryRemoteRepositoryConfigNpmRepositoryOutputReference;
    putNpmRepository(value: ArtifactRegistryRepositoryRemoteRepositoryConfigNpmRepository): void;
    resetNpmRepository(): void;
    get npmRepositoryInput(): ArtifactRegistryRepositoryRemoteRepositoryConfigNpmRepository | undefined;
    private _pythonRepository;
    get pythonRepository(): ArtifactRegistryRepositoryRemoteRepositoryConfigPythonRepositoryOutputReference;
    putPythonRepository(value: ArtifactRegistryRepositoryRemoteRepositoryConfigPythonRepository): void;
    resetPythonRepository(): void;
    get pythonRepositoryInput(): ArtifactRegistryRepositoryRemoteRepositoryConfigPythonRepository | undefined;
    private _upstreamCredentials;
    get upstreamCredentials(): ArtifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentialsOutputReference;
    putUpstreamCredentials(value: ArtifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentials): void;
    resetUpstreamCredentials(): void;
    get upstreamCredentialsInput(): ArtifactRegistryRepositoryRemoteRepositoryConfigUpstreamCredentials | undefined;
    private _yumRepository;
    get yumRepository(): ArtifactRegistryRepositoryRemoteRepositoryConfigYumRepositoryOutputReference;
    putYumRepository(value: ArtifactRegistryRepositoryRemoteRepositoryConfigYumRepository): void;
    resetYumRepository(): void;
    get yumRepositoryInput(): ArtifactRegistryRepositoryRemoteRepositoryConfigYumRepository | undefined;
}
export interface ArtifactRegistryRepositoryTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#create ArtifactRegistryRepository#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#delete ArtifactRegistryRepository#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#update ArtifactRegistryRepository#update}
    */
    readonly update?: string;
}
export declare function artifactRegistryRepositoryTimeoutsToTerraform(struct?: ArtifactRegistryRepositoryTimeouts | cdktn.IResolvable): any;
export declare function artifactRegistryRepositoryTimeoutsToHclTerraform(struct?: ArtifactRegistryRepositoryTimeouts | cdktn.IResolvable): any;
export declare class ArtifactRegistryRepositoryTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryRepositoryTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ArtifactRegistryRepositoryTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface ArtifactRegistryRepositoryVirtualRepositoryConfigUpstreamPolicies {
    /**
    * The user-provided ID of the upstream policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#id ArtifactRegistryRepository#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Entries with a greater priority value take precedence in the pull order.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#priority ArtifactRegistryRepository#priority}
    */
    readonly priority?: number;
    /**
    * A reference to the repository resource, for example:
    * "projects/p1/locations/us-central1/repository/repo1".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#repository ArtifactRegistryRepository#repository}
    */
    readonly repository?: string;
}
export declare function artifactRegistryRepositoryVirtualRepositoryConfigUpstreamPoliciesToTerraform(struct?: ArtifactRegistryRepositoryVirtualRepositoryConfigUpstreamPolicies | cdktn.IResolvable): any;
export declare function artifactRegistryRepositoryVirtualRepositoryConfigUpstreamPoliciesToHclTerraform(struct?: ArtifactRegistryRepositoryVirtualRepositoryConfigUpstreamPolicies | cdktn.IResolvable): any;
export declare class ArtifactRegistryRepositoryVirtualRepositoryConfigUpstreamPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArtifactRegistryRepositoryVirtualRepositoryConfigUpstreamPolicies | cdktn.IResolvable | undefined;
    set internalValue(value: ArtifactRegistryRepositoryVirtualRepositoryConfigUpstreamPolicies | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    private _repository?;
    get repository(): string;
    set repository(value: string);
    resetRepository(): void;
    get repositoryInput(): string | undefined;
}
export declare class ArtifactRegistryRepositoryVirtualRepositoryConfigUpstreamPoliciesList extends cdktn.ComplexList {
    internalValue?: ArtifactRegistryRepositoryVirtualRepositoryConfigUpstreamPolicies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArtifactRegistryRepositoryVirtualRepositoryConfigUpstreamPoliciesOutputReference;
}
export interface ArtifactRegistryRepositoryVirtualRepositoryConfig {
    /**
    * upstream_policies block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#upstream_policies ArtifactRegistryRepository#upstream_policies}
    */
    readonly upstreamPolicies?: ArtifactRegistryRepositoryVirtualRepositoryConfigUpstreamPolicies[] | cdktn.IResolvable;
}
export declare function artifactRegistryRepositoryVirtualRepositoryConfigToTerraform(struct?: ArtifactRegistryRepositoryVirtualRepositoryConfigOutputReference | ArtifactRegistryRepositoryVirtualRepositoryConfig): any;
export declare function artifactRegistryRepositoryVirtualRepositoryConfigToHclTerraform(struct?: ArtifactRegistryRepositoryVirtualRepositoryConfigOutputReference | ArtifactRegistryRepositoryVirtualRepositoryConfig): any;
export declare class ArtifactRegistryRepositoryVirtualRepositoryConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryRepositoryVirtualRepositoryConfig | undefined;
    set internalValue(value: ArtifactRegistryRepositoryVirtualRepositoryConfig | undefined);
    private _upstreamPolicies;
    get upstreamPolicies(): ArtifactRegistryRepositoryVirtualRepositoryConfigUpstreamPoliciesList;
    putUpstreamPolicies(value: ArtifactRegistryRepositoryVirtualRepositoryConfigUpstreamPolicies[] | cdktn.IResolvable): void;
    resetUpstreamPolicies(): void;
    get upstreamPoliciesInput(): cdktn.IResolvable | ArtifactRegistryRepositoryVirtualRepositoryConfigUpstreamPolicies[] | undefined;
}
export interface ArtifactRegistryRepositoryVulnerabilityScanningConfig {
    /**
    * This configures whether vulnerability scanning is automatically performed for artifacts pushed to this repository. Possible values: ["INHERITED", "DISABLED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#enablement_config ArtifactRegistryRepository#enablement_config}
    */
    readonly enablementConfig?: string;
}
export declare function artifactRegistryRepositoryVulnerabilityScanningConfigToTerraform(struct?: ArtifactRegistryRepositoryVulnerabilityScanningConfigOutputReference | ArtifactRegistryRepositoryVulnerabilityScanningConfig): any;
export declare function artifactRegistryRepositoryVulnerabilityScanningConfigToHclTerraform(struct?: ArtifactRegistryRepositoryVulnerabilityScanningConfigOutputReference | ArtifactRegistryRepositoryVulnerabilityScanningConfig): any;
export declare class ArtifactRegistryRepositoryVulnerabilityScanningConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactRegistryRepositoryVulnerabilityScanningConfig | undefined;
    set internalValue(value: ArtifactRegistryRepositoryVulnerabilityScanningConfig | undefined);
    private _enablementConfig?;
    get enablementConfig(): string;
    set enablementConfig(value: string);
    resetEnablementConfig(): void;
    get enablementConfigInput(): string | undefined;
    get enablementState(): string;
    get enablementStateReason(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository google_artifact_registry_repository}
*/
export declare class ArtifactRegistryRepository extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_artifact_registry_repository";
    /**
    * Generates CDKTN code for importing a ArtifactRegistryRepository resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ArtifactRegistryRepository to import
    * @param importFromId The id of the existing ArtifactRegistryRepository that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ArtifactRegistryRepository to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/artifact_registry_repository google_artifact_registry_repository} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ArtifactRegistryRepositoryConfig
    */
    constructor(scope: Construct, id: string, config: ArtifactRegistryRepositoryConfig);
    private _cleanupPolicyDryRun?;
    get cleanupPolicyDryRun(): boolean | cdktn.IResolvable;
    set cleanupPolicyDryRun(value: boolean | cdktn.IResolvable);
    resetCleanupPolicyDryRun(): void;
    get cleanupPolicyDryRunInput(): boolean | cdktn.IResolvable | undefined;
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disallowUnspecifiedMode?;
    get disallowUnspecifiedMode(): boolean | cdktn.IResolvable;
    set disallowUnspecifiedMode(value: boolean | cdktn.IResolvable);
    resetDisallowUnspecifiedMode(): void;
    get disallowUnspecifiedModeInput(): boolean | cdktn.IResolvable | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _format?;
    get format(): string;
    set format(value: string);
    get formatInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsKeyName?;
    get kmsKeyName(): string;
    set kmsKeyName(value: string);
    resetKmsKeyName(): void;
    get kmsKeyNameInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get registryUri(): string;
    private _repositoryId?;
    get repositoryId(): string;
    set repositoryId(value: string);
    get repositoryIdInput(): string | undefined;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get updateTime(): string;
    private _cleanupPolicies;
    get cleanupPolicies(): ArtifactRegistryRepositoryCleanupPoliciesList;
    putCleanupPolicies(value: ArtifactRegistryRepositoryCleanupPolicies[] | cdktn.IResolvable): void;
    resetCleanupPolicies(): void;
    get cleanupPoliciesInput(): cdktn.IResolvable | ArtifactRegistryRepositoryCleanupPolicies[] | undefined;
    private _dockerConfig;
    get dockerConfig(): ArtifactRegistryRepositoryDockerConfigOutputReference;
    putDockerConfig(value: ArtifactRegistryRepositoryDockerConfig): void;
    resetDockerConfig(): void;
    get dockerConfigInput(): ArtifactRegistryRepositoryDockerConfig | undefined;
    private _mavenConfig;
    get mavenConfig(): ArtifactRegistryRepositoryMavenConfigOutputReference;
    putMavenConfig(value: ArtifactRegistryRepositoryMavenConfig): void;
    resetMavenConfig(): void;
    get mavenConfigInput(): ArtifactRegistryRepositoryMavenConfig | undefined;
    private _platformLogsConfig;
    get platformLogsConfig(): ArtifactRegistryRepositoryPlatformLogsConfigOutputReference;
    putPlatformLogsConfig(value: ArtifactRegistryRepositoryPlatformLogsConfig): void;
    resetPlatformLogsConfig(): void;
    get platformLogsConfigInput(): ArtifactRegistryRepositoryPlatformLogsConfig | undefined;
    private _remoteRepositoryConfig;
    get remoteRepositoryConfig(): ArtifactRegistryRepositoryRemoteRepositoryConfigOutputReference;
    putRemoteRepositoryConfig(value: ArtifactRegistryRepositoryRemoteRepositoryConfig): void;
    resetRemoteRepositoryConfig(): void;
    get remoteRepositoryConfigInput(): ArtifactRegistryRepositoryRemoteRepositoryConfig | undefined;
    private _timeouts;
    get timeouts(): ArtifactRegistryRepositoryTimeoutsOutputReference;
    putTimeouts(value: ArtifactRegistryRepositoryTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ArtifactRegistryRepositoryTimeouts | undefined;
    private _virtualRepositoryConfig;
    get virtualRepositoryConfig(): ArtifactRegistryRepositoryVirtualRepositoryConfigOutputReference;
    putVirtualRepositoryConfig(value: ArtifactRegistryRepositoryVirtualRepositoryConfig): void;
    resetVirtualRepositoryConfig(): void;
    get virtualRepositoryConfigInput(): ArtifactRegistryRepositoryVirtualRepositoryConfig | undefined;
    private _vulnerabilityScanningConfig;
    get vulnerabilityScanningConfig(): ArtifactRegistryRepositoryVulnerabilityScanningConfigOutputReference;
    putVulnerabilityScanningConfig(value: ArtifactRegistryRepositoryVulnerabilityScanningConfig): void;
    resetVulnerabilityScanningConfig(): void;
    get vulnerabilityScanningConfigInput(): ArtifactRegistryRepositoryVulnerabilityScanningConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
