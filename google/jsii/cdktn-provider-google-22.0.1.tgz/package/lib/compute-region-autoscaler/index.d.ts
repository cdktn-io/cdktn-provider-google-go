/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeRegionAutoscalerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#deletion_policy ComputeRegionAutoscaler#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#description ComputeRegionAutoscaler#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#id ComputeRegionAutoscaler#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the resource. The name must be 1-63 characters long and match
    * the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the
    * first character must be a lowercase letter, and all following
    * characters must be a dash, lowercase letter, or digit, except the last
    * character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#name ComputeRegionAutoscaler#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#project ComputeRegionAutoscaler#project}
    */
    readonly project?: string;
    /**
    * URL of the region where the instance group resides.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#region ComputeRegionAutoscaler#region}
    */
    readonly region?: string;
    /**
    * URL of the managed instance group that this autoscaler will scale.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#target ComputeRegionAutoscaler#target}
    */
    readonly target: string;
    /**
    * autoscaling_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#autoscaling_policy ComputeRegionAutoscaler#autoscaling_policy}
    */
    readonly autoscalingPolicy: ComputeRegionAutoscalerAutoscalingPolicy;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#timeouts ComputeRegionAutoscaler#timeouts}
    */
    readonly timeouts?: ComputeRegionAutoscalerTimeouts;
}
export interface ComputeRegionAutoscalerAutoscalingPolicyCpuUtilization {
    /**
    * Indicates whether predictive autoscaling based on CPU metric is enabled. Valid values are:
    *
    * - NONE (default). No predictive method is used. The autoscaler scales the group to meet current demand based on real-time metrics.
    *
    * - OPTIMIZE_AVAILABILITY. Predictive autoscaling improves availability by monitoring daily and weekly load patterns and scaling out ahead of anticipated demand.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#predictive_method ComputeRegionAutoscaler#predictive_method}
    */
    readonly predictiveMethod?: string;
    /**
    * The target CPU utilization that the autoscaler should maintain.
    * Must be a float value in the range (0, 1]. If not specified, the
    * default is 0.6.
    *
    * If the CPU level is below the target utilization, the autoscaler
    * scales down the number of instances until it reaches the minimum
    * number of instances you specified or until the average CPU of
    * your instances reaches the target utilization.
    *
    * If the average CPU is above the target utilization, the autoscaler
    * scales up until it reaches the maximum number of instances you
    * specified or until the average utilization reaches the target
    * utilization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#target ComputeRegionAutoscaler#target}
    */
    readonly target: number;
}
export declare function computeRegionAutoscalerAutoscalingPolicyCpuUtilizationToTerraform(struct?: ComputeRegionAutoscalerAutoscalingPolicyCpuUtilizationOutputReference | ComputeRegionAutoscalerAutoscalingPolicyCpuUtilization): any;
export declare function computeRegionAutoscalerAutoscalingPolicyCpuUtilizationToHclTerraform(struct?: ComputeRegionAutoscalerAutoscalingPolicyCpuUtilizationOutputReference | ComputeRegionAutoscalerAutoscalingPolicyCpuUtilization): any;
export declare class ComputeRegionAutoscalerAutoscalingPolicyCpuUtilizationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionAutoscalerAutoscalingPolicyCpuUtilization | undefined;
    set internalValue(value: ComputeRegionAutoscalerAutoscalingPolicyCpuUtilization | undefined);
    private _predictiveMethod?;
    get predictiveMethod(): string;
    set predictiveMethod(value: string);
    resetPredictiveMethod(): void;
    get predictiveMethodInput(): string | undefined;
    private _target?;
    get target(): number;
    set target(value: number);
    get targetInput(): number | undefined;
}
export interface ComputeRegionAutoscalerAutoscalingPolicyLoadBalancingUtilization {
    /**
    * Fraction of backend capacity utilization (set in HTTP(s) load
    * balancing configuration) that autoscaler should maintain. Must
    * be a positive float value. If not defined, the default is 0.8.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#target ComputeRegionAutoscaler#target}
    */
    readonly target: number;
}
export declare function computeRegionAutoscalerAutoscalingPolicyLoadBalancingUtilizationToTerraform(struct?: ComputeRegionAutoscalerAutoscalingPolicyLoadBalancingUtilizationOutputReference | ComputeRegionAutoscalerAutoscalingPolicyLoadBalancingUtilization): any;
export declare function computeRegionAutoscalerAutoscalingPolicyLoadBalancingUtilizationToHclTerraform(struct?: ComputeRegionAutoscalerAutoscalingPolicyLoadBalancingUtilizationOutputReference | ComputeRegionAutoscalerAutoscalingPolicyLoadBalancingUtilization): any;
export declare class ComputeRegionAutoscalerAutoscalingPolicyLoadBalancingUtilizationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionAutoscalerAutoscalingPolicyLoadBalancingUtilization | undefined;
    set internalValue(value: ComputeRegionAutoscalerAutoscalingPolicyLoadBalancingUtilization | undefined);
    private _target?;
    get target(): number;
    set target(value: number);
    get targetInput(): number | undefined;
}
export interface ComputeRegionAutoscalerAutoscalingPolicyMetric {
    /**
    * A filter string to be used as the filter string for
    * a Stackdriver Monitoring TimeSeries.list API call.
    * This filter is used to select a specific TimeSeries for
    * the purpose of autoscaling and to determine whether the metric
    * is exporting per-instance or per-group data.
    *
    * You can only use the AND operator for joining selectors.
    * You can only use direct equality comparison operator (=) without
    * any functions for each selector.
    * You can specify the metric in both the filter string and in the
    * metric field. However, if specified in both places, the metric must
    * be identical.
    *
    * The monitored resource type determines what kind of values are
    * expected for the metric. If it is a gce_instance, the autoscaler
    * expects the metric to include a separate TimeSeries for each
    * instance in a group. In such a case, you cannot filter on resource
    * labels.
    *
    * If the resource type is any other value, the autoscaler expects
    * this metric to contain values that apply to the entire autoscaled
    * instance group and resource label filtering can be performed to
    * point autoscaler at the correct TimeSeries to scale upon.
    * This is called a per-group metric for the purpose of autoscaling.
    *
    * If not specified, the type defaults to gce_instance.
    *
    * You should provide a filter that is selective enough to pick just
    * one TimeSeries for the autoscaled group or for each of the instances
    * (if you are using gce_instance resource type). If multiple
    * TimeSeries are returned upon the query execution, the autoscaler
    * will sum their respective values to obtain its scaling value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#filter ComputeRegionAutoscaler#filter}
    */
    readonly filter?: string;
    /**
    * The identifier (type) of the Stackdriver Monitoring metric.
    * The metric cannot have negative values.
    *
    * The metric must have a value type of INT64 or DOUBLE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#name ComputeRegionAutoscaler#name}
    */
    readonly name: string;
    /**
    * If scaling is based on a per-group metric value that represents the
    * total amount of work to be done or resource usage, set this value to
    * an amount assigned for a single instance of the scaled group.
    * The autoscaler will keep the number of instances proportional to the
    * value of this metric, the metric itself should not change value due
    * to group resizing.
    *
    * For example, a good metric to use with the target is
    * 'pubsub.googleapis.com/subscription/num_undelivered_messages'
    * or a custom metric exporting the total number of requests coming to
    * your instances.
    *
    * A bad example would be a metric exporting an average or median
    * latency, since this value can't include a chunk assignable to a
    * single instance, it could be better used with utilization_target
    * instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#single_instance_assignment ComputeRegionAutoscaler#single_instance_assignment}
    */
    readonly singleInstanceAssignment?: number;
    /**
    * The target value of the metric that autoscaler should
    * maintain. This must be a positive value. A utilization
    * metric scales number of virtual machines handling requests
    * to increase or decrease proportionally to the metric.
    *
    * For example, a good metric to use as a utilizationTarget is
    * www.googleapis.com/compute/instance/network/received_bytes_count.
    * The autoscaler will work to keep this value constant for each
    * of the instances.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#target ComputeRegionAutoscaler#target}
    */
    readonly target?: number;
    /**
    * Defines how target utilization value is expressed for a
    * Stackdriver Monitoring metric. Possible values: ["GAUGE", "DELTA_PER_SECOND", "DELTA_PER_MINUTE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#type ComputeRegionAutoscaler#type}
    */
    readonly type?: string;
}
export declare function computeRegionAutoscalerAutoscalingPolicyMetricToTerraform(struct?: ComputeRegionAutoscalerAutoscalingPolicyMetric | cdktn.IResolvable): any;
export declare function computeRegionAutoscalerAutoscalingPolicyMetricToHclTerraform(struct?: ComputeRegionAutoscalerAutoscalingPolicyMetric | cdktn.IResolvable): any;
export declare class ComputeRegionAutoscalerAutoscalingPolicyMetricOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionAutoscalerAutoscalingPolicyMetric | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionAutoscalerAutoscalingPolicyMetric | cdktn.IResolvable | undefined);
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _singleInstanceAssignment?;
    get singleInstanceAssignment(): number;
    set singleInstanceAssignment(value: number);
    resetSingleInstanceAssignment(): void;
    get singleInstanceAssignmentInput(): number | undefined;
    private _target?;
    get target(): number;
    set target(value: number);
    resetTarget(): void;
    get targetInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class ComputeRegionAutoscalerAutoscalingPolicyMetricList extends cdktn.ComplexList {
    internalValue?: ComputeRegionAutoscalerAutoscalingPolicyMetric[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionAutoscalerAutoscalingPolicyMetricOutputReference;
}
export interface ComputeRegionAutoscalerAutoscalingPolicyScaleInControlMaxScaledInReplicas {
    /**
    * Specifies a fixed number of VM instances. This must be a positive
    * integer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#fixed ComputeRegionAutoscaler#fixed}
    */
    readonly fixed?: number;
    /**
    * Specifies a percentage of instances between 0 to 100%, inclusive.
    * For example, specify 80 for 80%.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#percent ComputeRegionAutoscaler#percent}
    */
    readonly percent?: number;
}
export declare function computeRegionAutoscalerAutoscalingPolicyScaleInControlMaxScaledInReplicasToTerraform(struct?: ComputeRegionAutoscalerAutoscalingPolicyScaleInControlMaxScaledInReplicasOutputReference | ComputeRegionAutoscalerAutoscalingPolicyScaleInControlMaxScaledInReplicas): any;
export declare function computeRegionAutoscalerAutoscalingPolicyScaleInControlMaxScaledInReplicasToHclTerraform(struct?: ComputeRegionAutoscalerAutoscalingPolicyScaleInControlMaxScaledInReplicasOutputReference | ComputeRegionAutoscalerAutoscalingPolicyScaleInControlMaxScaledInReplicas): any;
export declare class ComputeRegionAutoscalerAutoscalingPolicyScaleInControlMaxScaledInReplicasOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionAutoscalerAutoscalingPolicyScaleInControlMaxScaledInReplicas | undefined;
    set internalValue(value: ComputeRegionAutoscalerAutoscalingPolicyScaleInControlMaxScaledInReplicas | undefined);
    private _fixed?;
    get fixed(): number;
    set fixed(value: number);
    resetFixed(): void;
    get fixedInput(): number | undefined;
    private _percent?;
    get percent(): number;
    set percent(value: number);
    resetPercent(): void;
    get percentInput(): number | undefined;
}
export interface ComputeRegionAutoscalerAutoscalingPolicyScaleInControl {
    /**
    * How long back autoscaling should look when computing recommendations
    * to include directives regarding slower scale down, as described above.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#time_window_sec ComputeRegionAutoscaler#time_window_sec}
    */
    readonly timeWindowSec?: number;
    /**
    * max_scaled_in_replicas block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#max_scaled_in_replicas ComputeRegionAutoscaler#max_scaled_in_replicas}
    */
    readonly maxScaledInReplicas?: ComputeRegionAutoscalerAutoscalingPolicyScaleInControlMaxScaledInReplicas;
}
export declare function computeRegionAutoscalerAutoscalingPolicyScaleInControlToTerraform(struct?: ComputeRegionAutoscalerAutoscalingPolicyScaleInControlOutputReference | ComputeRegionAutoscalerAutoscalingPolicyScaleInControl): any;
export declare function computeRegionAutoscalerAutoscalingPolicyScaleInControlToHclTerraform(struct?: ComputeRegionAutoscalerAutoscalingPolicyScaleInControlOutputReference | ComputeRegionAutoscalerAutoscalingPolicyScaleInControl): any;
export declare class ComputeRegionAutoscalerAutoscalingPolicyScaleInControlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionAutoscalerAutoscalingPolicyScaleInControl | undefined;
    set internalValue(value: ComputeRegionAutoscalerAutoscalingPolicyScaleInControl | undefined);
    private _timeWindowSec?;
    get timeWindowSec(): number;
    set timeWindowSec(value: number);
    resetTimeWindowSec(): void;
    get timeWindowSecInput(): number | undefined;
    private _maxScaledInReplicas;
    get maxScaledInReplicas(): ComputeRegionAutoscalerAutoscalingPolicyScaleInControlMaxScaledInReplicasOutputReference;
    putMaxScaledInReplicas(value: ComputeRegionAutoscalerAutoscalingPolicyScaleInControlMaxScaledInReplicas): void;
    resetMaxScaledInReplicas(): void;
    get maxScaledInReplicasInput(): ComputeRegionAutoscalerAutoscalingPolicyScaleInControlMaxScaledInReplicas | undefined;
}
export interface ComputeRegionAutoscalerAutoscalingPolicyScalingSchedules {
    /**
    * A description of a scaling schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#description ComputeRegionAutoscaler#description}
    */
    readonly description?: string;
    /**
    * A boolean value that specifies if a scaling schedule can influence autoscaler recommendations. If set to true, then a scaling schedule has no effect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#disabled ComputeRegionAutoscaler#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * The duration of time intervals (in seconds) for which this scaling schedule will be running. The minimum allowed value is 300.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#duration_sec ComputeRegionAutoscaler#duration_sec}
    */
    readonly durationSec: number;
    /**
    * Minimum number of VM instances that autoscaler will recommend in time intervals starting according to schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#min_required_replicas ComputeRegionAutoscaler#min_required_replicas}
    */
    readonly minRequiredReplicas: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#name ComputeRegionAutoscaler#name}
    */
    readonly name: string;
    /**
    * The start timestamps of time intervals when this scaling schedule should provide a scaling signal. This field uses the extended cron format (with an optional year field).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#schedule ComputeRegionAutoscaler#schedule}
    */
    readonly schedule: string;
    /**
    * The time zone to be used when interpreting the schedule. The value of this field must be a time zone name from the tz database: http://en.wikipedia.org/wiki/Tz_database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#time_zone ComputeRegionAutoscaler#time_zone}
    */
    readonly timeZone?: string;
}
export declare function computeRegionAutoscalerAutoscalingPolicyScalingSchedulesToTerraform(struct?: ComputeRegionAutoscalerAutoscalingPolicyScalingSchedules | cdktn.IResolvable): any;
export declare function computeRegionAutoscalerAutoscalingPolicyScalingSchedulesToHclTerraform(struct?: ComputeRegionAutoscalerAutoscalingPolicyScalingSchedules | cdktn.IResolvable): any;
export declare class ComputeRegionAutoscalerAutoscalingPolicyScalingSchedulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionAutoscalerAutoscalingPolicyScalingSchedules | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionAutoscalerAutoscalingPolicyScalingSchedules | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _durationSec?;
    get durationSec(): number;
    set durationSec(value: number);
    get durationSecInput(): number | undefined;
    private _minRequiredReplicas?;
    get minRequiredReplicas(): number;
    set minRequiredReplicas(value: number);
    get minRequiredReplicasInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _schedule?;
    get schedule(): string;
    set schedule(value: string);
    get scheduleInput(): string | undefined;
    private _timeZone?;
    get timeZone(): string;
    set timeZone(value: string);
    resetTimeZone(): void;
    get timeZoneInput(): string | undefined;
}
export declare class ComputeRegionAutoscalerAutoscalingPolicyScalingSchedulesList extends cdktn.ComplexList {
    internalValue?: ComputeRegionAutoscalerAutoscalingPolicyScalingSchedules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionAutoscalerAutoscalingPolicyScalingSchedulesOutputReference;
}
export interface ComputeRegionAutoscalerAutoscalingPolicy {
    /**
    * The number of seconds that the autoscaler should wait before it
    * starts collecting information from a new instance. This prevents
    * the autoscaler from collecting information when the instance is
    * initializing, during which the collected usage would not be
    * reliable. The default time autoscaler waits is 60 seconds.
    *
    * Virtual machine initialization times might vary because of
    * numerous factors. We recommend that you test how long an
    * instance may take to initialize. To do this, create an instance
    * and time the startup process.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#cooldown_period ComputeRegionAutoscaler#cooldown_period}
    */
    readonly cooldownPeriod?: number;
    /**
    * The maximum number of instances that the autoscaler can scale up
    * to. This is required when creating or updating an autoscaler. The
    * maximum number of replicas should not be lower than minimal number
    * of replicas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#max_replicas ComputeRegionAutoscaler#max_replicas}
    */
    readonly maxReplicas: number;
    /**
    * The minimum number of replicas that the autoscaler can scale down
    * to. This cannot be less than 0. If not provided, autoscaler will
    * choose a default value depending on maximum number of instances
    * allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#min_replicas ComputeRegionAutoscaler#min_replicas}
    */
    readonly minReplicas: number;
    /**
    * Defines operating mode for this policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#mode ComputeRegionAutoscaler#mode}
    */
    readonly mode?: string;
    /**
    * The number of seconds that the autoscaler waits for load stabilization
    * before making scale-in decisions.
    *
    * This might appear as a delay in scaling in but it is an important mechanism
    * for your application to not have fluctuating size due to short term load
    * fluctuations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#stabilization_period ComputeRegionAutoscaler#stabilization_period}
    */
    readonly stabilizationPeriod?: number;
    /**
    * cpu_utilization block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#cpu_utilization ComputeRegionAutoscaler#cpu_utilization}
    */
    readonly cpuUtilization?: ComputeRegionAutoscalerAutoscalingPolicyCpuUtilization;
    /**
    * load_balancing_utilization block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#load_balancing_utilization ComputeRegionAutoscaler#load_balancing_utilization}
    */
    readonly loadBalancingUtilization?: ComputeRegionAutoscalerAutoscalingPolicyLoadBalancingUtilization;
    /**
    * metric block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#metric ComputeRegionAutoscaler#metric}
    */
    readonly metric?: ComputeRegionAutoscalerAutoscalingPolicyMetric[] | cdktn.IResolvable;
    /**
    * scale_in_control block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#scale_in_control ComputeRegionAutoscaler#scale_in_control}
    */
    readonly scaleInControl?: ComputeRegionAutoscalerAutoscalingPolicyScaleInControl;
    /**
    * scaling_schedules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#scaling_schedules ComputeRegionAutoscaler#scaling_schedules}
    */
    readonly scalingSchedules?: ComputeRegionAutoscalerAutoscalingPolicyScalingSchedules[] | cdktn.IResolvable;
}
export declare function computeRegionAutoscalerAutoscalingPolicyToTerraform(struct?: ComputeRegionAutoscalerAutoscalingPolicyOutputReference | ComputeRegionAutoscalerAutoscalingPolicy): any;
export declare function computeRegionAutoscalerAutoscalingPolicyToHclTerraform(struct?: ComputeRegionAutoscalerAutoscalingPolicyOutputReference | ComputeRegionAutoscalerAutoscalingPolicy): any;
export declare class ComputeRegionAutoscalerAutoscalingPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionAutoscalerAutoscalingPolicy | undefined;
    set internalValue(value: ComputeRegionAutoscalerAutoscalingPolicy | undefined);
    private _cooldownPeriod?;
    get cooldownPeriod(): number;
    set cooldownPeriod(value: number);
    resetCooldownPeriod(): void;
    get cooldownPeriodInput(): number | undefined;
    private _maxReplicas?;
    get maxReplicas(): number;
    set maxReplicas(value: number);
    get maxReplicasInput(): number | undefined;
    private _minReplicas?;
    get minReplicas(): number;
    set minReplicas(value: number);
    get minReplicasInput(): number | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _stabilizationPeriod?;
    get stabilizationPeriod(): number;
    set stabilizationPeriod(value: number);
    resetStabilizationPeriod(): void;
    get stabilizationPeriodInput(): number | undefined;
    private _cpuUtilization;
    get cpuUtilization(): ComputeRegionAutoscalerAutoscalingPolicyCpuUtilizationOutputReference;
    putCpuUtilization(value: ComputeRegionAutoscalerAutoscalingPolicyCpuUtilization): void;
    resetCpuUtilization(): void;
    get cpuUtilizationInput(): ComputeRegionAutoscalerAutoscalingPolicyCpuUtilization | undefined;
    private _loadBalancingUtilization;
    get loadBalancingUtilization(): ComputeRegionAutoscalerAutoscalingPolicyLoadBalancingUtilizationOutputReference;
    putLoadBalancingUtilization(value: ComputeRegionAutoscalerAutoscalingPolicyLoadBalancingUtilization): void;
    resetLoadBalancingUtilization(): void;
    get loadBalancingUtilizationInput(): ComputeRegionAutoscalerAutoscalingPolicyLoadBalancingUtilization | undefined;
    private _metric;
    get metric(): ComputeRegionAutoscalerAutoscalingPolicyMetricList;
    putMetric(value: ComputeRegionAutoscalerAutoscalingPolicyMetric[] | cdktn.IResolvable): void;
    resetMetric(): void;
    get metricInput(): cdktn.IResolvable | ComputeRegionAutoscalerAutoscalingPolicyMetric[] | undefined;
    private _scaleInControl;
    get scaleInControl(): ComputeRegionAutoscalerAutoscalingPolicyScaleInControlOutputReference;
    putScaleInControl(value: ComputeRegionAutoscalerAutoscalingPolicyScaleInControl): void;
    resetScaleInControl(): void;
    get scaleInControlInput(): ComputeRegionAutoscalerAutoscalingPolicyScaleInControl | undefined;
    private _scalingSchedules;
    get scalingSchedules(): ComputeRegionAutoscalerAutoscalingPolicyScalingSchedulesList;
    putScalingSchedules(value: ComputeRegionAutoscalerAutoscalingPolicyScalingSchedules[] | cdktn.IResolvable): void;
    resetScalingSchedules(): void;
    get scalingSchedulesInput(): cdktn.IResolvable | ComputeRegionAutoscalerAutoscalingPolicyScalingSchedules[] | undefined;
}
export interface ComputeRegionAutoscalerTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#create ComputeRegionAutoscaler#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#delete ComputeRegionAutoscaler#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#update ComputeRegionAutoscaler#update}
    */
    readonly update?: string;
}
export declare function computeRegionAutoscalerTimeoutsToTerraform(struct?: ComputeRegionAutoscalerTimeouts | cdktn.IResolvable): any;
export declare function computeRegionAutoscalerTimeoutsToHclTerraform(struct?: ComputeRegionAutoscalerTimeouts | cdktn.IResolvable): any;
export declare class ComputeRegionAutoscalerTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionAutoscalerTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionAutoscalerTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler google_compute_region_autoscaler}
*/
export declare class ComputeRegionAutoscaler extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_region_autoscaler";
    /**
    * Generates CDKTN code for importing a ComputeRegionAutoscaler resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeRegionAutoscaler to import
    * @param importFromId The id of the existing ComputeRegionAutoscaler that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeRegionAutoscaler to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_autoscaler google_compute_region_autoscaler} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeRegionAutoscalerConfig
    */
    constructor(scope: Construct, id: string, config: ComputeRegionAutoscalerConfig);
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get selfLink(): string;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _autoscalingPolicy;
    get autoscalingPolicy(): ComputeRegionAutoscalerAutoscalingPolicyOutputReference;
    putAutoscalingPolicy(value: ComputeRegionAutoscalerAutoscalingPolicy): void;
    get autoscalingPolicyInput(): ComputeRegionAutoscalerAutoscalingPolicy | undefined;
    private _timeouts;
    get timeouts(): ComputeRegionAutoscalerTimeoutsOutputReference;
    putTimeouts(value: ComputeRegionAutoscalerTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeRegionAutoscalerTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
