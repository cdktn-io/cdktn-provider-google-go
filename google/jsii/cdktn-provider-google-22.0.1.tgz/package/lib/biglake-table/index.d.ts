/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BiglakeTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * The id of the parent database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/biglake_table#database BiglakeTable#database}
    */
    readonly database?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/biglake_table#deletion_policy BiglakeTable#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/biglake_table#id BiglakeTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Output only. The name of the Table. Format:
    * projects/{project_id_or_number}/locations/{locationId}/catalogs/{catalogId}/databases/{databaseId}/tables/{tableId}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/biglake_table#name BiglakeTable#name}
    */
    readonly name: string;
    /**
    * The database type. Possible values: ["HIVE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/biglake_table#type BiglakeTable#type}
    */
    readonly type?: string;
    /**
    * hive_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/biglake_table#hive_options BiglakeTable#hive_options}
    */
    readonly hiveOptions?: BiglakeTableHiveOptions;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/biglake_table#timeouts BiglakeTable#timeouts}
    */
    readonly timeouts?: BiglakeTableTimeouts;
}
export interface BiglakeTableHiveOptionsStorageDescriptorSerdeInfo {
    /**
    * The fully qualified Java class name of the serialization library.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/biglake_table#serialization_lib BiglakeTable#serialization_lib}
    */
    readonly serializationLib?: string;
}
export declare function biglakeTableHiveOptionsStorageDescriptorSerdeInfoToTerraform(struct?: BiglakeTableHiveOptionsStorageDescriptorSerdeInfoOutputReference | BiglakeTableHiveOptionsStorageDescriptorSerdeInfo): any;
export declare function biglakeTableHiveOptionsStorageDescriptorSerdeInfoToHclTerraform(struct?: BiglakeTableHiveOptionsStorageDescriptorSerdeInfoOutputReference | BiglakeTableHiveOptionsStorageDescriptorSerdeInfo): any;
export declare class BiglakeTableHiveOptionsStorageDescriptorSerdeInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BiglakeTableHiveOptionsStorageDescriptorSerdeInfo | undefined;
    set internalValue(value: BiglakeTableHiveOptionsStorageDescriptorSerdeInfo | undefined);
    private _serializationLib?;
    get serializationLib(): string;
    set serializationLib(value: string);
    resetSerializationLib(): void;
    get serializationLibInput(): string | undefined;
}
export interface BiglakeTableHiveOptionsStorageDescriptor {
    /**
    * The fully qualified Java class name of the input format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/biglake_table#input_format BiglakeTable#input_format}
    */
    readonly inputFormat?: string;
    /**
    * Cloud Storage folder URI where the table data is stored, starting with "gs://".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/biglake_table#location_uri BiglakeTable#location_uri}
    */
    readonly locationUri?: string;
    /**
    * The fully qualified Java class name of the output format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/biglake_table#output_format BiglakeTable#output_format}
    */
    readonly outputFormat?: string;
    /**
    * serde_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/biglake_table#serde_info BiglakeTable#serde_info}
    */
    readonly serdeInfo?: BiglakeTableHiveOptionsStorageDescriptorSerdeInfo;
}
export declare function biglakeTableHiveOptionsStorageDescriptorToTerraform(struct?: BiglakeTableHiveOptionsStorageDescriptorOutputReference | BiglakeTableHiveOptionsStorageDescriptor): any;
export declare function biglakeTableHiveOptionsStorageDescriptorToHclTerraform(struct?: BiglakeTableHiveOptionsStorageDescriptorOutputReference | BiglakeTableHiveOptionsStorageDescriptor): any;
export declare class BiglakeTableHiveOptionsStorageDescriptorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BiglakeTableHiveOptionsStorageDescriptor | undefined;
    set internalValue(value: BiglakeTableHiveOptionsStorageDescriptor | undefined);
    private _inputFormat?;
    get inputFormat(): string;
    set inputFormat(value: string);
    resetInputFormat(): void;
    get inputFormatInput(): string | undefined;
    private _locationUri?;
    get locationUri(): string;
    set locationUri(value: string);
    resetLocationUri(): void;
    get locationUriInput(): string | undefined;
    private _outputFormat?;
    get outputFormat(): string;
    set outputFormat(value: string);
    resetOutputFormat(): void;
    get outputFormatInput(): string | undefined;
    private _serdeInfo;
    get serdeInfo(): BiglakeTableHiveOptionsStorageDescriptorSerdeInfoOutputReference;
    putSerdeInfo(value: BiglakeTableHiveOptionsStorageDescriptorSerdeInfo): void;
    resetSerdeInfo(): void;
    get serdeInfoInput(): BiglakeTableHiveOptionsStorageDescriptorSerdeInfo | undefined;
}
export interface BiglakeTableHiveOptions {
    /**
    * Stores user supplied Hive table parameters. An object containing a
    * list of "key": value pairs.
    * Example: { "name": "wrench", "mass": "1.3kg", "count": "3" }.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/biglake_table#parameters BiglakeTable#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Hive table type. For example, MANAGED_TABLE, EXTERNAL_TABLE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/biglake_table#table_type BiglakeTable#table_type}
    */
    readonly tableType?: string;
    /**
    * storage_descriptor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/biglake_table#storage_descriptor BiglakeTable#storage_descriptor}
    */
    readonly storageDescriptor?: BiglakeTableHiveOptionsStorageDescriptor;
}
export declare function biglakeTableHiveOptionsToTerraform(struct?: BiglakeTableHiveOptionsOutputReference | BiglakeTableHiveOptions): any;
export declare function biglakeTableHiveOptionsToHclTerraform(struct?: BiglakeTableHiveOptionsOutputReference | BiglakeTableHiveOptions): any;
export declare class BiglakeTableHiveOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BiglakeTableHiveOptions | undefined;
    set internalValue(value: BiglakeTableHiveOptions | undefined);
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _tableType?;
    get tableType(): string;
    set tableType(value: string);
    resetTableType(): void;
    get tableTypeInput(): string | undefined;
    private _storageDescriptor;
    get storageDescriptor(): BiglakeTableHiveOptionsStorageDescriptorOutputReference;
    putStorageDescriptor(value: BiglakeTableHiveOptionsStorageDescriptor): void;
    resetStorageDescriptor(): void;
    get storageDescriptorInput(): BiglakeTableHiveOptionsStorageDescriptor | undefined;
}
export interface BiglakeTableTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/biglake_table#create BiglakeTable#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/biglake_table#delete BiglakeTable#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/biglake_table#update BiglakeTable#update}
    */
    readonly update?: string;
}
export declare function biglakeTableTimeoutsToTerraform(struct?: BiglakeTableTimeouts | cdktn.IResolvable): any;
export declare function biglakeTableTimeoutsToHclTerraform(struct?: BiglakeTableTimeouts | cdktn.IResolvable): any;
export declare class BiglakeTableTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BiglakeTableTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BiglakeTableTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/biglake_table google_biglake_table}
*/
export declare class BiglakeTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_biglake_table";
    /**
    * Generates CDKTN code for importing a BiglakeTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BiglakeTable to import
    * @param importFromId The id of the existing BiglakeTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/biglake_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BiglakeTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/biglake_table google_biglake_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BiglakeTableConfig
    */
    constructor(scope: Construct, id: string, config: BiglakeTableConfig);
    get createTime(): string;
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    get deleteTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    get etag(): string;
    get expireTime(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    get updateTime(): string;
    private _hiveOptions;
    get hiveOptions(): BiglakeTableHiveOptionsOutputReference;
    putHiveOptions(value: BiglakeTableHiveOptions): void;
    resetHiveOptions(): void;
    get hiveOptionsInput(): BiglakeTableHiveOptions | undefined;
    private _timeouts;
    get timeouts(): BiglakeTableTimeoutsOutputReference;
    putTimeouts(value: BiglakeTableTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BiglakeTableTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
