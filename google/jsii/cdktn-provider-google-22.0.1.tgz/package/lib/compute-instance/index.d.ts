/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * If true, allows Terraform to stop the instance to update its properties. If you try to update a property that requires stopping the instance without setting this field, the update will fail.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#allow_stopping_for_update ComputeInstance#allow_stopping_for_update}
    */
    readonly allowStoppingForUpdate?: boolean | cdktn.IResolvable;
    /**
    * Whether sending and receiving of packets with non-matching source or destination IPs is allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#can_ip_forward ComputeInstance#can_ip_forward}
    */
    readonly canIpForward?: boolean | cdktn.IResolvable;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#deletion_policy ComputeInstance#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Whether deletion protection is enabled on this instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#deletion_protection ComputeInstance#deletion_protection}
    */
    readonly deletionProtection?: boolean | cdktn.IResolvable;
    /**
    * A brief description of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#description ComputeInstance#description}
    */
    readonly description?: string;
    /**
    * Desired status of the instance. Either "RUNNING", "SUSPENDED" or "TERMINATED".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#desired_status ComputeInstance#desired_status}
    */
    readonly desiredStatus?: string;
    /**
    * Whether the instance has virtual displays enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#enable_display ComputeInstance#enable_display}
    */
    readonly enableDisplay?: boolean | cdktn.IResolvable;
    /**
    * A custom hostname for the instance. Must be a fully qualified DNS name and RFC-1035-valid. Valid format is a series of labels 1-63 characters long matching the regular expression [a-z]([-a-z0-9]*[a-z0-9]), concatenated with periods. The entire hostname must not exceed 253 characters. Changing this forces a new resource to be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#hostname ComputeInstance#hostname}
    */
    readonly hostname?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#id ComputeInstance#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Action to be taken when a customer's encryption key is revoked. Supports "STOP" and "NONE", with "NONE" being the default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#key_revocation_action_type ComputeInstance#key_revocation_action_type}
    */
    readonly keyRevocationActionType?: string;
    /**
    * A set of key/value label pairs assigned to the instance.
    *
    * 				**Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * 				Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#labels ComputeInstance#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The machine type to create.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#machine_type ComputeInstance#machine_type}
    */
    readonly machineType: string;
    /**
    * Metadata key/value pairs made available within the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#metadata ComputeInstance#metadata}
    */
    readonly metadata?: {
        [key: string]: string;
    };
    /**
    * Metadata startup scripts made available within the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#metadata_startup_script ComputeInstance#metadata_startup_script}
    */
    readonly metadataStartupScript?: string;
    /**
    * The minimum CPU platform specified for the VM instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#min_cpu_platform ComputeInstance#min_cpu_platform}
    */
    readonly minCpuPlatform?: string;
    /**
    * The name of the instance. One of name or self_link must be provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#name ComputeInstance#name}
    */
    readonly name: string;
    /**
    * The ID of the project in which the resource belongs. If self_link is provided, this value is ignored. If neither self_link nor project are provided, the provider project is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#project ComputeInstance#project}
    */
    readonly project?: string;
    /**
    * A list of self_links of resource policies to attach to the instance. Currently a max of 1 resource policy is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#resource_policies ComputeInstance#resource_policies}
    */
    readonly resourcePolicies?: string[];
    /**
    * The list of tags attached to the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#tags ComputeInstance#tags}
    */
    readonly tags?: string[];
    /**
    * The zone of the instance. If self_link is provided, this value is ignored. If neither self_link nor zone are provided, the provider zone is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#zone ComputeInstance#zone}
    */
    readonly zone?: string;
    /**
    * advanced_machine_features block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#advanced_machine_features ComputeInstance#advanced_machine_features}
    */
    readonly advancedMachineFeatures?: ComputeInstanceAdvancedMachineFeatures;
    /**
    * attached_disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#attached_disk ComputeInstance#attached_disk}
    */
    readonly attachedDisk?: ComputeInstanceAttachedDisk[] | cdktn.IResolvable;
    /**
    * boot_disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#boot_disk ComputeInstance#boot_disk}
    */
    readonly bootDisk: ComputeInstanceBootDisk;
    /**
    * confidential_instance_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#confidential_instance_config ComputeInstance#confidential_instance_config}
    */
    readonly confidentialInstanceConfig?: ComputeInstanceConfidentialInstanceConfig;
    /**
    * guest_accelerator block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#guest_accelerator ComputeInstance#guest_accelerator}
    */
    readonly guestAccelerator?: ComputeInstanceGuestAccelerator[] | cdktn.IResolvable;
    /**
    * instance_encryption_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#instance_encryption_key ComputeInstance#instance_encryption_key}
    */
    readonly instanceEncryptionKey?: ComputeInstanceInstanceEncryptionKey;
    /**
    * network_interface block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#network_interface ComputeInstance#network_interface}
    */
    readonly networkInterface: ComputeInstanceNetworkInterface[] | cdktn.IResolvable;
    /**
    * network_performance_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#network_performance_config ComputeInstance#network_performance_config}
    */
    readonly networkPerformanceConfig?: ComputeInstanceNetworkPerformanceConfig;
    /**
    * params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#params ComputeInstance#params}
    */
    readonly params?: ComputeInstanceParams;
    /**
    * reservation_affinity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#reservation_affinity ComputeInstance#reservation_affinity}
    */
    readonly reservationAffinity?: ComputeInstanceReservationAffinity;
    /**
    * scheduling block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#scheduling ComputeInstance#scheduling}
    */
    readonly scheduling?: ComputeInstanceScheduling;
    /**
    * scratch_disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#scratch_disk ComputeInstance#scratch_disk}
    */
    readonly scratchDisk?: ComputeInstanceScratchDisk[] | cdktn.IResolvable;
    /**
    * service_account block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#service_account ComputeInstance#service_account}
    */
    readonly serviceAccount?: ComputeInstanceServiceAccount;
    /**
    * shielded_instance_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#shielded_instance_config ComputeInstance#shielded_instance_config}
    */
    readonly shieldedInstanceConfig?: ComputeInstanceShieldedInstanceConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#timeouts ComputeInstance#timeouts}
    */
    readonly timeouts?: ComputeInstanceTimeouts;
    /**
    * workload_identity_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#workload_identity_config ComputeInstance#workload_identity_config}
    */
    readonly workloadIdentityConfig?: ComputeInstanceWorkloadIdentityConfig;
}
export interface ComputeInstanceAdvancedMachineFeatures {
    /**
    * Whether to enable nested virtualization or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#enable_nested_virtualization ComputeInstance#enable_nested_virtualization}
    */
    readonly enableNestedVirtualization?: boolean | cdktn.IResolvable;
    /**
    * Whether to enable UEFI networking for the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#enable_uefi_networking ComputeInstance#enable_uefi_networking}
    */
    readonly enableUefiNetworking?: boolean | cdktn.IResolvable;
    /**
    * The PMU is a hardware component within the CPU core that monitors how the processor runs code. Valid values for the level of PMU are "STANDARD", "ENHANCED", and "ARCHITECTURAL".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#performance_monitoring_unit ComputeInstance#performance_monitoring_unit}
    */
    readonly performanceMonitoringUnit?: string;
    /**
    * The number of threads per physical core. To disable simultaneous multithreading (SMT) set this to 1. If unset, the maximum number of threads supported per core by the underlying processor is assumed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#threads_per_core ComputeInstance#threads_per_core}
    */
    readonly threadsPerCore?: number;
    /**
    * Turbo frequency mode to use for the instance. Currently supported modes is "ALL_CORE_MAX".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#turbo_mode ComputeInstance#turbo_mode}
    */
    readonly turboMode?: string;
    /**
    * The number of physical cores to expose to an instance. Multiply by the number of threads per core to compute the total number of virtual CPUs to expose to the instance. If unset, the number of cores is inferred from the instance\'s nominal CPU count and the underlying platform\'s SMT width.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#visible_core_count ComputeInstance#visible_core_count}
    */
    readonly visibleCoreCount?: number;
}
export declare function computeInstanceAdvancedMachineFeaturesToTerraform(struct?: ComputeInstanceAdvancedMachineFeaturesOutputReference | ComputeInstanceAdvancedMachineFeatures): any;
export declare function computeInstanceAdvancedMachineFeaturesToHclTerraform(struct?: ComputeInstanceAdvancedMachineFeaturesOutputReference | ComputeInstanceAdvancedMachineFeatures): any;
export declare class ComputeInstanceAdvancedMachineFeaturesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceAdvancedMachineFeatures | undefined;
    set internalValue(value: ComputeInstanceAdvancedMachineFeatures | undefined);
    private _enableNestedVirtualization?;
    get enableNestedVirtualization(): boolean | cdktn.IResolvable;
    set enableNestedVirtualization(value: boolean | cdktn.IResolvable);
    resetEnableNestedVirtualization(): void;
    get enableNestedVirtualizationInput(): boolean | cdktn.IResolvable | undefined;
    private _enableUefiNetworking?;
    get enableUefiNetworking(): boolean | cdktn.IResolvable;
    set enableUefiNetworking(value: boolean | cdktn.IResolvable);
    resetEnableUefiNetworking(): void;
    get enableUefiNetworkingInput(): boolean | cdktn.IResolvable | undefined;
    private _performanceMonitoringUnit?;
    get performanceMonitoringUnit(): string;
    set performanceMonitoringUnit(value: string);
    resetPerformanceMonitoringUnit(): void;
    get performanceMonitoringUnitInput(): string | undefined;
    private _threadsPerCore?;
    get threadsPerCore(): number;
    set threadsPerCore(value: number);
    resetThreadsPerCore(): void;
    get threadsPerCoreInput(): number | undefined;
    private _turboMode?;
    get turboMode(): string;
    set turboMode(value: string);
    resetTurboMode(): void;
    get turboModeInput(): string | undefined;
    private _visibleCoreCount?;
    get visibleCoreCount(): number;
    set visibleCoreCount(value: number);
    resetVisibleCoreCount(): void;
    get visibleCoreCountInput(): number | undefined;
}
export interface ComputeInstanceAttachedDisk {
    /**
    * Name with which the attached disk is accessible under /dev/disk/by-id/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#device_name ComputeInstance#device_name}
    */
    readonly deviceName?: string;
    /**
    * A 256-bit customer-supplied encryption key, encoded in RFC 4648 base64 to encrypt this disk. Only one of kms_key_self_link, disk_encryption_key_rsa and disk_encryption_key_raw may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#disk_encryption_key_raw ComputeInstance#disk_encryption_key_raw}
    */
    readonly diskEncryptionKeyRaw?: string;
    /**
    * Specifies an RFC 4648 base64 encoded, RSA-wrapped 2048-bit customer-supplied encryption key to either encrypt or decrypt this resource. Only one of kms_key_self_link, disk_encryption_key_rsa and disk_encryption_key_raw may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#disk_encryption_key_rsa ComputeInstance#disk_encryption_key_rsa}
    */
    readonly diskEncryptionKeyRsa?: string;
    /**
    * The service account being used for the encryption request for the given KMS key. If absent, the Compute Engine default service account is used
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#disk_encryption_service_account ComputeInstance#disk_encryption_service_account}
    */
    readonly diskEncryptionServiceAccount?: string;
    /**
    * Whether to force attach the regional disk even if it's currently attached to another instance. If you try to force attach a zonal disk to an instance, you will receive an error. Setting this parameter cause VM recreation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#force_attach ComputeInstance#force_attach}
    */
    readonly forceAttach?: boolean | cdktn.IResolvable;
    /**
    * The self_link of the encryption key that is stored in Google Cloud KMS to encrypt this disk. Only one of kms_key_self_link, disk_encryption_key_rsa and disk_encryption_key_raw may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#kms_key_self_link ComputeInstance#kms_key_self_link}
    */
    readonly kmsKeySelfLink?: string;
    /**
    * Read/write mode for the disk. One of "READ_ONLY" or "READ_WRITE".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#mode ComputeInstance#mode}
    */
    readonly mode?: string;
    /**
    * The name or self_link of the disk attached to this instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#source ComputeInstance#source}
    */
    readonly source: string;
}
export declare function computeInstanceAttachedDiskToTerraform(struct?: ComputeInstanceAttachedDisk | cdktn.IResolvable): any;
export declare function computeInstanceAttachedDiskToHclTerraform(struct?: ComputeInstanceAttachedDisk | cdktn.IResolvable): any;
export declare class ComputeInstanceAttachedDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceAttachedDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInstanceAttachedDisk | cdktn.IResolvable | undefined);
    private _deviceName?;
    get deviceName(): string;
    set deviceName(value: string);
    resetDeviceName(): void;
    get deviceNameInput(): string | undefined;
    private _diskEncryptionKeyRaw?;
    get diskEncryptionKeyRaw(): string;
    set diskEncryptionKeyRaw(value: string);
    resetDiskEncryptionKeyRaw(): void;
    get diskEncryptionKeyRawInput(): string | undefined;
    private _diskEncryptionKeyRsa?;
    get diskEncryptionKeyRsa(): string;
    set diskEncryptionKeyRsa(value: string);
    resetDiskEncryptionKeyRsa(): void;
    get diskEncryptionKeyRsaInput(): string | undefined;
    get diskEncryptionKeySha256(): string;
    private _diskEncryptionServiceAccount?;
    get diskEncryptionServiceAccount(): string;
    set diskEncryptionServiceAccount(value: string);
    resetDiskEncryptionServiceAccount(): void;
    get diskEncryptionServiceAccountInput(): string | undefined;
    private _forceAttach?;
    get forceAttach(): boolean | cdktn.IResolvable;
    set forceAttach(value: boolean | cdktn.IResolvable);
    resetForceAttach(): void;
    get forceAttachInput(): boolean | cdktn.IResolvable | undefined;
    private _kmsKeySelfLink?;
    get kmsKeySelfLink(): string;
    set kmsKeySelfLink(value: string);
    resetKmsKeySelfLink(): void;
    get kmsKeySelfLinkInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
}
export declare class ComputeInstanceAttachedDiskList extends cdktn.ComplexList {
    internalValue?: ComputeInstanceAttachedDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceAttachedDiskOutputReference;
}
export interface ComputeInstanceBootDiskInitializeParamsSourceImageEncryptionKey {
    /**
    * The self link of the encryption key that is stored in Google Cloud KMS. Only one of kms_key_self_link, rsa_encrypted_key and raw_key may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#kms_key_self_link ComputeInstance#kms_key_self_link}
    */
    readonly kmsKeySelfLink?: string;
    /**
    * The service account being used for the encryption request for the given KMS key. If absent, the Compute Engine default service account is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#kms_key_service_account ComputeInstance#kms_key_service_account}
    */
    readonly kmsKeyServiceAccount?: string;
    /**
    * Specifies a 256-bit customer-supplied encryption key, encoded in RFC 4648 base64 to either encrypt or decrypt this resource. Only one of kms_key_self_link, rsa_encrypted_key and raw_key may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#raw_key ComputeInstance#raw_key}
    */
    readonly rawKey?: string;
    /**
    * Specifies an RFC 4648 base64 encoded, RSA-wrapped 2048-bit customer-supplied encryption key to either encrypt or decrypt this resource. Only one of kms_key_self_link, rsa_encrypted_key and raw_key may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#rsa_encrypted_key ComputeInstance#rsa_encrypted_key}
    */
    readonly rsaEncryptedKey?: string;
}
export declare function computeInstanceBootDiskInitializeParamsSourceImageEncryptionKeyToTerraform(struct?: ComputeInstanceBootDiskInitializeParamsSourceImageEncryptionKeyOutputReference | ComputeInstanceBootDiskInitializeParamsSourceImageEncryptionKey): any;
export declare function computeInstanceBootDiskInitializeParamsSourceImageEncryptionKeyToHclTerraform(struct?: ComputeInstanceBootDiskInitializeParamsSourceImageEncryptionKeyOutputReference | ComputeInstanceBootDiskInitializeParamsSourceImageEncryptionKey): any;
export declare class ComputeInstanceBootDiskInitializeParamsSourceImageEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceBootDiskInitializeParamsSourceImageEncryptionKey | undefined;
    set internalValue(value: ComputeInstanceBootDiskInitializeParamsSourceImageEncryptionKey | undefined);
    private _kmsKeySelfLink?;
    get kmsKeySelfLink(): string;
    set kmsKeySelfLink(value: string);
    resetKmsKeySelfLink(): void;
    get kmsKeySelfLinkInput(): string | undefined;
    private _kmsKeyServiceAccount?;
    get kmsKeyServiceAccount(): string;
    set kmsKeyServiceAccount(value: string);
    resetKmsKeyServiceAccount(): void;
    get kmsKeyServiceAccountInput(): string | undefined;
    private _rawKey?;
    get rawKey(): string;
    set rawKey(value: string);
    resetRawKey(): void;
    get rawKeyInput(): string | undefined;
    private _rsaEncryptedKey?;
    get rsaEncryptedKey(): string;
    set rsaEncryptedKey(value: string);
    resetRsaEncryptedKey(): void;
    get rsaEncryptedKeyInput(): string | undefined;
    get sha256(): string;
}
export interface ComputeInstanceBootDiskInitializeParamsSourceSnapshotEncryptionKey {
    /**
    * The self link of the encryption key that is stored in Google Cloud KMS. Only one of kms_key_self_link, rsa_encrypted_key and raw_key may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#kms_key_self_link ComputeInstance#kms_key_self_link}
    */
    readonly kmsKeySelfLink?: string;
    /**
    * The service account being used for the encryption request for the given KMS key. If absent, the Compute Engine default service account is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#kms_key_service_account ComputeInstance#kms_key_service_account}
    */
    readonly kmsKeyServiceAccount?: string;
    /**
    * Specifies a 256-bit customer-supplied encryption key, encoded in RFC 4648 base64 to either encrypt or decrypt this resource. Only one of kms_key_self_link, rsa_encrypted_key and raw_key may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#raw_key ComputeInstance#raw_key}
    */
    readonly rawKey?: string;
    /**
    * Specifies an RFC 4648 base64 encoded, RSA-wrapped 2048-bit customer-supplied encryption key to either encrypt or decrypt this resource. Only one of kms_key_self_link, rsa_encrypted_key and raw_key may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#rsa_encrypted_key ComputeInstance#rsa_encrypted_key}
    */
    readonly rsaEncryptedKey?: string;
}
export declare function computeInstanceBootDiskInitializeParamsSourceSnapshotEncryptionKeyToTerraform(struct?: ComputeInstanceBootDiskInitializeParamsSourceSnapshotEncryptionKeyOutputReference | ComputeInstanceBootDiskInitializeParamsSourceSnapshotEncryptionKey): any;
export declare function computeInstanceBootDiskInitializeParamsSourceSnapshotEncryptionKeyToHclTerraform(struct?: ComputeInstanceBootDiskInitializeParamsSourceSnapshotEncryptionKeyOutputReference | ComputeInstanceBootDiskInitializeParamsSourceSnapshotEncryptionKey): any;
export declare class ComputeInstanceBootDiskInitializeParamsSourceSnapshotEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceBootDiskInitializeParamsSourceSnapshotEncryptionKey | undefined;
    set internalValue(value: ComputeInstanceBootDiskInitializeParamsSourceSnapshotEncryptionKey | undefined);
    private _kmsKeySelfLink?;
    get kmsKeySelfLink(): string;
    set kmsKeySelfLink(value: string);
    resetKmsKeySelfLink(): void;
    get kmsKeySelfLinkInput(): string | undefined;
    private _kmsKeyServiceAccount?;
    get kmsKeyServiceAccount(): string;
    set kmsKeyServiceAccount(value: string);
    resetKmsKeyServiceAccount(): void;
    get kmsKeyServiceAccountInput(): string | undefined;
    private _rawKey?;
    get rawKey(): string;
    set rawKey(value: string);
    resetRawKey(): void;
    get rawKeyInput(): string | undefined;
    private _rsaEncryptedKey?;
    get rsaEncryptedKey(): string;
    set rsaEncryptedKey(value: string);
    resetRsaEncryptedKey(): void;
    get rsaEncryptedKeyInput(): string | undefined;
    get sha256(): string;
}
export interface ComputeInstanceBootDiskInitializeParams {
    /**
    * The architecture of the disk. One of "X86_64" or "ARM64".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#architecture ComputeInstance#architecture}
    */
    readonly architecture?: string;
    /**
    * A flag to enable confidential compute mode on boot disk
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#enable_confidential_compute ComputeInstance#enable_confidential_compute}
    */
    readonly enableConfidentialCompute?: boolean | cdktn.IResolvable;
    /**
    * The image from which this disk was initialised.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#image ComputeInstance#image}
    */
    readonly image?: string;
    /**
    * A set of key/value label pairs assigned to the disk.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#labels ComputeInstance#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Indicates how many IOPS to provision for the disk. This sets the number of I/O operations per second that the disk can handle.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#provisioned_iops ComputeInstance#provisioned_iops}
    */
    readonly provisionedIops?: number;
    /**
    * Indicates how much throughput to provision for the disk. This sets the number of throughput mb per second that the disk can handle.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#provisioned_throughput ComputeInstance#provisioned_throughput}
    */
    readonly provisionedThroughput?: number;
    /**
    * A list of short names or self_links of zones in which to create a regional disk.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#replica_zones ComputeInstance#replica_zones}
    */
    readonly replicaZones?: string[];
    /**
    * A map of resource manager tags. Resource manager tag keys and values have the same definition as resource manager tags. Keys must be in the format tagKeys/{tag_key_id}, and values are in the format tagValues/456. The field is ignored (both PUT & PATCH) when empty.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#resource_manager_tags ComputeInstance#resource_manager_tags}
    */
    readonly resourceManagerTags?: {
        [key: string]: string;
    };
    /**
    * A list of self_links of resource policies to attach to the instance's boot disk. Modifying this list will cause the instance to recreate. Currently a max of 1 resource policy is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#resource_policies ComputeInstance#resource_policies}
    */
    readonly resourcePolicies?: string[];
    /**
    * The size of the image in gigabytes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#size ComputeInstance#size}
    */
    readonly size?: number;
    /**
    * The snapshot from which this disk was initialised.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#snapshot ComputeInstance#snapshot}
    */
    readonly snapshot?: string;
    /**
    * The URL of the storage pool in which the new disk is created
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#storage_pool ComputeInstance#storage_pool}
    */
    readonly storagePool?: string;
    /**
    * The Google Compute Engine disk type. Such as pd-standard, pd-ssd or pd-balanced.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#type ComputeInstance#type}
    */
    readonly type?: string;
    /**
    * source_image_encryption_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#source_image_encryption_key ComputeInstance#source_image_encryption_key}
    */
    readonly sourceImageEncryptionKey?: ComputeInstanceBootDiskInitializeParamsSourceImageEncryptionKey;
    /**
    * source_snapshot_encryption_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#source_snapshot_encryption_key ComputeInstance#source_snapshot_encryption_key}
    */
    readonly sourceSnapshotEncryptionKey?: ComputeInstanceBootDiskInitializeParamsSourceSnapshotEncryptionKey;
}
export declare function computeInstanceBootDiskInitializeParamsToTerraform(struct?: ComputeInstanceBootDiskInitializeParamsOutputReference | ComputeInstanceBootDiskInitializeParams): any;
export declare function computeInstanceBootDiskInitializeParamsToHclTerraform(struct?: ComputeInstanceBootDiskInitializeParamsOutputReference | ComputeInstanceBootDiskInitializeParams): any;
export declare class ComputeInstanceBootDiskInitializeParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceBootDiskInitializeParams | undefined;
    set internalValue(value: ComputeInstanceBootDiskInitializeParams | undefined);
    private _architecture?;
    get architecture(): string;
    set architecture(value: string);
    resetArchitecture(): void;
    get architectureInput(): string | undefined;
    private _enableConfidentialCompute?;
    get enableConfidentialCompute(): boolean | cdktn.IResolvable;
    set enableConfidentialCompute(value: boolean | cdktn.IResolvable);
    resetEnableConfidentialCompute(): void;
    get enableConfidentialComputeInput(): boolean | cdktn.IResolvable | undefined;
    private _image?;
    get image(): string;
    set image(value: string);
    resetImage(): void;
    get imageInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _provisionedIops?;
    get provisionedIops(): number;
    set provisionedIops(value: number);
    resetProvisionedIops(): void;
    get provisionedIopsInput(): number | undefined;
    private _provisionedThroughput?;
    get provisionedThroughput(): number;
    set provisionedThroughput(value: number);
    resetProvisionedThroughput(): void;
    get provisionedThroughputInput(): number | undefined;
    private _replicaZones?;
    get replicaZones(): string[];
    set replicaZones(value: string[]);
    resetReplicaZones(): void;
    get replicaZonesInput(): string[] | undefined;
    private _resourceManagerTags?;
    get resourceManagerTags(): {
        [key: string]: string;
    };
    set resourceManagerTags(value: {
        [key: string]: string;
    });
    resetResourceManagerTags(): void;
    get resourceManagerTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _resourcePolicies?;
    get resourcePolicies(): string[];
    set resourcePolicies(value: string[]);
    resetResourcePolicies(): void;
    get resourcePoliciesInput(): string[] | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    resetSize(): void;
    get sizeInput(): number | undefined;
    private _snapshot?;
    get snapshot(): string;
    set snapshot(value: string);
    resetSnapshot(): void;
    get snapshotInput(): string | undefined;
    private _storagePool?;
    get storagePool(): string;
    set storagePool(value: string);
    resetStoragePool(): void;
    get storagePoolInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _sourceImageEncryptionKey;
    get sourceImageEncryptionKey(): ComputeInstanceBootDiskInitializeParamsSourceImageEncryptionKeyOutputReference;
    putSourceImageEncryptionKey(value: ComputeInstanceBootDiskInitializeParamsSourceImageEncryptionKey): void;
    resetSourceImageEncryptionKey(): void;
    get sourceImageEncryptionKeyInput(): ComputeInstanceBootDiskInitializeParamsSourceImageEncryptionKey | undefined;
    private _sourceSnapshotEncryptionKey;
    get sourceSnapshotEncryptionKey(): ComputeInstanceBootDiskInitializeParamsSourceSnapshotEncryptionKeyOutputReference;
    putSourceSnapshotEncryptionKey(value: ComputeInstanceBootDiskInitializeParamsSourceSnapshotEncryptionKey): void;
    resetSourceSnapshotEncryptionKey(): void;
    get sourceSnapshotEncryptionKeyInput(): ComputeInstanceBootDiskInitializeParamsSourceSnapshotEncryptionKey | undefined;
}
export interface ComputeInstanceBootDisk {
    /**
    * Whether the disk will be auto-deleted when the instance is deleted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#auto_delete ComputeInstance#auto_delete}
    */
    readonly autoDelete?: boolean | cdktn.IResolvable;
    /**
    * Name with which attached disk will be accessible under /dev/disk/by-id/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#device_name ComputeInstance#device_name}
    */
    readonly deviceName?: string;
    /**
    * A 256-bit customer-supplied encryption key, encoded in RFC 4648 base64 to encrypt this disk. Only one of kms_key_self_link, disk_encryption_key_raw and disk_encryption_key_rsa may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#disk_encryption_key_raw ComputeInstance#disk_encryption_key_raw}
    */
    readonly diskEncryptionKeyRaw?: string;
    /**
    * Specifies an RFC 4648 base64 encoded, RSA-wrapped 2048-bit customer-supplied encryption key to either encrypt or decrypt this resource. Only one of kms_key_self_link, disk_encryption_key_raw and disk_encryption_key_rsa may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#disk_encryption_key_rsa ComputeInstance#disk_encryption_key_rsa}
    */
    readonly diskEncryptionKeyRsa?: string;
    /**
    * The service account being used for the encryption request for the given KMS key. If absent, the Compute Engine default service account is used
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#disk_encryption_service_account ComputeInstance#disk_encryption_service_account}
    */
    readonly diskEncryptionServiceAccount?: string;
    /**
    * Whether to force attach the regional disk even if it's currently attached to another instance. If you try to force attach a zonal disk to an instance, you will receive an error. Setting this parameter cause VM recreation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#force_attach ComputeInstance#force_attach}
    */
    readonly forceAttach?: boolean | cdktn.IResolvable;
    /**
    * A list of features to enable on the guest operating system. Applicable only for bootable images.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#guest_os_features ComputeInstance#guest_os_features}
    */
    readonly guestOsFeatures?: string[];
    /**
    * The disk interface used for attaching this disk. One of SCSI or NVME. (This field is shared with attached_disk and only used for specific cases, please don't specify this field without advice from Google.)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#interface ComputeInstance#interface}
    */
    readonly interface?: string;
    /**
    * The self_link of the encryption key that is stored in Google Cloud KMS to encrypt this disk. Only one of kms_key_self_link, disk_encryption_key_raw and disk_encryption_key_rsa may be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#kms_key_self_link ComputeInstance#kms_key_self_link}
    */
    readonly kmsKeySelfLink?: string;
    /**
    * Read/write mode for the disk. One of "READ_ONLY" or "READ_WRITE".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#mode ComputeInstance#mode}
    */
    readonly mode?: string;
    /**
    * The name or self_link of the disk attached to this instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#source ComputeInstance#source}
    */
    readonly source?: string;
    /**
    * initialize_params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#initialize_params ComputeInstance#initialize_params}
    */
    readonly initializeParams?: ComputeInstanceBootDiskInitializeParams;
}
export declare function computeInstanceBootDiskToTerraform(struct?: ComputeInstanceBootDiskOutputReference | ComputeInstanceBootDisk): any;
export declare function computeInstanceBootDiskToHclTerraform(struct?: ComputeInstanceBootDiskOutputReference | ComputeInstanceBootDisk): any;
export declare class ComputeInstanceBootDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceBootDisk | undefined;
    set internalValue(value: ComputeInstanceBootDisk | undefined);
    private _autoDelete?;
    get autoDelete(): boolean | cdktn.IResolvable;
    set autoDelete(value: boolean | cdktn.IResolvable);
    resetAutoDelete(): void;
    get autoDeleteInput(): boolean | cdktn.IResolvable | undefined;
    private _deviceName?;
    get deviceName(): string;
    set deviceName(value: string);
    resetDeviceName(): void;
    get deviceNameInput(): string | undefined;
    private _diskEncryptionKeyRaw?;
    get diskEncryptionKeyRaw(): string;
    set diskEncryptionKeyRaw(value: string);
    resetDiskEncryptionKeyRaw(): void;
    get diskEncryptionKeyRawInput(): string | undefined;
    private _diskEncryptionKeyRsa?;
    get diskEncryptionKeyRsa(): string;
    set diskEncryptionKeyRsa(value: string);
    resetDiskEncryptionKeyRsa(): void;
    get diskEncryptionKeyRsaInput(): string | undefined;
    get diskEncryptionKeySha256(): string;
    private _diskEncryptionServiceAccount?;
    get diskEncryptionServiceAccount(): string;
    set diskEncryptionServiceAccount(value: string);
    resetDiskEncryptionServiceAccount(): void;
    get diskEncryptionServiceAccountInput(): string | undefined;
    private _forceAttach?;
    get forceAttach(): boolean | cdktn.IResolvable;
    set forceAttach(value: boolean | cdktn.IResolvable);
    resetForceAttach(): void;
    get forceAttachInput(): boolean | cdktn.IResolvable | undefined;
    private _guestOsFeatures?;
    get guestOsFeatures(): string[];
    set guestOsFeatures(value: string[]);
    resetGuestOsFeatures(): void;
    get guestOsFeaturesInput(): string[] | undefined;
    private _interface?;
    get interface(): string;
    set interface(value: string);
    resetInterface(): void;
    get interfaceInput(): string | undefined;
    private _kmsKeySelfLink?;
    get kmsKeySelfLink(): string;
    set kmsKeySelfLink(value: string);
    resetKmsKeySelfLink(): void;
    get kmsKeySelfLinkInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _initializeParams;
    get initializeParams(): ComputeInstanceBootDiskInitializeParamsOutputReference;
    putInitializeParams(value: ComputeInstanceBootDiskInitializeParams): void;
    resetInitializeParams(): void;
    get initializeParamsInput(): ComputeInstanceBootDiskInitializeParams | undefined;
}
export interface ComputeInstanceConfidentialInstanceConfig {
    /**
    *
    * 								The confidential computing technology the instance uses.
    * 								SEV is an AMD feature. TDX is an Intel feature. One of the following
    * 								values is required: SEV, SEV_SNP, TDX. If SEV_SNP, min_cpu_platform =
    * 								"AMD Milan" is currently required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#confidential_instance_type ComputeInstance#confidential_instance_type}
    */
    readonly confidentialInstanceType?: string;
    /**
    * Defines whether the instance should have confidential compute enabled. Field will be deprecated in a future release
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#enable_confidential_compute ComputeInstance#enable_confidential_compute}
    */
    readonly enableConfidentialCompute?: boolean | cdktn.IResolvable;
}
export declare function computeInstanceConfidentialInstanceConfigToTerraform(struct?: ComputeInstanceConfidentialInstanceConfigOutputReference | ComputeInstanceConfidentialInstanceConfig): any;
export declare function computeInstanceConfidentialInstanceConfigToHclTerraform(struct?: ComputeInstanceConfidentialInstanceConfigOutputReference | ComputeInstanceConfidentialInstanceConfig): any;
export declare class ComputeInstanceConfidentialInstanceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceConfidentialInstanceConfig | undefined;
    set internalValue(value: ComputeInstanceConfidentialInstanceConfig | undefined);
    private _confidentialInstanceType?;
    get confidentialInstanceType(): string;
    set confidentialInstanceType(value: string);
    resetConfidentialInstanceType(): void;
    get confidentialInstanceTypeInput(): string | undefined;
    private _enableConfidentialCompute?;
    get enableConfidentialCompute(): boolean | cdktn.IResolvable;
    set enableConfidentialCompute(value: boolean | cdktn.IResolvable);
    resetEnableConfidentialCompute(): void;
    get enableConfidentialComputeInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ComputeInstanceGuestAccelerator {
    /**
    * The number of the guest accelerator cards exposed to this instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#count ComputeInstance#count}
    */
    readonly count: number;
    /**
    * The accelerator type resource exposed to this instance. E.g. nvidia-tesla-k80.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#type ComputeInstance#type}
    */
    readonly type: string;
}
export declare function computeInstanceGuestAcceleratorToTerraform(struct?: ComputeInstanceGuestAccelerator | cdktn.IResolvable): any;
export declare function computeInstanceGuestAcceleratorToHclTerraform(struct?: ComputeInstanceGuestAccelerator | cdktn.IResolvable): any;
export declare class ComputeInstanceGuestAcceleratorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceGuestAccelerator | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInstanceGuestAccelerator | cdktn.IResolvable | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    get countInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class ComputeInstanceGuestAcceleratorList extends cdktn.ComplexList {
    internalValue?: ComputeInstanceGuestAccelerator[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceGuestAcceleratorOutputReference;
}
export interface ComputeInstanceInstanceEncryptionKey {
    /**
    * The self link of the encryption key that is stored in Google Cloud KMS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#kms_key_self_link ComputeInstance#kms_key_self_link}
    */
    readonly kmsKeySelfLink?: string;
    /**
    * The service account being used for the encryption request for the given KMS key. If absent, the Compute Engine default service account is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#kms_key_service_account ComputeInstance#kms_key_service_account}
    */
    readonly kmsKeyServiceAccount?: string;
}
export declare function computeInstanceInstanceEncryptionKeyToTerraform(struct?: ComputeInstanceInstanceEncryptionKeyOutputReference | ComputeInstanceInstanceEncryptionKey): any;
export declare function computeInstanceInstanceEncryptionKeyToHclTerraform(struct?: ComputeInstanceInstanceEncryptionKeyOutputReference | ComputeInstanceInstanceEncryptionKey): any;
export declare class ComputeInstanceInstanceEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceInstanceEncryptionKey | undefined;
    set internalValue(value: ComputeInstanceInstanceEncryptionKey | undefined);
    private _kmsKeySelfLink?;
    get kmsKeySelfLink(): string;
    set kmsKeySelfLink(value: string);
    resetKmsKeySelfLink(): void;
    get kmsKeySelfLinkInput(): string | undefined;
    private _kmsKeyServiceAccount?;
    get kmsKeyServiceAccount(): string;
    set kmsKeyServiceAccount(value: string);
    resetKmsKeyServiceAccount(): void;
    get kmsKeyServiceAccountInput(): string | undefined;
    get sha256(): string;
}
export interface ComputeInstanceNetworkInterfaceAccessConfig {
    /**
    * The IP address that is be 1:1 mapped to the instance's network ip.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#nat_ip ComputeInstance#nat_ip}
    */
    readonly natIp?: string;
    /**
    * The networking tier used for configuring this instance. One of PREMIUM or STANDARD.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#network_tier ComputeInstance#network_tier}
    */
    readonly networkTier?: string;
    /**
    * The DNS domain name for the public PTR record.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#public_ptr_domain_name ComputeInstance#public_ptr_domain_name}
    */
    readonly publicPtrDomainName?: string;
}
export declare function computeInstanceNetworkInterfaceAccessConfigToTerraform(struct?: ComputeInstanceNetworkInterfaceAccessConfig | cdktn.IResolvable): any;
export declare function computeInstanceNetworkInterfaceAccessConfigToHclTerraform(struct?: ComputeInstanceNetworkInterfaceAccessConfig | cdktn.IResolvable): any;
export declare class ComputeInstanceNetworkInterfaceAccessConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceNetworkInterfaceAccessConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInstanceNetworkInterfaceAccessConfig | cdktn.IResolvable | undefined);
    private _natIp?;
    get natIp(): string;
    set natIp(value: string);
    resetNatIp(): void;
    get natIpInput(): string | undefined;
    private _networkTier?;
    get networkTier(): string;
    set networkTier(value: string);
    resetNetworkTier(): void;
    get networkTierInput(): string | undefined;
    private _publicPtrDomainName?;
    get publicPtrDomainName(): string;
    set publicPtrDomainName(value: string);
    resetPublicPtrDomainName(): void;
    get publicPtrDomainNameInput(): string | undefined;
}
export declare class ComputeInstanceNetworkInterfaceAccessConfigList extends cdktn.ComplexList {
    internalValue?: ComputeInstanceNetworkInterfaceAccessConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceNetworkInterfaceAccessConfigOutputReference;
}
export interface ComputeInstanceNetworkInterfaceAliasIpRange {
    /**
    * The IP CIDR range represented by this alias IP range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#ip_cidr_range ComputeInstance#ip_cidr_range}
    */
    readonly ipCidrRange: string;
    /**
    * The subnetwork secondary range name specifying the secondary range from which to allocate the IP CIDR range for this alias IP range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#subnetwork_range_name ComputeInstance#subnetwork_range_name}
    */
    readonly subnetworkRangeName?: string;
}
export declare function computeInstanceNetworkInterfaceAliasIpRangeToTerraform(struct?: ComputeInstanceNetworkInterfaceAliasIpRange | cdktn.IResolvable): any;
export declare function computeInstanceNetworkInterfaceAliasIpRangeToHclTerraform(struct?: ComputeInstanceNetworkInterfaceAliasIpRange | cdktn.IResolvable): any;
export declare class ComputeInstanceNetworkInterfaceAliasIpRangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceNetworkInterfaceAliasIpRange | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInstanceNetworkInterfaceAliasIpRange | cdktn.IResolvable | undefined);
    private _ipCidrRange?;
    get ipCidrRange(): string;
    set ipCidrRange(value: string);
    get ipCidrRangeInput(): string | undefined;
    private _subnetworkRangeName?;
    get subnetworkRangeName(): string;
    set subnetworkRangeName(value: string);
    resetSubnetworkRangeName(): void;
    get subnetworkRangeNameInput(): string | undefined;
}
export declare class ComputeInstanceNetworkInterfaceAliasIpRangeList extends cdktn.ComplexList {
    internalValue?: ComputeInstanceNetworkInterfaceAliasIpRange[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceNetworkInterfaceAliasIpRangeOutputReference;
}
export interface ComputeInstanceNetworkInterfaceIpv6AccessConfig {
    /**
    * The first IPv6 address of the external IPv6 range associated with this instance, prefix length is stored in externalIpv6PrefixLength in ipv6AccessConfig. To use a static external IP address, it must be unused and in the same region as the instance's zone. If not specified, Google Cloud will automatically assign an external IPv6 address from the instance's subnetwork.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#external_ipv6 ComputeInstance#external_ipv6}
    */
    readonly externalIpv6?: string;
    /**
    * The prefix length of the external IPv6 range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#external_ipv6_prefix_length ComputeInstance#external_ipv6_prefix_length}
    */
    readonly externalIpv6PrefixLength?: string;
    /**
    * The name of this access configuration. In ipv6AccessConfigs, the recommended name is External IPv6.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#name ComputeInstance#name}
    */
    readonly name?: string;
    /**
    * The service-level to be provided for IPv6 traffic when the subnet has an external subnet. Only PREMIUM tier is valid for IPv6
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#network_tier ComputeInstance#network_tier}
    */
    readonly networkTier: string;
    /**
    * The domain name to be used when creating DNSv6 records for the external IPv6 ranges.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#public_ptr_domain_name ComputeInstance#public_ptr_domain_name}
    */
    readonly publicPtrDomainName?: string;
}
export declare function computeInstanceNetworkInterfaceIpv6AccessConfigToTerraform(struct?: ComputeInstanceNetworkInterfaceIpv6AccessConfig | cdktn.IResolvable): any;
export declare function computeInstanceNetworkInterfaceIpv6AccessConfigToHclTerraform(struct?: ComputeInstanceNetworkInterfaceIpv6AccessConfig | cdktn.IResolvable): any;
export declare class ComputeInstanceNetworkInterfaceIpv6AccessConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceNetworkInterfaceIpv6AccessConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInstanceNetworkInterfaceIpv6AccessConfig | cdktn.IResolvable | undefined);
    private _externalIpv6?;
    get externalIpv6(): string;
    set externalIpv6(value: string);
    resetExternalIpv6(): void;
    get externalIpv6Input(): string | undefined;
    private _externalIpv6PrefixLength?;
    get externalIpv6PrefixLength(): string;
    set externalIpv6PrefixLength(value: string);
    resetExternalIpv6PrefixLength(): void;
    get externalIpv6PrefixLengthInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _networkTier?;
    get networkTier(): string;
    set networkTier(value: string);
    get networkTierInput(): string | undefined;
    private _publicPtrDomainName?;
    get publicPtrDomainName(): string;
    set publicPtrDomainName(value: string);
    resetPublicPtrDomainName(): void;
    get publicPtrDomainNameInput(): string | undefined;
}
export declare class ComputeInstanceNetworkInterfaceIpv6AccessConfigList extends cdktn.ComplexList {
    internalValue?: ComputeInstanceNetworkInterfaceIpv6AccessConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceNetworkInterfaceIpv6AccessConfigOutputReference;
}
export interface ComputeInstanceNetworkInterface {
    /**
    * If true, DNS resolution will be enabled over this interface. Only valid with network_attachment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#enable_vpc_scoped_dns ComputeInstance#enable_vpc_scoped_dns}
    */
    readonly enableVpcScopedDns?: boolean | cdktn.IResolvable;
    /**
    * Indicates whether igmp query is enabled on the network interface or not. If enabled, also indicates the version of IGMP supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#igmp_query ComputeInstance#igmp_query}
    */
    readonly igmpQuery?: string;
    /**
    * The prefix length of the primary internal IPv6 range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#internal_ipv6_prefix_length ComputeInstance#internal_ipv6_prefix_length}
    */
    readonly internalIpv6PrefixLength?: number;
    /**
    * An IPv6 internal network address for this network interface. If not specified, Google Cloud will automatically assign an internal IPv6 address from the instance's subnetwork.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#ipv6_address ComputeInstance#ipv6_address}
    */
    readonly ipv6Address?: string;
    /**
    * The name or self_link of the network attached to this interface.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#network ComputeInstance#network}
    */
    readonly network?: string;
    /**
    * The URL of the network attachment that this interface should connect to in the following format: projects/{projectNumber}/regions/{region_name}/networkAttachments/{network_attachment_name}.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#network_attachment ComputeInstance#network_attachment}
    */
    readonly networkAttachment?: string;
    /**
    * The private IP address assigned to the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#network_ip ComputeInstance#network_ip}
    */
    readonly networkIp?: string;
    /**
    * The type of vNIC to be used on this interface. Possible values:GVNIC, VIRTIO_NET, IDPF, MRDMA, IRDMA and IDPF
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#nic_type ComputeInstance#nic_type}
    */
    readonly nicType?: string;
    /**
    * The networking queue count that's specified by users for the network interface. Both Rx and Tx queues will be set to this number. It will be empty if not specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#queue_count ComputeInstance#queue_count}
    */
    readonly queueCount?: number;
    /**
    * Producer Service's Service class Id for the region of this network interface. Can only be used with network_attachment. It is not possible to use on its own; however, network_attachment can be used without service_class_id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#service_class_id ComputeInstance#service_class_id}
    */
    readonly serviceClassId?: string;
    /**
    * The stack type for this network interface to identify whether the IPv6 feature is enabled or not. If not specified, IPV4_ONLY will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#stack_type ComputeInstance#stack_type}
    */
    readonly stackType?: string;
    /**
    * The name or self_link of the subnetwork attached to this interface.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#subnetwork ComputeInstance#subnetwork}
    */
    readonly subnetwork?: string;
    /**
    * The project in which the subnetwork belongs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#subnetwork_project ComputeInstance#subnetwork_project}
    */
    readonly subnetworkProject?: string;
    /**
    * VLAN tag of a dynamic network interface, must be an integer in the range from 2 to 255 inclusively.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#vlan ComputeInstance#vlan}
    */
    readonly vlan?: number;
    /**
    * access_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#access_config ComputeInstance#access_config}
    */
    readonly accessConfig?: ComputeInstanceNetworkInterfaceAccessConfig[] | cdktn.IResolvable;
    /**
    * alias_ip_range block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#alias_ip_range ComputeInstance#alias_ip_range}
    */
    readonly aliasIpRange?: ComputeInstanceNetworkInterfaceAliasIpRange[] | cdktn.IResolvable;
    /**
    * ipv6_access_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#ipv6_access_config ComputeInstance#ipv6_access_config}
    */
    readonly ipv6AccessConfig?: ComputeInstanceNetworkInterfaceIpv6AccessConfig[] | cdktn.IResolvable;
}
export declare function computeInstanceNetworkInterfaceToTerraform(struct?: ComputeInstanceNetworkInterface | cdktn.IResolvable): any;
export declare function computeInstanceNetworkInterfaceToHclTerraform(struct?: ComputeInstanceNetworkInterface | cdktn.IResolvable): any;
export declare class ComputeInstanceNetworkInterfaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceNetworkInterface | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInstanceNetworkInterface | cdktn.IResolvable | undefined);
    private _enableVpcScopedDns?;
    get enableVpcScopedDns(): boolean | cdktn.IResolvable;
    set enableVpcScopedDns(value: boolean | cdktn.IResolvable);
    resetEnableVpcScopedDns(): void;
    get enableVpcScopedDnsInput(): boolean | cdktn.IResolvable | undefined;
    private _igmpQuery?;
    get igmpQuery(): string;
    set igmpQuery(value: string);
    resetIgmpQuery(): void;
    get igmpQueryInput(): string | undefined;
    private _internalIpv6PrefixLength?;
    get internalIpv6PrefixLength(): number;
    set internalIpv6PrefixLength(value: number);
    resetInternalIpv6PrefixLength(): void;
    get internalIpv6PrefixLengthInput(): number | undefined;
    get ipv6AccessType(): string;
    private _ipv6Address?;
    get ipv6Address(): string;
    set ipv6Address(value: string);
    resetIpv6Address(): void;
    get ipv6AddressInput(): string | undefined;
    get name(): string;
    private _network?;
    get network(): string;
    set network(value: string);
    resetNetwork(): void;
    get networkInput(): string | undefined;
    private _networkAttachment?;
    get networkAttachment(): string;
    set networkAttachment(value: string);
    resetNetworkAttachment(): void;
    get networkAttachmentInput(): string | undefined;
    private _networkIp?;
    get networkIp(): string;
    set networkIp(value: string);
    resetNetworkIp(): void;
    get networkIpInput(): string | undefined;
    private _nicType?;
    get nicType(): string;
    set nicType(value: string);
    resetNicType(): void;
    get nicTypeInput(): string | undefined;
    get parentNicName(): string;
    private _queueCount?;
    get queueCount(): number;
    set queueCount(value: number);
    resetQueueCount(): void;
    get queueCountInput(): number | undefined;
    private _serviceClassId?;
    get serviceClassId(): string;
    set serviceClassId(value: string);
    resetServiceClassId(): void;
    get serviceClassIdInput(): string | undefined;
    private _stackType?;
    get stackType(): string;
    set stackType(value: string);
    resetStackType(): void;
    get stackTypeInput(): string | undefined;
    private _subnetwork?;
    get subnetwork(): string;
    set subnetwork(value: string);
    resetSubnetwork(): void;
    get subnetworkInput(): string | undefined;
    private _subnetworkProject?;
    get subnetworkProject(): string;
    set subnetworkProject(value: string);
    resetSubnetworkProject(): void;
    get subnetworkProjectInput(): string | undefined;
    private _vlan?;
    get vlan(): number;
    set vlan(value: number);
    resetVlan(): void;
    get vlanInput(): number | undefined;
    private _accessConfig;
    get accessConfig(): ComputeInstanceNetworkInterfaceAccessConfigList;
    putAccessConfig(value: ComputeInstanceNetworkInterfaceAccessConfig[] | cdktn.IResolvable): void;
    resetAccessConfig(): void;
    get accessConfigInput(): cdktn.IResolvable | ComputeInstanceNetworkInterfaceAccessConfig[] | undefined;
    private _aliasIpRange;
    get aliasIpRange(): ComputeInstanceNetworkInterfaceAliasIpRangeList;
    putAliasIpRange(value: ComputeInstanceNetworkInterfaceAliasIpRange[] | cdktn.IResolvable): void;
    resetAliasIpRange(): void;
    get aliasIpRangeInput(): cdktn.IResolvable | ComputeInstanceNetworkInterfaceAliasIpRange[] | undefined;
    private _ipv6AccessConfig;
    get ipv6AccessConfig(): ComputeInstanceNetworkInterfaceIpv6AccessConfigList;
    putIpv6AccessConfig(value: ComputeInstanceNetworkInterfaceIpv6AccessConfig[] | cdktn.IResolvable): void;
    resetIpv6AccessConfig(): void;
    get ipv6AccessConfigInput(): cdktn.IResolvable | ComputeInstanceNetworkInterfaceIpv6AccessConfig[] | undefined;
}
export declare class ComputeInstanceNetworkInterfaceList extends cdktn.ComplexList {
    internalValue?: ComputeInstanceNetworkInterface[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceNetworkInterfaceOutputReference;
}
export interface ComputeInstanceNetworkPerformanceConfig {
    /**
    * The egress bandwidth tier to enable. Possible values:TIER_1, DEFAULT
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#total_egress_bandwidth_tier ComputeInstance#total_egress_bandwidth_tier}
    */
    readonly totalEgressBandwidthTier: string;
}
export declare function computeInstanceNetworkPerformanceConfigToTerraform(struct?: ComputeInstanceNetworkPerformanceConfigOutputReference | ComputeInstanceNetworkPerformanceConfig): any;
export declare function computeInstanceNetworkPerformanceConfigToHclTerraform(struct?: ComputeInstanceNetworkPerformanceConfigOutputReference | ComputeInstanceNetworkPerformanceConfig): any;
export declare class ComputeInstanceNetworkPerformanceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceNetworkPerformanceConfig | undefined;
    set internalValue(value: ComputeInstanceNetworkPerformanceConfig | undefined);
    private _totalEgressBandwidthTier?;
    get totalEgressBandwidthTier(): string;
    set totalEgressBandwidthTier(value: string);
    get totalEgressBandwidthTierInput(): string | undefined;
}
export interface ComputeInstanceParams {
    /**
    * A map of resource manager tags. Resource manager tag keys and values have the same definition as resource manager tags. Keys must be in the format tagKeys/{tag_key_id}, and values are in the format tagValues/456. The field is ignored (both PUT & PATCH) when empty.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#resource_manager_tags ComputeInstance#resource_manager_tags}
    */
    readonly resourceManagerTags?: {
        [key: string]: string;
    };
}
export declare function computeInstanceParamsToTerraform(struct?: ComputeInstanceParamsOutputReference | ComputeInstanceParams): any;
export declare function computeInstanceParamsToHclTerraform(struct?: ComputeInstanceParamsOutputReference | ComputeInstanceParams): any;
export declare class ComputeInstanceParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceParams | undefined;
    set internalValue(value: ComputeInstanceParams | undefined);
    private _resourceManagerTags?;
    get resourceManagerTags(): {
        [key: string]: string;
    };
    set resourceManagerTags(value: {
        [key: string]: string;
    });
    resetResourceManagerTags(): void;
    get resourceManagerTagsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ComputeInstanceReservationAffinitySpecificReservation {
    /**
    * Corresponds to the label key of a reservation resource. To target a SPECIFIC_RESERVATION by name, specify compute.googleapis.com/reservation-name as the key and specify the name of your reservation as the only value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#key ComputeInstance#key}
    */
    readonly key: string;
    /**
    * Corresponds to the label values of a reservation resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#values ComputeInstance#values}
    */
    readonly values: string[];
}
export declare function computeInstanceReservationAffinitySpecificReservationToTerraform(struct?: ComputeInstanceReservationAffinitySpecificReservationOutputReference | ComputeInstanceReservationAffinitySpecificReservation): any;
export declare function computeInstanceReservationAffinitySpecificReservationToHclTerraform(struct?: ComputeInstanceReservationAffinitySpecificReservationOutputReference | ComputeInstanceReservationAffinitySpecificReservation): any;
export declare class ComputeInstanceReservationAffinitySpecificReservationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceReservationAffinitySpecificReservation | undefined;
    set internalValue(value: ComputeInstanceReservationAffinitySpecificReservation | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export interface ComputeInstanceReservationAffinity {
    /**
    * The type of reservation from which this instance can consume resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#type ComputeInstance#type}
    */
    readonly type: string;
    /**
    * specific_reservation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#specific_reservation ComputeInstance#specific_reservation}
    */
    readonly specificReservation?: ComputeInstanceReservationAffinitySpecificReservation;
}
export declare function computeInstanceReservationAffinityToTerraform(struct?: ComputeInstanceReservationAffinityOutputReference | ComputeInstanceReservationAffinity): any;
export declare function computeInstanceReservationAffinityToHclTerraform(struct?: ComputeInstanceReservationAffinityOutputReference | ComputeInstanceReservationAffinity): any;
export declare class ComputeInstanceReservationAffinityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceReservationAffinity | undefined;
    set internalValue(value: ComputeInstanceReservationAffinity | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _specificReservation;
    get specificReservation(): ComputeInstanceReservationAffinitySpecificReservationOutputReference;
    putSpecificReservation(value: ComputeInstanceReservationAffinitySpecificReservation): void;
    resetSpecificReservation(): void;
    get specificReservationInput(): ComputeInstanceReservationAffinitySpecificReservation | undefined;
}
export interface ComputeInstanceSchedulingLocalSsdRecoveryTimeout {
    /**
    * Span of time that's a fraction of a second at nanosecond
    * resolution. Durations less than one second are represented
    * with a 0 seconds field and a positive nanos field. Must
    * be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#nanos ComputeInstance#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second.
    * Must be from 0 to 315,576,000,000 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#seconds ComputeInstance#seconds}
    */
    readonly seconds: number;
}
export declare function computeInstanceSchedulingLocalSsdRecoveryTimeoutToTerraform(struct?: ComputeInstanceSchedulingLocalSsdRecoveryTimeoutOutputReference | ComputeInstanceSchedulingLocalSsdRecoveryTimeout): any;
export declare function computeInstanceSchedulingLocalSsdRecoveryTimeoutToHclTerraform(struct?: ComputeInstanceSchedulingLocalSsdRecoveryTimeoutOutputReference | ComputeInstanceSchedulingLocalSsdRecoveryTimeout): any;
export declare class ComputeInstanceSchedulingLocalSsdRecoveryTimeoutOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceSchedulingLocalSsdRecoveryTimeout | undefined;
    set internalValue(value: ComputeInstanceSchedulingLocalSsdRecoveryTimeout | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): number;
    set seconds(value: number);
    get secondsInput(): number | undefined;
}
export interface ComputeInstanceSchedulingMaxRunDuration {
    /**
    * Span of time that's a fraction of a second at nanosecond
    * resolution. Durations less than one second are represented
    * with a 0 seconds field and a positive nanos field. Must
    * be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#nanos ComputeInstance#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second.
    * Must be from 0 to 315,576,000,000 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#seconds ComputeInstance#seconds}
    */
    readonly seconds: number;
}
export declare function computeInstanceSchedulingMaxRunDurationToTerraform(struct?: ComputeInstanceSchedulingMaxRunDurationOutputReference | ComputeInstanceSchedulingMaxRunDuration): any;
export declare function computeInstanceSchedulingMaxRunDurationToHclTerraform(struct?: ComputeInstanceSchedulingMaxRunDurationOutputReference | ComputeInstanceSchedulingMaxRunDuration): any;
export declare class ComputeInstanceSchedulingMaxRunDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceSchedulingMaxRunDuration | undefined;
    set internalValue(value: ComputeInstanceSchedulingMaxRunDuration | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): number;
    set seconds(value: number);
    get secondsInput(): number | undefined;
}
export interface ComputeInstanceSchedulingNodeAffinities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#key ComputeInstance#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#operator ComputeInstance#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#values ComputeInstance#values}
    */
    readonly values: string[];
}
export declare function computeInstanceSchedulingNodeAffinitiesToTerraform(struct?: ComputeInstanceSchedulingNodeAffinities | cdktn.IResolvable): any;
export declare function computeInstanceSchedulingNodeAffinitiesToHclTerraform(struct?: ComputeInstanceSchedulingNodeAffinities | cdktn.IResolvable): any;
export declare class ComputeInstanceSchedulingNodeAffinitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceSchedulingNodeAffinities | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInstanceSchedulingNodeAffinities | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class ComputeInstanceSchedulingNodeAffinitiesList extends cdktn.ComplexList {
    internalValue?: ComputeInstanceSchedulingNodeAffinities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceSchedulingNodeAffinitiesOutputReference;
}
export interface ComputeInstanceSchedulingOnInstanceStopAction {
    /**
    * If true, the contents of any attached Local SSD disks will be discarded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#discard_local_ssd ComputeInstance#discard_local_ssd}
    */
    readonly discardLocalSsd?: boolean | cdktn.IResolvable;
}
export declare function computeInstanceSchedulingOnInstanceStopActionToTerraform(struct?: ComputeInstanceSchedulingOnInstanceStopActionOutputReference | ComputeInstanceSchedulingOnInstanceStopAction): any;
export declare function computeInstanceSchedulingOnInstanceStopActionToHclTerraform(struct?: ComputeInstanceSchedulingOnInstanceStopActionOutputReference | ComputeInstanceSchedulingOnInstanceStopAction): any;
export declare class ComputeInstanceSchedulingOnInstanceStopActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceSchedulingOnInstanceStopAction | undefined;
    set internalValue(value: ComputeInstanceSchedulingOnInstanceStopAction | undefined);
    private _discardLocalSsd?;
    get discardLocalSsd(): boolean | cdktn.IResolvable;
    set discardLocalSsd(value: boolean | cdktn.IResolvable);
    resetDiscardLocalSsd(): void;
    get discardLocalSsdInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ComputeInstanceSchedulingPreemptionNoticeDuration {
    /**
    * Span of time that's a fraction of a second at nanosecond resolution. Durations less than one second are represented with a 0 seconds field and a positive nanos field. Must be from 0 to 999,999,999 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#nanos ComputeInstance#nanos}
    */
    readonly nanos?: number;
    /**
    * Span of time at a resolution of a second. Must be from 0 to 315,576,000,000 inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#seconds ComputeInstance#seconds}
    */
    readonly seconds: number;
}
export declare function computeInstanceSchedulingPreemptionNoticeDurationToTerraform(struct?: ComputeInstanceSchedulingPreemptionNoticeDurationOutputReference | ComputeInstanceSchedulingPreemptionNoticeDuration): any;
export declare function computeInstanceSchedulingPreemptionNoticeDurationToHclTerraform(struct?: ComputeInstanceSchedulingPreemptionNoticeDurationOutputReference | ComputeInstanceSchedulingPreemptionNoticeDuration): any;
export declare class ComputeInstanceSchedulingPreemptionNoticeDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceSchedulingPreemptionNoticeDuration | undefined;
    set internalValue(value: ComputeInstanceSchedulingPreemptionNoticeDuration | undefined);
    private _nanos?;
    get nanos(): number;
    set nanos(value: number);
    resetNanos(): void;
    get nanosInput(): number | undefined;
    private _seconds?;
    get seconds(): number;
    set seconds(value: number);
    get secondsInput(): number | undefined;
}
export interface ComputeInstanceScheduling {
    /**
    * Specifies if the instance should be restarted if it was terminated by Compute Engine (not a user).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#automatic_restart ComputeInstance#automatic_restart}
    */
    readonly automaticRestart?: boolean | cdktn.IResolvable;
    /**
    * Specifies the availability domain, which this instance should be scheduled on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#availability_domain ComputeInstance#availability_domain}
    */
    readonly availabilityDomain?: number;
    /**
    * Specify the time in seconds for host error detection, the value must be within the range of [90, 330] with the increment of 30, if unset, the default behavior of host error recovery will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#host_error_timeout_seconds ComputeInstance#host_error_timeout_seconds}
    */
    readonly hostErrorTimeoutSeconds?: number;
    /**
    * Specifies the action GCE should take when SPOT VM is preempted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#instance_termination_action ComputeInstance#instance_termination_action}
    */
    readonly instanceTerminationAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#min_node_cpus ComputeInstance#min_node_cpus}
    */
    readonly minNodeCpus?: number;
    /**
    * Describes maintenance behavior for the instance. One of MIGRATE or TERMINATE,
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#on_host_maintenance ComputeInstance#on_host_maintenance}
    */
    readonly onHostMaintenance?: string;
    /**
    * Whether the instance is preemptible.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#preemptible ComputeInstance#preemptible}
    */
    readonly preemptible?: boolean | cdktn.IResolvable;
    /**
    * Describes the desired provisioning model for the instance. Possible values are STANDARD, SPOT, FLEX_START, and RESERVATION_BOUND. For STANDARD, resources are provisioned immediately. For SPOT, resources are offered at a discount compared to standard pricing but may be preempted. For FLEX_START, resources are offered at a discount with flexible start times. For RESERVATION_BOUND, the instance is bound to a specific reservation and will only consume capacity from that reservation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#provisioning_model ComputeInstance#provisioning_model}
    */
    readonly provisioningModel?: string;
    /**
    * Specifies the timestamp, when the instance will be terminated,
    * in RFC3339 text format. If specified, the instance termination action
    * will be performed at the termination time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#termination_time ComputeInstance#termination_time}
    */
    readonly terminationTime?: string;
    /**
    * local_ssd_recovery_timeout block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#local_ssd_recovery_timeout ComputeInstance#local_ssd_recovery_timeout}
    */
    readonly localSsdRecoveryTimeout?: ComputeInstanceSchedulingLocalSsdRecoveryTimeout;
    /**
    * max_run_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#max_run_duration ComputeInstance#max_run_duration}
    */
    readonly maxRunDuration?: ComputeInstanceSchedulingMaxRunDuration;
    /**
    * node_affinities block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#node_affinities ComputeInstance#node_affinities}
    */
    readonly nodeAffinities?: ComputeInstanceSchedulingNodeAffinities[] | cdktn.IResolvable;
    /**
    * on_instance_stop_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#on_instance_stop_action ComputeInstance#on_instance_stop_action}
    */
    readonly onInstanceStopAction?: ComputeInstanceSchedulingOnInstanceStopAction;
    /**
    * preemption_notice_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#preemption_notice_duration ComputeInstance#preemption_notice_duration}
    */
    readonly preemptionNoticeDuration?: ComputeInstanceSchedulingPreemptionNoticeDuration;
}
export declare function computeInstanceSchedulingToTerraform(struct?: ComputeInstanceSchedulingOutputReference | ComputeInstanceScheduling): any;
export declare function computeInstanceSchedulingToHclTerraform(struct?: ComputeInstanceSchedulingOutputReference | ComputeInstanceScheduling): any;
export declare class ComputeInstanceSchedulingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceScheduling | undefined;
    set internalValue(value: ComputeInstanceScheduling | undefined);
    private _automaticRestart?;
    get automaticRestart(): boolean | cdktn.IResolvable;
    set automaticRestart(value: boolean | cdktn.IResolvable);
    resetAutomaticRestart(): void;
    get automaticRestartInput(): boolean | cdktn.IResolvable | undefined;
    private _availabilityDomain?;
    get availabilityDomain(): number;
    set availabilityDomain(value: number);
    resetAvailabilityDomain(): void;
    get availabilityDomainInput(): number | undefined;
    private _hostErrorTimeoutSeconds?;
    get hostErrorTimeoutSeconds(): number;
    set hostErrorTimeoutSeconds(value: number);
    resetHostErrorTimeoutSeconds(): void;
    get hostErrorTimeoutSecondsInput(): number | undefined;
    private _instanceTerminationAction?;
    get instanceTerminationAction(): string;
    set instanceTerminationAction(value: string);
    resetInstanceTerminationAction(): void;
    get instanceTerminationActionInput(): string | undefined;
    private _minNodeCpus?;
    get minNodeCpus(): number;
    set minNodeCpus(value: number);
    resetMinNodeCpus(): void;
    get minNodeCpusInput(): number | undefined;
    private _onHostMaintenance?;
    get onHostMaintenance(): string;
    set onHostMaintenance(value: string);
    resetOnHostMaintenance(): void;
    get onHostMaintenanceInput(): string | undefined;
    private _preemptible?;
    get preemptible(): boolean | cdktn.IResolvable;
    set preemptible(value: boolean | cdktn.IResolvable);
    resetPreemptible(): void;
    get preemptibleInput(): boolean | cdktn.IResolvable | undefined;
    private _provisioningModel?;
    get provisioningModel(): string;
    set provisioningModel(value: string);
    resetProvisioningModel(): void;
    get provisioningModelInput(): string | undefined;
    private _terminationTime?;
    get terminationTime(): string;
    set terminationTime(value: string);
    resetTerminationTime(): void;
    get terminationTimeInput(): string | undefined;
    private _localSsdRecoveryTimeout;
    get localSsdRecoveryTimeout(): ComputeInstanceSchedulingLocalSsdRecoveryTimeoutOutputReference;
    putLocalSsdRecoveryTimeout(value: ComputeInstanceSchedulingLocalSsdRecoveryTimeout): void;
    resetLocalSsdRecoveryTimeout(): void;
    get localSsdRecoveryTimeoutInput(): ComputeInstanceSchedulingLocalSsdRecoveryTimeout | undefined;
    private _maxRunDuration;
    get maxRunDuration(): ComputeInstanceSchedulingMaxRunDurationOutputReference;
    putMaxRunDuration(value: ComputeInstanceSchedulingMaxRunDuration): void;
    resetMaxRunDuration(): void;
    get maxRunDurationInput(): ComputeInstanceSchedulingMaxRunDuration | undefined;
    private _nodeAffinities;
    get nodeAffinities(): ComputeInstanceSchedulingNodeAffinitiesList;
    putNodeAffinities(value: ComputeInstanceSchedulingNodeAffinities[] | cdktn.IResolvable): void;
    resetNodeAffinities(): void;
    get nodeAffinitiesInput(): cdktn.IResolvable | ComputeInstanceSchedulingNodeAffinities[] | undefined;
    private _onInstanceStopAction;
    get onInstanceStopAction(): ComputeInstanceSchedulingOnInstanceStopActionOutputReference;
    putOnInstanceStopAction(value: ComputeInstanceSchedulingOnInstanceStopAction): void;
    resetOnInstanceStopAction(): void;
    get onInstanceStopActionInput(): ComputeInstanceSchedulingOnInstanceStopAction | undefined;
    private _preemptionNoticeDuration;
    get preemptionNoticeDuration(): ComputeInstanceSchedulingPreemptionNoticeDurationOutputReference;
    putPreemptionNoticeDuration(value: ComputeInstanceSchedulingPreemptionNoticeDuration): void;
    resetPreemptionNoticeDuration(): void;
    get preemptionNoticeDurationInput(): ComputeInstanceSchedulingPreemptionNoticeDuration | undefined;
}
export interface ComputeInstanceScratchDisk {
    /**
    * Name with which the attached disk is accessible under /dev/disk/by-id/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#device_name ComputeInstance#device_name}
    */
    readonly deviceName?: string;
    /**
    * The disk interface used for attaching this disk. One of SCSI or NVME.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#interface ComputeInstance#interface}
    */
    readonly interface: string;
    /**
    * The size of the disk in gigabytes. One of 375 or 3000.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#size ComputeInstance#size}
    */
    readonly size?: number;
}
export declare function computeInstanceScratchDiskToTerraform(struct?: ComputeInstanceScratchDisk | cdktn.IResolvable): any;
export declare function computeInstanceScratchDiskToHclTerraform(struct?: ComputeInstanceScratchDisk | cdktn.IResolvable): any;
export declare class ComputeInstanceScratchDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceScratchDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInstanceScratchDisk | cdktn.IResolvable | undefined);
    private _deviceName?;
    get deviceName(): string;
    set deviceName(value: string);
    resetDeviceName(): void;
    get deviceNameInput(): string | undefined;
    private _interface?;
    get interface(): string;
    set interface(value: string);
    get interfaceInput(): string | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    resetSize(): void;
    get sizeInput(): number | undefined;
}
export declare class ComputeInstanceScratchDiskList extends cdktn.ComplexList {
    internalValue?: ComputeInstanceScratchDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceScratchDiskOutputReference;
}
export interface ComputeInstanceServiceAccount {
    /**
    * The service account e-mail address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#email ComputeInstance#email}
    */
    readonly email?: string;
    /**
    * A list of service scopes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#scopes ComputeInstance#scopes}
    */
    readonly scopes: string[];
}
export declare function computeInstanceServiceAccountToTerraform(struct?: ComputeInstanceServiceAccountOutputReference | ComputeInstanceServiceAccount): any;
export declare function computeInstanceServiceAccountToHclTerraform(struct?: ComputeInstanceServiceAccountOutputReference | ComputeInstanceServiceAccount): any;
export declare class ComputeInstanceServiceAccountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceServiceAccount | undefined;
    set internalValue(value: ComputeInstanceServiceAccount | undefined);
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    get scopesInput(): string[] | undefined;
}
export interface ComputeInstanceShieldedInstanceConfig {
    /**
    * Whether integrity monitoring is enabled for the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#enable_integrity_monitoring ComputeInstance#enable_integrity_monitoring}
    */
    readonly enableIntegrityMonitoring?: boolean | cdktn.IResolvable;
    /**
    * Whether secure boot is enabled for the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#enable_secure_boot ComputeInstance#enable_secure_boot}
    */
    readonly enableSecureBoot?: boolean | cdktn.IResolvable;
    /**
    * Whether the instance uses vTPM.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#enable_vtpm ComputeInstance#enable_vtpm}
    */
    readonly enableVtpm?: boolean | cdktn.IResolvable;
}
export declare function computeInstanceShieldedInstanceConfigToTerraform(struct?: ComputeInstanceShieldedInstanceConfigOutputReference | ComputeInstanceShieldedInstanceConfig): any;
export declare function computeInstanceShieldedInstanceConfigToHclTerraform(struct?: ComputeInstanceShieldedInstanceConfigOutputReference | ComputeInstanceShieldedInstanceConfig): any;
export declare class ComputeInstanceShieldedInstanceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceShieldedInstanceConfig | undefined;
    set internalValue(value: ComputeInstanceShieldedInstanceConfig | undefined);
    private _enableIntegrityMonitoring?;
    get enableIntegrityMonitoring(): boolean | cdktn.IResolvable;
    set enableIntegrityMonitoring(value: boolean | cdktn.IResolvable);
    resetEnableIntegrityMonitoring(): void;
    get enableIntegrityMonitoringInput(): boolean | cdktn.IResolvable | undefined;
    private _enableSecureBoot?;
    get enableSecureBoot(): boolean | cdktn.IResolvable;
    set enableSecureBoot(value: boolean | cdktn.IResolvable);
    resetEnableSecureBoot(): void;
    get enableSecureBootInput(): boolean | cdktn.IResolvable | undefined;
    private _enableVtpm?;
    get enableVtpm(): boolean | cdktn.IResolvable;
    set enableVtpm(value: boolean | cdktn.IResolvable);
    resetEnableVtpm(): void;
    get enableVtpmInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ComputeInstanceTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#create ComputeInstance#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#delete ComputeInstance#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#update ComputeInstance#update}
    */
    readonly update?: string;
}
export declare function computeInstanceTimeoutsToTerraform(struct?: ComputeInstanceTimeouts | cdktn.IResolvable): any;
export declare function computeInstanceTimeoutsToHclTerraform(struct?: ComputeInstanceTimeouts | cdktn.IResolvable): any;
export declare class ComputeInstanceTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInstanceTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface ComputeInstanceWorkloadIdentityConfig {
    /**
    * Identity SPIFFE id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#identity ComputeInstance#identity}
    */
    readonly identity?: string;
    /**
    * Specifies whether identity certificates are enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#identity_certificate_enabled ComputeInstance#identity_certificate_enabled}
    */
    readonly identityCertificateEnabled?: boolean | cdktn.IResolvable;
}
export declare function computeInstanceWorkloadIdentityConfigToTerraform(struct?: ComputeInstanceWorkloadIdentityConfigOutputReference | ComputeInstanceWorkloadIdentityConfig): any;
export declare function computeInstanceWorkloadIdentityConfigToHclTerraform(struct?: ComputeInstanceWorkloadIdentityConfigOutputReference | ComputeInstanceWorkloadIdentityConfig): any;
export declare class ComputeInstanceWorkloadIdentityConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceWorkloadIdentityConfig | undefined;
    set internalValue(value: ComputeInstanceWorkloadIdentityConfig | undefined);
    private _identity?;
    get identity(): string;
    set identity(value: string);
    resetIdentity(): void;
    get identityInput(): string | undefined;
    private _identityCertificateEnabled?;
    get identityCertificateEnabled(): boolean | cdktn.IResolvable;
    set identityCertificateEnabled(value: boolean | cdktn.IResolvable);
    resetIdentityCertificateEnabled(): void;
    get identityCertificateEnabledInput(): boolean | cdktn.IResolvable | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance google_compute_instance}
*/
export declare class ComputeInstance extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_instance";
    /**
    * Generates CDKTN code for importing a ComputeInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeInstance to import
    * @param importFromId The id of the existing ComputeInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_instance google_compute_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeInstanceConfig
    */
    constructor(scope: Construct, id: string, config: ComputeInstanceConfig);
    private _allowStoppingForUpdate?;
    get allowStoppingForUpdate(): boolean | cdktn.IResolvable;
    set allowStoppingForUpdate(value: boolean | cdktn.IResolvable);
    resetAllowStoppingForUpdate(): void;
    get allowStoppingForUpdateInput(): boolean | cdktn.IResolvable | undefined;
    private _canIpForward?;
    get canIpForward(): boolean | cdktn.IResolvable;
    set canIpForward(value: boolean | cdktn.IResolvable);
    resetCanIpForward(): void;
    get canIpForwardInput(): boolean | cdktn.IResolvable | undefined;
    get cpuPlatform(): string;
    get creationTimestamp(): string;
    get currentStatus(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _deletionProtection?;
    get deletionProtection(): boolean | cdktn.IResolvable;
    set deletionProtection(value: boolean | cdktn.IResolvable);
    resetDeletionProtection(): void;
    get deletionProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _desiredStatus?;
    get desiredStatus(): string;
    set desiredStatus(value: string);
    resetDesiredStatus(): void;
    get desiredStatusInput(): string | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _enableDisplay?;
    get enableDisplay(): boolean | cdktn.IResolvable;
    set enableDisplay(value: boolean | cdktn.IResolvable);
    resetEnableDisplay(): void;
    get enableDisplayInput(): boolean | cdktn.IResolvable | undefined;
    private _hostname?;
    get hostname(): string;
    set hostname(value: string);
    resetHostname(): void;
    get hostnameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get instanceId(): string;
    private _keyRevocationActionType?;
    get keyRevocationActionType(): string;
    set keyRevocationActionType(value: string);
    resetKeyRevocationActionType(): void;
    get keyRevocationActionTypeInput(): string | undefined;
    get labelFingerprint(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _machineType?;
    get machineType(): string;
    set machineType(value: string);
    get machineTypeInput(): string | undefined;
    private _metadata?;
    get metadata(): {
        [key: string]: string;
    };
    set metadata(value: {
        [key: string]: string;
    });
    resetMetadata(): void;
    get metadataInput(): {
        [key: string]: string;
    } | undefined;
    get metadataFingerprint(): string;
    private _metadataStartupScript?;
    get metadataStartupScript(): string;
    set metadataStartupScript(value: string);
    resetMetadataStartupScript(): void;
    get metadataStartupScriptInput(): string | undefined;
    private _minCpuPlatform?;
    get minCpuPlatform(): string;
    set minCpuPlatform(value: string);
    resetMinCpuPlatform(): void;
    get minCpuPlatformInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _resourcePolicies?;
    get resourcePolicies(): string[];
    set resourcePolicies(value: string[]);
    resetResourcePolicies(): void;
    get resourcePoliciesInput(): string[] | undefined;
    get selfLink(): string;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    get tagsFingerprint(): string;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    resetZone(): void;
    get zoneInput(): string | undefined;
    private _advancedMachineFeatures;
    get advancedMachineFeatures(): ComputeInstanceAdvancedMachineFeaturesOutputReference;
    putAdvancedMachineFeatures(value: ComputeInstanceAdvancedMachineFeatures): void;
    resetAdvancedMachineFeatures(): void;
    get advancedMachineFeaturesInput(): ComputeInstanceAdvancedMachineFeatures | undefined;
    private _attachedDisk;
    get attachedDisk(): ComputeInstanceAttachedDiskList;
    putAttachedDisk(value: ComputeInstanceAttachedDisk[] | cdktn.IResolvable): void;
    resetAttachedDisk(): void;
    get attachedDiskInput(): cdktn.IResolvable | ComputeInstanceAttachedDisk[] | undefined;
    private _bootDisk;
    get bootDisk(): ComputeInstanceBootDiskOutputReference;
    putBootDisk(value: ComputeInstanceBootDisk): void;
    get bootDiskInput(): ComputeInstanceBootDisk | undefined;
    private _confidentialInstanceConfig;
    get confidentialInstanceConfig(): ComputeInstanceConfidentialInstanceConfigOutputReference;
    putConfidentialInstanceConfig(value: ComputeInstanceConfidentialInstanceConfig): void;
    resetConfidentialInstanceConfig(): void;
    get confidentialInstanceConfigInput(): ComputeInstanceConfidentialInstanceConfig | undefined;
    private _guestAccelerator;
    get guestAccelerator(): ComputeInstanceGuestAcceleratorList;
    putGuestAccelerator(value: ComputeInstanceGuestAccelerator[] | cdktn.IResolvable): void;
    resetGuestAccelerator(): void;
    get guestAcceleratorInput(): cdktn.IResolvable | ComputeInstanceGuestAccelerator[] | undefined;
    private _instanceEncryptionKey;
    get instanceEncryptionKey(): ComputeInstanceInstanceEncryptionKeyOutputReference;
    putInstanceEncryptionKey(value: ComputeInstanceInstanceEncryptionKey): void;
    resetInstanceEncryptionKey(): void;
    get instanceEncryptionKeyInput(): ComputeInstanceInstanceEncryptionKey | undefined;
    private _networkInterface;
    get networkInterface(): ComputeInstanceNetworkInterfaceList;
    putNetworkInterface(value: ComputeInstanceNetworkInterface[] | cdktn.IResolvable): void;
    get networkInterfaceInput(): cdktn.IResolvable | ComputeInstanceNetworkInterface[] | undefined;
    private _networkPerformanceConfig;
    get networkPerformanceConfig(): ComputeInstanceNetworkPerformanceConfigOutputReference;
    putNetworkPerformanceConfig(value: ComputeInstanceNetworkPerformanceConfig): void;
    resetNetworkPerformanceConfig(): void;
    get networkPerformanceConfigInput(): ComputeInstanceNetworkPerformanceConfig | undefined;
    private _params;
    get params(): ComputeInstanceParamsOutputReference;
    putParams(value: ComputeInstanceParams): void;
    resetParams(): void;
    get paramsInput(): ComputeInstanceParams | undefined;
    private _reservationAffinity;
    get reservationAffinity(): ComputeInstanceReservationAffinityOutputReference;
    putReservationAffinity(value: ComputeInstanceReservationAffinity): void;
    resetReservationAffinity(): void;
    get reservationAffinityInput(): ComputeInstanceReservationAffinity | undefined;
    private _scheduling;
    get scheduling(): ComputeInstanceSchedulingOutputReference;
    putScheduling(value: ComputeInstanceScheduling): void;
    resetScheduling(): void;
    get schedulingInput(): ComputeInstanceScheduling | undefined;
    private _scratchDisk;
    get scratchDisk(): ComputeInstanceScratchDiskList;
    putScratchDisk(value: ComputeInstanceScratchDisk[] | cdktn.IResolvable): void;
    resetScratchDisk(): void;
    get scratchDiskInput(): cdktn.IResolvable | ComputeInstanceScratchDisk[] | undefined;
    private _serviceAccount;
    get serviceAccount(): ComputeInstanceServiceAccountOutputReference;
    putServiceAccount(value: ComputeInstanceServiceAccount): void;
    resetServiceAccount(): void;
    get serviceAccountInput(): ComputeInstanceServiceAccount | undefined;
    private _shieldedInstanceConfig;
    get shieldedInstanceConfig(): ComputeInstanceShieldedInstanceConfigOutputReference;
    putShieldedInstanceConfig(value: ComputeInstanceShieldedInstanceConfig): void;
    resetShieldedInstanceConfig(): void;
    get shieldedInstanceConfigInput(): ComputeInstanceShieldedInstanceConfig | undefined;
    private _timeouts;
    get timeouts(): ComputeInstanceTimeoutsOutputReference;
    putTimeouts(value: ComputeInstanceTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeInstanceTimeouts | undefined;
    private _workloadIdentityConfig;
    get workloadIdentityConfig(): ComputeInstanceWorkloadIdentityConfigOutputReference;
    putWorkloadIdentityConfig(value: ComputeInstanceWorkloadIdentityConfig): void;
    resetWorkloadIdentityConfig(): void;
    get workloadIdentityConfigInput(): ComputeInstanceWorkloadIdentityConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
