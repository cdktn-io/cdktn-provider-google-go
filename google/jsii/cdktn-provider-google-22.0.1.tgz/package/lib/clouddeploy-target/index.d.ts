/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ClouddeployTargetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Optional. User annotations. These attributes can only be set and used by the user, and not by Google Cloud Deploy. See https://google.aip.dev/128#annotations for more details such as format and size limitations.
    *
    * **Note**: This field is non-authoritative, and will only manage the annotations present in your configuration.
    * Please refer to the field `effective_annotations` for all of the annotations present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#annotations ClouddeployTarget#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#deletion_policy ClouddeployTarget#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Optional. The deploy parameters to use for this target.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#deploy_parameters ClouddeployTarget#deploy_parameters}
    */
    readonly deployParameters?: {
        [key: string]: string;
    };
    /**
    * Optional. Description of the `Target`. Max length is 255 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#description ClouddeployTarget#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#id ClouddeployTarget#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Optional. Labels are attributes that can be set and used by both the user and by Google Cloud Deploy. Labels must meet the following constraints: * Keys and values can contain only lowercase letters, numeric characters, underscores, and dashes. * All characters must use UTF-8 encoding, and international characters are allowed. * Keys must start with a lowercase letter or international character. * Each resource is limited to a maximum of 64 labels. Both keys and values are additionally constrained to be <= 128 bytes.
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field `effective_labels` for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#labels ClouddeployTarget#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The location for the resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#location ClouddeployTarget#location}
    */
    readonly location: string;
    /**
    * Name of the `Target`. Format is `[a-z]([a-z0-9-]{0,61}[a-z0-9])?`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#name ClouddeployTarget#name}
    */
    readonly name: string;
    /**
    * The project for the resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#project ClouddeployTarget#project}
    */
    readonly project?: string;
    /**
    * Optional. Whether or not the `Target` requires approval.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#require_approval ClouddeployTarget#require_approval}
    */
    readonly requireApproval?: boolean | cdktn.IResolvable;
    /**
    * anthos_cluster block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#anthos_cluster ClouddeployTarget#anthos_cluster}
    */
    readonly anthosCluster?: ClouddeployTargetAnthosCluster;
    /**
    * associated_entities block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#associated_entities ClouddeployTarget#associated_entities}
    */
    readonly associatedEntities?: ClouddeployTargetAssociatedEntities[] | cdktn.IResolvable;
    /**
    * custom_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#custom_target ClouddeployTarget#custom_target}
    */
    readonly customTarget?: ClouddeployTargetCustomTarget;
    /**
    * execution_configs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#execution_configs ClouddeployTarget#execution_configs}
    */
    readonly executionConfigs?: ClouddeployTargetExecutionConfigs[] | cdktn.IResolvable;
    /**
    * gke block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#gke ClouddeployTarget#gke}
    */
    readonly gke?: ClouddeployTargetGke;
    /**
    * multi_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#multi_target ClouddeployTarget#multi_target}
    */
    readonly multiTarget?: ClouddeployTargetMultiTarget;
    /**
    * run block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#run ClouddeployTarget#run}
    */
    readonly run?: ClouddeployTargetRun;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#timeouts ClouddeployTarget#timeouts}
    */
    readonly timeouts?: ClouddeployTargetTimeouts;
}
export interface ClouddeployTargetAnthosCluster {
    /**
    * Membership of the GKE Hub-registered cluster to which to apply the Skaffold configuration. Format is `projects/{project}/locations/{location}/memberships/{membership_name}`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#membership ClouddeployTarget#membership}
    */
    readonly membership?: string;
}
export declare function clouddeployTargetAnthosClusterToTerraform(struct?: ClouddeployTargetAnthosClusterOutputReference | ClouddeployTargetAnthosCluster): any;
export declare function clouddeployTargetAnthosClusterToHclTerraform(struct?: ClouddeployTargetAnthosClusterOutputReference | ClouddeployTargetAnthosCluster): any;
export declare class ClouddeployTargetAnthosClusterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddeployTargetAnthosCluster | undefined;
    set internalValue(value: ClouddeployTargetAnthosCluster | undefined);
    private _membership?;
    get membership(): string;
    set membership(value: string);
    resetMembership(): void;
    get membershipInput(): string | undefined;
}
export interface ClouddeployTargetAssociatedEntitiesAnthosClusters {
    /**
    * Optional. Membership of the GKE Hub-registered cluster to which to apply the Skaffold configuration. Format is `projects/{project}/locations/{location}/memberships/{membership_name}`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#membership ClouddeployTarget#membership}
    */
    readonly membership?: string;
}
export declare function clouddeployTargetAssociatedEntitiesAnthosClustersToTerraform(struct?: ClouddeployTargetAssociatedEntitiesAnthosClusters | cdktn.IResolvable): any;
export declare function clouddeployTargetAssociatedEntitiesAnthosClustersToHclTerraform(struct?: ClouddeployTargetAssociatedEntitiesAnthosClusters | cdktn.IResolvable): any;
export declare class ClouddeployTargetAssociatedEntitiesAnthosClustersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ClouddeployTargetAssociatedEntitiesAnthosClusters | cdktn.IResolvable | undefined;
    set internalValue(value: ClouddeployTargetAssociatedEntitiesAnthosClusters | cdktn.IResolvable | undefined);
    private _membership?;
    get membership(): string;
    set membership(value: string);
    resetMembership(): void;
    get membershipInput(): string | undefined;
}
export declare class ClouddeployTargetAssociatedEntitiesAnthosClustersList extends cdktn.ComplexList {
    internalValue?: ClouddeployTargetAssociatedEntitiesAnthosClusters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ClouddeployTargetAssociatedEntitiesAnthosClustersOutputReference;
}
export interface ClouddeployTargetAssociatedEntitiesGkeClusters {
    /**
    * Optional. Information specifying a GKE Cluster. Format is `projects/{project_id}/locations/{location_id}/clusters/{cluster_id}`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#cluster ClouddeployTarget#cluster}
    */
    readonly cluster?: string;
    /**
    * Optional. If true, `cluster` is accessed using the private IP address of the control plane endpoint. Otherwise, the default IP address of the control plane endpoint is used. The default IP address is the private IP address for clusters with private control-plane endpoints and the public IP address otherwise. Only specify this option when `cluster` is a [private GKE cluster](https://cloud.google.com/kubernetes-engine/docs/concepts/private-cluster-concept).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#internal_ip ClouddeployTarget#internal_ip}
    */
    readonly internalIp?: boolean | cdktn.IResolvable;
    /**
    * Optional. If set, used to configure a [proxy](https://kubernetes.io/docs/concepts/configuration/organize-cluster-access-kubeconfig/#proxy) to the Kubernetes server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#proxy_url ClouddeployTarget#proxy_url}
    */
    readonly proxyUrl?: string;
}
export declare function clouddeployTargetAssociatedEntitiesGkeClustersToTerraform(struct?: ClouddeployTargetAssociatedEntitiesGkeClusters | cdktn.IResolvable): any;
export declare function clouddeployTargetAssociatedEntitiesGkeClustersToHclTerraform(struct?: ClouddeployTargetAssociatedEntitiesGkeClusters | cdktn.IResolvable): any;
export declare class ClouddeployTargetAssociatedEntitiesGkeClustersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ClouddeployTargetAssociatedEntitiesGkeClusters | cdktn.IResolvable | undefined;
    set internalValue(value: ClouddeployTargetAssociatedEntitiesGkeClusters | cdktn.IResolvable | undefined);
    private _cluster?;
    get cluster(): string;
    set cluster(value: string);
    resetCluster(): void;
    get clusterInput(): string | undefined;
    private _internalIp?;
    get internalIp(): boolean | cdktn.IResolvable;
    set internalIp(value: boolean | cdktn.IResolvable);
    resetInternalIp(): void;
    get internalIpInput(): boolean | cdktn.IResolvable | undefined;
    private _proxyUrl?;
    get proxyUrl(): string;
    set proxyUrl(value: string);
    resetProxyUrl(): void;
    get proxyUrlInput(): string | undefined;
}
export declare class ClouddeployTargetAssociatedEntitiesGkeClustersList extends cdktn.ComplexList {
    internalValue?: ClouddeployTargetAssociatedEntitiesGkeClusters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ClouddeployTargetAssociatedEntitiesGkeClustersOutputReference;
}
export interface ClouddeployTargetAssociatedEntities {
    /**
    * The name for the key in the map for which this object is mapped to in the API
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#entity_id ClouddeployTarget#entity_id}
    */
    readonly entityId: string;
    /**
    * anthos_clusters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#anthos_clusters ClouddeployTarget#anthos_clusters}
    */
    readonly anthosClusters?: ClouddeployTargetAssociatedEntitiesAnthosClusters[] | cdktn.IResolvable;
    /**
    * gke_clusters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#gke_clusters ClouddeployTarget#gke_clusters}
    */
    readonly gkeClusters?: ClouddeployTargetAssociatedEntitiesGkeClusters[] | cdktn.IResolvable;
}
export declare function clouddeployTargetAssociatedEntitiesToTerraform(struct?: ClouddeployTargetAssociatedEntities | cdktn.IResolvable): any;
export declare function clouddeployTargetAssociatedEntitiesToHclTerraform(struct?: ClouddeployTargetAssociatedEntities | cdktn.IResolvable): any;
export declare class ClouddeployTargetAssociatedEntitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ClouddeployTargetAssociatedEntities | cdktn.IResolvable | undefined;
    set internalValue(value: ClouddeployTargetAssociatedEntities | cdktn.IResolvable | undefined);
    private _entityId?;
    get entityId(): string;
    set entityId(value: string);
    get entityIdInput(): string | undefined;
    private _anthosClusters;
    get anthosClusters(): ClouddeployTargetAssociatedEntitiesAnthosClustersList;
    putAnthosClusters(value: ClouddeployTargetAssociatedEntitiesAnthosClusters[] | cdktn.IResolvable): void;
    resetAnthosClusters(): void;
    get anthosClustersInput(): cdktn.IResolvable | ClouddeployTargetAssociatedEntitiesAnthosClusters[] | undefined;
    private _gkeClusters;
    get gkeClusters(): ClouddeployTargetAssociatedEntitiesGkeClustersList;
    putGkeClusters(value: ClouddeployTargetAssociatedEntitiesGkeClusters[] | cdktn.IResolvable): void;
    resetGkeClusters(): void;
    get gkeClustersInput(): cdktn.IResolvable | ClouddeployTargetAssociatedEntitiesGkeClusters[] | undefined;
}
export declare class ClouddeployTargetAssociatedEntitiesList extends cdktn.ComplexList {
    internalValue?: ClouddeployTargetAssociatedEntities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ClouddeployTargetAssociatedEntitiesOutputReference;
}
export interface ClouddeployTargetCustomTarget {
    /**
    * Required. The name of the CustomTargetType. Format must be `projects/{project}/locations/{location}/customTargetTypes/{custom_target_type}`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#custom_target_type ClouddeployTarget#custom_target_type}
    */
    readonly customTargetType: string;
}
export declare function clouddeployTargetCustomTargetToTerraform(struct?: ClouddeployTargetCustomTargetOutputReference | ClouddeployTargetCustomTarget): any;
export declare function clouddeployTargetCustomTargetToHclTerraform(struct?: ClouddeployTargetCustomTargetOutputReference | ClouddeployTargetCustomTarget): any;
export declare class ClouddeployTargetCustomTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddeployTargetCustomTarget | undefined;
    set internalValue(value: ClouddeployTargetCustomTarget | undefined);
    private _customTargetType?;
    get customTargetType(): string;
    set customTargetType(value: string);
    get customTargetTypeInput(): string | undefined;
}
export interface ClouddeployTargetExecutionConfigsDefaultPool {
    /**
    * Optional. Cloud Storage location where execution outputs should be stored. This can either be a bucket ("gs://my-bucket") or a path within a bucket ("gs://my-bucket/my-dir"). If unspecified, a default bucket located in the same region will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#artifact_storage ClouddeployTarget#artifact_storage}
    */
    readonly artifactStorage?: string;
    /**
    * Optional. Google service account to use for execution. If unspecified, the project execution service account (-compute@developer.gserviceaccount.com) will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#service_account ClouddeployTarget#service_account}
    */
    readonly serviceAccount?: string;
}
export declare function clouddeployTargetExecutionConfigsDefaultPoolToTerraform(struct?: ClouddeployTargetExecutionConfigsDefaultPoolOutputReference | ClouddeployTargetExecutionConfigsDefaultPool): any;
export declare function clouddeployTargetExecutionConfigsDefaultPoolToHclTerraform(struct?: ClouddeployTargetExecutionConfigsDefaultPoolOutputReference | ClouddeployTargetExecutionConfigsDefaultPool): any;
export declare class ClouddeployTargetExecutionConfigsDefaultPoolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddeployTargetExecutionConfigsDefaultPool | undefined;
    set internalValue(value: ClouddeployTargetExecutionConfigsDefaultPool | undefined);
    private _artifactStorage?;
    get artifactStorage(): string;
    set artifactStorage(value: string);
    resetArtifactStorage(): void;
    get artifactStorageInput(): string | undefined;
    private _serviceAccount?;
    get serviceAccount(): string;
    set serviceAccount(value: string);
    resetServiceAccount(): void;
    get serviceAccountInput(): string | undefined;
}
export interface ClouddeployTargetExecutionConfigsPrivatePool {
    /**
    * Optional. Cloud Storage location where execution outputs should be stored. This can either be a bucket ("gs://my-bucket") or a path within a bucket ("gs://my-bucket/my-dir"). If unspecified, a default bucket located in the same region will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#artifact_storage ClouddeployTarget#artifact_storage}
    */
    readonly artifactStorage?: string;
    /**
    * Optional. Google service account to use for execution. If unspecified, the project execution service account (-compute@developer.gserviceaccount.com) will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#service_account ClouddeployTarget#service_account}
    */
    readonly serviceAccount?: string;
    /**
    * Required. Resource name of the Cloud Build worker pool to use. The format is `projects/{project}/locations/{location}/workerPools/{pool}`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#worker_pool ClouddeployTarget#worker_pool}
    */
    readonly workerPool: string;
}
export declare function clouddeployTargetExecutionConfigsPrivatePoolToTerraform(struct?: ClouddeployTargetExecutionConfigsPrivatePoolOutputReference | ClouddeployTargetExecutionConfigsPrivatePool): any;
export declare function clouddeployTargetExecutionConfigsPrivatePoolToHclTerraform(struct?: ClouddeployTargetExecutionConfigsPrivatePoolOutputReference | ClouddeployTargetExecutionConfigsPrivatePool): any;
export declare class ClouddeployTargetExecutionConfigsPrivatePoolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddeployTargetExecutionConfigsPrivatePool | undefined;
    set internalValue(value: ClouddeployTargetExecutionConfigsPrivatePool | undefined);
    private _artifactStorage?;
    get artifactStorage(): string;
    set artifactStorage(value: string);
    resetArtifactStorage(): void;
    get artifactStorageInput(): string | undefined;
    private _serviceAccount?;
    get serviceAccount(): string;
    set serviceAccount(value: string);
    resetServiceAccount(): void;
    get serviceAccountInput(): string | undefined;
    private _workerPool?;
    get workerPool(): string;
    set workerPool(value: string);
    get workerPoolInput(): string | undefined;
}
export interface ClouddeployTargetExecutionConfigs {
    /**
    * Optional. Cloud Storage location in which to store execution outputs. This can either be a bucket ("gs://my-bucket") or a path within a bucket ("gs://my-bucket/my-dir"). If unspecified, a default bucket located in the same region will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#artifact_storage ClouddeployTarget#artifact_storage}
    */
    readonly artifactStorage?: string;
    /**
    * Optional. Execution timeout for a Cloud Build Execution. This must be between 10m and 24h in seconds format. If unspecified, a default timeout of 1h is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#execution_timeout ClouddeployTarget#execution_timeout}
    */
    readonly executionTimeout?: string;
    /**
    * Optional. Google service account to use for execution. If unspecified, the project execution service account (-compute@developer.gserviceaccount.com) is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#service_account ClouddeployTarget#service_account}
    */
    readonly serviceAccount?: string;
    /**
    * Required. Usages when this configuration should be applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#usages ClouddeployTarget#usages}
    */
    readonly usages: string[];
    /**
    * Optional. If true, additional logging will be enabled when running builds in this execution environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#verbose ClouddeployTarget#verbose}
    */
    readonly verbose?: boolean | cdktn.IResolvable;
    /**
    * Optional. The resource name of the `WorkerPool`, with the format `projects/{project}/locations/{location}/workerPools/{worker_pool}`. If this optional field is unspecified, the default Cloud Build pool will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#worker_pool ClouddeployTarget#worker_pool}
    */
    readonly workerPool?: string;
    /**
    * default_pool block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#default_pool ClouddeployTarget#default_pool}
    */
    readonly defaultPool?: ClouddeployTargetExecutionConfigsDefaultPool;
    /**
    * private_pool block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#private_pool ClouddeployTarget#private_pool}
    */
    readonly privatePool?: ClouddeployTargetExecutionConfigsPrivatePool;
}
export declare function clouddeployTargetExecutionConfigsToTerraform(struct?: ClouddeployTargetExecutionConfigs | cdktn.IResolvable): any;
export declare function clouddeployTargetExecutionConfigsToHclTerraform(struct?: ClouddeployTargetExecutionConfigs | cdktn.IResolvable): any;
export declare class ClouddeployTargetExecutionConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ClouddeployTargetExecutionConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: ClouddeployTargetExecutionConfigs | cdktn.IResolvable | undefined);
    private _artifactStorage?;
    get artifactStorage(): string;
    set artifactStorage(value: string);
    resetArtifactStorage(): void;
    get artifactStorageInput(): string | undefined;
    private _executionTimeout?;
    get executionTimeout(): string;
    set executionTimeout(value: string);
    resetExecutionTimeout(): void;
    get executionTimeoutInput(): string | undefined;
    private _serviceAccount?;
    get serviceAccount(): string;
    set serviceAccount(value: string);
    resetServiceAccount(): void;
    get serviceAccountInput(): string | undefined;
    private _usages?;
    get usages(): string[];
    set usages(value: string[]);
    get usagesInput(): string[] | undefined;
    private _verbose?;
    get verbose(): boolean | cdktn.IResolvable;
    set verbose(value: boolean | cdktn.IResolvable);
    resetVerbose(): void;
    get verboseInput(): boolean | cdktn.IResolvable | undefined;
    private _workerPool?;
    get workerPool(): string;
    set workerPool(value: string);
    resetWorkerPool(): void;
    get workerPoolInput(): string | undefined;
    private _defaultPool;
    get defaultPool(): ClouddeployTargetExecutionConfigsDefaultPoolOutputReference;
    putDefaultPool(value: ClouddeployTargetExecutionConfigsDefaultPool): void;
    resetDefaultPool(): void;
    get defaultPoolInput(): ClouddeployTargetExecutionConfigsDefaultPool | undefined;
    private _privatePool;
    get privatePool(): ClouddeployTargetExecutionConfigsPrivatePoolOutputReference;
    putPrivatePool(value: ClouddeployTargetExecutionConfigsPrivatePool): void;
    resetPrivatePool(): void;
    get privatePoolInput(): ClouddeployTargetExecutionConfigsPrivatePool | undefined;
}
export declare class ClouddeployTargetExecutionConfigsList extends cdktn.ComplexList {
    internalValue?: ClouddeployTargetExecutionConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ClouddeployTargetExecutionConfigsOutputReference;
}
export interface ClouddeployTargetGke {
    /**
    * Information specifying a GKE Cluster. Format is `projects/{project_id}/locations/{location_id}/clusters/{cluster_id}.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#cluster ClouddeployTarget#cluster}
    */
    readonly cluster?: string;
    /**
    * Optional. If set, the cluster will be accessed using the DNS endpoint. Note that both `dns_endpoint` and `internal_ip` cannot be set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#dns_endpoint ClouddeployTarget#dns_endpoint}
    */
    readonly dnsEndpoint?: boolean | cdktn.IResolvable;
    /**
    * Optional. If true, `cluster` is accessed using the private IP address of the control plane endpoint. Otherwise, the default IP address of the control plane endpoint is used. The default IP address is the private IP address for clusters with private control-plane endpoints and the public IP address otherwise. Only specify this option when `cluster` is a [private GKE cluster](https://cloud.google.com/kubernetes-engine/docs/concepts/private-cluster-concept).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#internal_ip ClouddeployTarget#internal_ip}
    */
    readonly internalIp?: boolean | cdktn.IResolvable;
    /**
    * Optional. If set, used to configure a [proxy](https://kubernetes.io/docs/concepts/configuration/organize-cluster-access-kubeconfig/#proxy) to the Kubernetes server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#proxy_url ClouddeployTarget#proxy_url}
    */
    readonly proxyUrl?: string;
}
export declare function clouddeployTargetGkeToTerraform(struct?: ClouddeployTargetGkeOutputReference | ClouddeployTargetGke): any;
export declare function clouddeployTargetGkeToHclTerraform(struct?: ClouddeployTargetGkeOutputReference | ClouddeployTargetGke): any;
export declare class ClouddeployTargetGkeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddeployTargetGke | undefined;
    set internalValue(value: ClouddeployTargetGke | undefined);
    private _cluster?;
    get cluster(): string;
    set cluster(value: string);
    resetCluster(): void;
    get clusterInput(): string | undefined;
    private _dnsEndpoint?;
    get dnsEndpoint(): boolean | cdktn.IResolvable;
    set dnsEndpoint(value: boolean | cdktn.IResolvable);
    resetDnsEndpoint(): void;
    get dnsEndpointInput(): boolean | cdktn.IResolvable | undefined;
    private _internalIp?;
    get internalIp(): boolean | cdktn.IResolvable;
    set internalIp(value: boolean | cdktn.IResolvable);
    resetInternalIp(): void;
    get internalIpInput(): boolean | cdktn.IResolvable | undefined;
    private _proxyUrl?;
    get proxyUrl(): string;
    set proxyUrl(value: string);
    resetProxyUrl(): void;
    get proxyUrlInput(): string | undefined;
}
export interface ClouddeployTargetMultiTarget {
    /**
    * Required. The target_ids of this multiTarget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#target_ids ClouddeployTarget#target_ids}
    */
    readonly targetIds: string[];
}
export declare function clouddeployTargetMultiTargetToTerraform(struct?: ClouddeployTargetMultiTargetOutputReference | ClouddeployTargetMultiTarget): any;
export declare function clouddeployTargetMultiTargetToHclTerraform(struct?: ClouddeployTargetMultiTargetOutputReference | ClouddeployTargetMultiTarget): any;
export declare class ClouddeployTargetMultiTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddeployTargetMultiTarget | undefined;
    set internalValue(value: ClouddeployTargetMultiTarget | undefined);
    private _targetIds?;
    get targetIds(): string[];
    set targetIds(value: string[]);
    get targetIdsInput(): string[] | undefined;
}
export interface ClouddeployTargetRun {
    /**
    * Required. The location where the Cloud Run Service should be located. Format is `projects/{project}/locations/{location}`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#location ClouddeployTarget#location}
    */
    readonly location: string;
}
export declare function clouddeployTargetRunToTerraform(struct?: ClouddeployTargetRunOutputReference | ClouddeployTargetRun): any;
export declare function clouddeployTargetRunToHclTerraform(struct?: ClouddeployTargetRunOutputReference | ClouddeployTargetRun): any;
export declare class ClouddeployTargetRunOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddeployTargetRun | undefined;
    set internalValue(value: ClouddeployTargetRun | undefined);
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
}
export interface ClouddeployTargetTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#create ClouddeployTarget#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#delete ClouddeployTarget#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#update ClouddeployTarget#update}
    */
    readonly update?: string;
}
export declare function clouddeployTargetTimeoutsToTerraform(struct?: ClouddeployTargetTimeouts | cdktn.IResolvable): any;
export declare function clouddeployTargetTimeoutsToHclTerraform(struct?: ClouddeployTargetTimeouts | cdktn.IResolvable): any;
export declare class ClouddeployTargetTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClouddeployTargetTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ClouddeployTargetTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target google_clouddeploy_target}
*/
export declare class ClouddeployTarget extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_clouddeploy_target";
    /**
    * Generates CDKTN code for importing a ClouddeployTarget resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ClouddeployTarget to import
    * @param importFromId The id of the existing ClouddeployTarget that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ClouddeployTarget to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/clouddeploy_target google_clouddeploy_target} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ClouddeployTargetConfig
    */
    constructor(scope: Construct, id: string, config: ClouddeployTargetConfig);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _deployParameters?;
    get deployParameters(): {
        [key: string]: string;
    };
    set deployParameters(value: {
        [key: string]: string;
    });
    resetDeployParameters(): void;
    get deployParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _effectiveAnnotations;
    get effectiveAnnotations(): cdktn.StringMap;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _requireApproval?;
    get requireApproval(): boolean | cdktn.IResolvable;
    set requireApproval(value: boolean | cdktn.IResolvable);
    resetRequireApproval(): void;
    get requireApprovalInput(): boolean | cdktn.IResolvable | undefined;
    get targetId(): string;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get uid(): string;
    get updateTime(): string;
    private _anthosCluster;
    get anthosCluster(): ClouddeployTargetAnthosClusterOutputReference;
    putAnthosCluster(value: ClouddeployTargetAnthosCluster): void;
    resetAnthosCluster(): void;
    get anthosClusterInput(): ClouddeployTargetAnthosCluster | undefined;
    private _associatedEntities;
    get associatedEntities(): ClouddeployTargetAssociatedEntitiesList;
    putAssociatedEntities(value: ClouddeployTargetAssociatedEntities[] | cdktn.IResolvable): void;
    resetAssociatedEntities(): void;
    get associatedEntitiesInput(): cdktn.IResolvable | ClouddeployTargetAssociatedEntities[] | undefined;
    private _customTarget;
    get customTarget(): ClouddeployTargetCustomTargetOutputReference;
    putCustomTarget(value: ClouddeployTargetCustomTarget): void;
    resetCustomTarget(): void;
    get customTargetInput(): ClouddeployTargetCustomTarget | undefined;
    private _executionConfigs;
    get executionConfigs(): ClouddeployTargetExecutionConfigsList;
    putExecutionConfigs(value: ClouddeployTargetExecutionConfigs[] | cdktn.IResolvable): void;
    resetExecutionConfigs(): void;
    get executionConfigsInput(): cdktn.IResolvable | ClouddeployTargetExecutionConfigs[] | undefined;
    private _gke;
    get gke(): ClouddeployTargetGkeOutputReference;
    putGke(value: ClouddeployTargetGke): void;
    resetGke(): void;
    get gkeInput(): ClouddeployTargetGke | undefined;
    private _multiTarget;
    get multiTarget(): ClouddeployTargetMultiTargetOutputReference;
    putMultiTarget(value: ClouddeployTargetMultiTarget): void;
    resetMultiTarget(): void;
    get multiTargetInput(): ClouddeployTargetMultiTarget | undefined;
    private _run;
    get run(): ClouddeployTargetRunOutputReference;
    putRun(value: ClouddeployTargetRun): void;
    resetRun(): void;
    get runInput(): ClouddeployTargetRun | undefined;
    private _timeouts;
    get timeouts(): ClouddeployTargetTimeoutsOutputReference;
    putTimeouts(value: ClouddeployTargetTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ClouddeployTargetTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
