/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeRegionCompositeHealthCheckConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_composite_health_check#deletion_policy ComputeRegionCompositeHealthCheck#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource. Provide this property when you
    * create the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_composite_health_check#description ComputeRegionCompositeHealthCheck#description}
    */
    readonly description?: string;
    /**
    * URL to the destination resource. Must be set. Must be a
    * ForwardingRule. The ForwardingRule must have
    * load balancing scheme INTERNAL or
    * INTERNAL_MANAGED and must be regional and in the same region
    * as the CompositeHealthCheck (cross-region deployment for
    * INTERNAL_MANAGED is not supported). Can be mutated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_composite_health_check#health_destination ComputeRegionCompositeHealthCheck#health_destination}
    */
    readonly healthDestination: string;
    /**
    * URLs to the HealthSource resources whose results are AND'ed.
    * I.e. he aggregated result is is HEALTHY only if all sources
    * are HEALTHY. Must have at least 1. Must not have more than 10.
    * Must be regional and in the same region as the
    * CompositeHealthCheck. Can be mutated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_composite_health_check#health_sources ComputeRegionCompositeHealthCheck#health_sources}
    */
    readonly healthSources?: string[];
    /**
    * Name of the resource. Provided by the client when the resource is created.
    * The name must be 1-63 characters long, and comply with RFC1035.
    * Specifically, the name must be 1-63 characters long and match the regular
    * expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the first
    * character must be a lowercase letter, and all following characters must
    * be a dash, lowercase letter, or digit, except the last character, which
    * cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_composite_health_check#name ComputeRegionCompositeHealthCheck#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_composite_health_check#project ComputeRegionCompositeHealthCheck#project}
    */
    readonly project?: string;
    /**
    * URL of the region where the composite health check resides.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_composite_health_check#region ComputeRegionCompositeHealthCheck#region}
    */
    readonly region: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_composite_health_check#timeouts ComputeRegionCompositeHealthCheck#timeouts}
    */
    readonly timeouts?: ComputeRegionCompositeHealthCheckTimeouts;
}
export interface ComputeRegionCompositeHealthCheckTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_composite_health_check#create ComputeRegionCompositeHealthCheck#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_composite_health_check#delete ComputeRegionCompositeHealthCheck#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_composite_health_check#update ComputeRegionCompositeHealthCheck#update}
    */
    readonly update?: string;
}
export declare function computeRegionCompositeHealthCheckTimeoutsToTerraform(struct?: ComputeRegionCompositeHealthCheckTimeouts | cdktn.IResolvable): any;
export declare function computeRegionCompositeHealthCheckTimeoutsToHclTerraform(struct?: ComputeRegionCompositeHealthCheckTimeouts | cdktn.IResolvable): any;
export declare class ComputeRegionCompositeHealthCheckTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionCompositeHealthCheckTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionCompositeHealthCheckTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_composite_health_check google_compute_region_composite_health_check}
*/
export declare class ComputeRegionCompositeHealthCheck extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_region_composite_health_check";
    /**
    * Generates CDKTN code for importing a ComputeRegionCompositeHealthCheck resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeRegionCompositeHealthCheck to import
    * @param importFromId The id of the existing ComputeRegionCompositeHealthCheck that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_composite_health_check#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeRegionCompositeHealthCheck to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/compute_region_composite_health_check google_compute_region_composite_health_check} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeRegionCompositeHealthCheckConfig
    */
    constructor(scope: Construct, id: string, config: ComputeRegionCompositeHealthCheckConfig);
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get fingerprint(): string;
    private _healthDestination?;
    get healthDestination(): string;
    set healthDestination(value: string);
    get healthDestinationInput(): string | undefined;
    private _healthSources?;
    get healthSources(): string[];
    set healthSources(value: string[]);
    resetHealthSources(): void;
    get healthSourcesInput(): string[] | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    get selfLinkWithId(): string;
    private _timeouts;
    get timeouts(): ComputeRegionCompositeHealthCheckTimeoutsOutputReference;
    putTimeouts(value: ComputeRegionCompositeHealthCheckTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeRegionCompositeHealthCheckTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
