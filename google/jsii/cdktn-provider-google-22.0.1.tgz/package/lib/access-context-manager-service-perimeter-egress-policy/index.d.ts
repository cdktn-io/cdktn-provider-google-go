/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccessContextManagerServicePerimeterEgressPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy#deletion_policy AccessContextManagerServicePerimeterEgressPolicy#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy#id AccessContextManagerServicePerimeterEgressPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the Service Perimeter to add this resource to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy#perimeter AccessContextManagerServicePerimeterEgressPolicy#perimeter}
    */
    readonly perimeter: string;
    /**
    * Human readable title. Must be unique within the perimeter. Does not affect behavior.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy#title AccessContextManagerServicePerimeterEgressPolicy#title}
    */
    readonly title?: string;
    /**
    * egress_from block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy#egress_from AccessContextManagerServicePerimeterEgressPolicy#egress_from}
    */
    readonly egressFrom?: AccessContextManagerServicePerimeterEgressPolicyEgressFrom;
    /**
    * egress_to block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy#egress_to AccessContextManagerServicePerimeterEgressPolicy#egress_to}
    */
    readonly egressTo?: AccessContextManagerServicePerimeterEgressPolicyEgressTo;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy#timeouts AccessContextManagerServicePerimeterEgressPolicy#timeouts}
    */
    readonly timeouts?: AccessContextManagerServicePerimeterEgressPolicyTimeouts;
}
export interface AccessContextManagerServicePerimeterEgressPolicyEgressFromSourcesPscEndpoint {
    /**
    * The full resource name of the global forwarding rule that identifies a Private Service Connect endpoint.
    * Forwarding rule format: '//compute.googleapis.com/projects/{PROJECT_ID}/global/forwardingRules/{FORWARDING_RULE_ID}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy#forwarding_rule AccessContextManagerServicePerimeterEgressPolicy#forwarding_rule}
    */
    readonly forwardingRule?: string;
}
export declare function accessContextManagerServicePerimeterEgressPolicyEgressFromSourcesPscEndpointToTerraform(struct?: AccessContextManagerServicePerimeterEgressPolicyEgressFromSourcesPscEndpointOutputReference | AccessContextManagerServicePerimeterEgressPolicyEgressFromSourcesPscEndpoint): any;
export declare function accessContextManagerServicePerimeterEgressPolicyEgressFromSourcesPscEndpointToHclTerraform(struct?: AccessContextManagerServicePerimeterEgressPolicyEgressFromSourcesPscEndpointOutputReference | AccessContextManagerServicePerimeterEgressPolicyEgressFromSourcesPscEndpoint): any;
export declare class AccessContextManagerServicePerimeterEgressPolicyEgressFromSourcesPscEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterEgressPolicyEgressFromSourcesPscEndpoint | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterEgressPolicyEgressFromSourcesPscEndpoint | undefined);
    private _forwardingRule?;
    get forwardingRule(): string;
    set forwardingRule(value: string);
    resetForwardingRule(): void;
    get forwardingRuleInput(): string | undefined;
}
export interface AccessContextManagerServicePerimeterEgressPolicyEgressFromSources {
    /**
    * An AccessLevel resource name that allows resources outside the ServicePerimeter to be accessed from the inside.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy#access_level AccessContextManagerServicePerimeterEgressPolicy#access_level}
    */
    readonly accessLevel?: string;
    /**
    * A Google Cloud resource that is allowed to egress the perimeter.
    * Requests from these resources are allowed to access data outside the perimeter.
    * Projects, folders, and organizations are allowed.
    * Project format: 'projects/{project_number}'
    * Folder format: 'folders/{folder_number}'
    * Organization format: 'organizations/{organization_number}'
    * The resource may be in any Google Cloud organization, not just the
    * organization that the perimeter is defined in. '*' is not allowed, the
    * case of allowing all Google Cloud resources only is not supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy#resource AccessContextManagerServicePerimeterEgressPolicy#resource}
    */
    readonly resource?: string;
    /**
    * psc_endpoint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy#psc_endpoint AccessContextManagerServicePerimeterEgressPolicy#psc_endpoint}
    */
    readonly pscEndpoint?: AccessContextManagerServicePerimeterEgressPolicyEgressFromSourcesPscEndpoint;
}
export declare function accessContextManagerServicePerimeterEgressPolicyEgressFromSourcesToTerraform(struct?: AccessContextManagerServicePerimeterEgressPolicyEgressFromSources | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterEgressPolicyEgressFromSourcesToHclTerraform(struct?: AccessContextManagerServicePerimeterEgressPolicyEgressFromSources | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterEgressPolicyEgressFromSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterEgressPolicyEgressFromSources | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterEgressPolicyEgressFromSources | cdktn.IResolvable | undefined);
    private _accessLevel?;
    get accessLevel(): string;
    set accessLevel(value: string);
    resetAccessLevel(): void;
    get accessLevelInput(): string | undefined;
    private _resource?;
    get resource(): string;
    set resource(value: string);
    resetResource(): void;
    get resourceInput(): string | undefined;
    private _pscEndpoint;
    get pscEndpoint(): AccessContextManagerServicePerimeterEgressPolicyEgressFromSourcesPscEndpointOutputReference;
    putPscEndpoint(value: AccessContextManagerServicePerimeterEgressPolicyEgressFromSourcesPscEndpoint): void;
    resetPscEndpoint(): void;
    get pscEndpointInput(): AccessContextManagerServicePerimeterEgressPolicyEgressFromSourcesPscEndpoint | undefined;
}
export declare class AccessContextManagerServicePerimeterEgressPolicyEgressFromSourcesList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterEgressPolicyEgressFromSources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterEgressPolicyEgressFromSourcesOutputReference;
}
export interface AccessContextManagerServicePerimeterEgressPolicyEgressFrom {
    /**
    * Identities can be an individual user, service account, Google group,
    * or third-party identity. For third-party identity, only single identities
    * are supported and other identity types are not supported.The v1 identities
    * that have the prefix user, group and serviceAccount in
    * https://cloud.google.com/iam/docs/principal-identifiers#v1 are supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy#identities AccessContextManagerServicePerimeterEgressPolicy#identities}
    */
    readonly identities?: string[];
    /**
    * Specifies the type of identities that are allowed access to outside the
    * perimeter. If left unspecified, then members of 'identities' field will
    * be allowed access. Possible values: ["ANY_IDENTITY", "ANY_USER_ACCOUNT", "ANY_SERVICE_ACCOUNT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy#identity_type AccessContextManagerServicePerimeterEgressPolicy#identity_type}
    */
    readonly identityType?: string;
    /**
    * Whether to enforce traffic restrictions based on 'sources' field. If the 'sources' field is non-empty, then this field must be set to 'SOURCE_RESTRICTION_ENABLED'. Possible values: ["SOURCE_RESTRICTION_UNSPECIFIED", "SOURCE_RESTRICTION_ENABLED", "SOURCE_RESTRICTION_DISABLED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy#source_restriction AccessContextManagerServicePerimeterEgressPolicy#source_restriction}
    */
    readonly sourceRestriction?: string;
    /**
    * sources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy#sources AccessContextManagerServicePerimeterEgressPolicy#sources}
    */
    readonly sources?: AccessContextManagerServicePerimeterEgressPolicyEgressFromSources[] | cdktn.IResolvable;
}
export declare function accessContextManagerServicePerimeterEgressPolicyEgressFromToTerraform(struct?: AccessContextManagerServicePerimeterEgressPolicyEgressFromOutputReference | AccessContextManagerServicePerimeterEgressPolicyEgressFrom): any;
export declare function accessContextManagerServicePerimeterEgressPolicyEgressFromToHclTerraform(struct?: AccessContextManagerServicePerimeterEgressPolicyEgressFromOutputReference | AccessContextManagerServicePerimeterEgressPolicyEgressFrom): any;
export declare class AccessContextManagerServicePerimeterEgressPolicyEgressFromOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterEgressPolicyEgressFrom | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterEgressPolicyEgressFrom | undefined);
    private _identities?;
    get identities(): string[];
    set identities(value: string[]);
    resetIdentities(): void;
    get identitiesInput(): string[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
    private _sourceRestriction?;
    get sourceRestriction(): string;
    set sourceRestriction(value: string);
    resetSourceRestriction(): void;
    get sourceRestrictionInput(): string | undefined;
    private _sources;
    get sources(): AccessContextManagerServicePerimeterEgressPolicyEgressFromSourcesList;
    putSources(value: AccessContextManagerServicePerimeterEgressPolicyEgressFromSources[] | cdktn.IResolvable): void;
    resetSources(): void;
    get sourcesInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterEgressPolicyEgressFromSources[] | undefined;
}
export interface AccessContextManagerServicePerimeterEgressPolicyEgressToOperationsMethodSelectors {
    /**
    * Value for 'method' should be a valid method name for the corresponding
    * 'serviceName' in 'ApiOperation'. If '*' used as value for method,
    * then ALL methods and permissions are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy#method AccessContextManagerServicePerimeterEgressPolicy#method}
    */
    readonly method?: string;
    /**
    * Value for permission should be a valid Cloud IAM permission for the
    * corresponding 'serviceName' in 'ApiOperation'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy#permission AccessContextManagerServicePerimeterEgressPolicy#permission}
    */
    readonly permission?: string;
}
export declare function accessContextManagerServicePerimeterEgressPolicyEgressToOperationsMethodSelectorsToTerraform(struct?: AccessContextManagerServicePerimeterEgressPolicyEgressToOperationsMethodSelectors | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterEgressPolicyEgressToOperationsMethodSelectorsToHclTerraform(struct?: AccessContextManagerServicePerimeterEgressPolicyEgressToOperationsMethodSelectors | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterEgressPolicyEgressToOperationsMethodSelectorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterEgressPolicyEgressToOperationsMethodSelectors | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterEgressPolicyEgressToOperationsMethodSelectors | cdktn.IResolvable | undefined);
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    resetPermission(): void;
    get permissionInput(): string | undefined;
}
export declare class AccessContextManagerServicePerimeterEgressPolicyEgressToOperationsMethodSelectorsList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterEgressPolicyEgressToOperationsMethodSelectors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterEgressPolicyEgressToOperationsMethodSelectorsOutputReference;
}
export interface AccessContextManagerServicePerimeterEgressPolicyEgressToOperations {
    /**
    * The name of the API whose methods or permissions the 'IngressPolicy' or
    * 'EgressPolicy' want to allow. A single 'ApiOperation' with serviceName
    * field set to '*' will allow all methods AND permissions for all services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy#service_name AccessContextManagerServicePerimeterEgressPolicy#service_name}
    */
    readonly serviceName?: string;
    /**
    * method_selectors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy#method_selectors AccessContextManagerServicePerimeterEgressPolicy#method_selectors}
    */
    readonly methodSelectors?: AccessContextManagerServicePerimeterEgressPolicyEgressToOperationsMethodSelectors[] | cdktn.IResolvable;
}
export declare function accessContextManagerServicePerimeterEgressPolicyEgressToOperationsToTerraform(struct?: AccessContextManagerServicePerimeterEgressPolicyEgressToOperations | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterEgressPolicyEgressToOperationsToHclTerraform(struct?: AccessContextManagerServicePerimeterEgressPolicyEgressToOperations | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterEgressPolicyEgressToOperationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessContextManagerServicePerimeterEgressPolicyEgressToOperations | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterEgressPolicyEgressToOperations | cdktn.IResolvable | undefined);
    private _serviceName?;
    get serviceName(): string;
    set serviceName(value: string);
    resetServiceName(): void;
    get serviceNameInput(): string | undefined;
    private _methodSelectors;
    get methodSelectors(): AccessContextManagerServicePerimeterEgressPolicyEgressToOperationsMethodSelectorsList;
    putMethodSelectors(value: AccessContextManagerServicePerimeterEgressPolicyEgressToOperationsMethodSelectors[] | cdktn.IResolvable): void;
    resetMethodSelectors(): void;
    get methodSelectorsInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterEgressPolicyEgressToOperationsMethodSelectors[] | undefined;
}
export declare class AccessContextManagerServicePerimeterEgressPolicyEgressToOperationsList extends cdktn.ComplexList {
    internalValue?: AccessContextManagerServicePerimeterEgressPolicyEgressToOperations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessContextManagerServicePerimeterEgressPolicyEgressToOperationsOutputReference;
}
export interface AccessContextManagerServicePerimeterEgressPolicyEgressTo {
    /**
    * A list of external resources that are allowed to be accessed. A request
    * matches if it contains an external resource in this list (Example:
    * s3://bucket/path). Currently '*' is not allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy#external_resources AccessContextManagerServicePerimeterEgressPolicy#external_resources}
    */
    readonly externalResources?: string[];
    /**
    * A list of resources, in the form 'projects/{project_number}',
    * 'folders/{folder_number}', or 'organizations/{organization_number}',
    * that match this to stanza. A request matches
    * if it contains a resource in this list. If * is specified for resources,
    * then this 'EgressTo' rule will authorize access to all resources outside
    * the perimeter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy#resources AccessContextManagerServicePerimeterEgressPolicy#resources}
    */
    readonly resources?: string[];
    /**
    * A list of IAM roles that represent the set of operations that the sources
    * specified in the corresponding 'EgressFrom'
    * are allowed to perform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy#roles AccessContextManagerServicePerimeterEgressPolicy#roles}
    */
    readonly roles?: string[];
    /**
    * operations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy#operations AccessContextManagerServicePerimeterEgressPolicy#operations}
    */
    readonly operations?: AccessContextManagerServicePerimeterEgressPolicyEgressToOperations[] | cdktn.IResolvable;
}
export declare function accessContextManagerServicePerimeterEgressPolicyEgressToToTerraform(struct?: AccessContextManagerServicePerimeterEgressPolicyEgressToOutputReference | AccessContextManagerServicePerimeterEgressPolicyEgressTo): any;
export declare function accessContextManagerServicePerimeterEgressPolicyEgressToToHclTerraform(struct?: AccessContextManagerServicePerimeterEgressPolicyEgressToOutputReference | AccessContextManagerServicePerimeterEgressPolicyEgressTo): any;
export declare class AccessContextManagerServicePerimeterEgressPolicyEgressToOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterEgressPolicyEgressTo | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterEgressPolicyEgressTo | undefined);
    private _externalResources?;
    get externalResources(): string[];
    set externalResources(value: string[]);
    resetExternalResources(): void;
    get externalResourcesInput(): string[] | undefined;
    private _resources?;
    get resources(): string[];
    set resources(value: string[]);
    resetResources(): void;
    get resourcesInput(): string[] | undefined;
    private _roles?;
    get roles(): string[];
    set roles(value: string[]);
    resetRoles(): void;
    get rolesInput(): string[] | undefined;
    private _operations;
    get operations(): AccessContextManagerServicePerimeterEgressPolicyEgressToOperationsList;
    putOperations(value: AccessContextManagerServicePerimeterEgressPolicyEgressToOperations[] | cdktn.IResolvable): void;
    resetOperations(): void;
    get operationsInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterEgressPolicyEgressToOperations[] | undefined;
}
export interface AccessContextManagerServicePerimeterEgressPolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy#create AccessContextManagerServicePerimeterEgressPolicy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy#delete AccessContextManagerServicePerimeterEgressPolicy#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy#update AccessContextManagerServicePerimeterEgressPolicy#update}
    */
    readonly update?: string;
}
export declare function accessContextManagerServicePerimeterEgressPolicyTimeoutsToTerraform(struct?: AccessContextManagerServicePerimeterEgressPolicyTimeouts | cdktn.IResolvable): any;
export declare function accessContextManagerServicePerimeterEgressPolicyTimeoutsToHclTerraform(struct?: AccessContextManagerServicePerimeterEgressPolicyTimeouts | cdktn.IResolvable): any;
export declare class AccessContextManagerServicePerimeterEgressPolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerServicePerimeterEgressPolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerServicePerimeterEgressPolicyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy google_access_context_manager_service_perimeter_egress_policy}
*/
export declare class AccessContextManagerServicePerimeterEgressPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_access_context_manager_service_perimeter_egress_policy";
    /**
    * Generates CDKTN code for importing a AccessContextManagerServicePerimeterEgressPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessContextManagerServicePerimeterEgressPolicy to import
    * @param importFromId The id of the existing AccessContextManagerServicePerimeterEgressPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessContextManagerServicePerimeterEgressPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.11.0/docs/resources/access_context_manager_service_perimeter_egress_policy google_access_context_manager_service_perimeter_egress_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessContextManagerServicePerimeterEgressPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AccessContextManagerServicePerimeterEgressPolicyConfig);
    get accessPolicyId(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _perimeter?;
    get perimeter(): string;
    set perimeter(value: string);
    get perimeterInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _egressFrom;
    get egressFrom(): AccessContextManagerServicePerimeterEgressPolicyEgressFromOutputReference;
    putEgressFrom(value: AccessContextManagerServicePerimeterEgressPolicyEgressFrom): void;
    resetEgressFrom(): void;
    get egressFromInput(): AccessContextManagerServicePerimeterEgressPolicyEgressFrom | undefined;
    private _egressTo;
    get egressTo(): AccessContextManagerServicePerimeterEgressPolicyEgressToOutputReference;
    putEgressTo(value: AccessContextManagerServicePerimeterEgressPolicyEgressTo): void;
    resetEgressTo(): void;
    get egressToInput(): AccessContextManagerServicePerimeterEgressPolicyEgressTo | undefined;
    private _timeouts;
    get timeouts(): AccessContextManagerServicePerimeterEgressPolicyTimeoutsOutputReference;
    putTimeouts(value: AccessContextManagerServicePerimeterEgressPolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AccessContextManagerServicePerimeterEgressPolicyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
