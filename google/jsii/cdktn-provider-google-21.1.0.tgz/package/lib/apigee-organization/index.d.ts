/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigeeOrganizationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Primary GCP region for analytics data storage. For valid values, see [Create an Apigee organization](https://cloud.google.com/apigee/docs/api-platform/get-started/create-org).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_organization#analytics_region ApigeeOrganization#analytics_region}
    */
    readonly analyticsRegion?: string;
    /**
    * Cloud KMS key name used for encrypting API consumer data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_organization#api_consumer_data_encryption_key_name ApigeeOrganization#api_consumer_data_encryption_key_name}
    */
    readonly apiConsumerDataEncryptionKeyName?: string;
    /**
    * This field is needed only for customers using non-default data residency regions.
    * Apigee stores some control plane data only in single region.
    * This field determines which single region Apigee should use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_organization#api_consumer_data_location ApigeeOrganization#api_consumer_data_location}
    */
    readonly apiConsumerDataLocation?: string;
    /**
    * Compute Engine network used for Service Networking to be peered with Apigee runtime instances.
    * See [Getting started with the Service Networking API](https://cloud.google.com/service-infrastructure/docs/service-networking/getting-started).
    * Valid only when 'RuntimeType' is set to CLOUD. The value can be updated only when there are no runtime instances. For example: "default".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_organization#authorized_network ApigeeOrganization#authorized_network}
    */
    readonly authorizedNetwork?: string;
    /**
    * Billing type of the Apigee organization. See [Apigee pricing](https://cloud.google.com/apigee/pricing).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_organization#billing_type ApigeeOrganization#billing_type}
    */
    readonly billingType?: string;
    /**
    * Cloud KMS key name used for encrypting control plane data that is stored in a multi region.
    * Only used for the data residency region "US" or "EU".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_organization#control_plane_encryption_key_name ApigeeOrganization#control_plane_encryption_key_name}
    */
    readonly controlPlaneEncryptionKeyName?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_organization#deletion_policy ApigeeOrganization#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Description of the Apigee organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_organization#description ApigeeOrganization#description}
    */
    readonly description?: string;
    /**
    * Flag that specifies whether the VPC Peering through Private Google Access should be
    * disabled between the consumer network and Apigee. Required if an 'authorizedNetwork'
    * on the consumer project is not provided, in which case the flag should be set to 'true'.
    * Valid only when 'RuntimeType' is set to CLOUD. The value must be set before the creation
    * of any Apigee runtime instance and can be updated only when there are no runtime instances.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_organization#disable_vpc_peering ApigeeOrganization#disable_vpc_peering}
    */
    readonly disableVpcPeering?: boolean | cdktn.IResolvable;
    /**
    * The display name of the Apigee organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_organization#display_name ApigeeOrganization#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_organization#id ApigeeOrganization#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The project ID associated with the Apigee organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_organization#project_id ApigeeOrganization#project_id}
    */
    readonly projectId: string;
    /**
    * Optional. This setting is applicable only for organizations that are soft-deleted (i.e., BillingType
    * is not EVALUATION). It controls how long Organization data will be retained after the initial delete
    * operation completes. During this period, the Organization may be restored to its last known state.
    * After this period, the Organization will no longer be able to be restored. Default value: "DELETION_RETENTION_UNSPECIFIED" Possible values: ["DELETION_RETENTION_UNSPECIFIED", "MINIMUM"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_organization#retention ApigeeOrganization#retention}
    */
    readonly retention?: string;
    /**
    * Cloud KMS key name used for encrypting the data that is stored and replicated across runtime instances.
    * Update is not allowed after the organization is created.
    * If not specified, a Google-Managed encryption key will be used.
    * Valid only when 'RuntimeType' is CLOUD. For example: 'projects/foo/locations/us/keyRings/bar/cryptoKeys/baz'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_organization#runtime_database_encryption_key_name ApigeeOrganization#runtime_database_encryption_key_name}
    */
    readonly runtimeDatabaseEncryptionKeyName?: string;
    /**
    * Runtime type of the Apigee organization based on the Apigee subscription purchased. Default value: "CLOUD" Possible values: ["CLOUD", "HYBRID"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_organization#runtime_type ApigeeOrganization#runtime_type}
    */
    readonly runtimeType?: string;
    /**
    * properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_organization#properties ApigeeOrganization#properties}
    */
    readonly properties?: ApigeeOrganizationProperties;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_organization#timeouts ApigeeOrganization#timeouts}
    */
    readonly timeouts?: ApigeeOrganizationTimeouts;
}
export interface ApigeeOrganizationPropertiesProperty {
    /**
    * Name of the property.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_organization#name ApigeeOrganization#name}
    */
    readonly name?: string;
    /**
    * Value of the property.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_organization#value ApigeeOrganization#value}
    */
    readonly value?: string;
}
export declare function apigeeOrganizationPropertiesPropertyToTerraform(struct?: ApigeeOrganizationPropertiesProperty | cdktn.IResolvable): any;
export declare function apigeeOrganizationPropertiesPropertyToHclTerraform(struct?: ApigeeOrganizationPropertiesProperty | cdktn.IResolvable): any;
export declare class ApigeeOrganizationPropertiesPropertyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigeeOrganizationPropertiesProperty | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeOrganizationPropertiesProperty | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApigeeOrganizationPropertiesPropertyList extends cdktn.ComplexList {
    internalValue?: ApigeeOrganizationPropertiesProperty[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigeeOrganizationPropertiesPropertyOutputReference;
}
export interface ApigeeOrganizationProperties {
    /**
    * property block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_organization#property ApigeeOrganization#property}
    */
    readonly property?: ApigeeOrganizationPropertiesProperty[] | cdktn.IResolvable;
}
export declare function apigeeOrganizationPropertiesToTerraform(struct?: ApigeeOrganizationPropertiesOutputReference | ApigeeOrganizationProperties): any;
export declare function apigeeOrganizationPropertiesToHclTerraform(struct?: ApigeeOrganizationPropertiesOutputReference | ApigeeOrganizationProperties): any;
export declare class ApigeeOrganizationPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeOrganizationProperties | undefined;
    set internalValue(value: ApigeeOrganizationProperties | undefined);
    private _property;
    get property(): ApigeeOrganizationPropertiesPropertyList;
    putProperty(value: ApigeeOrganizationPropertiesProperty[] | cdktn.IResolvable): void;
    resetProperty(): void;
    get propertyInput(): cdktn.IResolvable | ApigeeOrganizationPropertiesProperty[] | undefined;
}
export interface ApigeeOrganizationTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_organization#create ApigeeOrganization#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_organization#delete ApigeeOrganization#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_organization#update ApigeeOrganization#update}
    */
    readonly update?: string;
}
export declare function apigeeOrganizationTimeoutsToTerraform(struct?: ApigeeOrganizationTimeouts | cdktn.IResolvable): any;
export declare function apigeeOrganizationTimeoutsToHclTerraform(struct?: ApigeeOrganizationTimeouts | cdktn.IResolvable): any;
export declare class ApigeeOrganizationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeOrganizationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeOrganizationTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_organization google_apigee_organization}
*/
export declare class ApigeeOrganization extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apigee_organization";
    /**
    * Generates CDKTN code for importing a ApigeeOrganization resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigeeOrganization to import
    * @param importFromId The id of the existing ApigeeOrganization that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_organization#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigeeOrganization to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_organization google_apigee_organization} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigeeOrganizationConfig
    */
    constructor(scope: Construct, id: string, config: ApigeeOrganizationConfig);
    private _analyticsRegion?;
    get analyticsRegion(): string;
    set analyticsRegion(value: string);
    resetAnalyticsRegion(): void;
    get analyticsRegionInput(): string | undefined;
    private _apiConsumerDataEncryptionKeyName?;
    get apiConsumerDataEncryptionKeyName(): string;
    set apiConsumerDataEncryptionKeyName(value: string);
    resetApiConsumerDataEncryptionKeyName(): void;
    get apiConsumerDataEncryptionKeyNameInput(): string | undefined;
    private _apiConsumerDataLocation?;
    get apiConsumerDataLocation(): string;
    set apiConsumerDataLocation(value: string);
    resetApiConsumerDataLocation(): void;
    get apiConsumerDataLocationInput(): string | undefined;
    get apigeeProjectId(): string;
    private _authorizedNetwork?;
    get authorizedNetwork(): string;
    set authorizedNetwork(value: string);
    resetAuthorizedNetwork(): void;
    get authorizedNetworkInput(): string | undefined;
    private _billingType?;
    get billingType(): string;
    set billingType(value: string);
    resetBillingType(): void;
    get billingTypeInput(): string | undefined;
    get caCertificate(): string;
    private _controlPlaneEncryptionKeyName?;
    get controlPlaneEncryptionKeyName(): string;
    set controlPlaneEncryptionKeyName(value: string);
    resetControlPlaneEncryptionKeyName(): void;
    get controlPlaneEncryptionKeyNameInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disableVpcPeering?;
    get disableVpcPeering(): boolean | cdktn.IResolvable;
    set disableVpcPeering(value: boolean | cdktn.IResolvable);
    resetDisableVpcPeering(): void;
    get disableVpcPeeringInput(): boolean | cdktn.IResolvable | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _retention?;
    get retention(): string;
    set retention(value: string);
    resetRetention(): void;
    get retentionInput(): string | undefined;
    private _runtimeDatabaseEncryptionKeyName?;
    get runtimeDatabaseEncryptionKeyName(): string;
    set runtimeDatabaseEncryptionKeyName(value: string);
    resetRuntimeDatabaseEncryptionKeyName(): void;
    get runtimeDatabaseEncryptionKeyNameInput(): string | undefined;
    private _runtimeType?;
    get runtimeType(): string;
    set runtimeType(value: string);
    resetRuntimeType(): void;
    get runtimeTypeInput(): string | undefined;
    get subscriptionType(): string;
    private _properties;
    get properties(): ApigeeOrganizationPropertiesOutputReference;
    putProperties(value: ApigeeOrganizationProperties): void;
    resetProperties(): void;
    get propertiesInput(): ApigeeOrganizationProperties | undefined;
    private _timeouts;
    get timeouts(): ApigeeOrganizationTimeoutsOutputReference;
    putTimeouts(value: ApigeeOrganizationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApigeeOrganizationTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
