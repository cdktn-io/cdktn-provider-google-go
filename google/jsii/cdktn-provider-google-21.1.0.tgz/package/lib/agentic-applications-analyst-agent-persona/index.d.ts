/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AgenticApplicationsAnalystAgentPersonaConfig extends cdktn.TerraformMetaArguments {
    /**
    * Id of the requesting object
    * If auto-generating Id server-side, remove this field and
    * analyst_agent_persona_id from the method_signature of Create RPC
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#analyst_agent_persona_id AgenticApplicationsAnalystAgentPersona#analyst_agent_persona_id}
    */
    readonly analystAgentPersonaId: string;
    /**
    * The customer-specific context to be used by the agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#customer_context AgenticApplicationsAnalystAgentPersona#customer_context}
    */
    readonly customerContext?: string[];
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#deletion_policy AgenticApplicationsAnalystAgentPersona#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The description of the persona, shown to users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#display_description AgenticApplicationsAnalystAgentPersona#display_description}
    */
    readonly displayDescription?: string;
    /**
    * The display name of the persona, shown to users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#display_name AgenticApplicationsAnalystAgentPersona#display_name}
    */
    readonly displayName: string;
    /**
    * The Gemini Enterprise Engine ID associated with this persona.
    * If set, any requests coming from this GE Engine will be routed to this
    * persona.
    * If not set, requests from GE will only be routed to this persona if its
    * name ends in "/default".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#gemini_enterprise_engine AgenticApplicationsAnalystAgentPersona#gemini_enterprise_engine}
    */
    readonly geminiEnterpriseEngine?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#id AgenticApplicationsAnalystAgentPersona#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#location AgenticApplicationsAnalystAgentPersona#location}
    */
    readonly location: string;
    /**
    * The math rendering mode selected for this persona.
    * Possible values:
    * MATH_RENDERING_MODE_LATEX
    * MATH_RENDERING_MODE_PLAIN_TEXT
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#math_rendering_mode AgenticApplicationsAnalystAgentPersona#math_rendering_mode}
    */
    readonly mathRenderingMode?: string;
    /**
    * The description of the persona review, used by the model.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#model_description AgenticApplicationsAnalystAgentPersona#model_description}
    */
    readonly modelDescription?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#project AgenticApplicationsAnalystAgentPersona#project}
    */
    readonly project?: string;
    /**
    * Possible values:
    * ANALYST_ROLE_GENERIC_FINANCE_ANALYST
    * ANALYST_ROLE_CORPORATE_FINANCE_ANALYST
    * ANALYST_ROLE_CROSS_ASSET_DERIVATIVES_STRATEGIST
    * ANALYST_ROLE_KYC_ANALYST
    * ANALYST_ROLE_SALES_TRADER
    * ANALYST_ROLE_QUANT_ANALYST
    * ANALYST_ROLE_EXCHANGE_MANAGER
    * ANALYST_ROLE_PORTFOLIO_MANAGER
    * ANALYST_ROLE_WEALTH_MANAGER
    * ANALYST_ROLE_INSTITUTIONAL_PORTFOLIO_STRATEGIST
    * ANALYST_ROLE_MNA_EXECUTION_ANALYST
    * ANALYST_ROLE_ECM_ORIGINATION_STRATEGIST
    * ANALYST_ROLE_LEVERAGED_FINANCE_SPECIALIST
    * ANALYST_ROLE_INVESTMENT_RESEARCH_ANALYST
    * ANALYST_ROLE_CORPORATE_BANKING_ANALYST
    * ANALYST_ROLE_CREDIT_RISK_STRATEGIST
    * ANALYST_ROLE_BEHAVIORAL_FINANCIAL_STRATEGIST
    * ANALYST_ROLE_FUND_ACCOUNTANT
    * ANALYST_ROLE_MODEL_VALIDATION_AUDITOR
    * ANALYST_ROLE_PRIVATE_EQUITY_SPECIALIST
    * ANALYST_ROLE_TREASURY_ANALYST
    * ANALYST_ROLE_VENTURE_CAPITAL_ANALYST
    * ANALYST_ROLE_AML_INVESTIGATOR
    * ANALYST_ROLE_DUE_DILIGENCE_ANALYST
    * ANALYST_ROLE_INSURANCE_CLAIMS_ANALYST
    * ANALYST_ROLE_SPECIALTY_LIABILITY_UNDERWRITER
    * ANALYST_ROLE_CATASTROPHE_EXPOSURE_MODELER
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#role AgenticApplicationsAnalystAgentPersona#role}
    */
    readonly role?: string;
    /**
    * artifact_examples block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#artifact_examples AgenticApplicationsAnalystAgentPersona#artifact_examples}
    */
    readonly artifactExamples?: AgenticApplicationsAnalystAgentPersonaArtifactExamples[] | cdktn.IResolvable;
    /**
    * artifacts_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#artifacts_config AgenticApplicationsAnalystAgentPersona#artifacts_config}
    */
    readonly artifactsConfig?: AgenticApplicationsAnalystAgentPersonaArtifactsConfig;
    /**
    * external_data_sources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#external_data_sources AgenticApplicationsAnalystAgentPersona#external_data_sources}
    */
    readonly externalDataSources?: AgenticApplicationsAnalystAgentPersonaExternalDataSources[] | cdktn.IResolvable;
    /**
    * mcp_data_sources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#mcp_data_sources AgenticApplicationsAnalystAgentPersona#mcp_data_sources}
    */
    readonly mcpDataSources?: AgenticApplicationsAnalystAgentPersonaMcpDataSources[] | cdktn.IResolvable;
    /**
    * resources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#resources AgenticApplicationsAnalystAgentPersona#resources}
    */
    readonly resources?: AgenticApplicationsAnalystAgentPersonaResources[] | cdktn.IResolvable;
    /**
    * skills block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#skills AgenticApplicationsAnalystAgentPersona#skills}
    */
    readonly skills?: AgenticApplicationsAnalystAgentPersonaSkills[] | cdktn.IResolvable;
    /**
    * tables block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#tables AgenticApplicationsAnalystAgentPersona#tables}
    */
    readonly tables?: AgenticApplicationsAnalystAgentPersonaTables[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#timeouts AgenticApplicationsAnalystAgentPersona#timeouts}
    */
    readonly timeouts?: AgenticApplicationsAnalystAgentPersonaTimeouts;
    /**
    * web_search_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#web_search_config AgenticApplicationsAnalystAgentPersona#web_search_config}
    */
    readonly webSearchConfig?: AgenticApplicationsAnalystAgentPersonaWebSearchConfig;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceBigqueryResource {
    /**
    * Points to a bigquery dataset to use.
    *
    * Expected Format:
    * projects/{project_id_or_number}/datasets/{dataset_id}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#bigquery_dataset AgenticApplicationsAnalystAgentPersona#bigquery_dataset}
    */
    readonly bigqueryDataset?: string;
    /**
    * Points to a bigquery table to use.
    *
    * Expected Format:
    * projects/{project_id_or_number}/datasets/{dataset_id}/tables/{table_id}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#bigquery_table AgenticApplicationsAnalystAgentPersona#bigquery_table}
    */
    readonly bigqueryTable?: string;
    /**
    * A map of column names to column descriptions for the bigquery_table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#column_descriptions AgenticApplicationsAnalystAgentPersona#column_descriptions}
    */
    readonly columnDescriptions?: {
        [key: string]: string;
    };
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactExamplesResourceBigqueryResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceBigqueryResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceBigqueryResource): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactExamplesResourceBigqueryResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceBigqueryResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceBigqueryResource): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceBigqueryResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceBigqueryResource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceBigqueryResource | undefined);
    private _bigqueryDataset?;
    get bigqueryDataset(): string;
    set bigqueryDataset(value: string);
    resetBigqueryDataset(): void;
    get bigqueryDatasetInput(): string | undefined;
    private _bigqueryTable?;
    get bigqueryTable(): string;
    set bigqueryTable(value: string);
    resetBigqueryTable(): void;
    get bigqueryTableInput(): string | undefined;
    private _columnDescriptions?;
    get columnDescriptions(): {
        [key: string]: string;
    };
    set columnDescriptions(value: {
        [key: string]: string;
    });
    resetColumnDescriptions(): void;
    get columnDescriptionsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceF1Resource {
    /**
    * ## - Points to an f1 table to use.
    *
    * - Expected Format:
    * - {group}.{table_name}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#f1_table AgenticApplicationsAnalystAgentPersona#f1_table}
    */
    readonly f1Table?: string;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactExamplesResourceF1ResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceF1ResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceF1Resource): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactExamplesResourceF1ResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceF1ResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceF1Resource): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceF1ResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceF1Resource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceF1Resource | undefined);
    private _f1Table?;
    get f1Table(): string;
    set f1Table(value: string);
    resetF1Table(): void;
    get f1TableInput(): string | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleCloudStorageResource {
    /**
    * If non-empty, only files with these extensions are included when
    * expanding the resource.  If empty, all files are included.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#file_extension_restrictions AgenticApplicationsAnalystAgentPersona#file_extension_restrictions}
    */
    readonly fileExtensionRestrictions?: string[];
    /**
    * The Google Cloud Storage object or folder.
    *
    * Format: /
    * or: //
    *
    * Note that to refer to a folder, it _must_ end in a slash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#google_cloud_storage_object AgenticApplicationsAnalystAgentPersona#google_cloud_storage_object}
    */
    readonly googleCloudStorageObject: string;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleCloudStorageResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleCloudStorageResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleCloudStorageResource): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleCloudStorageResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleCloudStorageResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleCloudStorageResource): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleCloudStorageResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleCloudStorageResource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleCloudStorageResource | undefined);
    private _fileExtensionRestrictions?;
    get fileExtensionRestrictions(): string[];
    set fileExtensionRestrictions(value: string[]);
    resetFileExtensionRestrictions(): void;
    get fileExtensionRestrictionsInput(): string[] | undefined;
    private _googleCloudStorageObject?;
    get googleCloudStorageObject(): string;
    set googleCloudStorageObject(value: string);
    get googleCloudStorageObjectInput(): string | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleDriveResource {
    /**
    * If non-empty, only files with these extensions are included when
    * expanding the resource.  If empty, all files are included.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#file_extension_restrictions AgenticApplicationsAnalystAgentPersona#file_extension_restrictions}
    */
    readonly fileExtensionRestrictions?: string[];
    /**
    * Points to a drive file to use. May refer to workspace files or folders
    * as well.  If folder is specifically, all files in the folder
    * (recursively) are used.
    *
    * Expected Format:
    * files/{file_id}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#file_reference AgenticApplicationsAnalystAgentPersona#file_reference}
    */
    readonly fileReference?: string;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleDriveResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleDriveResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleDriveResource): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleDriveResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleDriveResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleDriveResource): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleDriveResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleDriveResource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleDriveResource | undefined);
    private _fileExtensionRestrictions?;
    get fileExtensionRestrictions(): string[];
    set fileExtensionRestrictions(value: string[]);
    resetFileExtensionRestrictions(): void;
    get fileExtensionRestrictionsInput(): string[] | undefined;
    private _fileReference?;
    get fileReference(): string;
    set fileReference(value: string);
    resetFileReference(): void;
    get fileReferenceInput(): string | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceRawFileResource {
    /**
    * The raw file content.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#file_content AgenticApplicationsAnalystAgentPersona#file_content}
    */
    readonly fileContent: string;
    /**
    * The title of the file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#file_title AgenticApplicationsAnalystAgentPersona#file_title}
    */
    readonly fileTitle: string;
    /**
    * The mime type of the file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#mime_type AgenticApplicationsAnalystAgentPersona#mime_type}
    */
    readonly mimeType: string;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactExamplesResourceRawFileResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceRawFileResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceRawFileResource): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactExamplesResourceRawFileResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceRawFileResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceRawFileResource): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceRawFileResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceRawFileResource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceRawFileResource | undefined);
    private _fileContent?;
    get fileContent(): string;
    set fileContent(value: string);
    get fileContentInput(): string | undefined;
    private _fileTitle?;
    get fileTitle(): string;
    set fileTitle(value: string);
    get fileTitleInput(): string | undefined;
    private _mimeType?;
    get mimeType(): string;
    set mimeType(value: string);
    get mimeTypeInput(): string | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactExamplesResource {
    /**
    * A user-friendly name for this resource. This can be shown to the user
    * and used by the model.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#display_label AgenticApplicationsAnalystAgentPersona#display_label}
    */
    readonly displayLabel?: string;
    /**
    * A description of the resource. The model may use this, it will not be
    * shown to users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#model_description AgenticApplicationsAnalystAgentPersona#model_description}
    */
    readonly modelDescription?: string;
    /**
    * If true, use RAG to retrieve relevant information from the resources.
    *
    * Must only be set for file-based resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#use_rag AgenticApplicationsAnalystAgentPersona#use_rag}
    */
    readonly useRag?: boolean | cdktn.IResolvable;
    /**
    * bigquery_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#bigquery_resource AgenticApplicationsAnalystAgentPersona#bigquery_resource}
    */
    readonly bigqueryResource?: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceBigqueryResource;
    /**
    * f1_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#f1_resource AgenticApplicationsAnalystAgentPersona#f1_resource}
    */
    readonly f1Resource?: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceF1Resource;
    /**
    * google_cloud_storage_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#google_cloud_storage_resource AgenticApplicationsAnalystAgentPersona#google_cloud_storage_resource}
    */
    readonly googleCloudStorageResource?: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleCloudStorageResource;
    /**
    * google_drive_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#google_drive_resource AgenticApplicationsAnalystAgentPersona#google_drive_resource}
    */
    readonly googleDriveResource?: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleDriveResource;
    /**
    * raw_file_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#raw_file_resource AgenticApplicationsAnalystAgentPersona#raw_file_resource}
    */
    readonly rawFileResource?: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceRawFileResource;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactExamplesResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactExamplesResource): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactExamplesResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactExamplesResource): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactExamplesResource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResource | undefined);
    private _displayLabel?;
    get displayLabel(): string;
    set displayLabel(value: string);
    resetDisplayLabel(): void;
    get displayLabelInput(): string | undefined;
    private _modelDescription?;
    get modelDescription(): string;
    set modelDescription(value: string);
    resetModelDescription(): void;
    get modelDescriptionInput(): string | undefined;
    private _useRag?;
    get useRag(): boolean | cdktn.IResolvable;
    set useRag(value: boolean | cdktn.IResolvable);
    resetUseRag(): void;
    get useRagInput(): boolean | cdktn.IResolvable | undefined;
    private _bigqueryResource;
    get bigqueryResource(): AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceBigqueryResourceOutputReference;
    putBigqueryResource(value: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceBigqueryResource): void;
    resetBigqueryResource(): void;
    get bigqueryResourceInput(): AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceBigqueryResource | undefined;
    private _f1Resource;
    get f1Resource(): AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceF1ResourceOutputReference;
    putF1Resource(value: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceF1Resource): void;
    resetF1Resource(): void;
    get f1ResourceInput(): AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceF1Resource | undefined;
    private _googleCloudStorageResource;
    get googleCloudStorageResource(): AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleCloudStorageResourceOutputReference;
    putGoogleCloudStorageResource(value: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleCloudStorageResource): void;
    resetGoogleCloudStorageResource(): void;
    get googleCloudStorageResourceInput(): AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleCloudStorageResource | undefined;
    private _googleDriveResource;
    get googleDriveResource(): AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleDriveResourceOutputReference;
    putGoogleDriveResource(value: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleDriveResource): void;
    resetGoogleDriveResource(): void;
    get googleDriveResourceInput(): AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceGoogleDriveResource | undefined;
    private _rawFileResource;
    get rawFileResource(): AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceRawFileResourceOutputReference;
    putRawFileResource(value: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceRawFileResource): void;
    resetRawFileResource(): void;
    get rawFileResourceInput(): AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceRawFileResource | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactExamples {
    /**
    * resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#resource AgenticApplicationsAnalystAgentPersona#resource}
    */
    readonly resource: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResource;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactExamplesToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactExamples | cdktn.IResolvable): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactExamplesToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactExamples | cdktn.IResolvable): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactExamplesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactExamples | cdktn.IResolvable | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactExamples | cdktn.IResolvable | undefined);
    private _resource;
    get resource(): AgenticApplicationsAnalystAgentPersonaArtifactExamplesResourceOutputReference;
    putResource(value: AgenticApplicationsAnalystAgentPersonaArtifactExamplesResource): void;
    get resourceInput(): AgenticApplicationsAnalystAgentPersonaArtifactExamplesResource | undefined;
}
export declare class AgenticApplicationsAnalystAgentPersonaArtifactExamplesList extends cdktn.ComplexList {
    internalValue?: AgenticApplicationsAnalystAgentPersonaArtifactExamples[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AgenticApplicationsAnalystAgentPersonaArtifactExamplesOutputReference;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceBigqueryResource {
    /**
    * Points to a bigquery dataset to use.
    *
    * Expected Format:
    * projects/{project_id_or_number}/datasets/{dataset_id}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#bigquery_dataset AgenticApplicationsAnalystAgentPersona#bigquery_dataset}
    */
    readonly bigqueryDataset?: string;
    /**
    * Points to a bigquery table to use.
    *
    * Expected Format:
    * projects/{project_id_or_number}/datasets/{dataset_id}/tables/{table_id}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#bigquery_table AgenticApplicationsAnalystAgentPersona#bigquery_table}
    */
    readonly bigqueryTable?: string;
    /**
    * A map of column names to column descriptions for the bigquery_table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#column_descriptions AgenticApplicationsAnalystAgentPersona#column_descriptions}
    */
    readonly columnDescriptions?: {
        [key: string]: string;
    };
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceBigqueryResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceBigqueryResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceBigqueryResource): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceBigqueryResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceBigqueryResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceBigqueryResource): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceBigqueryResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceBigqueryResource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceBigqueryResource | undefined);
    private _bigqueryDataset?;
    get bigqueryDataset(): string;
    set bigqueryDataset(value: string);
    resetBigqueryDataset(): void;
    get bigqueryDatasetInput(): string | undefined;
    private _bigqueryTable?;
    get bigqueryTable(): string;
    set bigqueryTable(value: string);
    resetBigqueryTable(): void;
    get bigqueryTableInput(): string | undefined;
    private _columnDescriptions?;
    get columnDescriptions(): {
        [key: string]: string;
    };
    set columnDescriptions(value: {
        [key: string]: string;
    });
    resetColumnDescriptions(): void;
    get columnDescriptionsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceF1Resource {
    /**
    * ## - Points to an f1 table to use.
    *
    * - Expected Format:
    * - {group}.{table_name}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#f1_table AgenticApplicationsAnalystAgentPersona#f1_table}
    */
    readonly f1Table?: string;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceF1ResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceF1ResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceF1Resource): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceF1ResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceF1ResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceF1Resource): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceF1ResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceF1Resource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceF1Resource | undefined);
    private _f1Table?;
    get f1Table(): string;
    set f1Table(value: string);
    resetF1Table(): void;
    get f1TableInput(): string | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleCloudStorageResource {
    /**
    * If non-empty, only files with these extensions are included when
    * expanding the resource.  If empty, all files are included.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#file_extension_restrictions AgenticApplicationsAnalystAgentPersona#file_extension_restrictions}
    */
    readonly fileExtensionRestrictions?: string[];
    /**
    * The Google Cloud Storage object or folder.
    *
    * Format: /
    * or: //
    *
    * Note that to refer to a folder, it _must_ end in a slash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#google_cloud_storage_object AgenticApplicationsAnalystAgentPersona#google_cloud_storage_object}
    */
    readonly googleCloudStorageObject: string;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleCloudStorageResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleCloudStorageResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleCloudStorageResource): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleCloudStorageResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleCloudStorageResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleCloudStorageResource): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleCloudStorageResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleCloudStorageResource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleCloudStorageResource | undefined);
    private _fileExtensionRestrictions?;
    get fileExtensionRestrictions(): string[];
    set fileExtensionRestrictions(value: string[]);
    resetFileExtensionRestrictions(): void;
    get fileExtensionRestrictionsInput(): string[] | undefined;
    private _googleCloudStorageObject?;
    get googleCloudStorageObject(): string;
    set googleCloudStorageObject(value: string);
    get googleCloudStorageObjectInput(): string | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleDriveResource {
    /**
    * If non-empty, only files with these extensions are included when
    * expanding the resource.  If empty, all files are included.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#file_extension_restrictions AgenticApplicationsAnalystAgentPersona#file_extension_restrictions}
    */
    readonly fileExtensionRestrictions?: string[];
    /**
    * Points to a drive file to use. May refer to workspace files or folders
    * as well.  If folder is specifically, all files in the folder
    * (recursively) are used.
    *
    * Expected Format:
    * files/{file_id}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#file_reference AgenticApplicationsAnalystAgentPersona#file_reference}
    */
    readonly fileReference?: string;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleDriveResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleDriveResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleDriveResource): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleDriveResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleDriveResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleDriveResource): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleDriveResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleDriveResource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleDriveResource | undefined);
    private _fileExtensionRestrictions?;
    get fileExtensionRestrictions(): string[];
    set fileExtensionRestrictions(value: string[]);
    resetFileExtensionRestrictions(): void;
    get fileExtensionRestrictionsInput(): string[] | undefined;
    private _fileReference?;
    get fileReference(): string;
    set fileReference(value: string);
    resetFileReference(): void;
    get fileReferenceInput(): string | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceRawFileResource {
    /**
    * The raw file content.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#file_content AgenticApplicationsAnalystAgentPersona#file_content}
    */
    readonly fileContent: string;
    /**
    * The title of the file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#file_title AgenticApplicationsAnalystAgentPersona#file_title}
    */
    readonly fileTitle: string;
    /**
    * The mime type of the file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#mime_type AgenticApplicationsAnalystAgentPersona#mime_type}
    */
    readonly mimeType: string;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceRawFileResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceRawFileResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceRawFileResource): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceRawFileResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceRawFileResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceRawFileResource): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceRawFileResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceRawFileResource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceRawFileResource | undefined);
    private _fileContent?;
    get fileContent(): string;
    set fileContent(value: string);
    get fileContentInput(): string | undefined;
    private _fileTitle?;
    get fileTitle(): string;
    set fileTitle(value: string);
    get fileTitleInput(): string | undefined;
    private _mimeType?;
    get mimeType(): string;
    set mimeType(value: string);
    get mimeTypeInput(): string | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResource {
    /**
    * A user-friendly name for this resource. This can be shown to the user
    * and used by the model.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#display_label AgenticApplicationsAnalystAgentPersona#display_label}
    */
    readonly displayLabel?: string;
    /**
    * A description of the resource. The model may use this, it will not be
    * shown to users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#model_description AgenticApplicationsAnalystAgentPersona#model_description}
    */
    readonly modelDescription?: string;
    /**
    * If true, use RAG to retrieve relevant information from the resources.
    *
    * Must only be set for file-based resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#use_rag AgenticApplicationsAnalystAgentPersona#use_rag}
    */
    readonly useRag?: boolean | cdktn.IResolvable;
    /**
    * bigquery_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#bigquery_resource AgenticApplicationsAnalystAgentPersona#bigquery_resource}
    */
    readonly bigqueryResource?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceBigqueryResource;
    /**
    * f1_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#f1_resource AgenticApplicationsAnalystAgentPersona#f1_resource}
    */
    readonly f1Resource?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceF1Resource;
    /**
    * google_cloud_storage_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#google_cloud_storage_resource AgenticApplicationsAnalystAgentPersona#google_cloud_storage_resource}
    */
    readonly googleCloudStorageResource?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleCloudStorageResource;
    /**
    * google_drive_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#google_drive_resource AgenticApplicationsAnalystAgentPersona#google_drive_resource}
    */
    readonly googleDriveResource?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleDriveResource;
    /**
    * raw_file_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#raw_file_resource AgenticApplicationsAnalystAgentPersona#raw_file_resource}
    */
    readonly rawFileResource?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceRawFileResource;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResource): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResource): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResource | undefined);
    private _displayLabel?;
    get displayLabel(): string;
    set displayLabel(value: string);
    resetDisplayLabel(): void;
    get displayLabelInput(): string | undefined;
    private _modelDescription?;
    get modelDescription(): string;
    set modelDescription(value: string);
    resetModelDescription(): void;
    get modelDescriptionInput(): string | undefined;
    private _useRag?;
    get useRag(): boolean | cdktn.IResolvable;
    set useRag(value: boolean | cdktn.IResolvable);
    resetUseRag(): void;
    get useRagInput(): boolean | cdktn.IResolvable | undefined;
    private _bigqueryResource;
    get bigqueryResource(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceBigqueryResourceOutputReference;
    putBigqueryResource(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceBigqueryResource): void;
    resetBigqueryResource(): void;
    get bigqueryResourceInput(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceBigqueryResource | undefined;
    private _f1Resource;
    get f1Resource(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceF1ResourceOutputReference;
    putF1Resource(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceF1Resource): void;
    resetF1Resource(): void;
    get f1ResourceInput(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceF1Resource | undefined;
    private _googleCloudStorageResource;
    get googleCloudStorageResource(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleCloudStorageResourceOutputReference;
    putGoogleCloudStorageResource(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleCloudStorageResource): void;
    resetGoogleCloudStorageResource(): void;
    get googleCloudStorageResourceInput(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleCloudStorageResource | undefined;
    private _googleDriveResource;
    get googleDriveResource(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleDriveResourceOutputReference;
    putGoogleDriveResource(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleDriveResource): void;
    resetGoogleDriveResource(): void;
    get googleDriveResourceInput(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceGoogleDriveResource | undefined;
    private _rawFileResource;
    get rawFileResource(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceRawFileResourceOutputReference;
    putRawFileResource(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceRawFileResource): void;
    resetRawFileResource(): void;
    get rawFileResourceInput(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceRawFileResource | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamples {
    /**
    * resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#resource AgenticApplicationsAnalystAgentPersona#resource}
    */
    readonly resource: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResource;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamples | cdktn.IResolvable): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamples | cdktn.IResolvable): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamples | cdktn.IResolvable | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamples | cdktn.IResolvable | undefined);
    private _resource;
    get resource(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResourceOutputReference;
    putResource(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResource): void;
    get resourceInput(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesResource | undefined;
}
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesList extends cdktn.ComplexList {
    internalValue?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamples[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesOutputReference;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptions {
    /**
    * Format for document export.
    * Possible values:
    * PDF
    * DOCX
    * GOOGLE_DOCS
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#export_format AgenticApplicationsAnalystAgentPersona#export_format}
    */
    readonly exportFormat?: string;
    /**
    * document_examples block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#document_examples AgenticApplicationsAnalystAgentPersona#document_examples}
    */
    readonly documentExamples?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamples[] | cdktn.IResolvable;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptions): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptions): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptions | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptions | undefined);
    private _exportFormat?;
    get exportFormat(): string;
    set exportFormat(value: string);
    resetExportFormat(): void;
    get exportFormatInput(): string | undefined;
    private _documentExamples;
    get documentExamples(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamplesList;
    putDocumentExamples(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamples[] | cdktn.IResolvable): void;
    resetDocumentExamples(): void;
    get documentExamplesInput(): cdktn.IResolvable | AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsDocumentExamples[] | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactsConfigMethodologyExportOptions {
    /**
    * If true, append the detailed methodology to the final response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#append_methodology AgenticApplicationsAnalystAgentPersona#append_methodology}
    */
    readonly appendMethodology?: boolean | cdktn.IResolvable;
    /**
    * Format for methodology export.
    * Possible values:
    * MARKDOWN
    * HTML
    * PDF
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#export_format AgenticApplicationsAnalystAgentPersona#export_format}
    */
    readonly exportFormat?: string;
    /**
    * If true, export the detailed methodology as a separate artifact.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#export_methodology_artifact AgenticApplicationsAnalystAgentPersona#export_methodology_artifact}
    */
    readonly exportMethodologyArtifact?: boolean | cdktn.IResolvable;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigMethodologyExportOptionsToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigMethodologyExportOptionsOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigMethodologyExportOptions): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigMethodologyExportOptionsToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigMethodologyExportOptionsOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigMethodologyExportOptions): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigMethodologyExportOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigMethodologyExportOptions | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigMethodologyExportOptions | undefined);
    private _appendMethodology?;
    get appendMethodology(): boolean | cdktn.IResolvable;
    set appendMethodology(value: boolean | cdktn.IResolvable);
    resetAppendMethodology(): void;
    get appendMethodologyInput(): boolean | cdktn.IResolvable | undefined;
    private _exportFormat?;
    get exportFormat(): string;
    set exportFormat(value: string);
    resetExportFormat(): void;
    get exportFormatInput(): string | undefined;
    private _exportMethodologyArtifact?;
    get exportMethodologyArtifact(): boolean | cdktn.IResolvable;
    set exportMethodologyArtifact(value: boolean | cdktn.IResolvable);
    resetExportMethodologyArtifact(): void;
    get exportMethodologyArtifactInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceBigqueryResource {
    /**
    * Points to a bigquery dataset to use.
    *
    * Expected Format:
    * projects/{project_id_or_number}/datasets/{dataset_id}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#bigquery_dataset AgenticApplicationsAnalystAgentPersona#bigquery_dataset}
    */
    readonly bigqueryDataset?: string;
    /**
    * Points to a bigquery table to use.
    *
    * Expected Format:
    * projects/{project_id_or_number}/datasets/{dataset_id}/tables/{table_id}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#bigquery_table AgenticApplicationsAnalystAgentPersona#bigquery_table}
    */
    readonly bigqueryTable?: string;
    /**
    * A map of column names to column descriptions for the bigquery_table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#column_descriptions AgenticApplicationsAnalystAgentPersona#column_descriptions}
    */
    readonly columnDescriptions?: {
        [key: string]: string;
    };
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceBigqueryResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceBigqueryResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceBigqueryResource): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceBigqueryResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceBigqueryResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceBigqueryResource): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceBigqueryResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceBigqueryResource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceBigqueryResource | undefined);
    private _bigqueryDataset?;
    get bigqueryDataset(): string;
    set bigqueryDataset(value: string);
    resetBigqueryDataset(): void;
    get bigqueryDatasetInput(): string | undefined;
    private _bigqueryTable?;
    get bigqueryTable(): string;
    set bigqueryTable(value: string);
    resetBigqueryTable(): void;
    get bigqueryTableInput(): string | undefined;
    private _columnDescriptions?;
    get columnDescriptions(): {
        [key: string]: string;
    };
    set columnDescriptions(value: {
        [key: string]: string;
    });
    resetColumnDescriptions(): void;
    get columnDescriptionsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceF1Resource {
    /**
    * ## - Points to an f1 table to use.
    *
    * - Expected Format:
    * - {group}.{table_name}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#f1_table AgenticApplicationsAnalystAgentPersona#f1_table}
    */
    readonly f1Table?: string;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceF1ResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceF1ResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceF1Resource): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceF1ResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceF1ResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceF1Resource): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceF1ResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceF1Resource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceF1Resource | undefined);
    private _f1Table?;
    get f1Table(): string;
    set f1Table(value: string);
    resetF1Table(): void;
    get f1TableInput(): string | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleCloudStorageResource {
    /**
    * If non-empty, only files with these extensions are included when
    * expanding the resource.  If empty, all files are included.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#file_extension_restrictions AgenticApplicationsAnalystAgentPersona#file_extension_restrictions}
    */
    readonly fileExtensionRestrictions?: string[];
    /**
    * The Google Cloud Storage object or folder.
    *
    * Format: /
    * or: //
    *
    * Note that to refer to a folder, it _must_ end in a slash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#google_cloud_storage_object AgenticApplicationsAnalystAgentPersona#google_cloud_storage_object}
    */
    readonly googleCloudStorageObject: string;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleCloudStorageResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleCloudStorageResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleCloudStorageResource): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleCloudStorageResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleCloudStorageResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleCloudStorageResource): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleCloudStorageResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleCloudStorageResource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleCloudStorageResource | undefined);
    private _fileExtensionRestrictions?;
    get fileExtensionRestrictions(): string[];
    set fileExtensionRestrictions(value: string[]);
    resetFileExtensionRestrictions(): void;
    get fileExtensionRestrictionsInput(): string[] | undefined;
    private _googleCloudStorageObject?;
    get googleCloudStorageObject(): string;
    set googleCloudStorageObject(value: string);
    get googleCloudStorageObjectInput(): string | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleDriveResource {
    /**
    * If non-empty, only files with these extensions are included when
    * expanding the resource.  If empty, all files are included.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#file_extension_restrictions AgenticApplicationsAnalystAgentPersona#file_extension_restrictions}
    */
    readonly fileExtensionRestrictions?: string[];
    /**
    * Points to a drive file to use. May refer to workspace files or folders
    * as well.  If folder is specifically, all files in the folder
    * (recursively) are used.
    *
    * Expected Format:
    * files/{file_id}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#file_reference AgenticApplicationsAnalystAgentPersona#file_reference}
    */
    readonly fileReference?: string;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleDriveResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleDriveResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleDriveResource): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleDriveResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleDriveResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleDriveResource): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleDriveResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleDriveResource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleDriveResource | undefined);
    private _fileExtensionRestrictions?;
    get fileExtensionRestrictions(): string[];
    set fileExtensionRestrictions(value: string[]);
    resetFileExtensionRestrictions(): void;
    get fileExtensionRestrictionsInput(): string[] | undefined;
    private _fileReference?;
    get fileReference(): string;
    set fileReference(value: string);
    resetFileReference(): void;
    get fileReferenceInput(): string | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceRawFileResource {
    /**
    * The raw file content.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#file_content AgenticApplicationsAnalystAgentPersona#file_content}
    */
    readonly fileContent: string;
    /**
    * The title of the file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#file_title AgenticApplicationsAnalystAgentPersona#file_title}
    */
    readonly fileTitle: string;
    /**
    * The mime type of the file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#mime_type AgenticApplicationsAnalystAgentPersona#mime_type}
    */
    readonly mimeType: string;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceRawFileResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceRawFileResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceRawFileResource): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceRawFileResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceRawFileResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceRawFileResource): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceRawFileResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceRawFileResource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceRawFileResource | undefined);
    private _fileContent?;
    get fileContent(): string;
    set fileContent(value: string);
    get fileContentInput(): string | undefined;
    private _fileTitle?;
    get fileTitle(): string;
    set fileTitle(value: string);
    get fileTitleInput(): string | undefined;
    private _mimeType?;
    get mimeType(): string;
    set mimeType(value: string);
    get mimeTypeInput(): string | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResource {
    /**
    * A user-friendly name for this resource. This can be shown to the user
    * and used by the model.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#display_label AgenticApplicationsAnalystAgentPersona#display_label}
    */
    readonly displayLabel?: string;
    /**
    * A description of the resource. The model may use this, it will not be
    * shown to users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#model_description AgenticApplicationsAnalystAgentPersona#model_description}
    */
    readonly modelDescription?: string;
    /**
    * If true, use RAG to retrieve relevant information from the resources.
    *
    * Must only be set for file-based resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#use_rag AgenticApplicationsAnalystAgentPersona#use_rag}
    */
    readonly useRag?: boolean | cdktn.IResolvable;
    /**
    * bigquery_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#bigquery_resource AgenticApplicationsAnalystAgentPersona#bigquery_resource}
    */
    readonly bigqueryResource?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceBigqueryResource;
    /**
    * f1_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#f1_resource AgenticApplicationsAnalystAgentPersona#f1_resource}
    */
    readonly f1Resource?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceF1Resource;
    /**
    * google_cloud_storage_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#google_cloud_storage_resource AgenticApplicationsAnalystAgentPersona#google_cloud_storage_resource}
    */
    readonly googleCloudStorageResource?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleCloudStorageResource;
    /**
    * google_drive_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#google_drive_resource AgenticApplicationsAnalystAgentPersona#google_drive_resource}
    */
    readonly googleDriveResource?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleDriveResource;
    /**
    * raw_file_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#raw_file_resource AgenticApplicationsAnalystAgentPersona#raw_file_resource}
    */
    readonly rawFileResource?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceRawFileResource;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResource): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResource): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResource | undefined);
    private _displayLabel?;
    get displayLabel(): string;
    set displayLabel(value: string);
    resetDisplayLabel(): void;
    get displayLabelInput(): string | undefined;
    private _modelDescription?;
    get modelDescription(): string;
    set modelDescription(value: string);
    resetModelDescription(): void;
    get modelDescriptionInput(): string | undefined;
    private _useRag?;
    get useRag(): boolean | cdktn.IResolvable;
    set useRag(value: boolean | cdktn.IResolvable);
    resetUseRag(): void;
    get useRagInput(): boolean | cdktn.IResolvable | undefined;
    private _bigqueryResource;
    get bigqueryResource(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceBigqueryResourceOutputReference;
    putBigqueryResource(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceBigqueryResource): void;
    resetBigqueryResource(): void;
    get bigqueryResourceInput(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceBigqueryResource | undefined;
    private _f1Resource;
    get f1Resource(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceF1ResourceOutputReference;
    putF1Resource(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceF1Resource): void;
    resetF1Resource(): void;
    get f1ResourceInput(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceF1Resource | undefined;
    private _googleCloudStorageResource;
    get googleCloudStorageResource(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleCloudStorageResourceOutputReference;
    putGoogleCloudStorageResource(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleCloudStorageResource): void;
    resetGoogleCloudStorageResource(): void;
    get googleCloudStorageResourceInput(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleCloudStorageResource | undefined;
    private _googleDriveResource;
    get googleDriveResource(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleDriveResourceOutputReference;
    putGoogleDriveResource(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleDriveResource): void;
    resetGoogleDriveResource(): void;
    get googleDriveResourceInput(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceGoogleDriveResource | undefined;
    private _rawFileResource;
    get rawFileResource(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceRawFileResourceOutputReference;
    putRawFileResource(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceRawFileResource): void;
    resetRawFileResource(): void;
    get rawFileResourceInput(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceRawFileResource | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamples {
    /**
    * resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#resource AgenticApplicationsAnalystAgentPersona#resource}
    */
    readonly resource: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResource;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamples | cdktn.IResolvable): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamples | cdktn.IResolvable): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamples | cdktn.IResolvable | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamples | cdktn.IResolvable | undefined);
    private _resource;
    get resource(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResourceOutputReference;
    putResource(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResource): void;
    get resourceInput(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesResource | undefined;
}
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesList extends cdktn.ComplexList {
    internalValue?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamples[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesOutputReference;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptions {
    /**
    * Format for slide export.
    * Possible values:
    * PDF
    * PNG
    * PPTX
    * GOOGLE_SLIDES
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#export_format AgenticApplicationsAnalystAgentPersona#export_format}
    */
    readonly exportFormat?: string;
    /**
    * slide_examples block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#slide_examples AgenticApplicationsAnalystAgentPersona#slide_examples}
    */
    readonly slideExamples?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamples[] | cdktn.IResolvable;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptions): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptions): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptions | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptions | undefined);
    private _exportFormat?;
    get exportFormat(): string;
    set exportFormat(value: string);
    resetExportFormat(): void;
    get exportFormatInput(): string | undefined;
    private _slideExamples;
    get slideExamples(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamplesList;
    putSlideExamples(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamples[] | cdktn.IResolvable): void;
    resetSlideExamples(): void;
    get slideExamplesInput(): cdktn.IResolvable | AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsSlideExamples[] | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceBigqueryResource {
    /**
    * Points to a bigquery dataset to use.
    *
    * Expected Format:
    * projects/{project_id_or_number}/datasets/{dataset_id}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#bigquery_dataset AgenticApplicationsAnalystAgentPersona#bigquery_dataset}
    */
    readonly bigqueryDataset?: string;
    /**
    * Points to a bigquery table to use.
    *
    * Expected Format:
    * projects/{project_id_or_number}/datasets/{dataset_id}/tables/{table_id}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#bigquery_table AgenticApplicationsAnalystAgentPersona#bigquery_table}
    */
    readonly bigqueryTable?: string;
    /**
    * A map of column names to column descriptions for the bigquery_table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#column_descriptions AgenticApplicationsAnalystAgentPersona#column_descriptions}
    */
    readonly columnDescriptions?: {
        [key: string]: string;
    };
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceBigqueryResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceBigqueryResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceBigqueryResource): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceBigqueryResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceBigqueryResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceBigqueryResource): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceBigqueryResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceBigqueryResource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceBigqueryResource | undefined);
    private _bigqueryDataset?;
    get bigqueryDataset(): string;
    set bigqueryDataset(value: string);
    resetBigqueryDataset(): void;
    get bigqueryDatasetInput(): string | undefined;
    private _bigqueryTable?;
    get bigqueryTable(): string;
    set bigqueryTable(value: string);
    resetBigqueryTable(): void;
    get bigqueryTableInput(): string | undefined;
    private _columnDescriptions?;
    get columnDescriptions(): {
        [key: string]: string;
    };
    set columnDescriptions(value: {
        [key: string]: string;
    });
    resetColumnDescriptions(): void;
    get columnDescriptionsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceF1Resource {
    /**
    * ## - Points to an f1 table to use.
    *
    * - Expected Format:
    * - {group}.{table_name}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#f1_table AgenticApplicationsAnalystAgentPersona#f1_table}
    */
    readonly f1Table?: string;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceF1ResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceF1ResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceF1Resource): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceF1ResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceF1ResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceF1Resource): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceF1ResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceF1Resource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceF1Resource | undefined);
    private _f1Table?;
    get f1Table(): string;
    set f1Table(value: string);
    resetF1Table(): void;
    get f1TableInput(): string | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleCloudStorageResource {
    /**
    * If non-empty, only files with these extensions are included when
    * expanding the resource.  If empty, all files are included.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#file_extension_restrictions AgenticApplicationsAnalystAgentPersona#file_extension_restrictions}
    */
    readonly fileExtensionRestrictions?: string[];
    /**
    * The Google Cloud Storage object or folder.
    *
    * Format: /
    * or: //
    *
    * Note that to refer to a folder, it _must_ end in a slash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#google_cloud_storage_object AgenticApplicationsAnalystAgentPersona#google_cloud_storage_object}
    */
    readonly googleCloudStorageObject: string;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleCloudStorageResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleCloudStorageResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleCloudStorageResource): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleCloudStorageResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleCloudStorageResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleCloudStorageResource): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleCloudStorageResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleCloudStorageResource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleCloudStorageResource | undefined);
    private _fileExtensionRestrictions?;
    get fileExtensionRestrictions(): string[];
    set fileExtensionRestrictions(value: string[]);
    resetFileExtensionRestrictions(): void;
    get fileExtensionRestrictionsInput(): string[] | undefined;
    private _googleCloudStorageObject?;
    get googleCloudStorageObject(): string;
    set googleCloudStorageObject(value: string);
    get googleCloudStorageObjectInput(): string | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleDriveResource {
    /**
    * If non-empty, only files with these extensions are included when
    * expanding the resource.  If empty, all files are included.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#file_extension_restrictions AgenticApplicationsAnalystAgentPersona#file_extension_restrictions}
    */
    readonly fileExtensionRestrictions?: string[];
    /**
    * Points to a drive file to use. May refer to workspace files or folders
    * as well.  If folder is specifically, all files in the folder
    * (recursively) are used.
    *
    * Expected Format:
    * files/{file_id}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#file_reference AgenticApplicationsAnalystAgentPersona#file_reference}
    */
    readonly fileReference?: string;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleDriveResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleDriveResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleDriveResource): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleDriveResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleDriveResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleDriveResource): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleDriveResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleDriveResource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleDriveResource | undefined);
    private _fileExtensionRestrictions?;
    get fileExtensionRestrictions(): string[];
    set fileExtensionRestrictions(value: string[]);
    resetFileExtensionRestrictions(): void;
    get fileExtensionRestrictionsInput(): string[] | undefined;
    private _fileReference?;
    get fileReference(): string;
    set fileReference(value: string);
    resetFileReference(): void;
    get fileReferenceInput(): string | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceRawFileResource {
    /**
    * The raw file content.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#file_content AgenticApplicationsAnalystAgentPersona#file_content}
    */
    readonly fileContent: string;
    /**
    * The title of the file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#file_title AgenticApplicationsAnalystAgentPersona#file_title}
    */
    readonly fileTitle: string;
    /**
    * The mime type of the file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#mime_type AgenticApplicationsAnalystAgentPersona#mime_type}
    */
    readonly mimeType: string;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceRawFileResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceRawFileResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceRawFileResource): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceRawFileResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceRawFileResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceRawFileResource): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceRawFileResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceRawFileResource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceRawFileResource | undefined);
    private _fileContent?;
    get fileContent(): string;
    set fileContent(value: string);
    get fileContentInput(): string | undefined;
    private _fileTitle?;
    get fileTitle(): string;
    set fileTitle(value: string);
    get fileTitleInput(): string | undefined;
    private _mimeType?;
    get mimeType(): string;
    set mimeType(value: string);
    get mimeTypeInput(): string | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResource {
    /**
    * A user-friendly name for this resource. This can be shown to the user
    * and used by the model.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#display_label AgenticApplicationsAnalystAgentPersona#display_label}
    */
    readonly displayLabel?: string;
    /**
    * A description of the resource. The model may use this, it will not be
    * shown to users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#model_description AgenticApplicationsAnalystAgentPersona#model_description}
    */
    readonly modelDescription?: string;
    /**
    * If true, use RAG to retrieve relevant information from the resources.
    *
    * Must only be set for file-based resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#use_rag AgenticApplicationsAnalystAgentPersona#use_rag}
    */
    readonly useRag?: boolean | cdktn.IResolvable;
    /**
    * bigquery_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#bigquery_resource AgenticApplicationsAnalystAgentPersona#bigquery_resource}
    */
    readonly bigqueryResource?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceBigqueryResource;
    /**
    * f1_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#f1_resource AgenticApplicationsAnalystAgentPersona#f1_resource}
    */
    readonly f1Resource?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceF1Resource;
    /**
    * google_cloud_storage_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#google_cloud_storage_resource AgenticApplicationsAnalystAgentPersona#google_cloud_storage_resource}
    */
    readonly googleCloudStorageResource?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleCloudStorageResource;
    /**
    * google_drive_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#google_drive_resource AgenticApplicationsAnalystAgentPersona#google_drive_resource}
    */
    readonly googleDriveResource?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleDriveResource;
    /**
    * raw_file_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#raw_file_resource AgenticApplicationsAnalystAgentPersona#raw_file_resource}
    */
    readonly rawFileResource?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceRawFileResource;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResource): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResource): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResource | undefined);
    private _displayLabel?;
    get displayLabel(): string;
    set displayLabel(value: string);
    resetDisplayLabel(): void;
    get displayLabelInput(): string | undefined;
    private _modelDescription?;
    get modelDescription(): string;
    set modelDescription(value: string);
    resetModelDescription(): void;
    get modelDescriptionInput(): string | undefined;
    private _useRag?;
    get useRag(): boolean | cdktn.IResolvable;
    set useRag(value: boolean | cdktn.IResolvable);
    resetUseRag(): void;
    get useRagInput(): boolean | cdktn.IResolvable | undefined;
    private _bigqueryResource;
    get bigqueryResource(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceBigqueryResourceOutputReference;
    putBigqueryResource(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceBigqueryResource): void;
    resetBigqueryResource(): void;
    get bigqueryResourceInput(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceBigqueryResource | undefined;
    private _f1Resource;
    get f1Resource(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceF1ResourceOutputReference;
    putF1Resource(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceF1Resource): void;
    resetF1Resource(): void;
    get f1ResourceInput(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceF1Resource | undefined;
    private _googleCloudStorageResource;
    get googleCloudStorageResource(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleCloudStorageResourceOutputReference;
    putGoogleCloudStorageResource(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleCloudStorageResource): void;
    resetGoogleCloudStorageResource(): void;
    get googleCloudStorageResourceInput(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleCloudStorageResource | undefined;
    private _googleDriveResource;
    get googleDriveResource(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleDriveResourceOutputReference;
    putGoogleDriveResource(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleDriveResource): void;
    resetGoogleDriveResource(): void;
    get googleDriveResourceInput(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceGoogleDriveResource | undefined;
    private _rawFileResource;
    get rawFileResource(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceRawFileResourceOutputReference;
    putRawFileResource(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceRawFileResource): void;
    resetRawFileResource(): void;
    get rawFileResourceInput(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceRawFileResource | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamples {
    /**
    * The type of the visualization (e.g. "Bar Chart", "Line Chart").
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#visualization_type AgenticApplicationsAnalystAgentPersona#visualization_type}
    */
    readonly visualizationType: string;
    /**
    * resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#resource AgenticApplicationsAnalystAgentPersona#resource}
    */
    readonly resource: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResource;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamples | cdktn.IResolvable): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamples | cdktn.IResolvable): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamples | cdktn.IResolvable | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamples | cdktn.IResolvable | undefined);
    private _visualizationType?;
    get visualizationType(): string;
    set visualizationType(value: string);
    get visualizationTypeInput(): string | undefined;
    private _resource;
    get resource(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResourceOutputReference;
    putResource(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResource): void;
    get resourceInput(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesResource | undefined;
}
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesList extends cdktn.ComplexList {
    internalValue?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamples[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesOutputReference;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptions {
    /**
    * Mode for generating visualizations.
    * Possible values:
    * VISUALIZATION_MODE_EXPLICIT_ONLY
    * VISUALIZATION_MODE_WHEN_NECESSARY
    * VISUALIZATION_MODE_WHEN_HELPFUL
    * VISUALIZATION_MODE_ALWAYS
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#visualization_mode AgenticApplicationsAnalystAgentPersona#visualization_mode}
    */
    readonly visualizationMode?: string;
    /**
    * visualization_examples block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#visualization_examples AgenticApplicationsAnalystAgentPersona#visualization_examples}
    */
    readonly visualizationExamples?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamples[] | cdktn.IResolvable;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptions): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptions): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptions | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptions | undefined);
    private _visualizationMode?;
    get visualizationMode(): string;
    set visualizationMode(value: string);
    resetVisualizationMode(): void;
    get visualizationModeInput(): string | undefined;
    private _visualizationExamples;
    get visualizationExamples(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamplesList;
    putVisualizationExamples(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamples[] | cdktn.IResolvable): void;
    resetVisualizationExamples(): void;
    get visualizationExamplesInput(): cdktn.IResolvable | AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsVisualizationExamples[] | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaArtifactsConfig {
    /**
    * document_generation_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#document_generation_options AgenticApplicationsAnalystAgentPersona#document_generation_options}
    */
    readonly documentGenerationOptions?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptions;
    /**
    * methodology_export_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#methodology_export_options AgenticApplicationsAnalystAgentPersona#methodology_export_options}
    */
    readonly methodologyExportOptions?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigMethodologyExportOptions;
    /**
    * slide_generation_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#slide_generation_options AgenticApplicationsAnalystAgentPersona#slide_generation_options}
    */
    readonly slideGenerationOptions?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptions;
    /**
    * visualization_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#visualization_options AgenticApplicationsAnalystAgentPersona#visualization_options}
    */
    readonly visualizationOptions?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptions;
}
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfig): any;
export declare function agenticApplicationsAnalystAgentPersonaArtifactsConfigToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaArtifactsConfigOutputReference | AgenticApplicationsAnalystAgentPersonaArtifactsConfig): any;
export declare class AgenticApplicationsAnalystAgentPersonaArtifactsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaArtifactsConfig | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfig | undefined);
    private _documentGenerationOptions;
    get documentGenerationOptions(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptionsOutputReference;
    putDocumentGenerationOptions(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptions): void;
    resetDocumentGenerationOptions(): void;
    get documentGenerationOptionsInput(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigDocumentGenerationOptions | undefined;
    private _methodologyExportOptions;
    get methodologyExportOptions(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigMethodologyExportOptionsOutputReference;
    putMethodologyExportOptions(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigMethodologyExportOptions): void;
    resetMethodologyExportOptions(): void;
    get methodologyExportOptionsInput(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigMethodologyExportOptions | undefined;
    private _slideGenerationOptions;
    get slideGenerationOptions(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptionsOutputReference;
    putSlideGenerationOptions(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptions): void;
    resetSlideGenerationOptions(): void;
    get slideGenerationOptionsInput(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigSlideGenerationOptions | undefined;
    private _visualizationOptions;
    get visualizationOptions(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptionsOutputReference;
    putVisualizationOptions(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptions): void;
    resetVisualizationOptions(): void;
    get visualizationOptionsInput(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigVisualizationOptions | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaExternalDataSourcesAirQuality {
}
export declare function agenticApplicationsAnalystAgentPersonaExternalDataSourcesAirQualityToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesAirQualityOutputReference | AgenticApplicationsAnalystAgentPersonaExternalDataSourcesAirQuality): any;
export declare function agenticApplicationsAnalystAgentPersonaExternalDataSourcesAirQualityToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesAirQualityOutputReference | AgenticApplicationsAnalystAgentPersonaExternalDataSourcesAirQuality): any;
export declare class AgenticApplicationsAnalystAgentPersonaExternalDataSourcesAirQualityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaExternalDataSourcesAirQuality | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesAirQuality | undefined);
}
export interface AgenticApplicationsAnalystAgentPersonaExternalDataSourcesBureauLaborStatistics {
}
export declare function agenticApplicationsAnalystAgentPersonaExternalDataSourcesBureauLaborStatisticsToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesBureauLaborStatisticsOutputReference | AgenticApplicationsAnalystAgentPersonaExternalDataSourcesBureauLaborStatistics): any;
export declare function agenticApplicationsAnalystAgentPersonaExternalDataSourcesBureauLaborStatisticsToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesBureauLaborStatisticsOutputReference | AgenticApplicationsAnalystAgentPersonaExternalDataSourcesBureauLaborStatistics): any;
export declare class AgenticApplicationsAnalystAgentPersonaExternalDataSourcesBureauLaborStatisticsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaExternalDataSourcesBureauLaborStatistics | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesBureauLaborStatistics | undefined);
}
export interface AgenticApplicationsAnalystAgentPersonaExternalDataSourcesCoindesk {
}
export declare function agenticApplicationsAnalystAgentPersonaExternalDataSourcesCoindeskToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesCoindeskOutputReference | AgenticApplicationsAnalystAgentPersonaExternalDataSourcesCoindesk): any;
export declare function agenticApplicationsAnalystAgentPersonaExternalDataSourcesCoindeskToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesCoindeskOutputReference | AgenticApplicationsAnalystAgentPersonaExternalDataSourcesCoindesk): any;
export declare class AgenticApplicationsAnalystAgentPersonaExternalDataSourcesCoindeskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaExternalDataSourcesCoindesk | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesCoindesk | undefined);
}
export interface AgenticApplicationsAnalystAgentPersonaExternalDataSourcesFinnhub {
}
export declare function agenticApplicationsAnalystAgentPersonaExternalDataSourcesFinnhubToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesFinnhubOutputReference | AgenticApplicationsAnalystAgentPersonaExternalDataSourcesFinnhub): any;
export declare function agenticApplicationsAnalystAgentPersonaExternalDataSourcesFinnhubToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesFinnhubOutputReference | AgenticApplicationsAnalystAgentPersonaExternalDataSourcesFinnhub): any;
export declare class AgenticApplicationsAnalystAgentPersonaExternalDataSourcesFinnhubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaExternalDataSourcesFinnhub | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesFinnhub | undefined);
}
export interface AgenticApplicationsAnalystAgentPersonaExternalDataSourcesFred {
}
export declare function agenticApplicationsAnalystAgentPersonaExternalDataSourcesFredToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesFredOutputReference | AgenticApplicationsAnalystAgentPersonaExternalDataSourcesFred): any;
export declare function agenticApplicationsAnalystAgentPersonaExternalDataSourcesFredToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesFredOutputReference | AgenticApplicationsAnalystAgentPersonaExternalDataSourcesFred): any;
export declare class AgenticApplicationsAnalystAgentPersonaExternalDataSourcesFredOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaExternalDataSourcesFred | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesFred | undefined);
}
export interface AgenticApplicationsAnalystAgentPersonaExternalDataSourcesSecEdgar {
}
export declare function agenticApplicationsAnalystAgentPersonaExternalDataSourcesSecEdgarToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesSecEdgarOutputReference | AgenticApplicationsAnalystAgentPersonaExternalDataSourcesSecEdgar): any;
export declare function agenticApplicationsAnalystAgentPersonaExternalDataSourcesSecEdgarToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesSecEdgarOutputReference | AgenticApplicationsAnalystAgentPersonaExternalDataSourcesSecEdgar): any;
export declare class AgenticApplicationsAnalystAgentPersonaExternalDataSourcesSecEdgarOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaExternalDataSourcesSecEdgar | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesSecEdgar | undefined);
}
export interface AgenticApplicationsAnalystAgentPersonaExternalDataSourcesTreasurySecuritiesAuctions {
}
export declare function agenticApplicationsAnalystAgentPersonaExternalDataSourcesTreasurySecuritiesAuctionsToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesTreasurySecuritiesAuctionsOutputReference | AgenticApplicationsAnalystAgentPersonaExternalDataSourcesTreasurySecuritiesAuctions): any;
export declare function agenticApplicationsAnalystAgentPersonaExternalDataSourcesTreasurySecuritiesAuctionsToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesTreasurySecuritiesAuctionsOutputReference | AgenticApplicationsAnalystAgentPersonaExternalDataSourcesTreasurySecuritiesAuctions): any;
export declare class AgenticApplicationsAnalystAgentPersonaExternalDataSourcesTreasurySecuritiesAuctionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaExternalDataSourcesTreasurySecuritiesAuctions | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesTreasurySecuritiesAuctions | undefined);
}
export interface AgenticApplicationsAnalystAgentPersonaExternalDataSourcesUsda {
}
export declare function agenticApplicationsAnalystAgentPersonaExternalDataSourcesUsdaToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesUsdaOutputReference | AgenticApplicationsAnalystAgentPersonaExternalDataSourcesUsda): any;
export declare function agenticApplicationsAnalystAgentPersonaExternalDataSourcesUsdaToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesUsdaOutputReference | AgenticApplicationsAnalystAgentPersonaExternalDataSourcesUsda): any;
export declare class AgenticApplicationsAnalystAgentPersonaExternalDataSourcesUsdaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaExternalDataSourcesUsda | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesUsda | undefined);
}
export interface AgenticApplicationsAnalystAgentPersonaExternalDataSources {
    /**
    * Whether this external data source is enabled for the current analysis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#enabled AgenticApplicationsAnalystAgentPersona#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * air_quality block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#air_quality AgenticApplicationsAnalystAgentPersona#air_quality}
    */
    readonly airQuality?: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesAirQuality;
    /**
    * bureau_labor_statistics block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#bureau_labor_statistics AgenticApplicationsAnalystAgentPersona#bureau_labor_statistics}
    */
    readonly bureauLaborStatistics?: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesBureauLaborStatistics;
    /**
    * coindesk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#coindesk AgenticApplicationsAnalystAgentPersona#coindesk}
    */
    readonly coindesk?: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesCoindesk;
    /**
    * finnhub block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#finnhub AgenticApplicationsAnalystAgentPersona#finnhub}
    */
    readonly finnhub?: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesFinnhub;
    /**
    * fred block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#fred AgenticApplicationsAnalystAgentPersona#fred}
    */
    readonly fred?: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesFred;
    /**
    * sec_edgar block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#sec_edgar AgenticApplicationsAnalystAgentPersona#sec_edgar}
    */
    readonly secEdgar?: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesSecEdgar;
    /**
    * treasury_securities_auctions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#treasury_securities_auctions AgenticApplicationsAnalystAgentPersona#treasury_securities_auctions}
    */
    readonly treasurySecuritiesAuctions?: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesTreasurySecuritiesAuctions;
    /**
    * usda block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#usda AgenticApplicationsAnalystAgentPersona#usda}
    */
    readonly usda?: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesUsda;
}
export declare function agenticApplicationsAnalystAgentPersonaExternalDataSourcesToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaExternalDataSources | cdktn.IResolvable): any;
export declare function agenticApplicationsAnalystAgentPersonaExternalDataSourcesToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaExternalDataSources | cdktn.IResolvable): any;
export declare class AgenticApplicationsAnalystAgentPersonaExternalDataSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaExternalDataSources | cdktn.IResolvable | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaExternalDataSources | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get selectionName(): string;
    private _airQuality;
    get airQuality(): AgenticApplicationsAnalystAgentPersonaExternalDataSourcesAirQualityOutputReference;
    putAirQuality(value: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesAirQuality): void;
    resetAirQuality(): void;
    get airQualityInput(): AgenticApplicationsAnalystAgentPersonaExternalDataSourcesAirQuality | undefined;
    private _bureauLaborStatistics;
    get bureauLaborStatistics(): AgenticApplicationsAnalystAgentPersonaExternalDataSourcesBureauLaborStatisticsOutputReference;
    putBureauLaborStatistics(value: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesBureauLaborStatistics): void;
    resetBureauLaborStatistics(): void;
    get bureauLaborStatisticsInput(): AgenticApplicationsAnalystAgentPersonaExternalDataSourcesBureauLaborStatistics | undefined;
    private _coindesk;
    get coindesk(): AgenticApplicationsAnalystAgentPersonaExternalDataSourcesCoindeskOutputReference;
    putCoindesk(value: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesCoindesk): void;
    resetCoindesk(): void;
    get coindeskInput(): AgenticApplicationsAnalystAgentPersonaExternalDataSourcesCoindesk | undefined;
    private _finnhub;
    get finnhub(): AgenticApplicationsAnalystAgentPersonaExternalDataSourcesFinnhubOutputReference;
    putFinnhub(value: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesFinnhub): void;
    resetFinnhub(): void;
    get finnhubInput(): AgenticApplicationsAnalystAgentPersonaExternalDataSourcesFinnhub | undefined;
    private _fred;
    get fred(): AgenticApplicationsAnalystAgentPersonaExternalDataSourcesFredOutputReference;
    putFred(value: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesFred): void;
    resetFred(): void;
    get fredInput(): AgenticApplicationsAnalystAgentPersonaExternalDataSourcesFred | undefined;
    private _secEdgar;
    get secEdgar(): AgenticApplicationsAnalystAgentPersonaExternalDataSourcesSecEdgarOutputReference;
    putSecEdgar(value: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesSecEdgar): void;
    resetSecEdgar(): void;
    get secEdgarInput(): AgenticApplicationsAnalystAgentPersonaExternalDataSourcesSecEdgar | undefined;
    private _treasurySecuritiesAuctions;
    get treasurySecuritiesAuctions(): AgenticApplicationsAnalystAgentPersonaExternalDataSourcesTreasurySecuritiesAuctionsOutputReference;
    putTreasurySecuritiesAuctions(value: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesTreasurySecuritiesAuctions): void;
    resetTreasurySecuritiesAuctions(): void;
    get treasurySecuritiesAuctionsInput(): AgenticApplicationsAnalystAgentPersonaExternalDataSourcesTreasurySecuritiesAuctions | undefined;
    private _usda;
    get usda(): AgenticApplicationsAnalystAgentPersonaExternalDataSourcesUsdaOutputReference;
    putUsda(value: AgenticApplicationsAnalystAgentPersonaExternalDataSourcesUsda): void;
    resetUsda(): void;
    get usdaInput(): AgenticApplicationsAnalystAgentPersonaExternalDataSourcesUsda | undefined;
}
export declare class AgenticApplicationsAnalystAgentPersonaExternalDataSourcesList extends cdktn.ComplexList {
    internalValue?: AgenticApplicationsAnalystAgentPersonaExternalDataSources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AgenticApplicationsAnalystAgentPersonaExternalDataSourcesOutputReference;
}
export interface AgenticApplicationsAnalystAgentPersonaMcpDataSources {
    /**
    * Input only. The API key of the MCP server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#api_key AgenticApplicationsAnalystAgentPersona#api_key}
    */
    readonly apiKey?: string;
    /**
    * The HTTP header when the API key is passed in a request header
    * (e.g. 'x-api-key', 'api-key', 'X-Auth-Token').
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#api_key_header AgenticApplicationsAnalystAgentPersona#api_key_header}
    */
    readonly apiKeyHeader?: string;
    /**
    * The API key parameter name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#api_key_name AgenticApplicationsAnalystAgentPersona#api_key_name}
    */
    readonly apiKeyName?: string;
    /**
    * The client ID for authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#client_id AgenticApplicationsAnalystAgentPersona#client_id}
    */
    readonly clientId?: string;
    /**
    * Input only. The client secret for authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#client_secret AgenticApplicationsAnalystAgentPersona#client_secret}
    */
    readonly clientSecret?: string;
    /**
    * The description of the MCP agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#description AgenticApplicationsAnalystAgentPersona#description}
    */
    readonly description: string;
    /**
    * The display name of the MCP server. Must be no longer than 63 characters
    * and can only contain letters, numbers, spaces, underscores, and hyphens.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#display_name AgenticApplicationsAnalystAgentPersona#display_name}
    */
    readonly displayName: string;
    /**
    * Whether this external data source is enabled for the current analysis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#enabled AgenticApplicationsAnalystAgentPersona#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * The URL to use for retrieving the OAuth token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#oauth_token_url AgenticApplicationsAnalystAgentPersona#oauth_token_url}
    */
    readonly oauthTokenUrl?: string;
    /**
    * The custom prompt for the MCP agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#prompt AgenticApplicationsAnalystAgentPersona#prompt}
    */
    readonly prompt?: string;
    /**
    * The URL of the MCP server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#server_url AgenticApplicationsAnalystAgentPersona#server_url}
    */
    readonly serverUrl: string;
}
export declare function agenticApplicationsAnalystAgentPersonaMcpDataSourcesToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaMcpDataSources | cdktn.IResolvable): any;
export declare function agenticApplicationsAnalystAgentPersonaMcpDataSourcesToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaMcpDataSources | cdktn.IResolvable): any;
export declare class AgenticApplicationsAnalystAgentPersonaMcpDataSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaMcpDataSources | cdktn.IResolvable | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaMcpDataSources | cdktn.IResolvable | undefined);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
    private _apiKeyHeader?;
    get apiKeyHeader(): string;
    set apiKeyHeader(value: string);
    resetApiKeyHeader(): void;
    get apiKeyHeaderInput(): string | undefined;
    private _apiKeyName?;
    get apiKeyName(): string;
    set apiKeyName(value: string);
    resetApiKeyName(): void;
    get apiKeyNameInput(): string | undefined;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    resetClientSecret(): void;
    get clientSecretInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _oauthTokenUrl?;
    get oauthTokenUrl(): string;
    set oauthTokenUrl(value: string);
    resetOauthTokenUrl(): void;
    get oauthTokenUrlInput(): string | undefined;
    private _prompt?;
    get prompt(): string;
    set prompt(value: string);
    resetPrompt(): void;
    get promptInput(): string | undefined;
    private _serverUrl?;
    get serverUrl(): string;
    set serverUrl(value: string);
    get serverUrlInput(): string | undefined;
}
export declare class AgenticApplicationsAnalystAgentPersonaMcpDataSourcesList extends cdktn.ComplexList {
    internalValue?: AgenticApplicationsAnalystAgentPersonaMcpDataSources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AgenticApplicationsAnalystAgentPersonaMcpDataSourcesOutputReference;
}
export interface AgenticApplicationsAnalystAgentPersonaResourcesBigqueryResource {
    /**
    * Points to a bigquery dataset to use.
    *
    * Expected Format:
    * projects/{project_id_or_number}/datasets/{dataset_id}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#bigquery_dataset AgenticApplicationsAnalystAgentPersona#bigquery_dataset}
    */
    readonly bigqueryDataset?: string;
    /**
    * Points to a bigquery table to use.
    *
    * Expected Format:
    * projects/{project_id_or_number}/datasets/{dataset_id}/tables/{table_id}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#bigquery_table AgenticApplicationsAnalystAgentPersona#bigquery_table}
    */
    readonly bigqueryTable?: string;
    /**
    * A map of column names to column descriptions for the bigquery_table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#column_descriptions AgenticApplicationsAnalystAgentPersona#column_descriptions}
    */
    readonly columnDescriptions?: {
        [key: string]: string;
    };
}
export declare function agenticApplicationsAnalystAgentPersonaResourcesBigqueryResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaResourcesBigqueryResourceOutputReference | AgenticApplicationsAnalystAgentPersonaResourcesBigqueryResource): any;
export declare function agenticApplicationsAnalystAgentPersonaResourcesBigqueryResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaResourcesBigqueryResourceOutputReference | AgenticApplicationsAnalystAgentPersonaResourcesBigqueryResource): any;
export declare class AgenticApplicationsAnalystAgentPersonaResourcesBigqueryResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaResourcesBigqueryResource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaResourcesBigqueryResource | undefined);
    private _bigqueryDataset?;
    get bigqueryDataset(): string;
    set bigqueryDataset(value: string);
    resetBigqueryDataset(): void;
    get bigqueryDatasetInput(): string | undefined;
    private _bigqueryTable?;
    get bigqueryTable(): string;
    set bigqueryTable(value: string);
    resetBigqueryTable(): void;
    get bigqueryTableInput(): string | undefined;
    private _columnDescriptions?;
    get columnDescriptions(): {
        [key: string]: string;
    };
    set columnDescriptions(value: {
        [key: string]: string;
    });
    resetColumnDescriptions(): void;
    get columnDescriptionsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaResourcesF1Resource {
    /**
    * ## - Points to an f1 table to use.
    *
    * - Expected Format:
    * - {group}.{table_name}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#f1_table AgenticApplicationsAnalystAgentPersona#f1_table}
    */
    readonly f1Table?: string;
}
export declare function agenticApplicationsAnalystAgentPersonaResourcesF1ResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaResourcesF1ResourceOutputReference | AgenticApplicationsAnalystAgentPersonaResourcesF1Resource): any;
export declare function agenticApplicationsAnalystAgentPersonaResourcesF1ResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaResourcesF1ResourceOutputReference | AgenticApplicationsAnalystAgentPersonaResourcesF1Resource): any;
export declare class AgenticApplicationsAnalystAgentPersonaResourcesF1ResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaResourcesF1Resource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaResourcesF1Resource | undefined);
    private _f1Table?;
    get f1Table(): string;
    set f1Table(value: string);
    resetF1Table(): void;
    get f1TableInput(): string | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaResourcesGoogleCloudStorageResource {
    /**
    * If non-empty, only files with these extensions are included when
    * expanding the resource.  If empty, all files are included.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#file_extension_restrictions AgenticApplicationsAnalystAgentPersona#file_extension_restrictions}
    */
    readonly fileExtensionRestrictions?: string[];
    /**
    * The Google Cloud Storage object or folder.
    *
    * Format: /
    * or: //
    *
    * Note that to refer to a folder, it _must_ end in a slash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#google_cloud_storage_object AgenticApplicationsAnalystAgentPersona#google_cloud_storage_object}
    */
    readonly googleCloudStorageObject: string;
}
export declare function agenticApplicationsAnalystAgentPersonaResourcesGoogleCloudStorageResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaResourcesGoogleCloudStorageResourceOutputReference | AgenticApplicationsAnalystAgentPersonaResourcesGoogleCloudStorageResource): any;
export declare function agenticApplicationsAnalystAgentPersonaResourcesGoogleCloudStorageResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaResourcesGoogleCloudStorageResourceOutputReference | AgenticApplicationsAnalystAgentPersonaResourcesGoogleCloudStorageResource): any;
export declare class AgenticApplicationsAnalystAgentPersonaResourcesGoogleCloudStorageResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaResourcesGoogleCloudStorageResource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaResourcesGoogleCloudStorageResource | undefined);
    private _fileExtensionRestrictions?;
    get fileExtensionRestrictions(): string[];
    set fileExtensionRestrictions(value: string[]);
    resetFileExtensionRestrictions(): void;
    get fileExtensionRestrictionsInput(): string[] | undefined;
    private _googleCloudStorageObject?;
    get googleCloudStorageObject(): string;
    set googleCloudStorageObject(value: string);
    get googleCloudStorageObjectInput(): string | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaResourcesGoogleDriveResource {
    /**
    * If non-empty, only files with these extensions are included when
    * expanding the resource.  If empty, all files are included.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#file_extension_restrictions AgenticApplicationsAnalystAgentPersona#file_extension_restrictions}
    */
    readonly fileExtensionRestrictions?: string[];
    /**
    * Points to a drive file to use. May refer to workspace files or folders
    * as well.  If folder is specifically, all files in the folder
    * (recursively) are used.
    *
    * Expected Format:
    * files/{file_id}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#file_reference AgenticApplicationsAnalystAgentPersona#file_reference}
    */
    readonly fileReference?: string;
}
export declare function agenticApplicationsAnalystAgentPersonaResourcesGoogleDriveResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaResourcesGoogleDriveResourceOutputReference | AgenticApplicationsAnalystAgentPersonaResourcesGoogleDriveResource): any;
export declare function agenticApplicationsAnalystAgentPersonaResourcesGoogleDriveResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaResourcesGoogleDriveResourceOutputReference | AgenticApplicationsAnalystAgentPersonaResourcesGoogleDriveResource): any;
export declare class AgenticApplicationsAnalystAgentPersonaResourcesGoogleDriveResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaResourcesGoogleDriveResource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaResourcesGoogleDriveResource | undefined);
    private _fileExtensionRestrictions?;
    get fileExtensionRestrictions(): string[];
    set fileExtensionRestrictions(value: string[]);
    resetFileExtensionRestrictions(): void;
    get fileExtensionRestrictionsInput(): string[] | undefined;
    private _fileReference?;
    get fileReference(): string;
    set fileReference(value: string);
    resetFileReference(): void;
    get fileReferenceInput(): string | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaResourcesRawFileResource {
    /**
    * The raw file content.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#file_content AgenticApplicationsAnalystAgentPersona#file_content}
    */
    readonly fileContent: string;
    /**
    * The title of the file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#file_title AgenticApplicationsAnalystAgentPersona#file_title}
    */
    readonly fileTitle: string;
    /**
    * The mime type of the file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#mime_type AgenticApplicationsAnalystAgentPersona#mime_type}
    */
    readonly mimeType: string;
}
export declare function agenticApplicationsAnalystAgentPersonaResourcesRawFileResourceToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaResourcesRawFileResourceOutputReference | AgenticApplicationsAnalystAgentPersonaResourcesRawFileResource): any;
export declare function agenticApplicationsAnalystAgentPersonaResourcesRawFileResourceToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaResourcesRawFileResourceOutputReference | AgenticApplicationsAnalystAgentPersonaResourcesRawFileResource): any;
export declare class AgenticApplicationsAnalystAgentPersonaResourcesRawFileResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaResourcesRawFileResource | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaResourcesRawFileResource | undefined);
    private _fileContent?;
    get fileContent(): string;
    set fileContent(value: string);
    get fileContentInput(): string | undefined;
    private _fileTitle?;
    get fileTitle(): string;
    set fileTitle(value: string);
    get fileTitleInput(): string | undefined;
    private _mimeType?;
    get mimeType(): string;
    set mimeType(value: string);
    get mimeTypeInput(): string | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaResources {
    /**
    * A user-friendly name for this resource. This can be shown to the user
    * and used by the model.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#display_label AgenticApplicationsAnalystAgentPersona#display_label}
    */
    readonly displayLabel?: string;
    /**
    * A description of the resource. The model may use this, it will not be
    * shown to users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#model_description AgenticApplicationsAnalystAgentPersona#model_description}
    */
    readonly modelDescription?: string;
    /**
    * If true, use RAG to retrieve relevant information from the resources.
    *
    * Must only be set for file-based resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#use_rag AgenticApplicationsAnalystAgentPersona#use_rag}
    */
    readonly useRag?: boolean | cdktn.IResolvable;
    /**
    * bigquery_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#bigquery_resource AgenticApplicationsAnalystAgentPersona#bigquery_resource}
    */
    readonly bigqueryResource?: AgenticApplicationsAnalystAgentPersonaResourcesBigqueryResource;
    /**
    * f1_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#f1_resource AgenticApplicationsAnalystAgentPersona#f1_resource}
    */
    readonly f1Resource?: AgenticApplicationsAnalystAgentPersonaResourcesF1Resource;
    /**
    * google_cloud_storage_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#google_cloud_storage_resource AgenticApplicationsAnalystAgentPersona#google_cloud_storage_resource}
    */
    readonly googleCloudStorageResource?: AgenticApplicationsAnalystAgentPersonaResourcesGoogleCloudStorageResource;
    /**
    * google_drive_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#google_drive_resource AgenticApplicationsAnalystAgentPersona#google_drive_resource}
    */
    readonly googleDriveResource?: AgenticApplicationsAnalystAgentPersonaResourcesGoogleDriveResource;
    /**
    * raw_file_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#raw_file_resource AgenticApplicationsAnalystAgentPersona#raw_file_resource}
    */
    readonly rawFileResource?: AgenticApplicationsAnalystAgentPersonaResourcesRawFileResource;
}
export declare function agenticApplicationsAnalystAgentPersonaResourcesToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaResources | cdktn.IResolvable): any;
export declare function agenticApplicationsAnalystAgentPersonaResourcesToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaResources | cdktn.IResolvable): any;
export declare class AgenticApplicationsAnalystAgentPersonaResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaResources | cdktn.IResolvable | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaResources | cdktn.IResolvable | undefined);
    private _displayLabel?;
    get displayLabel(): string;
    set displayLabel(value: string);
    resetDisplayLabel(): void;
    get displayLabelInput(): string | undefined;
    private _modelDescription?;
    get modelDescription(): string;
    set modelDescription(value: string);
    resetModelDescription(): void;
    get modelDescriptionInput(): string | undefined;
    private _useRag?;
    get useRag(): boolean | cdktn.IResolvable;
    set useRag(value: boolean | cdktn.IResolvable);
    resetUseRag(): void;
    get useRagInput(): boolean | cdktn.IResolvable | undefined;
    private _bigqueryResource;
    get bigqueryResource(): AgenticApplicationsAnalystAgentPersonaResourcesBigqueryResourceOutputReference;
    putBigqueryResource(value: AgenticApplicationsAnalystAgentPersonaResourcesBigqueryResource): void;
    resetBigqueryResource(): void;
    get bigqueryResourceInput(): AgenticApplicationsAnalystAgentPersonaResourcesBigqueryResource | undefined;
    private _f1Resource;
    get f1Resource(): AgenticApplicationsAnalystAgentPersonaResourcesF1ResourceOutputReference;
    putF1Resource(value: AgenticApplicationsAnalystAgentPersonaResourcesF1Resource): void;
    resetF1Resource(): void;
    get f1ResourceInput(): AgenticApplicationsAnalystAgentPersonaResourcesF1Resource | undefined;
    private _googleCloudStorageResource;
    get googleCloudStorageResource(): AgenticApplicationsAnalystAgentPersonaResourcesGoogleCloudStorageResourceOutputReference;
    putGoogleCloudStorageResource(value: AgenticApplicationsAnalystAgentPersonaResourcesGoogleCloudStorageResource): void;
    resetGoogleCloudStorageResource(): void;
    get googleCloudStorageResourceInput(): AgenticApplicationsAnalystAgentPersonaResourcesGoogleCloudStorageResource | undefined;
    private _googleDriveResource;
    get googleDriveResource(): AgenticApplicationsAnalystAgentPersonaResourcesGoogleDriveResourceOutputReference;
    putGoogleDriveResource(value: AgenticApplicationsAnalystAgentPersonaResourcesGoogleDriveResource): void;
    resetGoogleDriveResource(): void;
    get googleDriveResourceInput(): AgenticApplicationsAnalystAgentPersonaResourcesGoogleDriveResource | undefined;
    private _rawFileResource;
    get rawFileResource(): AgenticApplicationsAnalystAgentPersonaResourcesRawFileResourceOutputReference;
    putRawFileResource(value: AgenticApplicationsAnalystAgentPersonaResourcesRawFileResource): void;
    resetRawFileResource(): void;
    get rawFileResourceInput(): AgenticApplicationsAnalystAgentPersonaResourcesRawFileResource | undefined;
}
export declare class AgenticApplicationsAnalystAgentPersonaResourcesList extends cdktn.ComplexList {
    internalValue?: AgenticApplicationsAnalystAgentPersonaResources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AgenticApplicationsAnalystAgentPersonaResourcesOutputReference;
}
export interface AgenticApplicationsAnalystAgentPersonaSkillsReferences {
    /**
    * The content of the reference.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#content AgenticApplicationsAnalystAgentPersona#content}
    */
    readonly content: string;
    /**
    * The identifier of the reference within the skill. Use a descriptive
    * string that reflects the reference's function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#reference_id AgenticApplicationsAnalystAgentPersona#reference_id}
    */
    readonly referenceId: string;
}
export declare function agenticApplicationsAnalystAgentPersonaSkillsReferencesToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaSkillsReferences | cdktn.IResolvable): any;
export declare function agenticApplicationsAnalystAgentPersonaSkillsReferencesToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaSkillsReferences | cdktn.IResolvable): any;
export declare class AgenticApplicationsAnalystAgentPersonaSkillsReferencesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaSkillsReferences | cdktn.IResolvable | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaSkillsReferences | cdktn.IResolvable | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    private _referenceId?;
    get referenceId(): string;
    set referenceId(value: string);
    get referenceIdInput(): string | undefined;
}
export declare class AgenticApplicationsAnalystAgentPersonaSkillsReferencesList extends cdktn.ComplexList {
    internalValue?: AgenticApplicationsAnalystAgentPersonaSkillsReferences[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AgenticApplicationsAnalystAgentPersonaSkillsReferencesOutputReference;
}
export interface AgenticApplicationsAnalystAgentPersonaSkills {
    /**
    * The markdown text content of the skill.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#content AgenticApplicationsAnalystAgentPersona#content}
    */
    readonly content: string;
    /**
    * The description of the skill.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#description AgenticApplicationsAnalystAgentPersona#description}
    */
    readonly description?: string;
    /**
    * The identifier of the skill. Use a descriptive string that reflects the
    * skill's function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#skill_id AgenticApplicationsAnalystAgentPersona#skill_id}
    */
    readonly skillId: string;
    /**
    * references block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#references AgenticApplicationsAnalystAgentPersona#references}
    */
    readonly references?: AgenticApplicationsAnalystAgentPersonaSkillsReferences[] | cdktn.IResolvable;
}
export declare function agenticApplicationsAnalystAgentPersonaSkillsToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaSkills | cdktn.IResolvable): any;
export declare function agenticApplicationsAnalystAgentPersonaSkillsToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaSkills | cdktn.IResolvable): any;
export declare class AgenticApplicationsAnalystAgentPersonaSkillsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaSkills | cdktn.IResolvable | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaSkills | cdktn.IResolvable | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _skillId?;
    get skillId(): string;
    set skillId(value: string);
    get skillIdInput(): string | undefined;
    private _references;
    get references(): AgenticApplicationsAnalystAgentPersonaSkillsReferencesList;
    putReferences(value: AgenticApplicationsAnalystAgentPersonaSkillsReferences[] | cdktn.IResolvable): void;
    resetReferences(): void;
    get referencesInput(): cdktn.IResolvable | AgenticApplicationsAnalystAgentPersonaSkillsReferences[] | undefined;
}
export declare class AgenticApplicationsAnalystAgentPersonaSkillsList extends cdktn.ComplexList {
    internalValue?: AgenticApplicationsAnalystAgentPersonaSkills[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AgenticApplicationsAnalystAgentPersonaSkillsOutputReference;
}
export interface AgenticApplicationsAnalystAgentPersonaTablesColumns {
    /**
    * The data type of the column. This should be a GoogleSQL data type.
    * Parameterized types such as PROTO, ENUM, ARRAY, STRUCT<...>, and
    * RANGE are not supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#data_type AgenticApplicationsAnalystAgentPersona#data_type}
    */
    readonly dataType: string;
    /**
    * The description of the column.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#description AgenticApplicationsAnalystAgentPersona#description}
    */
    readonly description?: string;
    /**
    * The name of the column.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#name AgenticApplicationsAnalystAgentPersona#name}
    */
    readonly name: string;
}
export declare function agenticApplicationsAnalystAgentPersonaTablesColumnsToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaTablesColumns | cdktn.IResolvable): any;
export declare function agenticApplicationsAnalystAgentPersonaTablesColumnsToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaTablesColumns | cdktn.IResolvable): any;
export declare class AgenticApplicationsAnalystAgentPersonaTablesColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaTablesColumns | cdktn.IResolvable | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaTablesColumns | cdktn.IResolvable | undefined);
    private _dataType?;
    get dataType(): string;
    set dataType(value: string);
    get dataTypeInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class AgenticApplicationsAnalystAgentPersonaTablesColumnsList extends cdktn.ComplexList {
    internalValue?: AgenticApplicationsAnalystAgentPersonaTablesColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AgenticApplicationsAnalystAgentPersonaTablesColumnsOutputReference;
}
export interface AgenticApplicationsAnalystAgentPersonaTables {
    /**
    * The description of the table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#description AgenticApplicationsAnalystAgentPersona#description}
    */
    readonly description?: string;
    /**
    * The name of the table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#name AgenticApplicationsAnalystAgentPersona#name}
    */
    readonly name: string;
    /**
    * columns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#columns AgenticApplicationsAnalystAgentPersona#columns}
    */
    readonly columns?: AgenticApplicationsAnalystAgentPersonaTablesColumns[] | cdktn.IResolvable;
}
export declare function agenticApplicationsAnalystAgentPersonaTablesToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaTables | cdktn.IResolvable): any;
export declare function agenticApplicationsAnalystAgentPersonaTablesToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaTables | cdktn.IResolvable): any;
export declare class AgenticApplicationsAnalystAgentPersonaTablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaTables | cdktn.IResolvable | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaTables | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _columns;
    get columns(): AgenticApplicationsAnalystAgentPersonaTablesColumnsList;
    putColumns(value: AgenticApplicationsAnalystAgentPersonaTablesColumns[] | cdktn.IResolvable): void;
    resetColumns(): void;
    get columnsInput(): cdktn.IResolvable | AgenticApplicationsAnalystAgentPersonaTablesColumns[] | undefined;
}
export declare class AgenticApplicationsAnalystAgentPersonaTablesList extends cdktn.ComplexList {
    internalValue?: AgenticApplicationsAnalystAgentPersonaTables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AgenticApplicationsAnalystAgentPersonaTablesOutputReference;
}
export interface AgenticApplicationsAnalystAgentPersonaTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#create AgenticApplicationsAnalystAgentPersona#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#delete AgenticApplicationsAnalystAgentPersona#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#update AgenticApplicationsAnalystAgentPersona#update}
    */
    readonly update?: string;
}
export declare function agenticApplicationsAnalystAgentPersonaTimeoutsToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaTimeouts | cdktn.IResolvable): any;
export declare function agenticApplicationsAnalystAgentPersonaTimeoutsToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaTimeouts | cdktn.IResolvable): any;
export declare class AgenticApplicationsAnalystAgentPersonaTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface AgenticApplicationsAnalystAgentPersonaWebSearchConfig {
    /**
    * Whether web search grounding is disabled for the analyst agent.
    * Defaults to false if not specified (i.e. web search grounding is enabled).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#disabled AgenticApplicationsAnalystAgentPersona#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * List of domains to be excluded from Google Search / Enterprise Web Search
    * grounding.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#excluded_domains AgenticApplicationsAnalystAgentPersona#excluded_domains}
    */
    readonly excludedDomains?: string[];
}
export declare function agenticApplicationsAnalystAgentPersonaWebSearchConfigToTerraform(struct?: AgenticApplicationsAnalystAgentPersonaWebSearchConfigOutputReference | AgenticApplicationsAnalystAgentPersonaWebSearchConfig): any;
export declare function agenticApplicationsAnalystAgentPersonaWebSearchConfigToHclTerraform(struct?: AgenticApplicationsAnalystAgentPersonaWebSearchConfigOutputReference | AgenticApplicationsAnalystAgentPersonaWebSearchConfig): any;
export declare class AgenticApplicationsAnalystAgentPersonaWebSearchConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgenticApplicationsAnalystAgentPersonaWebSearchConfig | undefined;
    set internalValue(value: AgenticApplicationsAnalystAgentPersonaWebSearchConfig | undefined);
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _excludedDomains?;
    get excludedDomains(): string[];
    set excludedDomains(value: string[]);
    resetExcludedDomains(): void;
    get excludedDomainsInput(): string[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona google_agentic_applications_analyst_agent_persona}
*/
export declare class AgenticApplicationsAnalystAgentPersona extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_agentic_applications_analyst_agent_persona";
    /**
    * Generates CDKTN code for importing a AgenticApplicationsAnalystAgentPersona resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AgenticApplicationsAnalystAgentPersona to import
    * @param importFromId The id of the existing AgenticApplicationsAnalystAgentPersona that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AgenticApplicationsAnalystAgentPersona to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/agentic_applications_analyst_agent_persona google_agentic_applications_analyst_agent_persona} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AgenticApplicationsAnalystAgentPersonaConfig
    */
    constructor(scope: Construct, id: string, config: AgenticApplicationsAnalystAgentPersonaConfig);
    private _analystAgentPersonaId?;
    get analystAgentPersonaId(): string;
    set analystAgentPersonaId(value: string);
    get analystAgentPersonaIdInput(): string | undefined;
    get createTime(): string;
    private _customerContext?;
    get customerContext(): string[];
    set customerContext(value: string[]);
    resetCustomerContext(): void;
    get customerContextInput(): string[] | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _displayDescription?;
    get displayDescription(): string;
    set displayDescription(value: string);
    resetDisplayDescription(): void;
    get displayDescriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _geminiEnterpriseEngine?;
    get geminiEnterpriseEngine(): string;
    set geminiEnterpriseEngine(value: string);
    resetGeminiEnterpriseEngine(): void;
    get geminiEnterpriseEngineInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _mathRenderingMode?;
    get mathRenderingMode(): string;
    set mathRenderingMode(value: string);
    resetMathRenderingMode(): void;
    get mathRenderingModeInput(): string | undefined;
    private _modelDescription?;
    get modelDescription(): string;
    set modelDescription(value: string);
    resetModelDescription(): void;
    get modelDescriptionInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    resetRole(): void;
    get roleInput(): string | undefined;
    get updateTime(): string;
    private _artifactExamples;
    get artifactExamples(): AgenticApplicationsAnalystAgentPersonaArtifactExamplesList;
    putArtifactExamples(value: AgenticApplicationsAnalystAgentPersonaArtifactExamples[] | cdktn.IResolvable): void;
    resetArtifactExamples(): void;
    get artifactExamplesInput(): cdktn.IResolvable | AgenticApplicationsAnalystAgentPersonaArtifactExamples[] | undefined;
    private _artifactsConfig;
    get artifactsConfig(): AgenticApplicationsAnalystAgentPersonaArtifactsConfigOutputReference;
    putArtifactsConfig(value: AgenticApplicationsAnalystAgentPersonaArtifactsConfig): void;
    resetArtifactsConfig(): void;
    get artifactsConfigInput(): AgenticApplicationsAnalystAgentPersonaArtifactsConfig | undefined;
    private _externalDataSources;
    get externalDataSources(): AgenticApplicationsAnalystAgentPersonaExternalDataSourcesList;
    putExternalDataSources(value: AgenticApplicationsAnalystAgentPersonaExternalDataSources[] | cdktn.IResolvable): void;
    resetExternalDataSources(): void;
    get externalDataSourcesInput(): cdktn.IResolvable | AgenticApplicationsAnalystAgentPersonaExternalDataSources[] | undefined;
    private _mcpDataSources;
    get mcpDataSources(): AgenticApplicationsAnalystAgentPersonaMcpDataSourcesList;
    putMcpDataSources(value: AgenticApplicationsAnalystAgentPersonaMcpDataSources[] | cdktn.IResolvable): void;
    resetMcpDataSources(): void;
    get mcpDataSourcesInput(): cdktn.IResolvable | AgenticApplicationsAnalystAgentPersonaMcpDataSources[] | undefined;
    private _resources;
    get resources(): AgenticApplicationsAnalystAgentPersonaResourcesList;
    putResources(value: AgenticApplicationsAnalystAgentPersonaResources[] | cdktn.IResolvable): void;
    resetResources(): void;
    get resourcesInput(): cdktn.IResolvable | AgenticApplicationsAnalystAgentPersonaResources[] | undefined;
    private _skills;
    get skills(): AgenticApplicationsAnalystAgentPersonaSkillsList;
    putSkills(value: AgenticApplicationsAnalystAgentPersonaSkills[] | cdktn.IResolvable): void;
    resetSkills(): void;
    get skillsInput(): cdktn.IResolvable | AgenticApplicationsAnalystAgentPersonaSkills[] | undefined;
    private _tables;
    get tables(): AgenticApplicationsAnalystAgentPersonaTablesList;
    putTables(value: AgenticApplicationsAnalystAgentPersonaTables[] | cdktn.IResolvable): void;
    resetTables(): void;
    get tablesInput(): cdktn.IResolvable | AgenticApplicationsAnalystAgentPersonaTables[] | undefined;
    private _timeouts;
    get timeouts(): AgenticApplicationsAnalystAgentPersonaTimeoutsOutputReference;
    putTimeouts(value: AgenticApplicationsAnalystAgentPersonaTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AgenticApplicationsAnalystAgentPersonaTimeouts | undefined;
    private _webSearchConfig;
    get webSearchConfig(): AgenticApplicationsAnalystAgentPersonaWebSearchConfigOutputReference;
    putWebSearchConfig(value: AgenticApplicationsAnalystAgentPersonaWebSearchConfig): void;
    resetWebSearchConfig(): void;
    get webSearchConfigInput(): AgenticApplicationsAnalystAgentPersonaWebSearchConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
