/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BiglakeIcebergNamespaceIamPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_iceberg_namespace_iam_policy#catalog BiglakeIcebergNamespaceIamPolicy#catalog}
    */
    readonly catalog: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_iceberg_namespace_iam_policy#id BiglakeIcebergNamespaceIamPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_iceberg_namespace_iam_policy#namespace_id BiglakeIcebergNamespaceIamPolicy#namespace_id}
    */
    readonly namespaceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_iceberg_namespace_iam_policy#policy_data BiglakeIcebergNamespaceIamPolicy#policy_data}
    */
    readonly policyData: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_iceberg_namespace_iam_policy#project BiglakeIcebergNamespaceIamPolicy#project}
    */
    readonly project?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_iceberg_namespace_iam_policy google_biglake_iceberg_namespace_iam_policy}
*/
export declare class BiglakeIcebergNamespaceIamPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_biglake_iceberg_namespace_iam_policy";
    /**
    * Generates CDKTN code for importing a BiglakeIcebergNamespaceIamPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BiglakeIcebergNamespaceIamPolicy to import
    * @param importFromId The id of the existing BiglakeIcebergNamespaceIamPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_iceberg_namespace_iam_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BiglakeIcebergNamespaceIamPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_iceberg_namespace_iam_policy google_biglake_iceberg_namespace_iam_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BiglakeIcebergNamespaceIamPolicyConfig
    */
    constructor(scope: Construct, id: string, config: BiglakeIcebergNamespaceIamPolicyConfig);
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    get catalogInput(): string | undefined;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _namespaceId?;
    get namespaceId(): string;
    set namespaceId(value: string);
    get namespaceIdInput(): string | undefined;
    private _policyData?;
    get policyData(): string;
    set policyData(value: string);
    get policyDataInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
