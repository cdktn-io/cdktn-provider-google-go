/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApihubPluginInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#deletion_policy ApihubPluginInstance#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The display name for this plugin instance. Max length is 255 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#disable ApihubPluginInstance#disable}
    */
    readonly disable?: boolean | cdktn.IResolvable;
    /**
    * The display name for this plugin instance. Max length is 255 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#display_name ApihubPluginInstance#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#id ApihubPluginInstance#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#location ApihubPluginInstance#location}
    */
    readonly location: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#plugin ApihubPluginInstance#plugin}
    */
    readonly plugin: string;
    /**
    * The ID to use for the plugin instance, which will become the final
    * component of the plugin instance's resource name. This field is optional.
    *
    * * If provided, the same will be used. The service will throw an error if
    * the specified id is already used by another plugin instance in the plugin
    * resource.
    * * If not provided, a system generated id will be used.
    *
    * This value should be 4-63 characters, and valid characters
    * are /a-z[0-9]-_/.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#plugin_instance_id ApihubPluginInstance#plugin_instance_id}
    */
    readonly pluginInstanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#project ApihubPluginInstance#project}
    */
    readonly project?: string;
    /**
    * Optional. The source project id of the plugin instance. This will be the id of runtime project in case of gcp based plugins and org id in case of non gcp based plugins. This field will be a required field for Google provided on-ramp plugins.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#source_project_id ApihubPluginInstance#source_project_id}
    */
    readonly sourceProjectId?: string;
    /**
    * actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#actions ApihubPluginInstance#actions}
    */
    readonly actions?: ApihubPluginInstanceActions[] | cdktn.IResolvable;
    /**
    * auth_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#auth_config ApihubPluginInstance#auth_config}
    */
    readonly authConfig?: ApihubPluginInstanceAuthConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#timeouts ApihubPluginInstance#timeouts}
    */
    readonly timeouts?: ApihubPluginInstanceTimeouts;
}
export interface ApihubPluginInstanceActionsHubInstanceActionLastExecution {
}
export declare function apihubPluginInstanceActionsHubInstanceActionLastExecutionToTerraform(struct?: ApihubPluginInstanceActionsHubInstanceActionLastExecution): any;
export declare function apihubPluginInstanceActionsHubInstanceActionLastExecutionToHclTerraform(struct?: ApihubPluginInstanceActionsHubInstanceActionLastExecution): any;
export declare class ApihubPluginInstanceActionsHubInstanceActionLastExecutionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApihubPluginInstanceActionsHubInstanceActionLastExecution | undefined;
    set internalValue(value: ApihubPluginInstanceActionsHubInstanceActionLastExecution | undefined);
    get endTime(): string;
    get errorMessage(): string;
    get result(): string;
    get startTime(): string;
}
export declare class ApihubPluginInstanceActionsHubInstanceActionLastExecutionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApihubPluginInstanceActionsHubInstanceActionLastExecutionOutputReference;
}
export interface ApihubPluginInstanceActionsHubInstanceAction {
}
export declare function apihubPluginInstanceActionsHubInstanceActionToTerraform(struct?: ApihubPluginInstanceActionsHubInstanceAction): any;
export declare function apihubPluginInstanceActionsHubInstanceActionToHclTerraform(struct?: ApihubPluginInstanceActionsHubInstanceAction): any;
export declare class ApihubPluginInstanceActionsHubInstanceActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApihubPluginInstanceActionsHubInstanceAction | undefined;
    set internalValue(value: ApihubPluginInstanceActionsHubInstanceAction | undefined);
    get currentExecutionState(): string;
    private _lastExecution;
    get lastExecution(): ApihubPluginInstanceActionsHubInstanceActionLastExecutionList;
}
export declare class ApihubPluginInstanceActionsHubInstanceActionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApihubPluginInstanceActionsHubInstanceActionOutputReference;
}
export interface ApihubPluginInstanceActionsCurationConfigCustomCuration {
    /**
    * The unique name of the curation resource. This will be the name of the
    * curation resource in the format:
    * 'projects/{project}/locations/{location}/curations/{curation}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#curation ApihubPluginInstance#curation}
    */
    readonly curation: string;
}
export declare function apihubPluginInstanceActionsCurationConfigCustomCurationToTerraform(struct?: ApihubPluginInstanceActionsCurationConfigCustomCurationOutputReference | ApihubPluginInstanceActionsCurationConfigCustomCuration): any;
export declare function apihubPluginInstanceActionsCurationConfigCustomCurationToHclTerraform(struct?: ApihubPluginInstanceActionsCurationConfigCustomCurationOutputReference | ApihubPluginInstanceActionsCurationConfigCustomCuration): any;
export declare class ApihubPluginInstanceActionsCurationConfigCustomCurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApihubPluginInstanceActionsCurationConfigCustomCuration | undefined;
    set internalValue(value: ApihubPluginInstanceActionsCurationConfigCustomCuration | undefined);
    private _curation?;
    get curation(): string;
    set curation(value: string);
    get curationInput(): string | undefined;
}
export interface ApihubPluginInstanceActionsCurationConfig {
    /**
    * Possible values:
    * CURATION_TYPE_UNSPECIFIED
    * DEFAULT_CURATION_FOR_API_METADATA
    * CUSTOM_CURATION_FOR_API_METADATA
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#curation_type ApihubPluginInstance#curation_type}
    */
    readonly curationType?: string;
    /**
    * custom_curation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#custom_curation ApihubPluginInstance#custom_curation}
    */
    readonly customCuration?: ApihubPluginInstanceActionsCurationConfigCustomCuration;
}
export declare function apihubPluginInstanceActionsCurationConfigToTerraform(struct?: ApihubPluginInstanceActionsCurationConfigOutputReference | ApihubPluginInstanceActionsCurationConfig): any;
export declare function apihubPluginInstanceActionsCurationConfigToHclTerraform(struct?: ApihubPluginInstanceActionsCurationConfigOutputReference | ApihubPluginInstanceActionsCurationConfig): any;
export declare class ApihubPluginInstanceActionsCurationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApihubPluginInstanceActionsCurationConfig | undefined;
    set internalValue(value: ApihubPluginInstanceActionsCurationConfig | undefined);
    private _curationType?;
    get curationType(): string;
    set curationType(value: string);
    resetCurationType(): void;
    get curationTypeInput(): string | undefined;
    private _customCuration;
    get customCuration(): ApihubPluginInstanceActionsCurationConfigCustomCurationOutputReference;
    putCustomCuration(value: ApihubPluginInstanceActionsCurationConfigCustomCuration): void;
    resetCustomCuration(): void;
    get customCurationInput(): ApihubPluginInstanceActionsCurationConfigCustomCuration | undefined;
}
export interface ApihubPluginInstanceActions {
    /**
    * This should map to one of the action id specified
    * in actions_config in the plugin.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#action_id ApihubPluginInstance#action_id}
    */
    readonly actionId: string;
    /**
    * The schedule for this plugin instance action. This can only be set if the
    * plugin supports API_HUB_SCHEDULE_TRIGGER mode for this action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#schedule_cron_expression ApihubPluginInstance#schedule_cron_expression}
    */
    readonly scheduleCronExpression?: string;
    /**
    * The time zone for the schedule cron expression. If not provided, UTC will
    * be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#schedule_time_zone ApihubPluginInstance#schedule_time_zone}
    */
    readonly scheduleTimeZone?: string;
    /**
    * curation_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#curation_config ApihubPluginInstance#curation_config}
    */
    readonly curationConfig?: ApihubPluginInstanceActionsCurationConfig;
}
export declare function apihubPluginInstanceActionsToTerraform(struct?: ApihubPluginInstanceActions | cdktn.IResolvable): any;
export declare function apihubPluginInstanceActionsToHclTerraform(struct?: ApihubPluginInstanceActions | cdktn.IResolvable): any;
export declare class ApihubPluginInstanceActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApihubPluginInstanceActions | cdktn.IResolvable | undefined;
    set internalValue(value: ApihubPluginInstanceActions | cdktn.IResolvable | undefined);
    private _actionId?;
    get actionId(): string;
    set actionId(value: string);
    get actionIdInput(): string | undefined;
    private _hubInstanceAction;
    get hubInstanceAction(): ApihubPluginInstanceActionsHubInstanceActionList;
    private _scheduleCronExpression?;
    get scheduleCronExpression(): string;
    set scheduleCronExpression(value: string);
    resetScheduleCronExpression(): void;
    get scheduleCronExpressionInput(): string | undefined;
    private _scheduleTimeZone?;
    get scheduleTimeZone(): string;
    set scheduleTimeZone(value: string);
    resetScheduleTimeZone(): void;
    get scheduleTimeZoneInput(): string | undefined;
    get state(): string;
    private _curationConfig;
    get curationConfig(): ApihubPluginInstanceActionsCurationConfigOutputReference;
    putCurationConfig(value: ApihubPluginInstanceActionsCurationConfig): void;
    resetCurationConfig(): void;
    get curationConfigInput(): ApihubPluginInstanceActionsCurationConfig | undefined;
}
export declare class ApihubPluginInstanceActionsList extends cdktn.ComplexList {
    internalValue?: ApihubPluginInstanceActions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApihubPluginInstanceActionsOutputReference;
}
export interface ApihubPluginInstanceAuthConfigApiKeyConfigApiKey {
    /**
    * The resource name of the secret version in the format,
    * format as: 'projects/* /secrets/* /versions/*'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#secret_version ApihubPluginInstance#secret_version}
     *
    * Note: The above comment contained a comment block ending sequence (* followed by /). We have introduced a space between to prevent syntax errors. Please ignore the space.
    */
    readonly secretVersion: string;
}
export declare function apihubPluginInstanceAuthConfigApiKeyConfigApiKeyToTerraform(struct?: ApihubPluginInstanceAuthConfigApiKeyConfigApiKeyOutputReference | ApihubPluginInstanceAuthConfigApiKeyConfigApiKey): any;
export declare function apihubPluginInstanceAuthConfigApiKeyConfigApiKeyToHclTerraform(struct?: ApihubPluginInstanceAuthConfigApiKeyConfigApiKeyOutputReference | ApihubPluginInstanceAuthConfigApiKeyConfigApiKey): any;
export declare class ApihubPluginInstanceAuthConfigApiKeyConfigApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApihubPluginInstanceAuthConfigApiKeyConfigApiKey | undefined;
    set internalValue(value: ApihubPluginInstanceAuthConfigApiKeyConfigApiKey | undefined);
    private _secretVersion?;
    get secretVersion(): string;
    set secretVersion(value: string);
    get secretVersionInput(): string | undefined;
}
export interface ApihubPluginInstanceAuthConfigApiKeyConfig {
    /**
    * The location of the API key.
    * The default value is QUERY.
    * Possible values:
    * HTTP_ELEMENT_LOCATION_UNSPECIFIED
    * QUERY
    * HEADER
    * PATH
    * BODY
    * COOKIE
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#http_element_location ApihubPluginInstance#http_element_location}
    */
    readonly httpElementLocation: string;
    /**
    * The parameter name of the API key.
    * E.g. If the API request is "https://example.com/act?api_key=",
    * "api_key" would be the parameter name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#name ApihubPluginInstance#name}
    */
    readonly name: string;
    /**
    * api_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#api_key ApihubPluginInstance#api_key}
    */
    readonly apiKey: ApihubPluginInstanceAuthConfigApiKeyConfigApiKey;
}
export declare function apihubPluginInstanceAuthConfigApiKeyConfigToTerraform(struct?: ApihubPluginInstanceAuthConfigApiKeyConfigOutputReference | ApihubPluginInstanceAuthConfigApiKeyConfig): any;
export declare function apihubPluginInstanceAuthConfigApiKeyConfigToHclTerraform(struct?: ApihubPluginInstanceAuthConfigApiKeyConfigOutputReference | ApihubPluginInstanceAuthConfigApiKeyConfig): any;
export declare class ApihubPluginInstanceAuthConfigApiKeyConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApihubPluginInstanceAuthConfigApiKeyConfig | undefined;
    set internalValue(value: ApihubPluginInstanceAuthConfigApiKeyConfig | undefined);
    private _httpElementLocation?;
    get httpElementLocation(): string;
    set httpElementLocation(value: string);
    get httpElementLocationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _apiKey;
    get apiKey(): ApihubPluginInstanceAuthConfigApiKeyConfigApiKeyOutputReference;
    putApiKey(value: ApihubPluginInstanceAuthConfigApiKeyConfigApiKey): void;
    get apiKeyInput(): ApihubPluginInstanceAuthConfigApiKeyConfigApiKey | undefined;
}
export interface ApihubPluginInstanceAuthConfigGoogleServiceAccountConfig {
    /**
    * The service account to be used for authenticating request.
    *
    * The 'iam.serviceAccounts.getAccessToken' permission should be granted on
    * this service account to the impersonator service account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#service_account ApihubPluginInstance#service_account}
    */
    readonly serviceAccount: string;
}
export declare function apihubPluginInstanceAuthConfigGoogleServiceAccountConfigToTerraform(struct?: ApihubPluginInstanceAuthConfigGoogleServiceAccountConfigOutputReference | ApihubPluginInstanceAuthConfigGoogleServiceAccountConfig): any;
export declare function apihubPluginInstanceAuthConfigGoogleServiceAccountConfigToHclTerraform(struct?: ApihubPluginInstanceAuthConfigGoogleServiceAccountConfigOutputReference | ApihubPluginInstanceAuthConfigGoogleServiceAccountConfig): any;
export declare class ApihubPluginInstanceAuthConfigGoogleServiceAccountConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApihubPluginInstanceAuthConfigGoogleServiceAccountConfig | undefined;
    set internalValue(value: ApihubPluginInstanceAuthConfigGoogleServiceAccountConfig | undefined);
    private _serviceAccount?;
    get serviceAccount(): string;
    set serviceAccount(value: string);
    get serviceAccountInput(): string | undefined;
}
export interface ApihubPluginInstanceAuthConfigOauth2ClientCredentialsConfigClientSecret {
    /**
    * The resource name of the secret version in the format,
    * format as: 'projects/* /secrets/* /versions/*'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#secret_version ApihubPluginInstance#secret_version}
     *
    * Note: The above comment contained a comment block ending sequence (* followed by /). We have introduced a space between to prevent syntax errors. Please ignore the space.
    */
    readonly secretVersion: string;
}
export declare function apihubPluginInstanceAuthConfigOauth2ClientCredentialsConfigClientSecretToTerraform(struct?: ApihubPluginInstanceAuthConfigOauth2ClientCredentialsConfigClientSecretOutputReference | ApihubPluginInstanceAuthConfigOauth2ClientCredentialsConfigClientSecret): any;
export declare function apihubPluginInstanceAuthConfigOauth2ClientCredentialsConfigClientSecretToHclTerraform(struct?: ApihubPluginInstanceAuthConfigOauth2ClientCredentialsConfigClientSecretOutputReference | ApihubPluginInstanceAuthConfigOauth2ClientCredentialsConfigClientSecret): any;
export declare class ApihubPluginInstanceAuthConfigOauth2ClientCredentialsConfigClientSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApihubPluginInstanceAuthConfigOauth2ClientCredentialsConfigClientSecret | undefined;
    set internalValue(value: ApihubPluginInstanceAuthConfigOauth2ClientCredentialsConfigClientSecret | undefined);
    private _secretVersion?;
    get secretVersion(): string;
    set secretVersion(value: string);
    get secretVersionInput(): string | undefined;
}
export interface ApihubPluginInstanceAuthConfigOauth2ClientCredentialsConfig {
    /**
    * The client identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#client_id ApihubPluginInstance#client_id}
    */
    readonly clientId: string;
    /**
    * client_secret block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#client_secret ApihubPluginInstance#client_secret}
    */
    readonly clientSecret: ApihubPluginInstanceAuthConfigOauth2ClientCredentialsConfigClientSecret;
}
export declare function apihubPluginInstanceAuthConfigOauth2ClientCredentialsConfigToTerraform(struct?: ApihubPluginInstanceAuthConfigOauth2ClientCredentialsConfigOutputReference | ApihubPluginInstanceAuthConfigOauth2ClientCredentialsConfig): any;
export declare function apihubPluginInstanceAuthConfigOauth2ClientCredentialsConfigToHclTerraform(struct?: ApihubPluginInstanceAuthConfigOauth2ClientCredentialsConfigOutputReference | ApihubPluginInstanceAuthConfigOauth2ClientCredentialsConfig): any;
export declare class ApihubPluginInstanceAuthConfigOauth2ClientCredentialsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApihubPluginInstanceAuthConfigOauth2ClientCredentialsConfig | undefined;
    set internalValue(value: ApihubPluginInstanceAuthConfigOauth2ClientCredentialsConfig | undefined);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    get clientIdInput(): string | undefined;
    private _clientSecret;
    get clientSecret(): ApihubPluginInstanceAuthConfigOauth2ClientCredentialsConfigClientSecretOutputReference;
    putClientSecret(value: ApihubPluginInstanceAuthConfigOauth2ClientCredentialsConfigClientSecret): void;
    get clientSecretInput(): ApihubPluginInstanceAuthConfigOauth2ClientCredentialsConfigClientSecret | undefined;
}
export interface ApihubPluginInstanceAuthConfigUserPasswordConfigPassword {
    /**
    * The resource name of the secret version in the format,
    * format as: 'projects/* /secrets/* /versions/*'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#secret_version ApihubPluginInstance#secret_version}
     *
    * Note: The above comment contained a comment block ending sequence (* followed by /). We have introduced a space between to prevent syntax errors. Please ignore the space.
    */
    readonly secretVersion: string;
}
export declare function apihubPluginInstanceAuthConfigUserPasswordConfigPasswordToTerraform(struct?: ApihubPluginInstanceAuthConfigUserPasswordConfigPasswordOutputReference | ApihubPluginInstanceAuthConfigUserPasswordConfigPassword): any;
export declare function apihubPluginInstanceAuthConfigUserPasswordConfigPasswordToHclTerraform(struct?: ApihubPluginInstanceAuthConfigUserPasswordConfigPasswordOutputReference | ApihubPluginInstanceAuthConfigUserPasswordConfigPassword): any;
export declare class ApihubPluginInstanceAuthConfigUserPasswordConfigPasswordOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApihubPluginInstanceAuthConfigUserPasswordConfigPassword | undefined;
    set internalValue(value: ApihubPluginInstanceAuthConfigUserPasswordConfigPassword | undefined);
    private _secretVersion?;
    get secretVersion(): string;
    set secretVersion(value: string);
    get secretVersionInput(): string | undefined;
}
export interface ApihubPluginInstanceAuthConfigUserPasswordConfig {
    /**
    * Username.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#username ApihubPluginInstance#username}
    */
    readonly username: string;
    /**
    * password block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#password ApihubPluginInstance#password}
    */
    readonly password: ApihubPluginInstanceAuthConfigUserPasswordConfigPassword;
}
export declare function apihubPluginInstanceAuthConfigUserPasswordConfigToTerraform(struct?: ApihubPluginInstanceAuthConfigUserPasswordConfigOutputReference | ApihubPluginInstanceAuthConfigUserPasswordConfig): any;
export declare function apihubPluginInstanceAuthConfigUserPasswordConfigToHclTerraform(struct?: ApihubPluginInstanceAuthConfigUserPasswordConfigOutputReference | ApihubPluginInstanceAuthConfigUserPasswordConfig): any;
export declare class ApihubPluginInstanceAuthConfigUserPasswordConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApihubPluginInstanceAuthConfigUserPasswordConfig | undefined;
    set internalValue(value: ApihubPluginInstanceAuthConfigUserPasswordConfig | undefined);
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
    private _password;
    get password(): ApihubPluginInstanceAuthConfigUserPasswordConfigPasswordOutputReference;
    putPassword(value: ApihubPluginInstanceAuthConfigUserPasswordConfigPassword): void;
    get passwordInput(): ApihubPluginInstanceAuthConfigUserPasswordConfigPassword | undefined;
}
export interface ApihubPluginInstanceAuthConfig {
    /**
    * Possible values:
    * AUTH_TYPE_UNSPECIFIED
    * NO_AUTH
    * GOOGLE_SERVICE_ACCOUNT
    * USER_PASSWORD
    * API_KEY
    * OAUTH2_CLIENT_CREDENTIALS
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#auth_type ApihubPluginInstance#auth_type}
    */
    readonly authType: string;
    /**
    * api_key_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#api_key_config ApihubPluginInstance#api_key_config}
    */
    readonly apiKeyConfig?: ApihubPluginInstanceAuthConfigApiKeyConfig;
    /**
    * google_service_account_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#google_service_account_config ApihubPluginInstance#google_service_account_config}
    */
    readonly googleServiceAccountConfig?: ApihubPluginInstanceAuthConfigGoogleServiceAccountConfig;
    /**
    * oauth2_client_credentials_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#oauth2_client_credentials_config ApihubPluginInstance#oauth2_client_credentials_config}
    */
    readonly oauth2ClientCredentialsConfig?: ApihubPluginInstanceAuthConfigOauth2ClientCredentialsConfig;
    /**
    * user_password_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#user_password_config ApihubPluginInstance#user_password_config}
    */
    readonly userPasswordConfig?: ApihubPluginInstanceAuthConfigUserPasswordConfig;
}
export declare function apihubPluginInstanceAuthConfigToTerraform(struct?: ApihubPluginInstanceAuthConfigOutputReference | ApihubPluginInstanceAuthConfig): any;
export declare function apihubPluginInstanceAuthConfigToHclTerraform(struct?: ApihubPluginInstanceAuthConfigOutputReference | ApihubPluginInstanceAuthConfig): any;
export declare class ApihubPluginInstanceAuthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApihubPluginInstanceAuthConfig | undefined;
    set internalValue(value: ApihubPluginInstanceAuthConfig | undefined);
    private _authType?;
    get authType(): string;
    set authType(value: string);
    get authTypeInput(): string | undefined;
    private _apiKeyConfig;
    get apiKeyConfig(): ApihubPluginInstanceAuthConfigApiKeyConfigOutputReference;
    putApiKeyConfig(value: ApihubPluginInstanceAuthConfigApiKeyConfig): void;
    resetApiKeyConfig(): void;
    get apiKeyConfigInput(): ApihubPluginInstanceAuthConfigApiKeyConfig | undefined;
    private _googleServiceAccountConfig;
    get googleServiceAccountConfig(): ApihubPluginInstanceAuthConfigGoogleServiceAccountConfigOutputReference;
    putGoogleServiceAccountConfig(value: ApihubPluginInstanceAuthConfigGoogleServiceAccountConfig): void;
    resetGoogleServiceAccountConfig(): void;
    get googleServiceAccountConfigInput(): ApihubPluginInstanceAuthConfigGoogleServiceAccountConfig | undefined;
    private _oauth2ClientCredentialsConfig;
    get oauth2ClientCredentialsConfig(): ApihubPluginInstanceAuthConfigOauth2ClientCredentialsConfigOutputReference;
    putOauth2ClientCredentialsConfig(value: ApihubPluginInstanceAuthConfigOauth2ClientCredentialsConfig): void;
    resetOauth2ClientCredentialsConfig(): void;
    get oauth2ClientCredentialsConfigInput(): ApihubPluginInstanceAuthConfigOauth2ClientCredentialsConfig | undefined;
    private _userPasswordConfig;
    get userPasswordConfig(): ApihubPluginInstanceAuthConfigUserPasswordConfigOutputReference;
    putUserPasswordConfig(value: ApihubPluginInstanceAuthConfigUserPasswordConfig): void;
    resetUserPasswordConfig(): void;
    get userPasswordConfigInput(): ApihubPluginInstanceAuthConfigUserPasswordConfig | undefined;
}
export interface ApihubPluginInstanceTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#create ApihubPluginInstance#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#delete ApihubPluginInstance#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#update ApihubPluginInstance#update}
    */
    readonly update?: string;
}
export declare function apihubPluginInstanceTimeoutsToTerraform(struct?: ApihubPluginInstanceTimeouts | cdktn.IResolvable): any;
export declare function apihubPluginInstanceTimeoutsToHclTerraform(struct?: ApihubPluginInstanceTimeouts | cdktn.IResolvable): any;
export declare class ApihubPluginInstanceTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApihubPluginInstanceTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApihubPluginInstanceTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance google_apihub_plugin_instance}
*/
export declare class ApihubPluginInstance extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apihub_plugin_instance";
    /**
    * Generates CDKTN code for importing a ApihubPluginInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApihubPluginInstance to import
    * @param importFromId The id of the existing ApihubPluginInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApihubPluginInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_plugin_instance google_apihub_plugin_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApihubPluginInstanceConfig
    */
    constructor(scope: Construct, id: string, config: ApihubPluginInstanceConfig);
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _disable?;
    get disable(): boolean | cdktn.IResolvable;
    set disable(value: boolean | cdktn.IResolvable);
    resetDisable(): void;
    get disableInput(): boolean | cdktn.IResolvable | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get errorMessage(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _plugin?;
    get plugin(): string;
    set plugin(value: string);
    get pluginInput(): string | undefined;
    private _pluginInstanceId?;
    get pluginInstanceId(): string;
    set pluginInstanceId(value: string);
    get pluginInstanceIdInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _sourceProjectId?;
    get sourceProjectId(): string;
    set sourceProjectId(value: string);
    resetSourceProjectId(): void;
    get sourceProjectIdInput(): string | undefined;
    get state(): string;
    get updateTime(): string;
    private _actions;
    get actions(): ApihubPluginInstanceActionsList;
    putActions(value: ApihubPluginInstanceActions[] | cdktn.IResolvable): void;
    resetActions(): void;
    get actionsInput(): cdktn.IResolvable | ApihubPluginInstanceActions[] | undefined;
    private _authConfig;
    get authConfig(): ApihubPluginInstanceAuthConfigOutputReference;
    putAuthConfig(value: ApihubPluginInstanceAuthConfig): void;
    resetAuthConfig(): void;
    get authConfigInput(): ApihubPluginInstanceAuthConfig | undefined;
    private _timeouts;
    get timeouts(): ApihubPluginInstanceTimeoutsOutputReference;
    putTimeouts(value: ApihubPluginInstanceTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApihubPluginInstanceTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
