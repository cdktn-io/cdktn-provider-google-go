/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigeeSharedflowConfig extends cdktn.TerraformMetaArguments {
    /**
    * Path to the config zip bundle
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_sharedflow#config_bundle ApigeeSharedflow#config_bundle}
    */
    readonly configBundle: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_sharedflow#deletion_policy ApigeeSharedflow#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * A hash of local config bundle in string, user needs to use a Terraform Hash function of their choice. A change in hash will trigger an update.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_sharedflow#detect_md5hash ApigeeSharedflow#detect_md5hash}
    */
    readonly detectMd5Hash?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_sharedflow#id ApigeeSharedflow#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the shared flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_sharedflow#name ApigeeSharedflow#name}
    */
    readonly name: string;
    /**
    * The Apigee Organization name associated with the Apigee instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_sharedflow#org_id ApigeeSharedflow#org_id}
    */
    readonly orgId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_sharedflow#timeouts ApigeeSharedflow#timeouts}
    */
    readonly timeouts?: ApigeeSharedflowTimeouts;
}
export interface ApigeeSharedflowMetaData {
}
export declare function apigeeSharedflowMetaDataToTerraform(struct?: ApigeeSharedflowMetaData): any;
export declare function apigeeSharedflowMetaDataToHclTerraform(struct?: ApigeeSharedflowMetaData): any;
export declare class ApigeeSharedflowMetaDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigeeSharedflowMetaData | undefined;
    set internalValue(value: ApigeeSharedflowMetaData | undefined);
    get createdAt(): string;
    get lastModifiedAt(): string;
    get subType(): string;
}
export declare class ApigeeSharedflowMetaDataList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigeeSharedflowMetaDataOutputReference;
}
export interface ApigeeSharedflowTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_sharedflow#create ApigeeSharedflow#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_sharedflow#delete ApigeeSharedflow#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_sharedflow#update ApigeeSharedflow#update}
    */
    readonly update?: string;
}
export declare function apigeeSharedflowTimeoutsToTerraform(struct?: ApigeeSharedflowTimeouts | cdktn.IResolvable): any;
export declare function apigeeSharedflowTimeoutsToHclTerraform(struct?: ApigeeSharedflowTimeouts | cdktn.IResolvable): any;
export declare class ApigeeSharedflowTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeSharedflowTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeSharedflowTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_sharedflow google_apigee_sharedflow}
*/
export declare class ApigeeSharedflow extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apigee_sharedflow";
    /**
    * Generates CDKTN code for importing a ApigeeSharedflow resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigeeSharedflow to import
    * @param importFromId The id of the existing ApigeeSharedflow that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_sharedflow#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigeeSharedflow to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_sharedflow google_apigee_sharedflow} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigeeSharedflowConfig
    */
    constructor(scope: Construct, id: string, config: ApigeeSharedflowConfig);
    private _configBundle?;
    get configBundle(): string;
    set configBundle(value: string);
    get configBundleInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _detectMd5Hash?;
    get detectMd5Hash(): string;
    set detectMd5Hash(value: string);
    resetDetectMd5Hash(): void;
    get detectMd5HashInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get latestRevisionId(): string;
    get md5Hash(): string;
    private _metaData;
    get metaData(): ApigeeSharedflowMetaDataList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _orgId?;
    get orgId(): string;
    set orgId(value: string);
    get orgIdInput(): string | undefined;
    get revision(): string[];
    private _timeouts;
    get timeouts(): ApigeeSharedflowTimeoutsOutputReference;
    putTimeouts(value: ApigeeSharedflowTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApigeeSharedflowTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
