/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BigqueryRowAccessPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the dataset containing this row access policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_row_access_policy#dataset_id BigqueryRowAccessPolicy#dataset_id}
    */
    readonly datasetId: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_row_access_policy#deletion_policy BigqueryRowAccessPolicy#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * A SQL boolean expression that represents the rows defined by this row
    * access policy, similar to the boolean expression in a WHERE clause of a
    * SELECT query on a table.
    * References to other tables, routines, and temporary functions are not
    * supported.
    *
    * Examples: region="EU"
    * date_field = CAST('2019-9-27' as DATE)
    * nullable_field is not NULL
    * numeric_field BETWEEN 1.0 AND 5.0
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_row_access_policy#filter_predicate BigqueryRowAccessPolicy#filter_predicate}
    */
    readonly filterPredicate: string;
    /**
    * Input only. The optional list of iam_member users or groups that specifies the initial
    * members that the row-level access policy should be created with.
    *
    * grantees types:
    * - "user:alice@example.com": An email address that represents a specific
    * Google account.
    * - "serviceAccount:my-other-app@appspot.gserviceaccount.com": An email
    * address that represents a service account.
    * - "group:admins@example.com": An email address that represents a Google
    * group.
    * - "domain:example.com":The Google Workspace domain (primary) that
    * represents all the users of that domain.
    * - "allAuthenticatedUsers": A special identifier that represents all service
    * accounts and all users on the internet who have authenticated with a Google
    * Account. This identifier includes accounts that aren't connected to a
    * Google Workspace or Cloud Identity domain, such as personal Gmail accounts.
    * Users who aren't authenticated, such as anonymous visitors, aren't
    * included.
    * - "allUsers":A special identifier that represents anyone who is on
    * the internet, including authenticated and unauthenticated users. Because
    * BigQuery requires authentication before a user can access the service,
    * allUsers includes only authenticated users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_row_access_policy#grantees BigqueryRowAccessPolicy#grantees}
    */
    readonly grantees?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_row_access_policy#id BigqueryRowAccessPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the row access policy. The ID must contain only
    * letters (a-z, A-Z), numbers (0-9), or underscores (_). The maximum
    * length is 256 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_row_access_policy#policy_id BigqueryRowAccessPolicy#policy_id}
    */
    readonly policyId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_row_access_policy#project BigqueryRowAccessPolicy#project}
    */
    readonly project?: string;
    /**
    * The ID of the table containing this row access policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_row_access_policy#table_id BigqueryRowAccessPolicy#table_id}
    */
    readonly tableId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_row_access_policy#timeouts BigqueryRowAccessPolicy#timeouts}
    */
    readonly timeouts?: BigqueryRowAccessPolicyTimeouts;
}
export interface BigqueryRowAccessPolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_row_access_policy#create BigqueryRowAccessPolicy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_row_access_policy#delete BigqueryRowAccessPolicy#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_row_access_policy#update BigqueryRowAccessPolicy#update}
    */
    readonly update?: string;
}
export declare function bigqueryRowAccessPolicyTimeoutsToTerraform(struct?: BigqueryRowAccessPolicyTimeouts | cdktn.IResolvable): any;
export declare function bigqueryRowAccessPolicyTimeoutsToHclTerraform(struct?: BigqueryRowAccessPolicyTimeouts | cdktn.IResolvable): any;
export declare class BigqueryRowAccessPolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryRowAccessPolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BigqueryRowAccessPolicyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_row_access_policy google_bigquery_row_access_policy}
*/
export declare class BigqueryRowAccessPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_bigquery_row_access_policy";
    /**
    * Generates CDKTN code for importing a BigqueryRowAccessPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BigqueryRowAccessPolicy to import
    * @param importFromId The id of the existing BigqueryRowAccessPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_row_access_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BigqueryRowAccessPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_row_access_policy google_bigquery_row_access_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BigqueryRowAccessPolicyConfig
    */
    constructor(scope: Construct, id: string, config: BigqueryRowAccessPolicyConfig);
    get creationTime(): string;
    private _datasetId?;
    get datasetId(): string;
    set datasetId(value: string);
    get datasetIdInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _filterPredicate?;
    get filterPredicate(): string;
    set filterPredicate(value: string);
    get filterPredicateInput(): string | undefined;
    private _grantees?;
    get grantees(): string[];
    set grantees(value: string[]);
    resetGrantees(): void;
    get granteesInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastModifiedTime(): string;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    get policyIdInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _tableId?;
    get tableId(): string;
    set tableId(value: string);
    get tableIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): BigqueryRowAccessPolicyTimeoutsOutputReference;
    putTimeouts(value: BigqueryRowAccessPolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BigqueryRowAccessPolicyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
