/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CertificateManagerTrustConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_trust_config#deletion_policy CertificateManagerTrustConfig#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * One or more paragraphs of text description of a trust config.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_trust_config#description CertificateManagerTrustConfig#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_trust_config#id CertificateManagerTrustConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Set of label tags associated with the trust config.
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_trust_config#labels CertificateManagerTrustConfig#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The trust config location.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_trust_config#location CertificateManagerTrustConfig#location}
    */
    readonly location: string;
    /**
    * A user-defined name of the trust config. Trust config names must be unique globally.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_trust_config#name CertificateManagerTrustConfig#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_trust_config#project CertificateManagerTrustConfig#project}
    */
    readonly project?: string;
    /**
    * allowlisted_certificates block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_trust_config#allowlisted_certificates CertificateManagerTrustConfig#allowlisted_certificates}
    */
    readonly allowlistedCertificates?: CertificateManagerTrustConfigAllowlistedCertificates[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_trust_config#timeouts CertificateManagerTrustConfig#timeouts}
    */
    readonly timeouts?: CertificateManagerTrustConfigTimeouts;
    /**
    * trust_stores block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_trust_config#trust_stores CertificateManagerTrustConfig#trust_stores}
    */
    readonly trustStores?: CertificateManagerTrustConfigTrustStores[] | cdktn.IResolvable;
}
export interface CertificateManagerTrustConfigAllowlistedCertificates {
    /**
    * PEM certificate that is allowlisted. The certificate can be up to 5k bytes, and must be a parseable X.509 certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_trust_config#pem_certificate CertificateManagerTrustConfig#pem_certificate}
    */
    readonly pemCertificate: string;
}
export declare function certificateManagerTrustConfigAllowlistedCertificatesToTerraform(struct?: CertificateManagerTrustConfigAllowlistedCertificates | cdktn.IResolvable): any;
export declare function certificateManagerTrustConfigAllowlistedCertificatesToHclTerraform(struct?: CertificateManagerTrustConfigAllowlistedCertificates | cdktn.IResolvable): any;
export declare class CertificateManagerTrustConfigAllowlistedCertificatesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CertificateManagerTrustConfigAllowlistedCertificates | cdktn.IResolvable | undefined;
    set internalValue(value: CertificateManagerTrustConfigAllowlistedCertificates | cdktn.IResolvable | undefined);
    private _pemCertificate?;
    get pemCertificate(): string;
    set pemCertificate(value: string);
    get pemCertificateInput(): string | undefined;
}
export declare class CertificateManagerTrustConfigAllowlistedCertificatesList extends cdktn.ComplexList {
    internalValue?: CertificateManagerTrustConfigAllowlistedCertificates[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CertificateManagerTrustConfigAllowlistedCertificatesOutputReference;
}
export interface CertificateManagerTrustConfigTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_trust_config#create CertificateManagerTrustConfig#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_trust_config#delete CertificateManagerTrustConfig#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_trust_config#update CertificateManagerTrustConfig#update}
    */
    readonly update?: string;
}
export declare function certificateManagerTrustConfigTimeoutsToTerraform(struct?: CertificateManagerTrustConfigTimeouts | cdktn.IResolvable): any;
export declare function certificateManagerTrustConfigTimeoutsToHclTerraform(struct?: CertificateManagerTrustConfigTimeouts | cdktn.IResolvable): any;
export declare class CertificateManagerTrustConfigTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CertificateManagerTrustConfigTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CertificateManagerTrustConfigTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface CertificateManagerTrustConfigTrustStoresIntermediateCas {
    /**
    * PEM intermediate certificate used for building up paths for validation.
    * Each certificate provided in PEM format may occupy up to 5kB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_trust_config#pem_certificate CertificateManagerTrustConfig#pem_certificate}
    */
    readonly pemCertificate?: string;
}
export declare function certificateManagerTrustConfigTrustStoresIntermediateCasToTerraform(struct?: CertificateManagerTrustConfigTrustStoresIntermediateCas | cdktn.IResolvable): any;
export declare function certificateManagerTrustConfigTrustStoresIntermediateCasToHclTerraform(struct?: CertificateManagerTrustConfigTrustStoresIntermediateCas | cdktn.IResolvable): any;
export declare class CertificateManagerTrustConfigTrustStoresIntermediateCasOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CertificateManagerTrustConfigTrustStoresIntermediateCas | cdktn.IResolvable | undefined;
    set internalValue(value: CertificateManagerTrustConfigTrustStoresIntermediateCas | cdktn.IResolvable | undefined);
    private _pemCertificate?;
    get pemCertificate(): string;
    set pemCertificate(value: string);
    resetPemCertificate(): void;
    get pemCertificateInput(): string | undefined;
}
export declare class CertificateManagerTrustConfigTrustStoresIntermediateCasList extends cdktn.ComplexList {
    internalValue?: CertificateManagerTrustConfigTrustStoresIntermediateCas[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CertificateManagerTrustConfigTrustStoresIntermediateCasOutputReference;
}
export interface CertificateManagerTrustConfigTrustStoresTrustAnchors {
    /**
    * PEM root certificate of the PKI used for validation.
    * Each certificate provided in PEM format may occupy up to 5kB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_trust_config#pem_certificate CertificateManagerTrustConfig#pem_certificate}
    */
    readonly pemCertificate?: string;
}
export declare function certificateManagerTrustConfigTrustStoresTrustAnchorsToTerraform(struct?: CertificateManagerTrustConfigTrustStoresTrustAnchors | cdktn.IResolvable): any;
export declare function certificateManagerTrustConfigTrustStoresTrustAnchorsToHclTerraform(struct?: CertificateManagerTrustConfigTrustStoresTrustAnchors | cdktn.IResolvable): any;
export declare class CertificateManagerTrustConfigTrustStoresTrustAnchorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CertificateManagerTrustConfigTrustStoresTrustAnchors | cdktn.IResolvable | undefined;
    set internalValue(value: CertificateManagerTrustConfigTrustStoresTrustAnchors | cdktn.IResolvable | undefined);
    private _pemCertificate?;
    get pemCertificate(): string;
    set pemCertificate(value: string);
    resetPemCertificate(): void;
    get pemCertificateInput(): string | undefined;
}
export declare class CertificateManagerTrustConfigTrustStoresTrustAnchorsList extends cdktn.ComplexList {
    internalValue?: CertificateManagerTrustConfigTrustStoresTrustAnchors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CertificateManagerTrustConfigTrustStoresTrustAnchorsOutputReference;
}
export interface CertificateManagerTrustConfigTrustStores {
    /**
    * intermediate_cas block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_trust_config#intermediate_cas CertificateManagerTrustConfig#intermediate_cas}
    */
    readonly intermediateCas?: CertificateManagerTrustConfigTrustStoresIntermediateCas[] | cdktn.IResolvable;
    /**
    * trust_anchors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_trust_config#trust_anchors CertificateManagerTrustConfig#trust_anchors}
    */
    readonly trustAnchors?: CertificateManagerTrustConfigTrustStoresTrustAnchors[] | cdktn.IResolvable;
}
export declare function certificateManagerTrustConfigTrustStoresToTerraform(struct?: CertificateManagerTrustConfigTrustStores | cdktn.IResolvable): any;
export declare function certificateManagerTrustConfigTrustStoresToHclTerraform(struct?: CertificateManagerTrustConfigTrustStores | cdktn.IResolvable): any;
export declare class CertificateManagerTrustConfigTrustStoresOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CertificateManagerTrustConfigTrustStores | cdktn.IResolvable | undefined;
    set internalValue(value: CertificateManagerTrustConfigTrustStores | cdktn.IResolvable | undefined);
    private _intermediateCas;
    get intermediateCas(): CertificateManagerTrustConfigTrustStoresIntermediateCasList;
    putIntermediateCas(value: CertificateManagerTrustConfigTrustStoresIntermediateCas[] | cdktn.IResolvable): void;
    resetIntermediateCas(): void;
    get intermediateCasInput(): cdktn.IResolvable | CertificateManagerTrustConfigTrustStoresIntermediateCas[] | undefined;
    private _trustAnchors;
    get trustAnchors(): CertificateManagerTrustConfigTrustStoresTrustAnchorsList;
    putTrustAnchors(value: CertificateManagerTrustConfigTrustStoresTrustAnchors[] | cdktn.IResolvable): void;
    resetTrustAnchors(): void;
    get trustAnchorsInput(): cdktn.IResolvable | CertificateManagerTrustConfigTrustStoresTrustAnchors[] | undefined;
}
export declare class CertificateManagerTrustConfigTrustStoresList extends cdktn.ComplexList {
    internalValue?: CertificateManagerTrustConfigTrustStores[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CertificateManagerTrustConfigTrustStoresOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_trust_config google_certificate_manager_trust_config}
*/
export declare class CertificateManagerTrustConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_certificate_manager_trust_config";
    /**
    * Generates CDKTN code for importing a CertificateManagerTrustConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CertificateManagerTrustConfig to import
    * @param importFromId The id of the existing CertificateManagerTrustConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_trust_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CertificateManagerTrustConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_trust_config google_certificate_manager_trust_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CertificateManagerTrustConfigConfig
    */
    constructor(scope: Construct, id: string, config: CertificateManagerTrustConfigConfig);
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get updateTime(): string;
    private _allowlistedCertificates;
    get allowlistedCertificates(): CertificateManagerTrustConfigAllowlistedCertificatesList;
    putAllowlistedCertificates(value: CertificateManagerTrustConfigAllowlistedCertificates[] | cdktn.IResolvable): void;
    resetAllowlistedCertificates(): void;
    get allowlistedCertificatesInput(): cdktn.IResolvable | CertificateManagerTrustConfigAllowlistedCertificates[] | undefined;
    private _timeouts;
    get timeouts(): CertificateManagerTrustConfigTimeoutsOutputReference;
    putTimeouts(value: CertificateManagerTrustConfigTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CertificateManagerTrustConfigTimeouts | undefined;
    private _trustStores;
    get trustStores(): CertificateManagerTrustConfigTrustStoresList;
    putTrustStores(value: CertificateManagerTrustConfigTrustStores[] | cdktn.IResolvable): void;
    resetTrustStores(): void;
    get trustStoresInput(): cdktn.IResolvable | CertificateManagerTrustConfigTrustStores[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
