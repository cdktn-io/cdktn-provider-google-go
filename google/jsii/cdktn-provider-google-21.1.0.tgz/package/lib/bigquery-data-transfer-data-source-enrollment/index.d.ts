/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BigqueryDataTransferDataSourceEnrollmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the data source to enroll. For Google Cloud Carbon Footprint exports this is
    * '61cede5a-0000-2440-ad42-883d24f8f7b8'. Call 'projects.dataSources.list' to see the data
    * sources currently enrolled in a project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_data_transfer_data_source_enrollment#data_source_id BigqueryDataTransferDataSourceEnrollment#data_source_id}
    */
    readonly dataSourceId: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_data_transfer_data_source_enrollment#deletion_policy BigqueryDataTransferDataSourceEnrollment#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_data_transfer_data_source_enrollment#id BigqueryDataTransferDataSourceEnrollment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_data_transfer_data_source_enrollment#project BigqueryDataTransferDataSourceEnrollment#project}
    */
    readonly project?: string;
    /**
    * The location whose 'unenrollDataSources' endpoint is called when this resource is destroyed.
    * Enrollment itself is project-wide and unenrolling through any location removes it everywhere;
    * this only exists because the API offers no project-level unenroll method. Override it only if
    * 'us' is not routable for the project, for example under a data-residency organization policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_data_transfer_data_source_enrollment#unenroll_location BigqueryDataTransferDataSourceEnrollment#unenroll_location}
    */
    readonly unenrollLocation?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_data_transfer_data_source_enrollment#timeouts BigqueryDataTransferDataSourceEnrollment#timeouts}
    */
    readonly timeouts?: BigqueryDataTransferDataSourceEnrollmentTimeouts;
}
export interface BigqueryDataTransferDataSourceEnrollmentParameters {
}
export declare function bigqueryDataTransferDataSourceEnrollmentParametersToTerraform(struct?: BigqueryDataTransferDataSourceEnrollmentParameters): any;
export declare function bigqueryDataTransferDataSourceEnrollmentParametersToHclTerraform(struct?: BigqueryDataTransferDataSourceEnrollmentParameters): any;
export declare class BigqueryDataTransferDataSourceEnrollmentParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BigqueryDataTransferDataSourceEnrollmentParameters | undefined;
    set internalValue(value: BigqueryDataTransferDataSourceEnrollmentParameters | undefined);
    get allowedValues(): string[];
    get deprecated(): cdktn.IResolvable;
    get description(): string;
    get displayName(): string;
    get immutable(): cdktn.IResolvable;
    get maxListSize(): number;
    get maxValue(): number;
    get minValue(): number;
    get paramId(): string;
    get required(): cdktn.IResolvable;
    get type(): string;
    get validationDescription(): string;
    get validationHelpUrl(): string;
    get validationRegex(): string;
}
export declare class BigqueryDataTransferDataSourceEnrollmentParametersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BigqueryDataTransferDataSourceEnrollmentParametersOutputReference;
}
export interface BigqueryDataTransferDataSourceEnrollmentTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_data_transfer_data_source_enrollment#create BigqueryDataTransferDataSourceEnrollment#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_data_transfer_data_source_enrollment#delete BigqueryDataTransferDataSourceEnrollment#delete}
    */
    readonly delete?: string;
}
export declare function bigqueryDataTransferDataSourceEnrollmentTimeoutsToTerraform(struct?: BigqueryDataTransferDataSourceEnrollmentTimeouts | cdktn.IResolvable): any;
export declare function bigqueryDataTransferDataSourceEnrollmentTimeoutsToHclTerraform(struct?: BigqueryDataTransferDataSourceEnrollmentTimeouts | cdktn.IResolvable): any;
export declare class BigqueryDataTransferDataSourceEnrollmentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryDataTransferDataSourceEnrollmentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BigqueryDataTransferDataSourceEnrollmentTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_data_transfer_data_source_enrollment google_bigquery_data_transfer_data_source_enrollment}
*/
export declare class BigqueryDataTransferDataSourceEnrollment extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_bigquery_data_transfer_data_source_enrollment";
    /**
    * Generates CDKTN code for importing a BigqueryDataTransferDataSourceEnrollment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BigqueryDataTransferDataSourceEnrollment to import
    * @param importFromId The id of the existing BigqueryDataTransferDataSourceEnrollment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_data_transfer_data_source_enrollment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BigqueryDataTransferDataSourceEnrollment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_data_transfer_data_source_enrollment google_bigquery_data_transfer_data_source_enrollment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BigqueryDataTransferDataSourceEnrollmentConfig
    */
    constructor(scope: Construct, id: string, config: BigqueryDataTransferDataSourceEnrollmentConfig);
    get authorizationType(): string;
    get clientId(): string;
    get dataRefreshType(): string;
    private _dataSourceId?;
    get dataSourceId(): string;
    set dataSourceId(value: string);
    get dataSourceIdInput(): string | undefined;
    get defaultDataRefreshWindowDays(): number;
    get defaultSchedule(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    get description(): string;
    get displayName(): string;
    get helpUrl(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get manualRunsDisabled(): cdktn.IResolvable;
    get minimumScheduleInterval(): string;
    get name(): string;
    private _parameters;
    get parameters(): BigqueryDataTransferDataSourceEnrollmentParametersList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get scopes(): string[];
    get supportsCustomSchedule(): cdktn.IResolvable;
    private _unenrollLocation?;
    get unenrollLocation(): string;
    set unenrollLocation(value: string);
    resetUnenrollLocation(): void;
    get unenrollLocationInput(): string | undefined;
    get updateDeadlineSeconds(): number;
    private _timeouts;
    get timeouts(): BigqueryDataTransferDataSourceEnrollmentTimeoutsOutputReference;
    putTimeouts(value: BigqueryDataTransferDataSourceEnrollmentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BigqueryDataTransferDataSourceEnrollmentTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
