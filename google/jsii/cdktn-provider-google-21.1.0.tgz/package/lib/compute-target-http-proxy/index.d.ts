/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeTargetHttpProxyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_http_proxy#deletion_policy ComputeTargetHttpProxy#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_http_proxy#description ComputeTargetHttpProxy#description}
    */
    readonly description?: string;
    /**
    * Specifies how long to keep a connection open, after completing a response,
    * while there is no matching traffic (in seconds). If an HTTP keepalive is
    * not specified, a default value will be used. For Global
    * external HTTP(S) load balancer, the default value is 610 seconds, the
    * minimum allowed value is 5 seconds and the maximum allowed value is 1200
    * seconds. For cross-region internal HTTP(S) load balancer, the default
    * value is 600 seconds, the minimum allowed value is 5 seconds, and the
    * maximum allowed value is 600 seconds. For Global external HTTP(S) load
    * balancer (classic), this option is not available publicly.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_http_proxy#http_keep_alive_timeout_sec ComputeTargetHttpProxy#http_keep_alive_timeout_sec}
    */
    readonly httpKeepAliveTimeoutSec?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_http_proxy#id ComputeTargetHttpProxy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the resource. Provided by the client when the resource is
    * created. The name must be 1-63 characters long, and comply with
    * RFC1035. Specifically, the name must be 1-63 characters long and match
    * the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the
    * first character must be a lowercase letter, and all following
    * characters must be a dash, lowercase letter, or digit, except the last
    * character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_http_proxy#name ComputeTargetHttpProxy#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_http_proxy#project ComputeTargetHttpProxy#project}
    */
    readonly project?: string;
    /**
    * This field only applies when the forwarding rule that references
    * this target proxy has a loadBalancingScheme set to INTERNAL_SELF_MANAGED.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_http_proxy#proxy_bind ComputeTargetHttpProxy#proxy_bind}
    */
    readonly proxyBind?: boolean | cdktn.IResolvable;
    /**
    * A reference to the UrlMap resource that defines the mapping from URL
    * to the BackendService.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_http_proxy#url_map ComputeTargetHttpProxy#url_map}
    */
    readonly urlMap: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_http_proxy#timeouts ComputeTargetHttpProxy#timeouts}
    */
    readonly timeouts?: ComputeTargetHttpProxyTimeouts;
}
export interface ComputeTargetHttpProxyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_http_proxy#create ComputeTargetHttpProxy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_http_proxy#delete ComputeTargetHttpProxy#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_http_proxy#update ComputeTargetHttpProxy#update}
    */
    readonly update?: string;
}
export declare function computeTargetHttpProxyTimeoutsToTerraform(struct?: ComputeTargetHttpProxyTimeouts | cdktn.IResolvable): any;
export declare function computeTargetHttpProxyTimeoutsToHclTerraform(struct?: ComputeTargetHttpProxyTimeouts | cdktn.IResolvable): any;
export declare class ComputeTargetHttpProxyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeTargetHttpProxyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeTargetHttpProxyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_http_proxy google_compute_target_http_proxy}
*/
export declare class ComputeTargetHttpProxy extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_target_http_proxy";
    /**
    * Generates CDKTN code for importing a ComputeTargetHttpProxy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeTargetHttpProxy to import
    * @param importFromId The id of the existing ComputeTargetHttpProxy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_http_proxy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeTargetHttpProxy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_http_proxy google_compute_target_http_proxy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeTargetHttpProxyConfig
    */
    constructor(scope: Construct, id: string, config: ComputeTargetHttpProxyConfig);
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get fingerprint(): string;
    private _httpKeepAliveTimeoutSec?;
    get httpKeepAliveTimeoutSec(): number;
    set httpKeepAliveTimeoutSec(value: number);
    resetHttpKeepAliveTimeoutSec(): void;
    get httpKeepAliveTimeoutSecInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _proxyBind?;
    get proxyBind(): boolean | cdktn.IResolvable;
    set proxyBind(value: boolean | cdktn.IResolvable);
    resetProxyBind(): void;
    get proxyBindInput(): boolean | cdktn.IResolvable | undefined;
    get proxyId(): number;
    get selfLink(): string;
    private _urlMap?;
    get urlMap(): string;
    set urlMap(value: string);
    get urlMapInput(): string | undefined;
    private _timeouts;
    get timeouts(): ComputeTargetHttpProxyTimeoutsOutputReference;
    putTimeouts(value: ComputeTargetHttpProxyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeTargetHttpProxyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
