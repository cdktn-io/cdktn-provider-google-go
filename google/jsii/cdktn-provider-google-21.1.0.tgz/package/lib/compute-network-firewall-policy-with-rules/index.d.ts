/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeNetworkFirewallPolicyWithRulesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#deletion_policy ComputeNetworkFirewallPolicyWithRules#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#description ComputeNetworkFirewallPolicyWithRules#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#id ComputeNetworkFirewallPolicyWithRules#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * User-provided name of the Network firewall policy.
    * The name should be unique in the project in which the firewall policy is created.
    * The name must be 1-63 characters long, and comply with RFC1035. Specifically,
    * the name must be 1-63 characters long and match the regular expression [a-z]([-a-z0-9]*[a-z0-9])?
    * which means the first character must be a lowercase letter, and all following characters must be a dash,
    * lowercase letter, or digit, except the last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#name ComputeNetworkFirewallPolicyWithRules#name}
    */
    readonly name: string;
    /**
    * Policy type is used to determine which resources (networks) the policy can be associated with.
    * A policy can be associated with a network only if the network has the matching policyType in its network profile.
    * Different policy types may support some of the Firewall Rules features. Possible values: ["VPC_POLICY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#policy_type ComputeNetworkFirewallPolicyWithRules#policy_type}
    */
    readonly policyType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#project ComputeNetworkFirewallPolicyWithRules#project}
    */
    readonly project?: string;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#rule ComputeNetworkFirewallPolicyWithRules#rule}
    */
    readonly rule: ComputeNetworkFirewallPolicyWithRulesRule[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#timeouts ComputeNetworkFirewallPolicyWithRules#timeouts}
    */
    readonly timeouts?: ComputeNetworkFirewallPolicyWithRulesTimeouts;
}
export interface ComputeNetworkFirewallPolicyWithRulesPredefinedRulesMatchLayer4Config {
}
export declare function computeNetworkFirewallPolicyWithRulesPredefinedRulesMatchLayer4ConfigToTerraform(struct?: ComputeNetworkFirewallPolicyWithRulesPredefinedRulesMatchLayer4Config): any;
export declare function computeNetworkFirewallPolicyWithRulesPredefinedRulesMatchLayer4ConfigToHclTerraform(struct?: ComputeNetworkFirewallPolicyWithRulesPredefinedRulesMatchLayer4Config): any;
export declare class ComputeNetworkFirewallPolicyWithRulesPredefinedRulesMatchLayer4ConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeNetworkFirewallPolicyWithRulesPredefinedRulesMatchLayer4Config | undefined;
    set internalValue(value: ComputeNetworkFirewallPolicyWithRulesPredefinedRulesMatchLayer4Config | undefined);
    get ipProtocol(): string;
    get ports(): string[];
}
export declare class ComputeNetworkFirewallPolicyWithRulesPredefinedRulesMatchLayer4ConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeNetworkFirewallPolicyWithRulesPredefinedRulesMatchLayer4ConfigOutputReference;
}
export interface ComputeNetworkFirewallPolicyWithRulesPredefinedRulesMatchSrcSecureTag {
}
export declare function computeNetworkFirewallPolicyWithRulesPredefinedRulesMatchSrcSecureTagToTerraform(struct?: ComputeNetworkFirewallPolicyWithRulesPredefinedRulesMatchSrcSecureTag): any;
export declare function computeNetworkFirewallPolicyWithRulesPredefinedRulesMatchSrcSecureTagToHclTerraform(struct?: ComputeNetworkFirewallPolicyWithRulesPredefinedRulesMatchSrcSecureTag): any;
export declare class ComputeNetworkFirewallPolicyWithRulesPredefinedRulesMatchSrcSecureTagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeNetworkFirewallPolicyWithRulesPredefinedRulesMatchSrcSecureTag | undefined;
    set internalValue(value: ComputeNetworkFirewallPolicyWithRulesPredefinedRulesMatchSrcSecureTag | undefined);
    get name(): string;
    get state(): string;
}
export declare class ComputeNetworkFirewallPolicyWithRulesPredefinedRulesMatchSrcSecureTagList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeNetworkFirewallPolicyWithRulesPredefinedRulesMatchSrcSecureTagOutputReference;
}
export interface ComputeNetworkFirewallPolicyWithRulesPredefinedRulesMatch {
}
export declare function computeNetworkFirewallPolicyWithRulesPredefinedRulesMatchToTerraform(struct?: ComputeNetworkFirewallPolicyWithRulesPredefinedRulesMatch): any;
export declare function computeNetworkFirewallPolicyWithRulesPredefinedRulesMatchToHclTerraform(struct?: ComputeNetworkFirewallPolicyWithRulesPredefinedRulesMatch): any;
export declare class ComputeNetworkFirewallPolicyWithRulesPredefinedRulesMatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeNetworkFirewallPolicyWithRulesPredefinedRulesMatch | undefined;
    set internalValue(value: ComputeNetworkFirewallPolicyWithRulesPredefinedRulesMatch | undefined);
    get destAddressGroups(): string[];
    get destFqdns(): string[];
    get destIpRanges(): string[];
    get destRegionCodes(): string[];
    get destThreatIntelligences(): string[];
    private _layer4Config;
    get layer4Config(): ComputeNetworkFirewallPolicyWithRulesPredefinedRulesMatchLayer4ConfigList;
    get srcAddressGroups(): string[];
    get srcFqdns(): string[];
    get srcIpRanges(): string[];
    get srcRegionCodes(): string[];
    private _srcSecureTag;
    get srcSecureTag(): ComputeNetworkFirewallPolicyWithRulesPredefinedRulesMatchSrcSecureTagList;
    get srcThreatIntelligences(): string[];
}
export declare class ComputeNetworkFirewallPolicyWithRulesPredefinedRulesMatchList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeNetworkFirewallPolicyWithRulesPredefinedRulesMatchOutputReference;
}
export interface ComputeNetworkFirewallPolicyWithRulesPredefinedRulesTargetSecureTag {
}
export declare function computeNetworkFirewallPolicyWithRulesPredefinedRulesTargetSecureTagToTerraform(struct?: ComputeNetworkFirewallPolicyWithRulesPredefinedRulesTargetSecureTag): any;
export declare function computeNetworkFirewallPolicyWithRulesPredefinedRulesTargetSecureTagToHclTerraform(struct?: ComputeNetworkFirewallPolicyWithRulesPredefinedRulesTargetSecureTag): any;
export declare class ComputeNetworkFirewallPolicyWithRulesPredefinedRulesTargetSecureTagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeNetworkFirewallPolicyWithRulesPredefinedRulesTargetSecureTag | undefined;
    set internalValue(value: ComputeNetworkFirewallPolicyWithRulesPredefinedRulesTargetSecureTag | undefined);
    get name(): string;
    get state(): string;
}
export declare class ComputeNetworkFirewallPolicyWithRulesPredefinedRulesTargetSecureTagList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeNetworkFirewallPolicyWithRulesPredefinedRulesTargetSecureTagOutputReference;
}
export interface ComputeNetworkFirewallPolicyWithRulesPredefinedRules {
}
export declare function computeNetworkFirewallPolicyWithRulesPredefinedRulesToTerraform(struct?: ComputeNetworkFirewallPolicyWithRulesPredefinedRules): any;
export declare function computeNetworkFirewallPolicyWithRulesPredefinedRulesToHclTerraform(struct?: ComputeNetworkFirewallPolicyWithRulesPredefinedRules): any;
export declare class ComputeNetworkFirewallPolicyWithRulesPredefinedRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeNetworkFirewallPolicyWithRulesPredefinedRules | undefined;
    set internalValue(value: ComputeNetworkFirewallPolicyWithRulesPredefinedRules | undefined);
    get action(): string;
    get description(): string;
    get direction(): string;
    get disabled(): cdktn.IResolvable;
    get enableLogging(): cdktn.IResolvable;
    private _match;
    get match(): ComputeNetworkFirewallPolicyWithRulesPredefinedRulesMatchList;
    get priority(): number;
    get ruleName(): string;
    get securityProfileGroup(): string;
    private _targetSecureTag;
    get targetSecureTag(): ComputeNetworkFirewallPolicyWithRulesPredefinedRulesTargetSecureTagList;
    get targetServiceAccounts(): string[];
    get tlsInspect(): cdktn.IResolvable;
}
export declare class ComputeNetworkFirewallPolicyWithRulesPredefinedRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeNetworkFirewallPolicyWithRulesPredefinedRulesOutputReference;
}
export interface ComputeNetworkFirewallPolicyWithRulesRuleMatchLayer4Config {
    /**
    * The IP protocol to which this rule applies. The protocol
    * type is required when creating a firewall rule.
    * This value can either be one of the following well
    * known protocol strings (tcp, udp, icmp, esp, ah, ipip, sctp),
    * or the IP protocol number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#ip_protocol ComputeNetworkFirewallPolicyWithRules#ip_protocol}
    */
    readonly ipProtocol: string;
    /**
    * An optional list of ports to which this rule applies. This field
    * is only applicable for UDP or TCP protocol. Each entry must be
    * either an integer or a range. If not specified, this rule
    * applies to connections through any port.
    * Example inputs include: ["22"], ["80","443"], and
    * ["12345-12349"].
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#ports ComputeNetworkFirewallPolicyWithRules#ports}
    */
    readonly ports?: string[];
}
export declare function computeNetworkFirewallPolicyWithRulesRuleMatchLayer4ConfigToTerraform(struct?: ComputeNetworkFirewallPolicyWithRulesRuleMatchLayer4Config | cdktn.IResolvable): any;
export declare function computeNetworkFirewallPolicyWithRulesRuleMatchLayer4ConfigToHclTerraform(struct?: ComputeNetworkFirewallPolicyWithRulesRuleMatchLayer4Config | cdktn.IResolvable): any;
export declare class ComputeNetworkFirewallPolicyWithRulesRuleMatchLayer4ConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeNetworkFirewallPolicyWithRulesRuleMatchLayer4Config | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeNetworkFirewallPolicyWithRulesRuleMatchLayer4Config | cdktn.IResolvable | undefined);
    private _ipProtocol?;
    get ipProtocol(): string;
    set ipProtocol(value: string);
    get ipProtocolInput(): string | undefined;
    private _ports?;
    get ports(): string[];
    set ports(value: string[]);
    resetPorts(): void;
    get portsInput(): string[] | undefined;
}
export declare class ComputeNetworkFirewallPolicyWithRulesRuleMatchLayer4ConfigList extends cdktn.ComplexList {
    internalValue?: ComputeNetworkFirewallPolicyWithRulesRuleMatchLayer4Config[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeNetworkFirewallPolicyWithRulesRuleMatchLayer4ConfigOutputReference;
}
export interface ComputeNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTag {
    /**
    * Name of the secure tag, created with TagManager's TagValue API.
    * @pattern tagValues/[0-9]+
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#name ComputeNetworkFirewallPolicyWithRules#name}
    */
    readonly name?: string;
}
export declare function computeNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTagToTerraform(struct?: ComputeNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTag | cdktn.IResolvable): any;
export declare function computeNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTagToHclTerraform(struct?: ComputeNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTag | cdktn.IResolvable): any;
export declare class ComputeNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTag | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTag | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get state(): string;
}
export declare class ComputeNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTagList extends cdktn.ComplexList {
    internalValue?: ComputeNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTag[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTagOutputReference;
}
export interface ComputeNetworkFirewallPolicyWithRulesRuleMatch {
    /**
    * Address groups which should be matched against the traffic destination.
    * Maximum number of destination address groups is 10.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#dest_address_groups ComputeNetworkFirewallPolicyWithRules#dest_address_groups}
    */
    readonly destAddressGroups?: string[];
    /**
    * Fully Qualified Domain Name (FQDN) which should be matched against
    * traffic destination. Maximum number of destination fqdn allowed is 100.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#dest_fqdns ComputeNetworkFirewallPolicyWithRules#dest_fqdns}
    */
    readonly destFqdns?: string[];
    /**
    * Destination IP address range in CIDR format. Required for
    * EGRESS rules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#dest_ip_ranges ComputeNetworkFirewallPolicyWithRules#dest_ip_ranges}
    */
    readonly destIpRanges?: string[];
    /**
    * Region codes whose IP addresses will be used to match for destination
    * of traffic. Should be specified as 2 letter country code defined as per
    * ISO 3166 alpha-2 country codes. ex."US"
    * Maximum number of destination region codes allowed is 5000.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#dest_region_codes ComputeNetworkFirewallPolicyWithRules#dest_region_codes}
    */
    readonly destRegionCodes?: string[];
    /**
    * Names of Network Threat Intelligence lists.
    * The IPs in these lists will be matched against traffic destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#dest_threat_intelligences ComputeNetworkFirewallPolicyWithRules#dest_threat_intelligences}
    */
    readonly destThreatIntelligences?: string[];
    /**
    * Address groups which should be matched against the traffic source.
    * Maximum number of source address groups is 10.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#src_address_groups ComputeNetworkFirewallPolicyWithRules#src_address_groups}
    */
    readonly srcAddressGroups?: string[];
    /**
    * Fully Qualified Domain Name (FQDN) which should be matched against
    * traffic source. Maximum number of source fqdn allowed is 100.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#src_fqdns ComputeNetworkFirewallPolicyWithRules#src_fqdns}
    */
    readonly srcFqdns?: string[];
    /**
    * Source IP address range in CIDR format. Required for
    * INGRESS rules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#src_ip_ranges ComputeNetworkFirewallPolicyWithRules#src_ip_ranges}
    */
    readonly srcIpRanges?: string[];
    /**
    * Region codes whose IP addresses will be used to match for source
    * of traffic. Should be specified as 2 letter country code defined as per
    * ISO 3166 alpha-2 country codes. ex."US"
    * Maximum number of source region codes allowed is 5000.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#src_region_codes ComputeNetworkFirewallPolicyWithRules#src_region_codes}
    */
    readonly srcRegionCodes?: string[];
    /**
    * Names of Network Threat Intelligence lists.
    * The IPs in these lists will be matched against traffic source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#src_threat_intelligences ComputeNetworkFirewallPolicyWithRules#src_threat_intelligences}
    */
    readonly srcThreatIntelligences?: string[];
    /**
    * layer4_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#layer4_config ComputeNetworkFirewallPolicyWithRules#layer4_config}
    */
    readonly layer4Config: ComputeNetworkFirewallPolicyWithRulesRuleMatchLayer4Config[] | cdktn.IResolvable;
    /**
    * src_secure_tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#src_secure_tag ComputeNetworkFirewallPolicyWithRules#src_secure_tag}
    */
    readonly srcSecureTag?: ComputeNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTag[] | cdktn.IResolvable;
}
export declare function computeNetworkFirewallPolicyWithRulesRuleMatchToTerraform(struct?: ComputeNetworkFirewallPolicyWithRulesRuleMatchOutputReference | ComputeNetworkFirewallPolicyWithRulesRuleMatch): any;
export declare function computeNetworkFirewallPolicyWithRulesRuleMatchToHclTerraform(struct?: ComputeNetworkFirewallPolicyWithRulesRuleMatchOutputReference | ComputeNetworkFirewallPolicyWithRulesRuleMatch): any;
export declare class ComputeNetworkFirewallPolicyWithRulesRuleMatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeNetworkFirewallPolicyWithRulesRuleMatch | undefined;
    set internalValue(value: ComputeNetworkFirewallPolicyWithRulesRuleMatch | undefined);
    private _destAddressGroups?;
    get destAddressGroups(): string[];
    set destAddressGroups(value: string[]);
    resetDestAddressGroups(): void;
    get destAddressGroupsInput(): string[] | undefined;
    private _destFqdns?;
    get destFqdns(): string[];
    set destFqdns(value: string[]);
    resetDestFqdns(): void;
    get destFqdnsInput(): string[] | undefined;
    private _destIpRanges?;
    get destIpRanges(): string[];
    set destIpRanges(value: string[]);
    resetDestIpRanges(): void;
    get destIpRangesInput(): string[] | undefined;
    private _destRegionCodes?;
    get destRegionCodes(): string[];
    set destRegionCodes(value: string[]);
    resetDestRegionCodes(): void;
    get destRegionCodesInput(): string[] | undefined;
    private _destThreatIntelligences?;
    get destThreatIntelligences(): string[];
    set destThreatIntelligences(value: string[]);
    resetDestThreatIntelligences(): void;
    get destThreatIntelligencesInput(): string[] | undefined;
    private _srcAddressGroups?;
    get srcAddressGroups(): string[];
    set srcAddressGroups(value: string[]);
    resetSrcAddressGroups(): void;
    get srcAddressGroupsInput(): string[] | undefined;
    private _srcFqdns?;
    get srcFqdns(): string[];
    set srcFqdns(value: string[]);
    resetSrcFqdns(): void;
    get srcFqdnsInput(): string[] | undefined;
    private _srcIpRanges?;
    get srcIpRanges(): string[];
    set srcIpRanges(value: string[]);
    resetSrcIpRanges(): void;
    get srcIpRangesInput(): string[] | undefined;
    private _srcRegionCodes?;
    get srcRegionCodes(): string[];
    set srcRegionCodes(value: string[]);
    resetSrcRegionCodes(): void;
    get srcRegionCodesInput(): string[] | undefined;
    private _srcThreatIntelligences?;
    get srcThreatIntelligences(): string[];
    set srcThreatIntelligences(value: string[]);
    resetSrcThreatIntelligences(): void;
    get srcThreatIntelligencesInput(): string[] | undefined;
    private _layer4Config;
    get layer4Config(): ComputeNetworkFirewallPolicyWithRulesRuleMatchLayer4ConfigList;
    putLayer4Config(value: ComputeNetworkFirewallPolicyWithRulesRuleMatchLayer4Config[] | cdktn.IResolvable): void;
    get layer4ConfigInput(): cdktn.IResolvable | ComputeNetworkFirewallPolicyWithRulesRuleMatchLayer4Config[] | undefined;
    private _srcSecureTag;
    get srcSecureTag(): ComputeNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTagList;
    putSrcSecureTag(value: ComputeNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTag[] | cdktn.IResolvable): void;
    resetSrcSecureTag(): void;
    get srcSecureTagInput(): cdktn.IResolvable | ComputeNetworkFirewallPolicyWithRulesRuleMatchSrcSecureTag[] | undefined;
}
export interface ComputeNetworkFirewallPolicyWithRulesRuleTargetSecureTag {
    /**
    * Name of the secure tag, created with TagManager's TagValue API.
    * @pattern tagValues/[0-9]+
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#name ComputeNetworkFirewallPolicyWithRules#name}
    */
    readonly name?: string;
}
export declare function computeNetworkFirewallPolicyWithRulesRuleTargetSecureTagToTerraform(struct?: ComputeNetworkFirewallPolicyWithRulesRuleTargetSecureTag | cdktn.IResolvable): any;
export declare function computeNetworkFirewallPolicyWithRulesRuleTargetSecureTagToHclTerraform(struct?: ComputeNetworkFirewallPolicyWithRulesRuleTargetSecureTag | cdktn.IResolvable): any;
export declare class ComputeNetworkFirewallPolicyWithRulesRuleTargetSecureTagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeNetworkFirewallPolicyWithRulesRuleTargetSecureTag | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeNetworkFirewallPolicyWithRulesRuleTargetSecureTag | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get state(): string;
}
export declare class ComputeNetworkFirewallPolicyWithRulesRuleTargetSecureTagList extends cdktn.ComplexList {
    internalValue?: ComputeNetworkFirewallPolicyWithRulesRuleTargetSecureTag[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeNetworkFirewallPolicyWithRulesRuleTargetSecureTagOutputReference;
}
export interface ComputeNetworkFirewallPolicyWithRulesRule {
    /**
    * The Action to perform when the client connection triggers the rule. Can currently be either
    * "allow", "deny", "apply_security_profile_group" or "goto_next".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#action ComputeNetworkFirewallPolicyWithRules#action}
    */
    readonly action: string;
    /**
    * A description of the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#description ComputeNetworkFirewallPolicyWithRules#description}
    */
    readonly description?: string;
    /**
    * The direction in which this rule applies. If unspecified an INGRESS rule is created. Possible values: ["INGRESS", "EGRESS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#direction ComputeNetworkFirewallPolicyWithRules#direction}
    */
    readonly direction?: string;
    /**
    * Denotes whether the firewall policy rule is disabled. When set to true,
    * the firewall policy rule is not enforced and traffic behaves as if it did
    * not exist. If this is unspecified, the firewall policy rule will be
    * enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#disabled ComputeNetworkFirewallPolicyWithRules#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Denotes whether to enable logging for a particular rule.
    * If logging is enabled, logs will be exported to the
    * configured export destination in Stackdriver.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#enable_logging ComputeNetworkFirewallPolicyWithRules#enable_logging}
    */
    readonly enableLogging?: boolean | cdktn.IResolvable;
    /**
    * An integer indicating the priority of a rule in the list. The priority must be a value
    * between 0 and 2147483647. Rules are evaluated from highest to lowest priority where 0 is the
    * highest priority and 2147483647 is the lowest priority.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#priority ComputeNetworkFirewallPolicyWithRules#priority}
    */
    readonly priority: number;
    /**
    * An optional name for the rule. This field is not a unique identifier
    * and can be updated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#rule_name ComputeNetworkFirewallPolicyWithRules#rule_name}
    */
    readonly ruleName?: string;
    /**
    * A fully-qualified URL of a SecurityProfile resource instance.
    * Example:
    * https://networksecurity.googleapis.com/v1/projects/{project}/locations/{location}/securityProfileGroups/my-security-profile-group
    * Must be specified if action is 'apply_security_profile_group'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#security_profile_group ComputeNetworkFirewallPolicyWithRules#security_profile_group}
    */
    readonly securityProfileGroup?: string;
    /**
    * A list of service accounts indicating the sets of
    * instances that are applied with this rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#target_service_accounts ComputeNetworkFirewallPolicyWithRules#target_service_accounts}
    */
    readonly targetServiceAccounts?: string[];
    /**
    * Boolean flag indicating if the traffic should be TLS decrypted.
    * It can be set only if action = 'apply_security_profile_group' and cannot be set for other actions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#tls_inspect ComputeNetworkFirewallPolicyWithRules#tls_inspect}
    */
    readonly tlsInspect?: boolean | cdktn.IResolvable;
    /**
    * match block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#match ComputeNetworkFirewallPolicyWithRules#match}
    */
    readonly match: ComputeNetworkFirewallPolicyWithRulesRuleMatch;
    /**
    * target_secure_tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#target_secure_tag ComputeNetworkFirewallPolicyWithRules#target_secure_tag}
    */
    readonly targetSecureTag?: ComputeNetworkFirewallPolicyWithRulesRuleTargetSecureTag[] | cdktn.IResolvable;
}
export declare function computeNetworkFirewallPolicyWithRulesRuleToTerraform(struct?: ComputeNetworkFirewallPolicyWithRulesRule | cdktn.IResolvable): any;
export declare function computeNetworkFirewallPolicyWithRulesRuleToHclTerraform(struct?: ComputeNetworkFirewallPolicyWithRulesRule | cdktn.IResolvable): any;
export declare class ComputeNetworkFirewallPolicyWithRulesRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeNetworkFirewallPolicyWithRulesRule | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeNetworkFirewallPolicyWithRulesRule | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _enableLogging?;
    get enableLogging(): boolean | cdktn.IResolvable;
    set enableLogging(value: boolean | cdktn.IResolvable);
    resetEnableLogging(): void;
    get enableLoggingInput(): boolean | cdktn.IResolvable | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
    private _ruleName?;
    get ruleName(): string;
    set ruleName(value: string);
    resetRuleName(): void;
    get ruleNameInput(): string | undefined;
    private _securityProfileGroup?;
    get securityProfileGroup(): string;
    set securityProfileGroup(value: string);
    resetSecurityProfileGroup(): void;
    get securityProfileGroupInput(): string | undefined;
    private _targetServiceAccounts?;
    get targetServiceAccounts(): string[];
    set targetServiceAccounts(value: string[]);
    resetTargetServiceAccounts(): void;
    get targetServiceAccountsInput(): string[] | undefined;
    private _tlsInspect?;
    get tlsInspect(): boolean | cdktn.IResolvable;
    set tlsInspect(value: boolean | cdktn.IResolvable);
    resetTlsInspect(): void;
    get tlsInspectInput(): boolean | cdktn.IResolvable | undefined;
    private _match;
    get match(): ComputeNetworkFirewallPolicyWithRulesRuleMatchOutputReference;
    putMatch(value: ComputeNetworkFirewallPolicyWithRulesRuleMatch): void;
    get matchInput(): ComputeNetworkFirewallPolicyWithRulesRuleMatch | undefined;
    private _targetSecureTag;
    get targetSecureTag(): ComputeNetworkFirewallPolicyWithRulesRuleTargetSecureTagList;
    putTargetSecureTag(value: ComputeNetworkFirewallPolicyWithRulesRuleTargetSecureTag[] | cdktn.IResolvable): void;
    resetTargetSecureTag(): void;
    get targetSecureTagInput(): cdktn.IResolvable | ComputeNetworkFirewallPolicyWithRulesRuleTargetSecureTag[] | undefined;
}
export declare class ComputeNetworkFirewallPolicyWithRulesRuleList extends cdktn.ComplexList {
    internalValue?: ComputeNetworkFirewallPolicyWithRulesRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeNetworkFirewallPolicyWithRulesRuleOutputReference;
}
export interface ComputeNetworkFirewallPolicyWithRulesTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#create ComputeNetworkFirewallPolicyWithRules#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#delete ComputeNetworkFirewallPolicyWithRules#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#update ComputeNetworkFirewallPolicyWithRules#update}
    */
    readonly update?: string;
}
export declare function computeNetworkFirewallPolicyWithRulesTimeoutsToTerraform(struct?: ComputeNetworkFirewallPolicyWithRulesTimeouts | cdktn.IResolvable): any;
export declare function computeNetworkFirewallPolicyWithRulesTimeoutsToHclTerraform(struct?: ComputeNetworkFirewallPolicyWithRulesTimeouts | cdktn.IResolvable): any;
export declare class ComputeNetworkFirewallPolicyWithRulesTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeNetworkFirewallPolicyWithRulesTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeNetworkFirewallPolicyWithRulesTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules google_compute_network_firewall_policy_with_rules}
*/
export declare class ComputeNetworkFirewallPolicyWithRules extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_network_firewall_policy_with_rules";
    /**
    * Generates CDKTN code for importing a ComputeNetworkFirewallPolicyWithRules resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeNetworkFirewallPolicyWithRules to import
    * @param importFromId The id of the existing ComputeNetworkFirewallPolicyWithRules that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeNetworkFirewallPolicyWithRules to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_firewall_policy_with_rules google_compute_network_firewall_policy_with_rules} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeNetworkFirewallPolicyWithRulesConfig
    */
    constructor(scope: Construct, id: string, config: ComputeNetworkFirewallPolicyWithRulesConfig);
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get fingerprint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get networkFirewallPolicyId(): string;
    private _policyType?;
    get policyType(): string;
    set policyType(value: string);
    resetPolicyType(): void;
    get policyTypeInput(): string | undefined;
    private _predefinedRules;
    get predefinedRules(): ComputeNetworkFirewallPolicyWithRulesPredefinedRulesList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get ruleTupleCount(): number;
    get selfLink(): string;
    get selfLinkWithId(): string;
    private _rule;
    get rule(): ComputeNetworkFirewallPolicyWithRulesRuleList;
    putRule(value: ComputeNetworkFirewallPolicyWithRulesRule[] | cdktn.IResolvable): void;
    get ruleInput(): cdktn.IResolvable | ComputeNetworkFirewallPolicyWithRulesRule[] | undefined;
    private _timeouts;
    get timeouts(): ComputeNetworkFirewallPolicyWithRulesTimeoutsOutputReference;
    putTimeouts(value: ComputeNetworkFirewallPolicyWithRulesTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeNetworkFirewallPolicyWithRulesTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
