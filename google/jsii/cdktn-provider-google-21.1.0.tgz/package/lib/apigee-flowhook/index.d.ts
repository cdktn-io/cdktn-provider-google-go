/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigeeFlowhookConfig extends cdktn.TerraformMetaArguments {
    /**
    * Flag that specifies whether execution should continue if the flow hook throws an exception. Set to true to continue execution. Set to false to stop execution if the flow hook throws an exception. Defaults to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_flowhook#continue_on_error ApigeeFlowhook#continue_on_error}
    */
    readonly continueOnError?: boolean | cdktn.IResolvable;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_flowhook#deletion_policy ApigeeFlowhook#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Description of the flow hook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_flowhook#description ApigeeFlowhook#description}
    */
    readonly description?: string;
    /**
    * The resource ID of the environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_flowhook#environment ApigeeFlowhook#environment}
    */
    readonly environment: string;
    /**
    * Where in the API call flow the flow hook is invoked. Must be one of PreProxyFlowHook, PostProxyFlowHook, PreTargetFlowHook, or PostTargetFlowHook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_flowhook#flow_hook_point ApigeeFlowhook#flow_hook_point}
    */
    readonly flowHookPoint: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_flowhook#id ApigeeFlowhook#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The Apigee Organization associated with the environment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_flowhook#org_id ApigeeFlowhook#org_id}
    */
    readonly orgId: string;
    /**
    * Id of the Sharedflow attaching to a flowhook point.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_flowhook#sharedflow ApigeeFlowhook#sharedflow}
    */
    readonly sharedflow: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_flowhook#timeouts ApigeeFlowhook#timeouts}
    */
    readonly timeouts?: ApigeeFlowhookTimeouts;
}
export interface ApigeeFlowhookTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_flowhook#create ApigeeFlowhook#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_flowhook#delete ApigeeFlowhook#delete}
    */
    readonly delete?: string;
}
export declare function apigeeFlowhookTimeoutsToTerraform(struct?: ApigeeFlowhookTimeouts | cdktn.IResolvable): any;
export declare function apigeeFlowhookTimeoutsToHclTerraform(struct?: ApigeeFlowhookTimeouts | cdktn.IResolvable): any;
export declare class ApigeeFlowhookTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeFlowhookTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeFlowhookTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_flowhook google_apigee_flowhook}
*/
export declare class ApigeeFlowhook extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apigee_flowhook";
    /**
    * Generates CDKTN code for importing a ApigeeFlowhook resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigeeFlowhook to import
    * @param importFromId The id of the existing ApigeeFlowhook that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_flowhook#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigeeFlowhook to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_flowhook google_apigee_flowhook} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigeeFlowhookConfig
    */
    constructor(scope: Construct, id: string, config: ApigeeFlowhookConfig);
    private _continueOnError?;
    get continueOnError(): boolean | cdktn.IResolvable;
    set continueOnError(value: boolean | cdktn.IResolvable);
    resetContinueOnError(): void;
    get continueOnErrorInput(): boolean | cdktn.IResolvable | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _environment?;
    get environment(): string;
    set environment(value: string);
    get environmentInput(): string | undefined;
    private _flowHookPoint?;
    get flowHookPoint(): string;
    set flowHookPoint(value: string);
    get flowHookPointInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _orgId?;
    get orgId(): string;
    set orgId(value: string);
    get orgIdInput(): string | undefined;
    private _sharedflow?;
    get sharedflow(): string;
    set sharedflow(value: string);
    get sharedflowInput(): string | undefined;
    private _timeouts;
    get timeouts(): ApigeeFlowhookTimeoutsOutputReference;
    putTimeouts(value: ApigeeFlowhookTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApigeeFlowhookTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
