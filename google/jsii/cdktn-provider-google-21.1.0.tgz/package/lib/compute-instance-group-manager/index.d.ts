/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeInstanceGroupManagerConfig extends cdktn.TerraformMetaArguments {
    /**
    * The base instance name to use for instances in this group. The value must be a valid RFC1035 name. Supported characters are lowercase letters, numbers, and hyphens (-). Instances are named by appending a hyphen and a random four-character string to the base instance name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#base_instance_name ComputeInstanceGroupManager#base_instance_name}
    */
    readonly baseInstanceName: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#deletion_policy ComputeInstanceGroupManager#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional textual description of the instance group manager.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#description ComputeInstanceGroupManager#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#id ComputeInstanceGroupManager#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Pagination behavior of the listManagedInstances API method for this managed instance group. Valid values are: "PAGELESS", "PAGINATED". If PAGELESS (default), Pagination is disabled for the group's listManagedInstances API method. maxResults and pageToken query parameters are ignored and all instances are returned in a single response. If PAGINATED, pagination is enabled, maxResults and pageToken query parameters are respected.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#list_managed_instances_results ComputeInstanceGroupManager#list_managed_instances_results}
    */
    readonly listManagedInstancesResults?: string;
    /**
    * The name of the instance group manager. Must be 1-63 characters long and comply with RFC1035. Supported characters include lowercase letters, numbers, and hyphens.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#name ComputeInstanceGroupManager#name}
    */
    readonly name: string;
    /**
    * The ID of the project in which the resource belongs. If it is not provided, the provider project is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#project ComputeInstanceGroupManager#project}
    */
    readonly project?: string;
    /**
    * The full URL of all target pools to which new instances in the group are added. Updating the target pools attribute does not affect existing instances.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#target_pools ComputeInstanceGroupManager#target_pools}
    */
    readonly targetPools?: string[];
    /**
    * The target number of running instances for this managed instance group. This value should always be explicitly set unless this resource is attached to an autoscaler, in which case it should never be set. Defaults to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#target_size ComputeInstanceGroupManager#target_size}
    */
    readonly targetSize?: number;
    /**
    * The target number of stopped instances for this managed instance group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#target_stopped_size ComputeInstanceGroupManager#target_stopped_size}
    */
    readonly targetStoppedSize?: number;
    /**
    * The target number of suspended instances for this managed instance group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#target_suspended_size ComputeInstanceGroupManager#target_suspended_size}
    */
    readonly targetSuspendedSize?: number;
    /**
    * Whether to wait for all instances to be created/updated before returning. Note that if this is set to true and the operation does not succeed, Terraform will continue trying until it times out.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#wait_for_instances ComputeInstanceGroupManager#wait_for_instances}
    */
    readonly waitForInstances?: boolean | cdktn.IResolvable;
    /**
    * When used with wait_for_instances specifies the status to wait for. When STABLE is specified this resource will wait until the instances are stable before returning. When UPDATED is set, it will wait for the version target to be reached and any per instance configs to be effective and all instances configs to be effective as well as all instances to be stable before returning.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#wait_for_instances_status ComputeInstanceGroupManager#wait_for_instances_status}
    */
    readonly waitForInstancesStatus?: string;
    /**
    * The zone that instances in this group should be created in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#zone ComputeInstanceGroupManager#zone}
    */
    readonly zone?: string;
    /**
    * all_instances_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#all_instances_config ComputeInstanceGroupManager#all_instances_config}
    */
    readonly allInstancesConfig?: ComputeInstanceGroupManagerAllInstancesConfig;
    /**
    * auto_healing_policies block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#auto_healing_policies ComputeInstanceGroupManager#auto_healing_policies}
    */
    readonly autoHealingPolicies?: ComputeInstanceGroupManagerAutoHealingPolicies;
    /**
    * instance_lifecycle_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#instance_lifecycle_policy ComputeInstanceGroupManager#instance_lifecycle_policy}
    */
    readonly instanceLifecyclePolicy?: ComputeInstanceGroupManagerInstanceLifecyclePolicy;
    /**
    * named_port block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#named_port ComputeInstanceGroupManager#named_port}
    */
    readonly namedPort?: ComputeInstanceGroupManagerNamedPort[] | cdktn.IResolvable;
    /**
    * resource_policies block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#resource_policies ComputeInstanceGroupManager#resource_policies}
    */
    readonly resourcePolicies?: ComputeInstanceGroupManagerResourcePolicies;
    /**
    * standby_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#standby_policy ComputeInstanceGroupManager#standby_policy}
    */
    readonly standbyPolicy?: ComputeInstanceGroupManagerStandbyPolicy;
    /**
    * stateful_disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#stateful_disk ComputeInstanceGroupManager#stateful_disk}
    */
    readonly statefulDisk?: ComputeInstanceGroupManagerStatefulDisk[] | cdktn.IResolvable;
    /**
    * stateful_external_ip block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#stateful_external_ip ComputeInstanceGroupManager#stateful_external_ip}
    */
    readonly statefulExternalIp?: ComputeInstanceGroupManagerStatefulExternalIp[] | cdktn.IResolvable;
    /**
    * stateful_internal_ip block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#stateful_internal_ip ComputeInstanceGroupManager#stateful_internal_ip}
    */
    readonly statefulInternalIp?: ComputeInstanceGroupManagerStatefulInternalIp[] | cdktn.IResolvable;
    /**
    * target_size_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#target_size_policy ComputeInstanceGroupManager#target_size_policy}
    */
    readonly targetSizePolicy?: ComputeInstanceGroupManagerTargetSizePolicy[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#timeouts ComputeInstanceGroupManager#timeouts}
    */
    readonly timeouts?: ComputeInstanceGroupManagerTimeouts;
    /**
    * update_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#update_policy ComputeInstanceGroupManager#update_policy}
    */
    readonly updatePolicy?: ComputeInstanceGroupManagerUpdatePolicy;
    /**
    * version block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#version ComputeInstanceGroupManager#version}
    */
    readonly version: ComputeInstanceGroupManagerVersion[] | cdktn.IResolvable;
}
export interface ComputeInstanceGroupManagerStatusAllInstancesConfig {
}
export declare function computeInstanceGroupManagerStatusAllInstancesConfigToTerraform(struct?: ComputeInstanceGroupManagerStatusAllInstancesConfig): any;
export declare function computeInstanceGroupManagerStatusAllInstancesConfigToHclTerraform(struct?: ComputeInstanceGroupManagerStatusAllInstancesConfig): any;
export declare class ComputeInstanceGroupManagerStatusAllInstancesConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceGroupManagerStatusAllInstancesConfig | undefined;
    set internalValue(value: ComputeInstanceGroupManagerStatusAllInstancesConfig | undefined);
    get currentRevision(): string;
    get effective(): cdktn.IResolvable;
}
export declare class ComputeInstanceGroupManagerStatusAllInstancesConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceGroupManagerStatusAllInstancesConfigOutputReference;
}
export interface ComputeInstanceGroupManagerStatusStatefulPerInstanceConfigs {
}
export declare function computeInstanceGroupManagerStatusStatefulPerInstanceConfigsToTerraform(struct?: ComputeInstanceGroupManagerStatusStatefulPerInstanceConfigs): any;
export declare function computeInstanceGroupManagerStatusStatefulPerInstanceConfigsToHclTerraform(struct?: ComputeInstanceGroupManagerStatusStatefulPerInstanceConfigs): any;
export declare class ComputeInstanceGroupManagerStatusStatefulPerInstanceConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceGroupManagerStatusStatefulPerInstanceConfigs | undefined;
    set internalValue(value: ComputeInstanceGroupManagerStatusStatefulPerInstanceConfigs | undefined);
    get allEffective(): cdktn.IResolvable;
}
export declare class ComputeInstanceGroupManagerStatusStatefulPerInstanceConfigsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceGroupManagerStatusStatefulPerInstanceConfigsOutputReference;
}
export interface ComputeInstanceGroupManagerStatusStateful {
}
export declare function computeInstanceGroupManagerStatusStatefulToTerraform(struct?: ComputeInstanceGroupManagerStatusStateful): any;
export declare function computeInstanceGroupManagerStatusStatefulToHclTerraform(struct?: ComputeInstanceGroupManagerStatusStateful): any;
export declare class ComputeInstanceGroupManagerStatusStatefulOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceGroupManagerStatusStateful | undefined;
    set internalValue(value: ComputeInstanceGroupManagerStatusStateful | undefined);
    get hasStatefulConfig(): cdktn.IResolvable;
    private _perInstanceConfigs;
    get perInstanceConfigs(): ComputeInstanceGroupManagerStatusStatefulPerInstanceConfigsList;
}
export declare class ComputeInstanceGroupManagerStatusStatefulList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceGroupManagerStatusStatefulOutputReference;
}
export interface ComputeInstanceGroupManagerStatusVersionTarget {
}
export declare function computeInstanceGroupManagerStatusVersionTargetToTerraform(struct?: ComputeInstanceGroupManagerStatusVersionTarget): any;
export declare function computeInstanceGroupManagerStatusVersionTargetToHclTerraform(struct?: ComputeInstanceGroupManagerStatusVersionTarget): any;
export declare class ComputeInstanceGroupManagerStatusVersionTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceGroupManagerStatusVersionTarget | undefined;
    set internalValue(value: ComputeInstanceGroupManagerStatusVersionTarget | undefined);
    get isReached(): cdktn.IResolvable;
}
export declare class ComputeInstanceGroupManagerStatusVersionTargetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceGroupManagerStatusVersionTargetOutputReference;
}
export interface ComputeInstanceGroupManagerStatus {
}
export declare function computeInstanceGroupManagerStatusToTerraform(struct?: ComputeInstanceGroupManagerStatus): any;
export declare function computeInstanceGroupManagerStatusToHclTerraform(struct?: ComputeInstanceGroupManagerStatus): any;
export declare class ComputeInstanceGroupManagerStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceGroupManagerStatus | undefined;
    set internalValue(value: ComputeInstanceGroupManagerStatus | undefined);
    private _allInstancesConfig;
    get allInstancesConfig(): ComputeInstanceGroupManagerStatusAllInstancesConfigList;
    get isStable(): cdktn.IResolvable;
    private _stateful;
    get stateful(): ComputeInstanceGroupManagerStatusStatefulList;
    private _versionTarget;
    get versionTarget(): ComputeInstanceGroupManagerStatusVersionTargetList;
}
export declare class ComputeInstanceGroupManagerStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceGroupManagerStatusOutputReference;
}
export interface ComputeInstanceGroupManagerAllInstancesConfig {
    /**
    * The label key-value pairs that you want to patch onto the instance,
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#labels ComputeInstanceGroupManager#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The metadata key-value pairs that you want to patch onto the instance. For more information, see Project and instance metadata,
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#metadata ComputeInstanceGroupManager#metadata}
    */
    readonly metadata?: {
        [key: string]: string;
    };
}
export declare function computeInstanceGroupManagerAllInstancesConfigToTerraform(struct?: ComputeInstanceGroupManagerAllInstancesConfigOutputReference | ComputeInstanceGroupManagerAllInstancesConfig): any;
export declare function computeInstanceGroupManagerAllInstancesConfigToHclTerraform(struct?: ComputeInstanceGroupManagerAllInstancesConfigOutputReference | ComputeInstanceGroupManagerAllInstancesConfig): any;
export declare class ComputeInstanceGroupManagerAllInstancesConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceGroupManagerAllInstancesConfig | undefined;
    set internalValue(value: ComputeInstanceGroupManagerAllInstancesConfig | undefined);
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _metadata?;
    get metadata(): {
        [key: string]: string;
    };
    set metadata(value: {
        [key: string]: string;
    });
    resetMetadata(): void;
    get metadataInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ComputeInstanceGroupManagerAutoHealingPolicies {
    /**
    * The health check resource that signals autohealing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#health_check ComputeInstanceGroupManager#health_check}
    */
    readonly healthCheck: string;
    /**
    * The number of seconds that the managed instance group waits before it applies autohealing policies to new instances or recently recreated instances. Between 0 and 3600.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#initial_delay_sec ComputeInstanceGroupManager#initial_delay_sec}
    */
    readonly initialDelaySec: number;
}
export declare function computeInstanceGroupManagerAutoHealingPoliciesToTerraform(struct?: ComputeInstanceGroupManagerAutoHealingPoliciesOutputReference | ComputeInstanceGroupManagerAutoHealingPolicies): any;
export declare function computeInstanceGroupManagerAutoHealingPoliciesToHclTerraform(struct?: ComputeInstanceGroupManagerAutoHealingPoliciesOutputReference | ComputeInstanceGroupManagerAutoHealingPolicies): any;
export declare class ComputeInstanceGroupManagerAutoHealingPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceGroupManagerAutoHealingPolicies | undefined;
    set internalValue(value: ComputeInstanceGroupManagerAutoHealingPolicies | undefined);
    private _healthCheck?;
    get healthCheck(): string;
    set healthCheck(value: string);
    get healthCheckInput(): string | undefined;
    private _initialDelaySec?;
    get initialDelaySec(): number;
    set initialDelaySec(value: number);
    get initialDelaySecInput(): number | undefined;
}
export interface ComputeInstanceGroupManagerInstanceLifecyclePolicyOnRepair {
    /**
    * Specifies whether the MIG can change a VM's zone during a repair. If "YES", MIG can select a different zone for the VM during a repair. Else if "NO", MIG cannot change a VM's zone during a repair. The default value of allow_changing_zone is "NO".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#allow_changing_zone ComputeInstanceGroupManager#allow_changing_zone}
    */
    readonly allowChangingZone?: string;
}
export declare function computeInstanceGroupManagerInstanceLifecyclePolicyOnRepairToTerraform(struct?: ComputeInstanceGroupManagerInstanceLifecyclePolicyOnRepairOutputReference | ComputeInstanceGroupManagerInstanceLifecyclePolicyOnRepair): any;
export declare function computeInstanceGroupManagerInstanceLifecyclePolicyOnRepairToHclTerraform(struct?: ComputeInstanceGroupManagerInstanceLifecyclePolicyOnRepairOutputReference | ComputeInstanceGroupManagerInstanceLifecyclePolicyOnRepair): any;
export declare class ComputeInstanceGroupManagerInstanceLifecyclePolicyOnRepairOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceGroupManagerInstanceLifecyclePolicyOnRepair | undefined;
    set internalValue(value: ComputeInstanceGroupManagerInstanceLifecyclePolicyOnRepair | undefined);
    private _allowChangingZone?;
    get allowChangingZone(): string;
    set allowChangingZone(value: string);
    resetAllowChangingZone(): void;
    get allowChangingZoneInput(): string | undefined;
}
export interface ComputeInstanceGroupManagerInstanceLifecyclePolicy {
    /**
    * Specifies the action that a MIG performs on a failed VM. If the value of the "on_failed_health_check" field is DEFAULT_ACTION, then the same action also applies to the VMs on which your application fails a health check. Valid values are: REPAIR, DO_NOTHING. If REPAIR (default), then MIG automatically repairs a failed VM by recreating it. For more information, see about repairing VMs in a MIG. If DO_NOTHING, then MIG does not repair a failed VM.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#default_action_on_failure ComputeInstanceGroupManager#default_action_on_failure}
    */
    readonly defaultActionOnFailure?: string;
    /**
    * Specifies whether to apply the group's latest configuration when repairing a VM. Valid options are: YES, NO. If YES and you updated the group's instance template or per-instance configurations after the VM was created, then these changes are applied when VM is repaired. If NO (default), then updates are applied in accordance with the group's update policy type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#force_update_on_repair ComputeInstanceGroupManager#force_update_on_repair}
    */
    readonly forceUpdateOnRepair?: string;
    /**
    * Specifies the action that a MIG performs on an unhealthy VM. A VM is marked as unhealthy when the application running on that VM fails a health check. Valid values are: DEFAULT_ACTION, DO_NOTHING, REPAIR. If DEFAULT_ACTION (default), then MIG uses the same action configured for the  "default_action_on_failure" field. If DO_NOTHING, then MIG does not repair unhealthy VM. If REPAIR, then MIG automatically repairs an unhealthy VM by recreating it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#on_failed_health_check ComputeInstanceGroupManager#on_failed_health_check}
    */
    readonly onFailedHealthCheck?: string;
    /**
    * on_repair block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#on_repair ComputeInstanceGroupManager#on_repair}
    */
    readonly onRepair?: ComputeInstanceGroupManagerInstanceLifecyclePolicyOnRepair;
}
export declare function computeInstanceGroupManagerInstanceLifecyclePolicyToTerraform(struct?: ComputeInstanceGroupManagerInstanceLifecyclePolicyOutputReference | ComputeInstanceGroupManagerInstanceLifecyclePolicy): any;
export declare function computeInstanceGroupManagerInstanceLifecyclePolicyToHclTerraform(struct?: ComputeInstanceGroupManagerInstanceLifecyclePolicyOutputReference | ComputeInstanceGroupManagerInstanceLifecyclePolicy): any;
export declare class ComputeInstanceGroupManagerInstanceLifecyclePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceGroupManagerInstanceLifecyclePolicy | undefined;
    set internalValue(value: ComputeInstanceGroupManagerInstanceLifecyclePolicy | undefined);
    private _defaultActionOnFailure?;
    get defaultActionOnFailure(): string;
    set defaultActionOnFailure(value: string);
    resetDefaultActionOnFailure(): void;
    get defaultActionOnFailureInput(): string | undefined;
    private _forceUpdateOnRepair?;
    get forceUpdateOnRepair(): string;
    set forceUpdateOnRepair(value: string);
    resetForceUpdateOnRepair(): void;
    get forceUpdateOnRepairInput(): string | undefined;
    private _onFailedHealthCheck?;
    get onFailedHealthCheck(): string;
    set onFailedHealthCheck(value: string);
    resetOnFailedHealthCheck(): void;
    get onFailedHealthCheckInput(): string | undefined;
    private _onRepair;
    get onRepair(): ComputeInstanceGroupManagerInstanceLifecyclePolicyOnRepairOutputReference;
    putOnRepair(value: ComputeInstanceGroupManagerInstanceLifecyclePolicyOnRepair): void;
    resetOnRepair(): void;
    get onRepairInput(): ComputeInstanceGroupManagerInstanceLifecyclePolicyOnRepair | undefined;
}
export interface ComputeInstanceGroupManagerNamedPort {
    /**
    * The name of the port.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#name ComputeInstanceGroupManager#name}
    */
    readonly name: string;
    /**
    * The port number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#port ComputeInstanceGroupManager#port}
    */
    readonly port: number;
}
export declare function computeInstanceGroupManagerNamedPortToTerraform(struct?: ComputeInstanceGroupManagerNamedPort | cdktn.IResolvable): any;
export declare function computeInstanceGroupManagerNamedPortToHclTerraform(struct?: ComputeInstanceGroupManagerNamedPort | cdktn.IResolvable): any;
export declare class ComputeInstanceGroupManagerNamedPortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceGroupManagerNamedPort | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInstanceGroupManagerNamedPort | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
}
export declare class ComputeInstanceGroupManagerNamedPortList extends cdktn.ComplexList {
    internalValue?: ComputeInstanceGroupManagerNamedPort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceGroupManagerNamedPortOutputReference;
}
export interface ComputeInstanceGroupManagerResourcePolicies {
    /**
    * The URL of the workload policy that is specified for this managed instance group. It can be a full or partial URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#workload_policy ComputeInstanceGroupManager#workload_policy}
    */
    readonly workloadPolicy?: string;
}
export declare function computeInstanceGroupManagerResourcePoliciesToTerraform(struct?: ComputeInstanceGroupManagerResourcePoliciesOutputReference | ComputeInstanceGroupManagerResourcePolicies): any;
export declare function computeInstanceGroupManagerResourcePoliciesToHclTerraform(struct?: ComputeInstanceGroupManagerResourcePoliciesOutputReference | ComputeInstanceGroupManagerResourcePolicies): any;
export declare class ComputeInstanceGroupManagerResourcePoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceGroupManagerResourcePolicies | undefined;
    set internalValue(value: ComputeInstanceGroupManagerResourcePolicies | undefined);
    private _workloadPolicy?;
    get workloadPolicy(): string;
    set workloadPolicy(value: string);
    resetWorkloadPolicy(): void;
    get workloadPolicyInput(): string | undefined;
}
export interface ComputeInstanceGroupManagerStandbyPolicy {
    /**
    * Specifies the number of seconds that the MIG should wait to suspend or stop a VM after that VM was created. The initial delay gives the initialization script the time to prepare your VM for a quick scale out. The value of initial delay must be between 0 and 3600 seconds. The default value is 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#initial_delay_sec ComputeInstanceGroupManager#initial_delay_sec}
    */
    readonly initialDelaySec?: number;
    /**
    * Defines how a MIG resumes or starts VMs from a standby pool when the group scales out. The default mode is "MANUAL".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#mode ComputeInstanceGroupManager#mode}
    */
    readonly mode?: string;
}
export declare function computeInstanceGroupManagerStandbyPolicyToTerraform(struct?: ComputeInstanceGroupManagerStandbyPolicyOutputReference | ComputeInstanceGroupManagerStandbyPolicy): any;
export declare function computeInstanceGroupManagerStandbyPolicyToHclTerraform(struct?: ComputeInstanceGroupManagerStandbyPolicyOutputReference | ComputeInstanceGroupManagerStandbyPolicy): any;
export declare class ComputeInstanceGroupManagerStandbyPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceGroupManagerStandbyPolicy | undefined;
    set internalValue(value: ComputeInstanceGroupManagerStandbyPolicy | undefined);
    private _initialDelaySec?;
    get initialDelaySec(): number;
    set initialDelaySec(value: number);
    resetInitialDelaySec(): void;
    get initialDelaySecInput(): number | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
}
export interface ComputeInstanceGroupManagerStatefulDisk {
    /**
    * A value that prescribes what should happen to the stateful disk when the VM instance is deleted. The available options are NEVER and ON_PERMANENT_INSTANCE_DELETION. NEVER - detach the disk when the VM is deleted, but do not delete the disk. ON_PERMANENT_INSTANCE_DELETION will delete the stateful disk when the VM is permanently deleted from the instance group. The default is NEVER.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#delete_rule ComputeInstanceGroupManager#delete_rule}
    */
    readonly deleteRule?: string;
    /**
    * The device name of the disk to be attached.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#device_name ComputeInstanceGroupManager#device_name}
    */
    readonly deviceName: string;
}
export declare function computeInstanceGroupManagerStatefulDiskToTerraform(struct?: ComputeInstanceGroupManagerStatefulDisk | cdktn.IResolvable): any;
export declare function computeInstanceGroupManagerStatefulDiskToHclTerraform(struct?: ComputeInstanceGroupManagerStatefulDisk | cdktn.IResolvable): any;
export declare class ComputeInstanceGroupManagerStatefulDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceGroupManagerStatefulDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInstanceGroupManagerStatefulDisk | cdktn.IResolvable | undefined);
    private _deleteRule?;
    get deleteRule(): string;
    set deleteRule(value: string);
    resetDeleteRule(): void;
    get deleteRuleInput(): string | undefined;
    private _deviceName?;
    get deviceName(): string;
    set deviceName(value: string);
    get deviceNameInput(): string | undefined;
}
export declare class ComputeInstanceGroupManagerStatefulDiskList extends cdktn.ComplexList {
    internalValue?: ComputeInstanceGroupManagerStatefulDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceGroupManagerStatefulDiskOutputReference;
}
export interface ComputeInstanceGroupManagerStatefulExternalIp {
    /**
    * A value that prescribes what should happen to an associated static Address resource when a VM instance is permanently deleted. The available options are NEVER and ON_PERMANENT_INSTANCE_DELETION. NEVER - detach the IP when the VM is deleted, but do not delete the address resource. ON_PERMANENT_INSTANCE_DELETION will delete the stateful address when the VM is permanently deleted from the instance group. The default is NEVER.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#delete_rule ComputeInstanceGroupManager#delete_rule}
    */
    readonly deleteRule?: string;
    /**
    * The network interface name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#interface_name ComputeInstanceGroupManager#interface_name}
    */
    readonly interfaceName?: string;
}
export declare function computeInstanceGroupManagerStatefulExternalIpToTerraform(struct?: ComputeInstanceGroupManagerStatefulExternalIp | cdktn.IResolvable): any;
export declare function computeInstanceGroupManagerStatefulExternalIpToHclTerraform(struct?: ComputeInstanceGroupManagerStatefulExternalIp | cdktn.IResolvable): any;
export declare class ComputeInstanceGroupManagerStatefulExternalIpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceGroupManagerStatefulExternalIp | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInstanceGroupManagerStatefulExternalIp | cdktn.IResolvable | undefined);
    private _deleteRule?;
    get deleteRule(): string;
    set deleteRule(value: string);
    resetDeleteRule(): void;
    get deleteRuleInput(): string | undefined;
    private _interfaceName?;
    get interfaceName(): string;
    set interfaceName(value: string);
    resetInterfaceName(): void;
    get interfaceNameInput(): string | undefined;
}
export declare class ComputeInstanceGroupManagerStatefulExternalIpList extends cdktn.ComplexList {
    internalValue?: ComputeInstanceGroupManagerStatefulExternalIp[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceGroupManagerStatefulExternalIpOutputReference;
}
export interface ComputeInstanceGroupManagerStatefulInternalIp {
    /**
    * A value that prescribes what should happen to an associated static Address resource when a VM instance is permanently deleted. The available options are NEVER and ON_PERMANENT_INSTANCE_DELETION. NEVER - detach the IP when the VM is deleted, but do not delete the address resource. ON_PERMANENT_INSTANCE_DELETION will delete the stateful address when the VM is permanently deleted from the instance group. The default is NEVER.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#delete_rule ComputeInstanceGroupManager#delete_rule}
    */
    readonly deleteRule?: string;
    /**
    * The network interface name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#interface_name ComputeInstanceGroupManager#interface_name}
    */
    readonly interfaceName?: string;
}
export declare function computeInstanceGroupManagerStatefulInternalIpToTerraform(struct?: ComputeInstanceGroupManagerStatefulInternalIp | cdktn.IResolvable): any;
export declare function computeInstanceGroupManagerStatefulInternalIpToHclTerraform(struct?: ComputeInstanceGroupManagerStatefulInternalIp | cdktn.IResolvable): any;
export declare class ComputeInstanceGroupManagerStatefulInternalIpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceGroupManagerStatefulInternalIp | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInstanceGroupManagerStatefulInternalIp | cdktn.IResolvable | undefined);
    private _deleteRule?;
    get deleteRule(): string;
    set deleteRule(value: string);
    resetDeleteRule(): void;
    get deleteRuleInput(): string | undefined;
    private _interfaceName?;
    get interfaceName(): string;
    set interfaceName(value: string);
    resetInterfaceName(): void;
    get interfaceNameInput(): string | undefined;
}
export declare class ComputeInstanceGroupManagerStatefulInternalIpList extends cdktn.ComplexList {
    internalValue?: ComputeInstanceGroupManagerStatefulInternalIp[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceGroupManagerStatefulInternalIpOutputReference;
}
export interface ComputeInstanceGroupManagerTargetSizePolicy {
    /**
    * The mode of target size policy based on which the MIG creates its VMs individually or all at once.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#mode ComputeInstanceGroupManager#mode}
    */
    readonly mode: string;
}
export declare function computeInstanceGroupManagerTargetSizePolicyToTerraform(struct?: ComputeInstanceGroupManagerTargetSizePolicy | cdktn.IResolvable): any;
export declare function computeInstanceGroupManagerTargetSizePolicyToHclTerraform(struct?: ComputeInstanceGroupManagerTargetSizePolicy | cdktn.IResolvable): any;
export declare class ComputeInstanceGroupManagerTargetSizePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceGroupManagerTargetSizePolicy | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInstanceGroupManagerTargetSizePolicy | cdktn.IResolvable | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
}
export declare class ComputeInstanceGroupManagerTargetSizePolicyList extends cdktn.ComplexList {
    internalValue?: ComputeInstanceGroupManagerTargetSizePolicy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceGroupManagerTargetSizePolicyOutputReference;
}
export interface ComputeInstanceGroupManagerTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#create ComputeInstanceGroupManager#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#delete ComputeInstanceGroupManager#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#update ComputeInstanceGroupManager#update}
    */
    readonly update?: string;
}
export declare function computeInstanceGroupManagerTimeoutsToTerraform(struct?: ComputeInstanceGroupManagerTimeouts | cdktn.IResolvable): any;
export declare function computeInstanceGroupManagerTimeoutsToHclTerraform(struct?: ComputeInstanceGroupManagerTimeouts | cdktn.IResolvable): any;
export declare class ComputeInstanceGroupManagerTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceGroupManagerTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInstanceGroupManagerTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface ComputeInstanceGroupManagerUpdatePolicy {
    /**
    * Specifies a fixed number of VM instances. This must be a positive integer. Conflicts with max_surge_percent. Both cannot be 0
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#max_surge_fixed ComputeInstanceGroupManager#max_surge_fixed}
    */
    readonly maxSurgeFixed?: number;
    /**
    * Specifies a percentage of instances between 0 to 100%, inclusive. For example, specify 80 for 80%. Conflicts with max_surge_fixed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#max_surge_percent ComputeInstanceGroupManager#max_surge_percent}
    */
    readonly maxSurgePercent?: number;
    /**
    * Specifies a fixed number of VM instances. This must be a positive integer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#max_unavailable_fixed ComputeInstanceGroupManager#max_unavailable_fixed}
    */
    readonly maxUnavailableFixed?: number;
    /**
    * Specifies a percentage of instances between 0 to 100%, inclusive. For example, specify 80 for 80%.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#max_unavailable_percent ComputeInstanceGroupManager#max_unavailable_percent}
    */
    readonly maxUnavailablePercent?: number;
    /**
    * Minimal action to be taken on an instance. You can specify either NONE to forbid any actions, REFRESH to update without stopping instances, RESTART to restart existing instances or REPLACE to delete and create new instances from the target template. If you specify a REFRESH, the Updater will attempt to perform that action only. However, if the Updater determines that the minimal action you specify is not enough to perform the update, it might perform a more disruptive action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#minimal_action ComputeInstanceGroupManager#minimal_action}
    */
    readonly minimalAction: string;
    /**
    * Most disruptive action that is allowed to be taken on an instance. You can specify either NONE to forbid any actions, REFRESH to allow actions that do not need instance restart, RESTART to allow actions that can be applied without instance replacing or REPLACE to allow all possible actions. If the Updater determines that the minimal update action needed is more disruptive than most disruptive allowed action you specify it will not perform the update at all.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#most_disruptive_allowed_action ComputeInstanceGroupManager#most_disruptive_allowed_action}
    */
    readonly mostDisruptiveAllowedAction?: string;
    /**
    * The instance replacement method for managed instance groups. Valid values are: "RECREATE", "SUBSTITUTE". If SUBSTITUTE (default), the group replaces VM instances with new instances that have randomly generated names. If RECREATE, instance names are preserved.  You must also set max_unavailable_fixed or max_unavailable_percent to be greater than 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#replacement_method ComputeInstanceGroupManager#replacement_method}
    */
    readonly replacementMethod?: string;
    /**
    * The type of update process. You can specify either PROACTIVE so that the instance group manager proactively executes actions in order to bring instances to their target versions or OPPORTUNISTIC so that no action is proactively executed but the update will be performed as part of other actions (for example, resizes or recreateInstances calls).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#type ComputeInstanceGroupManager#type}
    */
    readonly type: string;
}
export declare function computeInstanceGroupManagerUpdatePolicyToTerraform(struct?: ComputeInstanceGroupManagerUpdatePolicyOutputReference | ComputeInstanceGroupManagerUpdatePolicy): any;
export declare function computeInstanceGroupManagerUpdatePolicyToHclTerraform(struct?: ComputeInstanceGroupManagerUpdatePolicyOutputReference | ComputeInstanceGroupManagerUpdatePolicy): any;
export declare class ComputeInstanceGroupManagerUpdatePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceGroupManagerUpdatePolicy | undefined;
    set internalValue(value: ComputeInstanceGroupManagerUpdatePolicy | undefined);
    private _maxSurgeFixed?;
    get maxSurgeFixed(): number;
    set maxSurgeFixed(value: number);
    resetMaxSurgeFixed(): void;
    get maxSurgeFixedInput(): number | undefined;
    private _maxSurgePercent?;
    get maxSurgePercent(): number;
    set maxSurgePercent(value: number);
    resetMaxSurgePercent(): void;
    get maxSurgePercentInput(): number | undefined;
    private _maxUnavailableFixed?;
    get maxUnavailableFixed(): number;
    set maxUnavailableFixed(value: number);
    resetMaxUnavailableFixed(): void;
    get maxUnavailableFixedInput(): number | undefined;
    private _maxUnavailablePercent?;
    get maxUnavailablePercent(): number;
    set maxUnavailablePercent(value: number);
    resetMaxUnavailablePercent(): void;
    get maxUnavailablePercentInput(): number | undefined;
    private _minimalAction?;
    get minimalAction(): string;
    set minimalAction(value: string);
    get minimalActionInput(): string | undefined;
    private _mostDisruptiveAllowedAction?;
    get mostDisruptiveAllowedAction(): string;
    set mostDisruptiveAllowedAction(value: string);
    resetMostDisruptiveAllowedAction(): void;
    get mostDisruptiveAllowedActionInput(): string | undefined;
    private _replacementMethod?;
    get replacementMethod(): string;
    set replacementMethod(value: string);
    resetReplacementMethod(): void;
    get replacementMethodInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface ComputeInstanceGroupManagerVersionTargetSize {
    /**
    * The number of instances which are managed for this version. Conflicts with percent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#fixed ComputeInstanceGroupManager#fixed}
    */
    readonly fixed?: number;
    /**
    * The number of instances (calculated as percentage) which are managed for this version. Conflicts with fixed. Note that when using percent, rounding will be in favor of explicitly set target_size values; a managed instance group with 2 instances and 2 versions, one of which has a target_size.percent of 60 will create 2 instances of that version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#percent ComputeInstanceGroupManager#percent}
    */
    readonly percent?: number;
}
export declare function computeInstanceGroupManagerVersionTargetSizeToTerraform(struct?: ComputeInstanceGroupManagerVersionTargetSizeOutputReference | ComputeInstanceGroupManagerVersionTargetSize): any;
export declare function computeInstanceGroupManagerVersionTargetSizeToHclTerraform(struct?: ComputeInstanceGroupManagerVersionTargetSizeOutputReference | ComputeInstanceGroupManagerVersionTargetSize): any;
export declare class ComputeInstanceGroupManagerVersionTargetSizeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeInstanceGroupManagerVersionTargetSize | undefined;
    set internalValue(value: ComputeInstanceGroupManagerVersionTargetSize | undefined);
    private _fixed?;
    get fixed(): number;
    set fixed(value: number);
    resetFixed(): void;
    get fixedInput(): number | undefined;
    private _percent?;
    get percent(): number;
    set percent(value: number);
    resetPercent(): void;
    get percentInput(): number | undefined;
}
export interface ComputeInstanceGroupManagerVersion {
    /**
    * The full URL to an instance template from which all new instances of this version will be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#instance_template ComputeInstanceGroupManager#instance_template}
    */
    readonly instanceTemplate: string;
    /**
    * Version name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#name ComputeInstanceGroupManager#name}
    */
    readonly name?: string;
    /**
    * target_size block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#target_size ComputeInstanceGroupManager#target_size}
    */
    readonly targetSize?: ComputeInstanceGroupManagerVersionTargetSize;
}
export declare function computeInstanceGroupManagerVersionToTerraform(struct?: ComputeInstanceGroupManagerVersion | cdktn.IResolvable): any;
export declare function computeInstanceGroupManagerVersionToHclTerraform(struct?: ComputeInstanceGroupManagerVersion | cdktn.IResolvable): any;
export declare class ComputeInstanceGroupManagerVersionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeInstanceGroupManagerVersion | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeInstanceGroupManagerVersion | cdktn.IResolvable | undefined);
    private _instanceTemplate?;
    get instanceTemplate(): string;
    set instanceTemplate(value: string);
    get instanceTemplateInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _targetSize;
    get targetSize(): ComputeInstanceGroupManagerVersionTargetSizeOutputReference;
    putTargetSize(value: ComputeInstanceGroupManagerVersionTargetSize): void;
    resetTargetSize(): void;
    get targetSizeInput(): ComputeInstanceGroupManagerVersionTargetSize | undefined;
}
export declare class ComputeInstanceGroupManagerVersionList extends cdktn.ComplexList {
    internalValue?: ComputeInstanceGroupManagerVersion[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeInstanceGroupManagerVersionOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager google_compute_instance_group_manager}
*/
export declare class ComputeInstanceGroupManager extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_instance_group_manager";
    /**
    * Generates CDKTN code for importing a ComputeInstanceGroupManager resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeInstanceGroupManager to import
    * @param importFromId The id of the existing ComputeInstanceGroupManager that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeInstanceGroupManager to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_instance_group_manager google_compute_instance_group_manager} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeInstanceGroupManagerConfig
    */
    constructor(scope: Construct, id: string, config: ComputeInstanceGroupManagerConfig);
    private _baseInstanceName?;
    get baseInstanceName(): string;
    set baseInstanceName(value: string);
    get baseInstanceNameInput(): string | undefined;
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get fingerprint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get instanceGroup(): string;
    get instanceGroupManagerId(): number;
    private _listManagedInstancesResults?;
    get listManagedInstancesResults(): string;
    set listManagedInstancesResults(value: string);
    resetListManagedInstancesResults(): void;
    get listManagedInstancesResultsInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get operation(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get selfLink(): string;
    private _status;
    get status(): ComputeInstanceGroupManagerStatusList;
    private _targetPools?;
    get targetPools(): string[];
    set targetPools(value: string[]);
    resetTargetPools(): void;
    get targetPoolsInput(): string[] | undefined;
    private _targetSize?;
    get targetSize(): number;
    set targetSize(value: number);
    resetTargetSize(): void;
    get targetSizeInput(): number | undefined;
    private _targetStoppedSize?;
    get targetStoppedSize(): number;
    set targetStoppedSize(value: number);
    resetTargetStoppedSize(): void;
    get targetStoppedSizeInput(): number | undefined;
    private _targetSuspendedSize?;
    get targetSuspendedSize(): number;
    set targetSuspendedSize(value: number);
    resetTargetSuspendedSize(): void;
    get targetSuspendedSizeInput(): number | undefined;
    private _waitForInstances?;
    get waitForInstances(): boolean | cdktn.IResolvable;
    set waitForInstances(value: boolean | cdktn.IResolvable);
    resetWaitForInstances(): void;
    get waitForInstancesInput(): boolean | cdktn.IResolvable | undefined;
    private _waitForInstancesStatus?;
    get waitForInstancesStatus(): string;
    set waitForInstancesStatus(value: string);
    resetWaitForInstancesStatus(): void;
    get waitForInstancesStatusInput(): string | undefined;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    resetZone(): void;
    get zoneInput(): string | undefined;
    private _allInstancesConfig;
    get allInstancesConfig(): ComputeInstanceGroupManagerAllInstancesConfigOutputReference;
    putAllInstancesConfig(value: ComputeInstanceGroupManagerAllInstancesConfig): void;
    resetAllInstancesConfig(): void;
    get allInstancesConfigInput(): ComputeInstanceGroupManagerAllInstancesConfig | undefined;
    private _autoHealingPolicies;
    get autoHealingPolicies(): ComputeInstanceGroupManagerAutoHealingPoliciesOutputReference;
    putAutoHealingPolicies(value: ComputeInstanceGroupManagerAutoHealingPolicies): void;
    resetAutoHealingPolicies(): void;
    get autoHealingPoliciesInput(): ComputeInstanceGroupManagerAutoHealingPolicies | undefined;
    private _instanceLifecyclePolicy;
    get instanceLifecyclePolicy(): ComputeInstanceGroupManagerInstanceLifecyclePolicyOutputReference;
    putInstanceLifecyclePolicy(value: ComputeInstanceGroupManagerInstanceLifecyclePolicy): void;
    resetInstanceLifecyclePolicy(): void;
    get instanceLifecyclePolicyInput(): ComputeInstanceGroupManagerInstanceLifecyclePolicy | undefined;
    private _namedPort;
    get namedPort(): ComputeInstanceGroupManagerNamedPortList;
    putNamedPort(value: ComputeInstanceGroupManagerNamedPort[] | cdktn.IResolvable): void;
    resetNamedPort(): void;
    get namedPortInput(): cdktn.IResolvable | ComputeInstanceGroupManagerNamedPort[] | undefined;
    private _resourcePolicies;
    get resourcePolicies(): ComputeInstanceGroupManagerResourcePoliciesOutputReference;
    putResourcePolicies(value: ComputeInstanceGroupManagerResourcePolicies): void;
    resetResourcePolicies(): void;
    get resourcePoliciesInput(): ComputeInstanceGroupManagerResourcePolicies | undefined;
    private _standbyPolicy;
    get standbyPolicy(): ComputeInstanceGroupManagerStandbyPolicyOutputReference;
    putStandbyPolicy(value: ComputeInstanceGroupManagerStandbyPolicy): void;
    resetStandbyPolicy(): void;
    get standbyPolicyInput(): ComputeInstanceGroupManagerStandbyPolicy | undefined;
    private _statefulDisk;
    get statefulDisk(): ComputeInstanceGroupManagerStatefulDiskList;
    putStatefulDisk(value: ComputeInstanceGroupManagerStatefulDisk[] | cdktn.IResolvable): void;
    resetStatefulDisk(): void;
    get statefulDiskInput(): cdktn.IResolvable | ComputeInstanceGroupManagerStatefulDisk[] | undefined;
    private _statefulExternalIp;
    get statefulExternalIp(): ComputeInstanceGroupManagerStatefulExternalIpList;
    putStatefulExternalIp(value: ComputeInstanceGroupManagerStatefulExternalIp[] | cdktn.IResolvable): void;
    resetStatefulExternalIp(): void;
    get statefulExternalIpInput(): cdktn.IResolvable | ComputeInstanceGroupManagerStatefulExternalIp[] | undefined;
    private _statefulInternalIp;
    get statefulInternalIp(): ComputeInstanceGroupManagerStatefulInternalIpList;
    putStatefulInternalIp(value: ComputeInstanceGroupManagerStatefulInternalIp[] | cdktn.IResolvable): void;
    resetStatefulInternalIp(): void;
    get statefulInternalIpInput(): cdktn.IResolvable | ComputeInstanceGroupManagerStatefulInternalIp[] | undefined;
    private _targetSizePolicy;
    get targetSizePolicy(): ComputeInstanceGroupManagerTargetSizePolicyList;
    putTargetSizePolicy(value: ComputeInstanceGroupManagerTargetSizePolicy[] | cdktn.IResolvable): void;
    resetTargetSizePolicy(): void;
    get targetSizePolicyInput(): cdktn.IResolvable | ComputeInstanceGroupManagerTargetSizePolicy[] | undefined;
    private _timeouts;
    get timeouts(): ComputeInstanceGroupManagerTimeoutsOutputReference;
    putTimeouts(value: ComputeInstanceGroupManagerTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeInstanceGroupManagerTimeouts | undefined;
    private _updatePolicy;
    get updatePolicy(): ComputeInstanceGroupManagerUpdatePolicyOutputReference;
    putUpdatePolicy(value: ComputeInstanceGroupManagerUpdatePolicy): void;
    resetUpdatePolicy(): void;
    get updatePolicyInput(): ComputeInstanceGroupManagerUpdatePolicy | undefined;
    private _version;
    get version(): ComputeInstanceGroupManagerVersionList;
    putVersion(value: ComputeInstanceGroupManagerVersion[] | cdktn.IResolvable): void;
    get versionInput(): cdktn.IResolvable | ComputeInstanceGroupManagerVersion[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
