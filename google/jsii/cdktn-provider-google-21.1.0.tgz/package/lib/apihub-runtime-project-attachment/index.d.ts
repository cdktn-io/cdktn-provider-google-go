/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApihubRuntimeProjectAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_runtime_project_attachment#deletion_policy ApihubRuntimeProjectAttachment#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_runtime_project_attachment#id ApihubRuntimeProjectAttachment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Part of 'parent'. See documentation of 'projectsId'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_runtime_project_attachment#location ApihubRuntimeProjectAttachment#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_runtime_project_attachment#project ApihubRuntimeProjectAttachment#project}
    */
    readonly project?: string;
    /**
    * Required. Immutable. Google cloud project name in the format: "projects/abc" or "projects/123".
    * As input, project name with either project id or number are accepted.
    * As output, this field will contain project number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_runtime_project_attachment#runtime_project ApihubRuntimeProjectAttachment#runtime_project}
    */
    readonly runtimeProject: string;
    /**
    * The ID to use for the Runtime Project Attachment, which will become the
    * final component of the Runtime Project Attachment's name. The ID must be the same
    * as the project ID of the Google cloud project specified in the
    * runtime_project_attachment.runtime_project field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_runtime_project_attachment#runtime_project_attachment_id ApihubRuntimeProjectAttachment#runtime_project_attachment_id}
    */
    readonly runtimeProjectAttachmentId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_runtime_project_attachment#timeouts ApihubRuntimeProjectAttachment#timeouts}
    */
    readonly timeouts?: ApihubRuntimeProjectAttachmentTimeouts;
}
export interface ApihubRuntimeProjectAttachmentTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_runtime_project_attachment#create ApihubRuntimeProjectAttachment#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_runtime_project_attachment#delete ApihubRuntimeProjectAttachment#delete}
    */
    readonly delete?: string;
}
export declare function apihubRuntimeProjectAttachmentTimeoutsToTerraform(struct?: ApihubRuntimeProjectAttachmentTimeouts | cdktn.IResolvable): any;
export declare function apihubRuntimeProjectAttachmentTimeoutsToHclTerraform(struct?: ApihubRuntimeProjectAttachmentTimeouts | cdktn.IResolvable): any;
export declare class ApihubRuntimeProjectAttachmentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApihubRuntimeProjectAttachmentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApihubRuntimeProjectAttachmentTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_runtime_project_attachment google_apihub_runtime_project_attachment}
*/
export declare class ApihubRuntimeProjectAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apihub_runtime_project_attachment";
    /**
    * Generates CDKTN code for importing a ApihubRuntimeProjectAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApihubRuntimeProjectAttachment to import
    * @param importFromId The id of the existing ApihubRuntimeProjectAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_runtime_project_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApihubRuntimeProjectAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apihub_runtime_project_attachment google_apihub_runtime_project_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApihubRuntimeProjectAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: ApihubRuntimeProjectAttachmentConfig);
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _runtimeProject?;
    get runtimeProject(): string;
    set runtimeProject(value: string);
    get runtimeProjectInput(): string | undefined;
    private _runtimeProjectAttachmentId?;
    get runtimeProjectAttachmentId(): string;
    set runtimeProjectAttachmentId(value: string);
    get runtimeProjectAttachmentIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): ApihubRuntimeProjectAttachmentTimeoutsOutputReference;
    putTimeouts(value: ApihubRuntimeProjectAttachmentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApihubRuntimeProjectAttachmentTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
