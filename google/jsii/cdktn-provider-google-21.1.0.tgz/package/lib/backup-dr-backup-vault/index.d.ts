/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BackupDrBackupVaultConfig extends cdktn.TerraformMetaArguments {
    /**
    * Access restriction for the backup vault. Default value is 'WITHIN_ORGANIZATION' if not provided during creation. Default value: "WITHIN_ORGANIZATION" Possible values: ["ACCESS_RESTRICTION_UNSPECIFIED", "WITHIN_PROJECT", "WITHIN_ORGANIZATION", "UNRESTRICTED", "WITHIN_ORG_BUT_UNRESTRICTED_FOR_BA"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_vault#access_restriction BackupDrBackupVault#access_restriction}
    */
    readonly accessRestriction?: string;
    /**
    * Allow idempotent deletion of backup vault. The request will still succeed in case the backup vault does not exist.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_vault#allow_missing BackupDrBackupVault#allow_missing}
    */
    readonly allowMissing?: boolean | cdktn.IResolvable;
    /**
    * Optional. User annotations. See https://google.aip.dev/128#annotations
    * Stores small amounts of arbitrary data.
    *
    * **Note**: This field is non-authoritative, and will only manage the annotations present in your configuration.
    * Please refer to the field 'effective_annotations' for all of the annotations present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_vault#annotations BackupDrBackupVault#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Required. The default and minimum enforced retention for each backup within the backup vault. The enforced retention for each backup can be extended.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_vault#backup_minimum_enforced_retention_duration BackupDrBackupVault#backup_minimum_enforced_retention_duration}
    */
    readonly backupMinimumEnforcedRetentionDuration: string;
    /**
    * How a backup's enforced retention end time is inherited. Default value is 'INHERIT_VAULT_RETENTION' if not provided during creation. Possible values: ["BACKUP_RETENTION_INHERITANCE_UNSPECIFIED", "INHERIT_VAULT_RETENTION", "MATCH_BACKUP_EXPIRE_TIME"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_vault#backup_retention_inheritance BackupDrBackupVault#backup_retention_inheritance}
    */
    readonly backupRetentionInheritance?: string;
    /**
    * Required. ID of the requesting object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_vault#backup_vault_id BackupDrBackupVault#backup_vault_id}
    */
    readonly backupVaultId: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_vault#deletion_policy BackupDrBackupVault#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Optional. The description of the BackupVault instance (2048 characters or less).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_vault#description BackupDrBackupVault#description}
    */
    readonly description?: string;
    /**
    * Optional. Time after which the BackupVault resource is locked.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_vault#effective_time BackupDrBackupVault#effective_time}
    */
    readonly effectiveTime?: string;
    /**
    * If set, the following restrictions against deletion of the backup vault instance can be overridden:
    *    * deletion of a backup vault instance containing no backups, but still containing empty datasources.
    *    * deletion of a backup vault instance that is being referenced by an active backup plan.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_vault#force_delete BackupDrBackupVault#force_delete}
    */
    readonly forceDelete?: boolean | cdktn.IResolvable;
    /**
    * If set, allow update to extend the minimum enforced retention for backup vault. This overrides
    *  the restriction against conflicting retention periods. This conflict may occur when the
    *  expiration schedule defined by the associated backup plan is shorter than the minimum
    *  retention set by the backup vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_vault#force_update BackupDrBackupVault#force_update}
    */
    readonly forceUpdate?: boolean | cdktn.IResolvable;
    /**
    * If set to true, we will force update access restriction even if some non compliant data sources are present.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_vault#force_update_access_restriction BackupDrBackupVault#force_update_access_restriction}
    */
    readonly forceUpdateAccessRestriction?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_vault#id BackupDrBackupVault#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * If set, the following restrictions against deletion of the backup vault instance can be overridden:
    *    * deletion of a backup vault instance that is being referenced by an active backup plan.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_vault#ignore_backup_plan_references BackupDrBackupVault#ignore_backup_plan_references}
    */
    readonly ignoreBackupPlanReferences?: boolean | cdktn.IResolvable;
    /**
    * If set, the following restrictions against deletion of the backup vault instance can be overridden:
    *    * deletion of a backup vault instance containing no backups, but still containing empty datasources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_vault#ignore_inactive_datasources BackupDrBackupVault#ignore_inactive_datasources}
    */
    readonly ignoreInactiveDatasources?: boolean | cdktn.IResolvable;
    /**
    * Optional. Resource labels to represent user provided metadata.
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_vault#labels BackupDrBackupVault#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The GCP location for the backup vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_vault#location BackupDrBackupVault#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_vault#project BackupDrBackupVault#project}
    */
    readonly project?: string;
    /**
    * encryption_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_vault#encryption_config BackupDrBackupVault#encryption_config}
    */
    readonly encryptionConfig?: BackupDrBackupVaultEncryptionConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_vault#timeouts BackupDrBackupVault#timeouts}
    */
    readonly timeouts?: BackupDrBackupVaultTimeouts;
}
export interface BackupDrBackupVaultEncryptionConfig {
    /**
    * The Resource name of the Cloud KMS key to be used to encrypt new backups. The key must be in the same location as the backup vault. The key must be a Cloud KMS CryptoKey.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_vault#kms_key_name BackupDrBackupVault#kms_key_name}
    */
    readonly kmsKeyName?: string;
}
export declare function backupDrBackupVaultEncryptionConfigToTerraform(struct?: BackupDrBackupVaultEncryptionConfigOutputReference | BackupDrBackupVaultEncryptionConfig): any;
export declare function backupDrBackupVaultEncryptionConfigToHclTerraform(struct?: BackupDrBackupVaultEncryptionConfigOutputReference | BackupDrBackupVaultEncryptionConfig): any;
export declare class BackupDrBackupVaultEncryptionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrBackupVaultEncryptionConfig | undefined;
    set internalValue(value: BackupDrBackupVaultEncryptionConfig | undefined);
    private _kmsKeyName?;
    get kmsKeyName(): string;
    set kmsKeyName(value: string);
    resetKmsKeyName(): void;
    get kmsKeyNameInput(): string | undefined;
}
export interface BackupDrBackupVaultTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_vault#create BackupDrBackupVault#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_vault#delete BackupDrBackupVault#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_vault#update BackupDrBackupVault#update}
    */
    readonly update?: string;
}
export declare function backupDrBackupVaultTimeoutsToTerraform(struct?: BackupDrBackupVaultTimeouts | cdktn.IResolvable): any;
export declare function backupDrBackupVaultTimeoutsToHclTerraform(struct?: BackupDrBackupVaultTimeouts | cdktn.IResolvable): any;
export declare class BackupDrBackupVaultTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrBackupVaultTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BackupDrBackupVaultTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_vault google_backup_dr_backup_vault}
*/
export declare class BackupDrBackupVault extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_backup_dr_backup_vault";
    /**
    * Generates CDKTN code for importing a BackupDrBackupVault resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BackupDrBackupVault to import
    * @param importFromId The id of the existing BackupDrBackupVault that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_vault#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BackupDrBackupVault to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_vault google_backup_dr_backup_vault} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BackupDrBackupVaultConfig
    */
    constructor(scope: Construct, id: string, config: BackupDrBackupVaultConfig);
    private _accessRestriction?;
    get accessRestriction(): string;
    set accessRestriction(value: string);
    resetAccessRestriction(): void;
    get accessRestrictionInput(): string | undefined;
    private _allowMissing?;
    get allowMissing(): boolean | cdktn.IResolvable;
    set allowMissing(value: boolean | cdktn.IResolvable);
    resetAllowMissing(): void;
    get allowMissingInput(): boolean | cdktn.IResolvable | undefined;
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    get backupCount(): string;
    private _backupMinimumEnforcedRetentionDuration?;
    get backupMinimumEnforcedRetentionDuration(): string;
    set backupMinimumEnforcedRetentionDuration(value: string);
    get backupMinimumEnforcedRetentionDurationInput(): string | undefined;
    private _backupRetentionInheritance?;
    get backupRetentionInheritance(): string;
    set backupRetentionInheritance(value: string);
    resetBackupRetentionInheritance(): void;
    get backupRetentionInheritanceInput(): string | undefined;
    private _backupVaultId?;
    get backupVaultId(): string;
    set backupVaultId(value: string);
    get backupVaultIdInput(): string | undefined;
    get createTime(): string;
    get deletable(): cdktn.IResolvable;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _effectiveAnnotations;
    get effectiveAnnotations(): cdktn.StringMap;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _effectiveTime?;
    get effectiveTime(): string;
    set effectiveTime(value: string);
    resetEffectiveTime(): void;
    get effectiveTimeInput(): string | undefined;
    get etag(): string;
    private _forceDelete?;
    get forceDelete(): boolean | cdktn.IResolvable;
    set forceDelete(value: boolean | cdktn.IResolvable);
    resetForceDelete(): void;
    get forceDeleteInput(): boolean | cdktn.IResolvable | undefined;
    private _forceUpdate?;
    get forceUpdate(): boolean | cdktn.IResolvable;
    set forceUpdate(value: boolean | cdktn.IResolvable);
    resetForceUpdate(): void;
    get forceUpdateInput(): boolean | cdktn.IResolvable | undefined;
    private _forceUpdateAccessRestriction?;
    get forceUpdateAccessRestriction(): boolean | cdktn.IResolvable;
    set forceUpdateAccessRestriction(value: boolean | cdktn.IResolvable);
    resetForceUpdateAccessRestriction(): void;
    get forceUpdateAccessRestrictionInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ignoreBackupPlanReferences?;
    get ignoreBackupPlanReferences(): boolean | cdktn.IResolvable;
    set ignoreBackupPlanReferences(value: boolean | cdktn.IResolvable);
    resetIgnoreBackupPlanReferences(): void;
    get ignoreBackupPlanReferencesInput(): boolean | cdktn.IResolvable | undefined;
    private _ignoreInactiveDatasources?;
    get ignoreInactiveDatasources(): boolean | cdktn.IResolvable;
    set ignoreInactiveDatasources(value: boolean | cdktn.IResolvable);
    resetIgnoreInactiveDatasources(): void;
    get ignoreInactiveDatasourcesInput(): boolean | cdktn.IResolvable | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get serviceAccount(): string;
    get state(): string;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get totalStoredBytes(): string;
    get uid(): string;
    get updateTime(): string;
    private _encryptionConfig;
    get encryptionConfig(): BackupDrBackupVaultEncryptionConfigOutputReference;
    putEncryptionConfig(value: BackupDrBackupVaultEncryptionConfig): void;
    resetEncryptionConfig(): void;
    get encryptionConfigInput(): BackupDrBackupVaultEncryptionConfig | undefined;
    private _timeouts;
    get timeouts(): BackupDrBackupVaultTimeoutsOutputReference;
    putTimeouts(value: BackupDrBackupVaultTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BackupDrBackupVaultTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
