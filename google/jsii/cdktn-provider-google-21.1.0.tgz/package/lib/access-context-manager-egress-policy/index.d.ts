/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccessContextManagerEgressPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/access_context_manager_egress_policy#deletion_policy AccessContextManagerEgressPolicy#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The name of the Service Perimeter to add this resource to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/access_context_manager_egress_policy#egress_policy_name AccessContextManagerEgressPolicy#egress_policy_name}
    */
    readonly egressPolicyName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/access_context_manager_egress_policy#id AccessContextManagerEgressPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A GCP resource that is inside of the service perimeter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/access_context_manager_egress_policy#resource AccessContextManagerEgressPolicy#resource}
    */
    readonly resource: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/access_context_manager_egress_policy#timeouts AccessContextManagerEgressPolicy#timeouts}
    */
    readonly timeouts?: AccessContextManagerEgressPolicyTimeouts;
}
export interface AccessContextManagerEgressPolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/access_context_manager_egress_policy#create AccessContextManagerEgressPolicy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/access_context_manager_egress_policy#delete AccessContextManagerEgressPolicy#delete}
    */
    readonly delete?: string;
}
export declare function accessContextManagerEgressPolicyTimeoutsToTerraform(struct?: AccessContextManagerEgressPolicyTimeouts | cdktn.IResolvable): any;
export declare function accessContextManagerEgressPolicyTimeoutsToHclTerraform(struct?: AccessContextManagerEgressPolicyTimeouts | cdktn.IResolvable): any;
export declare class AccessContextManagerEgressPolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessContextManagerEgressPolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AccessContextManagerEgressPolicyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/access_context_manager_egress_policy google_access_context_manager_egress_policy}
*/
export declare class AccessContextManagerEgressPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_access_context_manager_egress_policy";
    /**
    * Generates CDKTN code for importing a AccessContextManagerEgressPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessContextManagerEgressPolicy to import
    * @param importFromId The id of the existing AccessContextManagerEgressPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/access_context_manager_egress_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessContextManagerEgressPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/access_context_manager_egress_policy google_access_context_manager_egress_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessContextManagerEgressPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AccessContextManagerEgressPolicyConfig);
    get accessPolicyId(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _egressPolicyName?;
    get egressPolicyName(): string;
    set egressPolicyName(value: string);
    get egressPolicyNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _resource?;
    get resource(): string;
    set resource(value: string);
    get resourceInput(): string | undefined;
    private _timeouts;
    get timeouts(): AccessContextManagerEgressPolicyTimeoutsOutputReference;
    putTimeouts(value: AccessContextManagerEgressPolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AccessContextManagerEgressPolicyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
