/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeSnapshotSettingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_snapshot_settings#id ComputeSnapshotSettings#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_snapshot_settings#project ComputeSnapshotSettings#project}
    */
    readonly project?: string;
    /**
    * storage_location block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_snapshot_settings#storage_location ComputeSnapshotSettings#storage_location}
    */
    readonly storageLocation: ComputeSnapshotSettingsStorageLocation;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_snapshot_settings#timeouts ComputeSnapshotSettings#timeouts}
    */
    readonly timeouts?: ComputeSnapshotSettingsTimeouts;
}
export interface ComputeSnapshotSettingsStorageLocationLocations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_snapshot_settings#location ComputeSnapshotSettings#location}
    */
    readonly location: string;
    /**
    * Name of the location. It should be one of the Cloud Storage buckets.
    * Only one location can be specified. (should match location)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_snapshot_settings#name ComputeSnapshotSettings#name}
    */
    readonly name: string;
}
export declare function computeSnapshotSettingsStorageLocationLocationsToTerraform(struct?: ComputeSnapshotSettingsStorageLocationLocations | cdktn.IResolvable): any;
export declare function computeSnapshotSettingsStorageLocationLocationsToHclTerraform(struct?: ComputeSnapshotSettingsStorageLocationLocations | cdktn.IResolvable): any;
export declare class ComputeSnapshotSettingsStorageLocationLocationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeSnapshotSettingsStorageLocationLocations | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeSnapshotSettingsStorageLocationLocations | cdktn.IResolvable | undefined);
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class ComputeSnapshotSettingsStorageLocationLocationsList extends cdktn.ComplexList {
    internalValue?: ComputeSnapshotSettingsStorageLocationLocations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeSnapshotSettingsStorageLocationLocationsOutputReference;
}
export interface ComputeSnapshotSettingsStorageLocation {
    /**
    * The chosen location policy Possible values: ["NEAREST_MULTI_REGION", "LOCAL_REGION", "SPECIFIC_LOCATIONS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_snapshot_settings#policy ComputeSnapshotSettings#policy}
    */
    readonly policy: string;
    /**
    * locations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_snapshot_settings#locations ComputeSnapshotSettings#locations}
    */
    readonly locations?: ComputeSnapshotSettingsStorageLocationLocations[] | cdktn.IResolvable;
}
export declare function computeSnapshotSettingsStorageLocationToTerraform(struct?: ComputeSnapshotSettingsStorageLocationOutputReference | ComputeSnapshotSettingsStorageLocation): any;
export declare function computeSnapshotSettingsStorageLocationToHclTerraform(struct?: ComputeSnapshotSettingsStorageLocationOutputReference | ComputeSnapshotSettingsStorageLocation): any;
export declare class ComputeSnapshotSettingsStorageLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSnapshotSettingsStorageLocation | undefined;
    set internalValue(value: ComputeSnapshotSettingsStorageLocation | undefined);
    private _policy?;
    get policy(): string;
    set policy(value: string);
    get policyInput(): string | undefined;
    private _locations;
    get locations(): ComputeSnapshotSettingsStorageLocationLocationsList;
    putLocations(value: ComputeSnapshotSettingsStorageLocationLocations[] | cdktn.IResolvable): void;
    resetLocations(): void;
    get locationsInput(): cdktn.IResolvable | ComputeSnapshotSettingsStorageLocationLocations[] | undefined;
}
export interface ComputeSnapshotSettingsTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_snapshot_settings#create ComputeSnapshotSettings#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_snapshot_settings#delete ComputeSnapshotSettings#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_snapshot_settings#update ComputeSnapshotSettings#update}
    */
    readonly update?: string;
}
export declare function computeSnapshotSettingsTimeoutsToTerraform(struct?: ComputeSnapshotSettingsTimeouts | cdktn.IResolvable): any;
export declare function computeSnapshotSettingsTimeoutsToHclTerraform(struct?: ComputeSnapshotSettingsTimeouts | cdktn.IResolvable): any;
export declare class ComputeSnapshotSettingsTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSnapshotSettingsTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeSnapshotSettingsTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_snapshot_settings google_compute_snapshot_settings}
*/
export declare class ComputeSnapshotSettings extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_snapshot_settings";
    /**
    * Generates CDKTN code for importing a ComputeSnapshotSettings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeSnapshotSettings to import
    * @param importFromId The id of the existing ComputeSnapshotSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_snapshot_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeSnapshotSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_snapshot_settings google_compute_snapshot_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeSnapshotSettingsConfig
    */
    constructor(scope: Construct, id: string, config: ComputeSnapshotSettingsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _storageLocation;
    get storageLocation(): ComputeSnapshotSettingsStorageLocationOutputReference;
    putStorageLocation(value: ComputeSnapshotSettingsStorageLocation): void;
    get storageLocationInput(): ComputeSnapshotSettingsStorageLocation | undefined;
    private _timeouts;
    get timeouts(): ComputeSnapshotSettingsTimeoutsOutputReference;
    putTimeouts(value: ComputeSnapshotSettingsTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeSnapshotSettingsTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
