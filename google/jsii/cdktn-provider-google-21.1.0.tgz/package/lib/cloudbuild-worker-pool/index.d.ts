/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudbuildWorkerPoolConfig extends cdktn.TerraformMetaArguments {
    /**
    * User specified annotations. See https://google.aip.dev/128#annotations for more details such as format and size limitations.
    *
    * **Note**: This field is non-authoritative, and will only manage the annotations present in your configuration.
    * Please refer to the field `effective_annotations` for all of the annotations present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_worker_pool#annotations CloudbuildWorkerPool#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_worker_pool#deletion_policy CloudbuildWorkerPool#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * A user-specified, human-readable name for the `WorkerPool`. If provided, this value must be 1-63 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_worker_pool#display_name CloudbuildWorkerPool#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_worker_pool#id CloudbuildWorkerPool#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location for the resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_worker_pool#location CloudbuildWorkerPool#location}
    */
    readonly location: string;
    /**
    * User-defined name of the `WorkerPool`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_worker_pool#name CloudbuildWorkerPool#name}
    */
    readonly name: string;
    /**
    * The project for the resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_worker_pool#project CloudbuildWorkerPool#project}
    */
    readonly project?: string;
    /**
    * network_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_worker_pool#network_config CloudbuildWorkerPool#network_config}
    */
    readonly networkConfig?: CloudbuildWorkerPoolNetworkConfig;
    /**
    * private_service_connect block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_worker_pool#private_service_connect CloudbuildWorkerPool#private_service_connect}
    */
    readonly privateServiceConnect?: CloudbuildWorkerPoolPrivateServiceConnect;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_worker_pool#timeouts CloudbuildWorkerPool#timeouts}
    */
    readonly timeouts?: CloudbuildWorkerPoolTimeouts;
    /**
    * worker_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_worker_pool#worker_config CloudbuildWorkerPool#worker_config}
    */
    readonly workerConfig?: CloudbuildWorkerPoolWorkerConfig;
}
export interface CloudbuildWorkerPoolNetworkConfig {
    /**
    * Required. Immutable. The network definition that the workers are peered to. If this section is left empty, the workers will be peered to `WorkerPool.project_id` on the service producer network. Must be in the format `projects/{project}/global/networks/{network}`, where `{project}` is a project number, such as `12345`, and `{network}` is the name of a VPC network in the project. See [Understanding network configuration options](https://cloud.google.com/cloud-build/docs/custom-workers/set-up-custom-worker-pool-environment#understanding_the_network_configuration_options)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_worker_pool#peered_network CloudbuildWorkerPool#peered_network}
    */
    readonly peeredNetwork: string;
    /**
    * Optional. Immutable. Subnet IP range within the peered network. This is specified in CIDR notation with a slash and the subnet prefix size. You can optionally specify an IP address before the subnet prefix value. e.g. `192.168.0.0/29` would specify an IP range starting at 192.168.0.0 with a prefix size of 29 bits. `/16` would specify a prefix size of 16 bits, with an automatically determined IP within the peered VPC. If unspecified, a value of `/24` will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_worker_pool#peered_network_ip_range CloudbuildWorkerPool#peered_network_ip_range}
    */
    readonly peeredNetworkIpRange?: string;
}
export declare function cloudbuildWorkerPoolNetworkConfigToTerraform(struct?: CloudbuildWorkerPoolNetworkConfigOutputReference | CloudbuildWorkerPoolNetworkConfig): any;
export declare function cloudbuildWorkerPoolNetworkConfigToHclTerraform(struct?: CloudbuildWorkerPoolNetworkConfigOutputReference | CloudbuildWorkerPoolNetworkConfig): any;
export declare class CloudbuildWorkerPoolNetworkConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildWorkerPoolNetworkConfig | undefined;
    set internalValue(value: CloudbuildWorkerPoolNetworkConfig | undefined);
    private _peeredNetwork?;
    get peeredNetwork(): string;
    set peeredNetwork(value: string);
    get peeredNetworkInput(): string | undefined;
    private _peeredNetworkIpRange?;
    get peeredNetworkIpRange(): string;
    set peeredNetworkIpRange(value: string);
    resetPeeredNetworkIpRange(): void;
    get peeredNetworkIpRangeInput(): string | undefined;
}
export interface CloudbuildWorkerPoolPrivateServiceConnect {
    /**
    * Required. Immutable. The network attachment that the worker network interface is connected to. Must be in the format `projects/{project}/regions/{region}/networkAttachments/{networkAttachment}`. The region of network attachment must be the same as the worker pool. See [Network Attachments](https://cloud.google.com/vpc/docs/about-network-attachments)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_worker_pool#network_attachment CloudbuildWorkerPool#network_attachment}
    */
    readonly networkAttachment: string;
    /**
    * Immutable. Route all traffic through PSC interface. Enable this if you want full control of traffic in the private pool. Configure Cloud NAT for the subnet of network attachment if you need to access public Internet. If false, Only route private IPs, e.g. 10.0.0.0/8, 172.16.0.0/12, and 192.168.0.0/16 through PSC interface.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_worker_pool#route_all_traffic CloudbuildWorkerPool#route_all_traffic}
    */
    readonly routeAllTraffic?: boolean | cdktn.IResolvable;
}
export declare function cloudbuildWorkerPoolPrivateServiceConnectToTerraform(struct?: CloudbuildWorkerPoolPrivateServiceConnectOutputReference | CloudbuildWorkerPoolPrivateServiceConnect): any;
export declare function cloudbuildWorkerPoolPrivateServiceConnectToHclTerraform(struct?: CloudbuildWorkerPoolPrivateServiceConnectOutputReference | CloudbuildWorkerPoolPrivateServiceConnect): any;
export declare class CloudbuildWorkerPoolPrivateServiceConnectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildWorkerPoolPrivateServiceConnect | undefined;
    set internalValue(value: CloudbuildWorkerPoolPrivateServiceConnect | undefined);
    private _networkAttachment?;
    get networkAttachment(): string;
    set networkAttachment(value: string);
    get networkAttachmentInput(): string | undefined;
    private _routeAllTraffic?;
    get routeAllTraffic(): boolean | cdktn.IResolvable;
    set routeAllTraffic(value: boolean | cdktn.IResolvable);
    resetRouteAllTraffic(): void;
    get routeAllTrafficInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CloudbuildWorkerPoolTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_worker_pool#create CloudbuildWorkerPool#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_worker_pool#delete CloudbuildWorkerPool#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_worker_pool#update CloudbuildWorkerPool#update}
    */
    readonly update?: string;
}
export declare function cloudbuildWorkerPoolTimeoutsToTerraform(struct?: CloudbuildWorkerPoolTimeouts | cdktn.IResolvable): any;
export declare function cloudbuildWorkerPoolTimeoutsToHclTerraform(struct?: CloudbuildWorkerPoolTimeouts | cdktn.IResolvable): any;
export declare class CloudbuildWorkerPoolTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildWorkerPoolTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CloudbuildWorkerPoolTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface CloudbuildWorkerPoolWorkerConfig {
    /**
    * Size of the disk attached to the worker, in GB. See [Worker pool config file](https://cloud.google.com/cloud-build/docs/custom-workers/worker-pool-config-file). Specify a value of up to 1000. If `0` is specified, Cloud Build will use a standard disk size.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_worker_pool#disk_size_gb CloudbuildWorkerPool#disk_size_gb}
    */
    readonly diskSizeGb?: number;
    /**
    * Enable nested virtualization on the worker, if supported by the machine type. See [Worker pool config file](https://cloud.google.com/build/docs/private-pools/worker-pool-config-file-schema). If left blank, Cloud Build will set this to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_worker_pool#enable_nested_virtualization CloudbuildWorkerPool#enable_nested_virtualization}
    */
    readonly enableNestedVirtualization?: boolean | cdktn.IResolvable;
    /**
    * Machine type of a worker, such as `n1-standard-1`. See [Worker pool config file](https://cloud.google.com/cloud-build/docs/custom-workers/worker-pool-config-file). If left blank, Cloud Build will use `n1-standard-1`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_worker_pool#machine_type CloudbuildWorkerPool#machine_type}
    */
    readonly machineType?: string;
    /**
    * If true, workers are created without any public address, which prevents network egress to public IPs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_worker_pool#no_external_ip CloudbuildWorkerPool#no_external_ip}
    */
    readonly noExternalIp?: boolean | cdktn.IResolvable;
}
export declare function cloudbuildWorkerPoolWorkerConfigToTerraform(struct?: CloudbuildWorkerPoolWorkerConfigOutputReference | CloudbuildWorkerPoolWorkerConfig): any;
export declare function cloudbuildWorkerPoolWorkerConfigToHclTerraform(struct?: CloudbuildWorkerPoolWorkerConfigOutputReference | CloudbuildWorkerPoolWorkerConfig): any;
export declare class CloudbuildWorkerPoolWorkerConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildWorkerPoolWorkerConfig | undefined;
    set internalValue(value: CloudbuildWorkerPoolWorkerConfig | undefined);
    private _diskSizeGb?;
    get diskSizeGb(): number;
    set diskSizeGb(value: number);
    resetDiskSizeGb(): void;
    get diskSizeGbInput(): number | undefined;
    private _enableNestedVirtualization?;
    get enableNestedVirtualization(): boolean | cdktn.IResolvable;
    set enableNestedVirtualization(value: boolean | cdktn.IResolvable);
    resetEnableNestedVirtualization(): void;
    get enableNestedVirtualizationInput(): boolean | cdktn.IResolvable | undefined;
    private _machineType?;
    get machineType(): string;
    set machineType(value: string);
    resetMachineType(): void;
    get machineTypeInput(): string | undefined;
    private _noExternalIp?;
    get noExternalIp(): boolean | cdktn.IResolvable;
    set noExternalIp(value: boolean | cdktn.IResolvable);
    resetNoExternalIp(): void;
    get noExternalIpInput(): boolean | cdktn.IResolvable | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_worker_pool google_cloudbuild_worker_pool}
*/
export declare class CloudbuildWorkerPool extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_cloudbuild_worker_pool";
    /**
    * Generates CDKTN code for importing a CloudbuildWorkerPool resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudbuildWorkerPool to import
    * @param importFromId The id of the existing CloudbuildWorkerPool that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_worker_pool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudbuildWorkerPool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_worker_pool google_cloudbuild_worker_pool} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudbuildWorkerPoolConfig
    */
    constructor(scope: Construct, id: string, config: CloudbuildWorkerPoolConfig);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    get createTime(): string;
    get deleteTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _effectiveAnnotations;
    get effectiveAnnotations(): cdktn.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get state(): string;
    get uid(): string;
    get updateTime(): string;
    private _networkConfig;
    get networkConfig(): CloudbuildWorkerPoolNetworkConfigOutputReference;
    putNetworkConfig(value: CloudbuildWorkerPoolNetworkConfig): void;
    resetNetworkConfig(): void;
    get networkConfigInput(): CloudbuildWorkerPoolNetworkConfig | undefined;
    private _privateServiceConnect;
    get privateServiceConnect(): CloudbuildWorkerPoolPrivateServiceConnectOutputReference;
    putPrivateServiceConnect(value: CloudbuildWorkerPoolPrivateServiceConnect): void;
    resetPrivateServiceConnect(): void;
    get privateServiceConnectInput(): CloudbuildWorkerPoolPrivateServiceConnect | undefined;
    private _timeouts;
    get timeouts(): CloudbuildWorkerPoolTimeoutsOutputReference;
    putTimeouts(value: CloudbuildWorkerPoolTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CloudbuildWorkerPoolTimeouts | undefined;
    private _workerConfig;
    get workerConfig(): CloudbuildWorkerPoolWorkerConfigOutputReference;
    putWorkerConfig(value: CloudbuildWorkerPoolWorkerConfig): void;
    resetWorkerConfig(): void;
    get workerConfigInput(): CloudbuildWorkerPoolWorkerConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
