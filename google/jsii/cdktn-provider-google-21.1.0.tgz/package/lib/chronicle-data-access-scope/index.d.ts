/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChronicleDataAccessScopeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Optional. Whether or not the scope allows all labels, allow_all and
    * allowed_data_access_labels are mutually exclusive and one of them must be
    * present. denied_data_access_labels can still be used along with allow_all.
    * When combined with denied_data_access_labels, access will be granted to all
    * data that doesn't have labels mentioned in denied_data_access_labels. E.g.:
    * A customer with scope with denied labels A and B and allow_all will be able
    * to see all data except data labeled with A and data labeled with B and data
    * with labels A and B.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope#allow_all ChronicleDataAccessScope#allow_all}
    */
    readonly allowAll?: boolean | cdktn.IResolvable;
    /**
    * Required. The user provided scope id which will become the last part of the name
    * of the scope resource.
    * Needs to be compliant with https://google.aip.dev/122
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope#data_access_scope_id ChronicleDataAccessScope#data_access_scope_id}
    */
    readonly dataAccessScopeId: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope#deletion_policy ChronicleDataAccessScope#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Optional. A description of the data access scope for a human reader.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope#description ChronicleDataAccessScope#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope#id ChronicleDataAccessScope#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The unique identifier for the Chronicle instance, which is the same as the customer ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope#instance ChronicleDataAccessScope#instance}
    */
    readonly instance: string;
    /**
    * The location of the resource. This is the geographical region where the Chronicle instance resides, such as "us" or "europe-west2".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope#location ChronicleDataAccessScope#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope#project ChronicleDataAccessScope#project}
    */
    readonly project?: string;
    /**
    * allowed_data_access_labels block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope#allowed_data_access_labels ChronicleDataAccessScope#allowed_data_access_labels}
    */
    readonly allowedDataAccessLabels?: ChronicleDataAccessScopeAllowedDataAccessLabels[] | cdktn.IResolvable;
    /**
    * denied_data_access_labels block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope#denied_data_access_labels ChronicleDataAccessScope#denied_data_access_labels}
    */
    readonly deniedDataAccessLabels?: ChronicleDataAccessScopeDeniedDataAccessLabels[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope#timeouts ChronicleDataAccessScope#timeouts}
    */
    readonly timeouts?: ChronicleDataAccessScopeTimeouts;
}
export interface ChronicleDataAccessScopeAllowedDataAccessLabelsIngestionLabel {
    /**
    * Required. The key of the ingestion label. Always required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope#ingestion_label_key ChronicleDataAccessScope#ingestion_label_key}
    */
    readonly ingestionLabelKey: string;
    /**
    * Optional. The value of the ingestion label. Optional. An object
    * with no provided value and some key provided would match
    * against the given key and ANY value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope#ingestion_label_value ChronicleDataAccessScope#ingestion_label_value}
    */
    readonly ingestionLabelValue?: string;
}
export declare function chronicleDataAccessScopeAllowedDataAccessLabelsIngestionLabelToTerraform(struct?: ChronicleDataAccessScopeAllowedDataAccessLabelsIngestionLabelOutputReference | ChronicleDataAccessScopeAllowedDataAccessLabelsIngestionLabel): any;
export declare function chronicleDataAccessScopeAllowedDataAccessLabelsIngestionLabelToHclTerraform(struct?: ChronicleDataAccessScopeAllowedDataAccessLabelsIngestionLabelOutputReference | ChronicleDataAccessScopeAllowedDataAccessLabelsIngestionLabel): any;
export declare class ChronicleDataAccessScopeAllowedDataAccessLabelsIngestionLabelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDataAccessScopeAllowedDataAccessLabelsIngestionLabel | undefined;
    set internalValue(value: ChronicleDataAccessScopeAllowedDataAccessLabelsIngestionLabel | undefined);
    private _ingestionLabelKey?;
    get ingestionLabelKey(): string;
    set ingestionLabelKey(value: string);
    get ingestionLabelKeyInput(): string | undefined;
    private _ingestionLabelValue?;
    get ingestionLabelValue(): string;
    set ingestionLabelValue(value: string);
    resetIngestionLabelValue(): void;
    get ingestionLabelValueInput(): string | undefined;
}
export interface ChronicleDataAccessScopeAllowedDataAccessLabels {
    /**
    * The asset namespace configured in the forwarder
    * of the customer's events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope#asset_namespace ChronicleDataAccessScope#asset_namespace}
    */
    readonly assetNamespace?: string;
    /**
    * The name of the data access label.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope#data_access_label ChronicleDataAccessScope#data_access_label}
    */
    readonly dataAccessLabel?: string;
    /**
    * The name of the log type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope#log_type ChronicleDataAccessScope#log_type}
    */
    readonly logType?: string;
    /**
    * ingestion_label block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope#ingestion_label ChronicleDataAccessScope#ingestion_label}
    */
    readonly ingestionLabel?: ChronicleDataAccessScopeAllowedDataAccessLabelsIngestionLabel;
}
export declare function chronicleDataAccessScopeAllowedDataAccessLabelsToTerraform(struct?: ChronicleDataAccessScopeAllowedDataAccessLabels | cdktn.IResolvable): any;
export declare function chronicleDataAccessScopeAllowedDataAccessLabelsToHclTerraform(struct?: ChronicleDataAccessScopeAllowedDataAccessLabels | cdktn.IResolvable): any;
export declare class ChronicleDataAccessScopeAllowedDataAccessLabelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleDataAccessScopeAllowedDataAccessLabels | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleDataAccessScopeAllowedDataAccessLabels | cdktn.IResolvable | undefined);
    private _assetNamespace?;
    get assetNamespace(): string;
    set assetNamespace(value: string);
    resetAssetNamespace(): void;
    get assetNamespaceInput(): string | undefined;
    private _dataAccessLabel?;
    get dataAccessLabel(): string;
    set dataAccessLabel(value: string);
    resetDataAccessLabel(): void;
    get dataAccessLabelInput(): string | undefined;
    get displayName(): string;
    private _logType?;
    get logType(): string;
    set logType(value: string);
    resetLogType(): void;
    get logTypeInput(): string | undefined;
    private _ingestionLabel;
    get ingestionLabel(): ChronicleDataAccessScopeAllowedDataAccessLabelsIngestionLabelOutputReference;
    putIngestionLabel(value: ChronicleDataAccessScopeAllowedDataAccessLabelsIngestionLabel): void;
    resetIngestionLabel(): void;
    get ingestionLabelInput(): ChronicleDataAccessScopeAllowedDataAccessLabelsIngestionLabel | undefined;
}
export declare class ChronicleDataAccessScopeAllowedDataAccessLabelsList extends cdktn.ComplexList {
    internalValue?: ChronicleDataAccessScopeAllowedDataAccessLabels[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleDataAccessScopeAllowedDataAccessLabelsOutputReference;
}
export interface ChronicleDataAccessScopeDeniedDataAccessLabelsIngestionLabel {
    /**
    * Required. The key of the ingestion label. Always required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope#ingestion_label_key ChronicleDataAccessScope#ingestion_label_key}
    */
    readonly ingestionLabelKey: string;
    /**
    * Optional. The value of the ingestion label. Optional. An object
    * with no provided value and some key provided would match
    * against the given key and ANY value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope#ingestion_label_value ChronicleDataAccessScope#ingestion_label_value}
    */
    readonly ingestionLabelValue?: string;
}
export declare function chronicleDataAccessScopeDeniedDataAccessLabelsIngestionLabelToTerraform(struct?: ChronicleDataAccessScopeDeniedDataAccessLabelsIngestionLabelOutputReference | ChronicleDataAccessScopeDeniedDataAccessLabelsIngestionLabel): any;
export declare function chronicleDataAccessScopeDeniedDataAccessLabelsIngestionLabelToHclTerraform(struct?: ChronicleDataAccessScopeDeniedDataAccessLabelsIngestionLabelOutputReference | ChronicleDataAccessScopeDeniedDataAccessLabelsIngestionLabel): any;
export declare class ChronicleDataAccessScopeDeniedDataAccessLabelsIngestionLabelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDataAccessScopeDeniedDataAccessLabelsIngestionLabel | undefined;
    set internalValue(value: ChronicleDataAccessScopeDeniedDataAccessLabelsIngestionLabel | undefined);
    private _ingestionLabelKey?;
    get ingestionLabelKey(): string;
    set ingestionLabelKey(value: string);
    get ingestionLabelKeyInput(): string | undefined;
    private _ingestionLabelValue?;
    get ingestionLabelValue(): string;
    set ingestionLabelValue(value: string);
    resetIngestionLabelValue(): void;
    get ingestionLabelValueInput(): string | undefined;
}
export interface ChronicleDataAccessScopeDeniedDataAccessLabels {
    /**
    * The asset namespace configured in the forwarder
    * of the customer's events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope#asset_namespace ChronicleDataAccessScope#asset_namespace}
    */
    readonly assetNamespace?: string;
    /**
    * The name of the data access label.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope#data_access_label ChronicleDataAccessScope#data_access_label}
    */
    readonly dataAccessLabel?: string;
    /**
    * The name of the log type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope#log_type ChronicleDataAccessScope#log_type}
    */
    readonly logType?: string;
    /**
    * ingestion_label block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope#ingestion_label ChronicleDataAccessScope#ingestion_label}
    */
    readonly ingestionLabel?: ChronicleDataAccessScopeDeniedDataAccessLabelsIngestionLabel;
}
export declare function chronicleDataAccessScopeDeniedDataAccessLabelsToTerraform(struct?: ChronicleDataAccessScopeDeniedDataAccessLabels | cdktn.IResolvable): any;
export declare function chronicleDataAccessScopeDeniedDataAccessLabelsToHclTerraform(struct?: ChronicleDataAccessScopeDeniedDataAccessLabels | cdktn.IResolvable): any;
export declare class ChronicleDataAccessScopeDeniedDataAccessLabelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleDataAccessScopeDeniedDataAccessLabels | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleDataAccessScopeDeniedDataAccessLabels | cdktn.IResolvable | undefined);
    private _assetNamespace?;
    get assetNamespace(): string;
    set assetNamespace(value: string);
    resetAssetNamespace(): void;
    get assetNamespaceInput(): string | undefined;
    private _dataAccessLabel?;
    get dataAccessLabel(): string;
    set dataAccessLabel(value: string);
    resetDataAccessLabel(): void;
    get dataAccessLabelInput(): string | undefined;
    get displayName(): string;
    private _logType?;
    get logType(): string;
    set logType(value: string);
    resetLogType(): void;
    get logTypeInput(): string | undefined;
    private _ingestionLabel;
    get ingestionLabel(): ChronicleDataAccessScopeDeniedDataAccessLabelsIngestionLabelOutputReference;
    putIngestionLabel(value: ChronicleDataAccessScopeDeniedDataAccessLabelsIngestionLabel): void;
    resetIngestionLabel(): void;
    get ingestionLabelInput(): ChronicleDataAccessScopeDeniedDataAccessLabelsIngestionLabel | undefined;
}
export declare class ChronicleDataAccessScopeDeniedDataAccessLabelsList extends cdktn.ComplexList {
    internalValue?: ChronicleDataAccessScopeDeniedDataAccessLabels[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleDataAccessScopeDeniedDataAccessLabelsOutputReference;
}
export interface ChronicleDataAccessScopeTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope#create ChronicleDataAccessScope#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope#delete ChronicleDataAccessScope#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope#update ChronicleDataAccessScope#update}
    */
    readonly update?: string;
}
export declare function chronicleDataAccessScopeTimeoutsToTerraform(struct?: ChronicleDataAccessScopeTimeouts | cdktn.IResolvable): any;
export declare function chronicleDataAccessScopeTimeoutsToHclTerraform(struct?: ChronicleDataAccessScopeTimeouts | cdktn.IResolvable): any;
export declare class ChronicleDataAccessScopeTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDataAccessScopeTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleDataAccessScopeTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope google_chronicle_data_access_scope}
*/
export declare class ChronicleDataAccessScope extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_chronicle_data_access_scope";
    /**
    * Generates CDKTN code for importing a ChronicleDataAccessScope resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChronicleDataAccessScope to import
    * @param importFromId The id of the existing ChronicleDataAccessScope that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChronicleDataAccessScope to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_scope google_chronicle_data_access_scope} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChronicleDataAccessScopeConfig
    */
    constructor(scope: Construct, id: string, config: ChronicleDataAccessScopeConfig);
    private _allowAll?;
    get allowAll(): boolean | cdktn.IResolvable;
    set allowAll(value: boolean | cdktn.IResolvable);
    resetAllowAll(): void;
    get allowAllInput(): boolean | cdktn.IResolvable | undefined;
    get author(): string;
    get createTime(): string;
    private _dataAccessScopeId?;
    get dataAccessScopeId(): string;
    set dataAccessScopeId(value: string);
    get dataAccessScopeIdInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get displayName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instance?;
    get instance(): string;
    set instance(value: string);
    get instanceInput(): string | undefined;
    get lastEditor(): string;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get updateTime(): string;
    private _allowedDataAccessLabels;
    get allowedDataAccessLabels(): ChronicleDataAccessScopeAllowedDataAccessLabelsList;
    putAllowedDataAccessLabels(value: ChronicleDataAccessScopeAllowedDataAccessLabels[] | cdktn.IResolvable): void;
    resetAllowedDataAccessLabels(): void;
    get allowedDataAccessLabelsInput(): cdktn.IResolvable | ChronicleDataAccessScopeAllowedDataAccessLabels[] | undefined;
    private _deniedDataAccessLabels;
    get deniedDataAccessLabels(): ChronicleDataAccessScopeDeniedDataAccessLabelsList;
    putDeniedDataAccessLabels(value: ChronicleDataAccessScopeDeniedDataAccessLabels[] | cdktn.IResolvable): void;
    resetDeniedDataAccessLabels(): void;
    get deniedDataAccessLabelsInput(): cdktn.IResolvable | ChronicleDataAccessScopeDeniedDataAccessLabels[] | undefined;
    private _timeouts;
    get timeouts(): ChronicleDataAccessScopeTimeoutsOutputReference;
    putTimeouts(value: ChronicleDataAccessScopeTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ChronicleDataAccessScopeTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
