/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeSecurityPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#deletion_policy ComputeSecurityPolicy#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this security policy. Max size is 2048.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#description ComputeSecurityPolicy#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#id ComputeSecurityPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Labels to apply to this address.  A list of key->value pairs.
    *
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#labels ComputeSecurityPolicy#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The name of the security policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#name ComputeSecurityPolicy#name}
    */
    readonly name: string;
    /**
    * The project in which the resource belongs. If it is not provided, the provider project is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#project ComputeSecurityPolicy#project}
    */
    readonly project?: string;
    /**
    * The type indicates the intended use of the security policy. CLOUD_ARMOR - Cloud Armor backend security policies can be configured to filter incoming HTTP requests targeting backend services. They filter requests before they hit the origin servers. CLOUD_ARMOR_EDGE - Cloud Armor edge security policies can be configured to filter incoming HTTP requests targeting backend services (including Cloud CDN-enabled) as well as backend buckets (Cloud Storage). They filter requests before the request is served from Google's cache.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#type ComputeSecurityPolicy#type}
    */
    readonly type?: string;
    /**
    * adaptive_protection_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#adaptive_protection_config ComputeSecurityPolicy#adaptive_protection_config}
    */
    readonly adaptiveProtectionConfig?: ComputeSecurityPolicyAdaptiveProtectionConfig;
    /**
    * advanced_options_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#advanced_options_config ComputeSecurityPolicy#advanced_options_config}
    */
    readonly advancedOptionsConfig?: ComputeSecurityPolicyAdvancedOptionsConfig;
    /**
    * recaptcha_options_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#recaptcha_options_config ComputeSecurityPolicy#recaptcha_options_config}
    */
    readonly recaptchaOptionsConfig?: ComputeSecurityPolicyRecaptchaOptionsConfig;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#rule ComputeSecurityPolicy#rule}
    */
    readonly rule?: ComputeSecurityPolicyRule[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#timeouts ComputeSecurityPolicy#timeouts}
    */
    readonly timeouts?: ComputeSecurityPolicyTimeouts;
}
export interface ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsTrafficGranularityConfigs {
    /**
    * If enabled, traffic matching each unique value for the specified type constitutes a separate traffic unit. It can only be set to true if value is empty.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#enable_each_unique_value ComputeSecurityPolicy#enable_each_unique_value}
    */
    readonly enableEachUniqueValue?: boolean | cdktn.IResolvable;
    /**
    * Type of this configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#type ComputeSecurityPolicy#type}
    */
    readonly type: string;
    /**
    * Requests that match this value constitute a granular traffic unit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#value ComputeSecurityPolicy#value}
    */
    readonly value?: string;
}
export declare function computeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsTrafficGranularityConfigsToTerraform(struct?: ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsTrafficGranularityConfigs | cdktn.IResolvable): any;
export declare function computeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsTrafficGranularityConfigsToHclTerraform(struct?: ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsTrafficGranularityConfigs | cdktn.IResolvable): any;
export declare class ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsTrafficGranularityConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsTrafficGranularityConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsTrafficGranularityConfigs | cdktn.IResolvable | undefined);
    private _enableEachUniqueValue?;
    get enableEachUniqueValue(): boolean | cdktn.IResolvable;
    set enableEachUniqueValue(value: boolean | cdktn.IResolvable);
    resetEnableEachUniqueValue(): void;
    get enableEachUniqueValueInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsTrafficGranularityConfigsList extends cdktn.ComplexList {
    internalValue?: ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsTrafficGranularityConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsTrafficGranularityConfigsOutputReference;
}
export interface ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#auto_deploy_confidence_threshold ComputeSecurityPolicy#auto_deploy_confidence_threshold}
    */
    readonly autoDeployConfidenceThreshold?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#auto_deploy_expiration_sec ComputeSecurityPolicy#auto_deploy_expiration_sec}
    */
    readonly autoDeployExpirationSec?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#auto_deploy_impacted_baseline_threshold ComputeSecurityPolicy#auto_deploy_impacted_baseline_threshold}
    */
    readonly autoDeployImpactedBaselineThreshold?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#auto_deploy_load_threshold ComputeSecurityPolicy#auto_deploy_load_threshold}
    */
    readonly autoDeployLoadThreshold?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#detection_absolute_qps ComputeSecurityPolicy#detection_absolute_qps}
    */
    readonly detectionAbsoluteQps?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#detection_load_threshold ComputeSecurityPolicy#detection_load_threshold}
    */
    readonly detectionLoadThreshold?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#detection_relative_to_baseline_qps ComputeSecurityPolicy#detection_relative_to_baseline_qps}
    */
    readonly detectionRelativeToBaselineQps?: number;
    /**
    * The name must be 1-63 characters long, and comply with RFC1035. The name must be unique within the security policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#name ComputeSecurityPolicy#name}
    */
    readonly name: string;
    /**
    * traffic_granularity_configs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#traffic_granularity_configs ComputeSecurityPolicy#traffic_granularity_configs}
    */
    readonly trafficGranularityConfigs?: ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsTrafficGranularityConfigs[] | cdktn.IResolvable;
}
export declare function computeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsToTerraform(struct?: ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigs | cdktn.IResolvable): any;
export declare function computeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsToHclTerraform(struct?: ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigs | cdktn.IResolvable): any;
export declare class ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigs | cdktn.IResolvable | undefined);
    private _autoDeployConfidenceThreshold?;
    get autoDeployConfidenceThreshold(): number;
    set autoDeployConfidenceThreshold(value: number);
    resetAutoDeployConfidenceThreshold(): void;
    get autoDeployConfidenceThresholdInput(): number | undefined;
    private _autoDeployExpirationSec?;
    get autoDeployExpirationSec(): number;
    set autoDeployExpirationSec(value: number);
    resetAutoDeployExpirationSec(): void;
    get autoDeployExpirationSecInput(): number | undefined;
    private _autoDeployImpactedBaselineThreshold?;
    get autoDeployImpactedBaselineThreshold(): number;
    set autoDeployImpactedBaselineThreshold(value: number);
    resetAutoDeployImpactedBaselineThreshold(): void;
    get autoDeployImpactedBaselineThresholdInput(): number | undefined;
    private _autoDeployLoadThreshold?;
    get autoDeployLoadThreshold(): number;
    set autoDeployLoadThreshold(value: number);
    resetAutoDeployLoadThreshold(): void;
    get autoDeployLoadThresholdInput(): number | undefined;
    private _detectionAbsoluteQps?;
    get detectionAbsoluteQps(): number;
    set detectionAbsoluteQps(value: number);
    resetDetectionAbsoluteQps(): void;
    get detectionAbsoluteQpsInput(): number | undefined;
    private _detectionLoadThreshold?;
    get detectionLoadThreshold(): number;
    set detectionLoadThreshold(value: number);
    resetDetectionLoadThreshold(): void;
    get detectionLoadThresholdInput(): number | undefined;
    private _detectionRelativeToBaselineQps?;
    get detectionRelativeToBaselineQps(): number;
    set detectionRelativeToBaselineQps(value: number);
    resetDetectionRelativeToBaselineQps(): void;
    get detectionRelativeToBaselineQpsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _trafficGranularityConfigs;
    get trafficGranularityConfigs(): ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsTrafficGranularityConfigsList;
    putTrafficGranularityConfigs(value: ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsTrafficGranularityConfigs[] | cdktn.IResolvable): void;
    resetTrafficGranularityConfigs(): void;
    get trafficGranularityConfigsInput(): cdktn.IResolvable | ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsTrafficGranularityConfigs[] | undefined;
}
export declare class ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsList extends cdktn.ComplexList {
    internalValue?: ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsOutputReference;
}
export interface ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfig {
    /**
    * If set to true, enables CAAP for L7 DDoS detection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#enable ComputeSecurityPolicy#enable}
    */
    readonly enable?: boolean | cdktn.IResolvable;
    /**
    * Rule visibility. Supported values include: "STANDARD", "PREMIUM".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#rule_visibility ComputeSecurityPolicy#rule_visibility}
    */
    readonly ruleVisibility?: string;
    /**
    * threshold_configs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#threshold_configs ComputeSecurityPolicy#threshold_configs}
    */
    readonly thresholdConfigs?: ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigs[] | cdktn.IResolvable;
}
export declare function computeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigToTerraform(struct?: ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigOutputReference | ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfig): any;
export declare function computeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigToHclTerraform(struct?: ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigOutputReference | ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfig): any;
export declare class ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfig | undefined;
    set internalValue(value: ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfig | undefined);
    private _enable?;
    get enable(): boolean | cdktn.IResolvable;
    set enable(value: boolean | cdktn.IResolvable);
    resetEnable(): void;
    get enableInput(): boolean | cdktn.IResolvable | undefined;
    private _ruleVisibility?;
    get ruleVisibility(): string;
    set ruleVisibility(value: string);
    resetRuleVisibility(): void;
    get ruleVisibilityInput(): string | undefined;
    private _thresholdConfigs;
    get thresholdConfigs(): ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsList;
    putThresholdConfigs(value: ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigs[] | cdktn.IResolvable): void;
    resetThresholdConfigs(): void;
    get thresholdConfigsInput(): cdktn.IResolvable | ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigs[] | undefined;
}
export interface ComputeSecurityPolicyAdaptiveProtectionConfig {
    /**
    * layer_7_ddos_defense_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#layer_7_ddos_defense_config ComputeSecurityPolicy#layer_7_ddos_defense_config}
    */
    readonly layer7DdosDefenseConfig?: ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfig;
}
export declare function computeSecurityPolicyAdaptiveProtectionConfigToTerraform(struct?: ComputeSecurityPolicyAdaptiveProtectionConfigOutputReference | ComputeSecurityPolicyAdaptiveProtectionConfig): any;
export declare function computeSecurityPolicyAdaptiveProtectionConfigToHclTerraform(struct?: ComputeSecurityPolicyAdaptiveProtectionConfigOutputReference | ComputeSecurityPolicyAdaptiveProtectionConfig): any;
export declare class ComputeSecurityPolicyAdaptiveProtectionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyAdaptiveProtectionConfig | undefined;
    set internalValue(value: ComputeSecurityPolicyAdaptiveProtectionConfig | undefined);
    private _layer7DdosDefenseConfig;
    get layer7DdosDefenseConfig(): ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigOutputReference;
    putLayer7DdosDefenseConfig(value: ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfig): void;
    resetLayer7DdosDefenseConfig(): void;
    get layer7DdosDefenseConfigInput(): ComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfig | undefined;
}
export interface ComputeSecurityPolicyAdvancedOptionsConfigJsonCustomConfig {
    /**
    * A list of custom Content-Type header values to apply the JSON parsing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#content_types ComputeSecurityPolicy#content_types}
    */
    readonly contentTypes: string[];
}
export declare function computeSecurityPolicyAdvancedOptionsConfigJsonCustomConfigToTerraform(struct?: ComputeSecurityPolicyAdvancedOptionsConfigJsonCustomConfigOutputReference | ComputeSecurityPolicyAdvancedOptionsConfigJsonCustomConfig): any;
export declare function computeSecurityPolicyAdvancedOptionsConfigJsonCustomConfigToHclTerraform(struct?: ComputeSecurityPolicyAdvancedOptionsConfigJsonCustomConfigOutputReference | ComputeSecurityPolicyAdvancedOptionsConfigJsonCustomConfig): any;
export declare class ComputeSecurityPolicyAdvancedOptionsConfigJsonCustomConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyAdvancedOptionsConfigJsonCustomConfig | undefined;
    set internalValue(value: ComputeSecurityPolicyAdvancedOptionsConfigJsonCustomConfig | undefined);
    private _contentTypes?;
    get contentTypes(): string[];
    set contentTypes(value: string[]);
    get contentTypesInput(): string[] | undefined;
}
export interface ComputeSecurityPolicyAdvancedOptionsConfig {
    /**
    * JSON body parsing. Supported values include: "DISABLED", "STANDARD".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#json_parsing ComputeSecurityPolicy#json_parsing}
    */
    readonly jsonParsing?: string;
    /**
    * Logging level. Supported values include: "NORMAL", "VERBOSE".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#log_level ComputeSecurityPolicy#log_level}
    */
    readonly logLevel?: string;
    /**
    * The maximum request size chosen by the customer with Waf enabled. Values supported are "8KB", "16KB, "32KB", "48KB" and "64KB". Values are case insensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#request_body_inspection_size ComputeSecurityPolicy#request_body_inspection_size}
    */
    readonly requestBodyInspectionSize?: string;
    /**
    * An optional list of case-insensitive request header names to use for resolving the callers client IP address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#user_ip_request_headers ComputeSecurityPolicy#user_ip_request_headers}
    */
    readonly userIpRequestHeaders?: string[];
    /**
    * json_custom_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#json_custom_config ComputeSecurityPolicy#json_custom_config}
    */
    readonly jsonCustomConfig?: ComputeSecurityPolicyAdvancedOptionsConfigJsonCustomConfig;
}
export declare function computeSecurityPolicyAdvancedOptionsConfigToTerraform(struct?: ComputeSecurityPolicyAdvancedOptionsConfigOutputReference | ComputeSecurityPolicyAdvancedOptionsConfig): any;
export declare function computeSecurityPolicyAdvancedOptionsConfigToHclTerraform(struct?: ComputeSecurityPolicyAdvancedOptionsConfigOutputReference | ComputeSecurityPolicyAdvancedOptionsConfig): any;
export declare class ComputeSecurityPolicyAdvancedOptionsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyAdvancedOptionsConfig | undefined;
    set internalValue(value: ComputeSecurityPolicyAdvancedOptionsConfig | undefined);
    private _jsonParsing?;
    get jsonParsing(): string;
    set jsonParsing(value: string);
    resetJsonParsing(): void;
    get jsonParsingInput(): string | undefined;
    private _logLevel?;
    get logLevel(): string;
    set logLevel(value: string);
    resetLogLevel(): void;
    get logLevelInput(): string | undefined;
    private _requestBodyInspectionSize?;
    get requestBodyInspectionSize(): string;
    set requestBodyInspectionSize(value: string);
    resetRequestBodyInspectionSize(): void;
    get requestBodyInspectionSizeInput(): string | undefined;
    private _userIpRequestHeaders?;
    get userIpRequestHeaders(): string[];
    set userIpRequestHeaders(value: string[]);
    resetUserIpRequestHeaders(): void;
    get userIpRequestHeadersInput(): string[] | undefined;
    private _jsonCustomConfig;
    get jsonCustomConfig(): ComputeSecurityPolicyAdvancedOptionsConfigJsonCustomConfigOutputReference;
    putJsonCustomConfig(value: ComputeSecurityPolicyAdvancedOptionsConfigJsonCustomConfig): void;
    resetJsonCustomConfig(): void;
    get jsonCustomConfigInput(): ComputeSecurityPolicyAdvancedOptionsConfigJsonCustomConfig | undefined;
}
export interface ComputeSecurityPolicyRecaptchaOptionsConfig {
    /**
    * A field to supply a reCAPTCHA site key to be used for all the rules using the redirect action with the type of GOOGLE_RECAPTCHA under the security policy. The specified site key needs to be created from the reCAPTCHA API. The user is responsible for the validity of the specified site key. If not specified, a Google-managed site key is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#redirect_site_key ComputeSecurityPolicy#redirect_site_key}
    */
    readonly redirectSiteKey: string;
}
export declare function computeSecurityPolicyRecaptchaOptionsConfigToTerraform(struct?: ComputeSecurityPolicyRecaptchaOptionsConfigOutputReference | ComputeSecurityPolicyRecaptchaOptionsConfig): any;
export declare function computeSecurityPolicyRecaptchaOptionsConfigToHclTerraform(struct?: ComputeSecurityPolicyRecaptchaOptionsConfigOutputReference | ComputeSecurityPolicyRecaptchaOptionsConfig): any;
export declare class ComputeSecurityPolicyRecaptchaOptionsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyRecaptchaOptionsConfig | undefined;
    set internalValue(value: ComputeSecurityPolicyRecaptchaOptionsConfig | undefined);
    private _redirectSiteKey?;
    get redirectSiteKey(): string;
    set redirectSiteKey(value: string);
    get redirectSiteKeyInput(): string | undefined;
}
export interface ComputeSecurityPolicyRuleHeaderActionRequestHeadersToAdds {
    /**
    * The name of the header to set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#header_name ComputeSecurityPolicy#header_name}
    */
    readonly headerName: string;
    /**
    * The value to set the named header to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#header_value ComputeSecurityPolicy#header_value}
    */
    readonly headerValue?: string;
}
export declare function computeSecurityPolicyRuleHeaderActionRequestHeadersToAddsToTerraform(struct?: ComputeSecurityPolicyRuleHeaderActionRequestHeadersToAdds | cdktn.IResolvable): any;
export declare function computeSecurityPolicyRuleHeaderActionRequestHeadersToAddsToHclTerraform(struct?: ComputeSecurityPolicyRuleHeaderActionRequestHeadersToAdds | cdktn.IResolvable): any;
export declare class ComputeSecurityPolicyRuleHeaderActionRequestHeadersToAddsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeSecurityPolicyRuleHeaderActionRequestHeadersToAdds | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeSecurityPolicyRuleHeaderActionRequestHeadersToAdds | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    get headerNameInput(): string | undefined;
    private _headerValue?;
    get headerValue(): string;
    set headerValue(value: string);
    resetHeaderValue(): void;
    get headerValueInput(): string | undefined;
}
export declare class ComputeSecurityPolicyRuleHeaderActionRequestHeadersToAddsList extends cdktn.ComplexList {
    internalValue?: ComputeSecurityPolicyRuleHeaderActionRequestHeadersToAdds[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeSecurityPolicyRuleHeaderActionRequestHeadersToAddsOutputReference;
}
export interface ComputeSecurityPolicyRuleHeaderAction {
    /**
    * request_headers_to_adds block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#request_headers_to_adds ComputeSecurityPolicy#request_headers_to_adds}
    */
    readonly requestHeadersToAdds: ComputeSecurityPolicyRuleHeaderActionRequestHeadersToAdds[] | cdktn.IResolvable;
}
export declare function computeSecurityPolicyRuleHeaderActionToTerraform(struct?: ComputeSecurityPolicyRuleHeaderActionOutputReference | ComputeSecurityPolicyRuleHeaderAction): any;
export declare function computeSecurityPolicyRuleHeaderActionToHclTerraform(struct?: ComputeSecurityPolicyRuleHeaderActionOutputReference | ComputeSecurityPolicyRuleHeaderAction): any;
export declare class ComputeSecurityPolicyRuleHeaderActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyRuleHeaderAction | undefined;
    set internalValue(value: ComputeSecurityPolicyRuleHeaderAction | undefined);
    private _requestHeadersToAdds;
    get requestHeadersToAdds(): ComputeSecurityPolicyRuleHeaderActionRequestHeadersToAddsList;
    putRequestHeadersToAdds(value: ComputeSecurityPolicyRuleHeaderActionRequestHeadersToAdds[] | cdktn.IResolvable): void;
    get requestHeadersToAddsInput(): cdktn.IResolvable | ComputeSecurityPolicyRuleHeaderActionRequestHeadersToAdds[] | undefined;
}
export interface ComputeSecurityPolicyRuleMatchConfig {
    /**
    * Set of IP addresses or ranges (IPV4 or IPV6) in CIDR notation to match against inbound traffic. There is a limit of 10 IP ranges per rule. A value of '*' matches all IPs (can be used to override the default behavior).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#src_ip_ranges ComputeSecurityPolicy#src_ip_ranges}
    */
    readonly srcIpRanges: string[];
}
export declare function computeSecurityPolicyRuleMatchConfigToTerraform(struct?: ComputeSecurityPolicyRuleMatchConfigOutputReference | ComputeSecurityPolicyRuleMatchConfig): any;
export declare function computeSecurityPolicyRuleMatchConfigToHclTerraform(struct?: ComputeSecurityPolicyRuleMatchConfigOutputReference | ComputeSecurityPolicyRuleMatchConfig): any;
export declare class ComputeSecurityPolicyRuleMatchConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyRuleMatchConfig | undefined;
    set internalValue(value: ComputeSecurityPolicyRuleMatchConfig | undefined);
    private _srcIpRanges?;
    get srcIpRanges(): string[];
    set srcIpRanges(value: string[]);
    get srcIpRangesInput(): string[] | undefined;
}
export interface ComputeSecurityPolicyRuleMatchExpr {
    /**
    * Textual representation of an expression in Common Expression Language syntax. The application context of the containing message determines which well-known feature set of CEL is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#expression ComputeSecurityPolicy#expression}
    */
    readonly expression: string;
}
export declare function computeSecurityPolicyRuleMatchExprToTerraform(struct?: ComputeSecurityPolicyRuleMatchExprOutputReference | ComputeSecurityPolicyRuleMatchExpr): any;
export declare function computeSecurityPolicyRuleMatchExprToHclTerraform(struct?: ComputeSecurityPolicyRuleMatchExprOutputReference | ComputeSecurityPolicyRuleMatchExpr): any;
export declare class ComputeSecurityPolicyRuleMatchExprOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyRuleMatchExpr | undefined;
    set internalValue(value: ComputeSecurityPolicyRuleMatchExpr | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
}
export interface ComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptions {
    /**
    * A list of site keys to be used during the validation of reCAPTCHA action-tokens. The provided site keys need to be created from reCAPTCHA API under the same project where the security policy is created
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#action_token_site_keys ComputeSecurityPolicy#action_token_site_keys}
    */
    readonly actionTokenSiteKeys?: string[];
    /**
    * A list of site keys to be used during the validation of reCAPTCHA session-tokens. The provided site keys need to be created from reCAPTCHA API under the same project where the security policy is created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#session_token_site_keys ComputeSecurityPolicy#session_token_site_keys}
    */
    readonly sessionTokenSiteKeys?: string[];
}
export declare function computeSecurityPolicyRuleMatchExprOptionsRecaptchaOptionsToTerraform(struct?: ComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptionsOutputReference | ComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptions): any;
export declare function computeSecurityPolicyRuleMatchExprOptionsRecaptchaOptionsToHclTerraform(struct?: ComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptionsOutputReference | ComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptions): any;
export declare class ComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptions | undefined;
    set internalValue(value: ComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptions | undefined);
    private _actionTokenSiteKeys?;
    get actionTokenSiteKeys(): string[];
    set actionTokenSiteKeys(value: string[]);
    resetActionTokenSiteKeys(): void;
    get actionTokenSiteKeysInput(): string[] | undefined;
    private _sessionTokenSiteKeys?;
    get sessionTokenSiteKeys(): string[];
    set sessionTokenSiteKeys(value: string[]);
    resetSessionTokenSiteKeys(): void;
    get sessionTokenSiteKeysInput(): string[] | undefined;
}
export interface ComputeSecurityPolicyRuleMatchExprOptions {
    /**
    * recaptcha_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#recaptcha_options ComputeSecurityPolicy#recaptcha_options}
    */
    readonly recaptchaOptions: ComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptions;
}
export declare function computeSecurityPolicyRuleMatchExprOptionsToTerraform(struct?: ComputeSecurityPolicyRuleMatchExprOptionsOutputReference | ComputeSecurityPolicyRuleMatchExprOptions): any;
export declare function computeSecurityPolicyRuleMatchExprOptionsToHclTerraform(struct?: ComputeSecurityPolicyRuleMatchExprOptionsOutputReference | ComputeSecurityPolicyRuleMatchExprOptions): any;
export declare class ComputeSecurityPolicyRuleMatchExprOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyRuleMatchExprOptions | undefined;
    set internalValue(value: ComputeSecurityPolicyRuleMatchExprOptions | undefined);
    private _recaptchaOptions;
    get recaptchaOptions(): ComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptionsOutputReference;
    putRecaptchaOptions(value: ComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptions): void;
    get recaptchaOptionsInput(): ComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptions | undefined;
}
export interface ComputeSecurityPolicyRuleMatch {
    /**
    * Predefined rule expression. If this field is specified, config must also be specified. Available options:   SRC_IPS_V1: Must specify the corresponding src_ip_ranges field in config.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#versioned_expr ComputeSecurityPolicy#versioned_expr}
    */
    readonly versionedExpr?: string;
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#config ComputeSecurityPolicy#config}
    */
    readonly config?: ComputeSecurityPolicyRuleMatchConfig;
    /**
    * expr block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#expr ComputeSecurityPolicy#expr}
    */
    readonly expr?: ComputeSecurityPolicyRuleMatchExpr;
    /**
    * expr_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#expr_options ComputeSecurityPolicy#expr_options}
    */
    readonly exprOptions?: ComputeSecurityPolicyRuleMatchExprOptions;
}
export declare function computeSecurityPolicyRuleMatchToTerraform(struct?: ComputeSecurityPolicyRuleMatchOutputReference | ComputeSecurityPolicyRuleMatch): any;
export declare function computeSecurityPolicyRuleMatchToHclTerraform(struct?: ComputeSecurityPolicyRuleMatchOutputReference | ComputeSecurityPolicyRuleMatch): any;
export declare class ComputeSecurityPolicyRuleMatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyRuleMatch | undefined;
    set internalValue(value: ComputeSecurityPolicyRuleMatch | undefined);
    private _versionedExpr?;
    get versionedExpr(): string;
    set versionedExpr(value: string);
    resetVersionedExpr(): void;
    get versionedExprInput(): string | undefined;
    private _config;
    get config(): ComputeSecurityPolicyRuleMatchConfigOutputReference;
    putConfig(value: ComputeSecurityPolicyRuleMatchConfig): void;
    resetConfig(): void;
    get configInput(): ComputeSecurityPolicyRuleMatchConfig | undefined;
    private _expr;
    get expr(): ComputeSecurityPolicyRuleMatchExprOutputReference;
    putExpr(value: ComputeSecurityPolicyRuleMatchExpr): void;
    resetExpr(): void;
    get exprInput(): ComputeSecurityPolicyRuleMatchExpr | undefined;
    private _exprOptions;
    get exprOptions(): ComputeSecurityPolicyRuleMatchExprOptionsOutputReference;
    putExprOptions(value: ComputeSecurityPolicyRuleMatchExprOptions): void;
    resetExprOptions(): void;
    get exprOptionsInput(): ComputeSecurityPolicyRuleMatchExprOptions | undefined;
}
export interface ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie {
    /**
    * You can specify an exact match or a partial match by using a field operator and a field value. Available options: EQUALS: The operator matches if the field value equals the specified value. STARTS_WITH: The operator matches if the field value starts with the specified value. ENDS_WITH: The operator matches if the field value ends with the specified value. CONTAINS: The operator matches if the field value contains the specified value. EQUALS_ANY: The operator matches if the field value is any value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#operator ComputeSecurityPolicy#operator}
    */
    readonly operator: string;
    /**
    * A request field matching the specified value will be excluded from inspection during preconfigured WAF evaluation. The field value must be given if the field operator is not EQUALS_ANY, and cannot be given if the field operator is EQUALS_ANY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#value ComputeSecurityPolicy#value}
    */
    readonly value?: string;
}
export declare function computeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieToTerraform(struct?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie | cdktn.IResolvable): any;
export declare function computeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieToHclTerraform(struct?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie | cdktn.IResolvable): any;
export declare class ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieList extends cdktn.ComplexList {
    internalValue?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieOutputReference;
}
export interface ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader {
    /**
    * You can specify an exact match or a partial match by using a field operator and a field value. Available options: EQUALS: The operator matches if the field value equals the specified value. STARTS_WITH: The operator matches if the field value starts with the specified value. ENDS_WITH: The operator matches if the field value ends with the specified value. CONTAINS: The operator matches if the field value contains the specified value. EQUALS_ANY: The operator matches if the field value is any value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#operator ComputeSecurityPolicy#operator}
    */
    readonly operator: string;
    /**
    * A request field matching the specified value will be excluded from inspection during preconfigured WAF evaluation. The field value must be given if the field operator is not EQUALS_ANY, and cannot be given if the field operator is EQUALS_ANY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#value ComputeSecurityPolicy#value}
    */
    readonly value?: string;
}
export declare function computeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderToTerraform(struct?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader | cdktn.IResolvable): any;
export declare function computeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderToHclTerraform(struct?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader | cdktn.IResolvable): any;
export declare class ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderList extends cdktn.ComplexList {
    internalValue?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderOutputReference;
}
export interface ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam {
    /**
    * You can specify an exact match or a partial match by using a field operator and a field value. Available options: EQUALS: The operator matches if the field value equals the specified value. STARTS_WITH: The operator matches if the field value starts with the specified value. ENDS_WITH: The operator matches if the field value ends with the specified value. CONTAINS: The operator matches if the field value contains the specified value. EQUALS_ANY: The operator matches if the field value is any value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#operator ComputeSecurityPolicy#operator}
    */
    readonly operator: string;
    /**
    * A request field matching the specified value will be excluded from inspection during preconfigured WAF evaluation. The field value must be given if the field operator is not EQUALS_ANY, and cannot be given if the field operator is EQUALS_ANY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#value ComputeSecurityPolicy#value}
    */
    readonly value?: string;
}
export declare function computeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamToTerraform(struct?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam | cdktn.IResolvable): any;
export declare function computeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamToHclTerraform(struct?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam | cdktn.IResolvable): any;
export declare class ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamList extends cdktn.ComplexList {
    internalValue?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamOutputReference;
}
export interface ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri {
    /**
    * You can specify an exact match or a partial match by using a field operator and a field value. Available options: EQUALS: The operator matches if the field value equals the specified value. STARTS_WITH: The operator matches if the field value starts with the specified value. ENDS_WITH: The operator matches if the field value ends with the specified value. CONTAINS: The operator matches if the field value contains the specified value. EQUALS_ANY: The operator matches if the field value is any value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#operator ComputeSecurityPolicy#operator}
    */
    readonly operator: string;
    /**
    * A request field matching the specified value will be excluded from inspection during preconfigured WAF evaluation. The field value must be given if the field operator is not EQUALS_ANY, and cannot be given if the field operator is EQUALS_ANY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#value ComputeSecurityPolicy#value}
    */
    readonly value?: string;
}
export declare function computeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriToTerraform(struct?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri | cdktn.IResolvable): any;
export declare function computeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriToHclTerraform(struct?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri | cdktn.IResolvable): any;
export declare class ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriList extends cdktn.ComplexList {
    internalValue?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriOutputReference;
}
export interface ComputeSecurityPolicyRulePreconfiguredWafConfigExclusion {
    /**
    * A list of target rule IDs under the WAF rule set to apply the preconfigured WAF exclusion. If omitted, it refers to all the rule IDs under the WAF rule set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#target_rule_ids ComputeSecurityPolicy#target_rule_ids}
    */
    readonly targetRuleIds?: string[];
    /**
    * Target WAF rule set to apply the preconfigured WAF exclusion.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#target_rule_set ComputeSecurityPolicy#target_rule_set}
    */
    readonly targetRuleSet: string;
    /**
    * request_cookie block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#request_cookie ComputeSecurityPolicy#request_cookie}
    */
    readonly requestCookie?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie[] | cdktn.IResolvable;
    /**
    * request_header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#request_header ComputeSecurityPolicy#request_header}
    */
    readonly requestHeader?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader[] | cdktn.IResolvable;
    /**
    * request_query_param block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#request_query_param ComputeSecurityPolicy#request_query_param}
    */
    readonly requestQueryParam?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam[] | cdktn.IResolvable;
    /**
    * request_uri block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#request_uri ComputeSecurityPolicy#request_uri}
    */
    readonly requestUri?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri[] | cdktn.IResolvable;
}
export declare function computeSecurityPolicyRulePreconfiguredWafConfigExclusionToTerraform(struct?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusion | cdktn.IResolvable): any;
export declare function computeSecurityPolicyRulePreconfiguredWafConfigExclusionToHclTerraform(struct?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusion | cdktn.IResolvable): any;
export declare class ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusion | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusion | cdktn.IResolvable | undefined);
    private _targetRuleIds?;
    get targetRuleIds(): string[];
    set targetRuleIds(value: string[]);
    resetTargetRuleIds(): void;
    get targetRuleIdsInput(): string[] | undefined;
    private _targetRuleSet?;
    get targetRuleSet(): string;
    set targetRuleSet(value: string);
    get targetRuleSetInput(): string | undefined;
    private _requestCookie;
    get requestCookie(): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieList;
    putRequestCookie(value: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie[] | cdktn.IResolvable): void;
    resetRequestCookie(): void;
    get requestCookieInput(): cdktn.IResolvable | ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie[] | undefined;
    private _requestHeader;
    get requestHeader(): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderList;
    putRequestHeader(value: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader[] | cdktn.IResolvable): void;
    resetRequestHeader(): void;
    get requestHeaderInput(): cdktn.IResolvable | ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader[] | undefined;
    private _requestQueryParam;
    get requestQueryParam(): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamList;
    putRequestQueryParam(value: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam[] | cdktn.IResolvable): void;
    resetRequestQueryParam(): void;
    get requestQueryParamInput(): cdktn.IResolvable | ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam[] | undefined;
    private _requestUri;
    get requestUri(): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriList;
    putRequestUri(value: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri[] | cdktn.IResolvable): void;
    resetRequestUri(): void;
    get requestUriInput(): cdktn.IResolvable | ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri[] | undefined;
}
export declare class ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionList extends cdktn.ComplexList {
    internalValue?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusion[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionOutputReference;
}
export interface ComputeSecurityPolicyRulePreconfiguredWafConfig {
    /**
    * exclusion block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#exclusion ComputeSecurityPolicy#exclusion}
    */
    readonly exclusion?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusion[] | cdktn.IResolvable;
}
export declare function computeSecurityPolicyRulePreconfiguredWafConfigToTerraform(struct?: ComputeSecurityPolicyRulePreconfiguredWafConfigOutputReference | ComputeSecurityPolicyRulePreconfiguredWafConfig): any;
export declare function computeSecurityPolicyRulePreconfiguredWafConfigToHclTerraform(struct?: ComputeSecurityPolicyRulePreconfiguredWafConfigOutputReference | ComputeSecurityPolicyRulePreconfiguredWafConfig): any;
export declare class ComputeSecurityPolicyRulePreconfiguredWafConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyRulePreconfiguredWafConfig | undefined;
    set internalValue(value: ComputeSecurityPolicyRulePreconfiguredWafConfig | undefined);
    private _exclusion;
    get exclusion(): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionList;
    putExclusion(value: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusion[] | cdktn.IResolvable): void;
    resetExclusion(): void;
    get exclusionInput(): cdktn.IResolvable | ComputeSecurityPolicyRulePreconfiguredWafConfigExclusion[] | undefined;
}
export interface ComputeSecurityPolicyRuleRateLimitOptionsBanThreshold {
    /**
    * Number of HTTP(S) requests for calculating the threshold.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#count ComputeSecurityPolicy#count}
    */
    readonly count: number;
    /**
    * Interval over which the threshold is computed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#interval_sec ComputeSecurityPolicy#interval_sec}
    */
    readonly intervalSec: number;
}
export declare function computeSecurityPolicyRuleRateLimitOptionsBanThresholdToTerraform(struct?: ComputeSecurityPolicyRuleRateLimitOptionsBanThresholdOutputReference | ComputeSecurityPolicyRuleRateLimitOptionsBanThreshold): any;
export declare function computeSecurityPolicyRuleRateLimitOptionsBanThresholdToHclTerraform(struct?: ComputeSecurityPolicyRuleRateLimitOptionsBanThresholdOutputReference | ComputeSecurityPolicyRuleRateLimitOptionsBanThreshold): any;
export declare class ComputeSecurityPolicyRuleRateLimitOptionsBanThresholdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyRuleRateLimitOptionsBanThreshold | undefined;
    set internalValue(value: ComputeSecurityPolicyRuleRateLimitOptionsBanThreshold | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    get countInput(): number | undefined;
    private _intervalSec?;
    get intervalSec(): number;
    set intervalSec(value: number);
    get intervalSecInput(): number | undefined;
}
export interface ComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigs {
    /**
    * Rate limit key name applicable only for the following key types: HTTP_HEADER -- Name of the HTTP header whose value is taken as the key value. HTTP_COOKIE -- Name of the HTTP cookie whose value is taken as the key value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#enforce_on_key_name ComputeSecurityPolicy#enforce_on_key_name}
    */
    readonly enforceOnKeyName?: string;
    /**
    * Determines the key to enforce the rate_limit_threshold on
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#enforce_on_key_type ComputeSecurityPolicy#enforce_on_key_type}
    */
    readonly enforceOnKeyType?: string;
}
export declare function computeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsToTerraform(struct?: ComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigs | cdktn.IResolvable): any;
export declare function computeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsToHclTerraform(struct?: ComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigs | cdktn.IResolvable): any;
export declare class ComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigs | cdktn.IResolvable | undefined);
    private _enforceOnKeyName?;
    get enforceOnKeyName(): string;
    set enforceOnKeyName(value: string);
    resetEnforceOnKeyName(): void;
    get enforceOnKeyNameInput(): string | undefined;
    private _enforceOnKeyType?;
    get enforceOnKeyType(): string;
    set enforceOnKeyType(value: string);
    resetEnforceOnKeyType(): void;
    get enforceOnKeyTypeInput(): string | undefined;
}
export declare class ComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsList extends cdktn.ComplexList {
    internalValue?: ComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsOutputReference;
}
export interface ComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptions {
    /**
    * Target for the redirect action. This is required if the type is EXTERNAL_302 and cannot be specified for GOOGLE_RECAPTCHA.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#target ComputeSecurityPolicy#target}
    */
    readonly target?: string;
    /**
    * Type of the redirect action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#type ComputeSecurityPolicy#type}
    */
    readonly type: string;
}
export declare function computeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptionsToTerraform(struct?: ComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptionsOutputReference | ComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptions): any;
export declare function computeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptionsToHclTerraform(struct?: ComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptionsOutputReference | ComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptions): any;
export declare class ComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptions | undefined;
    set internalValue(value: ComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptions | undefined);
    private _target?;
    get target(): string;
    set target(value: string);
    resetTarget(): void;
    get targetInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface ComputeSecurityPolicyRuleRateLimitOptionsRateLimitThreshold {
    /**
    * Number of HTTP(S) requests for calculating the threshold.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#count ComputeSecurityPolicy#count}
    */
    readonly count: number;
    /**
    * Interval over which the threshold is computed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#interval_sec ComputeSecurityPolicy#interval_sec}
    */
    readonly intervalSec: number;
}
export declare function computeSecurityPolicyRuleRateLimitOptionsRateLimitThresholdToTerraform(struct?: ComputeSecurityPolicyRuleRateLimitOptionsRateLimitThresholdOutputReference | ComputeSecurityPolicyRuleRateLimitOptionsRateLimitThreshold): any;
export declare function computeSecurityPolicyRuleRateLimitOptionsRateLimitThresholdToHclTerraform(struct?: ComputeSecurityPolicyRuleRateLimitOptionsRateLimitThresholdOutputReference | ComputeSecurityPolicyRuleRateLimitOptionsRateLimitThreshold): any;
export declare class ComputeSecurityPolicyRuleRateLimitOptionsRateLimitThresholdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyRuleRateLimitOptionsRateLimitThreshold | undefined;
    set internalValue(value: ComputeSecurityPolicyRuleRateLimitOptionsRateLimitThreshold | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    get countInput(): number | undefined;
    private _intervalSec?;
    get intervalSec(): number;
    set intervalSec(value: number);
    get intervalSecInput(): number | undefined;
}
export interface ComputeSecurityPolicyRuleRateLimitOptions {
    /**
    * Can only be specified if the action for the rule is "rate_based_ban". If specified, determines the time (in seconds) the traffic will continue to be banned by the rate limit after the rate falls below the threshold.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#ban_duration_sec ComputeSecurityPolicy#ban_duration_sec}
    */
    readonly banDurationSec?: number;
    /**
    * Action to take for requests that are under the configured rate limit threshold. Valid option is "allow" only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#conform_action ComputeSecurityPolicy#conform_action}
    */
    readonly conformAction: string;
    /**
    * Determines the key to enforce the rateLimitThreshold on
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#enforce_on_key ComputeSecurityPolicy#enforce_on_key}
    */
    readonly enforceOnKey?: string;
    /**
    * Rate limit key name applicable only for the following key types: HTTP_HEADER -- Name of the HTTP header whose value is taken as the key value. HTTP_COOKIE -- Name of the HTTP cookie whose value is taken as the key value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#enforce_on_key_name ComputeSecurityPolicy#enforce_on_key_name}
    */
    readonly enforceOnKeyName?: string;
    /**
    * Action to take for requests that are above the configured rate limit threshold, to either deny with a specified HTTP response code, or redirect to a different endpoint. Valid options are "deny()" where valid values for status are 403, 404, 429, and 502, and "redirect" where the redirect parameters come from exceedRedirectOptions below.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#exceed_action ComputeSecurityPolicy#exceed_action}
    */
    readonly exceedAction: string;
    /**
    * ban_threshold block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#ban_threshold ComputeSecurityPolicy#ban_threshold}
    */
    readonly banThreshold?: ComputeSecurityPolicyRuleRateLimitOptionsBanThreshold;
    /**
    * enforce_on_key_configs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#enforce_on_key_configs ComputeSecurityPolicy#enforce_on_key_configs}
    */
    readonly enforceOnKeyConfigs?: ComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigs[] | cdktn.IResolvable;
    /**
    * exceed_redirect_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#exceed_redirect_options ComputeSecurityPolicy#exceed_redirect_options}
    */
    readonly exceedRedirectOptions?: ComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptions;
    /**
    * rate_limit_threshold block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#rate_limit_threshold ComputeSecurityPolicy#rate_limit_threshold}
    */
    readonly rateLimitThreshold: ComputeSecurityPolicyRuleRateLimitOptionsRateLimitThreshold;
}
export declare function computeSecurityPolicyRuleRateLimitOptionsToTerraform(struct?: ComputeSecurityPolicyRuleRateLimitOptionsOutputReference | ComputeSecurityPolicyRuleRateLimitOptions): any;
export declare function computeSecurityPolicyRuleRateLimitOptionsToHclTerraform(struct?: ComputeSecurityPolicyRuleRateLimitOptionsOutputReference | ComputeSecurityPolicyRuleRateLimitOptions): any;
export declare class ComputeSecurityPolicyRuleRateLimitOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyRuleRateLimitOptions | undefined;
    set internalValue(value: ComputeSecurityPolicyRuleRateLimitOptions | undefined);
    private _banDurationSec?;
    get banDurationSec(): number;
    set banDurationSec(value: number);
    resetBanDurationSec(): void;
    get banDurationSecInput(): number | undefined;
    private _conformAction?;
    get conformAction(): string;
    set conformAction(value: string);
    get conformActionInput(): string | undefined;
    private _enforceOnKey?;
    get enforceOnKey(): string;
    set enforceOnKey(value: string);
    resetEnforceOnKey(): void;
    get enforceOnKeyInput(): string | undefined;
    private _enforceOnKeyName?;
    get enforceOnKeyName(): string;
    set enforceOnKeyName(value: string);
    resetEnforceOnKeyName(): void;
    get enforceOnKeyNameInput(): string | undefined;
    private _exceedAction?;
    get exceedAction(): string;
    set exceedAction(value: string);
    get exceedActionInput(): string | undefined;
    private _banThreshold;
    get banThreshold(): ComputeSecurityPolicyRuleRateLimitOptionsBanThresholdOutputReference;
    putBanThreshold(value: ComputeSecurityPolicyRuleRateLimitOptionsBanThreshold): void;
    resetBanThreshold(): void;
    get banThresholdInput(): ComputeSecurityPolicyRuleRateLimitOptionsBanThreshold | undefined;
    private _enforceOnKeyConfigs;
    get enforceOnKeyConfigs(): ComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsList;
    putEnforceOnKeyConfigs(value: ComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigs[] | cdktn.IResolvable): void;
    resetEnforceOnKeyConfigs(): void;
    get enforceOnKeyConfigsInput(): cdktn.IResolvable | ComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigs[] | undefined;
    private _exceedRedirectOptions;
    get exceedRedirectOptions(): ComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptionsOutputReference;
    putExceedRedirectOptions(value: ComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptions): void;
    resetExceedRedirectOptions(): void;
    get exceedRedirectOptionsInput(): ComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptions | undefined;
    private _rateLimitThreshold;
    get rateLimitThreshold(): ComputeSecurityPolicyRuleRateLimitOptionsRateLimitThresholdOutputReference;
    putRateLimitThreshold(value: ComputeSecurityPolicyRuleRateLimitOptionsRateLimitThreshold): void;
    get rateLimitThresholdInput(): ComputeSecurityPolicyRuleRateLimitOptionsRateLimitThreshold | undefined;
}
export interface ComputeSecurityPolicyRuleRedirectOptions {
    /**
    * Target for the redirect action. This is required if the type is EXTERNAL_302 and cannot be specified for GOOGLE_RECAPTCHA.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#target ComputeSecurityPolicy#target}
    */
    readonly target?: string;
    /**
    * Type of the redirect action. Available options: EXTERNAL_302: Must specify the corresponding target field in config. GOOGLE_RECAPTCHA: Cannot specify target field in config.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#type ComputeSecurityPolicy#type}
    */
    readonly type: string;
}
export declare function computeSecurityPolicyRuleRedirectOptionsToTerraform(struct?: ComputeSecurityPolicyRuleRedirectOptionsOutputReference | ComputeSecurityPolicyRuleRedirectOptions): any;
export declare function computeSecurityPolicyRuleRedirectOptionsToHclTerraform(struct?: ComputeSecurityPolicyRuleRedirectOptionsOutputReference | ComputeSecurityPolicyRuleRedirectOptions): any;
export declare class ComputeSecurityPolicyRuleRedirectOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyRuleRedirectOptions | undefined;
    set internalValue(value: ComputeSecurityPolicyRuleRedirectOptions | undefined);
    private _target?;
    get target(): string;
    set target(value: string);
    resetTarget(): void;
    get targetInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface ComputeSecurityPolicyRule {
    /**
    * Action to take when match matches the request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#action ComputeSecurityPolicy#action}
    */
    readonly action: string;
    /**
    * An optional description of this rule. Max size is 64.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#description ComputeSecurityPolicy#description}
    */
    readonly description?: string;
    /**
    * When set to true, the action specified above is not enforced. Stackdriver logs for requests that trigger a preview action are annotated as such.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#preview ComputeSecurityPolicy#preview}
    */
    readonly preview?: boolean | cdktn.IResolvable;
    /**
    * An unique positive integer indicating the priority of evaluation for a rule. Rules are evaluated from highest priority (lowest numerically) to lowest priority (highest numerically) in order.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#priority ComputeSecurityPolicy#priority}
    */
    readonly priority: number;
    /**
    * header_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#header_action ComputeSecurityPolicy#header_action}
    */
    readonly headerAction?: ComputeSecurityPolicyRuleHeaderAction;
    /**
    * match block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#match ComputeSecurityPolicy#match}
    */
    readonly match: ComputeSecurityPolicyRuleMatch;
    /**
    * preconfigured_waf_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#preconfigured_waf_config ComputeSecurityPolicy#preconfigured_waf_config}
    */
    readonly preconfiguredWafConfig?: ComputeSecurityPolicyRulePreconfiguredWafConfig;
    /**
    * rate_limit_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#rate_limit_options ComputeSecurityPolicy#rate_limit_options}
    */
    readonly rateLimitOptions?: ComputeSecurityPolicyRuleRateLimitOptions;
    /**
    * redirect_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#redirect_options ComputeSecurityPolicy#redirect_options}
    */
    readonly redirectOptions?: ComputeSecurityPolicyRuleRedirectOptions;
}
export declare function computeSecurityPolicyRuleToTerraform(struct?: ComputeSecurityPolicyRule | cdktn.IResolvable): any;
export declare function computeSecurityPolicyRuleToHclTerraform(struct?: ComputeSecurityPolicyRule | cdktn.IResolvable): any;
export declare class ComputeSecurityPolicyRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeSecurityPolicyRule | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeSecurityPolicyRule | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _preview?;
    get preview(): boolean | cdktn.IResolvable;
    set preview(value: boolean | cdktn.IResolvable);
    resetPreview(): void;
    get previewInput(): boolean | cdktn.IResolvable | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
    private _headerAction;
    get headerAction(): ComputeSecurityPolicyRuleHeaderActionOutputReference;
    putHeaderAction(value: ComputeSecurityPolicyRuleHeaderAction): void;
    resetHeaderAction(): void;
    get headerActionInput(): ComputeSecurityPolicyRuleHeaderAction | undefined;
    private _match;
    get match(): ComputeSecurityPolicyRuleMatchOutputReference;
    putMatch(value: ComputeSecurityPolicyRuleMatch): void;
    get matchInput(): ComputeSecurityPolicyRuleMatch | undefined;
    private _preconfiguredWafConfig;
    get preconfiguredWafConfig(): ComputeSecurityPolicyRulePreconfiguredWafConfigOutputReference;
    putPreconfiguredWafConfig(value: ComputeSecurityPolicyRulePreconfiguredWafConfig): void;
    resetPreconfiguredWafConfig(): void;
    get preconfiguredWafConfigInput(): ComputeSecurityPolicyRulePreconfiguredWafConfig | undefined;
    private _rateLimitOptions;
    get rateLimitOptions(): ComputeSecurityPolicyRuleRateLimitOptionsOutputReference;
    putRateLimitOptions(value: ComputeSecurityPolicyRuleRateLimitOptions): void;
    resetRateLimitOptions(): void;
    get rateLimitOptionsInput(): ComputeSecurityPolicyRuleRateLimitOptions | undefined;
    private _redirectOptions;
    get redirectOptions(): ComputeSecurityPolicyRuleRedirectOptionsOutputReference;
    putRedirectOptions(value: ComputeSecurityPolicyRuleRedirectOptions): void;
    resetRedirectOptions(): void;
    get redirectOptionsInput(): ComputeSecurityPolicyRuleRedirectOptions | undefined;
}
export declare class ComputeSecurityPolicyRuleList extends cdktn.ComplexList {
    internalValue?: ComputeSecurityPolicyRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeSecurityPolicyRuleOutputReference;
}
export interface ComputeSecurityPolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#create ComputeSecurityPolicy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#delete ComputeSecurityPolicy#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#update ComputeSecurityPolicy#update}
    */
    readonly update?: string;
}
export declare function computeSecurityPolicyTimeoutsToTerraform(struct?: ComputeSecurityPolicyTimeouts | cdktn.IResolvable): any;
export declare function computeSecurityPolicyTimeoutsToHclTerraform(struct?: ComputeSecurityPolicyTimeouts | cdktn.IResolvable): any;
export declare class ComputeSecurityPolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeSecurityPolicyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy google_compute_security_policy}
*/
export declare class ComputeSecurityPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_security_policy";
    /**
    * Generates CDKTN code for importing a ComputeSecurityPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeSecurityPolicy to import
    * @param importFromId The id of the existing ComputeSecurityPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeSecurityPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy google_compute_security_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeSecurityPolicyConfig
    */
    constructor(scope: Construct, id: string, config: ComputeSecurityPolicyConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get fingerprint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get labelFingerprint(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get selfLink(): string;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _adaptiveProtectionConfig;
    get adaptiveProtectionConfig(): ComputeSecurityPolicyAdaptiveProtectionConfigOutputReference;
    putAdaptiveProtectionConfig(value: ComputeSecurityPolicyAdaptiveProtectionConfig): void;
    resetAdaptiveProtectionConfig(): void;
    get adaptiveProtectionConfigInput(): ComputeSecurityPolicyAdaptiveProtectionConfig | undefined;
    private _advancedOptionsConfig;
    get advancedOptionsConfig(): ComputeSecurityPolicyAdvancedOptionsConfigOutputReference;
    putAdvancedOptionsConfig(value: ComputeSecurityPolicyAdvancedOptionsConfig): void;
    resetAdvancedOptionsConfig(): void;
    get advancedOptionsConfigInput(): ComputeSecurityPolicyAdvancedOptionsConfig | undefined;
    private _recaptchaOptionsConfig;
    get recaptchaOptionsConfig(): ComputeSecurityPolicyRecaptchaOptionsConfigOutputReference;
    putRecaptchaOptionsConfig(value: ComputeSecurityPolicyRecaptchaOptionsConfig): void;
    resetRecaptchaOptionsConfig(): void;
    get recaptchaOptionsConfigInput(): ComputeSecurityPolicyRecaptchaOptionsConfig | undefined;
    private _rule;
    get rule(): ComputeSecurityPolicyRuleList;
    putRule(value: ComputeSecurityPolicyRule[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | ComputeSecurityPolicyRule[] | undefined;
    private _timeouts;
    get timeouts(): ComputeSecurityPolicyTimeoutsOutputReference;
    putTimeouts(value: ComputeSecurityPolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeSecurityPolicyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
