/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChronicleNativeDashboardConfig extends cdktn.TerraformMetaArguments {
    /**
    * The access level of the dashboard.
    * Possible values:
    * DASHBOARD_PRIVATE
    * DASHBOARD_PUBLIC
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#access ChronicleNativeDashboard#access}
    */
    readonly access?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#deletion_policy ChronicleNativeDashboard#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * A description of the dashboard.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#description ChronicleNativeDashboard#description}
    */
    readonly description?: string;
    /**
    * The display name/title of the dashboard visible to users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#display_name ChronicleNativeDashboard#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#id ChronicleNativeDashboard#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the Chronicle instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#instance ChronicleNativeDashboard#instance}
    */
    readonly instance: string;
    /**
    * Whether the dashboard is pinned by the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#is_pinned ChronicleNativeDashboard#is_pinned}
    */
    readonly isPinned?: boolean | cdktn.IResolvable;
    /**
    * The location of the Chronicle instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#location ChronicleNativeDashboard#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#project ChronicleNativeDashboard#project}
    */
    readonly project?: string;
    /**
    * The type of dashboard.
    * Possible values:
    * CURATED, PRIVATE, PUBLIC, CUSTOM, MARKETPLACE
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#type ChronicleNativeDashboard#type}
    */
    readonly type?: string;
    /**
    * charts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#charts ChronicleNativeDashboard#charts}
    */
    readonly charts?: ChronicleNativeDashboardCharts[] | cdktn.IResolvable;
    /**
    * filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#filters ChronicleNativeDashboard#filters}
    */
    readonly filters?: ChronicleNativeDashboardFilters[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#timeouts ChronicleNativeDashboard#timeouts}
    */
    readonly timeouts?: ChronicleNativeDashboardTimeouts;
}
export interface ChronicleNativeDashboardChartsChartLayout {
    /**
    * The number of columns the chart spans.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#span_x ChronicleNativeDashboard#span_x}
    */
    readonly spanX: number;
    /**
    * The number of rows the chart spans.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#span_y ChronicleNativeDashboard#span_y}
    */
    readonly spanY: number;
    /**
    * The starting X coordinate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#start_x ChronicleNativeDashboard#start_x}
    */
    readonly startX?: number;
    /**
    * The starting Y coordinate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#start_y ChronicleNativeDashboard#start_y}
    */
    readonly startY?: number;
}
export declare function chronicleNativeDashboardChartsChartLayoutToTerraform(struct?: ChronicleNativeDashboardChartsChartLayoutOutputReference | ChronicleNativeDashboardChartsChartLayout): any;
export declare function chronicleNativeDashboardChartsChartLayoutToHclTerraform(struct?: ChronicleNativeDashboardChartsChartLayoutOutputReference | ChronicleNativeDashboardChartsChartLayout): any;
export declare class ChronicleNativeDashboardChartsChartLayoutOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleNativeDashboardChartsChartLayout | undefined;
    set internalValue(value: ChronicleNativeDashboardChartsChartLayout | undefined);
    private _spanX?;
    get spanX(): number;
    set spanX(value: number);
    get spanXInput(): number | undefined;
    private _spanY?;
    get spanY(): number;
    set spanY(value: number);
    get spanYInput(): number | undefined;
    private _startX?;
    get startX(): number;
    set startX(value: number);
    resetStartX(): void;
    get startXInput(): number | undefined;
    private _startY?;
    get startY(): number;
    set startY(value: number);
    resetStartY(): void;
    get startYInput(): number | undefined;
}
export interface ChronicleNativeDashboardCharts {
    /**
    * The resource name of the associated DashboardChart.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#dashboard_chart ChronicleNativeDashboard#dashboard_chart}
    */
    readonly dashboardChart?: string;
    /**
    * List of dashboard filter IDs applied to this chart.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#filters_ids ChronicleNativeDashboard#filters_ids}
    */
    readonly filtersIds?: string[];
    /**
    * chart_layout block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#chart_layout ChronicleNativeDashboard#chart_layout}
    */
    readonly chartLayout?: ChronicleNativeDashboardChartsChartLayout;
}
export declare function chronicleNativeDashboardChartsToTerraform(struct?: ChronicleNativeDashboardCharts | cdktn.IResolvable): any;
export declare function chronicleNativeDashboardChartsToHclTerraform(struct?: ChronicleNativeDashboardCharts | cdktn.IResolvable): any;
export declare class ChronicleNativeDashboardChartsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleNativeDashboardCharts | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleNativeDashboardCharts | cdktn.IResolvable | undefined);
    private _dashboardChart?;
    get dashboardChart(): string;
    set dashboardChart(value: string);
    resetDashboardChart(): void;
    get dashboardChartInput(): string | undefined;
    private _filtersIds?;
    get filtersIds(): string[];
    set filtersIds(value: string[]);
    resetFiltersIds(): void;
    get filtersIdsInput(): string[] | undefined;
    private _chartLayout;
    get chartLayout(): ChronicleNativeDashboardChartsChartLayoutOutputReference;
    putChartLayout(value: ChronicleNativeDashboardChartsChartLayout): void;
    resetChartLayout(): void;
    get chartLayoutInput(): ChronicleNativeDashboardChartsChartLayout | undefined;
}
export declare class ChronicleNativeDashboardChartsList extends cdktn.ComplexList {
    internalValue?: ChronicleNativeDashboardCharts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleNativeDashboardChartsOutputReference;
}
export interface ChronicleNativeDashboardFiltersFilterOperatorAndFieldValues {
    /**
    * The values for the modifier. All operators should have a single
    * value other than 'IN' and 'BETWEEN'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#field_values ChronicleNativeDashboard#field_values}
    */
    readonly fieldValues?: string[];
    /**
    * The operator to apply to the field. Possible values: ["EQUAL", "NOT_EQUAL", "IN", "GREATER_THAN", "GREATER_THAN_OR_EQUAL_TO", "LESS_THAN", "LESS_THAN_OR_EQUAL_TO", "BETWEEN", "PAST", "IS_NULL", "IS_NOT_NULL", "STARTS_WITH", "ENDS_WITH", "DOES_NOT_STARTS_WITH", "DOES_NOT_ENDS_WITH", "NOT_IN", "CONTAINS", "DOES_NOT_CONTAIN"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#filter_operator ChronicleNativeDashboard#filter_operator}
    */
    readonly filterOperator?: string;
}
export declare function chronicleNativeDashboardFiltersFilterOperatorAndFieldValuesToTerraform(struct?: ChronicleNativeDashboardFiltersFilterOperatorAndFieldValues | cdktn.IResolvable): any;
export declare function chronicleNativeDashboardFiltersFilterOperatorAndFieldValuesToHclTerraform(struct?: ChronicleNativeDashboardFiltersFilterOperatorAndFieldValues | cdktn.IResolvable): any;
export declare class ChronicleNativeDashboardFiltersFilterOperatorAndFieldValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleNativeDashboardFiltersFilterOperatorAndFieldValues | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleNativeDashboardFiltersFilterOperatorAndFieldValues | cdktn.IResolvable | undefined);
    private _fieldValues?;
    get fieldValues(): string[];
    set fieldValues(value: string[]);
    resetFieldValues(): void;
    get fieldValuesInput(): string[] | undefined;
    private _filterOperator?;
    get filterOperator(): string;
    set filterOperator(value: string);
    resetFilterOperator(): void;
    get filterOperatorInput(): string | undefined;
}
export declare class ChronicleNativeDashboardFiltersFilterOperatorAndFieldValuesList extends cdktn.ComplexList {
    internalValue?: ChronicleNativeDashboardFiltersFilterOperatorAndFieldValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleNativeDashboardFiltersFilterOperatorAndFieldValuesOutputReference;
}
export interface ChronicleNativeDashboardFilters {
    /**
    * The IDs of charts that this filter applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#chart_ids ChronicleNativeDashboard#chart_ids}
    */
    readonly chartIds?: string[];
    /**
    * The data source for the filter.
    * Possible values:
    * UDM, ENTITY, INGESTION_METRICS, RULE_DETECTIONS, RULESETS, GLOBAL,
    * IOC_MATCHES, RULES, SOAR_CASES, SOAR_PLAYBOOKS, SOAR_CASE_HISTORY,
    * DATA_TABLE, INVESTIGATION, INVESTIGATION_FEEDBACK
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#data_source ChronicleNativeDashboard#data_source}
    */
    readonly dataSource?: string;
    /**
    * The display name of the filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#display_name ChronicleNativeDashboard#display_name}
    */
    readonly displayName?: string;
    /**
    * The UDM field path being filtered.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#field_path ChronicleNativeDashboard#field_path}
    */
    readonly fieldPath?: string;
    /**
    * The unique ID of the filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#id ChronicleNativeDashboard#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Whether the filter is mandatory for the dashboard consumer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#is_mandatory ChronicleNativeDashboard#is_mandatory}
    */
    readonly isMandatory?: boolean | cdktn.IResolvable;
    /**
    * Whether the filter is a standard time range filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#is_standard_time_range_filter ChronicleNativeDashboard#is_standard_time_range_filter}
    */
    readonly isStandardTimeRangeFilter?: boolean | cdktn.IResolvable;
    /**
    * Whether the standard time range filter is currently enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#is_standard_time_range_filter_enabled ChronicleNativeDashboard#is_standard_time_range_filter_enabled}
    */
    readonly isStandardTimeRangeFilterEnabled?: boolean | cdktn.IResolvable;
    /**
    * filter_operator_and_field_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#filter_operator_and_field_values ChronicleNativeDashboard#filter_operator_and_field_values}
    */
    readonly filterOperatorAndFieldValues?: ChronicleNativeDashboardFiltersFilterOperatorAndFieldValues[] | cdktn.IResolvable;
}
export declare function chronicleNativeDashboardFiltersToTerraform(struct?: ChronicleNativeDashboardFilters | cdktn.IResolvable): any;
export declare function chronicleNativeDashboardFiltersToHclTerraform(struct?: ChronicleNativeDashboardFilters | cdktn.IResolvable): any;
export declare class ChronicleNativeDashboardFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleNativeDashboardFilters | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleNativeDashboardFilters | cdktn.IResolvable | undefined);
    private _chartIds?;
    get chartIds(): string[];
    set chartIds(value: string[]);
    resetChartIds(): void;
    get chartIdsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    resetDataSource(): void;
    get dataSourceInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _fieldPath?;
    get fieldPath(): string;
    set fieldPath(value: string);
    resetFieldPath(): void;
    get fieldPathInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isMandatory?;
    get isMandatory(): boolean | cdktn.IResolvable;
    set isMandatory(value: boolean | cdktn.IResolvable);
    resetIsMandatory(): void;
    get isMandatoryInput(): boolean | cdktn.IResolvable | undefined;
    private _isStandardTimeRangeFilter?;
    get isStandardTimeRangeFilter(): boolean | cdktn.IResolvable;
    set isStandardTimeRangeFilter(value: boolean | cdktn.IResolvable);
    resetIsStandardTimeRangeFilter(): void;
    get isStandardTimeRangeFilterInput(): boolean | cdktn.IResolvable | undefined;
    private _isStandardTimeRangeFilterEnabled?;
    get isStandardTimeRangeFilterEnabled(): boolean | cdktn.IResolvable;
    set isStandardTimeRangeFilterEnabled(value: boolean | cdktn.IResolvable);
    resetIsStandardTimeRangeFilterEnabled(): void;
    get isStandardTimeRangeFilterEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _filterOperatorAndFieldValues;
    get filterOperatorAndFieldValues(): ChronicleNativeDashboardFiltersFilterOperatorAndFieldValuesList;
    putFilterOperatorAndFieldValues(value: ChronicleNativeDashboardFiltersFilterOperatorAndFieldValues[] | cdktn.IResolvable): void;
    resetFilterOperatorAndFieldValues(): void;
    get filterOperatorAndFieldValuesInput(): cdktn.IResolvable | ChronicleNativeDashboardFiltersFilterOperatorAndFieldValues[] | undefined;
}
export declare class ChronicleNativeDashboardFiltersList extends cdktn.ComplexList {
    internalValue?: ChronicleNativeDashboardFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleNativeDashboardFiltersOutputReference;
}
export interface ChronicleNativeDashboardTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#create ChronicleNativeDashboard#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#delete ChronicleNativeDashboard#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#update ChronicleNativeDashboard#update}
    */
    readonly update?: string;
}
export declare function chronicleNativeDashboardTimeoutsToTerraform(struct?: ChronicleNativeDashboardTimeouts | cdktn.IResolvable): any;
export declare function chronicleNativeDashboardTimeoutsToHclTerraform(struct?: ChronicleNativeDashboardTimeouts | cdktn.IResolvable): any;
export declare class ChronicleNativeDashboardTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleNativeDashboardTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleNativeDashboardTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard google_chronicle_native_dashboard}
*/
export declare class ChronicleNativeDashboard extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_chronicle_native_dashboard";
    /**
    * Generates CDKTN code for importing a ChronicleNativeDashboard resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChronicleNativeDashboard to import
    * @param importFromId The id of the existing ChronicleNativeDashboard that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChronicleNativeDashboard to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_native_dashboard google_chronicle_native_dashboard} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChronicleNativeDashboardConfig
    */
    constructor(scope: Construct, id: string, config: ChronicleNativeDashboardConfig);
    private _access?;
    get access(): string;
    set access(value: string);
    resetAccess(): void;
    get accessInput(): string | undefined;
    get createTime(): string;
    get createUserId(): string;
    get dashboardId(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get etag(): string;
    get fingerprint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instance?;
    get instance(): string;
    set instance(value: string);
    get instanceInput(): string | undefined;
    private _isPinned?;
    get isPinned(): boolean | cdktn.IResolvable;
    set isPinned(value: boolean | cdktn.IResolvable);
    resetIsPinned(): void;
    get isPinnedInput(): boolean | cdktn.IResolvable | undefined;
    get lastViewedTime(): string;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    get updateTime(): string;
    get updateUserId(): string;
    private _charts;
    get charts(): ChronicleNativeDashboardChartsList;
    putCharts(value: ChronicleNativeDashboardCharts[] | cdktn.IResolvable): void;
    resetCharts(): void;
    get chartsInput(): cdktn.IResolvable | ChronicleNativeDashboardCharts[] | undefined;
    private _filters;
    get filters(): ChronicleNativeDashboardFiltersList;
    putFilters(value: ChronicleNativeDashboardFilters[] | cdktn.IResolvable): void;
    resetFilters(): void;
    get filtersInput(): cdktn.IResolvable | ChronicleNativeDashboardFilters[] | undefined;
    private _timeouts;
    get timeouts(): ChronicleNativeDashboardTimeoutsOutputReference;
    putTimeouts(value: ChronicleNativeDashboardTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ChronicleNativeDashboardTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
