/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApphubServiceProjectAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service_project_attachment#deletion_policy ApphubServiceProjectAttachment#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service_project_attachment#id ApphubServiceProjectAttachment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service_project_attachment#project ApphubServiceProjectAttachment#project}
    */
    readonly project?: string;
    /**
    * "Immutable. Service project name in the format: \"projects/abc\"
    * or \"projects/123\". As input, project name with either project id or number
    * are accepted. As output, this field will contain project number."
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service_project_attachment#service_project ApphubServiceProjectAttachment#service_project}
    */
    readonly serviceProject?: string;
    /**
    * Required. The service project attachment identifier must contain the project_id of the service project specified in the service_project_attachment.service_project field. Hint: "projects/{project_id}"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service_project_attachment#service_project_attachment_id ApphubServiceProjectAttachment#service_project_attachment_id}
    */
    readonly serviceProjectAttachmentId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service_project_attachment#timeouts ApphubServiceProjectAttachment#timeouts}
    */
    readonly timeouts?: ApphubServiceProjectAttachmentTimeouts;
}
export interface ApphubServiceProjectAttachmentTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service_project_attachment#create ApphubServiceProjectAttachment#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service_project_attachment#delete ApphubServiceProjectAttachment#delete}
    */
    readonly delete?: string;
}
export declare function apphubServiceProjectAttachmentTimeoutsToTerraform(struct?: ApphubServiceProjectAttachmentTimeouts | cdktn.IResolvable): any;
export declare function apphubServiceProjectAttachmentTimeoutsToHclTerraform(struct?: ApphubServiceProjectAttachmentTimeouts | cdktn.IResolvable): any;
export declare class ApphubServiceProjectAttachmentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApphubServiceProjectAttachmentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApphubServiceProjectAttachmentTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service_project_attachment google_apphub_service_project_attachment}
*/
export declare class ApphubServiceProjectAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apphub_service_project_attachment";
    /**
    * Generates CDKTN code for importing a ApphubServiceProjectAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApphubServiceProjectAttachment to import
    * @param importFromId The id of the existing ApphubServiceProjectAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service_project_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApphubServiceProjectAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service_project_attachment google_apphub_service_project_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApphubServiceProjectAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: ApphubServiceProjectAttachmentConfig);
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _serviceProject?;
    get serviceProject(): string;
    set serviceProject(value: string);
    resetServiceProject(): void;
    get serviceProjectInput(): string | undefined;
    private _serviceProjectAttachmentId?;
    get serviceProjectAttachmentId(): string;
    set serviceProjectAttachmentId(value: string);
    get serviceProjectAttachmentIdInput(): string | undefined;
    get state(): string;
    get uid(): string;
    private _timeouts;
    get timeouts(): ApphubServiceProjectAttachmentTimeoutsOutputReference;
    putTimeouts(value: ApphubServiceProjectAttachmentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApphubServiceProjectAttachmentTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
