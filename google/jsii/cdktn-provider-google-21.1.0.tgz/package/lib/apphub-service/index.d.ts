/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApphubServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Part of 'parent'.  Full resource name of a parent Application. Example: projects/{HOST_PROJECT_ID}/locations/{LOCATION}/applications/{APPLICATION_ID}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#application_id ApphubService#application_id}
    */
    readonly applicationId: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#deletion_policy ApphubService#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * User-defined description of a Service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#description ApphubService#description}
    */
    readonly description?: string;
    /**
    * Immutable. The resource name of the original discovered service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#discovered_service ApphubService#discovered_service}
    */
    readonly discoveredService: string;
    /**
    * User-defined name for the Service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#display_name ApphubService#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#id ApphubService#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Part of 'parent'.  Full resource name of a parent Application. Example: projects/{HOST_PROJECT_ID}/locations/{LOCATION}/applications/{APPLICATION_ID}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#location ApphubService#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#project ApphubService#project}
    */
    readonly project?: string;
    /**
    * The Service identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#service_id ApphubService#service_id}
    */
    readonly serviceId: string;
    /**
    * attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#attributes ApphubService#attributes}
    */
    readonly attributes?: ApphubServiceAttributes;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#timeouts ApphubService#timeouts}
    */
    readonly timeouts?: ApphubServiceTimeouts;
}
export interface ApphubServiceServicePropertiesExtendedMetadataValue {
}
export declare function apphubServiceServicePropertiesExtendedMetadataValueToTerraform(struct?: ApphubServiceServicePropertiesExtendedMetadataValue): any;
export declare function apphubServiceServicePropertiesExtendedMetadataValueToHclTerraform(struct?: ApphubServiceServicePropertiesExtendedMetadataValue): any;
export declare class ApphubServiceServicePropertiesExtendedMetadataValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApphubServiceServicePropertiesExtendedMetadataValue | undefined;
    set internalValue(value: ApphubServiceServicePropertiesExtendedMetadataValue | undefined);
    get extendedMetadataSchema(): string;
    get metadataStruct(): string;
}
export declare class ApphubServiceServicePropertiesExtendedMetadataValueList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApphubServiceServicePropertiesExtendedMetadataValueOutputReference;
}
export interface ApphubServiceServicePropertiesExtendedMetadata {
}
export declare function apphubServiceServicePropertiesExtendedMetadataToTerraform(struct?: ApphubServiceServicePropertiesExtendedMetadata): any;
export declare function apphubServiceServicePropertiesExtendedMetadataToHclTerraform(struct?: ApphubServiceServicePropertiesExtendedMetadata): any;
export declare class ApphubServiceServicePropertiesExtendedMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApphubServiceServicePropertiesExtendedMetadata | undefined;
    set internalValue(value: ApphubServiceServicePropertiesExtendedMetadata | undefined);
    get key(): string;
    private _value;
    get value(): ApphubServiceServicePropertiesExtendedMetadataValueList;
}
export declare class ApphubServiceServicePropertiesExtendedMetadataList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApphubServiceServicePropertiesExtendedMetadataOutputReference;
}
export interface ApphubServiceServicePropertiesFunctionalType {
}
export declare function apphubServiceServicePropertiesFunctionalTypeToTerraform(struct?: ApphubServiceServicePropertiesFunctionalType): any;
export declare function apphubServiceServicePropertiesFunctionalTypeToHclTerraform(struct?: ApphubServiceServicePropertiesFunctionalType): any;
export declare class ApphubServiceServicePropertiesFunctionalTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApphubServiceServicePropertiesFunctionalType | undefined;
    set internalValue(value: ApphubServiceServicePropertiesFunctionalType | undefined);
    get type(): string;
}
export declare class ApphubServiceServicePropertiesFunctionalTypeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApphubServiceServicePropertiesFunctionalTypeOutputReference;
}
export interface ApphubServiceServicePropertiesIdentity {
}
export declare function apphubServiceServicePropertiesIdentityToTerraform(struct?: ApphubServiceServicePropertiesIdentity): any;
export declare function apphubServiceServicePropertiesIdentityToHclTerraform(struct?: ApphubServiceServicePropertiesIdentity): any;
export declare class ApphubServiceServicePropertiesIdentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApphubServiceServicePropertiesIdentity | undefined;
    set internalValue(value: ApphubServiceServicePropertiesIdentity | undefined);
    get principal(): string;
}
export declare class ApphubServiceServicePropertiesIdentityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApphubServiceServicePropertiesIdentityOutputReference;
}
export interface ApphubServiceServicePropertiesRegistrationType {
}
export declare function apphubServiceServicePropertiesRegistrationTypeToTerraform(struct?: ApphubServiceServicePropertiesRegistrationType): any;
export declare function apphubServiceServicePropertiesRegistrationTypeToHclTerraform(struct?: ApphubServiceServicePropertiesRegistrationType): any;
export declare class ApphubServiceServicePropertiesRegistrationTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApphubServiceServicePropertiesRegistrationType | undefined;
    set internalValue(value: ApphubServiceServicePropertiesRegistrationType | undefined);
    get type(): string;
}
export declare class ApphubServiceServicePropertiesRegistrationTypeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApphubServiceServicePropertiesRegistrationTypeOutputReference;
}
export interface ApphubServiceServiceProperties {
}
export declare function apphubServiceServicePropertiesToTerraform(struct?: ApphubServiceServiceProperties): any;
export declare function apphubServiceServicePropertiesToHclTerraform(struct?: ApphubServiceServiceProperties): any;
export declare class ApphubServiceServicePropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApphubServiceServiceProperties | undefined;
    set internalValue(value: ApphubServiceServiceProperties | undefined);
    private _extendedMetadata;
    get extendedMetadata(): ApphubServiceServicePropertiesExtendedMetadataList;
    private _functionalType;
    get functionalType(): ApphubServiceServicePropertiesFunctionalTypeList;
    get gcpProject(): string;
    private _identity;
    get identity(): ApphubServiceServicePropertiesIdentityList;
    get location(): string;
    private _registrationType;
    get registrationType(): ApphubServiceServicePropertiesRegistrationTypeList;
    get zone(): string;
}
export declare class ApphubServiceServicePropertiesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApphubServiceServicePropertiesOutputReference;
}
export interface ApphubServiceServiceReference {
}
export declare function apphubServiceServiceReferenceToTerraform(struct?: ApphubServiceServiceReference): any;
export declare function apphubServiceServiceReferenceToHclTerraform(struct?: ApphubServiceServiceReference): any;
export declare class ApphubServiceServiceReferenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApphubServiceServiceReference | undefined;
    set internalValue(value: ApphubServiceServiceReference | undefined);
    get uri(): string;
}
export declare class ApphubServiceServiceReferenceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApphubServiceServiceReferenceOutputReference;
}
export interface ApphubServiceAttributesBusinessOwners {
    /**
    * Contact's name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#display_name ApphubService#display_name}
    */
    readonly displayName?: string;
    /**
    * Required. Email address of the contacts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#email ApphubService#email}
    */
    readonly email: string;
}
export declare function apphubServiceAttributesBusinessOwnersToTerraform(struct?: ApphubServiceAttributesBusinessOwners | cdktn.IResolvable): any;
export declare function apphubServiceAttributesBusinessOwnersToHclTerraform(struct?: ApphubServiceAttributesBusinessOwners | cdktn.IResolvable): any;
export declare class ApphubServiceAttributesBusinessOwnersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApphubServiceAttributesBusinessOwners | cdktn.IResolvable | undefined;
    set internalValue(value: ApphubServiceAttributesBusinessOwners | cdktn.IResolvable | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    get emailInput(): string | undefined;
}
export declare class ApphubServiceAttributesBusinessOwnersList extends cdktn.ComplexList {
    internalValue?: ApphubServiceAttributesBusinessOwners[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApphubServiceAttributesBusinessOwnersOutputReference;
}
export interface ApphubServiceAttributesCriticality {
    /**
    * Criticality type. Possible values: ["MISSION_CRITICAL", "HIGH", "MEDIUM", "LOW"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#type ApphubService#type}
    */
    readonly type: string;
}
export declare function apphubServiceAttributesCriticalityToTerraform(struct?: ApphubServiceAttributesCriticalityOutputReference | ApphubServiceAttributesCriticality): any;
export declare function apphubServiceAttributesCriticalityToHclTerraform(struct?: ApphubServiceAttributesCriticalityOutputReference | ApphubServiceAttributesCriticality): any;
export declare class ApphubServiceAttributesCriticalityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApphubServiceAttributesCriticality | undefined;
    set internalValue(value: ApphubServiceAttributesCriticality | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface ApphubServiceAttributesDeveloperOwners {
    /**
    * Contact's name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#display_name ApphubService#display_name}
    */
    readonly displayName?: string;
    /**
    * Required. Email address of the contacts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#email ApphubService#email}
    */
    readonly email: string;
}
export declare function apphubServiceAttributesDeveloperOwnersToTerraform(struct?: ApphubServiceAttributesDeveloperOwners | cdktn.IResolvable): any;
export declare function apphubServiceAttributesDeveloperOwnersToHclTerraform(struct?: ApphubServiceAttributesDeveloperOwners | cdktn.IResolvable): any;
export declare class ApphubServiceAttributesDeveloperOwnersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApphubServiceAttributesDeveloperOwners | cdktn.IResolvable | undefined;
    set internalValue(value: ApphubServiceAttributesDeveloperOwners | cdktn.IResolvable | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    get emailInput(): string | undefined;
}
export declare class ApphubServiceAttributesDeveloperOwnersList extends cdktn.ComplexList {
    internalValue?: ApphubServiceAttributesDeveloperOwners[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApphubServiceAttributesDeveloperOwnersOutputReference;
}
export interface ApphubServiceAttributesEnvironment {
    /**
    * Environment type. Possible values: ["PRODUCTION", "STAGING", "TEST", "DEVELOPMENT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#type ApphubService#type}
    */
    readonly type: string;
}
export declare function apphubServiceAttributesEnvironmentToTerraform(struct?: ApphubServiceAttributesEnvironmentOutputReference | ApphubServiceAttributesEnvironment): any;
export declare function apphubServiceAttributesEnvironmentToHclTerraform(struct?: ApphubServiceAttributesEnvironmentOutputReference | ApphubServiceAttributesEnvironment): any;
export declare class ApphubServiceAttributesEnvironmentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApphubServiceAttributesEnvironment | undefined;
    set internalValue(value: ApphubServiceAttributesEnvironment | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface ApphubServiceAttributesOperatorOwners {
    /**
    * Contact's name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#display_name ApphubService#display_name}
    */
    readonly displayName?: string;
    /**
    * Required. Email address of the contacts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#email ApphubService#email}
    */
    readonly email: string;
}
export declare function apphubServiceAttributesOperatorOwnersToTerraform(struct?: ApphubServiceAttributesOperatorOwners | cdktn.IResolvable): any;
export declare function apphubServiceAttributesOperatorOwnersToHclTerraform(struct?: ApphubServiceAttributesOperatorOwners | cdktn.IResolvable): any;
export declare class ApphubServiceAttributesOperatorOwnersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApphubServiceAttributesOperatorOwners | cdktn.IResolvable | undefined;
    set internalValue(value: ApphubServiceAttributesOperatorOwners | cdktn.IResolvable | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    get emailInput(): string | undefined;
}
export declare class ApphubServiceAttributesOperatorOwnersList extends cdktn.ComplexList {
    internalValue?: ApphubServiceAttributesOperatorOwners[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApphubServiceAttributesOperatorOwnersOutputReference;
}
export interface ApphubServiceAttributes {
    /**
    * business_owners block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#business_owners ApphubService#business_owners}
    */
    readonly businessOwners?: ApphubServiceAttributesBusinessOwners[] | cdktn.IResolvable;
    /**
    * criticality block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#criticality ApphubService#criticality}
    */
    readonly criticality?: ApphubServiceAttributesCriticality;
    /**
    * developer_owners block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#developer_owners ApphubService#developer_owners}
    */
    readonly developerOwners?: ApphubServiceAttributesDeveloperOwners[] | cdktn.IResolvable;
    /**
    * environment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#environment ApphubService#environment}
    */
    readonly environment?: ApphubServiceAttributesEnvironment;
    /**
    * operator_owners block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#operator_owners ApphubService#operator_owners}
    */
    readonly operatorOwners?: ApphubServiceAttributesOperatorOwners[] | cdktn.IResolvable;
}
export declare function apphubServiceAttributesToTerraform(struct?: ApphubServiceAttributesOutputReference | ApphubServiceAttributes): any;
export declare function apphubServiceAttributesToHclTerraform(struct?: ApphubServiceAttributesOutputReference | ApphubServiceAttributes): any;
export declare class ApphubServiceAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApphubServiceAttributes | undefined;
    set internalValue(value: ApphubServiceAttributes | undefined);
    private _businessOwners;
    get businessOwners(): ApphubServiceAttributesBusinessOwnersList;
    putBusinessOwners(value: ApphubServiceAttributesBusinessOwners[] | cdktn.IResolvable): void;
    resetBusinessOwners(): void;
    get businessOwnersInput(): cdktn.IResolvable | ApphubServiceAttributesBusinessOwners[] | undefined;
    private _criticality;
    get criticality(): ApphubServiceAttributesCriticalityOutputReference;
    putCriticality(value: ApphubServiceAttributesCriticality): void;
    resetCriticality(): void;
    get criticalityInput(): ApphubServiceAttributesCriticality | undefined;
    private _developerOwners;
    get developerOwners(): ApphubServiceAttributesDeveloperOwnersList;
    putDeveloperOwners(value: ApphubServiceAttributesDeveloperOwners[] | cdktn.IResolvable): void;
    resetDeveloperOwners(): void;
    get developerOwnersInput(): cdktn.IResolvable | ApphubServiceAttributesDeveloperOwners[] | undefined;
    private _environment;
    get environment(): ApphubServiceAttributesEnvironmentOutputReference;
    putEnvironment(value: ApphubServiceAttributesEnvironment): void;
    resetEnvironment(): void;
    get environmentInput(): ApphubServiceAttributesEnvironment | undefined;
    private _operatorOwners;
    get operatorOwners(): ApphubServiceAttributesOperatorOwnersList;
    putOperatorOwners(value: ApphubServiceAttributesOperatorOwners[] | cdktn.IResolvable): void;
    resetOperatorOwners(): void;
    get operatorOwnersInput(): cdktn.IResolvable | ApphubServiceAttributesOperatorOwners[] | undefined;
}
export interface ApphubServiceTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#create ApphubService#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#delete ApphubService#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#update ApphubService#update}
    */
    readonly update?: string;
}
export declare function apphubServiceTimeoutsToTerraform(struct?: ApphubServiceTimeouts | cdktn.IResolvable): any;
export declare function apphubServiceTimeoutsToHclTerraform(struct?: ApphubServiceTimeouts | cdktn.IResolvable): any;
export declare class ApphubServiceTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApphubServiceTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApphubServiceTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service google_apphub_service}
*/
export declare class ApphubService extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apphub_service";
    /**
    * Generates CDKTN code for importing a ApphubService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApphubService to import
    * @param importFromId The id of the existing ApphubService that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApphubService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_service google_apphub_service} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApphubServiceConfig
    */
    constructor(scope: Construct, id: string, config: ApphubServiceConfig);
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _discoveredService?;
    get discoveredService(): string;
    set discoveredService(value: string);
    get discoveredServiceInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _serviceId?;
    get serviceId(): string;
    set serviceId(value: string);
    get serviceIdInput(): string | undefined;
    private _serviceProperties;
    get serviceProperties(): ApphubServiceServicePropertiesList;
    private _serviceReference;
    get serviceReference(): ApphubServiceServiceReferenceList;
    get state(): string;
    get uid(): string;
    get updateTime(): string;
    private _attributes;
    get attributes(): ApphubServiceAttributesOutputReference;
    putAttributes(value: ApphubServiceAttributes): void;
    resetAttributes(): void;
    get attributesInput(): ApphubServiceAttributes | undefined;
    private _timeouts;
    get timeouts(): ApphubServiceTimeoutsOutputReference;
    putTimeouts(value: ApphubServiceTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApphubServiceTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
