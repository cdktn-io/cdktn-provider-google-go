/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BigqueryAnalyticsHubQueryTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the data exchange. Must contain only Unicode letters, numbers (0-9), underscores (_). Should not use characters that require URL-escaping, or characters outside of ASCII, spaces.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_analytics_hub_query_template#data_exchange_id BigqueryAnalyticsHubQueryTemplate#data_exchange_id}
    */
    readonly dataExchangeId: string;
    /**
    * This field uses a custom implementation please refer to documentation under /hashicorp/terraform-provider-google-beta/website/docs/r/bigquery_analytics_hub_query_template.html.markdown for specifics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_analytics_hub_query_template#deletion_policy BigqueryAnalyticsHubQueryTemplate#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Short description of the QueryTemplate. The description must not contain
    * Unicode non-characters and C0 and C1 control codes except tabs,
    * new lines, carriage returns, and page breaks.
    * Default value is an empty string. Max length: 2000 bytes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_analytics_hub_query_template#description BigqueryAnalyticsHubQueryTemplate#description}
    */
    readonly description?: string;
    /**
    * Human-readable display name of the QueryTemplate. The display name must
    * contain only Unicode letters, numbers (0-9), underscores (_), dashes (-),
    * spaces ( ), ampersands (&) and can't start or end with spaces. Default
    * value is an empty string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_analytics_hub_query_template#display_name BigqueryAnalyticsHubQueryTemplate#display_name}
    */
    readonly displayName: string;
    /**
    * Documentation describing the QueryTemplate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_analytics_hub_query_template#documentation BigqueryAnalyticsHubQueryTemplate#documentation}
    */
    readonly documentation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_analytics_hub_query_template#id BigqueryAnalyticsHubQueryTemplate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the location this data exchange query template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_analytics_hub_query_template#location BigqueryAnalyticsHubQueryTemplate#location}
    */
    readonly location: string;
    /**
    * Email or URL of the primary point of contact of the QueryTemplate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_analytics_hub_query_template#primary_contact BigqueryAnalyticsHubQueryTemplate#primary_contact}
    */
    readonly primaryContact?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_analytics_hub_query_template#project BigqueryAnalyticsHubQueryTemplate#project}
    */
    readonly project?: string;
    /**
    * Unique QueryTemplate ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_analytics_hub_query_template#query_template_id BigqueryAnalyticsHubQueryTemplate#query_template_id}
    */
    readonly queryTemplateId: string;
    /**
    * If set to 'true', the QueryTemplate will be submitted for approval and cannot be updated afterwards. This is a one-time action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_analytics_hub_query_template#submit BigqueryAnalyticsHubQueryTemplate#submit}
    */
    readonly submit?: boolean | cdktn.IResolvable;
    /**
    * encryption_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_analytics_hub_query_template#encryption_configuration BigqueryAnalyticsHubQueryTemplate#encryption_configuration}
    */
    readonly encryptionConfiguration?: BigqueryAnalyticsHubQueryTemplateEncryptionConfiguration;
    /**
    * routine block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_analytics_hub_query_template#routine BigqueryAnalyticsHubQueryTemplate#routine}
    */
    readonly routine?: BigqueryAnalyticsHubQueryTemplateRoutine;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_analytics_hub_query_template#timeouts BigqueryAnalyticsHubQueryTemplate#timeouts}
    */
    readonly timeouts?: BigqueryAnalyticsHubQueryTemplateTimeouts;
}
export interface BigqueryAnalyticsHubQueryTemplateEncryptionConfiguration {
    /**
    * The KMS key used to encrypt the query template.
    * Format: 'projects/{project}/locations/{location}/keyRings/{keyring}/cryptoKeys/{key}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_analytics_hub_query_template#kms_key_name BigqueryAnalyticsHubQueryTemplate#kms_key_name}
    */
    readonly kmsKeyName: string;
}
export declare function bigqueryAnalyticsHubQueryTemplateEncryptionConfigurationToTerraform(struct?: BigqueryAnalyticsHubQueryTemplateEncryptionConfigurationOutputReference | BigqueryAnalyticsHubQueryTemplateEncryptionConfiguration): any;
export declare function bigqueryAnalyticsHubQueryTemplateEncryptionConfigurationToHclTerraform(struct?: BigqueryAnalyticsHubQueryTemplateEncryptionConfigurationOutputReference | BigqueryAnalyticsHubQueryTemplateEncryptionConfiguration): any;
export declare class BigqueryAnalyticsHubQueryTemplateEncryptionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryAnalyticsHubQueryTemplateEncryptionConfiguration | undefined;
    set internalValue(value: BigqueryAnalyticsHubQueryTemplateEncryptionConfiguration | undefined);
    private _kmsKeyName?;
    get kmsKeyName(): string;
    set kmsKeyName(value: string);
    get kmsKeyNameInput(): string | undefined;
}
export interface BigqueryAnalyticsHubQueryTemplateRoutine {
    /**
    * SQL query logic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_analytics_hub_query_template#definition_body BigqueryAnalyticsHubQueryTemplate#definition_body}
    */
    readonly definitionBody?: string;
    /**
    * Type of routine (e.g., TABLE_VALUED_FUNCTION). Possible values: ["TABLE_VALUED_FUNCTION"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_analytics_hub_query_template#routine_type BigqueryAnalyticsHubQueryTemplate#routine_type}
    */
    readonly routineType?: string;
}
export declare function bigqueryAnalyticsHubQueryTemplateRoutineToTerraform(struct?: BigqueryAnalyticsHubQueryTemplateRoutineOutputReference | BigqueryAnalyticsHubQueryTemplateRoutine): any;
export declare function bigqueryAnalyticsHubQueryTemplateRoutineToHclTerraform(struct?: BigqueryAnalyticsHubQueryTemplateRoutineOutputReference | BigqueryAnalyticsHubQueryTemplateRoutine): any;
export declare class BigqueryAnalyticsHubQueryTemplateRoutineOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryAnalyticsHubQueryTemplateRoutine | undefined;
    set internalValue(value: BigqueryAnalyticsHubQueryTemplateRoutine | undefined);
    private _definitionBody?;
    get definitionBody(): string;
    set definitionBody(value: string);
    resetDefinitionBody(): void;
    get definitionBodyInput(): string | undefined;
    private _routineType?;
    get routineType(): string;
    set routineType(value: string);
    resetRoutineType(): void;
    get routineTypeInput(): string | undefined;
}
export interface BigqueryAnalyticsHubQueryTemplateTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_analytics_hub_query_template#create BigqueryAnalyticsHubQueryTemplate#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_analytics_hub_query_template#delete BigqueryAnalyticsHubQueryTemplate#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_analytics_hub_query_template#update BigqueryAnalyticsHubQueryTemplate#update}
    */
    readonly update?: string;
}
export declare function bigqueryAnalyticsHubQueryTemplateTimeoutsToTerraform(struct?: BigqueryAnalyticsHubQueryTemplateTimeouts | cdktn.IResolvable): any;
export declare function bigqueryAnalyticsHubQueryTemplateTimeoutsToHclTerraform(struct?: BigqueryAnalyticsHubQueryTemplateTimeouts | cdktn.IResolvable): any;
export declare class BigqueryAnalyticsHubQueryTemplateTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryAnalyticsHubQueryTemplateTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BigqueryAnalyticsHubQueryTemplateTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_analytics_hub_query_template google_bigquery_analytics_hub_query_template}
*/
export declare class BigqueryAnalyticsHubQueryTemplate extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_bigquery_analytics_hub_query_template";
    /**
    * Generates CDKTN code for importing a BigqueryAnalyticsHubQueryTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BigqueryAnalyticsHubQueryTemplate to import
    * @param importFromId The id of the existing BigqueryAnalyticsHubQueryTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_analytics_hub_query_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BigqueryAnalyticsHubQueryTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_analytics_hub_query_template google_bigquery_analytics_hub_query_template} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BigqueryAnalyticsHubQueryTemplateConfig
    */
    constructor(scope: Construct, id: string, config: BigqueryAnalyticsHubQueryTemplateConfig);
    get createTime(): string;
    private _dataExchangeId?;
    get dataExchangeId(): string;
    set dataExchangeId(value: string);
    get dataExchangeIdInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _documentation?;
    get documentation(): string;
    set documentation(value: string);
    resetDocumentation(): void;
    get documentationInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _primaryContact?;
    get primaryContact(): string;
    set primaryContact(value: string);
    resetPrimaryContact(): void;
    get primaryContactInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _queryTemplateId?;
    get queryTemplateId(): string;
    set queryTemplateId(value: string);
    get queryTemplateIdInput(): string | undefined;
    get state(): string;
    private _submit?;
    get submit(): boolean | cdktn.IResolvable;
    set submit(value: boolean | cdktn.IResolvable);
    resetSubmit(): void;
    get submitInput(): boolean | cdktn.IResolvable | undefined;
    get updateTime(): string;
    private _encryptionConfiguration;
    get encryptionConfiguration(): BigqueryAnalyticsHubQueryTemplateEncryptionConfigurationOutputReference;
    putEncryptionConfiguration(value: BigqueryAnalyticsHubQueryTemplateEncryptionConfiguration): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): BigqueryAnalyticsHubQueryTemplateEncryptionConfiguration | undefined;
    private _routine;
    get routine(): BigqueryAnalyticsHubQueryTemplateRoutineOutputReference;
    putRoutine(value: BigqueryAnalyticsHubQueryTemplateRoutine): void;
    resetRoutine(): void;
    get routineInput(): BigqueryAnalyticsHubQueryTemplateRoutine | undefined;
    private _timeouts;
    get timeouts(): BigqueryAnalyticsHubQueryTemplateTimeoutsOutputReference;
    putTimeouts(value: BigqueryAnalyticsHubQueryTemplateTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BigqueryAnalyticsHubQueryTemplateTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
