/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BlockchainNodeEngineBlockchainNodesConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the requesting object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/blockchain_node_engine_blockchain_nodes#blockchain_node_id BlockchainNodeEngineBlockchainNodes#blockchain_node_id}
    */
    readonly blockchainNodeId: string;
    /**
    * User-provided key-value pairs Possible values: ["ETHEREUM"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/blockchain_node_engine_blockchain_nodes#blockchain_type BlockchainNodeEngineBlockchainNodes#blockchain_type}
    */
    readonly blockchainType?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/blockchain_node_engine_blockchain_nodes#deletion_policy BlockchainNodeEngineBlockchainNodes#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/blockchain_node_engine_blockchain_nodes#id BlockchainNodeEngineBlockchainNodes#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * User-provided key-value pairs
    *
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/blockchain_node_engine_blockchain_nodes#labels BlockchainNodeEngineBlockchainNodes#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Location of Blockchain Node being created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/blockchain_node_engine_blockchain_nodes#location BlockchainNodeEngineBlockchainNodes#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/blockchain_node_engine_blockchain_nodes#project BlockchainNodeEngineBlockchainNodes#project}
    */
    readonly project?: string;
    /**
    * ethereum_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/blockchain_node_engine_blockchain_nodes#ethereum_details BlockchainNodeEngineBlockchainNodes#ethereum_details}
    */
    readonly ethereumDetails?: BlockchainNodeEngineBlockchainNodesEthereumDetails;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/blockchain_node_engine_blockchain_nodes#timeouts BlockchainNodeEngineBlockchainNodes#timeouts}
    */
    readonly timeouts?: BlockchainNodeEngineBlockchainNodesTimeouts;
}
export interface BlockchainNodeEngineBlockchainNodesConnectionInfoEndpointInfo {
}
export declare function blockchainNodeEngineBlockchainNodesConnectionInfoEndpointInfoToTerraform(struct?: BlockchainNodeEngineBlockchainNodesConnectionInfoEndpointInfo): any;
export declare function blockchainNodeEngineBlockchainNodesConnectionInfoEndpointInfoToHclTerraform(struct?: BlockchainNodeEngineBlockchainNodesConnectionInfoEndpointInfo): any;
export declare class BlockchainNodeEngineBlockchainNodesConnectionInfoEndpointInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BlockchainNodeEngineBlockchainNodesConnectionInfoEndpointInfo | undefined;
    set internalValue(value: BlockchainNodeEngineBlockchainNodesConnectionInfoEndpointInfo | undefined);
    get jsonRpcApiEndpoint(): string;
    get websocketsApiEndpoint(): string;
}
export declare class BlockchainNodeEngineBlockchainNodesConnectionInfoEndpointInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BlockchainNodeEngineBlockchainNodesConnectionInfoEndpointInfoOutputReference;
}
export interface BlockchainNodeEngineBlockchainNodesConnectionInfo {
}
export declare function blockchainNodeEngineBlockchainNodesConnectionInfoToTerraform(struct?: BlockchainNodeEngineBlockchainNodesConnectionInfo): any;
export declare function blockchainNodeEngineBlockchainNodesConnectionInfoToHclTerraform(struct?: BlockchainNodeEngineBlockchainNodesConnectionInfo): any;
export declare class BlockchainNodeEngineBlockchainNodesConnectionInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BlockchainNodeEngineBlockchainNodesConnectionInfo | undefined;
    set internalValue(value: BlockchainNodeEngineBlockchainNodesConnectionInfo | undefined);
    private _endpointInfo;
    get endpointInfo(): BlockchainNodeEngineBlockchainNodesConnectionInfoEndpointInfoList;
    get serviceAttachment(): string;
}
export declare class BlockchainNodeEngineBlockchainNodesConnectionInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BlockchainNodeEngineBlockchainNodesConnectionInfoOutputReference;
}
export interface BlockchainNodeEngineBlockchainNodesEthereumDetailsAdditionalEndpoints {
}
export declare function blockchainNodeEngineBlockchainNodesEthereumDetailsAdditionalEndpointsToTerraform(struct?: BlockchainNodeEngineBlockchainNodesEthereumDetailsAdditionalEndpoints): any;
export declare function blockchainNodeEngineBlockchainNodesEthereumDetailsAdditionalEndpointsToHclTerraform(struct?: BlockchainNodeEngineBlockchainNodesEthereumDetailsAdditionalEndpoints): any;
export declare class BlockchainNodeEngineBlockchainNodesEthereumDetailsAdditionalEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BlockchainNodeEngineBlockchainNodesEthereumDetailsAdditionalEndpoints | undefined;
    set internalValue(value: BlockchainNodeEngineBlockchainNodesEthereumDetailsAdditionalEndpoints | undefined);
    get beaconApiEndpoint(): string;
    get beaconPrometheusMetricsApiEndpoint(): string;
    get executionClientPrometheusMetricsApiEndpoint(): string;
}
export declare class BlockchainNodeEngineBlockchainNodesEthereumDetailsAdditionalEndpointsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BlockchainNodeEngineBlockchainNodesEthereumDetailsAdditionalEndpointsOutputReference;
}
export interface BlockchainNodeEngineBlockchainNodesEthereumDetailsGethDetails {
    /**
    * Blockchain garbage collection modes. Only applicable when NodeType is FULL or ARCHIVE. Possible values: ["FULL", "ARCHIVE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/blockchain_node_engine_blockchain_nodes#garbage_collection_mode BlockchainNodeEngineBlockchainNodes#garbage_collection_mode}
    */
    readonly garbageCollectionMode?: string;
}
export declare function blockchainNodeEngineBlockchainNodesEthereumDetailsGethDetailsToTerraform(struct?: BlockchainNodeEngineBlockchainNodesEthereumDetailsGethDetailsOutputReference | BlockchainNodeEngineBlockchainNodesEthereumDetailsGethDetails): any;
export declare function blockchainNodeEngineBlockchainNodesEthereumDetailsGethDetailsToHclTerraform(struct?: BlockchainNodeEngineBlockchainNodesEthereumDetailsGethDetailsOutputReference | BlockchainNodeEngineBlockchainNodesEthereumDetailsGethDetails): any;
export declare class BlockchainNodeEngineBlockchainNodesEthereumDetailsGethDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BlockchainNodeEngineBlockchainNodesEthereumDetailsGethDetails | undefined;
    set internalValue(value: BlockchainNodeEngineBlockchainNodesEthereumDetailsGethDetails | undefined);
    private _garbageCollectionMode?;
    get garbageCollectionMode(): string;
    set garbageCollectionMode(value: string);
    resetGarbageCollectionMode(): void;
    get garbageCollectionModeInput(): string | undefined;
}
export interface BlockchainNodeEngineBlockchainNodesEthereumDetailsValidatorConfig {
    /**
    * An Ethereum address which the beacon client will send fee rewards to if no recipient is configured in the validator client. See https://lighthouse-book.sigmaprime.io/suggested-fee-recipient.html or https://docs.prylabs.network/docs/execution-node/fee-recipient for examples of how this is used. Note that while this is often described as "suggested", as we run the execution node we can trust the execution node, and therefore this is considered enforced.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/blockchain_node_engine_blockchain_nodes#beacon_fee_recipient BlockchainNodeEngineBlockchainNodes#beacon_fee_recipient}
    */
    readonly beaconFeeRecipient?: string;
    /**
    * URLs for MEV-relay services to use for block building. When set, a managed MEV-boost service is configured on the beacon client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/blockchain_node_engine_blockchain_nodes#mev_relay_urls BlockchainNodeEngineBlockchainNodes#mev_relay_urls}
    */
    readonly mevRelayUrls?: string[];
}
export declare function blockchainNodeEngineBlockchainNodesEthereumDetailsValidatorConfigToTerraform(struct?: BlockchainNodeEngineBlockchainNodesEthereumDetailsValidatorConfigOutputReference | BlockchainNodeEngineBlockchainNodesEthereumDetailsValidatorConfig): any;
export declare function blockchainNodeEngineBlockchainNodesEthereumDetailsValidatorConfigToHclTerraform(struct?: BlockchainNodeEngineBlockchainNodesEthereumDetailsValidatorConfigOutputReference | BlockchainNodeEngineBlockchainNodesEthereumDetailsValidatorConfig): any;
export declare class BlockchainNodeEngineBlockchainNodesEthereumDetailsValidatorConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BlockchainNodeEngineBlockchainNodesEthereumDetailsValidatorConfig | undefined;
    set internalValue(value: BlockchainNodeEngineBlockchainNodesEthereumDetailsValidatorConfig | undefined);
    private _beaconFeeRecipient?;
    get beaconFeeRecipient(): string;
    set beaconFeeRecipient(value: string);
    resetBeaconFeeRecipient(): void;
    get beaconFeeRecipientInput(): string | undefined;
    private _mevRelayUrls?;
    get mevRelayUrls(): string[];
    set mevRelayUrls(value: string[]);
    resetMevRelayUrls(): void;
    get mevRelayUrlsInput(): string[] | undefined;
}
export interface BlockchainNodeEngineBlockchainNodesEthereumDetails {
    /**
    * Enables JSON-RPC access to functions in the admin namespace. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/blockchain_node_engine_blockchain_nodes#api_enable_admin BlockchainNodeEngineBlockchainNodes#api_enable_admin}
    */
    readonly apiEnableAdmin?: boolean | cdktn.IResolvable;
    /**
    * Enables JSON-RPC access to functions in the debug namespace. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/blockchain_node_engine_blockchain_nodes#api_enable_debug BlockchainNodeEngineBlockchainNodes#api_enable_debug}
    */
    readonly apiEnableDebug?: boolean | cdktn.IResolvable;
    /**
    * The consensus client Possible values: ["CONSENSUS_CLIENT_UNSPECIFIED", "LIGHTHOUSE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/blockchain_node_engine_blockchain_nodes#consensus_client BlockchainNodeEngineBlockchainNodes#consensus_client}
    */
    readonly consensusClient?: string;
    /**
    * The execution client Possible values: ["EXECUTION_CLIENT_UNSPECIFIED", "GETH", "ERIGON"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/blockchain_node_engine_blockchain_nodes#execution_client BlockchainNodeEngineBlockchainNodes#execution_client}
    */
    readonly executionClient?: string;
    /**
    * The Ethereum environment being accessed. Possible values: ["MAINNET", "TESTNET_GOERLI_PRATER", "TESTNET_SEPOLIA"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/blockchain_node_engine_blockchain_nodes#network BlockchainNodeEngineBlockchainNodes#network}
    */
    readonly network?: string;
    /**
    * The type of Ethereum node. Possible values: ["LIGHT", "FULL", "ARCHIVE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/blockchain_node_engine_blockchain_nodes#node_type BlockchainNodeEngineBlockchainNodes#node_type}
    */
    readonly nodeType?: string;
    /**
    * geth_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/blockchain_node_engine_blockchain_nodes#geth_details BlockchainNodeEngineBlockchainNodes#geth_details}
    */
    readonly fetchhDetails?: BlockchainNodeEngineBlockchainNodesEthereumDetailsGethDetails;
    /**
    * validator_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/blockchain_node_engine_blockchain_nodes#validator_config BlockchainNodeEngineBlockchainNodes#validator_config}
    */
    readonly validatorConfig?: BlockchainNodeEngineBlockchainNodesEthereumDetailsValidatorConfig;
}
export declare function blockchainNodeEngineBlockchainNodesEthereumDetailsToTerraform(struct?: BlockchainNodeEngineBlockchainNodesEthereumDetailsOutputReference | BlockchainNodeEngineBlockchainNodesEthereumDetails): any;
export declare function blockchainNodeEngineBlockchainNodesEthereumDetailsToHclTerraform(struct?: BlockchainNodeEngineBlockchainNodesEthereumDetailsOutputReference | BlockchainNodeEngineBlockchainNodesEthereumDetails): any;
export declare class BlockchainNodeEngineBlockchainNodesEthereumDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BlockchainNodeEngineBlockchainNodesEthereumDetails | undefined;
    set internalValue(value: BlockchainNodeEngineBlockchainNodesEthereumDetails | undefined);
    private _additionalEndpoints;
    get additionalEndpoints(): BlockchainNodeEngineBlockchainNodesEthereumDetailsAdditionalEndpointsList;
    private _apiEnableAdmin?;
    get apiEnableAdmin(): boolean | cdktn.IResolvable;
    set apiEnableAdmin(value: boolean | cdktn.IResolvable);
    resetApiEnableAdmin(): void;
    get apiEnableAdminInput(): boolean | cdktn.IResolvable | undefined;
    private _apiEnableDebug?;
    get apiEnableDebug(): boolean | cdktn.IResolvable;
    set apiEnableDebug(value: boolean | cdktn.IResolvable);
    resetApiEnableDebug(): void;
    get apiEnableDebugInput(): boolean | cdktn.IResolvable | undefined;
    private _consensusClient?;
    get consensusClient(): string;
    set consensusClient(value: string);
    resetConsensusClient(): void;
    get consensusClientInput(): string | undefined;
    private _executionClient?;
    get executionClient(): string;
    set executionClient(value: string);
    resetExecutionClient(): void;
    get executionClientInput(): string | undefined;
    private _network?;
    get network(): string;
    set network(value: string);
    resetNetwork(): void;
    get networkInput(): string | undefined;
    private _nodeType?;
    get nodeType(): string;
    set nodeType(value: string);
    resetNodeType(): void;
    get nodeTypeInput(): string | undefined;
    private _gethDetails;
    get fetchhDetails(): BlockchainNodeEngineBlockchainNodesEthereumDetailsGethDetailsOutputReference;
    putFetchhDetails(value: BlockchainNodeEngineBlockchainNodesEthereumDetailsGethDetails): void;
    resetFetchhDetails(): void;
    get fetchhDetailsInput(): BlockchainNodeEngineBlockchainNodesEthereumDetailsGethDetails | undefined;
    private _validatorConfig;
    get validatorConfig(): BlockchainNodeEngineBlockchainNodesEthereumDetailsValidatorConfigOutputReference;
    putValidatorConfig(value: BlockchainNodeEngineBlockchainNodesEthereumDetailsValidatorConfig): void;
    resetValidatorConfig(): void;
    get validatorConfigInput(): BlockchainNodeEngineBlockchainNodesEthereumDetailsValidatorConfig | undefined;
}
export interface BlockchainNodeEngineBlockchainNodesTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/blockchain_node_engine_blockchain_nodes#create BlockchainNodeEngineBlockchainNodes#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/blockchain_node_engine_blockchain_nodes#delete BlockchainNodeEngineBlockchainNodes#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/blockchain_node_engine_blockchain_nodes#update BlockchainNodeEngineBlockchainNodes#update}
    */
    readonly update?: string;
}
export declare function blockchainNodeEngineBlockchainNodesTimeoutsToTerraform(struct?: BlockchainNodeEngineBlockchainNodesTimeouts | cdktn.IResolvable): any;
export declare function blockchainNodeEngineBlockchainNodesTimeoutsToHclTerraform(struct?: BlockchainNodeEngineBlockchainNodesTimeouts | cdktn.IResolvable): any;
export declare class BlockchainNodeEngineBlockchainNodesTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BlockchainNodeEngineBlockchainNodesTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BlockchainNodeEngineBlockchainNodesTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/blockchain_node_engine_blockchain_nodes google_blockchain_node_engine_blockchain_nodes}
*/
export declare class BlockchainNodeEngineBlockchainNodes extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_blockchain_node_engine_blockchain_nodes";
    /**
    * Generates CDKTN code for importing a BlockchainNodeEngineBlockchainNodes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BlockchainNodeEngineBlockchainNodes to import
    * @param importFromId The id of the existing BlockchainNodeEngineBlockchainNodes that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/blockchain_node_engine_blockchain_nodes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BlockchainNodeEngineBlockchainNodes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/blockchain_node_engine_blockchain_nodes google_blockchain_node_engine_blockchain_nodes} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BlockchainNodeEngineBlockchainNodesConfig
    */
    constructor(scope: Construct, id: string, config: BlockchainNodeEngineBlockchainNodesConfig);
    private _blockchainNodeId?;
    get blockchainNodeId(): string;
    set blockchainNodeId(value: string);
    get blockchainNodeIdInput(): string | undefined;
    private _blockchainType?;
    get blockchainType(): string;
    set blockchainType(value: string);
    resetBlockchainType(): void;
    get blockchainTypeInput(): string | undefined;
    private _connectionInfo;
    get connectionInfo(): BlockchainNodeEngineBlockchainNodesConnectionInfoList;
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get updateTime(): string;
    private _ethereumDetails;
    get ethereumDetails(): BlockchainNodeEngineBlockchainNodesEthereumDetailsOutputReference;
    putEthereumDetails(value: BlockchainNodeEngineBlockchainNodesEthereumDetails): void;
    resetEthereumDetails(): void;
    get ethereumDetailsInput(): BlockchainNodeEngineBlockchainNodesEthereumDetails | undefined;
    private _timeouts;
    get timeouts(): BlockchainNodeEngineBlockchainNodesTimeoutsOutputReference;
    putTimeouts(value: BlockchainNodeEngineBlockchainNodesTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BlockchainNodeEngineBlockchainNodesTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
