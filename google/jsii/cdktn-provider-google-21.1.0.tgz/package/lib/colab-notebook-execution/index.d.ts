/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ColabNotebookExecutionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#deletion_policy ColabNotebookExecution#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Required. The display name of the Notebook Execution.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#display_name ColabNotebookExecution#display_name}
    */
    readonly displayName: string;
    /**
    * Max running time of the execution job in seconds (default 86400s / 24 hrs).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#execution_timeout ColabNotebookExecution#execution_timeout}
    */
    readonly executionTimeout?: string;
    /**
    * The user email to run the execution as.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#execution_user ColabNotebookExecution#execution_user}
    */
    readonly executionUser?: string;
    /**
    * The Cloud Storage location to upload the result to. Format:'gs://bucket-name'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#gcs_output_uri ColabNotebookExecution#gcs_output_uri}
    */
    readonly gcsOutputUri: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#id ColabNotebookExecution#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location for the resource: https://cloud.google.com/colab/docs/locations
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#location ColabNotebookExecution#location}
    */
    readonly location: string;
    /**
    * User specified ID for the Notebook Execution Job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#notebook_execution_job_id ColabNotebookExecution#notebook_execution_job_id}
    */
    readonly notebookExecutionJobId?: string;
    /**
    * The NotebookRuntimeTemplate to source compute configuration from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#notebook_runtime_template_resource_name ColabNotebookExecution#notebook_runtime_template_resource_name}
    */
    readonly notebookRuntimeTemplateResourceName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#project ColabNotebookExecution#project}
    */
    readonly project?: string;
    /**
    * The service account to run the execution as.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#service_account ColabNotebookExecution#service_account}
    */
    readonly serviceAccount?: string;
    /**
    * custom_environment_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#custom_environment_spec ColabNotebookExecution#custom_environment_spec}
    */
    readonly customEnvironmentSpec?: ColabNotebookExecutionCustomEnvironmentSpec;
    /**
    * dataform_repository_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#dataform_repository_source ColabNotebookExecution#dataform_repository_source}
    */
    readonly dataformRepositorySource?: ColabNotebookExecutionDataformRepositorySource;
    /**
    * direct_notebook_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#direct_notebook_source ColabNotebookExecution#direct_notebook_source}
    */
    readonly directNotebookSource?: ColabNotebookExecutionDirectNotebookSource;
    /**
    * gcs_notebook_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#gcs_notebook_source ColabNotebookExecution#gcs_notebook_source}
    */
    readonly gcsNotebookSource?: ColabNotebookExecutionGcsNotebookSource;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#timeouts ColabNotebookExecution#timeouts}
    */
    readonly timeouts?: ColabNotebookExecutionTimeouts;
    /**
    * workbench_runtime block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#workbench_runtime ColabNotebookExecution#workbench_runtime}
    */
    readonly workbenchRuntime?: ColabNotebookExecutionWorkbenchRuntime;
}
export interface ColabNotebookExecutionCustomEnvironmentSpecMachineSpec {
    /**
    * The number of accelerators used by the runtime.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#accelerator_count ColabNotebookExecution#accelerator_count}
    */
    readonly acceleratorCount?: number;
    /**
    * The type of hardware accelerator used by the runtime. If specified, acceleratorCount must also be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#accelerator_type ColabNotebookExecution#accelerator_type}
    */
    readonly acceleratorType?: string;
    /**
    * The Compute Engine machine type selected for the runtime.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#machine_type ColabNotebookExecution#machine_type}
    */
    readonly machineType?: string;
}
export declare function colabNotebookExecutionCustomEnvironmentSpecMachineSpecToTerraform(struct?: ColabNotebookExecutionCustomEnvironmentSpecMachineSpecOutputReference | ColabNotebookExecutionCustomEnvironmentSpecMachineSpec): any;
export declare function colabNotebookExecutionCustomEnvironmentSpecMachineSpecToHclTerraform(struct?: ColabNotebookExecutionCustomEnvironmentSpecMachineSpecOutputReference | ColabNotebookExecutionCustomEnvironmentSpecMachineSpec): any;
export declare class ColabNotebookExecutionCustomEnvironmentSpecMachineSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabNotebookExecutionCustomEnvironmentSpecMachineSpec | undefined;
    set internalValue(value: ColabNotebookExecutionCustomEnvironmentSpecMachineSpec | undefined);
    private _acceleratorCount?;
    get acceleratorCount(): number;
    set acceleratorCount(value: number);
    resetAcceleratorCount(): void;
    get acceleratorCountInput(): number | undefined;
    private _acceleratorType?;
    get acceleratorType(): string;
    set acceleratorType(value: string);
    resetAcceleratorType(): void;
    get acceleratorTypeInput(): string | undefined;
    private _machineType?;
    get machineType(): string;
    set machineType(value: string);
    resetMachineType(): void;
    get machineTypeInput(): string | undefined;
}
export interface ColabNotebookExecutionCustomEnvironmentSpecNetworkSpec {
    /**
    * Enable public internet access for the runtime.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#enable_internet_access ColabNotebookExecution#enable_internet_access}
    */
    readonly enableInternetAccess?: boolean | cdktn.IResolvable;
    /**
    * The name of the VPC that this runtime is in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#network ColabNotebookExecution#network}
    */
    readonly network?: string;
    /**
    * The name of the subnetwork that this runtime is in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#subnetwork ColabNotebookExecution#subnetwork}
    */
    readonly subnetwork?: string;
}
export declare function colabNotebookExecutionCustomEnvironmentSpecNetworkSpecToTerraform(struct?: ColabNotebookExecutionCustomEnvironmentSpecNetworkSpecOutputReference | ColabNotebookExecutionCustomEnvironmentSpecNetworkSpec): any;
export declare function colabNotebookExecutionCustomEnvironmentSpecNetworkSpecToHclTerraform(struct?: ColabNotebookExecutionCustomEnvironmentSpecNetworkSpecOutputReference | ColabNotebookExecutionCustomEnvironmentSpecNetworkSpec): any;
export declare class ColabNotebookExecutionCustomEnvironmentSpecNetworkSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabNotebookExecutionCustomEnvironmentSpecNetworkSpec | undefined;
    set internalValue(value: ColabNotebookExecutionCustomEnvironmentSpecNetworkSpec | undefined);
    private _enableInternetAccess?;
    get enableInternetAccess(): boolean | cdktn.IResolvable;
    set enableInternetAccess(value: boolean | cdktn.IResolvable);
    resetEnableInternetAccess(): void;
    get enableInternetAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _network?;
    get network(): string;
    set network(value: string);
    resetNetwork(): void;
    get networkInput(): string | undefined;
    private _subnetwork?;
    get subnetwork(): string;
    set subnetwork(value: string);
    resetSubnetwork(): void;
    get subnetworkInput(): string | undefined;
}
export interface ColabNotebookExecutionCustomEnvironmentSpecPersistentDiskSpec {
    /**
    * The disk size of the runtime in GB. If specified, the diskType must also be specified. The minimum size is 10GB and the maximum is 65536GB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#disk_size_gb ColabNotebookExecution#disk_size_gb}
    */
    readonly diskSizeGb?: string;
    /**
    * The type of the persistent disk.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#disk_type ColabNotebookExecution#disk_type}
    */
    readonly diskType?: string;
}
export declare function colabNotebookExecutionCustomEnvironmentSpecPersistentDiskSpecToTerraform(struct?: ColabNotebookExecutionCustomEnvironmentSpecPersistentDiskSpecOutputReference | ColabNotebookExecutionCustomEnvironmentSpecPersistentDiskSpec): any;
export declare function colabNotebookExecutionCustomEnvironmentSpecPersistentDiskSpecToHclTerraform(struct?: ColabNotebookExecutionCustomEnvironmentSpecPersistentDiskSpecOutputReference | ColabNotebookExecutionCustomEnvironmentSpecPersistentDiskSpec): any;
export declare class ColabNotebookExecutionCustomEnvironmentSpecPersistentDiskSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabNotebookExecutionCustomEnvironmentSpecPersistentDiskSpec | undefined;
    set internalValue(value: ColabNotebookExecutionCustomEnvironmentSpecPersistentDiskSpec | undefined);
    private _diskSizeGb?;
    get diskSizeGb(): string;
    set diskSizeGb(value: string);
    resetDiskSizeGb(): void;
    get diskSizeGbInput(): string | undefined;
    private _diskType?;
    get diskType(): string;
    set diskType(value: string);
    resetDiskType(): void;
    get diskTypeInput(): string | undefined;
}
export interface ColabNotebookExecutionCustomEnvironmentSpecShieldedInstanceConfig {
    /**
    * Defines whether the instance has integrity monitoring enabled. Enables monitoring and attestation of the boot integrity of the instance. The attestation is performed against the integrity policy baseline. This baseline is initially derived from the implicitly trusted boot image when the instance is created. Enabled by default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#enable_integrity_monitoring ColabNotebookExecution#enable_integrity_monitoring}
    */
    readonly enableIntegrityMonitoring?: boolean | cdktn.IResolvable;
    /**
    * Defines whether the instance has Secure Boot enabled. Secure Boot helps ensure that the system only runs authentic software by verifying the digital signature of all boot components, and halting the boot process if signature verification fails. Disabled by default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#enable_secure_boot ColabNotebookExecution#enable_secure_boot}
    */
    readonly enableSecureBoot?: boolean | cdktn.IResolvable;
    /**
    * Defines whether the instance has the vTPM enabled. Enabled by default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#enable_vtpm ColabNotebookExecution#enable_vtpm}
    */
    readonly enableVtpm?: boolean | cdktn.IResolvable;
}
export declare function colabNotebookExecutionCustomEnvironmentSpecShieldedInstanceConfigToTerraform(struct?: ColabNotebookExecutionCustomEnvironmentSpecShieldedInstanceConfigOutputReference | ColabNotebookExecutionCustomEnvironmentSpecShieldedInstanceConfig): any;
export declare function colabNotebookExecutionCustomEnvironmentSpecShieldedInstanceConfigToHclTerraform(struct?: ColabNotebookExecutionCustomEnvironmentSpecShieldedInstanceConfigOutputReference | ColabNotebookExecutionCustomEnvironmentSpecShieldedInstanceConfig): any;
export declare class ColabNotebookExecutionCustomEnvironmentSpecShieldedInstanceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabNotebookExecutionCustomEnvironmentSpecShieldedInstanceConfig | undefined;
    set internalValue(value: ColabNotebookExecutionCustomEnvironmentSpecShieldedInstanceConfig | undefined);
    private _enableIntegrityMonitoring?;
    get enableIntegrityMonitoring(): boolean | cdktn.IResolvable;
    set enableIntegrityMonitoring(value: boolean | cdktn.IResolvable);
    resetEnableIntegrityMonitoring(): void;
    get enableIntegrityMonitoringInput(): boolean | cdktn.IResolvable | undefined;
    private _enableSecureBoot?;
    get enableSecureBoot(): boolean | cdktn.IResolvable;
    set enableSecureBoot(value: boolean | cdktn.IResolvable);
    resetEnableSecureBoot(): void;
    get enableSecureBootInput(): boolean | cdktn.IResolvable | undefined;
    private _enableVtpm?;
    get enableVtpm(): boolean | cdktn.IResolvable;
    set enableVtpm(value: boolean | cdktn.IResolvable);
    resetEnableVtpm(): void;
    get enableVtpmInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ColabNotebookExecutionCustomEnvironmentSpec {
    /**
    * machine_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#machine_spec ColabNotebookExecution#machine_spec}
    */
    readonly machineSpec?: ColabNotebookExecutionCustomEnvironmentSpecMachineSpec;
    /**
    * network_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#network_spec ColabNotebookExecution#network_spec}
    */
    readonly networkSpec?: ColabNotebookExecutionCustomEnvironmentSpecNetworkSpec;
    /**
    * persistent_disk_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#persistent_disk_spec ColabNotebookExecution#persistent_disk_spec}
    */
    readonly persistentDiskSpec?: ColabNotebookExecutionCustomEnvironmentSpecPersistentDiskSpec;
    /**
    * shielded_instance_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#shielded_instance_config ColabNotebookExecution#shielded_instance_config}
    */
    readonly shieldedInstanceConfig?: ColabNotebookExecutionCustomEnvironmentSpecShieldedInstanceConfig;
}
export declare function colabNotebookExecutionCustomEnvironmentSpecToTerraform(struct?: ColabNotebookExecutionCustomEnvironmentSpecOutputReference | ColabNotebookExecutionCustomEnvironmentSpec): any;
export declare function colabNotebookExecutionCustomEnvironmentSpecToHclTerraform(struct?: ColabNotebookExecutionCustomEnvironmentSpecOutputReference | ColabNotebookExecutionCustomEnvironmentSpec): any;
export declare class ColabNotebookExecutionCustomEnvironmentSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabNotebookExecutionCustomEnvironmentSpec | undefined;
    set internalValue(value: ColabNotebookExecutionCustomEnvironmentSpec | undefined);
    private _machineSpec;
    get machineSpec(): ColabNotebookExecutionCustomEnvironmentSpecMachineSpecOutputReference;
    putMachineSpec(value: ColabNotebookExecutionCustomEnvironmentSpecMachineSpec): void;
    resetMachineSpec(): void;
    get machineSpecInput(): ColabNotebookExecutionCustomEnvironmentSpecMachineSpec | undefined;
    private _networkSpec;
    get networkSpec(): ColabNotebookExecutionCustomEnvironmentSpecNetworkSpecOutputReference;
    putNetworkSpec(value: ColabNotebookExecutionCustomEnvironmentSpecNetworkSpec): void;
    resetNetworkSpec(): void;
    get networkSpecInput(): ColabNotebookExecutionCustomEnvironmentSpecNetworkSpec | undefined;
    private _persistentDiskSpec;
    get persistentDiskSpec(): ColabNotebookExecutionCustomEnvironmentSpecPersistentDiskSpecOutputReference;
    putPersistentDiskSpec(value: ColabNotebookExecutionCustomEnvironmentSpecPersistentDiskSpec): void;
    resetPersistentDiskSpec(): void;
    get persistentDiskSpecInput(): ColabNotebookExecutionCustomEnvironmentSpecPersistentDiskSpec | undefined;
    private _shieldedInstanceConfig;
    get shieldedInstanceConfig(): ColabNotebookExecutionCustomEnvironmentSpecShieldedInstanceConfigOutputReference;
    putShieldedInstanceConfig(value: ColabNotebookExecutionCustomEnvironmentSpecShieldedInstanceConfig): void;
    resetShieldedInstanceConfig(): void;
    get shieldedInstanceConfigInput(): ColabNotebookExecutionCustomEnvironmentSpecShieldedInstanceConfig | undefined;
}
export interface ColabNotebookExecutionDataformRepositorySource {
    /**
    * The commit SHA to read repository with. If unset, the file will be read at HEAD.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#commit_sha ColabNotebookExecution#commit_sha}
    */
    readonly commitSha?: string;
    /**
    * The resource name of the Dataform Repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#dataform_repository_resource_name ColabNotebookExecution#dataform_repository_resource_name}
    */
    readonly dataformRepositoryResourceName: string;
}
export declare function colabNotebookExecutionDataformRepositorySourceToTerraform(struct?: ColabNotebookExecutionDataformRepositorySourceOutputReference | ColabNotebookExecutionDataformRepositorySource): any;
export declare function colabNotebookExecutionDataformRepositorySourceToHclTerraform(struct?: ColabNotebookExecutionDataformRepositorySourceOutputReference | ColabNotebookExecutionDataformRepositorySource): any;
export declare class ColabNotebookExecutionDataformRepositorySourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabNotebookExecutionDataformRepositorySource | undefined;
    set internalValue(value: ColabNotebookExecutionDataformRepositorySource | undefined);
    private _commitSha?;
    get commitSha(): string;
    set commitSha(value: string);
    resetCommitSha(): void;
    get commitShaInput(): string | undefined;
    private _dataformRepositoryResourceName?;
    get dataformRepositoryResourceName(): string;
    set dataformRepositoryResourceName(value: string);
    get dataformRepositoryResourceNameInput(): string | undefined;
}
export interface ColabNotebookExecutionDirectNotebookSource {
    /**
    * The base64-encoded contents of the input notebook file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#content ColabNotebookExecution#content}
    */
    readonly content: string;
}
export declare function colabNotebookExecutionDirectNotebookSourceToTerraform(struct?: ColabNotebookExecutionDirectNotebookSourceOutputReference | ColabNotebookExecutionDirectNotebookSource): any;
export declare function colabNotebookExecutionDirectNotebookSourceToHclTerraform(struct?: ColabNotebookExecutionDirectNotebookSourceOutputReference | ColabNotebookExecutionDirectNotebookSource): any;
export declare class ColabNotebookExecutionDirectNotebookSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabNotebookExecutionDirectNotebookSource | undefined;
    set internalValue(value: ColabNotebookExecutionDirectNotebookSource | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
}
export interface ColabNotebookExecutionGcsNotebookSource {
    /**
    * The version of the Cloud Storage object to read. If unset, the current version of the object is read. See https://cloud.google.com/storage/docs/metadata#generation-number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#generation ColabNotebookExecution#generation}
    */
    readonly generation?: string;
    /**
    * The Cloud Storage uri pointing to the ipynb file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#uri ColabNotebookExecution#uri}
    */
    readonly uri: string;
}
export declare function colabNotebookExecutionGcsNotebookSourceToTerraform(struct?: ColabNotebookExecutionGcsNotebookSourceOutputReference | ColabNotebookExecutionGcsNotebookSource): any;
export declare function colabNotebookExecutionGcsNotebookSourceToHclTerraform(struct?: ColabNotebookExecutionGcsNotebookSourceOutputReference | ColabNotebookExecutionGcsNotebookSource): any;
export declare class ColabNotebookExecutionGcsNotebookSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabNotebookExecutionGcsNotebookSource | undefined;
    set internalValue(value: ColabNotebookExecutionGcsNotebookSource | undefined);
    private _generation?;
    get generation(): string;
    set generation(value: string);
    resetGeneration(): void;
    get generationInput(): string | undefined;
    private _uri?;
    get uri(): string;
    set uri(value: string);
    get uriInput(): string | undefined;
}
export interface ColabNotebookExecutionTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#create ColabNotebookExecution#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#delete ColabNotebookExecution#delete}
    */
    readonly delete?: string;
}
export declare function colabNotebookExecutionTimeoutsToTerraform(struct?: ColabNotebookExecutionTimeouts | cdktn.IResolvable): any;
export declare function colabNotebookExecutionTimeoutsToHclTerraform(struct?: ColabNotebookExecutionTimeouts | cdktn.IResolvable): any;
export declare class ColabNotebookExecutionTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabNotebookExecutionTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ColabNotebookExecutionTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
export interface ColabNotebookExecutionWorkbenchRuntimeVmImage {
    /**
    * Use this VM image family to find the image; the newest image in this family will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#family ColabNotebookExecution#family}
    */
    readonly family?: string;
    /**
    * Use VM image name to find the image.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#name ColabNotebookExecution#name}
    */
    readonly name?: string;
    /**
    * The name of the Google Cloud project that this VM image belongs to. Format: {project_id}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#project ColabNotebookExecution#project}
    */
    readonly project?: string;
}
export declare function colabNotebookExecutionWorkbenchRuntimeVmImageToTerraform(struct?: ColabNotebookExecutionWorkbenchRuntimeVmImageOutputReference | ColabNotebookExecutionWorkbenchRuntimeVmImage): any;
export declare function colabNotebookExecutionWorkbenchRuntimeVmImageToHclTerraform(struct?: ColabNotebookExecutionWorkbenchRuntimeVmImageOutputReference | ColabNotebookExecutionWorkbenchRuntimeVmImage): any;
export declare class ColabNotebookExecutionWorkbenchRuntimeVmImageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabNotebookExecutionWorkbenchRuntimeVmImage | undefined;
    set internalValue(value: ColabNotebookExecutionWorkbenchRuntimeVmImage | undefined);
    private _family?;
    get family(): string;
    set family(value: string);
    resetFamily(): void;
    get familyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
}
export interface ColabNotebookExecutionWorkbenchRuntime {
    /**
    * vm_image block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#vm_image ColabNotebookExecution#vm_image}
    */
    readonly vmImage: ColabNotebookExecutionWorkbenchRuntimeVmImage;
}
export declare function colabNotebookExecutionWorkbenchRuntimeToTerraform(struct?: ColabNotebookExecutionWorkbenchRuntimeOutputReference | ColabNotebookExecutionWorkbenchRuntime): any;
export declare function colabNotebookExecutionWorkbenchRuntimeToHclTerraform(struct?: ColabNotebookExecutionWorkbenchRuntimeOutputReference | ColabNotebookExecutionWorkbenchRuntime): any;
export declare class ColabNotebookExecutionWorkbenchRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ColabNotebookExecutionWorkbenchRuntime | undefined;
    set internalValue(value: ColabNotebookExecutionWorkbenchRuntime | undefined);
    private _vmImage;
    get vmImage(): ColabNotebookExecutionWorkbenchRuntimeVmImageOutputReference;
    putVmImage(value: ColabNotebookExecutionWorkbenchRuntimeVmImage): void;
    get vmImageInput(): ColabNotebookExecutionWorkbenchRuntimeVmImage | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution google_colab_notebook_execution}
*/
export declare class ColabNotebookExecution extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_colab_notebook_execution";
    /**
    * Generates CDKTN code for importing a ColabNotebookExecution resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ColabNotebookExecution to import
    * @param importFromId The id of the existing ColabNotebookExecution that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ColabNotebookExecution to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/colab_notebook_execution google_colab_notebook_execution} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ColabNotebookExecutionConfig
    */
    constructor(scope: Construct, id: string, config: ColabNotebookExecutionConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _executionTimeout?;
    get executionTimeout(): string;
    set executionTimeout(value: string);
    resetExecutionTimeout(): void;
    get executionTimeoutInput(): string | undefined;
    private _executionUser?;
    get executionUser(): string;
    set executionUser(value: string);
    resetExecutionUser(): void;
    get executionUserInput(): string | undefined;
    private _gcsOutputUri?;
    get gcsOutputUri(): string;
    set gcsOutputUri(value: string);
    get gcsOutputUriInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _notebookExecutionJobId?;
    get notebookExecutionJobId(): string;
    set notebookExecutionJobId(value: string);
    resetNotebookExecutionJobId(): void;
    get notebookExecutionJobIdInput(): string | undefined;
    private _notebookRuntimeTemplateResourceName?;
    get notebookRuntimeTemplateResourceName(): string;
    set notebookRuntimeTemplateResourceName(value: string);
    resetNotebookRuntimeTemplateResourceName(): void;
    get notebookRuntimeTemplateResourceNameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _serviceAccount?;
    get serviceAccount(): string;
    set serviceAccount(value: string);
    resetServiceAccount(): void;
    get serviceAccountInput(): string | undefined;
    private _customEnvironmentSpec;
    get customEnvironmentSpec(): ColabNotebookExecutionCustomEnvironmentSpecOutputReference;
    putCustomEnvironmentSpec(value: ColabNotebookExecutionCustomEnvironmentSpec): void;
    resetCustomEnvironmentSpec(): void;
    get customEnvironmentSpecInput(): ColabNotebookExecutionCustomEnvironmentSpec | undefined;
    private _dataformRepositorySource;
    get dataformRepositorySource(): ColabNotebookExecutionDataformRepositorySourceOutputReference;
    putDataformRepositorySource(value: ColabNotebookExecutionDataformRepositorySource): void;
    resetDataformRepositorySource(): void;
    get dataformRepositorySourceInput(): ColabNotebookExecutionDataformRepositorySource | undefined;
    private _directNotebookSource;
    get directNotebookSource(): ColabNotebookExecutionDirectNotebookSourceOutputReference;
    putDirectNotebookSource(value: ColabNotebookExecutionDirectNotebookSource): void;
    resetDirectNotebookSource(): void;
    get directNotebookSourceInput(): ColabNotebookExecutionDirectNotebookSource | undefined;
    private _gcsNotebookSource;
    get gcsNotebookSource(): ColabNotebookExecutionGcsNotebookSourceOutputReference;
    putGcsNotebookSource(value: ColabNotebookExecutionGcsNotebookSource): void;
    resetGcsNotebookSource(): void;
    get gcsNotebookSourceInput(): ColabNotebookExecutionGcsNotebookSource | undefined;
    private _timeouts;
    get timeouts(): ColabNotebookExecutionTimeoutsOutputReference;
    putTimeouts(value: ColabNotebookExecutionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ColabNotebookExecutionTimeouts | undefined;
    private _workbenchRuntime;
    get workbenchRuntime(): ColabNotebookExecutionWorkbenchRuntimeOutputReference;
    putWorkbenchRuntime(value: ColabNotebookExecutionWorkbenchRuntime): void;
    resetWorkbenchRuntime(): void;
    get workbenchRuntimeInput(): ColabNotebookExecutionWorkbenchRuntime | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
