/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeNodeGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_node_group#deletion_policy ComputeNodeGroup#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional textual description of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_node_group#description ComputeNodeGroup#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_node_group#id ComputeNodeGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The initial number of nodes in the node group. One of 'initial_size' or 'autoscaling_policy' must be configured on resource creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_node_group#initial_size ComputeNodeGroup#initial_size}
    */
    readonly initialSize?: number;
    /**
    * Specifies how to handle instances when a node in the group undergoes maintenance. Set to one of: DEFAULT, RESTART_IN_PLACE, or MIGRATE_WITHIN_NODE_GROUP. The default value is DEFAULT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_node_group#maintenance_policy ComputeNodeGroup#maintenance_policy}
    */
    readonly maintenancePolicy?: string;
    /**
    * Name of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_node_group#name ComputeNodeGroup#name}
    */
    readonly name: string;
    /**
    * The URL of the node template to which this node group belongs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_node_group#node_template ComputeNodeGroup#node_template}
    */
    readonly nodeTemplate: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_node_group#project ComputeNodeGroup#project}
    */
    readonly project?: string;
    /**
    * Zone where this node group is located
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_node_group#zone ComputeNodeGroup#zone}
    */
    readonly zone?: string;
    /**
    * autoscaling_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_node_group#autoscaling_policy ComputeNodeGroup#autoscaling_policy}
    */
    readonly autoscalingPolicy?: ComputeNodeGroupAutoscalingPolicy;
    /**
    * maintenance_window block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_node_group#maintenance_window ComputeNodeGroup#maintenance_window}
    */
    readonly maintenanceWindow?: ComputeNodeGroupMaintenanceWindow;
    /**
    * share_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_node_group#share_settings ComputeNodeGroup#share_settings}
    */
    readonly shareSettings?: ComputeNodeGroupShareSettings;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_node_group#timeouts ComputeNodeGroup#timeouts}
    */
    readonly timeouts?: ComputeNodeGroupTimeouts;
}
export interface ComputeNodeGroupAutoscalingPolicy {
    /**
    * Maximum size of the node group. Set to a value less than or equal
    * to 100 and greater than or equal to min-nodes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_node_group#max_nodes ComputeNodeGroup#max_nodes}
    */
    readonly maxNodes?: number;
    /**
    * Minimum size of the node group. Must be less
    * than or equal to max-nodes. The default value is 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_node_group#min_nodes ComputeNodeGroup#min_nodes}
    */
    readonly minNodes?: number;
    /**
    * The autoscaling mode. Set to one of the following:
    *   - OFF: Disables the autoscaler.
    *   - ON: Enables scaling in and scaling out.
    *   - ONLY_SCALE_OUT: Enables only scaling out.
    *   You must use this mode if your node groups are configured to
    *   restart their hosted VMs on minimal servers. Possible values: ["OFF", "ON", "ONLY_SCALE_OUT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_node_group#mode ComputeNodeGroup#mode}
    */
    readonly mode?: string;
}
export declare function computeNodeGroupAutoscalingPolicyToTerraform(struct?: ComputeNodeGroupAutoscalingPolicyOutputReference | ComputeNodeGroupAutoscalingPolicy): any;
export declare function computeNodeGroupAutoscalingPolicyToHclTerraform(struct?: ComputeNodeGroupAutoscalingPolicyOutputReference | ComputeNodeGroupAutoscalingPolicy): any;
export declare class ComputeNodeGroupAutoscalingPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeNodeGroupAutoscalingPolicy | undefined;
    set internalValue(value: ComputeNodeGroupAutoscalingPolicy | undefined);
    private _maxNodes?;
    get maxNodes(): number;
    set maxNodes(value: number);
    resetMaxNodes(): void;
    get maxNodesInput(): number | undefined;
    private _minNodes?;
    get minNodes(): number;
    set minNodes(value: number);
    resetMinNodes(): void;
    get minNodesInput(): number | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
}
export interface ComputeNodeGroupMaintenanceWindow {
    /**
    * instances.start time of the window. This must be in UTC format that resolves to one of 00:00, 04:00, 08:00, 12:00, 16:00, or 20:00. For example, both 13:00-5 and 08:00 are valid.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_node_group#start_time ComputeNodeGroup#start_time}
    */
    readonly startTime: string;
}
export declare function computeNodeGroupMaintenanceWindowToTerraform(struct?: ComputeNodeGroupMaintenanceWindowOutputReference | ComputeNodeGroupMaintenanceWindow): any;
export declare function computeNodeGroupMaintenanceWindowToHclTerraform(struct?: ComputeNodeGroupMaintenanceWindowOutputReference | ComputeNodeGroupMaintenanceWindow): any;
export declare class ComputeNodeGroupMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeNodeGroupMaintenanceWindow | undefined;
    set internalValue(value: ComputeNodeGroupMaintenanceWindow | undefined);
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    get startTimeInput(): string | undefined;
}
export interface ComputeNodeGroupShareSettingsProjectMap {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_node_group#id ComputeNodeGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * The project id/number should be the same as the key of this project config in the project map.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_node_group#project_id ComputeNodeGroup#project_id}
    */
    readonly projectId: string;
}
export declare function computeNodeGroupShareSettingsProjectMapToTerraform(struct?: ComputeNodeGroupShareSettingsProjectMap | cdktn.IResolvable): any;
export declare function computeNodeGroupShareSettingsProjectMapToHclTerraform(struct?: ComputeNodeGroupShareSettingsProjectMap | cdktn.IResolvable): any;
export declare class ComputeNodeGroupShareSettingsProjectMapOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeNodeGroupShareSettingsProjectMap | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeNodeGroupShareSettingsProjectMap | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
}
export declare class ComputeNodeGroupShareSettingsProjectMapList extends cdktn.ComplexList {
    internalValue?: ComputeNodeGroupShareSettingsProjectMap[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeNodeGroupShareSettingsProjectMapOutputReference;
}
export interface ComputeNodeGroupShareSettings {
    /**
    * Node group sharing type. Possible values: ["ORGANIZATION", "SPECIFIC_PROJECTS", "LOCAL"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_node_group#share_type ComputeNodeGroup#share_type}
    */
    readonly shareType: string;
    /**
    * project_map block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_node_group#project_map ComputeNodeGroup#project_map}
    */
    readonly projectMap?: ComputeNodeGroupShareSettingsProjectMap[] | cdktn.IResolvable;
}
export declare function computeNodeGroupShareSettingsToTerraform(struct?: ComputeNodeGroupShareSettingsOutputReference | ComputeNodeGroupShareSettings): any;
export declare function computeNodeGroupShareSettingsToHclTerraform(struct?: ComputeNodeGroupShareSettingsOutputReference | ComputeNodeGroupShareSettings): any;
export declare class ComputeNodeGroupShareSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeNodeGroupShareSettings | undefined;
    set internalValue(value: ComputeNodeGroupShareSettings | undefined);
    private _shareType?;
    get shareType(): string;
    set shareType(value: string);
    get shareTypeInput(): string | undefined;
    private _projectMap;
    get projectMap(): ComputeNodeGroupShareSettingsProjectMapList;
    putProjectMap(value: ComputeNodeGroupShareSettingsProjectMap[] | cdktn.IResolvable): void;
    resetProjectMap(): void;
    get projectMapInput(): cdktn.IResolvable | ComputeNodeGroupShareSettingsProjectMap[] | undefined;
}
export interface ComputeNodeGroupTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_node_group#create ComputeNodeGroup#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_node_group#delete ComputeNodeGroup#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_node_group#update ComputeNodeGroup#update}
    */
    readonly update?: string;
}
export declare function computeNodeGroupTimeoutsToTerraform(struct?: ComputeNodeGroupTimeouts | cdktn.IResolvable): any;
export declare function computeNodeGroupTimeoutsToHclTerraform(struct?: ComputeNodeGroupTimeouts | cdktn.IResolvable): any;
export declare class ComputeNodeGroupTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeNodeGroupTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeNodeGroupTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_node_group google_compute_node_group}
*/
export declare class ComputeNodeGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_node_group";
    /**
    * Generates CDKTN code for importing a ComputeNodeGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeNodeGroup to import
    * @param importFromId The id of the existing ComputeNodeGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_node_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeNodeGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_node_group google_compute_node_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeNodeGroupConfig
    */
    constructor(scope: Construct, id: string, config: ComputeNodeGroupConfig);
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _initialSize?;
    get initialSize(): number;
    set initialSize(value: number);
    resetInitialSize(): void;
    get initialSizeInput(): number | undefined;
    private _maintenancePolicy?;
    get maintenancePolicy(): string;
    set maintenancePolicy(value: string);
    resetMaintenancePolicy(): void;
    get maintenancePolicyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nodeTemplate?;
    get nodeTemplate(): string;
    set nodeTemplate(value: string);
    get nodeTemplateInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get selfLink(): string;
    get size(): number;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    resetZone(): void;
    get zoneInput(): string | undefined;
    private _autoscalingPolicy;
    get autoscalingPolicy(): ComputeNodeGroupAutoscalingPolicyOutputReference;
    putAutoscalingPolicy(value: ComputeNodeGroupAutoscalingPolicy): void;
    resetAutoscalingPolicy(): void;
    get autoscalingPolicyInput(): ComputeNodeGroupAutoscalingPolicy | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): ComputeNodeGroupMaintenanceWindowOutputReference;
    putMaintenanceWindow(value: ComputeNodeGroupMaintenanceWindow): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): ComputeNodeGroupMaintenanceWindow | undefined;
    private _shareSettings;
    get shareSettings(): ComputeNodeGroupShareSettingsOutputReference;
    putShareSettings(value: ComputeNodeGroupShareSettings): void;
    resetShareSettings(): void;
    get shareSettingsInput(): ComputeNodeGroupShareSettings | undefined;
    private _timeouts;
    get timeouts(): ComputeNodeGroupTimeoutsOutputReference;
    putTimeouts(value: ComputeNodeGroupTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeNodeGroupTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
