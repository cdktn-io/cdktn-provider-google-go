/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CertificateManagerCertificateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate#deletion_policy CertificateManagerCertificate#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * A human-readable description of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate#description CertificateManagerCertificate#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate#id CertificateManagerCertificate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Set of label tags associated with the Certificate resource.
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate#labels CertificateManagerCertificate#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The Certificate Manager location. If not specified, "global" is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate#location CertificateManagerCertificate#location}
    */
    readonly location?: string;
    /**
    * A user-defined name of the certificate. Certificate names must be unique
    * The name must be 1-64 characters long, and match the regular expression [a-zA-Z][a-zA-Z0-9_-]* which means the first character must be a letter,
    * and all following characters must be a dash, underscore, letter or digit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate#name CertificateManagerCertificate#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate#project CertificateManagerCertificate#project}
    */
    readonly project?: string;
    /**
    * The scope of the certificate.
    *
    * DEFAULT: Certificates with default scope are served from core Google data centers.
    * If unsure, choose this option.
    *
    * EDGE_CACHE: Certificates with scope EDGE_CACHE are special-purposed certificates, served from Edge Points of Presence.
    * See https://cloud.google.com/vpc/docs/edge-locations.
    *
    * ALL_REGIONS: Certificates with ALL_REGIONS scope are served from all GCP regions (You can only use ALL_REGIONS with global certs).
    * See https://cloud.google.com/compute/docs/regions-zones.
    *
    * CLIENT_AUTH: Certificates with CLIENT_AUTH scope are used by a load balancer (TLS client) to be presented to the backend (TLS server) when backend mTLS is configured.
    * See https://cloud.google.com/load-balancing/docs/backend-authenticated-tls-backend-mtls#client-certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate#scope CertificateManagerCertificate#scope}
    */
    readonly scope?: string;
    /**
    * managed block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate#managed CertificateManagerCertificate#managed}
    */
    readonly managed?: CertificateManagerCertificateManaged;
    /**
    * self_managed block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate#self_managed CertificateManagerCertificate#self_managed}
    */
    readonly selfManaged?: CertificateManagerCertificateSelfManaged;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate#timeouts CertificateManagerCertificate#timeouts}
    */
    readonly timeouts?: CertificateManagerCertificateTimeouts;
}
export interface CertificateManagerCertificateManagedAuthorizationAttemptInfo {
}
export declare function certificateManagerCertificateManagedAuthorizationAttemptInfoToTerraform(struct?: CertificateManagerCertificateManagedAuthorizationAttemptInfo): any;
export declare function certificateManagerCertificateManagedAuthorizationAttemptInfoToHclTerraform(struct?: CertificateManagerCertificateManagedAuthorizationAttemptInfo): any;
export declare class CertificateManagerCertificateManagedAuthorizationAttemptInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CertificateManagerCertificateManagedAuthorizationAttemptInfo | undefined;
    set internalValue(value: CertificateManagerCertificateManagedAuthorizationAttemptInfo | undefined);
    get details(): string;
    get domain(): string;
    get failureReason(): string;
    get state(): string;
}
export declare class CertificateManagerCertificateManagedAuthorizationAttemptInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CertificateManagerCertificateManagedAuthorizationAttemptInfoOutputReference;
}
export interface CertificateManagerCertificateManagedProvisioningIssue {
}
export declare function certificateManagerCertificateManagedProvisioningIssueToTerraform(struct?: CertificateManagerCertificateManagedProvisioningIssue): any;
export declare function certificateManagerCertificateManagedProvisioningIssueToHclTerraform(struct?: CertificateManagerCertificateManagedProvisioningIssue): any;
export declare class CertificateManagerCertificateManagedProvisioningIssueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CertificateManagerCertificateManagedProvisioningIssue | undefined;
    set internalValue(value: CertificateManagerCertificateManagedProvisioningIssue | undefined);
    get details(): string;
    get reason(): string;
}
export declare class CertificateManagerCertificateManagedProvisioningIssueList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CertificateManagerCertificateManagedProvisioningIssueOutputReference;
}
export interface CertificateManagerCertificateManaged {
    /**
    * Authorizations that will be used for performing domain authorization. Either issuanceConfig or dnsAuthorizations should be specificed, but not both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate#dns_authorizations CertificateManagerCertificate#dns_authorizations}
    */
    readonly dnsAuthorizations?: string[];
    /**
    * The domains for which a managed SSL certificate will be generated.
    * Wildcard domains are only supported with DNS challenge resolution
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate#domains CertificateManagerCertificate#domains}
    */
    readonly domains?: string[];
    /**
    * The resource name for a CertificateIssuanceConfig used to configure private PKI certificates in the format projects/* /locations/* /certificateIssuanceConfigs/*.
    * If this field is not set, the certificates will instead be publicly signed as documented at https://cloud.google.com/load-balancing/docs/ssl-certificates/google-managed-certs#caa.
    * Either issuanceConfig or dnsAuthorizations should be specificed, but not both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate#issuance_config CertificateManagerCertificate#issuance_config}
     *
    * Note: The above comment contained a comment block ending sequence (* followed by /). We have introduced a space between to prevent syntax errors. Please ignore the space.
    */
    readonly issuanceConfig?: string;
}
export declare function certificateManagerCertificateManagedToTerraform(struct?: CertificateManagerCertificateManagedOutputReference | CertificateManagerCertificateManaged): any;
export declare function certificateManagerCertificateManagedToHclTerraform(struct?: CertificateManagerCertificateManagedOutputReference | CertificateManagerCertificateManaged): any;
export declare class CertificateManagerCertificateManagedOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CertificateManagerCertificateManaged | undefined;
    set internalValue(value: CertificateManagerCertificateManaged | undefined);
    private _authorizationAttemptInfo;
    get authorizationAttemptInfo(): CertificateManagerCertificateManagedAuthorizationAttemptInfoList;
    private _dnsAuthorizations?;
    get dnsAuthorizations(): string[];
    set dnsAuthorizations(value: string[]);
    resetDnsAuthorizations(): void;
    get dnsAuthorizationsInput(): string[] | undefined;
    private _domains?;
    get domains(): string[];
    set domains(value: string[]);
    resetDomains(): void;
    get domainsInput(): string[] | undefined;
    private _issuanceConfig?;
    get issuanceConfig(): string;
    set issuanceConfig(value: string);
    resetIssuanceConfig(): void;
    get issuanceConfigInput(): string | undefined;
    private _provisioningIssue;
    get provisioningIssue(): CertificateManagerCertificateManagedProvisioningIssueList;
    get state(): string;
}
export interface CertificateManagerCertificateSelfManaged {
    /**
    * The certificate chain in PEM-encoded form.
    *
    * Leaf certificate comes first, followed by intermediate ones if any.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate#certificate_pem CertificateManagerCertificate#certificate_pem}
    */
    readonly certificatePem?: string;
    /**
    * The certificate chain in PEM-encoded form.
    *
    * Leaf certificate comes first, followed by intermediate ones if any.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate#pem_certificate CertificateManagerCertificate#pem_certificate}
    */
    readonly pemCertificate?: string;
    /**
    * The private key of the leaf certificate in PEM-encoded form.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate#pem_private_key CertificateManagerCertificate#pem_private_key}
    */
    readonly pemPrivateKey?: string;
    /**
    * The private key of the leaf certificate in PEM-encoded form.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate#pem_private_key_wo CertificateManagerCertificate#pem_private_key_wo}
    */
    readonly pemPrivateKeyWo?: string;
    /**
    * Triggers update of 'pem_private_key_wo' write-only. Increment this value when an update to 'pem_private_key_wo' is needed. For more info see [updating write-only arguments](/docs/providers/google/guides/using_write_only_arguments.html#updating-write-only-arguments)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate#pem_private_key_wo_version CertificateManagerCertificate#pem_private_key_wo_version}
    */
    readonly pemPrivateKeyWoVersion?: string;
    /**
    * The private key of the leaf certificate in PEM-encoded form.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate#private_key_pem CertificateManagerCertificate#private_key_pem}
    */
    readonly privateKeyPem?: string;
}
export declare function certificateManagerCertificateSelfManagedToTerraform(struct?: CertificateManagerCertificateSelfManagedOutputReference | CertificateManagerCertificateSelfManaged): any;
export declare function certificateManagerCertificateSelfManagedToHclTerraform(struct?: CertificateManagerCertificateSelfManagedOutputReference | CertificateManagerCertificateSelfManaged): any;
export declare class CertificateManagerCertificateSelfManagedOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CertificateManagerCertificateSelfManaged | undefined;
    set internalValue(value: CertificateManagerCertificateSelfManaged | undefined);
    private _certificatePem?;
    get certificatePem(): string;
    set certificatePem(value: string);
    resetCertificatePem(): void;
    get certificatePemInput(): string | undefined;
    private _pemCertificate?;
    get pemCertificate(): string;
    set pemCertificate(value: string);
    resetPemCertificate(): void;
    get pemCertificateInput(): string | undefined;
    private _pemPrivateKey?;
    get pemPrivateKey(): string;
    set pemPrivateKey(value: string);
    resetPemPrivateKey(): void;
    get pemPrivateKeyInput(): string | undefined;
    private _pemPrivateKeyWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get pemPrivateKeyWo(): string;
    set pemPrivateKeyWo(value: string);
    resetPemPrivateKeyWo(): void;
    get pemPrivateKeyWoInput(): string | undefined;
    private _pemPrivateKeyWoVersion?;
    get pemPrivateKeyWoVersion(): string;
    set pemPrivateKeyWoVersion(value: string);
    resetPemPrivateKeyWoVersion(): void;
    get pemPrivateKeyWoVersionInput(): string | undefined;
    private _privateKeyPem?;
    get privateKeyPem(): string;
    set privateKeyPem(value: string);
    resetPrivateKeyPem(): void;
    get privateKeyPemInput(): string | undefined;
}
export interface CertificateManagerCertificateTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate#create CertificateManagerCertificate#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate#delete CertificateManagerCertificate#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate#update CertificateManagerCertificate#update}
    */
    readonly update?: string;
}
export declare function certificateManagerCertificateTimeoutsToTerraform(struct?: CertificateManagerCertificateTimeouts | cdktn.IResolvable): any;
export declare function certificateManagerCertificateTimeoutsToHclTerraform(struct?: CertificateManagerCertificateTimeouts | cdktn.IResolvable): any;
export declare class CertificateManagerCertificateTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CertificateManagerCertificateTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CertificateManagerCertificateTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate google_certificate_manager_certificate}
*/
export declare class CertificateManagerCertificate extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_certificate_manager_certificate";
    /**
    * Generates CDKTN code for importing a CertificateManagerCertificate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CertificateManagerCertificate to import
    * @param importFromId The id of the existing CertificateManagerCertificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CertificateManagerCertificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate google_certificate_manager_certificate} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CertificateManagerCertificateConfig
    */
    constructor(scope: Construct, id: string, config: CertificateManagerCertificateConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get sanDnsnames(): string[];
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _managed;
    get managed(): CertificateManagerCertificateManagedOutputReference;
    putManaged(value: CertificateManagerCertificateManaged): void;
    resetManaged(): void;
    get managedInput(): CertificateManagerCertificateManaged | undefined;
    private _selfManaged;
    get selfManaged(): CertificateManagerCertificateSelfManagedOutputReference;
    putSelfManaged(value: CertificateManagerCertificateSelfManaged): void;
    resetSelfManaged(): void;
    get selfManagedInput(): CertificateManagerCertificateSelfManaged | undefined;
    private _timeouts;
    get timeouts(): CertificateManagerCertificateTimeoutsOutputReference;
    putTimeouts(value: CertificateManagerCertificateTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CertificateManagerCertificateTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
