/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CertificateManagerCertificateMapConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate_map#deletion_policy CertificateManagerCertificateMap#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * A human-readable description of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate_map#description CertificateManagerCertificateMap#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate_map#id CertificateManagerCertificateMap#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Set of labels associated with a Certificate Map resource.
    *
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate_map#labels CertificateManagerCertificateMap#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * A user-defined name of the Certificate Map. Certificate Map names must be unique
    * globally and match the pattern 'projects/* /locations/* /certificateMaps/*'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate_map#name CertificateManagerCertificateMap#name}
     *
    * Note: The above comment contained a comment block ending sequence (* followed by /). We have introduced a space between to prevent syntax errors. Please ignore the space.
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate_map#project CertificateManagerCertificateMap#project}
    */
    readonly project?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate_map#timeouts CertificateManagerCertificateMap#timeouts}
    */
    readonly timeouts?: CertificateManagerCertificateMapTimeouts;
}
export interface CertificateManagerCertificateMapGclbTargetsIpConfigs {
}
export declare function certificateManagerCertificateMapGclbTargetsIpConfigsToTerraform(struct?: CertificateManagerCertificateMapGclbTargetsIpConfigs): any;
export declare function certificateManagerCertificateMapGclbTargetsIpConfigsToHclTerraform(struct?: CertificateManagerCertificateMapGclbTargetsIpConfigs): any;
export declare class CertificateManagerCertificateMapGclbTargetsIpConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CertificateManagerCertificateMapGclbTargetsIpConfigs | undefined;
    set internalValue(value: CertificateManagerCertificateMapGclbTargetsIpConfigs | undefined);
    get ipAddress(): string;
    get ports(): number[];
}
export declare class CertificateManagerCertificateMapGclbTargetsIpConfigsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CertificateManagerCertificateMapGclbTargetsIpConfigsOutputReference;
}
export interface CertificateManagerCertificateMapGclbTargets {
}
export declare function certificateManagerCertificateMapGclbTargetsToTerraform(struct?: CertificateManagerCertificateMapGclbTargets): any;
export declare function certificateManagerCertificateMapGclbTargetsToHclTerraform(struct?: CertificateManagerCertificateMapGclbTargets): any;
export declare class CertificateManagerCertificateMapGclbTargetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CertificateManagerCertificateMapGclbTargets | undefined;
    set internalValue(value: CertificateManagerCertificateMapGclbTargets | undefined);
    private _ipConfigs;
    get ipConfigs(): CertificateManagerCertificateMapGclbTargetsIpConfigsList;
    get targetHttpsProxy(): string;
    get targetSslProxy(): string;
}
export declare class CertificateManagerCertificateMapGclbTargetsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CertificateManagerCertificateMapGclbTargetsOutputReference;
}
export interface CertificateManagerCertificateMapTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate_map#create CertificateManagerCertificateMap#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate_map#delete CertificateManagerCertificateMap#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate_map#update CertificateManagerCertificateMap#update}
    */
    readonly update?: string;
}
export declare function certificateManagerCertificateMapTimeoutsToTerraform(struct?: CertificateManagerCertificateMapTimeouts | cdktn.IResolvable): any;
export declare function certificateManagerCertificateMapTimeoutsToHclTerraform(struct?: CertificateManagerCertificateMapTimeouts | cdktn.IResolvable): any;
export declare class CertificateManagerCertificateMapTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CertificateManagerCertificateMapTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CertificateManagerCertificateMapTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate_map google_certificate_manager_certificate_map}
*/
export declare class CertificateManagerCertificateMap extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_certificate_manager_certificate_map";
    /**
    * Generates CDKTN code for importing a CertificateManagerCertificateMap resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CertificateManagerCertificateMap to import
    * @param importFromId The id of the existing CertificateManagerCertificateMap that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate_map#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CertificateManagerCertificateMap to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/certificate_manager_certificate_map google_certificate_manager_certificate_map} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CertificateManagerCertificateMapConfig
    */
    constructor(scope: Construct, id: string, config: CertificateManagerCertificateMapConfig);
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _gclbTargets;
    get gclbTargets(): CertificateManagerCertificateMapGclbTargetsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get updateTime(): string;
    private _timeouts;
    get timeouts(): CertificateManagerCertificateMapTimeoutsOutputReference;
    putTimeouts(value: CertificateManagerCertificateMapTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CertificateManagerCertificateMapTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
