/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { ChronicleFeedDetails, ChronicleFeedDetailsOutputReference, ChronicleFeedFailureDetails, ChronicleFeedFailureDetailsOutputReference, ChronicleFeedTimeouts, ChronicleFeedTimeoutsOutputReference } from './index-structs/index';
export * from './index-structs/index';
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChronicleFeedConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_feed#deletion_policy ChronicleFeed#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Customer-provided feed name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_feed#display_name ChronicleFeed#display_name}
    */
    readonly displayName?: string;
    /**
    * Whether the feed is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_feed#enabled ChronicleFeed#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_feed#feed ChronicleFeed#feed}
    */
    readonly feed?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_feed#id ChronicleFeed#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_feed#instance ChronicleFeed#instance}
    */
    readonly instance: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_feed#location ChronicleFeed#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_feed#project ChronicleFeed#project}
    */
    readonly project?: string;
    /**
    * details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_feed#details ChronicleFeed#details}
    */
    readonly details?: ChronicleFeedDetails;
    /**
    * failure_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_feed#failure_details ChronicleFeed#failure_details}
    */
    readonly failureDetails?: ChronicleFeedFailureDetails;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_feed#timeouts ChronicleFeed#timeouts}
    */
    readonly timeouts?: ChronicleFeedTimeouts;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_feed google_chronicle_feed}
*/
export declare class ChronicleFeed extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_chronicle_feed";
    /**
    * Generates CDKTN code for importing a ChronicleFeed resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChronicleFeed to import
    * @param importFromId The id of the existing ChronicleFeed that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_feed#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChronicleFeed to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_feed google_chronicle_feed} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChronicleFeedConfig
    */
    constructor(scope: Construct, id: string, config: ChronicleFeedConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get failureMsg(): string;
    private _feed?;
    get feed(): string;
    set feed(value: string);
    resetFeed(): void;
    get feedInput(): string | undefined;
    get feedServiceAccount(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instance?;
    get instance(): string;
    set instance(value: string);
    get instanceInput(): string | undefined;
    get lastFeedInitiationTime(): string;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get readOnly(): cdktn.IResolvable;
    get referenceId(): string;
    get secret(): string;
    get state(): string;
    get uid(): string;
    private _details;
    get details(): ChronicleFeedDetailsOutputReference;
    putDetails(value: ChronicleFeedDetails): void;
    resetDetails(): void;
    get detailsInput(): ChronicleFeedDetails | undefined;
    private _failureDetails;
    get failureDetails(): ChronicleFeedFailureDetailsOutputReference;
    putFailureDetails(value: ChronicleFeedFailureDetails): void;
    resetFailureDetails(): void;
    get failureDetailsInput(): ChronicleFeedFailureDetails | undefined;
    private _timeouts;
    get timeouts(): ChronicleFeedTimeoutsOutputReference;
    putTimeouts(value: ChronicleFeedTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ChronicleFeedTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
