/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeFirewallPolicyIamMemberConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_firewall_policy_iam_member#id ComputeFirewallPolicyIamMember#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_firewall_policy_iam_member#member ComputeFirewallPolicyIamMember#member}
    */
    readonly member: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_firewall_policy_iam_member#name ComputeFirewallPolicyIamMember#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_firewall_policy_iam_member#role ComputeFirewallPolicyIamMember#role}
    */
    readonly role: string;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_firewall_policy_iam_member#condition ComputeFirewallPolicyIamMember#condition}
    */
    readonly condition?: ComputeFirewallPolicyIamMemberCondition;
}
export interface ComputeFirewallPolicyIamMemberCondition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_firewall_policy_iam_member#description ComputeFirewallPolicyIamMember#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_firewall_policy_iam_member#expression ComputeFirewallPolicyIamMember#expression}
    */
    readonly expression: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_firewall_policy_iam_member#title ComputeFirewallPolicyIamMember#title}
    */
    readonly title: string;
}
export declare function computeFirewallPolicyIamMemberConditionToTerraform(struct?: ComputeFirewallPolicyIamMemberConditionOutputReference | ComputeFirewallPolicyIamMemberCondition): any;
export declare function computeFirewallPolicyIamMemberConditionToHclTerraform(struct?: ComputeFirewallPolicyIamMemberConditionOutputReference | ComputeFirewallPolicyIamMemberCondition): any;
export declare class ComputeFirewallPolicyIamMemberConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeFirewallPolicyIamMemberCondition | undefined;
    set internalValue(value: ComputeFirewallPolicyIamMemberCondition | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_firewall_policy_iam_member google_compute_firewall_policy_iam_member}
*/
export declare class ComputeFirewallPolicyIamMember extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_firewall_policy_iam_member";
    /**
    * Generates CDKTN code for importing a ComputeFirewallPolicyIamMember resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeFirewallPolicyIamMember to import
    * @param importFromId The id of the existing ComputeFirewallPolicyIamMember that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_firewall_policy_iam_member#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeFirewallPolicyIamMember to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_firewall_policy_iam_member google_compute_firewall_policy_iam_member} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeFirewallPolicyIamMemberConfig
    */
    constructor(scope: Construct, id: string, config: ComputeFirewallPolicyIamMemberConfig);
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _member?;
    get member(): string;
    set member(value: string);
    get memberInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _condition;
    get condition(): ComputeFirewallPolicyIamMemberConditionOutputReference;
    putCondition(value: ComputeFirewallPolicyIamMemberCondition): void;
    resetCondition(): void;
    get conditionInput(): ComputeFirewallPolicyIamMemberCondition | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
