/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChronicleDataAccessLabelConfig extends cdktn.TerraformMetaArguments {
    /**
    * Required. The ID to use for the data access label, which will become the label's
    * display name and the final component of the label's resource name. The
    * maximum number of characters should be 63. Regex pattern is as per AIP:
    * https://google.aip.dev/122#resource-id-segments
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_label#data_access_label_id ChronicleDataAccessLabel#data_access_label_id}
    */
    readonly dataAccessLabelId: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_label#deletion_policy ChronicleDataAccessLabel#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Optional. A description of the data access label for a human reader.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_label#description ChronicleDataAccessLabel#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_label#id ChronicleDataAccessLabel#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The unique identifier for the Chronicle instance, which is the same as the customer ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_label#instance ChronicleDataAccessLabel#instance}
    */
    readonly instance: string;
    /**
    * The location of the resource. This is the geographical region where the Chronicle instance resides, such as "us" or "europe-west2".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_label#location ChronicleDataAccessLabel#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_label#project ChronicleDataAccessLabel#project}
    */
    readonly project?: string;
    /**
    * A UDM query over event data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_label#udm_query ChronicleDataAccessLabel#udm_query}
    */
    readonly udmQuery: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_label#timeouts ChronicleDataAccessLabel#timeouts}
    */
    readonly timeouts?: ChronicleDataAccessLabelTimeouts;
}
export interface ChronicleDataAccessLabelTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_label#create ChronicleDataAccessLabel#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_label#delete ChronicleDataAccessLabel#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_label#update ChronicleDataAccessLabel#update}
    */
    readonly update?: string;
}
export declare function chronicleDataAccessLabelTimeoutsToTerraform(struct?: ChronicleDataAccessLabelTimeouts | cdktn.IResolvable): any;
export declare function chronicleDataAccessLabelTimeoutsToHclTerraform(struct?: ChronicleDataAccessLabelTimeouts | cdktn.IResolvable): any;
export declare class ChronicleDataAccessLabelTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleDataAccessLabelTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleDataAccessLabelTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_label google_chronicle_data_access_label}
*/
export declare class ChronicleDataAccessLabel extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_chronicle_data_access_label";
    /**
    * Generates CDKTN code for importing a ChronicleDataAccessLabel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChronicleDataAccessLabel to import
    * @param importFromId The id of the existing ChronicleDataAccessLabel that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_label#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChronicleDataAccessLabel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_data_access_label google_chronicle_data_access_label} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChronicleDataAccessLabelConfig
    */
    constructor(scope: Construct, id: string, config: ChronicleDataAccessLabelConfig);
    get author(): string;
    get createTime(): string;
    private _dataAccessLabelId?;
    get dataAccessLabelId(): string;
    set dataAccessLabelId(value: string);
    get dataAccessLabelIdInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get displayName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instance?;
    get instance(): string;
    set instance(value: string);
    get instanceInput(): string | undefined;
    get lastEditor(): string;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _udmQuery?;
    get udmQuery(): string;
    set udmQuery(value: string);
    get udmQueryInput(): string | undefined;
    get updateTime(): string;
    private _timeouts;
    get timeouts(): ChronicleDataAccessLabelTimeoutsOutputReference;
    putTimeouts(value: ChronicleDataAccessLabelTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ChronicleDataAccessLabelTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
