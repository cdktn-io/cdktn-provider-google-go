/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { ComputeUrlMapDefaultCustomErrorResponsePolicy, ComputeUrlMapDefaultCustomErrorResponsePolicyOutputReference, ComputeUrlMapDefaultRouteAction, ComputeUrlMapDefaultRouteActionOutputReference, ComputeUrlMapDefaultUrlRedirect, ComputeUrlMapDefaultUrlRedirectOutputReference, ComputeUrlMapHeaderAction, ComputeUrlMapHeaderActionOutputReference, ComputeUrlMapHostRule, ComputeUrlMapHostRuleList, ComputeUrlMapPathMatcher, ComputeUrlMapPathMatcherList, ComputeUrlMapTest, ComputeUrlMapTestList, ComputeUrlMapTimeouts, ComputeUrlMapTimeoutsOutputReference } from './index-structs/index';
export * from './index-structs/index';
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeUrlMapConfig extends cdktn.TerraformMetaArguments {
    /**
    * The backend service or backend bucket to use when none of the given rules match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_url_map#default_service ComputeUrlMap#default_service}
    */
    readonly defaultService?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_url_map#deletion_policy ComputeUrlMap#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource. Provide this property when you create
    * the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_url_map#description ComputeUrlMap#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_url_map#id ComputeUrlMap#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the resource. Provided by the client when the resource is created. The
    * name must be 1-63 characters long, and comply with RFC1035. Specifically, the
    * name must be 1-63 characters long and match the regular expression
    * '[a-z]([-a-z0-9]*[a-z0-9])?' which means the first character must be a lowercase
    * letter, and all following characters must be a dash, lowercase letter, or digit,
    * except the last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_url_map#name ComputeUrlMap#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_url_map#project ComputeUrlMap#project}
    */
    readonly project?: string;
    /**
    * default_custom_error_response_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_url_map#default_custom_error_response_policy ComputeUrlMap#default_custom_error_response_policy}
    */
    readonly defaultCustomErrorResponsePolicy?: ComputeUrlMapDefaultCustomErrorResponsePolicy;
    /**
    * default_route_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_url_map#default_route_action ComputeUrlMap#default_route_action}
    */
    readonly defaultRouteAction?: ComputeUrlMapDefaultRouteAction;
    /**
    * default_url_redirect block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_url_map#default_url_redirect ComputeUrlMap#default_url_redirect}
    */
    readonly defaultUrlRedirect?: ComputeUrlMapDefaultUrlRedirect;
    /**
    * header_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_url_map#header_action ComputeUrlMap#header_action}
    */
    readonly headerAction?: ComputeUrlMapHeaderAction;
    /**
    * host_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_url_map#host_rule ComputeUrlMap#host_rule}
    */
    readonly hostRule?: ComputeUrlMapHostRule[] | cdktn.IResolvable;
    /**
    * path_matcher block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_url_map#path_matcher ComputeUrlMap#path_matcher}
    */
    readonly pathMatcher?: ComputeUrlMapPathMatcher[] | cdktn.IResolvable;
    /**
    * test block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_url_map#test ComputeUrlMap#test}
    */
    readonly test?: ComputeUrlMapTest[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_url_map#timeouts ComputeUrlMap#timeouts}
    */
    readonly timeouts?: ComputeUrlMapTimeouts;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_url_map google_compute_url_map}
*/
export declare class ComputeUrlMap extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_url_map";
    /**
    * Generates CDKTN code for importing a ComputeUrlMap resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeUrlMap to import
    * @param importFromId The id of the existing ComputeUrlMap that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_url_map#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeUrlMap to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_url_map google_compute_url_map} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeUrlMapConfig
    */
    constructor(scope: Construct, id: string, config: ComputeUrlMapConfig);
    get creationTimestamp(): string;
    private _defaultService?;
    get defaultService(): string;
    set defaultService(value: string);
    resetDefaultService(): void;
    get defaultServiceInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get fingerprint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get mapId(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get selfLink(): string;
    private _defaultCustomErrorResponsePolicy;
    get defaultCustomErrorResponsePolicy(): ComputeUrlMapDefaultCustomErrorResponsePolicyOutputReference;
    putDefaultCustomErrorResponsePolicy(value: ComputeUrlMapDefaultCustomErrorResponsePolicy): void;
    resetDefaultCustomErrorResponsePolicy(): void;
    get defaultCustomErrorResponsePolicyInput(): ComputeUrlMapDefaultCustomErrorResponsePolicy | undefined;
    private _defaultRouteAction;
    get defaultRouteAction(): ComputeUrlMapDefaultRouteActionOutputReference;
    putDefaultRouteAction(value: ComputeUrlMapDefaultRouteAction): void;
    resetDefaultRouteAction(): void;
    get defaultRouteActionInput(): ComputeUrlMapDefaultRouteAction | undefined;
    private _defaultUrlRedirect;
    get defaultUrlRedirect(): ComputeUrlMapDefaultUrlRedirectOutputReference;
    putDefaultUrlRedirect(value: ComputeUrlMapDefaultUrlRedirect): void;
    resetDefaultUrlRedirect(): void;
    get defaultUrlRedirectInput(): ComputeUrlMapDefaultUrlRedirect | undefined;
    private _headerAction;
    get headerAction(): ComputeUrlMapHeaderActionOutputReference;
    putHeaderAction(value: ComputeUrlMapHeaderAction): void;
    resetHeaderAction(): void;
    get headerActionInput(): ComputeUrlMapHeaderAction | undefined;
    private _hostRule;
    get hostRule(): ComputeUrlMapHostRuleList;
    putHostRule(value: ComputeUrlMapHostRule[] | cdktn.IResolvable): void;
    resetHostRule(): void;
    get hostRuleInput(): cdktn.IResolvable | ComputeUrlMapHostRule[] | undefined;
    private _pathMatcher;
    get pathMatcher(): ComputeUrlMapPathMatcherList;
    putPathMatcher(value: ComputeUrlMapPathMatcher[] | cdktn.IResolvable): void;
    resetPathMatcher(): void;
    get pathMatcherInput(): cdktn.IResolvable | ComputeUrlMapPathMatcher[] | undefined;
    private _test;
    get test(): ComputeUrlMapTestList;
    putTest(value: ComputeUrlMapTest[] | cdktn.IResolvable): void;
    resetTest(): void;
    get testInput(): cdktn.IResolvable | ComputeUrlMapTest[] | undefined;
    private _timeouts;
    get timeouts(): ComputeUrlMapTimeoutsOutputReference;
    putTimeouts(value: ComputeUrlMapTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeUrlMapTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
