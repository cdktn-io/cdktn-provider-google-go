/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeRegionPerInstanceConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#deletion_policy ComputeRegionPerInstanceConfig#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#id ComputeRegionPerInstanceConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The minimal action to perform on the instance during an update.
    * Default is 'NONE'. Possible values are:
    * * REPLACE
    * * RESTART
    * * REFRESH
    * * NONE
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#minimal_action ComputeRegionPerInstanceConfig#minimal_action}
    */
    readonly minimalAction?: string;
    /**
    * The most disruptive action to perform on the instance during an update.
    * Default is 'REPLACE'. Possible values are:
    * * REPLACE
    * * RESTART
    * * REFRESH
    * * NONE
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#most_disruptive_allowed_action ComputeRegionPerInstanceConfig#most_disruptive_allowed_action}
    */
    readonly mostDisruptiveAllowedAction?: string;
    /**
    * The name for this per-instance config and its corresponding instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#name ComputeRegionPerInstanceConfig#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#project ComputeRegionPerInstanceConfig#project}
    */
    readonly project?: string;
    /**
    * Region where the containing instance group manager is located
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#region ComputeRegionPerInstanceConfig#region}
    */
    readonly region?: string;
    /**
    * The region instance group manager this instance config is part of.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#region_instance_group_manager ComputeRegionPerInstanceConfig#region_instance_group_manager}
    */
    readonly regionInstanceGroupManager: string;
    /**
    * When true, deleting this config will immediately remove the underlying instance.
    * When false, deleting this config will use the behavior as determined by remove_instance_on_destroy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#remove_instance_on_destroy ComputeRegionPerInstanceConfig#remove_instance_on_destroy}
    */
    readonly removeInstanceOnDestroy?: boolean | cdktn.IResolvable;
    /**
    * When true, deleting this config will immediately remove any specified state from the underlying instance.
    * When false, deleting this config will *not* immediately remove any state from the underlying instance.
    * State will be removed on the next instance recreation or update.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#remove_instance_state_on_destroy ComputeRegionPerInstanceConfig#remove_instance_state_on_destroy}
    */
    readonly removeInstanceStateOnDestroy?: boolean | cdktn.IResolvable;
    /**
    * preserved_state block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#preserved_state ComputeRegionPerInstanceConfig#preserved_state}
    */
    readonly preservedState?: ComputeRegionPerInstanceConfigPreservedState;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#timeouts ComputeRegionPerInstanceConfig#timeouts}
    */
    readonly timeouts?: ComputeRegionPerInstanceConfigTimeouts;
}
export interface ComputeRegionPerInstanceConfigPreservedStateDisk {
    /**
    * A value that prescribes what should happen to the stateful disk when the VM instance is deleted.
    * The available options are 'NEVER' and 'ON_PERMANENT_INSTANCE_DELETION'.
    * 'NEVER' - detach the disk when the VM is deleted, but do not delete the disk.
    * 'ON_PERMANENT_INSTANCE_DELETION' will delete the stateful disk when the VM is permanently
    * deleted from the instance group. Default value: "NEVER" Possible values: ["NEVER", "ON_PERMANENT_INSTANCE_DELETION"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#delete_rule ComputeRegionPerInstanceConfig#delete_rule}
    */
    readonly deleteRule?: string;
    /**
    * A unique device name that is reflected into the /dev/ tree of a Linux operating system running within the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#device_name ComputeRegionPerInstanceConfig#device_name}
    */
    readonly deviceName: string;
    /**
    * The mode of the disk. Default value: "READ_WRITE" Possible values: ["READ_ONLY", "READ_WRITE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#mode ComputeRegionPerInstanceConfig#mode}
    */
    readonly mode?: string;
    /**
    * The URI of an existing persistent disk to attach under the specified device-name in the format
    * 'projects/project-id/zones/zone/disks/disk-name'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#source ComputeRegionPerInstanceConfig#source}
    */
    readonly source: string;
}
export declare function computeRegionPerInstanceConfigPreservedStateDiskToTerraform(struct?: ComputeRegionPerInstanceConfigPreservedStateDisk | cdktn.IResolvable): any;
export declare function computeRegionPerInstanceConfigPreservedStateDiskToHclTerraform(struct?: ComputeRegionPerInstanceConfigPreservedStateDisk | cdktn.IResolvable): any;
export declare class ComputeRegionPerInstanceConfigPreservedStateDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionPerInstanceConfigPreservedStateDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionPerInstanceConfigPreservedStateDisk | cdktn.IResolvable | undefined);
    private _deleteRule?;
    get deleteRule(): string;
    set deleteRule(value: string);
    resetDeleteRule(): void;
    get deleteRuleInput(): string | undefined;
    private _deviceName?;
    get deviceName(): string;
    set deviceName(value: string);
    get deviceNameInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
}
export declare class ComputeRegionPerInstanceConfigPreservedStateDiskList extends cdktn.ComplexList {
    internalValue?: ComputeRegionPerInstanceConfigPreservedStateDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionPerInstanceConfigPreservedStateDiskOutputReference;
}
export interface ComputeRegionPerInstanceConfigPreservedStateExternalIpIpAddress {
    /**
    * The URL of the reservation for this IP address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#address ComputeRegionPerInstanceConfig#address}
    */
    readonly address?: string;
}
export declare function computeRegionPerInstanceConfigPreservedStateExternalIpIpAddressToTerraform(struct?: ComputeRegionPerInstanceConfigPreservedStateExternalIpIpAddressOutputReference | ComputeRegionPerInstanceConfigPreservedStateExternalIpIpAddress): any;
export declare function computeRegionPerInstanceConfigPreservedStateExternalIpIpAddressToHclTerraform(struct?: ComputeRegionPerInstanceConfigPreservedStateExternalIpIpAddressOutputReference | ComputeRegionPerInstanceConfigPreservedStateExternalIpIpAddress): any;
export declare class ComputeRegionPerInstanceConfigPreservedStateExternalIpIpAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionPerInstanceConfigPreservedStateExternalIpIpAddress | undefined;
    set internalValue(value: ComputeRegionPerInstanceConfigPreservedStateExternalIpIpAddress | undefined);
    private _address?;
    get address(): string;
    set address(value: string);
    resetAddress(): void;
    get addressInput(): string | undefined;
}
export interface ComputeRegionPerInstanceConfigPreservedStateExternalIp {
    /**
    * These stateful IPs will never be released during autohealing, update or VM instance recreate operations. This flag is used to configure if the IP reservation should be deleted after it is no longer used by the group, e.g. when the given instance or the whole group is deleted. Default value: "NEVER" Possible values: ["NEVER", "ON_PERMANENT_INSTANCE_DELETION"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#auto_delete ComputeRegionPerInstanceConfig#auto_delete}
    */
    readonly autoDelete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#interface_name ComputeRegionPerInstanceConfig#interface_name}
    */
    readonly interfaceName: string;
    /**
    * ip_address block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#ip_address ComputeRegionPerInstanceConfig#ip_address}
    */
    readonly ipAddress?: ComputeRegionPerInstanceConfigPreservedStateExternalIpIpAddress;
}
export declare function computeRegionPerInstanceConfigPreservedStateExternalIpToTerraform(struct?: ComputeRegionPerInstanceConfigPreservedStateExternalIp | cdktn.IResolvable): any;
export declare function computeRegionPerInstanceConfigPreservedStateExternalIpToHclTerraform(struct?: ComputeRegionPerInstanceConfigPreservedStateExternalIp | cdktn.IResolvable): any;
export declare class ComputeRegionPerInstanceConfigPreservedStateExternalIpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionPerInstanceConfigPreservedStateExternalIp | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionPerInstanceConfigPreservedStateExternalIp | cdktn.IResolvable | undefined);
    private _autoDelete?;
    get autoDelete(): string;
    set autoDelete(value: string);
    resetAutoDelete(): void;
    get autoDeleteInput(): string | undefined;
    private _interfaceName?;
    get interfaceName(): string;
    set interfaceName(value: string);
    get interfaceNameInput(): string | undefined;
    private _ipAddress;
    get ipAddress(): ComputeRegionPerInstanceConfigPreservedStateExternalIpIpAddressOutputReference;
    putIpAddress(value: ComputeRegionPerInstanceConfigPreservedStateExternalIpIpAddress): void;
    resetIpAddress(): void;
    get ipAddressInput(): ComputeRegionPerInstanceConfigPreservedStateExternalIpIpAddress | undefined;
}
export declare class ComputeRegionPerInstanceConfigPreservedStateExternalIpList extends cdktn.ComplexList {
    internalValue?: ComputeRegionPerInstanceConfigPreservedStateExternalIp[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionPerInstanceConfigPreservedStateExternalIpOutputReference;
}
export interface ComputeRegionPerInstanceConfigPreservedStateInternalIpIpAddress {
    /**
    * The URL of the reservation for this IP address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#address ComputeRegionPerInstanceConfig#address}
    */
    readonly address?: string;
}
export declare function computeRegionPerInstanceConfigPreservedStateInternalIpIpAddressToTerraform(struct?: ComputeRegionPerInstanceConfigPreservedStateInternalIpIpAddressOutputReference | ComputeRegionPerInstanceConfigPreservedStateInternalIpIpAddress): any;
export declare function computeRegionPerInstanceConfigPreservedStateInternalIpIpAddressToHclTerraform(struct?: ComputeRegionPerInstanceConfigPreservedStateInternalIpIpAddressOutputReference | ComputeRegionPerInstanceConfigPreservedStateInternalIpIpAddress): any;
export declare class ComputeRegionPerInstanceConfigPreservedStateInternalIpIpAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionPerInstanceConfigPreservedStateInternalIpIpAddress | undefined;
    set internalValue(value: ComputeRegionPerInstanceConfigPreservedStateInternalIpIpAddress | undefined);
    private _address?;
    get address(): string;
    set address(value: string);
    resetAddress(): void;
    get addressInput(): string | undefined;
}
export interface ComputeRegionPerInstanceConfigPreservedStateInternalIp {
    /**
    * These stateful IPs will never be released during autohealing, update or VM instance recreate operations. This flag is used to configure if the IP reservation should be deleted after it is no longer used by the group, e.g. when the given instance or the whole group is deleted. Default value: "NEVER" Possible values: ["NEVER", "ON_PERMANENT_INSTANCE_DELETION"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#auto_delete ComputeRegionPerInstanceConfig#auto_delete}
    */
    readonly autoDelete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#interface_name ComputeRegionPerInstanceConfig#interface_name}
    */
    readonly interfaceName: string;
    /**
    * ip_address block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#ip_address ComputeRegionPerInstanceConfig#ip_address}
    */
    readonly ipAddress?: ComputeRegionPerInstanceConfigPreservedStateInternalIpIpAddress;
}
export declare function computeRegionPerInstanceConfigPreservedStateInternalIpToTerraform(struct?: ComputeRegionPerInstanceConfigPreservedStateInternalIp | cdktn.IResolvable): any;
export declare function computeRegionPerInstanceConfigPreservedStateInternalIpToHclTerraform(struct?: ComputeRegionPerInstanceConfigPreservedStateInternalIp | cdktn.IResolvable): any;
export declare class ComputeRegionPerInstanceConfigPreservedStateInternalIpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionPerInstanceConfigPreservedStateInternalIp | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionPerInstanceConfigPreservedStateInternalIp | cdktn.IResolvable | undefined);
    private _autoDelete?;
    get autoDelete(): string;
    set autoDelete(value: string);
    resetAutoDelete(): void;
    get autoDeleteInput(): string | undefined;
    private _interfaceName?;
    get interfaceName(): string;
    set interfaceName(value: string);
    get interfaceNameInput(): string | undefined;
    private _ipAddress;
    get ipAddress(): ComputeRegionPerInstanceConfigPreservedStateInternalIpIpAddressOutputReference;
    putIpAddress(value: ComputeRegionPerInstanceConfigPreservedStateInternalIpIpAddress): void;
    resetIpAddress(): void;
    get ipAddressInput(): ComputeRegionPerInstanceConfigPreservedStateInternalIpIpAddress | undefined;
}
export declare class ComputeRegionPerInstanceConfigPreservedStateInternalIpList extends cdktn.ComplexList {
    internalValue?: ComputeRegionPerInstanceConfigPreservedStateInternalIp[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionPerInstanceConfigPreservedStateInternalIpOutputReference;
}
export interface ComputeRegionPerInstanceConfigPreservedState {
    /**
    * Preserved metadata defined for this instance. This is a list of key->value pairs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#metadata ComputeRegionPerInstanceConfig#metadata}
    */
    readonly metadata?: {
        [key: string]: string;
    };
    /**
    * disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#disk ComputeRegionPerInstanceConfig#disk}
    */
    readonly disk?: ComputeRegionPerInstanceConfigPreservedStateDisk[] | cdktn.IResolvable;
    /**
    * external_ip block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#external_ip ComputeRegionPerInstanceConfig#external_ip}
    */
    readonly externalIp?: ComputeRegionPerInstanceConfigPreservedStateExternalIp[] | cdktn.IResolvable;
    /**
    * internal_ip block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#internal_ip ComputeRegionPerInstanceConfig#internal_ip}
    */
    readonly internalIp?: ComputeRegionPerInstanceConfigPreservedStateInternalIp[] | cdktn.IResolvable;
}
export declare function computeRegionPerInstanceConfigPreservedStateToTerraform(struct?: ComputeRegionPerInstanceConfigPreservedStateOutputReference | ComputeRegionPerInstanceConfigPreservedState): any;
export declare function computeRegionPerInstanceConfigPreservedStateToHclTerraform(struct?: ComputeRegionPerInstanceConfigPreservedStateOutputReference | ComputeRegionPerInstanceConfigPreservedState): any;
export declare class ComputeRegionPerInstanceConfigPreservedStateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionPerInstanceConfigPreservedState | undefined;
    set internalValue(value: ComputeRegionPerInstanceConfigPreservedState | undefined);
    private _metadata?;
    get metadata(): {
        [key: string]: string;
    };
    set metadata(value: {
        [key: string]: string;
    });
    resetMetadata(): void;
    get metadataInput(): {
        [key: string]: string;
    } | undefined;
    private _disk;
    get disk(): ComputeRegionPerInstanceConfigPreservedStateDiskList;
    putDisk(value: ComputeRegionPerInstanceConfigPreservedStateDisk[] | cdktn.IResolvable): void;
    resetDisk(): void;
    get diskInput(): cdktn.IResolvable | ComputeRegionPerInstanceConfigPreservedStateDisk[] | undefined;
    private _externalIp;
    get externalIp(): ComputeRegionPerInstanceConfigPreservedStateExternalIpList;
    putExternalIp(value: ComputeRegionPerInstanceConfigPreservedStateExternalIp[] | cdktn.IResolvable): void;
    resetExternalIp(): void;
    get externalIpInput(): cdktn.IResolvable | ComputeRegionPerInstanceConfigPreservedStateExternalIp[] | undefined;
    private _internalIp;
    get internalIp(): ComputeRegionPerInstanceConfigPreservedStateInternalIpList;
    putInternalIp(value: ComputeRegionPerInstanceConfigPreservedStateInternalIp[] | cdktn.IResolvable): void;
    resetInternalIp(): void;
    get internalIpInput(): cdktn.IResolvable | ComputeRegionPerInstanceConfigPreservedStateInternalIp[] | undefined;
}
export interface ComputeRegionPerInstanceConfigTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#create ComputeRegionPerInstanceConfig#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#delete ComputeRegionPerInstanceConfig#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#update ComputeRegionPerInstanceConfig#update}
    */
    readonly update?: string;
}
export declare function computeRegionPerInstanceConfigTimeoutsToTerraform(struct?: ComputeRegionPerInstanceConfigTimeouts | cdktn.IResolvable): any;
export declare function computeRegionPerInstanceConfigTimeoutsToHclTerraform(struct?: ComputeRegionPerInstanceConfigTimeouts | cdktn.IResolvable): any;
export declare class ComputeRegionPerInstanceConfigTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionPerInstanceConfigTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionPerInstanceConfigTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config google_compute_region_per_instance_config}
*/
export declare class ComputeRegionPerInstanceConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_region_per_instance_config";
    /**
    * Generates CDKTN code for importing a ComputeRegionPerInstanceConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeRegionPerInstanceConfig to import
    * @param importFromId The id of the existing ComputeRegionPerInstanceConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeRegionPerInstanceConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_per_instance_config google_compute_region_per_instance_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeRegionPerInstanceConfigConfig
    */
    constructor(scope: Construct, id: string, config: ComputeRegionPerInstanceConfigConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _minimalAction?;
    get minimalAction(): string;
    set minimalAction(value: string);
    resetMinimalAction(): void;
    get minimalActionInput(): string | undefined;
    private _mostDisruptiveAllowedAction?;
    get mostDisruptiveAllowedAction(): string;
    set mostDisruptiveAllowedAction(value: string);
    resetMostDisruptiveAllowedAction(): void;
    get mostDisruptiveAllowedActionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _regionInstanceGroupManager?;
    get regionInstanceGroupManager(): string;
    set regionInstanceGroupManager(value: string);
    get regionInstanceGroupManagerInput(): string | undefined;
    private _removeInstanceOnDestroy?;
    get removeInstanceOnDestroy(): boolean | cdktn.IResolvable;
    set removeInstanceOnDestroy(value: boolean | cdktn.IResolvable);
    resetRemoveInstanceOnDestroy(): void;
    get removeInstanceOnDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _removeInstanceStateOnDestroy?;
    get removeInstanceStateOnDestroy(): boolean | cdktn.IResolvable;
    set removeInstanceStateOnDestroy(value: boolean | cdktn.IResolvable);
    resetRemoveInstanceStateOnDestroy(): void;
    get removeInstanceStateOnDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _preservedState;
    get preservedState(): ComputeRegionPerInstanceConfigPreservedStateOutputReference;
    putPreservedState(value: ComputeRegionPerInstanceConfigPreservedState): void;
    resetPreservedState(): void;
    get preservedStateInput(): ComputeRegionPerInstanceConfigPreservedState | undefined;
    private _timeouts;
    get timeouts(): ComputeRegionPerInstanceConfigTimeoutsOutputReference;
    putTimeouts(value: ComputeRegionPerInstanceConfigTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeRegionPerInstanceConfigTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
