/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChronicleCaseTagDefinitionConfig extends cdktn.TerraformMetaArguments {
    /**
    * When checked, the tag will be assigned as the title of the case if it meets the conditions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_case_tag_definition#can_be_case_title ChronicleCaseTagDefinition#can_be_case_title}
    */
    readonly canBeCaseTitle: boolean | cdktn.IResolvable;
    /**
    * The type of comparison to be used when comparing the value to the case. Possible values: ["EXACT", "START_WITH", "CONTAIN", "ENDS_WITH"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_case_tag_definition#comparison_type ChronicleCaseTagDefinition#comparison_type}
    */
    readonly comparisonType: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_case_tag_definition#deletion_policy ChronicleCaseTagDefinition#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * This is the name of the tag that will be applied to the case.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_case_tag_definition#display_name ChronicleCaseTagDefinition#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_case_tag_definition#id ChronicleCaseTagDefinition#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_case_tag_definition#instance ChronicleCaseTagDefinition#instance}
    */
    readonly instance: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_case_tag_definition#location ChronicleCaseTagDefinition#location}
    */
    readonly location: string;
    /**
    * The criteria to match the case against. Possible values: ["BY_VENDOR", "BY_PRODUCT", "BY_RULE_GENERATOR", "BY_ENTITY_PROPERTY_NAME", "DATA_DRIVEN", "SYSTEM"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_case_tag_definition#match_criteria ChronicleCaseTagDefinition#match_criteria}
    */
    readonly matchCriteria: string;
    /**
    * Note that Google Security Operations merges priority with other alerts and
    * entities and events so that the priority here is not absolute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_case_tag_definition#priority ChronicleCaseTagDefinition#priority}
    */
    readonly priority: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_case_tag_definition#project ChronicleCaseTagDefinition#project}
    */
    readonly project?: string;
    /**
    * Specific Entity property name to search in case.
    * This is relevant only when a SearchIn of type BY_ENTITY_PROPERTY_NAME was chosen.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_case_tag_definition#property_name ChronicleCaseTagDefinition#property_name}
    */
    readonly propertyName?: string;
    /**
    * Specific value to search in case - in addition to SearchIn property.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_case_tag_definition#value ChronicleCaseTagDefinition#value}
    */
    readonly value: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_case_tag_definition#timeouts ChronicleCaseTagDefinition#timeouts}
    */
    readonly timeouts?: ChronicleCaseTagDefinitionTimeouts;
}
export interface ChronicleCaseTagDefinitionTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_case_tag_definition#create ChronicleCaseTagDefinition#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_case_tag_definition#delete ChronicleCaseTagDefinition#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_case_tag_definition#update ChronicleCaseTagDefinition#update}
    */
    readonly update?: string;
}
export declare function chronicleCaseTagDefinitionTimeoutsToTerraform(struct?: ChronicleCaseTagDefinitionTimeouts | cdktn.IResolvable): any;
export declare function chronicleCaseTagDefinitionTimeoutsToHclTerraform(struct?: ChronicleCaseTagDefinitionTimeouts | cdktn.IResolvable): any;
export declare class ChronicleCaseTagDefinitionTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleCaseTagDefinitionTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleCaseTagDefinitionTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_case_tag_definition google_chronicle_case_tag_definition}
*/
export declare class ChronicleCaseTagDefinition extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_chronicle_case_tag_definition";
    /**
    * Generates CDKTN code for importing a ChronicleCaseTagDefinition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChronicleCaseTagDefinition to import
    * @param importFromId The id of the existing ChronicleCaseTagDefinition that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_case_tag_definition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChronicleCaseTagDefinition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_case_tag_definition google_chronicle_case_tag_definition} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChronicleCaseTagDefinitionConfig
    */
    constructor(scope: Construct, id: string, config: ChronicleCaseTagDefinitionConfig);
    private _canBeCaseTitle?;
    get canBeCaseTitle(): boolean | cdktn.IResolvable;
    set canBeCaseTitle(value: boolean | cdktn.IResolvable);
    get canBeCaseTitleInput(): boolean | cdktn.IResolvable | undefined;
    get caseTagDefinitionId(): string;
    private _comparisonType?;
    get comparisonType(): string;
    set comparisonType(value: string);
    get comparisonTypeInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instance?;
    get instance(): string;
    set instance(value: string);
    get instanceInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _matchCriteria?;
    get matchCriteria(): string;
    set matchCriteria(value: string);
    get matchCriteriaInput(): string | undefined;
    get name(): string;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _propertyName?;
    get propertyName(): string;
    set propertyName(value: string);
    resetPropertyName(): void;
    get propertyNameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
    private _timeouts;
    get timeouts(): ChronicleCaseTagDefinitionTimeoutsOutputReference;
    putTimeouts(value: ChronicleCaseTagDefinitionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ChronicleCaseTagDefinitionTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
