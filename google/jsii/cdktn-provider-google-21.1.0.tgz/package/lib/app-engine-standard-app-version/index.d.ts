/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppEngineStandardAppVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Allows App Engine second generation runtimes to access the legacy bundled services.
    * Cannot specify both 'app_engine_apis' and 'app_engine_bundled_services' together.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#app_engine_apis AppEngineStandardAppVersion#app_engine_apis}
    */
    readonly appEngineApis?: boolean | cdktn.IResolvable;
    /**
    * A list of legacy bundled services to enable for this version on an App Engine second-generation runtime.
    * Cannot specify both 'app_engine_apis' and 'app_engine_bundled_services' together. Possible values: ["BUNDLED_SERVICE_TYPE_APP_IDENTITY_SERVICE", "BUNDLED_SERVICE_TYPE_BLOBSTORE", "BUNDLED_SERVICE_TYPE_CAPABILITY_SERVICE", "BUNDLED_SERVICE_TYPE_DATASTORE_V3", "BUNDLED_SERVICE_TYPE_IMAGES", "BUNDLED_SERVICE_TYPE_MAIL", "BUNDLED_SERVICE_TYPE_MEMCACHE", "BUNDLED_SERVICE_TYPE_MODULES", "BUNDLED_SERVICE_TYPE_SEARCH", "BUNDLED_SERVICE_TYPE_TASKQUEUES", "BUNDLED_SERVICE_TYPE_URLFETCH", "BUNDLED_SERVICE_TYPE_USERS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#app_engine_bundled_services AppEngineStandardAppVersion#app_engine_bundled_services}
    */
    readonly appEngineBundledServices?: string[];
    /**
    * If set to 'true', the service will be deleted if it is the last version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#delete_service_on_destroy AppEngineStandardAppVersion#delete_service_on_destroy}
    */
    readonly deleteServiceOnDestroy?: boolean | cdktn.IResolvable;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#deletion_policy AppEngineStandardAppVersion#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Environment variables available to the application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#env_variables AppEngineStandardAppVersion#env_variables}
    */
    readonly envVariables?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#id AppEngineStandardAppVersion#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A list of the types of messages that this application is able to receive. Possible values: ["INBOUND_SERVICE_MAIL", "INBOUND_SERVICE_MAIL_BOUNCE", "INBOUND_SERVICE_XMPP_ERROR", "INBOUND_SERVICE_XMPP_MESSAGE", "INBOUND_SERVICE_XMPP_SUBSCRIBE", "INBOUND_SERVICE_XMPP_PRESENCE", "INBOUND_SERVICE_CHANNEL_PRESENCE", "INBOUND_SERVICE_WARMUP"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#inbound_services AppEngineStandardAppVersion#inbound_services}
    */
    readonly inboundServices?: string[];
    /**
    * Instance class that is used to run this version. Valid values are
    * AutomaticScaling: F1, F2, F4, F4_1G
    * BasicScaling or ManualScaling: B1, B2, B4, B4_1G, B8
    * Defaults to F1 for AutomaticScaling and B2 for ManualScaling and BasicScaling. If no scaling is specified, AutomaticScaling is chosen.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#instance_class AppEngineStandardAppVersion#instance_class}
    */
    readonly instanceClass?: string;
    /**
    * If set to 'true', the application version will not be deleted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#noop_on_destroy AppEngineStandardAppVersion#noop_on_destroy}
    */
    readonly noopOnDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#project AppEngineStandardAppVersion#project}
    */
    readonly project?: string;
    /**
    * Desired runtime. Example python27.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#runtime AppEngineStandardAppVersion#runtime}
    */
    readonly runtime: string;
    /**
    * The version of the API in the given runtime environment.
    * Please see the app.yaml reference for valid values at 'https://cloud.google.com/appengine/docs/standard/<language>/config/appref'\
    * Substitute '<language>' with 'python', 'java', 'php', 'ruby', 'go' or 'nodejs'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#runtime_api_version AppEngineStandardAppVersion#runtime_api_version}
    */
    readonly runtimeApiVersion?: string;
    /**
    * AppEngine service resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#service AppEngineStandardAppVersion#service}
    */
    readonly service: string;
    /**
    * The identity that the deployed version will run as. Admin API will use the App Engine Appspot service account as default if this field is neither provided in app.yaml file nor through CLI flag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#service_account AppEngineStandardAppVersion#service_account}
    */
    readonly serviceAccount?: string;
    /**
    * Whether multiple requests can be dispatched to this version at once.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#threadsafe AppEngineStandardAppVersion#threadsafe}
    */
    readonly threadsafe?: boolean | cdktn.IResolvable;
    /**
    * Relative name of the version within the service. For example, 'v1'. Version names can contain only lowercase letters, numbers, or hyphens. Reserved names,"default", "latest", and any name with the prefix "ah-".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#version_id AppEngineStandardAppVersion#version_id}
    */
    readonly versionId?: string;
    /**
    * automatic_scaling block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#automatic_scaling AppEngineStandardAppVersion#automatic_scaling}
    */
    readonly automaticScaling?: AppEngineStandardAppVersionAutomaticScaling;
    /**
    * basic_scaling block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#basic_scaling AppEngineStandardAppVersion#basic_scaling}
    */
    readonly basicScaling?: AppEngineStandardAppVersionBasicScaling;
    /**
    * deployment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#deployment AppEngineStandardAppVersion#deployment}
    */
    readonly deployment: AppEngineStandardAppVersionDeployment;
    /**
    * entrypoint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#entrypoint AppEngineStandardAppVersion#entrypoint}
    */
    readonly entrypoint: AppEngineStandardAppVersionEntrypoint;
    /**
    * handlers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#handlers AppEngineStandardAppVersion#handlers}
    */
    readonly handlers?: AppEngineStandardAppVersionHandlers[] | cdktn.IResolvable;
    /**
    * libraries block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#libraries AppEngineStandardAppVersion#libraries}
    */
    readonly libraries?: AppEngineStandardAppVersionLibraries[] | cdktn.IResolvable;
    /**
    * manual_scaling block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#manual_scaling AppEngineStandardAppVersion#manual_scaling}
    */
    readonly manualScaling?: AppEngineStandardAppVersionManualScaling;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#timeouts AppEngineStandardAppVersion#timeouts}
    */
    readonly timeouts?: AppEngineStandardAppVersionTimeouts;
    /**
    * vpc_access_connector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#vpc_access_connector AppEngineStandardAppVersion#vpc_access_connector}
    */
    readonly vpcAccessConnector?: AppEngineStandardAppVersionVpcAccessConnector;
}
export interface AppEngineStandardAppVersionAutomaticScalingStandardSchedulerSettings {
    /**
    * Maximum number of instances to run for this version. Set to zero to disable maxInstances configuration.
    *
    * **Note:** Starting from March 2025, App Engine sets the maxInstances default for standard environment deployments to 20. This change doesn't impact existing apps. To override the default, specify a new value between 0 and 2147483647, and deploy a new version or redeploy over an existing version. To disable the maxInstances default configuration setting, specify the maximum permitted value 2147483647.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#max_instances AppEngineStandardAppVersion#max_instances}
    */
    readonly maxInstances?: number;
    /**
    * Minimum number of instances to run for this version. Set to zero to disable minInstances configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#min_instances AppEngineStandardAppVersion#min_instances}
    */
    readonly minInstances?: number;
    /**
    * Target CPU utilization ratio to maintain when scaling. Should be a value in the range [0.50, 0.95], zero, or a negative value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#target_cpu_utilization AppEngineStandardAppVersion#target_cpu_utilization}
    */
    readonly targetCpuUtilization?: number;
    /**
    * Target throughput utilization ratio to maintain when scaling. Should be a value in the range [0.50, 0.95], zero, or a negative value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#target_throughput_utilization AppEngineStandardAppVersion#target_throughput_utilization}
    */
    readonly targetThroughputUtilization?: number;
}
export declare function appEngineStandardAppVersionAutomaticScalingStandardSchedulerSettingsToTerraform(struct?: AppEngineStandardAppVersionAutomaticScalingStandardSchedulerSettingsOutputReference | AppEngineStandardAppVersionAutomaticScalingStandardSchedulerSettings): any;
export declare function appEngineStandardAppVersionAutomaticScalingStandardSchedulerSettingsToHclTerraform(struct?: AppEngineStandardAppVersionAutomaticScalingStandardSchedulerSettingsOutputReference | AppEngineStandardAppVersionAutomaticScalingStandardSchedulerSettings): any;
export declare class AppEngineStandardAppVersionAutomaticScalingStandardSchedulerSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppEngineStandardAppVersionAutomaticScalingStandardSchedulerSettings | undefined;
    set internalValue(value: AppEngineStandardAppVersionAutomaticScalingStandardSchedulerSettings | undefined);
    private _maxInstances?;
    get maxInstances(): number;
    set maxInstances(value: number);
    resetMaxInstances(): void;
    get maxInstancesInput(): number | undefined;
    private _minInstances?;
    get minInstances(): number;
    set minInstances(value: number);
    resetMinInstances(): void;
    get minInstancesInput(): number | undefined;
    private _targetCpuUtilization?;
    get targetCpuUtilization(): number;
    set targetCpuUtilization(value: number);
    resetTargetCpuUtilization(): void;
    get targetCpuUtilizationInput(): number | undefined;
    private _targetThroughputUtilization?;
    get targetThroughputUtilization(): number;
    set targetThroughputUtilization(value: number);
    resetTargetThroughputUtilization(): void;
    get targetThroughputUtilizationInput(): number | undefined;
}
export interface AppEngineStandardAppVersionAutomaticScaling {
    /**
    * Number of concurrent requests an automatic scaling instance can accept before the scheduler spawns a new instance.
    *
    * Defaults to a runtime-specific value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#max_concurrent_requests AppEngineStandardAppVersion#max_concurrent_requests}
    */
    readonly maxConcurrentRequests?: number;
    /**
    * Maximum number of idle instances that should be maintained for this version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#max_idle_instances AppEngineStandardAppVersion#max_idle_instances}
    */
    readonly maxIdleInstances?: number;
    /**
    * Maximum amount of time that a request should wait in the pending queue before starting a new instance to handle it.
    * A duration in seconds with up to nine fractional digits, terminated by 's'. Example: "3.5s".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#max_pending_latency AppEngineStandardAppVersion#max_pending_latency}
    */
    readonly maxPendingLatency?: string;
    /**
    * Minimum number of idle instances that should be maintained for this version. Only applicable for the default version of a service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#min_idle_instances AppEngineStandardAppVersion#min_idle_instances}
    */
    readonly minIdleInstances?: number;
    /**
    * Minimum amount of time a request should wait in the pending queue before starting a new instance to handle it.
    * A duration in seconds with up to nine fractional digits, terminated by 's'. Example: "3.5s".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#min_pending_latency AppEngineStandardAppVersion#min_pending_latency}
    */
    readonly minPendingLatency?: string;
    /**
    * standard_scheduler_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#standard_scheduler_settings AppEngineStandardAppVersion#standard_scheduler_settings}
    */
    readonly standardSchedulerSettings?: AppEngineStandardAppVersionAutomaticScalingStandardSchedulerSettings;
}
export declare function appEngineStandardAppVersionAutomaticScalingToTerraform(struct?: AppEngineStandardAppVersionAutomaticScalingOutputReference | AppEngineStandardAppVersionAutomaticScaling): any;
export declare function appEngineStandardAppVersionAutomaticScalingToHclTerraform(struct?: AppEngineStandardAppVersionAutomaticScalingOutputReference | AppEngineStandardAppVersionAutomaticScaling): any;
export declare class AppEngineStandardAppVersionAutomaticScalingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppEngineStandardAppVersionAutomaticScaling | undefined;
    set internalValue(value: AppEngineStandardAppVersionAutomaticScaling | undefined);
    private _maxConcurrentRequests?;
    get maxConcurrentRequests(): number;
    set maxConcurrentRequests(value: number);
    resetMaxConcurrentRequests(): void;
    get maxConcurrentRequestsInput(): number | undefined;
    private _maxIdleInstances?;
    get maxIdleInstances(): number;
    set maxIdleInstances(value: number);
    resetMaxIdleInstances(): void;
    get maxIdleInstancesInput(): number | undefined;
    private _maxPendingLatency?;
    get maxPendingLatency(): string;
    set maxPendingLatency(value: string);
    resetMaxPendingLatency(): void;
    get maxPendingLatencyInput(): string | undefined;
    private _minIdleInstances?;
    get minIdleInstances(): number;
    set minIdleInstances(value: number);
    resetMinIdleInstances(): void;
    get minIdleInstancesInput(): number | undefined;
    private _minPendingLatency?;
    get minPendingLatency(): string;
    set minPendingLatency(value: string);
    resetMinPendingLatency(): void;
    get minPendingLatencyInput(): string | undefined;
    private _standardSchedulerSettings;
    get standardSchedulerSettings(): AppEngineStandardAppVersionAutomaticScalingStandardSchedulerSettingsOutputReference;
    putStandardSchedulerSettings(value: AppEngineStandardAppVersionAutomaticScalingStandardSchedulerSettings): void;
    resetStandardSchedulerSettings(): void;
    get standardSchedulerSettingsInput(): AppEngineStandardAppVersionAutomaticScalingStandardSchedulerSettings | undefined;
}
export interface AppEngineStandardAppVersionBasicScaling {
    /**
    * Duration of time after the last request that an instance must wait before the instance is shut down.
    * A duration in seconds with up to nine fractional digits, terminated by 's'. Example: "3.5s". Defaults to 900s.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#idle_timeout AppEngineStandardAppVersion#idle_timeout}
    */
    readonly idleTimeout?: string;
    /**
    * Maximum number of instances to create for this version. Must be in the range [1.0, 200.0].
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#max_instances AppEngineStandardAppVersion#max_instances}
    */
    readonly maxInstances: number;
}
export declare function appEngineStandardAppVersionBasicScalingToTerraform(struct?: AppEngineStandardAppVersionBasicScalingOutputReference | AppEngineStandardAppVersionBasicScaling): any;
export declare function appEngineStandardAppVersionBasicScalingToHclTerraform(struct?: AppEngineStandardAppVersionBasicScalingOutputReference | AppEngineStandardAppVersionBasicScaling): any;
export declare class AppEngineStandardAppVersionBasicScalingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppEngineStandardAppVersionBasicScaling | undefined;
    set internalValue(value: AppEngineStandardAppVersionBasicScaling | undefined);
    private _idleTimeout?;
    get idleTimeout(): string;
    set idleTimeout(value: string);
    resetIdleTimeout(): void;
    get idleTimeoutInput(): string | undefined;
    private _maxInstances?;
    get maxInstances(): number;
    set maxInstances(value: number);
    get maxInstancesInput(): number | undefined;
}
export interface AppEngineStandardAppVersionDeploymentFiles {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#name AppEngineStandardAppVersion#name}
    */
    readonly name: string;
    /**
    * SHA1 checksum of the file
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#sha1_sum AppEngineStandardAppVersion#sha1_sum}
    */
    readonly sha1Sum?: string;
    /**
    * Source URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#source_url AppEngineStandardAppVersion#source_url}
    */
    readonly sourceUrl: string;
}
export declare function appEngineStandardAppVersionDeploymentFilesToTerraform(struct?: AppEngineStandardAppVersionDeploymentFiles | cdktn.IResolvable): any;
export declare function appEngineStandardAppVersionDeploymentFilesToHclTerraform(struct?: AppEngineStandardAppVersionDeploymentFiles | cdktn.IResolvable): any;
export declare class AppEngineStandardAppVersionDeploymentFilesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppEngineStandardAppVersionDeploymentFiles | cdktn.IResolvable | undefined;
    set internalValue(value: AppEngineStandardAppVersionDeploymentFiles | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _sha1Sum?;
    get sha1Sum(): string;
    set sha1Sum(value: string);
    resetSha1Sum(): void;
    get sha1SumInput(): string | undefined;
    private _sourceUrl?;
    get sourceUrl(): string;
    set sourceUrl(value: string);
    get sourceUrlInput(): string | undefined;
}
export declare class AppEngineStandardAppVersionDeploymentFilesList extends cdktn.ComplexList {
    internalValue?: AppEngineStandardAppVersionDeploymentFiles[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppEngineStandardAppVersionDeploymentFilesOutputReference;
}
export interface AppEngineStandardAppVersionDeploymentZip {
    /**
    * files count
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#files_count AppEngineStandardAppVersion#files_count}
    */
    readonly filesCount?: number;
    /**
    * Source URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#source_url AppEngineStandardAppVersion#source_url}
    */
    readonly sourceUrl: string;
}
export declare function appEngineStandardAppVersionDeploymentZipToTerraform(struct?: AppEngineStandardAppVersionDeploymentZipOutputReference | AppEngineStandardAppVersionDeploymentZip): any;
export declare function appEngineStandardAppVersionDeploymentZipToHclTerraform(struct?: AppEngineStandardAppVersionDeploymentZipOutputReference | AppEngineStandardAppVersionDeploymentZip): any;
export declare class AppEngineStandardAppVersionDeploymentZipOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppEngineStandardAppVersionDeploymentZip | undefined;
    set internalValue(value: AppEngineStandardAppVersionDeploymentZip | undefined);
    private _filesCount?;
    get filesCount(): number;
    set filesCount(value: number);
    resetFilesCount(): void;
    get filesCountInput(): number | undefined;
    private _sourceUrl?;
    get sourceUrl(): string;
    set sourceUrl(value: string);
    get sourceUrlInput(): string | undefined;
}
export interface AppEngineStandardAppVersionDeployment {
    /**
    * files block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#files AppEngineStandardAppVersion#files}
    */
    readonly files?: AppEngineStandardAppVersionDeploymentFiles[] | cdktn.IResolvable;
    /**
    * zip block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#zip AppEngineStandardAppVersion#zip}
    */
    readonly zip?: AppEngineStandardAppVersionDeploymentZip;
}
export declare function appEngineStandardAppVersionDeploymentToTerraform(struct?: AppEngineStandardAppVersionDeploymentOutputReference | AppEngineStandardAppVersionDeployment): any;
export declare function appEngineStandardAppVersionDeploymentToHclTerraform(struct?: AppEngineStandardAppVersionDeploymentOutputReference | AppEngineStandardAppVersionDeployment): any;
export declare class AppEngineStandardAppVersionDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppEngineStandardAppVersionDeployment | undefined;
    set internalValue(value: AppEngineStandardAppVersionDeployment | undefined);
    private _files;
    get files(): AppEngineStandardAppVersionDeploymentFilesList;
    putFiles(value: AppEngineStandardAppVersionDeploymentFiles[] | cdktn.IResolvable): void;
    resetFiles(): void;
    get filesInput(): cdktn.IResolvable | AppEngineStandardAppVersionDeploymentFiles[] | undefined;
    private _zip;
    get zip(): AppEngineStandardAppVersionDeploymentZipOutputReference;
    putZip(value: AppEngineStandardAppVersionDeploymentZip): void;
    resetZip(): void;
    get zipInput(): AppEngineStandardAppVersionDeploymentZip | undefined;
}
export interface AppEngineStandardAppVersionEntrypoint {
    /**
    * The format should be a shell command that can be fed to bash -c.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#shell AppEngineStandardAppVersion#shell}
    */
    readonly shell: string;
}
export declare function appEngineStandardAppVersionEntrypointToTerraform(struct?: AppEngineStandardAppVersionEntrypointOutputReference | AppEngineStandardAppVersionEntrypoint): any;
export declare function appEngineStandardAppVersionEntrypointToHclTerraform(struct?: AppEngineStandardAppVersionEntrypointOutputReference | AppEngineStandardAppVersionEntrypoint): any;
export declare class AppEngineStandardAppVersionEntrypointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppEngineStandardAppVersionEntrypoint | undefined;
    set internalValue(value: AppEngineStandardAppVersionEntrypoint | undefined);
    private _shell?;
    get shell(): string;
    set shell(value: string);
    get shellInput(): string | undefined;
}
export interface AppEngineStandardAppVersionHandlersScript {
    /**
    * Path to the script from the application root directory.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#script_path AppEngineStandardAppVersion#script_path}
    */
    readonly scriptPath: string;
}
export declare function appEngineStandardAppVersionHandlersScriptToTerraform(struct?: AppEngineStandardAppVersionHandlersScriptOutputReference | AppEngineStandardAppVersionHandlersScript): any;
export declare function appEngineStandardAppVersionHandlersScriptToHclTerraform(struct?: AppEngineStandardAppVersionHandlersScriptOutputReference | AppEngineStandardAppVersionHandlersScript): any;
export declare class AppEngineStandardAppVersionHandlersScriptOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppEngineStandardAppVersionHandlersScript | undefined;
    set internalValue(value: AppEngineStandardAppVersionHandlersScript | undefined);
    private _scriptPath?;
    get scriptPath(): string;
    set scriptPath(value: string);
    get scriptPathInput(): string | undefined;
}
export interface AppEngineStandardAppVersionHandlersStaticFiles {
    /**
    * Whether files should also be uploaded as code data. By default, files declared in static file handlers are uploaded as
    * static data and are only served to end users; they cannot be read by the application. If enabled, uploads are charged
    * against both your code and static data storage resource quotas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#application_readable AppEngineStandardAppVersion#application_readable}
    */
    readonly applicationReadable?: boolean | cdktn.IResolvable;
    /**
    * Time a static file served by this handler should be cached by web proxies and browsers.
    * A duration in seconds with up to nine fractional digits, terminated by 's'. Example "3.5s".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#expiration AppEngineStandardAppVersion#expiration}
    */
    readonly expiration?: string;
    /**
    * HTTP headers to use for all responses from these URLs.
    * An object containing a list of "key:value" value pairs.".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#http_headers AppEngineStandardAppVersion#http_headers}
    */
    readonly httpHeaders?: {
        [key: string]: string;
    };
    /**
    * MIME type used to serve all files served by this handler.
    * Defaults to file-specific MIME types, which are derived from each file's filename extension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#mime_type AppEngineStandardAppVersion#mime_type}
    */
    readonly mimeType?: string;
    /**
    * Path to the static files matched by the URL pattern, from the application root directory. The path can refer to text matched in groupings in the URL pattern.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#path AppEngineStandardAppVersion#path}
    */
    readonly path?: string;
    /**
    * Whether this handler should match the request if the file referenced by the handler does not exist.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#require_matching_file AppEngineStandardAppVersion#require_matching_file}
    */
    readonly requireMatchingFile?: boolean | cdktn.IResolvable;
    /**
    * Regular expression that matches the file paths for all files that should be referenced by this handler.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#upload_path_regex AppEngineStandardAppVersion#upload_path_regex}
    */
    readonly uploadPathRegex?: string;
}
export declare function appEngineStandardAppVersionHandlersStaticFilesToTerraform(struct?: AppEngineStandardAppVersionHandlersStaticFilesOutputReference | AppEngineStandardAppVersionHandlersStaticFiles): any;
export declare function appEngineStandardAppVersionHandlersStaticFilesToHclTerraform(struct?: AppEngineStandardAppVersionHandlersStaticFilesOutputReference | AppEngineStandardAppVersionHandlersStaticFiles): any;
export declare class AppEngineStandardAppVersionHandlersStaticFilesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppEngineStandardAppVersionHandlersStaticFiles | undefined;
    set internalValue(value: AppEngineStandardAppVersionHandlersStaticFiles | undefined);
    private _applicationReadable?;
    get applicationReadable(): boolean | cdktn.IResolvable;
    set applicationReadable(value: boolean | cdktn.IResolvable);
    resetApplicationReadable(): void;
    get applicationReadableInput(): boolean | cdktn.IResolvable | undefined;
    private _expiration?;
    get expiration(): string;
    set expiration(value: string);
    resetExpiration(): void;
    get expirationInput(): string | undefined;
    private _httpHeaders?;
    get httpHeaders(): {
        [key: string]: string;
    };
    set httpHeaders(value: {
        [key: string]: string;
    });
    resetHttpHeaders(): void;
    get httpHeadersInput(): {
        [key: string]: string;
    } | undefined;
    private _mimeType?;
    get mimeType(): string;
    set mimeType(value: string);
    resetMimeType(): void;
    get mimeTypeInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _requireMatchingFile?;
    get requireMatchingFile(): boolean | cdktn.IResolvable;
    set requireMatchingFile(value: boolean | cdktn.IResolvable);
    resetRequireMatchingFile(): void;
    get requireMatchingFileInput(): boolean | cdktn.IResolvable | undefined;
    private _uploadPathRegex?;
    get uploadPathRegex(): string;
    set uploadPathRegex(value: string);
    resetUploadPathRegex(): void;
    get uploadPathRegexInput(): string | undefined;
}
export interface AppEngineStandardAppVersionHandlers {
    /**
    * Actions to take when the user is not logged in. Possible values: ["AUTH_FAIL_ACTION_REDIRECT", "AUTH_FAIL_ACTION_UNAUTHORIZED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#auth_fail_action AppEngineStandardAppVersion#auth_fail_action}
    */
    readonly authFailAction?: string;
    /**
    * Methods to restrict access to a URL based on login status. Possible values: ["LOGIN_OPTIONAL", "LOGIN_ADMIN", "LOGIN_REQUIRED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#login AppEngineStandardAppVersion#login}
    */
    readonly login?: string;
    /**
    * 30x code to use when performing redirects for the secure field. Possible values: ["REDIRECT_HTTP_RESPONSE_CODE_301", "REDIRECT_HTTP_RESPONSE_CODE_302", "REDIRECT_HTTP_RESPONSE_CODE_303", "REDIRECT_HTTP_RESPONSE_CODE_307"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#redirect_http_response_code AppEngineStandardAppVersion#redirect_http_response_code}
    */
    readonly redirectHttpResponseCode?: string;
    /**
    * Security (HTTPS) enforcement for this URL. Possible values: ["SECURE_DEFAULT", "SECURE_NEVER", "SECURE_OPTIONAL", "SECURE_ALWAYS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#security_level AppEngineStandardAppVersion#security_level}
    */
    readonly securityLevel?: string;
    /**
    * URL prefix. Uses regular expression syntax, which means regexp special characters must be escaped, but should not contain groupings.
    * All URLs that begin with this prefix are handled by this handler, using the portion of the URL after the prefix as part of the file path.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#url_regex AppEngineStandardAppVersion#url_regex}
    */
    readonly urlRegex?: string;
    /**
    * script block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#script AppEngineStandardAppVersion#script}
    */
    readonly script?: AppEngineStandardAppVersionHandlersScript;
    /**
    * static_files block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#static_files AppEngineStandardAppVersion#static_files}
    */
    readonly staticFiles?: AppEngineStandardAppVersionHandlersStaticFiles;
}
export declare function appEngineStandardAppVersionHandlersToTerraform(struct?: AppEngineStandardAppVersionHandlers | cdktn.IResolvable): any;
export declare function appEngineStandardAppVersionHandlersToHclTerraform(struct?: AppEngineStandardAppVersionHandlers | cdktn.IResolvable): any;
export declare class AppEngineStandardAppVersionHandlersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppEngineStandardAppVersionHandlers | cdktn.IResolvable | undefined;
    set internalValue(value: AppEngineStandardAppVersionHandlers | cdktn.IResolvable | undefined);
    private _authFailAction?;
    get authFailAction(): string;
    set authFailAction(value: string);
    resetAuthFailAction(): void;
    get authFailActionInput(): string | undefined;
    private _login?;
    get login(): string;
    set login(value: string);
    resetLogin(): void;
    get loginInput(): string | undefined;
    private _redirectHttpResponseCode?;
    get redirectHttpResponseCode(): string;
    set redirectHttpResponseCode(value: string);
    resetRedirectHttpResponseCode(): void;
    get redirectHttpResponseCodeInput(): string | undefined;
    private _securityLevel?;
    get securityLevel(): string;
    set securityLevel(value: string);
    resetSecurityLevel(): void;
    get securityLevelInput(): string | undefined;
    private _urlRegex?;
    get urlRegex(): string;
    set urlRegex(value: string);
    resetUrlRegex(): void;
    get urlRegexInput(): string | undefined;
    private _script;
    get script(): AppEngineStandardAppVersionHandlersScriptOutputReference;
    putScript(value: AppEngineStandardAppVersionHandlersScript): void;
    resetScript(): void;
    get scriptInput(): AppEngineStandardAppVersionHandlersScript | undefined;
    private _staticFiles;
    get staticFiles(): AppEngineStandardAppVersionHandlersStaticFilesOutputReference;
    putStaticFiles(value: AppEngineStandardAppVersionHandlersStaticFiles): void;
    resetStaticFiles(): void;
    get staticFilesInput(): AppEngineStandardAppVersionHandlersStaticFiles | undefined;
}
export declare class AppEngineStandardAppVersionHandlersList extends cdktn.ComplexList {
    internalValue?: AppEngineStandardAppVersionHandlers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppEngineStandardAppVersionHandlersOutputReference;
}
export interface AppEngineStandardAppVersionLibraries {
    /**
    * Name of the library. Example "django".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#name AppEngineStandardAppVersion#name}
    */
    readonly name?: string;
    /**
    * Version of the library to select, or "latest".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#version AppEngineStandardAppVersion#version}
    */
    readonly version?: string;
}
export declare function appEngineStandardAppVersionLibrariesToTerraform(struct?: AppEngineStandardAppVersionLibraries | cdktn.IResolvable): any;
export declare function appEngineStandardAppVersionLibrariesToHclTerraform(struct?: AppEngineStandardAppVersionLibraries | cdktn.IResolvable): any;
export declare class AppEngineStandardAppVersionLibrariesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppEngineStandardAppVersionLibraries | cdktn.IResolvable | undefined;
    set internalValue(value: AppEngineStandardAppVersionLibraries | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export declare class AppEngineStandardAppVersionLibrariesList extends cdktn.ComplexList {
    internalValue?: AppEngineStandardAppVersionLibraries[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppEngineStandardAppVersionLibrariesOutputReference;
}
export interface AppEngineStandardAppVersionManualScaling {
    /**
    * Number of instances to assign to the service at the start.
    *
    * **Note:** When managing the number of instances at runtime through the App Engine Admin API or the (now deprecated) Python 2
    * Modules API set_num_instances() you must use 'lifecycle.ignore_changes = ["manual_scaling"[0].instances]' to prevent drift detection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#instances AppEngineStandardAppVersion#instances}
    */
    readonly instances: number;
}
export declare function appEngineStandardAppVersionManualScalingToTerraform(struct?: AppEngineStandardAppVersionManualScalingOutputReference | AppEngineStandardAppVersionManualScaling): any;
export declare function appEngineStandardAppVersionManualScalingToHclTerraform(struct?: AppEngineStandardAppVersionManualScalingOutputReference | AppEngineStandardAppVersionManualScaling): any;
export declare class AppEngineStandardAppVersionManualScalingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppEngineStandardAppVersionManualScaling | undefined;
    set internalValue(value: AppEngineStandardAppVersionManualScaling | undefined);
    private _instances?;
    get instances(): number;
    set instances(value: number);
    get instancesInput(): number | undefined;
}
export interface AppEngineStandardAppVersionTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#create AppEngineStandardAppVersion#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#delete AppEngineStandardAppVersion#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#update AppEngineStandardAppVersion#update}
    */
    readonly update?: string;
}
export declare function appEngineStandardAppVersionTimeoutsToTerraform(struct?: AppEngineStandardAppVersionTimeouts | cdktn.IResolvable): any;
export declare function appEngineStandardAppVersionTimeoutsToHclTerraform(struct?: AppEngineStandardAppVersionTimeouts | cdktn.IResolvable): any;
export declare class AppEngineStandardAppVersionTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppEngineStandardAppVersionTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AppEngineStandardAppVersionTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface AppEngineStandardAppVersionVpcAccessConnector {
    /**
    * The egress setting for the connector, controlling what traffic is diverted through it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#egress_setting AppEngineStandardAppVersion#egress_setting}
    */
    readonly egressSetting?: string;
    /**
    * Full Serverless VPC Access Connector name e.g. /projects/my-project/locations/us-central1/connectors/c1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#name AppEngineStandardAppVersion#name}
    */
    readonly name: string;
}
export declare function appEngineStandardAppVersionVpcAccessConnectorToTerraform(struct?: AppEngineStandardAppVersionVpcAccessConnectorOutputReference | AppEngineStandardAppVersionVpcAccessConnector): any;
export declare function appEngineStandardAppVersionVpcAccessConnectorToHclTerraform(struct?: AppEngineStandardAppVersionVpcAccessConnectorOutputReference | AppEngineStandardAppVersionVpcAccessConnector): any;
export declare class AppEngineStandardAppVersionVpcAccessConnectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppEngineStandardAppVersionVpcAccessConnector | undefined;
    set internalValue(value: AppEngineStandardAppVersionVpcAccessConnector | undefined);
    private _egressSetting?;
    get egressSetting(): string;
    set egressSetting(value: string);
    resetEgressSetting(): void;
    get egressSettingInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version google_app_engine_standard_app_version}
*/
export declare class AppEngineStandardAppVersion extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_app_engine_standard_app_version";
    /**
    * Generates CDKTN code for importing a AppEngineStandardAppVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppEngineStandardAppVersion to import
    * @param importFromId The id of the existing AppEngineStandardAppVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppEngineStandardAppVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/app_engine_standard_app_version google_app_engine_standard_app_version} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppEngineStandardAppVersionConfig
    */
    constructor(scope: Construct, id: string, config: AppEngineStandardAppVersionConfig);
    private _appEngineApis?;
    get appEngineApis(): boolean | cdktn.IResolvable;
    set appEngineApis(value: boolean | cdktn.IResolvable);
    resetAppEngineApis(): void;
    get appEngineApisInput(): boolean | cdktn.IResolvable | undefined;
    private _appEngineBundledServices?;
    get appEngineBundledServices(): string[];
    set appEngineBundledServices(value: string[]);
    resetAppEngineBundledServices(): void;
    get appEngineBundledServicesInput(): string[] | undefined;
    private _deleteServiceOnDestroy?;
    get deleteServiceOnDestroy(): boolean | cdktn.IResolvable;
    set deleteServiceOnDestroy(value: boolean | cdktn.IResolvable);
    resetDeleteServiceOnDestroy(): void;
    get deleteServiceOnDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _envVariables?;
    get envVariables(): {
        [key: string]: string;
    };
    set envVariables(value: {
        [key: string]: string;
    });
    resetEnvVariables(): void;
    get envVariablesInput(): {
        [key: string]: string;
    } | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inboundServices?;
    get inboundServices(): string[];
    set inboundServices(value: string[]);
    resetInboundServices(): void;
    get inboundServicesInput(): string[] | undefined;
    private _instanceClass?;
    get instanceClass(): string;
    set instanceClass(value: string);
    resetInstanceClass(): void;
    get instanceClassInput(): string | undefined;
    get name(): string;
    private _noopOnDestroy?;
    get noopOnDestroy(): boolean | cdktn.IResolvable;
    set noopOnDestroy(value: boolean | cdktn.IResolvable);
    resetNoopOnDestroy(): void;
    get noopOnDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _runtime?;
    get runtime(): string;
    set runtime(value: string);
    get runtimeInput(): string | undefined;
    private _runtimeApiVersion?;
    get runtimeApiVersion(): string;
    set runtimeApiVersion(value: string);
    resetRuntimeApiVersion(): void;
    get runtimeApiVersionInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _serviceAccount?;
    get serviceAccount(): string;
    set serviceAccount(value: string);
    resetServiceAccount(): void;
    get serviceAccountInput(): string | undefined;
    private _threadsafe?;
    get threadsafe(): boolean | cdktn.IResolvable;
    set threadsafe(value: boolean | cdktn.IResolvable);
    resetThreadsafe(): void;
    get threadsafeInput(): boolean | cdktn.IResolvable | undefined;
    private _versionId?;
    get versionId(): string;
    set versionId(value: string);
    resetVersionId(): void;
    get versionIdInput(): string | undefined;
    private _automaticScaling;
    get automaticScaling(): AppEngineStandardAppVersionAutomaticScalingOutputReference;
    putAutomaticScaling(value: AppEngineStandardAppVersionAutomaticScaling): void;
    resetAutomaticScaling(): void;
    get automaticScalingInput(): AppEngineStandardAppVersionAutomaticScaling | undefined;
    private _basicScaling;
    get basicScaling(): AppEngineStandardAppVersionBasicScalingOutputReference;
    putBasicScaling(value: AppEngineStandardAppVersionBasicScaling): void;
    resetBasicScaling(): void;
    get basicScalingInput(): AppEngineStandardAppVersionBasicScaling | undefined;
    private _deployment;
    get deployment(): AppEngineStandardAppVersionDeploymentOutputReference;
    putDeployment(value: AppEngineStandardAppVersionDeployment): void;
    get deploymentInput(): AppEngineStandardAppVersionDeployment | undefined;
    private _entrypoint;
    get entrypoint(): AppEngineStandardAppVersionEntrypointOutputReference;
    putEntrypoint(value: AppEngineStandardAppVersionEntrypoint): void;
    get entrypointInput(): AppEngineStandardAppVersionEntrypoint | undefined;
    private _handlers;
    get handlers(): AppEngineStandardAppVersionHandlersList;
    putHandlers(value: AppEngineStandardAppVersionHandlers[] | cdktn.IResolvable): void;
    resetHandlers(): void;
    get handlersInput(): cdktn.IResolvable | AppEngineStandardAppVersionHandlers[] | undefined;
    private _libraries;
    get libraries(): AppEngineStandardAppVersionLibrariesList;
    putLibraries(value: AppEngineStandardAppVersionLibraries[] | cdktn.IResolvable): void;
    resetLibraries(): void;
    get librariesInput(): cdktn.IResolvable | AppEngineStandardAppVersionLibraries[] | undefined;
    private _manualScaling;
    get manualScaling(): AppEngineStandardAppVersionManualScalingOutputReference;
    putManualScaling(value: AppEngineStandardAppVersionManualScaling): void;
    resetManualScaling(): void;
    get manualScalingInput(): AppEngineStandardAppVersionManualScaling | undefined;
    private _timeouts;
    get timeouts(): AppEngineStandardAppVersionTimeoutsOutputReference;
    putTimeouts(value: AppEngineStandardAppVersionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AppEngineStandardAppVersionTimeouts | undefined;
    private _vpcAccessConnector;
    get vpcAccessConnector(): AppEngineStandardAppVersionVpcAccessConnectorOutputReference;
    putVpcAccessConnector(value: AppEngineStandardAppVersionVpcAccessConnector): void;
    resetVpcAccessConnector(): void;
    get vpcAccessConnectorInput(): AppEngineStandardAppVersionVpcAccessConnector | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
