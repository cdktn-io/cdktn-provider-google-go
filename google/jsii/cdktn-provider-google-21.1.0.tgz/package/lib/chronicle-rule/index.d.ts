/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChronicleRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * This field uses a custom implementation please refer to documentation under /hashicorp/terraform-provider-google-beta/website/docs/r/chronicle_rule.html.markdown for specifics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_rule#deletion_policy ChronicleRule#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The etag for this rule.
    * If this is provided on update, the request will succeed if and only if it
    * matches the server-computed value, and will fail with an ABORTED error
    * otherwise.
    * Populated in BASIC view and FULL view.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_rule#etag ChronicleRule#etag}
    */
    readonly etag?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_rule#id ChronicleRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The unique identifier for the Chronicle instance, which is the same as the customer ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_rule#instance ChronicleRule#instance}
    */
    readonly instance: string;
    /**
    * The location of the resource. This is the geographical region where the Chronicle instance resides, such as "us" or "europe-west2".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_rule#location ChronicleRule#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_rule#project ChronicleRule#project}
    */
    readonly project?: string;
    /**
    * Rule Id is the ID of the Rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_rule#rule_id ChronicleRule#rule_id}
    */
    readonly ruleId?: string;
    /**
    * Resource name of the DataAccessScope bound to this rule.
    * Populated in BASIC view and FULL view.
    * If reference lists are used in the rule, validations will be performed
    * against this scope to ensure that the reference lists are compatible with
    * both the user's and the rule's scopes.
    * The scope should be in the format:
    * "projects/{project}/locations/{location}/instances/{instance}/dataAccessScopes/{scope}".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_rule#scope ChronicleRule#scope}
    */
    readonly scope?: string;
    /**
    * The YARA-L content of the rule.
    * Populated in FULL view.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_rule#text ChronicleRule#text}
    */
    readonly text?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_rule#timeouts ChronicleRule#timeouts}
    */
    readonly timeouts?: ChronicleRuleTimeouts;
}
export interface ChronicleRuleCompilationDiagnosticsPosition {
}
export declare function chronicleRuleCompilationDiagnosticsPositionToTerraform(struct?: ChronicleRuleCompilationDiagnosticsPosition): any;
export declare function chronicleRuleCompilationDiagnosticsPositionToHclTerraform(struct?: ChronicleRuleCompilationDiagnosticsPosition): any;
export declare class ChronicleRuleCompilationDiagnosticsPositionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleRuleCompilationDiagnosticsPosition | undefined;
    set internalValue(value: ChronicleRuleCompilationDiagnosticsPosition | undefined);
    get endColumn(): number;
    get endLine(): number;
    get startColumn(): number;
    get startLine(): number;
}
export declare class ChronicleRuleCompilationDiagnosticsPositionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleRuleCompilationDiagnosticsPositionOutputReference;
}
export interface ChronicleRuleCompilationDiagnostics {
}
export declare function chronicleRuleCompilationDiagnosticsToTerraform(struct?: ChronicleRuleCompilationDiagnostics): any;
export declare function chronicleRuleCompilationDiagnosticsToHclTerraform(struct?: ChronicleRuleCompilationDiagnostics): any;
export declare class ChronicleRuleCompilationDiagnosticsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleRuleCompilationDiagnostics | undefined;
    set internalValue(value: ChronicleRuleCompilationDiagnostics | undefined);
    get message(): string;
    private _position;
    get position(): ChronicleRuleCompilationDiagnosticsPositionList;
    get severity(): string;
    get uri(): string;
}
export declare class ChronicleRuleCompilationDiagnosticsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleRuleCompilationDiagnosticsOutputReference;
}
export interface ChronicleRuleSeverity {
}
export declare function chronicleRuleSeverityToTerraform(struct?: ChronicleRuleSeverity): any;
export declare function chronicleRuleSeverityToHclTerraform(struct?: ChronicleRuleSeverity): any;
export declare class ChronicleRuleSeverityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChronicleRuleSeverity | undefined;
    set internalValue(value: ChronicleRuleSeverity | undefined);
    get displayName(): string;
}
export declare class ChronicleRuleSeverityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChronicleRuleSeverityOutputReference;
}
export interface ChronicleRuleTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_rule#create ChronicleRule#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_rule#delete ChronicleRule#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_rule#update ChronicleRule#update}
    */
    readonly update?: string;
}
export declare function chronicleRuleTimeoutsToTerraform(struct?: ChronicleRuleTimeouts | cdktn.IResolvable): any;
export declare function chronicleRuleTimeoutsToHclTerraform(struct?: ChronicleRuleTimeouts | cdktn.IResolvable): any;
export declare class ChronicleRuleTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleRuleTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleRuleTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_rule google_chronicle_rule}
*/
export declare class ChronicleRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_chronicle_rule";
    /**
    * Generates CDKTN code for importing a ChronicleRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChronicleRule to import
    * @param importFromId The id of the existing ChronicleRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChronicleRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_rule google_chronicle_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChronicleRuleConfig
    */
    constructor(scope: Construct, id: string, config: ChronicleRuleConfig);
    get allowedRunFrequencies(): string[];
    get author(): string;
    private _compilationDiagnostics;
    get compilationDiagnostics(): ChronicleRuleCompilationDiagnosticsList;
    get compilationState(): string;
    get createTime(): string;
    get dataTables(): string[];
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    get displayName(): string;
    private _etag?;
    get etag(): string;
    set etag(value: string);
    resetEtag(): void;
    get etagInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instance?;
    get instance(): string;
    set instance(value: string);
    get instanceInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _metadata;
    get metadata(): cdktn.StringMap;
    get name(): string;
    get nearRealTimeLiveRuleEligible(): cdktn.IResolvable;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get referenceLists(): string[];
    get revisionCreateTime(): string;
    get revisionId(): string;
    private _ruleId?;
    get ruleId(): string;
    set ruleId(value: string);
    resetRuleId(): void;
    get ruleIdInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
    private _severity;
    get severity(): ChronicleRuleSeverityList;
    private _text?;
    get text(): string;
    set text(value: string);
    resetText(): void;
    get textInput(): string | undefined;
    get type(): string;
    private _timeouts;
    get timeouts(): ChronicleRuleTimeoutsOutputReference;
    putTimeouts(value: ChronicleRuleTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ChronicleRuleTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
