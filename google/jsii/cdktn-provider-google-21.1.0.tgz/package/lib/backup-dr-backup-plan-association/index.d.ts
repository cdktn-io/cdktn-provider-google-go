/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BackupDrBackupPlanAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The BP with which resource needs to be created
    * Note:
    * - A Backup Plan configured for 'compute.googleapis.com/Instance', can only protect instance type resources.
    * - A Backup Plan configured for 'compute.googleapis.com/Disk' can be used to protect both standard Disks and Regional Disks resources.
    * - A Backup Plan configured for 'file.googleapis.com/Instance' can only protect Filestore instances.
    * - A Backup Plan configured for 'sqladmin.googleapis.com/Instance' can only protect Cloud SQL instances.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_plan_association#backup_plan BackupDrBackupPlanAssociation#backup_plan}
    */
    readonly backupPlan: string;
    /**
    * The id of backupplan association
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_plan_association#backup_plan_association_id BackupDrBackupPlanAssociation#backup_plan_association_id}
    */
    readonly backupPlanAssociationId: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_plan_association#deletion_policy BackupDrBackupPlanAssociation#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_plan_association#id BackupDrBackupPlanAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location for the backupplan association
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_plan_association#location BackupDrBackupPlanAssociation#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_plan_association#project BackupDrBackupPlanAssociation#project}
    */
    readonly project?: string;
    /**
    * The resource for which BPA needs to be created
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_plan_association#resource BackupDrBackupPlanAssociation#resource}
    */
    readonly resource: string;
    /**
    * The resource type of workload on which backupplan is applied.
    * Examples include, "compute.googleapis.com/Instance", "compute.googleapis.com/Disk", "compute.googleapis.com/RegionDisk", and "file.googleapis.com/Instance"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_plan_association#resource_type BackupDrBackupPlanAssociation#resource_type}
    */
    readonly resourceType: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_plan_association#timeouts BackupDrBackupPlanAssociation#timeouts}
    */
    readonly timeouts?: BackupDrBackupPlanAssociationTimeouts;
}
export interface BackupDrBackupPlanAssociationRulesConfigInfoLastBackupError {
}
export declare function backupDrBackupPlanAssociationRulesConfigInfoLastBackupErrorToTerraform(struct?: BackupDrBackupPlanAssociationRulesConfigInfoLastBackupError): any;
export declare function backupDrBackupPlanAssociationRulesConfigInfoLastBackupErrorToHclTerraform(struct?: BackupDrBackupPlanAssociationRulesConfigInfoLastBackupError): any;
export declare class BackupDrBackupPlanAssociationRulesConfigInfoLastBackupErrorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupDrBackupPlanAssociationRulesConfigInfoLastBackupError | undefined;
    set internalValue(value: BackupDrBackupPlanAssociationRulesConfigInfoLastBackupError | undefined);
    get code(): number;
    get message(): string;
}
export declare class BackupDrBackupPlanAssociationRulesConfigInfoLastBackupErrorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupDrBackupPlanAssociationRulesConfigInfoLastBackupErrorOutputReference;
}
export interface BackupDrBackupPlanAssociationRulesConfigInfo {
}
export declare function backupDrBackupPlanAssociationRulesConfigInfoToTerraform(struct?: BackupDrBackupPlanAssociationRulesConfigInfo): any;
export declare function backupDrBackupPlanAssociationRulesConfigInfoToHclTerraform(struct?: BackupDrBackupPlanAssociationRulesConfigInfo): any;
export declare class BackupDrBackupPlanAssociationRulesConfigInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupDrBackupPlanAssociationRulesConfigInfo | undefined;
    set internalValue(value: BackupDrBackupPlanAssociationRulesConfigInfo | undefined);
    private _lastBackupError;
    get lastBackupError(): BackupDrBackupPlanAssociationRulesConfigInfoLastBackupErrorList;
    get lastBackupState(): string;
    get lastSuccessfulBackupConsistencyTime(): string;
    get ruleId(): string;
}
export declare class BackupDrBackupPlanAssociationRulesConfigInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupDrBackupPlanAssociationRulesConfigInfoOutputReference;
}
export interface BackupDrBackupPlanAssociationTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_plan_association#create BackupDrBackupPlanAssociation#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_plan_association#delete BackupDrBackupPlanAssociation#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_plan_association#update BackupDrBackupPlanAssociation#update}
    */
    readonly update?: string;
}
export declare function backupDrBackupPlanAssociationTimeoutsToTerraform(struct?: BackupDrBackupPlanAssociationTimeouts | cdktn.IResolvable): any;
export declare function backupDrBackupPlanAssociationTimeoutsToHclTerraform(struct?: BackupDrBackupPlanAssociationTimeouts | cdktn.IResolvable): any;
export declare class BackupDrBackupPlanAssociationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupDrBackupPlanAssociationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BackupDrBackupPlanAssociationTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_plan_association google_backup_dr_backup_plan_association}
*/
export declare class BackupDrBackupPlanAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_backup_dr_backup_plan_association";
    /**
    * Generates CDKTN code for importing a BackupDrBackupPlanAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BackupDrBackupPlanAssociation to import
    * @param importFromId The id of the existing BackupDrBackupPlanAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_plan_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BackupDrBackupPlanAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/backup_dr_backup_plan_association google_backup_dr_backup_plan_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BackupDrBackupPlanAssociationConfig
    */
    constructor(scope: Construct, id: string, config: BackupDrBackupPlanAssociationConfig);
    private _backupPlan?;
    get backupPlan(): string;
    set backupPlan(value: string);
    get backupPlanInput(): string | undefined;
    private _backupPlanAssociationId?;
    get backupPlanAssociationId(): string;
    set backupPlanAssociationId(value: string);
    get backupPlanAssociationIdInput(): string | undefined;
    get createTime(): string;
    get dataSource(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _resource?;
    get resource(): string;
    set resource(value: string);
    get resourceInput(): string | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    get resourceTypeInput(): string | undefined;
    private _rulesConfigInfo;
    get rulesConfigInfo(): BackupDrBackupPlanAssociationRulesConfigInfoList;
    get updateTime(): string;
    private _timeouts;
    get timeouts(): BackupDrBackupPlanAssociationTimeoutsOutputReference;
    putTimeouts(value: BackupDrBackupPlanAssociationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BackupDrBackupPlanAssociationTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
