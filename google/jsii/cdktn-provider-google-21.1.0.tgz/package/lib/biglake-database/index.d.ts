/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BiglakeDatabaseConfig extends cdktn.TerraformMetaArguments {
    /**
    * The parent catalog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_database#catalog BiglakeDatabase#catalog}
    */
    readonly catalog: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_database#deletion_policy BiglakeDatabase#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_database#id BiglakeDatabase#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_database#name BiglakeDatabase#name}
    */
    readonly name: string;
    /**
    * The database type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_database#type BiglakeDatabase#type}
    */
    readonly type: string;
    /**
    * hive_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_database#hive_options BiglakeDatabase#hive_options}
    */
    readonly hiveOptions: BiglakeDatabaseHiveOptions;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_database#timeouts BiglakeDatabase#timeouts}
    */
    readonly timeouts?: BiglakeDatabaseTimeouts;
}
export interface BiglakeDatabaseHiveOptions {
    /**
    * Cloud Storage folder URI where the database data is stored, starting with "gs://".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_database#location_uri BiglakeDatabase#location_uri}
    */
    readonly locationUri?: string;
    /**
    * Stores user supplied Hive database parameters. An object containing a
    * list of"key": value pairs.
    * Example: { "name": "wrench", "mass": "1.3kg", "count": "3" }.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_database#parameters BiglakeDatabase#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
}
export declare function biglakeDatabaseHiveOptionsToTerraform(struct?: BiglakeDatabaseHiveOptionsOutputReference | BiglakeDatabaseHiveOptions): any;
export declare function biglakeDatabaseHiveOptionsToHclTerraform(struct?: BiglakeDatabaseHiveOptionsOutputReference | BiglakeDatabaseHiveOptions): any;
export declare class BiglakeDatabaseHiveOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BiglakeDatabaseHiveOptions | undefined;
    set internalValue(value: BiglakeDatabaseHiveOptions | undefined);
    private _locationUri?;
    get locationUri(): string;
    set locationUri(value: string);
    resetLocationUri(): void;
    get locationUriInput(): string | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
}
export interface BiglakeDatabaseTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_database#create BiglakeDatabase#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_database#delete BiglakeDatabase#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_database#update BiglakeDatabase#update}
    */
    readonly update?: string;
}
export declare function biglakeDatabaseTimeoutsToTerraform(struct?: BiglakeDatabaseTimeouts | cdktn.IResolvable): any;
export declare function biglakeDatabaseTimeoutsToHclTerraform(struct?: BiglakeDatabaseTimeouts | cdktn.IResolvable): any;
export declare class BiglakeDatabaseTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BiglakeDatabaseTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BiglakeDatabaseTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_database google_biglake_database}
*/
export declare class BiglakeDatabase extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_biglake_database";
    /**
    * Generates CDKTN code for importing a BiglakeDatabase resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BiglakeDatabase to import
    * @param importFromId The id of the existing BiglakeDatabase that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_database#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BiglakeDatabase to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_database google_biglake_database} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BiglakeDatabaseConfig
    */
    constructor(scope: Construct, id: string, config: BiglakeDatabaseConfig);
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    get catalogInput(): string | undefined;
    get createTime(): string;
    get deleteTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    get expireTime(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    get updateTime(): string;
    private _hiveOptions;
    get hiveOptions(): BiglakeDatabaseHiveOptionsOutputReference;
    putHiveOptions(value: BiglakeDatabaseHiveOptions): void;
    get hiveOptionsInput(): BiglakeDatabaseHiveOptions | undefined;
    private _timeouts;
    get timeouts(): BiglakeDatabaseTimeoutsOutputReference;
    putTimeouts(value: BiglakeDatabaseTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BiglakeDatabaseTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
