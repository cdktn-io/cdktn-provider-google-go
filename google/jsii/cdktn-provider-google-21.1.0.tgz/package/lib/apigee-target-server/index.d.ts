/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigeeTargetServerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server#deletion_policy ApigeeTargetServer#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * A human-readable description of this TargetServer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server#description ApigeeTargetServer#description}
    */
    readonly description?: string;
    /**
    * The Apigee environment group associated with the Apigee environment,
    * in the format 'organizations/{{org_name}}/environments/{{env_name}}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server#env_id ApigeeTargetServer#env_id}
    */
    readonly envId: string;
    /**
    * The host name this target connects to. Value must be a valid hostname as described by RFC-1123.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server#host ApigeeTargetServer#host}
    */
    readonly host: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server#id ApigeeTargetServer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Enabling/disabling a TargetServer is useful when TargetServers are used in load balancing configurations, and one or more TargetServers need to taken out of rotation periodically. Defaults to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server#is_enabled ApigeeTargetServer#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * The resource id of this reference. Values must match the regular expression [\w\s-.]+.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server#name ApigeeTargetServer#name}
    */
    readonly name: string;
    /**
    * The port number this target connects to on the given host. Value must be between 1 and 65535, inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server#port ApigeeTargetServer#port}
    */
    readonly port: number;
    /**
    * Immutable. The protocol used by this TargetServer. Possible values: ["HTTP", "HTTP2", "GRPC_TARGET", "GRPC", "EXTERNAL_CALLOUT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server#protocol ApigeeTargetServer#protocol}
    */
    readonly protocol?: string;
    /**
    * s_sl_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server#s_sl_info ApigeeTargetServer#s_sl_info}
    */
    readonly sSlInfo?: ApigeeTargetServerSSlInfo;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server#timeouts ApigeeTargetServer#timeouts}
    */
    readonly timeouts?: ApigeeTargetServerTimeouts;
}
export interface ApigeeTargetServerSSlInfoCommonName {
    /**
    * The TLS Common Name string of the certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server#value ApigeeTargetServer#value}
    */
    readonly value?: string;
    /**
    * Indicates whether the cert should be matched against as a wildcard cert.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server#wildcard_match ApigeeTargetServer#wildcard_match}
    */
    readonly wildcardMatch?: boolean | cdktn.IResolvable;
}
export declare function apigeeTargetServerSSlInfoCommonNameToTerraform(struct?: ApigeeTargetServerSSlInfoCommonNameOutputReference | ApigeeTargetServerSSlInfoCommonName): any;
export declare function apigeeTargetServerSSlInfoCommonNameToHclTerraform(struct?: ApigeeTargetServerSSlInfoCommonNameOutputReference | ApigeeTargetServerSSlInfoCommonName): any;
export declare class ApigeeTargetServerSSlInfoCommonNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeTargetServerSSlInfoCommonName | undefined;
    set internalValue(value: ApigeeTargetServerSSlInfoCommonName | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _wildcardMatch?;
    get wildcardMatch(): boolean | cdktn.IResolvable;
    set wildcardMatch(value: boolean | cdktn.IResolvable);
    resetWildcardMatch(): void;
    get wildcardMatchInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ApigeeTargetServerSSlInfo {
    /**
    * The SSL/TLS cipher suites to be used. For programmable proxies, it must be one of the cipher suite names listed in: http://docs.oracle.com/javase/8/docs/technotes/guides/security/StandardNames.html#ciphersuites. For configurable proxies, it must follow the configuration specified in: https://commondatastorage.googleapis.com/chromium-boringssl-docs/ssl.h.html#Cipher-suite-configuration. This setting has no effect for configurable proxies when negotiating TLS 1.3.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server#ciphers ApigeeTargetServer#ciphers}
    */
    readonly ciphers?: string[];
    /**
    * Enables two-way TLS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server#client_auth_enabled ApigeeTargetServer#client_auth_enabled}
    */
    readonly clientAuthEnabled?: boolean | cdktn.IResolvable;
    /**
    * Enables TLS. If false, neither one-way nor two-way TLS will be enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server#enabled ApigeeTargetServer#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * If true, TLS is strictly enforced.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server#enforce ApigeeTargetServer#enforce}
    */
    readonly enforce?: boolean | cdktn.IResolvable;
    /**
    * If true, Edge ignores TLS certificate errors. Valid when configuring TLS for target servers and target endpoints, and when configuring virtual hosts that use 2-way TLS. When used with a target endpoint/target server, if the backend system uses SNI and returns a cert with a subject Distinguished Name (DN) that does not match the hostname, there is no way to ignore the error and the connection fails.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server#ignore_validation_errors ApigeeTargetServer#ignore_validation_errors}
    */
    readonly ignoreValidationErrors?: boolean | cdktn.IResolvable;
    /**
    * Required if clientAuthEnabled is true. The resource ID for the alias containing the private key and cert.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server#key_alias ApigeeTargetServer#key_alias}
    */
    readonly keyAlias?: string;
    /**
    * Required if clientAuthEnabled is true. The resource ID of the keystore.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server#key_store ApigeeTargetServer#key_store}
    */
    readonly keyStore?: string;
    /**
    * The TLS versioins to be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server#protocols ApigeeTargetServer#protocols}
    */
    readonly protocols?: string[];
    /**
    * The resource ID of the truststore.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server#trust_store ApigeeTargetServer#trust_store}
    */
    readonly trustStore?: string;
    /**
    * common_name block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server#common_name ApigeeTargetServer#common_name}
    */
    readonly commonName?: ApigeeTargetServerSSlInfoCommonName;
}
export declare function apigeeTargetServerSSlInfoToTerraform(struct?: ApigeeTargetServerSSlInfoOutputReference | ApigeeTargetServerSSlInfo): any;
export declare function apigeeTargetServerSSlInfoToHclTerraform(struct?: ApigeeTargetServerSSlInfoOutputReference | ApigeeTargetServerSSlInfo): any;
export declare class ApigeeTargetServerSSlInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeTargetServerSSlInfo | undefined;
    set internalValue(value: ApigeeTargetServerSSlInfo | undefined);
    private _ciphers?;
    get ciphers(): string[];
    set ciphers(value: string[]);
    resetCiphers(): void;
    get ciphersInput(): string[] | undefined;
    private _clientAuthEnabled?;
    get clientAuthEnabled(): boolean | cdktn.IResolvable;
    set clientAuthEnabled(value: boolean | cdktn.IResolvable);
    resetClientAuthEnabled(): void;
    get clientAuthEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _enforce?;
    get enforce(): boolean | cdktn.IResolvable;
    set enforce(value: boolean | cdktn.IResolvable);
    resetEnforce(): void;
    get enforceInput(): boolean | cdktn.IResolvable | undefined;
    private _ignoreValidationErrors?;
    get ignoreValidationErrors(): boolean | cdktn.IResolvable;
    set ignoreValidationErrors(value: boolean | cdktn.IResolvable);
    resetIgnoreValidationErrors(): void;
    get ignoreValidationErrorsInput(): boolean | cdktn.IResolvable | undefined;
    private _keyAlias?;
    get keyAlias(): string;
    set keyAlias(value: string);
    resetKeyAlias(): void;
    get keyAliasInput(): string | undefined;
    private _keyStore?;
    get keyStore(): string;
    set keyStore(value: string);
    resetKeyStore(): void;
    get keyStoreInput(): string | undefined;
    private _protocols?;
    get protocols(): string[];
    set protocols(value: string[]);
    resetProtocols(): void;
    get protocolsInput(): string[] | undefined;
    private _trustStore?;
    get trustStore(): string;
    set trustStore(value: string);
    resetTrustStore(): void;
    get trustStoreInput(): string | undefined;
    private _commonName;
    get commonName(): ApigeeTargetServerSSlInfoCommonNameOutputReference;
    putCommonName(value: ApigeeTargetServerSSlInfoCommonName): void;
    resetCommonName(): void;
    get commonNameInput(): ApigeeTargetServerSSlInfoCommonName | undefined;
}
export interface ApigeeTargetServerTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server#create ApigeeTargetServer#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server#delete ApigeeTargetServer#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server#update ApigeeTargetServer#update}
    */
    readonly update?: string;
}
export declare function apigeeTargetServerTimeoutsToTerraform(struct?: ApigeeTargetServerTimeouts | cdktn.IResolvable): any;
export declare function apigeeTargetServerTimeoutsToHclTerraform(struct?: ApigeeTargetServerTimeouts | cdktn.IResolvable): any;
export declare class ApigeeTargetServerTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeTargetServerTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeTargetServerTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server google_apigee_target_server}
*/
export declare class ApigeeTargetServer extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apigee_target_server";
    /**
    * Generates CDKTN code for importing a ApigeeTargetServer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigeeTargetServer to import
    * @param importFromId The id of the existing ApigeeTargetServer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigeeTargetServer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_target_server google_apigee_target_server} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigeeTargetServerConfig
    */
    constructor(scope: Construct, id: string, config: ApigeeTargetServerConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _envId?;
    get envId(): string;
    set envId(value: string);
    get envIdInput(): string | undefined;
    private _host?;
    get host(): string;
    set host(value: string);
    get hostInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    resetProtocol(): void;
    get protocolInput(): string | undefined;
    private _sSlInfo;
    get sSlInfo(): ApigeeTargetServerSSlInfoOutputReference;
    putSSlInfo(value: ApigeeTargetServerSSlInfo): void;
    resetSSlInfo(): void;
    get sSlInfoInput(): ApigeeTargetServerSSlInfo | undefined;
    private _timeouts;
    get timeouts(): ApigeeTargetServerTimeoutsOutputReference;
    putTimeouts(value: ApigeeTargetServerTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApigeeTargetServerTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
