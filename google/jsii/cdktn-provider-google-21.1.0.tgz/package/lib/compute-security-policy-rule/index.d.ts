/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeSecurityPolicyRuleAConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Action to perform when the rule is matched. The following are the valid actions:
    *
    * * allow: allow access to target.
    *
    * * deny(STATUS): deny access to target, returns the HTTP response code specified. Valid values for STATUS are 403, 404, and 502.
    *
    * * rate_based_ban: limit client traffic to the configured threshold and ban the client if the traffic exceeds the threshold. Configure parameters for this action in RateLimitOptions. Requires rateLimitOptions to be set.
    *
    * * redirect: redirect to a different target. This can either be an internal reCAPTCHA redirect, or an external URL-based redirect via a 302 response. Parameters for this action can be configured via redirectOptions. This action is only supported in Global Security Policies of type CLOUD_ARMOR.
    *
    * * throttle: limit client traffic to the configured threshold. Configure parameters for this action in rateLimitOptions. Requires rateLimitOptions to be set for this.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#action ComputeSecurityPolicyRuleA#action}
    */
    readonly action: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#deletion_policy ComputeSecurityPolicyRuleA#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource. Provide this property when you create the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#description ComputeSecurityPolicyRuleA#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#id ComputeSecurityPolicyRuleA#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * If set to true, the specified action is not enforced.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#preview ComputeSecurityPolicyRuleA#preview}
    */
    readonly preview?: boolean | cdktn.IResolvable;
    /**
    * An integer indicating the priority of a rule in the list.
    * The priority must be a positive value between 0 and 2147483647.
    * Rules are evaluated from highest to lowest priority where 0 is the highest priority and 2147483647 is the lowest priority.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#priority ComputeSecurityPolicyRuleA#priority}
    */
    readonly priority: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#project ComputeSecurityPolicyRuleA#project}
    */
    readonly project?: string;
    /**
    * The name of the security policy this rule belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#security_policy ComputeSecurityPolicyRuleA#security_policy}
    */
    readonly securityPolicy: string;
    /**
    * header_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#header_action ComputeSecurityPolicyRuleA#header_action}
    */
    readonly headerAction?: ComputeSecurityPolicyRuleHeaderActionA;
    /**
    * match block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#match ComputeSecurityPolicyRuleA#match}
    */
    readonly match?: ComputeSecurityPolicyRuleMatchA;
    /**
    * preconfigured_waf_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#preconfigured_waf_config ComputeSecurityPolicyRuleA#preconfigured_waf_config}
    */
    readonly preconfiguredWafConfig?: ComputeSecurityPolicyRulePreconfiguredWafConfigA;
    /**
    * rate_limit_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#rate_limit_options ComputeSecurityPolicyRuleA#rate_limit_options}
    */
    readonly rateLimitOptions?: ComputeSecurityPolicyRuleRateLimitOptionsA;
    /**
    * redirect_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#redirect_options ComputeSecurityPolicyRuleA#redirect_options}
    */
    readonly redirectOptions?: ComputeSecurityPolicyRuleRedirectOptionsA;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#timeouts ComputeSecurityPolicyRuleA#timeouts}
    */
    readonly timeouts?: ComputeSecurityPolicyRuleTimeouts;
}
export interface ComputeSecurityPolicyRuleHeaderActionRequestHeadersToAddsA {
    /**
    * The name of the header to set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#header_name ComputeSecurityPolicyRuleA#header_name}
    */
    readonly headerName?: string;
    /**
    * The value to set the named header to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#header_value ComputeSecurityPolicyRuleA#header_value}
    */
    readonly headerValue?: string;
}
export declare function computeSecurityPolicyRuleHeaderActionRequestHeadersToAddsAToTerraform(struct?: ComputeSecurityPolicyRuleHeaderActionRequestHeadersToAddsA | cdktn.IResolvable): any;
export declare function computeSecurityPolicyRuleHeaderActionRequestHeadersToAddsAToHclTerraform(struct?: ComputeSecurityPolicyRuleHeaderActionRequestHeadersToAddsA | cdktn.IResolvable): any;
export declare class ComputeSecurityPolicyRuleHeaderActionRequestHeadersToAddsAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeSecurityPolicyRuleHeaderActionRequestHeadersToAddsA | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeSecurityPolicyRuleHeaderActionRequestHeadersToAddsA | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    resetHeaderName(): void;
    get headerNameInput(): string | undefined;
    private _headerValue?;
    get headerValue(): string;
    set headerValue(value: string);
    resetHeaderValue(): void;
    get headerValueInput(): string | undefined;
}
export declare class ComputeSecurityPolicyRuleHeaderActionRequestHeadersToAddsAList extends cdktn.ComplexList {
    internalValue?: ComputeSecurityPolicyRuleHeaderActionRequestHeadersToAddsA[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeSecurityPolicyRuleHeaderActionRequestHeadersToAddsAOutputReference;
}
export interface ComputeSecurityPolicyRuleHeaderActionA {
    /**
    * request_headers_to_adds block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#request_headers_to_adds ComputeSecurityPolicyRuleA#request_headers_to_adds}
    */
    readonly requestHeadersToAdds?: ComputeSecurityPolicyRuleHeaderActionRequestHeadersToAddsA[] | cdktn.IResolvable;
}
export declare function computeSecurityPolicyRuleHeaderActionAToTerraform(struct?: ComputeSecurityPolicyRuleHeaderActionAOutputReference | ComputeSecurityPolicyRuleHeaderActionA): any;
export declare function computeSecurityPolicyRuleHeaderActionAToHclTerraform(struct?: ComputeSecurityPolicyRuleHeaderActionAOutputReference | ComputeSecurityPolicyRuleHeaderActionA): any;
export declare class ComputeSecurityPolicyRuleHeaderActionAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyRuleHeaderActionA | undefined;
    set internalValue(value: ComputeSecurityPolicyRuleHeaderActionA | undefined);
    private _requestHeadersToAdds;
    get requestHeadersToAdds(): ComputeSecurityPolicyRuleHeaderActionRequestHeadersToAddsAList;
    putRequestHeadersToAdds(value: ComputeSecurityPolicyRuleHeaderActionRequestHeadersToAddsA[] | cdktn.IResolvable): void;
    resetRequestHeadersToAdds(): void;
    get requestHeadersToAddsInput(): cdktn.IResolvable | ComputeSecurityPolicyRuleHeaderActionRequestHeadersToAddsA[] | undefined;
}
export interface ComputeSecurityPolicyRuleMatchConfigA {
    /**
    * CIDR IP address range. Maximum number of srcIpRanges allowed is 10.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#src_ip_ranges ComputeSecurityPolicyRuleA#src_ip_ranges}
    */
    readonly srcIpRanges?: string[];
}
export declare function computeSecurityPolicyRuleMatchConfigAToTerraform(struct?: ComputeSecurityPolicyRuleMatchConfigAOutputReference | ComputeSecurityPolicyRuleMatchConfigA): any;
export declare function computeSecurityPolicyRuleMatchConfigAToHclTerraform(struct?: ComputeSecurityPolicyRuleMatchConfigAOutputReference | ComputeSecurityPolicyRuleMatchConfigA): any;
export declare class ComputeSecurityPolicyRuleMatchConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyRuleMatchConfigA | undefined;
    set internalValue(value: ComputeSecurityPolicyRuleMatchConfigA | undefined);
    private _srcIpRanges?;
    get srcIpRanges(): string[];
    set srcIpRanges(value: string[]);
    resetSrcIpRanges(): void;
    get srcIpRangesInput(): string[] | undefined;
}
export interface ComputeSecurityPolicyRuleMatchExprA {
    /**
    * Textual representation of an expression in Common Expression Language syntax. The application context of the containing message determines which well-known feature set of CEL is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#expression ComputeSecurityPolicyRuleA#expression}
    */
    readonly expression: string;
}
export declare function computeSecurityPolicyRuleMatchExprAToTerraform(struct?: ComputeSecurityPolicyRuleMatchExprAOutputReference | ComputeSecurityPolicyRuleMatchExprA): any;
export declare function computeSecurityPolicyRuleMatchExprAToHclTerraform(struct?: ComputeSecurityPolicyRuleMatchExprAOutputReference | ComputeSecurityPolicyRuleMatchExprA): any;
export declare class ComputeSecurityPolicyRuleMatchExprAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyRuleMatchExprA | undefined;
    set internalValue(value: ComputeSecurityPolicyRuleMatchExprA | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
}
export interface ComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptionsA {
    /**
    * A list of site keys to be used during the validation of reCAPTCHA action-tokens. The provided site keys need to be created from reCAPTCHA API under the same project where the security policy is created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#action_token_site_keys ComputeSecurityPolicyRuleA#action_token_site_keys}
    */
    readonly actionTokenSiteKeys?: string[];
    /**
    * A list of site keys to be used during the validation of reCAPTCHA session-tokens. The provided site keys need to be created from reCAPTCHA API under the same project where the security policy is created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#session_token_site_keys ComputeSecurityPolicyRuleA#session_token_site_keys}
    */
    readonly sessionTokenSiteKeys?: string[];
}
export declare function computeSecurityPolicyRuleMatchExprOptionsRecaptchaOptionsAToTerraform(struct?: ComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptionsAOutputReference | ComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptionsA): any;
export declare function computeSecurityPolicyRuleMatchExprOptionsRecaptchaOptionsAToHclTerraform(struct?: ComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptionsAOutputReference | ComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptionsA): any;
export declare class ComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptionsAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptionsA | undefined;
    set internalValue(value: ComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptionsA | undefined);
    private _actionTokenSiteKeys?;
    get actionTokenSiteKeys(): string[];
    set actionTokenSiteKeys(value: string[]);
    resetActionTokenSiteKeys(): void;
    get actionTokenSiteKeysInput(): string[] | undefined;
    private _sessionTokenSiteKeys?;
    get sessionTokenSiteKeys(): string[];
    set sessionTokenSiteKeys(value: string[]);
    resetSessionTokenSiteKeys(): void;
    get sessionTokenSiteKeysInput(): string[] | undefined;
}
export interface ComputeSecurityPolicyRuleMatchExprOptionsA {
    /**
    * recaptcha_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#recaptcha_options ComputeSecurityPolicyRuleA#recaptcha_options}
    */
    readonly recaptchaOptions: ComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptionsA;
}
export declare function computeSecurityPolicyRuleMatchExprOptionsAToTerraform(struct?: ComputeSecurityPolicyRuleMatchExprOptionsAOutputReference | ComputeSecurityPolicyRuleMatchExprOptionsA): any;
export declare function computeSecurityPolicyRuleMatchExprOptionsAToHclTerraform(struct?: ComputeSecurityPolicyRuleMatchExprOptionsAOutputReference | ComputeSecurityPolicyRuleMatchExprOptionsA): any;
export declare class ComputeSecurityPolicyRuleMatchExprOptionsAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyRuleMatchExprOptionsA | undefined;
    set internalValue(value: ComputeSecurityPolicyRuleMatchExprOptionsA | undefined);
    private _recaptchaOptions;
    get recaptchaOptions(): ComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptionsAOutputReference;
    putRecaptchaOptions(value: ComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptionsA): void;
    get recaptchaOptionsInput(): ComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptionsA | undefined;
}
export interface ComputeSecurityPolicyRuleMatchA {
    /**
    * Preconfigured versioned expression. If this field is specified, config must also be specified.
    * Available preconfigured expressions along with their requirements are: SRC_IPS_V1 - must specify the corresponding srcIpRange field in config. Possible values: ["SRC_IPS_V1"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#versioned_expr ComputeSecurityPolicyRuleA#versioned_expr}
    */
    readonly versionedExpr?: string;
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#config ComputeSecurityPolicyRuleA#config}
    */
    readonly config?: ComputeSecurityPolicyRuleMatchConfigA;
    /**
    * expr block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#expr ComputeSecurityPolicyRuleA#expr}
    */
    readonly expr?: ComputeSecurityPolicyRuleMatchExprA;
    /**
    * expr_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#expr_options ComputeSecurityPolicyRuleA#expr_options}
    */
    readonly exprOptions?: ComputeSecurityPolicyRuleMatchExprOptionsA;
}
export declare function computeSecurityPolicyRuleMatchAToTerraform(struct?: ComputeSecurityPolicyRuleMatchAOutputReference | ComputeSecurityPolicyRuleMatchA): any;
export declare function computeSecurityPolicyRuleMatchAToHclTerraform(struct?: ComputeSecurityPolicyRuleMatchAOutputReference | ComputeSecurityPolicyRuleMatchA): any;
export declare class ComputeSecurityPolicyRuleMatchAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyRuleMatchA | undefined;
    set internalValue(value: ComputeSecurityPolicyRuleMatchA | undefined);
    private _versionedExpr?;
    get versionedExpr(): string;
    set versionedExpr(value: string);
    resetVersionedExpr(): void;
    get versionedExprInput(): string | undefined;
    private _config;
    get config(): ComputeSecurityPolicyRuleMatchConfigAOutputReference;
    putConfig(value: ComputeSecurityPolicyRuleMatchConfigA): void;
    resetConfig(): void;
    get configInput(): ComputeSecurityPolicyRuleMatchConfigA | undefined;
    private _expr;
    get expr(): ComputeSecurityPolicyRuleMatchExprAOutputReference;
    putExpr(value: ComputeSecurityPolicyRuleMatchExprA): void;
    resetExpr(): void;
    get exprInput(): ComputeSecurityPolicyRuleMatchExprA | undefined;
    private _exprOptions;
    get exprOptions(): ComputeSecurityPolicyRuleMatchExprOptionsAOutputReference;
    putExprOptions(value: ComputeSecurityPolicyRuleMatchExprOptionsA): void;
    resetExprOptions(): void;
    get exprOptionsInput(): ComputeSecurityPolicyRuleMatchExprOptionsA | undefined;
}
export interface ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieA {
    /**
    * You can specify an exact match or a partial match by using a field operator and a field value.
    * Available options:
    * EQUALS: The operator matches if the field value equals the specified value.
    * STARTS_WITH: The operator matches if the field value starts with the specified value.
    * ENDS_WITH: The operator matches if the field value ends with the specified value.
    * CONTAINS: The operator matches if the field value contains the specified value.
    * EQUALS_ANY: The operator matches if the field value is any value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#operator ComputeSecurityPolicyRuleA#operator}
    */
    readonly operator: string;
    /**
    * A request field matching the specified value will be excluded from inspection during preconfigured WAF evaluation.
    * The field value must be given if the field operator is not EQUALS_ANY, and cannot be given if the field operator is EQUALS_ANY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#value ComputeSecurityPolicyRuleA#value}
    */
    readonly value?: string;
}
export declare function computeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieAToTerraform(struct?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieA | cdktn.IResolvable): any;
export declare function computeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieAToHclTerraform(struct?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieA | cdktn.IResolvable): any;
export declare class ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieA | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieA | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieAList extends cdktn.ComplexList {
    internalValue?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieA[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieAOutputReference;
}
export interface ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderA {
    /**
    * You can specify an exact match or a partial match by using a field operator and a field value.
    * Available options:
    * EQUALS: The operator matches if the field value equals the specified value.
    * STARTS_WITH: The operator matches if the field value starts with the specified value.
    * ENDS_WITH: The operator matches if the field value ends with the specified value.
    * CONTAINS: The operator matches if the field value contains the specified value.
    * EQUALS_ANY: The operator matches if the field value is any value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#operator ComputeSecurityPolicyRuleA#operator}
    */
    readonly operator: string;
    /**
    * A request field matching the specified value will be excluded from inspection during preconfigured WAF evaluation.
    * The field value must be given if the field operator is not EQUALS_ANY, and cannot be given if the field operator is EQUALS_ANY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#value ComputeSecurityPolicyRuleA#value}
    */
    readonly value?: string;
}
export declare function computeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderAToTerraform(struct?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderA | cdktn.IResolvable): any;
export declare function computeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderAToHclTerraform(struct?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderA | cdktn.IResolvable): any;
export declare class ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderA | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderA | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderAList extends cdktn.ComplexList {
    internalValue?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderA[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderAOutputReference;
}
export interface ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamA {
    /**
    * You can specify an exact match or a partial match by using a field operator and a field value.
    * Available options:
    * EQUALS: The operator matches if the field value equals the specified value.
    * STARTS_WITH: The operator matches if the field value starts with the specified value.
    * ENDS_WITH: The operator matches if the field value ends with the specified value.
    * CONTAINS: The operator matches if the field value contains the specified value.
    * EQUALS_ANY: The operator matches if the field value is any value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#operator ComputeSecurityPolicyRuleA#operator}
    */
    readonly operator: string;
    /**
    * A request field matching the specified value will be excluded from inspection during preconfigured WAF evaluation.
    * The field value must be given if the field operator is not EQUALS_ANY, and cannot be given if the field operator is EQUALS_ANY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#value ComputeSecurityPolicyRuleA#value}
    */
    readonly value?: string;
}
export declare function computeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamAToTerraform(struct?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamA | cdktn.IResolvable): any;
export declare function computeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamAToHclTerraform(struct?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamA | cdktn.IResolvable): any;
export declare class ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamA | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamA | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamAList extends cdktn.ComplexList {
    internalValue?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamA[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamAOutputReference;
}
export interface ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriA {
    /**
    * You can specify an exact match or a partial match by using a field operator and a field value.
    * Available options:
    * EQUALS: The operator matches if the field value equals the specified value.
    * STARTS_WITH: The operator matches if the field value starts with the specified value.
    * ENDS_WITH: The operator matches if the field value ends with the specified value.
    * CONTAINS: The operator matches if the field value contains the specified value.
    * EQUALS_ANY: The operator matches if the field value is any value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#operator ComputeSecurityPolicyRuleA#operator}
    */
    readonly operator: string;
    /**
    * A request field matching the specified value will be excluded from inspection during preconfigured WAF evaluation.
    * The field value must be given if the field operator is not EQUALS_ANY, and cannot be given if the field operator is EQUALS_ANY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#value ComputeSecurityPolicyRuleA#value}
    */
    readonly value?: string;
}
export declare function computeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriAToTerraform(struct?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriA | cdktn.IResolvable): any;
export declare function computeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriAToHclTerraform(struct?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriA | cdktn.IResolvable): any;
export declare class ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriA | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriA | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriAList extends cdktn.ComplexList {
    internalValue?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriA[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriAOutputReference;
}
export interface ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionA {
    /**
    * A list of target rule IDs under the WAF rule set to apply the preconfigured WAF exclusion.
    * If omitted, it refers to all the rule IDs under the WAF rule set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#target_rule_ids ComputeSecurityPolicyRuleA#target_rule_ids}
    */
    readonly targetRuleIds?: string[];
    /**
    * Target WAF rule set to apply the preconfigured WAF exclusion.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#target_rule_set ComputeSecurityPolicyRuleA#target_rule_set}
    */
    readonly targetRuleSet: string;
    /**
    * request_cookie block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#request_cookie ComputeSecurityPolicyRuleA#request_cookie}
    */
    readonly requestCookie?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieA[] | cdktn.IResolvable;
    /**
    * request_header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#request_header ComputeSecurityPolicyRuleA#request_header}
    */
    readonly requestHeader?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderA[] | cdktn.IResolvable;
    /**
    * request_query_param block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#request_query_param ComputeSecurityPolicyRuleA#request_query_param}
    */
    readonly requestQueryParam?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamA[] | cdktn.IResolvable;
    /**
    * request_uri block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#request_uri ComputeSecurityPolicyRuleA#request_uri}
    */
    readonly requestUri?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriA[] | cdktn.IResolvable;
}
export declare function computeSecurityPolicyRulePreconfiguredWafConfigExclusionAToTerraform(struct?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionA | cdktn.IResolvable): any;
export declare function computeSecurityPolicyRulePreconfiguredWafConfigExclusionAToHclTerraform(struct?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionA | cdktn.IResolvable): any;
export declare class ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionA | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionA | cdktn.IResolvable | undefined);
    private _targetRuleIds?;
    get targetRuleIds(): string[];
    set targetRuleIds(value: string[]);
    resetTargetRuleIds(): void;
    get targetRuleIdsInput(): string[] | undefined;
    private _targetRuleSet?;
    get targetRuleSet(): string;
    set targetRuleSet(value: string);
    get targetRuleSetInput(): string | undefined;
    private _requestCookie;
    get requestCookie(): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieAList;
    putRequestCookie(value: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieA[] | cdktn.IResolvable): void;
    resetRequestCookie(): void;
    get requestCookieInput(): cdktn.IResolvable | ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieA[] | undefined;
    private _requestHeader;
    get requestHeader(): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderAList;
    putRequestHeader(value: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderA[] | cdktn.IResolvable): void;
    resetRequestHeader(): void;
    get requestHeaderInput(): cdktn.IResolvable | ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderA[] | undefined;
    private _requestQueryParam;
    get requestQueryParam(): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamAList;
    putRequestQueryParam(value: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamA[] | cdktn.IResolvable): void;
    resetRequestQueryParam(): void;
    get requestQueryParamInput(): cdktn.IResolvable | ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamA[] | undefined;
    private _requestUri;
    get requestUri(): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriAList;
    putRequestUri(value: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriA[] | cdktn.IResolvable): void;
    resetRequestUri(): void;
    get requestUriInput(): cdktn.IResolvable | ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriA[] | undefined;
}
export declare class ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionAList extends cdktn.ComplexList {
    internalValue?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionA[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionAOutputReference;
}
export interface ComputeSecurityPolicyRulePreconfiguredWafConfigA {
    /**
    * exclusion block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#exclusion ComputeSecurityPolicyRuleA#exclusion}
    */
    readonly exclusion?: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionA[] | cdktn.IResolvable;
}
export declare function computeSecurityPolicyRulePreconfiguredWafConfigAToTerraform(struct?: ComputeSecurityPolicyRulePreconfiguredWafConfigAOutputReference | ComputeSecurityPolicyRulePreconfiguredWafConfigA): any;
export declare function computeSecurityPolicyRulePreconfiguredWafConfigAToHclTerraform(struct?: ComputeSecurityPolicyRulePreconfiguredWafConfigAOutputReference | ComputeSecurityPolicyRulePreconfiguredWafConfigA): any;
export declare class ComputeSecurityPolicyRulePreconfiguredWafConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyRulePreconfiguredWafConfigA | undefined;
    set internalValue(value: ComputeSecurityPolicyRulePreconfiguredWafConfigA | undefined);
    private _exclusion;
    get exclusion(): ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionAList;
    putExclusion(value: ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionA[] | cdktn.IResolvable): void;
    resetExclusion(): void;
    get exclusionInput(): cdktn.IResolvable | ComputeSecurityPolicyRulePreconfiguredWafConfigExclusionA[] | undefined;
}
export interface ComputeSecurityPolicyRuleRateLimitOptionsBanThresholdA {
    /**
    * Number of HTTP(S) requests for calculating the threshold.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#count ComputeSecurityPolicyRuleA#count}
    */
    readonly count?: number;
    /**
    * Interval over which the threshold is computed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#interval_sec ComputeSecurityPolicyRuleA#interval_sec}
    */
    readonly intervalSec?: number;
}
export declare function computeSecurityPolicyRuleRateLimitOptionsBanThresholdAToTerraform(struct?: ComputeSecurityPolicyRuleRateLimitOptionsBanThresholdAOutputReference | ComputeSecurityPolicyRuleRateLimitOptionsBanThresholdA): any;
export declare function computeSecurityPolicyRuleRateLimitOptionsBanThresholdAToHclTerraform(struct?: ComputeSecurityPolicyRuleRateLimitOptionsBanThresholdAOutputReference | ComputeSecurityPolicyRuleRateLimitOptionsBanThresholdA): any;
export declare class ComputeSecurityPolicyRuleRateLimitOptionsBanThresholdAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyRuleRateLimitOptionsBanThresholdA | undefined;
    set internalValue(value: ComputeSecurityPolicyRuleRateLimitOptionsBanThresholdA | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    resetCount(): void;
    get countInput(): number | undefined;
    private _intervalSec?;
    get intervalSec(): number;
    set intervalSec(value: number);
    resetIntervalSec(): void;
    get intervalSecInput(): number | undefined;
}
export interface ComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsA {
    /**
    * Rate limit key name applicable only for the following key types:
    * HTTP_HEADER -- Name of the HTTP header whose value is taken as the key value.
    * HTTP_COOKIE -- Name of the HTTP cookie whose value is taken as the key value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#enforce_on_key_name ComputeSecurityPolicyRuleA#enforce_on_key_name}
    */
    readonly enforceOnKeyName?: string;
    /**
    * Determines the key to enforce the rateLimitThreshold on. Possible values are:
    * * ALL: A single rate limit threshold is applied to all the requests matching this rule. This is the default value if "enforceOnKeyConfigs" is not configured.
    * * IP: The source IP address of the request is the key. Each IP has this limit enforced separately.
    * * HTTP_HEADER: The value of the HTTP header whose name is configured under "enforceOnKeyName". The key value is truncated to the first 128 bytes of the header value. If no such header is present in the request, the key type defaults to ALL.
    * * XFF_IP: The first IP address (i.e. the originating client IP address) specified in the list of IPs under X-Forwarded-For HTTP header. If no such header is present or the value is not a valid IP, the key defaults to the source IP address of the request i.e. key type IP.
    * * HTTP_COOKIE: The value of the HTTP cookie whose name is configured under "enforceOnKeyName". The key value is truncated to the first 128 bytes of the cookie value. If no such cookie is present in the request, the key type defaults to ALL.
    * * HTTP_PATH: The URL path of the HTTP request. The key value is truncated to the first 128 bytes.
    * * SNI: Server name indication in the TLS session of the HTTPS request. The key value is truncated to the first 128 bytes. The key type defaults to ALL on a HTTP session.
    * * REGION_CODE: The country/region from which the request originates.
    * * TLS_JA3_FINGERPRINT: JA3 TLS/SSL fingerprint if the client connects using HTTPS, HTTP/2 or HTTP/3. If not available, the key type defaults to ALL.
    * * TLS_JA4_FINGERPRINT: JA4 TLS/SSL fingerprint if the client connects using HTTPS, HTTP/2 or HTTP/3. If not available, the key type defaults to ALL.
    * * USER_IP: The IP address of the originating client, which is resolved based on "userIpRequestHeaders" configured with the security policy. If there is no "userIpRequestHeaders" configuration or an IP address cannot be resolved from it, the key type defaults to IP. Possible values: ["ALL", "IP", "HTTP_HEADER", "XFF_IP", "HTTP_COOKIE", "HTTP_PATH", "SNI", "REGION_CODE", "TLS_JA3_FINGERPRINT", "TLS_JA4_FINGERPRINT", "USER_IP"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#enforce_on_key_type ComputeSecurityPolicyRuleA#enforce_on_key_type}
    */
    readonly enforceOnKeyType?: string;
}
export declare function computeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsAToTerraform(struct?: ComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsA | cdktn.IResolvable): any;
export declare function computeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsAToHclTerraform(struct?: ComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsA | cdktn.IResolvable): any;
export declare class ComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsA | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsA | cdktn.IResolvable | undefined);
    private _enforceOnKeyName?;
    get enforceOnKeyName(): string;
    set enforceOnKeyName(value: string);
    resetEnforceOnKeyName(): void;
    get enforceOnKeyNameInput(): string | undefined;
    private _enforceOnKeyType?;
    get enforceOnKeyType(): string;
    set enforceOnKeyType(value: string);
    resetEnforceOnKeyType(): void;
    get enforceOnKeyTypeInput(): string | undefined;
}
export declare class ComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsAList extends cdktn.ComplexList {
    internalValue?: ComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsA[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsAOutputReference;
}
export interface ComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptionsA {
    /**
    * Target for the redirect action. This is required if the type is EXTERNAL_302 and cannot be specified for GOOGLE_RECAPTCHA.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#target ComputeSecurityPolicyRuleA#target}
    */
    readonly target?: string;
    /**
    * Type of the redirect action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#type ComputeSecurityPolicyRuleA#type}
    */
    readonly type?: string;
}
export declare function computeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptionsAToTerraform(struct?: ComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptionsAOutputReference | ComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptionsA): any;
export declare function computeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptionsAToHclTerraform(struct?: ComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptionsAOutputReference | ComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptionsA): any;
export declare class ComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptionsAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptionsA | undefined;
    set internalValue(value: ComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptionsA | undefined);
    private _target?;
    get target(): string;
    set target(value: string);
    resetTarget(): void;
    get targetInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface ComputeSecurityPolicyRuleRateLimitOptionsRateLimitThresholdA {
    /**
    * Number of HTTP(S) requests for calculating the threshold.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#count ComputeSecurityPolicyRuleA#count}
    */
    readonly count?: number;
    /**
    * Interval over which the threshold is computed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#interval_sec ComputeSecurityPolicyRuleA#interval_sec}
    */
    readonly intervalSec?: number;
}
export declare function computeSecurityPolicyRuleRateLimitOptionsRateLimitThresholdAToTerraform(struct?: ComputeSecurityPolicyRuleRateLimitOptionsRateLimitThresholdAOutputReference | ComputeSecurityPolicyRuleRateLimitOptionsRateLimitThresholdA): any;
export declare function computeSecurityPolicyRuleRateLimitOptionsRateLimitThresholdAToHclTerraform(struct?: ComputeSecurityPolicyRuleRateLimitOptionsRateLimitThresholdAOutputReference | ComputeSecurityPolicyRuleRateLimitOptionsRateLimitThresholdA): any;
export declare class ComputeSecurityPolicyRuleRateLimitOptionsRateLimitThresholdAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyRuleRateLimitOptionsRateLimitThresholdA | undefined;
    set internalValue(value: ComputeSecurityPolicyRuleRateLimitOptionsRateLimitThresholdA | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    resetCount(): void;
    get countInput(): number | undefined;
    private _intervalSec?;
    get intervalSec(): number;
    set intervalSec(value: number);
    resetIntervalSec(): void;
    get intervalSecInput(): number | undefined;
}
export interface ComputeSecurityPolicyRuleRateLimitOptionsA {
    /**
    * Can only be specified if the action for the rule is "rate_based_ban".
    * If specified, determines the time (in seconds) the traffic will continue to be banned by the rate limit after the rate falls below the threshold.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#ban_duration_sec ComputeSecurityPolicyRuleA#ban_duration_sec}
    */
    readonly banDurationSec?: number;
    /**
    * Action to take for requests that are under the configured rate limit threshold.
    * Valid option is "allow" only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#conform_action ComputeSecurityPolicyRuleA#conform_action}
    */
    readonly conformAction?: string;
    /**
    * Determines the key to enforce the rateLimitThreshold on. Possible values are:
    * * ALL: A single rate limit threshold is applied to all the requests matching this rule. This is the default value if "enforceOnKey" is not configured.
    * * IP: The source IP address of the request is the key. Each IP has this limit enforced separately.
    * * HTTP_HEADER: The value of the HTTP header whose name is configured under "enforceOnKeyName". The key value is truncated to the first 128 bytes of the header value. If no such header is present in the request, the key type defaults to ALL.
    * * XFF_IP: The first IP address (i.e. the originating client IP address) specified in the list of IPs under X-Forwarded-For HTTP header. If no such header is present or the value is not a valid IP, the key defaults to the source IP address of the request i.e. key type IP.
    * * HTTP_COOKIE: The value of the HTTP cookie whose name is configured under "enforceOnKeyName". The key value is truncated to the first 128 bytes of the cookie value. If no such cookie is present in the request, the key type defaults to ALL.
    * * HTTP_PATH: The URL path of the HTTP request. The key value is truncated to the first 128 bytes.
    * * SNI: Server name indication in the TLS session of the HTTPS request. The key value is truncated to the first 128 bytes. The key type defaults to ALL on a HTTP session.
    * * REGION_CODE: The country/region from which the request originates.
    * * TLS_JA3_FINGERPRINT: JA3 TLS/SSL fingerprint if the client connects using HTTPS, HTTP/2 or HTTP/3. If not available, the key type defaults to ALL.
    * * TLS_JA4_FINGERPRINT: JA4 TLS/SSL fingerprint if the client connects using HTTPS, HTTP/2 or HTTP/3. If not available, the key type defaults to ALL.
    * * USER_IP: The IP address of the originating client, which is resolved based on "userIpRequestHeaders" configured with the security policy. If there is no "userIpRequestHeaders" configuration or an IP address cannot be resolved from it, the key type defaults to IP. Possible values: ["ALL", "IP", "HTTP_HEADER", "XFF_IP", "HTTP_COOKIE", "HTTP_PATH", "SNI", "REGION_CODE", "TLS_JA3_FINGERPRINT", "TLS_JA4_FINGERPRINT", "USER_IP"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#enforce_on_key ComputeSecurityPolicyRuleA#enforce_on_key}
    */
    readonly enforceOnKey?: string;
    /**
    * Rate limit key name applicable only for the following key types:
    * HTTP_HEADER -- Name of the HTTP header whose value is taken as the key value.
    * HTTP_COOKIE -- Name of the HTTP cookie whose value is taken as the key value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#enforce_on_key_name ComputeSecurityPolicyRuleA#enforce_on_key_name}
    */
    readonly enforceOnKeyName?: string;
    /**
    * Action to take for requests that are above the configured rate limit threshold, to either deny with a specified HTTP response code, or redirect to a different endpoint.
    * Valid options are deny(STATUS), where valid values for STATUS are 403, 404, 429, and 502.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#exceed_action ComputeSecurityPolicyRuleA#exceed_action}
    */
    readonly exceedAction?: string;
    /**
    * ban_threshold block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#ban_threshold ComputeSecurityPolicyRuleA#ban_threshold}
    */
    readonly banThreshold?: ComputeSecurityPolicyRuleRateLimitOptionsBanThresholdA;
    /**
    * enforce_on_key_configs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#enforce_on_key_configs ComputeSecurityPolicyRuleA#enforce_on_key_configs}
    */
    readonly enforceOnKeyConfigs?: ComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsA[] | cdktn.IResolvable;
    /**
    * exceed_redirect_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#exceed_redirect_options ComputeSecurityPolicyRuleA#exceed_redirect_options}
    */
    readonly exceedRedirectOptions?: ComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptionsA;
    /**
    * rate_limit_threshold block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#rate_limit_threshold ComputeSecurityPolicyRuleA#rate_limit_threshold}
    */
    readonly rateLimitThreshold?: ComputeSecurityPolicyRuleRateLimitOptionsRateLimitThresholdA;
}
export declare function computeSecurityPolicyRuleRateLimitOptionsAToTerraform(struct?: ComputeSecurityPolicyRuleRateLimitOptionsAOutputReference | ComputeSecurityPolicyRuleRateLimitOptionsA): any;
export declare function computeSecurityPolicyRuleRateLimitOptionsAToHclTerraform(struct?: ComputeSecurityPolicyRuleRateLimitOptionsAOutputReference | ComputeSecurityPolicyRuleRateLimitOptionsA): any;
export declare class ComputeSecurityPolicyRuleRateLimitOptionsAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyRuleRateLimitOptionsA | undefined;
    set internalValue(value: ComputeSecurityPolicyRuleRateLimitOptionsA | undefined);
    private _banDurationSec?;
    get banDurationSec(): number;
    set banDurationSec(value: number);
    resetBanDurationSec(): void;
    get banDurationSecInput(): number | undefined;
    private _conformAction?;
    get conformAction(): string;
    set conformAction(value: string);
    resetConformAction(): void;
    get conformActionInput(): string | undefined;
    private _enforceOnKey?;
    get enforceOnKey(): string;
    set enforceOnKey(value: string);
    resetEnforceOnKey(): void;
    get enforceOnKeyInput(): string | undefined;
    private _enforceOnKeyName?;
    get enforceOnKeyName(): string;
    set enforceOnKeyName(value: string);
    resetEnforceOnKeyName(): void;
    get enforceOnKeyNameInput(): string | undefined;
    private _exceedAction?;
    get exceedAction(): string;
    set exceedAction(value: string);
    resetExceedAction(): void;
    get exceedActionInput(): string | undefined;
    private _banThreshold;
    get banThreshold(): ComputeSecurityPolicyRuleRateLimitOptionsBanThresholdAOutputReference;
    putBanThreshold(value: ComputeSecurityPolicyRuleRateLimitOptionsBanThresholdA): void;
    resetBanThreshold(): void;
    get banThresholdInput(): ComputeSecurityPolicyRuleRateLimitOptionsBanThresholdA | undefined;
    private _enforceOnKeyConfigs;
    get enforceOnKeyConfigs(): ComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsAList;
    putEnforceOnKeyConfigs(value: ComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsA[] | cdktn.IResolvable): void;
    resetEnforceOnKeyConfigs(): void;
    get enforceOnKeyConfigsInput(): cdktn.IResolvable | ComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsA[] | undefined;
    private _exceedRedirectOptions;
    get exceedRedirectOptions(): ComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptionsAOutputReference;
    putExceedRedirectOptions(value: ComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptionsA): void;
    resetExceedRedirectOptions(): void;
    get exceedRedirectOptionsInput(): ComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptionsA | undefined;
    private _rateLimitThreshold;
    get rateLimitThreshold(): ComputeSecurityPolicyRuleRateLimitOptionsRateLimitThresholdAOutputReference;
    putRateLimitThreshold(value: ComputeSecurityPolicyRuleRateLimitOptionsRateLimitThresholdA): void;
    resetRateLimitThreshold(): void;
    get rateLimitThresholdInput(): ComputeSecurityPolicyRuleRateLimitOptionsRateLimitThresholdA | undefined;
}
export interface ComputeSecurityPolicyRuleRedirectOptionsA {
    /**
    * Target for the redirect action. This is required if the type is EXTERNAL_302 and cannot be specified for GOOGLE_RECAPTCHA.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#target ComputeSecurityPolicyRuleA#target}
    */
    readonly target?: string;
    /**
    * Type of the redirect action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#type ComputeSecurityPolicyRuleA#type}
    */
    readonly type?: string;
}
export declare function computeSecurityPolicyRuleRedirectOptionsAToTerraform(struct?: ComputeSecurityPolicyRuleRedirectOptionsAOutputReference | ComputeSecurityPolicyRuleRedirectOptionsA): any;
export declare function computeSecurityPolicyRuleRedirectOptionsAToHclTerraform(struct?: ComputeSecurityPolicyRuleRedirectOptionsAOutputReference | ComputeSecurityPolicyRuleRedirectOptionsA): any;
export declare class ComputeSecurityPolicyRuleRedirectOptionsAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyRuleRedirectOptionsA | undefined;
    set internalValue(value: ComputeSecurityPolicyRuleRedirectOptionsA | undefined);
    private _target?;
    get target(): string;
    set target(value: string);
    resetTarget(): void;
    get targetInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface ComputeSecurityPolicyRuleTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#create ComputeSecurityPolicyRuleA#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#delete ComputeSecurityPolicyRuleA#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#update ComputeSecurityPolicyRuleA#update}
    */
    readonly update?: string;
}
export declare function computeSecurityPolicyRuleTimeoutsToTerraform(struct?: ComputeSecurityPolicyRuleTimeouts | cdktn.IResolvable): any;
export declare function computeSecurityPolicyRuleTimeoutsToHclTerraform(struct?: ComputeSecurityPolicyRuleTimeouts | cdktn.IResolvable): any;
export declare class ComputeSecurityPolicyRuleTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeSecurityPolicyRuleTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeSecurityPolicyRuleTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule google_compute_security_policy_rule}
*/
export declare class ComputeSecurityPolicyRuleA extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_security_policy_rule";
    /**
    * Generates CDKTN code for importing a ComputeSecurityPolicyRuleA resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeSecurityPolicyRuleA to import
    * @param importFromId The id of the existing ComputeSecurityPolicyRuleA that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeSecurityPolicyRuleA to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_security_policy_rule google_compute_security_policy_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeSecurityPolicyRuleAConfig
    */
    constructor(scope: Construct, id: string, config: ComputeSecurityPolicyRuleAConfig);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _preview?;
    get preview(): boolean | cdktn.IResolvable;
    set preview(value: boolean | cdktn.IResolvable);
    resetPreview(): void;
    get previewInput(): boolean | cdktn.IResolvable | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _securityPolicy?;
    get securityPolicy(): string;
    set securityPolicy(value: string);
    get securityPolicyInput(): string | undefined;
    private _headerAction;
    get headerAction(): ComputeSecurityPolicyRuleHeaderActionAOutputReference;
    putHeaderAction(value: ComputeSecurityPolicyRuleHeaderActionA): void;
    resetHeaderAction(): void;
    get headerActionInput(): ComputeSecurityPolicyRuleHeaderActionA | undefined;
    private _match;
    get match(): ComputeSecurityPolicyRuleMatchAOutputReference;
    putMatch(value: ComputeSecurityPolicyRuleMatchA): void;
    resetMatch(): void;
    get matchInput(): ComputeSecurityPolicyRuleMatchA | undefined;
    private _preconfiguredWafConfig;
    get preconfiguredWafConfig(): ComputeSecurityPolicyRulePreconfiguredWafConfigAOutputReference;
    putPreconfiguredWafConfig(value: ComputeSecurityPolicyRulePreconfiguredWafConfigA): void;
    resetPreconfiguredWafConfig(): void;
    get preconfiguredWafConfigInput(): ComputeSecurityPolicyRulePreconfiguredWafConfigA | undefined;
    private _rateLimitOptions;
    get rateLimitOptions(): ComputeSecurityPolicyRuleRateLimitOptionsAOutputReference;
    putRateLimitOptions(value: ComputeSecurityPolicyRuleRateLimitOptionsA): void;
    resetRateLimitOptions(): void;
    get rateLimitOptionsInput(): ComputeSecurityPolicyRuleRateLimitOptionsA | undefined;
    private _redirectOptions;
    get redirectOptions(): ComputeSecurityPolicyRuleRedirectOptionsAOutputReference;
    putRedirectOptions(value: ComputeSecurityPolicyRuleRedirectOptionsA): void;
    resetRedirectOptions(): void;
    get redirectOptionsInput(): ComputeSecurityPolicyRuleRedirectOptionsA | undefined;
    private _timeouts;
    get timeouts(): ComputeSecurityPolicyRuleTimeoutsOutputReference;
    putTimeouts(value: ComputeSecurityPolicyRuleTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeSecurityPolicyRuleTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
