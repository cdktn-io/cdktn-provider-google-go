/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeWireGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Indicates whether the wire group is administratively enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_wire_group#admin_enabled ComputeWireGroup#admin_enabled}
    */
    readonly adminEnabled?: boolean | cdktn.IResolvable;
    /**
    * Required cross site network to which wire group belongs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_wire_group#cross_site_network ComputeWireGroup#cross_site_network}
    */
    readonly crossSiteNetwork: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_wire_group#deletion_policy ComputeWireGroup#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource. Provide this property when you create the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_wire_group#description ComputeWireGroup#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_wire_group#id ComputeWireGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the resource. Provided by the client when the resource is created. The name must be
    * 1-63 characters long, and comply with RFC1035. Specifically, the name must be 1-63 characters
    * long and match the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the first
    * character must be a lowercase letter, and all following characters must be a dash,
    * lowercase letter, or digit, except the last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_wire_group#name ComputeWireGroup#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_wire_group#project ComputeWireGroup#project}
    */
    readonly project?: string;
    /**
    * endpoints block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_wire_group#endpoints ComputeWireGroup#endpoints}
    */
    readonly endpoints?: ComputeWireGroupEndpoints[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_wire_group#timeouts ComputeWireGroup#timeouts}
    */
    readonly timeouts?: ComputeWireGroupTimeouts;
    /**
    * wire_properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_wire_group#wire_properties ComputeWireGroup#wire_properties}
    */
    readonly wireProperties?: ComputeWireGroupWireProperties;
}
export interface ComputeWireGroupTopologyEndpoints {
}
export declare function computeWireGroupTopologyEndpointsToTerraform(struct?: ComputeWireGroupTopologyEndpoints): any;
export declare function computeWireGroupTopologyEndpointsToHclTerraform(struct?: ComputeWireGroupTopologyEndpoints): any;
export declare class ComputeWireGroupTopologyEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeWireGroupTopologyEndpoints | undefined;
    set internalValue(value: ComputeWireGroupTopologyEndpoints | undefined);
    get city(): string;
    get label(): string;
}
export declare class ComputeWireGroupTopologyEndpointsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeWireGroupTopologyEndpointsOutputReference;
}
export interface ComputeWireGroupTopology {
}
export declare function computeWireGroupTopologyToTerraform(struct?: ComputeWireGroupTopology): any;
export declare function computeWireGroupTopologyToHclTerraform(struct?: ComputeWireGroupTopology): any;
export declare class ComputeWireGroupTopologyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeWireGroupTopology | undefined;
    set internalValue(value: ComputeWireGroupTopology | undefined);
    private _endpoints;
    get endpoints(): ComputeWireGroupTopologyEndpointsList;
}
export declare class ComputeWireGroupTopologyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeWireGroupTopologyOutputReference;
}
export interface ComputeWireGroupWiresEndpoints {
}
export declare function computeWireGroupWiresEndpointsToTerraform(struct?: ComputeWireGroupWiresEndpoints): any;
export declare function computeWireGroupWiresEndpointsToHclTerraform(struct?: ComputeWireGroupWiresEndpoints): any;
export declare class ComputeWireGroupWiresEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeWireGroupWiresEndpoints | undefined;
    set internalValue(value: ComputeWireGroupWiresEndpoints | undefined);
    get interconnect(): string;
    get vlanTag(): number;
}
export declare class ComputeWireGroupWiresEndpointsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeWireGroupWiresEndpointsOutputReference;
}
export interface ComputeWireGroupWiresWireProperties {
}
export declare function computeWireGroupWiresWirePropertiesToTerraform(struct?: ComputeWireGroupWiresWireProperties): any;
export declare function computeWireGroupWiresWirePropertiesToHclTerraform(struct?: ComputeWireGroupWiresWireProperties): any;
export declare class ComputeWireGroupWiresWirePropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeWireGroupWiresWireProperties | undefined;
    set internalValue(value: ComputeWireGroupWiresWireProperties | undefined);
    get bandwidthUnmetered(): number;
    get faultResponse(): string;
}
export declare class ComputeWireGroupWiresWirePropertiesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeWireGroupWiresWirePropertiesOutputReference;
}
export interface ComputeWireGroupWires {
}
export declare function computeWireGroupWiresToTerraform(struct?: ComputeWireGroupWires): any;
export declare function computeWireGroupWiresToHclTerraform(struct?: ComputeWireGroupWires): any;
export declare class ComputeWireGroupWiresOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeWireGroupWires | undefined;
    set internalValue(value: ComputeWireGroupWires | undefined);
    get adminEnabled(): cdktn.IResolvable;
    private _endpoints;
    get endpoints(): ComputeWireGroupWiresEndpointsList;
    get label(): string;
    private _wireProperties;
    get wireProperties(): ComputeWireGroupWiresWirePropertiesList;
}
export declare class ComputeWireGroupWiresList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeWireGroupWiresOutputReference;
}
export interface ComputeWireGroupEndpointsInterconnects {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_wire_group#interconnect ComputeWireGroup#interconnect}
    */
    readonly interconnect?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_wire_group#interconnect_name ComputeWireGroup#interconnect_name}
    */
    readonly interconnectName: string;
    /**
    * VLAN tags for the interconnect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_wire_group#vlan_tags ComputeWireGroup#vlan_tags}
    */
    readonly vlanTags?: number[];
}
export declare function computeWireGroupEndpointsInterconnectsToTerraform(struct?: ComputeWireGroupEndpointsInterconnects | cdktn.IResolvable): any;
export declare function computeWireGroupEndpointsInterconnectsToHclTerraform(struct?: ComputeWireGroupEndpointsInterconnects | cdktn.IResolvable): any;
export declare class ComputeWireGroupEndpointsInterconnectsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeWireGroupEndpointsInterconnects | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeWireGroupEndpointsInterconnects | cdktn.IResolvable | undefined);
    private _interconnect?;
    get interconnect(): string;
    set interconnect(value: string);
    resetInterconnect(): void;
    get interconnectInput(): string | undefined;
    private _interconnectName?;
    get interconnectName(): string;
    set interconnectName(value: string);
    get interconnectNameInput(): string | undefined;
    private _vlanTags?;
    get vlanTags(): number[];
    set vlanTags(value: number[]);
    resetVlanTags(): void;
    get vlanTagsInput(): number[] | undefined;
}
export declare class ComputeWireGroupEndpointsInterconnectsList extends cdktn.ComplexList {
    internalValue?: ComputeWireGroupEndpointsInterconnects[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeWireGroupEndpointsInterconnectsOutputReference;
}
export interface ComputeWireGroupEndpoints {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_wire_group#endpoint ComputeWireGroup#endpoint}
    */
    readonly endpoint: string;
    /**
    * interconnects block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_wire_group#interconnects ComputeWireGroup#interconnects}
    */
    readonly interconnects?: ComputeWireGroupEndpointsInterconnects[] | cdktn.IResolvable;
}
export declare function computeWireGroupEndpointsToTerraform(struct?: ComputeWireGroupEndpoints | cdktn.IResolvable): any;
export declare function computeWireGroupEndpointsToHclTerraform(struct?: ComputeWireGroupEndpoints | cdktn.IResolvable): any;
export declare class ComputeWireGroupEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeWireGroupEndpoints | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeWireGroupEndpoints | cdktn.IResolvable | undefined);
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    get endpointInput(): string | undefined;
    private _interconnects;
    get interconnects(): ComputeWireGroupEndpointsInterconnectsList;
    putInterconnects(value: ComputeWireGroupEndpointsInterconnects[] | cdktn.IResolvable): void;
    resetInterconnects(): void;
    get interconnectsInput(): cdktn.IResolvable | ComputeWireGroupEndpointsInterconnects[] | undefined;
}
export declare class ComputeWireGroupEndpointsList extends cdktn.ComplexList {
    internalValue?: ComputeWireGroupEndpoints[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeWireGroupEndpointsOutputReference;
}
export interface ComputeWireGroupTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_wire_group#create ComputeWireGroup#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_wire_group#delete ComputeWireGroup#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_wire_group#update ComputeWireGroup#update}
    */
    readonly update?: string;
}
export declare function computeWireGroupTimeoutsToTerraform(struct?: ComputeWireGroupTimeouts | cdktn.IResolvable): any;
export declare function computeWireGroupTimeoutsToHclTerraform(struct?: ComputeWireGroupTimeouts | cdktn.IResolvable): any;
export declare class ComputeWireGroupTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeWireGroupTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeWireGroupTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface ComputeWireGroupWireProperties {
    /**
    * The configuration of a wire's bandwidth allocation.
    * ALLOCATE_PER_WIRE: configures a separate unmetered bandwidth allocation (and associated charges) for each wire in the group.
    * SHARED_WITH_WIRE_GROUP: this is the default behavior, which configures one unmetered bandwidth allocation for the wire group. The unmetered bandwidth is divided equally across each wire in the group, but dynamic
    * throttling reallocates unused unmetered bandwidth from unused or underused wires to other wires in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_wire_group#bandwidth_allocation ComputeWireGroup#bandwidth_allocation}
    */
    readonly bandwidthAllocation: string;
    /**
    * The unmetered bandwidth setting.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_wire_group#bandwidth_unmetered ComputeWireGroup#bandwidth_unmetered}
    */
    readonly bandwidthUnmetered?: number;
    /**
    * Response when a fault is detected in a pseudowire:
    * NONE: default.
    * DISABLE_PORT: set the port line protocol down when inline probes detect a fault. This setting is only permitted on port mode pseudowires.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_wire_group#fault_response ComputeWireGroup#fault_response}
    */
    readonly faultResponse?: string;
}
export declare function computeWireGroupWirePropertiesToTerraform(struct?: ComputeWireGroupWirePropertiesOutputReference | ComputeWireGroupWireProperties): any;
export declare function computeWireGroupWirePropertiesToHclTerraform(struct?: ComputeWireGroupWirePropertiesOutputReference | ComputeWireGroupWireProperties): any;
export declare class ComputeWireGroupWirePropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeWireGroupWireProperties | undefined;
    set internalValue(value: ComputeWireGroupWireProperties | undefined);
    private _bandwidthAllocation?;
    get bandwidthAllocation(): string;
    set bandwidthAllocation(value: string);
    get bandwidthAllocationInput(): string | undefined;
    private _bandwidthUnmetered?;
    get bandwidthUnmetered(): number;
    set bandwidthUnmetered(value: number);
    resetBandwidthUnmetered(): void;
    get bandwidthUnmeteredInput(): number | undefined;
    private _faultResponse?;
    get faultResponse(): string;
    set faultResponse(value: string);
    resetFaultResponse(): void;
    get faultResponseInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_wire_group google_compute_wire_group}
*/
export declare class ComputeWireGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_wire_group";
    /**
    * Generates CDKTN code for importing a ComputeWireGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeWireGroup to import
    * @param importFromId The id of the existing ComputeWireGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_wire_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeWireGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_wire_group google_compute_wire_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeWireGroupConfig
    */
    constructor(scope: Construct, id: string, config: ComputeWireGroupConfig);
    private _adminEnabled?;
    get adminEnabled(): boolean | cdktn.IResolvable;
    set adminEnabled(value: boolean | cdktn.IResolvable);
    resetAdminEnabled(): void;
    get adminEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get creationTimestamp(): string;
    private _crossSiteNetwork?;
    get crossSiteNetwork(): string;
    set crossSiteNetwork(value: string);
    get crossSiteNetworkInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _topology;
    get topology(): ComputeWireGroupTopologyList;
    private _wires;
    get wires(): ComputeWireGroupWiresList;
    private _endpoints;
    get endpoints(): ComputeWireGroupEndpointsList;
    putEndpoints(value: ComputeWireGroupEndpoints[] | cdktn.IResolvable): void;
    resetEndpoints(): void;
    get endpointsInput(): cdktn.IResolvable | ComputeWireGroupEndpoints[] | undefined;
    private _timeouts;
    get timeouts(): ComputeWireGroupTimeoutsOutputReference;
    putTimeouts(value: ComputeWireGroupTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeWireGroupTimeouts | undefined;
    private _wireProperties;
    get wireProperties(): ComputeWireGroupWirePropertiesOutputReference;
    putWireProperties(value: ComputeWireGroupWireProperties): void;
    resetWireProperties(): void;
    get wirePropertiesInput(): ComputeWireGroupWireProperties | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
