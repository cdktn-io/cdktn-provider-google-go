/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigeeSecurityActionConfig extends cdktn.TerraformMetaArguments {
    /**
    * If unset, this would apply to all proxies in the environment.
    * If set, this action is enforced only if at least one proxy in the repeated
    * list is deployed at the time of enforcement. If set, several restrictions are enforced on SecurityActions.
    * There can be at most 100 enabled actions with proxies set in an env.
    * Several other restrictions apply on conditions and are detailed later.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#api_proxies ApigeeSecurityAction#api_proxies}
    */
    readonly apiProxies?: string[];
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#deletion_policy ApigeeSecurityAction#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional user provided description of the SecurityAction.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#description ApigeeSecurityAction#description}
    */
    readonly description?: string;
    /**
    * The Apigee environment that this security action applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#env_id ApigeeSecurityAction#env_id}
    */
    readonly envId: string;
    /**
    * The expiration for this SecurityAction.
    * Uses RFC 3339, where generated output will always be Z-normalized and uses 0, 3, 6 or 9
    * fractional digits. Offsets other than "Z" are also accepted.
    * Examples: "2014-10-02T15:01:23Z", "2014-10-02T15:01:23.045123456Z" or "2014-10-02T15:01:23+05:30".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#expire_time ApigeeSecurityAction#expire_time}
    */
    readonly expireTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#id ApigeeSecurityAction#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The organization that this security action applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#org_id ApigeeSecurityAction#org_id}
    */
    readonly orgId: string;
    /**
    * The ID to use for the SecurityAction, which will become the final component of the action's resource name.
    * This value should be 0-61 characters, and valid format is (^a-z?$).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#security_action_id ApigeeSecurityAction#security_action_id}
    */
    readonly securityActionId: string;
    /**
    * Only an ENABLED SecurityAction is enforced. An ENABLED SecurityAction past its expiration time will not be enforced. Possible values: ["ENABLED", "DISABLED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#state ApigeeSecurityAction#state}
    */
    readonly state: string;
    /**
    * The TTL for this SecurityAction.
    * A duration in seconds with up to nine fractional digits, ending with 's'. Example: "3.5s".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#ttl ApigeeSecurityAction#ttl}
    */
    readonly ttl?: string;
    /**
    * allow block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#allow ApigeeSecurityAction#allow}
    */
    readonly allow?: ApigeeSecurityActionAllow;
    /**
    * condition_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#condition_config ApigeeSecurityAction#condition_config}
    */
    readonly conditionConfig: ApigeeSecurityActionConditionConfig;
    /**
    * deny block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#deny ApigeeSecurityAction#deny}
    */
    readonly deny?: ApigeeSecurityActionDeny;
    /**
    * flag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#flag ApigeeSecurityAction#flag}
    */
    readonly flag?: ApigeeSecurityActionFlag;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#timeouts ApigeeSecurityAction#timeouts}
    */
    readonly timeouts?: ApigeeSecurityActionTimeouts;
}
export interface ApigeeSecurityActionAllow {
}
export declare function apigeeSecurityActionAllowToTerraform(struct?: ApigeeSecurityActionAllowOutputReference | ApigeeSecurityActionAllow): any;
export declare function apigeeSecurityActionAllowToHclTerraform(struct?: ApigeeSecurityActionAllowOutputReference | ApigeeSecurityActionAllow): any;
export declare class ApigeeSecurityActionAllowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeSecurityActionAllow | undefined;
    set internalValue(value: ApigeeSecurityActionAllow | undefined);
}
export interface ApigeeSecurityActionConditionConfig {
    /**
    * A list of accessTokens. Limit 1000 per action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#access_tokens ApigeeSecurityAction#access_tokens}
    */
    readonly accessTokens?: string[];
    /**
    * A list of API keys. Limit 1000 per action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#api_keys ApigeeSecurityAction#api_keys}
    */
    readonly apiKeys?: string[];
    /**
    * A list of API Products. Limit 1000 per action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#api_products ApigeeSecurityAction#api_products}
    */
    readonly apiProducts?: string[];
    /**
    * A list of ASN numbers to act on, e.g. 23. https://en.wikipedia.org/wiki/Autonomous_system_(Internet)
    * This uses int64 instead of uint32 because of https://linter.aip.dev/141/forbidden-types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#asns ApigeeSecurityAction#asns}
    */
    readonly asns?: string[];
    /**
    * A list of Bot Reasons. Current options: Flooder, Brute Guessor, Static Content Scraper,
    * OAuth Abuser, Robot Abuser, TorListRule, Advanced Anomaly Detection, Advanced API Scraper,
    * Search Engine Crawlers, Public Clouds, Public Cloud AWS, Public Cloud Azure, and Public Cloud Google.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#bot_reasons ApigeeSecurityAction#bot_reasons}
    */
    readonly botReasons?: string[];
    /**
    * A list of developer apps. Limit 1000 per action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#developer_apps ApigeeSecurityAction#developer_apps}
    */
    readonly developerApps?: string[];
    /**
    * A list of developers. Limit 1000 per action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#developers ApigeeSecurityAction#developers}
    */
    readonly developers?: string[];
    /**
    * Act only on particular HTTP methods. E.g. A read-only API can block POST/PUT/DELETE methods.
    * Accepted values are: GET, HEAD, POST, PUT, DELETE, CONNECT, OPTIONS, TRACE and PATCH.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#http_methods ApigeeSecurityAction#http_methods}
    */
    readonly httpMethods?: string[];
    /**
    * A list of IP addresses. This could be either IPv4 or IPv6. Limited to 100 per action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#ip_address_ranges ApigeeSecurityAction#ip_address_ranges}
    */
    readonly ipAddressRanges?: string[];
    /**
    * A list of countries/region codes to act on, e.g. US. This follows https://en.wikipedia.org/wiki/ISO_3166-1_alpha-2.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#region_codes ApigeeSecurityAction#region_codes}
    */
    readonly regionCodes?: string[];
    /**
    * A list of user agents to deny. We look for exact matches. Limit 50 per action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#user_agents ApigeeSecurityAction#user_agents}
    */
    readonly userAgents?: string[];
}
export declare function apigeeSecurityActionConditionConfigToTerraform(struct?: ApigeeSecurityActionConditionConfigOutputReference | ApigeeSecurityActionConditionConfig): any;
export declare function apigeeSecurityActionConditionConfigToHclTerraform(struct?: ApigeeSecurityActionConditionConfigOutputReference | ApigeeSecurityActionConditionConfig): any;
export declare class ApigeeSecurityActionConditionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeSecurityActionConditionConfig | undefined;
    set internalValue(value: ApigeeSecurityActionConditionConfig | undefined);
    private _accessTokens?;
    get accessTokens(): string[];
    set accessTokens(value: string[]);
    resetAccessTokens(): void;
    get accessTokensInput(): string[] | undefined;
    private _apiKeys?;
    get apiKeys(): string[];
    set apiKeys(value: string[]);
    resetApiKeys(): void;
    get apiKeysInput(): string[] | undefined;
    private _apiProducts?;
    get apiProducts(): string[];
    set apiProducts(value: string[]);
    resetApiProducts(): void;
    get apiProductsInput(): string[] | undefined;
    private _asns?;
    get asns(): string[];
    set asns(value: string[]);
    resetAsns(): void;
    get asnsInput(): string[] | undefined;
    private _botReasons?;
    get botReasons(): string[];
    set botReasons(value: string[]);
    resetBotReasons(): void;
    get botReasonsInput(): string[] | undefined;
    private _developerApps?;
    get developerApps(): string[];
    set developerApps(value: string[]);
    resetDeveloperApps(): void;
    get developerAppsInput(): string[] | undefined;
    private _developers?;
    get developers(): string[];
    set developers(value: string[]);
    resetDevelopers(): void;
    get developersInput(): string[] | undefined;
    private _httpMethods?;
    get httpMethods(): string[];
    set httpMethods(value: string[]);
    resetHttpMethods(): void;
    get httpMethodsInput(): string[] | undefined;
    private _ipAddressRanges?;
    get ipAddressRanges(): string[];
    set ipAddressRanges(value: string[]);
    resetIpAddressRanges(): void;
    get ipAddressRangesInput(): string[] | undefined;
    private _regionCodes?;
    get regionCodes(): string[];
    set regionCodes(value: string[]);
    resetRegionCodes(): void;
    get regionCodesInput(): string[] | undefined;
    private _userAgents?;
    get userAgents(): string[];
    set userAgents(value: string[]);
    resetUserAgents(): void;
    get userAgentsInput(): string[] | undefined;
}
export interface ApigeeSecurityActionDeny {
    /**
    * The HTTP response code if the Action = DENY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#response_code ApigeeSecurityAction#response_code}
    */
    readonly responseCode?: number;
}
export declare function apigeeSecurityActionDenyToTerraform(struct?: ApigeeSecurityActionDenyOutputReference | ApigeeSecurityActionDeny): any;
export declare function apigeeSecurityActionDenyToHclTerraform(struct?: ApigeeSecurityActionDenyOutputReference | ApigeeSecurityActionDeny): any;
export declare class ApigeeSecurityActionDenyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeSecurityActionDeny | undefined;
    set internalValue(value: ApigeeSecurityActionDeny | undefined);
    private _responseCode?;
    get responseCode(): number;
    set responseCode(value: number);
    resetResponseCode(): void;
    get responseCodeInput(): number | undefined;
}
export interface ApigeeSecurityActionFlagHeaders {
    /**
    * The header name to be sent to the target.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#name ApigeeSecurityAction#name}
    */
    readonly name?: string;
    /**
    * The header value to be sent to the target.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#value ApigeeSecurityAction#value}
    */
    readonly value?: string;
}
export declare function apigeeSecurityActionFlagHeadersToTerraform(struct?: ApigeeSecurityActionFlagHeaders | cdktn.IResolvable): any;
export declare function apigeeSecurityActionFlagHeadersToHclTerraform(struct?: ApigeeSecurityActionFlagHeaders | cdktn.IResolvable): any;
export declare class ApigeeSecurityActionFlagHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigeeSecurityActionFlagHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeSecurityActionFlagHeaders | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApigeeSecurityActionFlagHeadersList extends cdktn.ComplexList {
    internalValue?: ApigeeSecurityActionFlagHeaders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigeeSecurityActionFlagHeadersOutputReference;
}
export interface ApigeeSecurityActionFlag {
    /**
    * headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#headers ApigeeSecurityAction#headers}
    */
    readonly headers?: ApigeeSecurityActionFlagHeaders[] | cdktn.IResolvable;
}
export declare function apigeeSecurityActionFlagToTerraform(struct?: ApigeeSecurityActionFlagOutputReference | ApigeeSecurityActionFlag): any;
export declare function apigeeSecurityActionFlagToHclTerraform(struct?: ApigeeSecurityActionFlagOutputReference | ApigeeSecurityActionFlag): any;
export declare class ApigeeSecurityActionFlagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeSecurityActionFlag | undefined;
    set internalValue(value: ApigeeSecurityActionFlag | undefined);
    private _headers;
    get headers(): ApigeeSecurityActionFlagHeadersList;
    putHeaders(value: ApigeeSecurityActionFlagHeaders[] | cdktn.IResolvable): void;
    resetHeaders(): void;
    get headersInput(): cdktn.IResolvable | ApigeeSecurityActionFlagHeaders[] | undefined;
}
export interface ApigeeSecurityActionTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#create ApigeeSecurityAction#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#delete ApigeeSecurityAction#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#update ApigeeSecurityAction#update}
    */
    readonly update?: string;
}
export declare function apigeeSecurityActionTimeoutsToTerraform(struct?: ApigeeSecurityActionTimeouts | cdktn.IResolvable): any;
export declare function apigeeSecurityActionTimeoutsToHclTerraform(struct?: ApigeeSecurityActionTimeouts | cdktn.IResolvable): any;
export declare class ApigeeSecurityActionTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeSecurityActionTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeSecurityActionTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action google_apigee_security_action}
*/
export declare class ApigeeSecurityAction extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apigee_security_action";
    /**
    * Generates CDKTN code for importing a ApigeeSecurityAction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigeeSecurityAction to import
    * @param importFromId The id of the existing ApigeeSecurityAction that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigeeSecurityAction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_action google_apigee_security_action} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigeeSecurityActionConfig
    */
    constructor(scope: Construct, id: string, config: ApigeeSecurityActionConfig);
    private _apiProxies?;
    get apiProxies(): string[];
    set apiProxies(value: string[]);
    resetApiProxies(): void;
    get apiProxiesInput(): string[] | undefined;
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _envId?;
    get envId(): string;
    set envId(value: string);
    get envIdInput(): string | undefined;
    private _expireTime?;
    get expireTime(): string;
    set expireTime(value: string);
    resetExpireTime(): void;
    get expireTimeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _orgId?;
    get orgId(): string;
    set orgId(value: string);
    get orgIdInput(): string | undefined;
    private _securityActionId?;
    get securityActionId(): string;
    set securityActionId(value: string);
    get securityActionIdInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    get stateInput(): string | undefined;
    private _ttl?;
    get ttl(): string;
    set ttl(value: string);
    resetTtl(): void;
    get ttlInput(): string | undefined;
    get updateTime(): string;
    private _allow;
    get allow(): ApigeeSecurityActionAllowOutputReference;
    putAllow(value: ApigeeSecurityActionAllow): void;
    resetAllow(): void;
    get allowInput(): ApigeeSecurityActionAllow | undefined;
    private _conditionConfig;
    get conditionConfig(): ApigeeSecurityActionConditionConfigOutputReference;
    putConditionConfig(value: ApigeeSecurityActionConditionConfig): void;
    get conditionConfigInput(): ApigeeSecurityActionConditionConfig | undefined;
    private _deny;
    get deny(): ApigeeSecurityActionDenyOutputReference;
    putDeny(value: ApigeeSecurityActionDeny): void;
    resetDeny(): void;
    get denyInput(): ApigeeSecurityActionDeny | undefined;
    private _flag;
    get flag(): ApigeeSecurityActionFlagOutputReference;
    putFlag(value: ApigeeSecurityActionFlag): void;
    resetFlag(): void;
    get flagInput(): ApigeeSecurityActionFlag | undefined;
    private _timeouts;
    get timeouts(): ApigeeSecurityActionTimeoutsOutputReference;
    putTimeouts(value: ApigeeSecurityActionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApigeeSecurityActionTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
