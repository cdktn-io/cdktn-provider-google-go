/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeNetworkPeeringConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_peering#deletion_policy ComputeNetworkPeering#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Whether to export the custom routes to the peer network. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_peering#export_custom_routes ComputeNetworkPeering#export_custom_routes}
    */
    readonly exportCustomRoutes?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_peering#export_subnet_routes_with_public_ip ComputeNetworkPeering#export_subnet_routes_with_public_ip}
    */
    readonly exportSubnetRoutesWithPublicIp?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_peering#id ComputeNetworkPeering#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Whether to export the custom routes from the peer network. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_peering#import_custom_routes ComputeNetworkPeering#import_custom_routes}
    */
    readonly importCustomRoutes?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_peering#import_subnet_routes_with_public_ip ComputeNetworkPeering#import_subnet_routes_with_public_ip}
    */
    readonly importSubnetRoutesWithPublicIp?: boolean | cdktn.IResolvable;
    /**
    * Name of the peering.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_peering#name ComputeNetworkPeering#name}
    */
    readonly name: string;
    /**
    * The primary network of the peering.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_peering#network ComputeNetworkPeering#network}
    */
    readonly network: string;
    /**
    * The peer network in the peering. The peer network may belong to a different project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_peering#peer_network ComputeNetworkPeering#peer_network}
    */
    readonly peerNetwork: string;
    /**
    * Which IP version(s) of traffic and routes are allowed to be imported or exported between peer networks. The default value is IPV4_ONLY. Possible values: ["IPV4_ONLY", "IPV4_IPV6"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_peering#stack_type ComputeNetworkPeering#stack_type}
    */
    readonly stackType?: string;
    /**
    * The update strategy determines the semantics for updates and deletes to the peering connection configuration. The default value is INDEPENDENT. Possible values: ["INDEPENDENT", "CONSENSUS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_peering#update_strategy ComputeNetworkPeering#update_strategy}
    */
    readonly updateStrategy?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_peering#timeouts ComputeNetworkPeering#timeouts}
    */
    readonly timeouts?: ComputeNetworkPeeringTimeouts;
}
export interface ComputeNetworkPeeringTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_peering#create ComputeNetworkPeering#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_peering#delete ComputeNetworkPeering#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_peering#update ComputeNetworkPeering#update}
    */
    readonly update?: string;
}
export declare function computeNetworkPeeringTimeoutsToTerraform(struct?: ComputeNetworkPeeringTimeouts | cdktn.IResolvable): any;
export declare function computeNetworkPeeringTimeoutsToHclTerraform(struct?: ComputeNetworkPeeringTimeouts | cdktn.IResolvable): any;
export declare class ComputeNetworkPeeringTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeNetworkPeeringTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeNetworkPeeringTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_peering google_compute_network_peering}
*/
export declare class ComputeNetworkPeering extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_network_peering";
    /**
    * Generates CDKTN code for importing a ComputeNetworkPeering resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeNetworkPeering to import
    * @param importFromId The id of the existing ComputeNetworkPeering that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_peering#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeNetworkPeering to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_network_peering google_compute_network_peering} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeNetworkPeeringConfig
    */
    constructor(scope: Construct, id: string, config: ComputeNetworkPeeringConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _exportCustomRoutes?;
    get exportCustomRoutes(): boolean | cdktn.IResolvable;
    set exportCustomRoutes(value: boolean | cdktn.IResolvable);
    resetExportCustomRoutes(): void;
    get exportCustomRoutesInput(): boolean | cdktn.IResolvable | undefined;
    private _exportSubnetRoutesWithPublicIp?;
    get exportSubnetRoutesWithPublicIp(): boolean | cdktn.IResolvable;
    set exportSubnetRoutesWithPublicIp(value: boolean | cdktn.IResolvable);
    resetExportSubnetRoutesWithPublicIp(): void;
    get exportSubnetRoutesWithPublicIpInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _importCustomRoutes?;
    get importCustomRoutes(): boolean | cdktn.IResolvable;
    set importCustomRoutes(value: boolean | cdktn.IResolvable);
    resetImportCustomRoutes(): void;
    get importCustomRoutesInput(): boolean | cdktn.IResolvable | undefined;
    private _importSubnetRoutesWithPublicIp?;
    get importSubnetRoutesWithPublicIp(): boolean | cdktn.IResolvable;
    set importSubnetRoutesWithPublicIp(value: boolean | cdktn.IResolvable);
    resetImportSubnetRoutesWithPublicIp(): void;
    get importSubnetRoutesWithPublicIpInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _network?;
    get network(): string;
    set network(value: string);
    get networkInput(): string | undefined;
    private _peerNetwork?;
    get peerNetwork(): string;
    set peerNetwork(value: string);
    get peerNetworkInput(): string | undefined;
    private _stackType?;
    get stackType(): string;
    set stackType(value: string);
    resetStackType(): void;
    get stackTypeInput(): string | undefined;
    get state(): string;
    get stateDetails(): string;
    private _updateStrategy?;
    get updateStrategy(): string;
    set updateStrategy(value: string);
    resetUpdateStrategy(): void;
    get updateStrategyInput(): string | undefined;
    private _timeouts;
    get timeouts(): ComputeNetworkPeeringTimeoutsOutputReference;
    putTimeouts(value: ComputeNetworkPeeringTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeNetworkPeeringTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
