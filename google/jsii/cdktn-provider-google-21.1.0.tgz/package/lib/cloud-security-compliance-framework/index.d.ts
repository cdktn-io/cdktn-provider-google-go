/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudSecurityComplianceFrameworkConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#deletion_policy CloudSecurityComplianceFramework#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The description of the framework. The maximum length is 2000 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#description CloudSecurityComplianceFramework#description}
    */
    readonly description?: string;
    /**
    * Display name of the framework. The maximum length is 200 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#display_name CloudSecurityComplianceFramework#display_name}
    */
    readonly displayName?: string;
    /**
    * ID of the framework.
    * This is not the full name of the framework.
    * This is the last part of the full name of the framework.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#framework_id CloudSecurityComplianceFramework#framework_id}
    */
    readonly frameworkId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#id CloudSecurityComplianceFramework#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#location CloudSecurityComplianceFramework#location}
    */
    readonly location: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#organization CloudSecurityComplianceFramework#organization}
    */
    readonly organization?: string;
    /**
    * The parent resource in which to create the resource.
    * Must be in one of the following formats:
    * * 'projects/{{project}}'
    * * 'organizations/{{organization}}'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#parent CloudSecurityComplianceFramework#parent}
    */
    readonly parent?: string;
    /**
    * cloud_control_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#cloud_control_details CloudSecurityComplianceFramework#cloud_control_details}
    */
    readonly cloudControlDetails?: CloudSecurityComplianceFrameworkCloudControlDetails[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#timeouts CloudSecurityComplianceFramework#timeouts}
    */
    readonly timeouts?: CloudSecurityComplianceFrameworkTimeouts;
}
export interface CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValue {
    /**
    * The strings in the list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#values CloudSecurityComplianceFramework#values}
    */
    readonly values: string[];
}
export declare function cloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValueToTerraform(struct?: CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValueOutputReference | CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValue): any;
export declare function cloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValueToHclTerraform(struct?: CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValueOutputReference | CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValue): any;
export declare class CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValue | undefined;
    set internalValue(value: CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValue | undefined);
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export interface CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValue {
    /**
    * Represents a boolean value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#bool_value CloudSecurityComplianceFramework#bool_value}
    */
    readonly boolValue?: boolean | cdktn.IResolvable;
    /**
    * Represents a double value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#number_value CloudSecurityComplianceFramework#number_value}
    */
    readonly numberValue?: number;
    /**
    * Represents a string value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#string_value CloudSecurityComplianceFramework#string_value}
    */
    readonly stringValue?: string;
    /**
    * string_list_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#string_list_value CloudSecurityComplianceFramework#string_list_value}
    */
    readonly stringListValue?: CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValue;
}
export declare function cloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValueToTerraform(struct?: CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValueOutputReference | CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValue): any;
export declare function cloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValueToHclTerraform(struct?: CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValueOutputReference | CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValue): any;
export declare class CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValue | undefined;
    set internalValue(value: CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValue | undefined);
    private _boolValue?;
    get boolValue(): boolean | cdktn.IResolvable;
    set boolValue(value: boolean | cdktn.IResolvable);
    resetBoolValue(): void;
    get boolValueInput(): boolean | cdktn.IResolvable | undefined;
    private _numberValue?;
    get numberValue(): number;
    set numberValue(value: number);
    resetNumberValue(): void;
    get numberValueInput(): number | undefined;
    private _stringValue?;
    get stringValue(): string;
    set stringValue(value: string);
    resetStringValue(): void;
    get stringValueInput(): string | undefined;
    private _stringListValue;
    get stringListValue(): CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValueOutputReference;
    putStringListValue(value: CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValue): void;
    resetStringListValue(): void;
    get stringListValueInput(): CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValueStringListValue | undefined;
}
export interface CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValue {
    /**
    * The name of the parameter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#name CloudSecurityComplianceFramework#name}
    */
    readonly name?: string;
    /**
    * parameter_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#parameter_value CloudSecurityComplianceFramework#parameter_value}
    */
    readonly parameterValue?: CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValue;
}
export declare function cloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueToTerraform(struct?: CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueOutputReference | CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValue): any;
export declare function cloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueToHclTerraform(struct?: CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueOutputReference | CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValue): any;
export declare class CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValue | undefined;
    set internalValue(value: CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValue | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _parameterValue;
    get parameterValue(): CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValueOutputReference;
    putParameterValue(value: CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValue): void;
    resetParameterValue(): void;
    get parameterValueInput(): CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueParameterValue | undefined;
}
export interface CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueStringListValue {
    /**
    * The strings in the list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#values CloudSecurityComplianceFramework#values}
    */
    readonly values: string[];
}
export declare function cloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueStringListValueToTerraform(struct?: CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueStringListValueOutputReference | CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueStringListValue): any;
export declare function cloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueStringListValueToHclTerraform(struct?: CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueStringListValueOutputReference | CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueStringListValue): any;
export declare class CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueStringListValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueStringListValue | undefined;
    set internalValue(value: CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueStringListValue | undefined);
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export interface CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValue {
    /**
    * Represents a boolean value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#bool_value CloudSecurityComplianceFramework#bool_value}
    */
    readonly boolValue?: boolean | cdktn.IResolvable;
    /**
    * Represents a double value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#number_value CloudSecurityComplianceFramework#number_value}
    */
    readonly numberValue?: number;
    /**
    * Represents a string value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#string_value CloudSecurityComplianceFramework#string_value}
    */
    readonly stringValue?: string;
    /**
    * oneof_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#oneof_value CloudSecurityComplianceFramework#oneof_value}
    */
    readonly oneofValue?: CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValue;
    /**
    * string_list_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#string_list_value CloudSecurityComplianceFramework#string_list_value}
    */
    readonly stringListValue?: CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueStringListValue;
}
export declare function cloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueToTerraform(struct?: CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOutputReference | CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValue): any;
export declare function cloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueToHclTerraform(struct?: CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOutputReference | CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValue): any;
export declare class CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValue | undefined;
    set internalValue(value: CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValue | undefined);
    private _boolValue?;
    get boolValue(): boolean | cdktn.IResolvable;
    set boolValue(value: boolean | cdktn.IResolvable);
    resetBoolValue(): void;
    get boolValueInput(): boolean | cdktn.IResolvable | undefined;
    private _numberValue?;
    get numberValue(): number;
    set numberValue(value: number);
    resetNumberValue(): void;
    get numberValueInput(): number | undefined;
    private _stringValue?;
    get stringValue(): string;
    set stringValue(value: string);
    resetStringValue(): void;
    get stringValueInput(): string | undefined;
    private _oneofValue;
    get oneofValue(): CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValueOutputReference;
    putOneofValue(value: CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValue): void;
    resetOneofValue(): void;
    get oneofValueInput(): CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOneofValue | undefined;
    private _stringListValue;
    get stringListValue(): CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueStringListValueOutputReference;
    putStringListValue(value: CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueStringListValue): void;
    resetStringListValue(): void;
    get stringListValueInput(): CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueStringListValue | undefined;
}
export interface CloudSecurityComplianceFrameworkCloudControlDetailsParameters {
    /**
    * The name of the parameter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#name CloudSecurityComplianceFramework#name}
    */
    readonly name: string;
    /**
    * parameter_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#parameter_value CloudSecurityComplianceFramework#parameter_value}
    */
    readonly parameterValue: CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValue;
}
export declare function cloudSecurityComplianceFrameworkCloudControlDetailsParametersToTerraform(struct?: CloudSecurityComplianceFrameworkCloudControlDetailsParameters | cdktn.IResolvable): any;
export declare function cloudSecurityComplianceFrameworkCloudControlDetailsParametersToHclTerraform(struct?: CloudSecurityComplianceFrameworkCloudControlDetailsParameters | cdktn.IResolvable): any;
export declare class CloudSecurityComplianceFrameworkCloudControlDetailsParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudSecurityComplianceFrameworkCloudControlDetailsParameters | cdktn.IResolvable | undefined;
    set internalValue(value: CloudSecurityComplianceFrameworkCloudControlDetailsParameters | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameterValue;
    get parameterValue(): CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValueOutputReference;
    putParameterValue(value: CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValue): void;
    get parameterValueInput(): CloudSecurityComplianceFrameworkCloudControlDetailsParametersParameterValue | undefined;
}
export declare class CloudSecurityComplianceFrameworkCloudControlDetailsParametersList extends cdktn.ComplexList {
    internalValue?: CloudSecurityComplianceFrameworkCloudControlDetailsParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudSecurityComplianceFrameworkCloudControlDetailsParametersOutputReference;
}
export interface CloudSecurityComplianceFrameworkCloudControlDetails {
    /**
    * Major revision of cloudcontrol
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#major_revision_id CloudSecurityComplianceFramework#major_revision_id}
    */
    readonly majorRevisionId: string;
    /**
    * The name of the CloudControl in the format:
    * "{parent}/locations/{location}/cloudControls/{cloud-control}"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#name CloudSecurityComplianceFramework#name}
    */
    readonly name: string;
    /**
    * parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#parameters CloudSecurityComplianceFramework#parameters}
    */
    readonly parameters?: CloudSecurityComplianceFrameworkCloudControlDetailsParameters[] | cdktn.IResolvable;
}
export declare function cloudSecurityComplianceFrameworkCloudControlDetailsToTerraform(struct?: CloudSecurityComplianceFrameworkCloudControlDetails | cdktn.IResolvable): any;
export declare function cloudSecurityComplianceFrameworkCloudControlDetailsToHclTerraform(struct?: CloudSecurityComplianceFrameworkCloudControlDetails | cdktn.IResolvable): any;
export declare class CloudSecurityComplianceFrameworkCloudControlDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudSecurityComplianceFrameworkCloudControlDetails | cdktn.IResolvable | undefined;
    set internalValue(value: CloudSecurityComplianceFrameworkCloudControlDetails | cdktn.IResolvable | undefined);
    private _majorRevisionId?;
    get majorRevisionId(): string;
    set majorRevisionId(value: string);
    get majorRevisionIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters;
    get parameters(): CloudSecurityComplianceFrameworkCloudControlDetailsParametersList;
    putParameters(value: CloudSecurityComplianceFrameworkCloudControlDetailsParameters[] | cdktn.IResolvable): void;
    resetParameters(): void;
    get parametersInput(): cdktn.IResolvable | CloudSecurityComplianceFrameworkCloudControlDetailsParameters[] | undefined;
}
export declare class CloudSecurityComplianceFrameworkCloudControlDetailsList extends cdktn.ComplexList {
    internalValue?: CloudSecurityComplianceFrameworkCloudControlDetails[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudSecurityComplianceFrameworkCloudControlDetailsOutputReference;
}
export interface CloudSecurityComplianceFrameworkTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#create CloudSecurityComplianceFramework#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#delete CloudSecurityComplianceFramework#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#update CloudSecurityComplianceFramework#update}
    */
    readonly update?: string;
}
export declare function cloudSecurityComplianceFrameworkTimeoutsToTerraform(struct?: CloudSecurityComplianceFrameworkTimeouts | cdktn.IResolvable): any;
export declare function cloudSecurityComplianceFrameworkTimeoutsToHclTerraform(struct?: CloudSecurityComplianceFrameworkTimeouts | cdktn.IResolvable): any;
export declare class CloudSecurityComplianceFrameworkTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudSecurityComplianceFrameworkTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CloudSecurityComplianceFrameworkTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework google_cloud_security_compliance_framework}
*/
export declare class CloudSecurityComplianceFramework extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_cloud_security_compliance_framework";
    /**
    * Generates CDKTN code for importing a CloudSecurityComplianceFramework resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudSecurityComplianceFramework to import
    * @param importFromId The id of the existing CloudSecurityComplianceFramework that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudSecurityComplianceFramework to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_security_compliance_framework google_cloud_security_compliance_framework} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudSecurityComplianceFrameworkConfig
    */
    constructor(scope: Construct, id: string, config: CloudSecurityComplianceFrameworkConfig);
    get category(): string[];
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _frameworkId?;
    get frameworkId(): string;
    set frameworkId(value: string);
    get frameworkIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get majorRevisionId(): string;
    get name(): string;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    resetParent(): void;
    get parentInput(): string | undefined;
    get supportedCloudProviders(): string[];
    get supportedEnforcementModes(): string[];
    get supportedTargetResourceTypes(): string[];
    get type(): string;
    private _cloudControlDetails;
    get cloudControlDetails(): CloudSecurityComplianceFrameworkCloudControlDetailsList;
    putCloudControlDetails(value: CloudSecurityComplianceFrameworkCloudControlDetails[] | cdktn.IResolvable): void;
    resetCloudControlDetails(): void;
    get cloudControlDetailsInput(): cdktn.IResolvable | CloudSecurityComplianceFrameworkCloudControlDetails[] | undefined;
    private _timeouts;
    get timeouts(): CloudSecurityComplianceFrameworkTimeoutsOutputReference;
    putTimeouts(value: CloudSecurityComplianceFrameworkTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CloudSecurityComplianceFrameworkTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
