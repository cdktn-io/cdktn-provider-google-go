/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ActiveDirectoryDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of delegated administrator account used to perform Active Directory operations.
    * If not specified, setupadmin will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/active_directory_domain#admin ActiveDirectoryDomain#admin}
    */
    readonly admin?: string;
    /**
    * The full names of the Google Compute Engine networks the domain instance is connected to. The domain is only available on networks listed in authorizedNetworks.
    * If CIDR subnets overlap between networks, domain creation will fail.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/active_directory_domain#authorized_networks ActiveDirectoryDomain#authorized_networks}
    */
    readonly authorizedNetworks?: string[];
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/active_directory_domain#deletion_policy ActiveDirectoryDomain#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Whether Terraform will be prevented from destroying the domain. Defaults to true.
    * When a'terraform destroy' or 'terraform apply' would delete the domain,
    * the command will fail if this field is not set to false in Terraform state.
    * When the field is set to true or unset in Terraform state, a 'terraform apply'
    * or 'terraform destroy' that would delete the domain will fail.
    * When the field is set to false, deleting the domain is allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/active_directory_domain#deletion_protection ActiveDirectoryDomain#deletion_protection}
    */
    readonly deletionProtection?: boolean | cdktn.IResolvable;
    /**
    * The fully qualified domain name. e.g. mydomain.myorganization.com, with the restrictions
    * of https://cloud.google.com/managed-microsoft-ad/reference/rest/v1/projects.locations.global.domains.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/active_directory_domain#domain_name ActiveDirectoryDomain#domain_name}
    */
    readonly domainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/active_directory_domain#id ActiveDirectoryDomain#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource labels that can contain user-provided metadata
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/active_directory_domain#labels ActiveDirectoryDomain#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Locations where domain needs to be provisioned. [regions][compute/docs/regions-zones/]
    * e.g. us-west1 or us-east4 Service supports up to 4 locations at once. Each location will use a /26 block.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/active_directory_domain#locations ActiveDirectoryDomain#locations}
    */
    readonly locations: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/active_directory_domain#project ActiveDirectoryDomain#project}
    */
    readonly project?: string;
    /**
    * The CIDR range of internal addresses that are reserved for this domain. Reserved networks must be /24 or larger.
    * Ranges must be unique and non-overlapping with existing subnets in authorizedNetworks
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/active_directory_domain#reserved_ip_range ActiveDirectoryDomain#reserved_ip_range}
    */
    readonly reservedIpRange: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/active_directory_domain#timeouts ActiveDirectoryDomain#timeouts}
    */
    readonly timeouts?: ActiveDirectoryDomainTimeouts;
}
export interface ActiveDirectoryDomainTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/active_directory_domain#create ActiveDirectoryDomain#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/active_directory_domain#delete ActiveDirectoryDomain#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/active_directory_domain#update ActiveDirectoryDomain#update}
    */
    readonly update?: string;
}
export declare function activeDirectoryDomainTimeoutsToTerraform(struct?: ActiveDirectoryDomainTimeouts | cdktn.IResolvable): any;
export declare function activeDirectoryDomainTimeoutsToHclTerraform(struct?: ActiveDirectoryDomainTimeouts | cdktn.IResolvable): any;
export declare class ActiveDirectoryDomainTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ActiveDirectoryDomainTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ActiveDirectoryDomainTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/active_directory_domain google_active_directory_domain}
*/
export declare class ActiveDirectoryDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_active_directory_domain";
    /**
    * Generates CDKTN code for importing a ActiveDirectoryDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ActiveDirectoryDomain to import
    * @param importFromId The id of the existing ActiveDirectoryDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/active_directory_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ActiveDirectoryDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/active_directory_domain google_active_directory_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ActiveDirectoryDomainConfig
    */
    constructor(scope: Construct, id: string, config: ActiveDirectoryDomainConfig);
    private _admin?;
    get admin(): string;
    set admin(value: string);
    resetAdmin(): void;
    get adminInput(): string | undefined;
    private _authorizedNetworks?;
    get authorizedNetworks(): string[];
    set authorizedNetworks(value: string[]);
    resetAuthorizedNetworks(): void;
    get authorizedNetworksInput(): string[] | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _deletionProtection?;
    get deletionProtection(): boolean | cdktn.IResolvable;
    set deletionProtection(value: boolean | cdktn.IResolvable);
    resetDeletionProtection(): void;
    get deletionProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get fqdn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _locations?;
    get locations(): string[];
    set locations(value: string[]);
    get locationsInput(): string[] | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _reservedIpRange?;
    get reservedIpRange(): string;
    set reservedIpRange(value: string);
    get reservedIpRangeInput(): string | undefined;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _timeouts;
    get timeouts(): ActiveDirectoryDomainTimeoutsOutputReference;
    putTimeouts(value: ActiveDirectoryDomainTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ActiveDirectoryDomainTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
