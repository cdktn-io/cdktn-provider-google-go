/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigeeControlPlaneAccessConfig extends cdktn.TerraformMetaArguments {
    /**
    * Array of service accounts authorized to publish analytics data to the control plane, each specified using the following format: 'serviceAccount:service-account-name'.
    *
    * The 'service-account-name' is formatted like an email address. For example: serviceAccount@my_project_id.iam.gserviceaccount.com
    *
    * You might specify multiple service accounts, for example, if you have multiple environments and wish to assign a unique service account to each one.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_control_plane_access#analytics_publisher_identities ApigeeControlPlaneAccess#analytics_publisher_identities}
    */
    readonly analyticsPublisherIdentities?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_control_plane_access#id ApigeeControlPlaneAccess#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the Apigee organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_control_plane_access#name ApigeeControlPlaneAccess#name}
    */
    readonly name: string;
    /**
    * Array of service accounts to grant access to control plane resources (for the Synchronizer component), each specified using the following format: 'serviceAccount:service-account-name'.
    *
    * The 'service-account-name' is formatted like an email address. For example: serviceAccount@my_project_id.iam.gserviceaccount.com
    *
    * You might specify multiple service accounts, for example, if you have multiple environments and wish to assign a unique service account to each one.
    *
    * The service accounts must have **Apigee Synchronizer Manager** role. See also [Create service accounts](https://cloud.google.com/apigee/docs/hybrid/v1.8/sa-about#create-the-service-accounts).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_control_plane_access#synchronizer_identities ApigeeControlPlaneAccess#synchronizer_identities}
    */
    readonly synchronizerIdentities?: string[];
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_control_plane_access#timeouts ApigeeControlPlaneAccess#timeouts}
    */
    readonly timeouts?: ApigeeControlPlaneAccessTimeouts;
}
export interface ApigeeControlPlaneAccessTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_control_plane_access#create ApigeeControlPlaneAccess#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_control_plane_access#delete ApigeeControlPlaneAccess#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_control_plane_access#update ApigeeControlPlaneAccess#update}
    */
    readonly update?: string;
}
export declare function apigeeControlPlaneAccessTimeoutsToTerraform(struct?: ApigeeControlPlaneAccessTimeouts | cdktn.IResolvable): any;
export declare function apigeeControlPlaneAccessTimeoutsToHclTerraform(struct?: ApigeeControlPlaneAccessTimeouts | cdktn.IResolvable): any;
export declare class ApigeeControlPlaneAccessTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeControlPlaneAccessTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeControlPlaneAccessTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_control_plane_access google_apigee_control_plane_access}
*/
export declare class ApigeeControlPlaneAccess extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apigee_control_plane_access";
    /**
    * Generates CDKTN code for importing a ApigeeControlPlaneAccess resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigeeControlPlaneAccess to import
    * @param importFromId The id of the existing ApigeeControlPlaneAccess that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_control_plane_access#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigeeControlPlaneAccess to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_control_plane_access google_apigee_control_plane_access} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigeeControlPlaneAccessConfig
    */
    constructor(scope: Construct, id: string, config: ApigeeControlPlaneAccessConfig);
    private _analyticsPublisherIdentities?;
    get analyticsPublisherIdentities(): string[];
    set analyticsPublisherIdentities(value: string[]);
    resetAnalyticsPublisherIdentities(): void;
    get analyticsPublisherIdentitiesInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _synchronizerIdentities?;
    get synchronizerIdentities(): string[];
    set synchronizerIdentities(value: string[]);
    resetSynchronizerIdentities(): void;
    get synchronizerIdentitiesInput(): string[] | undefined;
    private _timeouts;
    get timeouts(): ApigeeControlPlaneAccessTimeoutsOutputReference;
    putTimeouts(value: ApigeeControlPlaneAccessTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApigeeControlPlaneAccessTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
