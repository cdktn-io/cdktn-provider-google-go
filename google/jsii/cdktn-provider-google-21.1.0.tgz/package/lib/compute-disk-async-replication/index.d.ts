/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeDiskAsyncReplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_disk_async_replication#deletion_policy ComputeDiskAsyncReplication#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_disk_async_replication#id ComputeDiskAsyncReplication#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Primary disk for asynchronous replication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_disk_async_replication#primary_disk ComputeDiskAsyncReplication#primary_disk}
    */
    readonly primaryDisk: string;
    /**
    * secondary_disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_disk_async_replication#secondary_disk ComputeDiskAsyncReplication#secondary_disk}
    */
    readonly secondaryDisk: ComputeDiskAsyncReplicationSecondaryDisk;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_disk_async_replication#timeouts ComputeDiskAsyncReplication#timeouts}
    */
    readonly timeouts?: ComputeDiskAsyncReplicationTimeouts;
}
export interface ComputeDiskAsyncReplicationSecondaryDisk {
    /**
    * Secondary disk for asynchronous replication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_disk_async_replication#disk ComputeDiskAsyncReplication#disk}
    */
    readonly disk: string;
}
export declare function computeDiskAsyncReplicationSecondaryDiskToTerraform(struct?: ComputeDiskAsyncReplicationSecondaryDiskOutputReference | ComputeDiskAsyncReplicationSecondaryDisk): any;
export declare function computeDiskAsyncReplicationSecondaryDiskToHclTerraform(struct?: ComputeDiskAsyncReplicationSecondaryDiskOutputReference | ComputeDiskAsyncReplicationSecondaryDisk): any;
export declare class ComputeDiskAsyncReplicationSecondaryDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeDiskAsyncReplicationSecondaryDisk | undefined;
    set internalValue(value: ComputeDiskAsyncReplicationSecondaryDisk | undefined);
    private _disk?;
    get disk(): string;
    set disk(value: string);
    get diskInput(): string | undefined;
    get state(): string;
}
export interface ComputeDiskAsyncReplicationTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_disk_async_replication#create ComputeDiskAsyncReplication#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_disk_async_replication#delete ComputeDiskAsyncReplication#delete}
    */
    readonly delete?: string;
}
export declare function computeDiskAsyncReplicationTimeoutsToTerraform(struct?: ComputeDiskAsyncReplicationTimeouts | cdktn.IResolvable): any;
export declare function computeDiskAsyncReplicationTimeoutsToHclTerraform(struct?: ComputeDiskAsyncReplicationTimeouts | cdktn.IResolvable): any;
export declare class ComputeDiskAsyncReplicationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeDiskAsyncReplicationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeDiskAsyncReplicationTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_disk_async_replication google_compute_disk_async_replication}
*/
export declare class ComputeDiskAsyncReplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_disk_async_replication";
    /**
    * Generates CDKTN code for importing a ComputeDiskAsyncReplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeDiskAsyncReplication to import
    * @param importFromId The id of the existing ComputeDiskAsyncReplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_disk_async_replication#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeDiskAsyncReplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_disk_async_replication google_compute_disk_async_replication} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeDiskAsyncReplicationConfig
    */
    constructor(scope: Construct, id: string, config: ComputeDiskAsyncReplicationConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _primaryDisk?;
    get primaryDisk(): string;
    set primaryDisk(value: string);
    get primaryDiskInput(): string | undefined;
    private _secondaryDisk;
    get secondaryDisk(): ComputeDiskAsyncReplicationSecondaryDiskOutputReference;
    putSecondaryDisk(value: ComputeDiskAsyncReplicationSecondaryDisk): void;
    get secondaryDiskInput(): ComputeDiskAsyncReplicationSecondaryDisk | undefined;
    private _timeouts;
    get timeouts(): ComputeDiskAsyncReplicationTimeoutsOutputReference;
    putTimeouts(value: ComputeDiskAsyncReplicationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeDiskAsyncReplicationTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
