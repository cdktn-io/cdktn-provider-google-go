/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BigtableAppProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * The unique name of the app profile in the form '[_a-zA-Z0-9][-_.a-zA-Z0-9]*'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigtable_app_profile#app_profile_id BigtableAppProfile#app_profile_id}
    */
    readonly appProfileId: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigtable_app_profile#deletion_policy BigtableAppProfile#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Long form description of the use case for this app profile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigtable_app_profile#description BigtableAppProfile#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigtable_app_profile#id BigtableAppProfile#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * If true, ignore safety checks when deleting/updating the app profile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigtable_app_profile#ignore_warnings BigtableAppProfile#ignore_warnings}
    */
    readonly ignoreWarnings?: boolean | cdktn.IResolvable;
    /**
    * The name of the instance to create the app profile within.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigtable_app_profile#instance BigtableAppProfile#instance}
    */
    readonly instance?: string;
    /**
    * The set of clusters to route to. The order is ignored; clusters will be tried in order of distance. If left empty, all clusters are eligible.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigtable_app_profile#multi_cluster_routing_cluster_ids BigtableAppProfile#multi_cluster_routing_cluster_ids}
    */
    readonly multiClusterRoutingClusterIds?: string[];
    /**
    * If true, read/write requests are routed to the nearest cluster in the instance, and will fail over to the nearest cluster that is available
    * in the event of transient errors or delays. Clusters in a region are considered equidistant. Choosing this option sacrifices read-your-writes
    * consistency to improve availability.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigtable_app_profile#multi_cluster_routing_use_any BigtableAppProfile#multi_cluster_routing_use_any}
    */
    readonly multiClusterRoutingUseAny?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigtable_app_profile#project BigtableAppProfile#project}
    */
    readonly project?: string;
    /**
    * Must be used with multi-cluster routing. If true, then this app profile will use row affinity sticky routing. With row affinity, Bigtable will route single row key requests based on the row key, rather than randomly. Instead, each row key will be assigned to a cluster by Cloud Bigtable, and will stick to that cluster. Choosing this option improves read-your-writes consistency for most requests under most circumstances, without sacrificing availability. Consistency is not guaranteed, as requests may still fail over between clusters in the event of errors or latency.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigtable_app_profile#row_affinity BigtableAppProfile#row_affinity}
    */
    readonly rowAffinity?: boolean | cdktn.IResolvable;
    /**
    * data_boost_isolation_read_only block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigtable_app_profile#data_boost_isolation_read_only BigtableAppProfile#data_boost_isolation_read_only}
    */
    readonly dataBoostIsolationReadOnly?: BigtableAppProfileDataBoostIsolationReadOnly;
    /**
    * single_cluster_routing block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigtable_app_profile#single_cluster_routing BigtableAppProfile#single_cluster_routing}
    */
    readonly singleClusterRouting?: BigtableAppProfileSingleClusterRouting;
    /**
    * standard_isolation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigtable_app_profile#standard_isolation BigtableAppProfile#standard_isolation}
    */
    readonly standardIsolation?: BigtableAppProfileStandardIsolation;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigtable_app_profile#timeouts BigtableAppProfile#timeouts}
    */
    readonly timeouts?: BigtableAppProfileTimeouts;
}
export interface BigtableAppProfileDataBoostIsolationReadOnly {
    /**
    * The Compute Billing Owner for this Data Boost App Profile. Possible values: ["HOST_PAYS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigtable_app_profile#compute_billing_owner BigtableAppProfile#compute_billing_owner}
    */
    readonly computeBillingOwner: string;
}
export declare function bigtableAppProfileDataBoostIsolationReadOnlyToTerraform(struct?: BigtableAppProfileDataBoostIsolationReadOnlyOutputReference | BigtableAppProfileDataBoostIsolationReadOnly): any;
export declare function bigtableAppProfileDataBoostIsolationReadOnlyToHclTerraform(struct?: BigtableAppProfileDataBoostIsolationReadOnlyOutputReference | BigtableAppProfileDataBoostIsolationReadOnly): any;
export declare class BigtableAppProfileDataBoostIsolationReadOnlyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigtableAppProfileDataBoostIsolationReadOnly | undefined;
    set internalValue(value: BigtableAppProfileDataBoostIsolationReadOnly | undefined);
    private _computeBillingOwner?;
    get computeBillingOwner(): string;
    set computeBillingOwner(value: string);
    get computeBillingOwnerInput(): string | undefined;
}
export interface BigtableAppProfileSingleClusterRouting {
    /**
    * If true, CheckAndMutateRow and ReadModifyWriteRow requests are allowed by this app profile.
    * It is unsafe to send these requests to the same table/row/column in multiple clusters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigtable_app_profile#allow_transactional_writes BigtableAppProfile#allow_transactional_writes}
    */
    readonly allowTransactionalWrites?: boolean | cdktn.IResolvable;
    /**
    * The cluster to which read/write requests should be routed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigtable_app_profile#cluster_id BigtableAppProfile#cluster_id}
    */
    readonly clusterId: string;
}
export declare function bigtableAppProfileSingleClusterRoutingToTerraform(struct?: BigtableAppProfileSingleClusterRoutingOutputReference | BigtableAppProfileSingleClusterRouting): any;
export declare function bigtableAppProfileSingleClusterRoutingToHclTerraform(struct?: BigtableAppProfileSingleClusterRoutingOutputReference | BigtableAppProfileSingleClusterRouting): any;
export declare class BigtableAppProfileSingleClusterRoutingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigtableAppProfileSingleClusterRouting | undefined;
    set internalValue(value: BigtableAppProfileSingleClusterRouting | undefined);
    private _allowTransactionalWrites?;
    get allowTransactionalWrites(): boolean | cdktn.IResolvable;
    set allowTransactionalWrites(value: boolean | cdktn.IResolvable);
    resetAllowTransactionalWrites(): void;
    get allowTransactionalWritesInput(): boolean | cdktn.IResolvable | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
}
export interface BigtableAppProfileStandardIsolation {
    /**
    * The priority of requests sent using this app profile. Possible values: ["PRIORITY_LOW", "PRIORITY_MEDIUM", "PRIORITY_HIGH"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigtable_app_profile#priority BigtableAppProfile#priority}
    */
    readonly priority: string;
}
export declare function bigtableAppProfileStandardIsolationToTerraform(struct?: BigtableAppProfileStandardIsolationOutputReference | BigtableAppProfileStandardIsolation): any;
export declare function bigtableAppProfileStandardIsolationToHclTerraform(struct?: BigtableAppProfileStandardIsolationOutputReference | BigtableAppProfileStandardIsolation): any;
export declare class BigtableAppProfileStandardIsolationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigtableAppProfileStandardIsolation | undefined;
    set internalValue(value: BigtableAppProfileStandardIsolation | undefined);
    private _priority?;
    get priority(): string;
    set priority(value: string);
    get priorityInput(): string | undefined;
}
export interface BigtableAppProfileTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigtable_app_profile#create BigtableAppProfile#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigtable_app_profile#delete BigtableAppProfile#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigtable_app_profile#update BigtableAppProfile#update}
    */
    readonly update?: string;
}
export declare function bigtableAppProfileTimeoutsToTerraform(struct?: BigtableAppProfileTimeouts | cdktn.IResolvable): any;
export declare function bigtableAppProfileTimeoutsToHclTerraform(struct?: BigtableAppProfileTimeouts | cdktn.IResolvable): any;
export declare class BigtableAppProfileTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigtableAppProfileTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BigtableAppProfileTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigtable_app_profile google_bigtable_app_profile}
*/
export declare class BigtableAppProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_bigtable_app_profile";
    /**
    * Generates CDKTN code for importing a BigtableAppProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BigtableAppProfile to import
    * @param importFromId The id of the existing BigtableAppProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigtable_app_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BigtableAppProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigtable_app_profile google_bigtable_app_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BigtableAppProfileConfig
    */
    constructor(scope: Construct, id: string, config: BigtableAppProfileConfig);
    private _appProfileId?;
    get appProfileId(): string;
    set appProfileId(value: string);
    get appProfileIdInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ignoreWarnings?;
    get ignoreWarnings(): boolean | cdktn.IResolvable;
    set ignoreWarnings(value: boolean | cdktn.IResolvable);
    resetIgnoreWarnings(): void;
    get ignoreWarningsInput(): boolean | cdktn.IResolvable | undefined;
    private _instance?;
    get instance(): string;
    set instance(value: string);
    resetInstance(): void;
    get instanceInput(): string | undefined;
    private _multiClusterRoutingClusterIds?;
    get multiClusterRoutingClusterIds(): string[];
    set multiClusterRoutingClusterIds(value: string[]);
    resetMultiClusterRoutingClusterIds(): void;
    get multiClusterRoutingClusterIdsInput(): string[] | undefined;
    private _multiClusterRoutingUseAny?;
    get multiClusterRoutingUseAny(): boolean | cdktn.IResolvable;
    set multiClusterRoutingUseAny(value: boolean | cdktn.IResolvable);
    resetMultiClusterRoutingUseAny(): void;
    get multiClusterRoutingUseAnyInput(): boolean | cdktn.IResolvable | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _rowAffinity?;
    get rowAffinity(): boolean | cdktn.IResolvable;
    set rowAffinity(value: boolean | cdktn.IResolvable);
    resetRowAffinity(): void;
    get rowAffinityInput(): boolean | cdktn.IResolvable | undefined;
    private _dataBoostIsolationReadOnly;
    get dataBoostIsolationReadOnly(): BigtableAppProfileDataBoostIsolationReadOnlyOutputReference;
    putDataBoostIsolationReadOnly(value: BigtableAppProfileDataBoostIsolationReadOnly): void;
    resetDataBoostIsolationReadOnly(): void;
    get dataBoostIsolationReadOnlyInput(): BigtableAppProfileDataBoostIsolationReadOnly | undefined;
    private _singleClusterRouting;
    get singleClusterRouting(): BigtableAppProfileSingleClusterRoutingOutputReference;
    putSingleClusterRouting(value: BigtableAppProfileSingleClusterRouting): void;
    resetSingleClusterRouting(): void;
    get singleClusterRoutingInput(): BigtableAppProfileSingleClusterRouting | undefined;
    private _standardIsolation;
    get standardIsolation(): BigtableAppProfileStandardIsolationOutputReference;
    putStandardIsolation(value: BigtableAppProfileStandardIsolation): void;
    resetStandardIsolation(): void;
    get standardIsolationInput(): BigtableAppProfileStandardIsolation | undefined;
    private _timeouts;
    get timeouts(): BigtableAppProfileTimeoutsOutputReference;
    putTimeouts(value: BigtableAppProfileTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BigtableAppProfileTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
