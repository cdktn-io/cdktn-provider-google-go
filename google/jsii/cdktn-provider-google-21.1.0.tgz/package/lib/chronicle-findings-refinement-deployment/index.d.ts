/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChronicleFindingsRefinementDeploymentConfig extends cdktn.TerraformMetaArguments {
    /**
    * The archive state of the findings refinement deployment.
    * Cannot be set to true unless enabled is set to false.
    * If currently set to true, enabled cannot be updated to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_findings_refinement_deployment#archived ChronicleFindingsRefinementDeployment#archived}
    */
    readonly archived?: boolean | cdktn.IResolvable;
    /**
    * Whether the findings refinement is currently deployed continuously against
    * incoming findings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_findings_refinement_deployment#enabled ChronicleFindingsRefinementDeployment#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_findings_refinement_deployment#findings_refinement ChronicleFindingsRefinementDeployment#findings_refinement}
    */
    readonly findingsRefinement: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_findings_refinement_deployment#id ChronicleFindingsRefinementDeployment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_findings_refinement_deployment#instance ChronicleFindingsRefinementDeployment#instance}
    */
    readonly instance: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_findings_refinement_deployment#location ChronicleFindingsRefinementDeployment#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_findings_refinement_deployment#project ChronicleFindingsRefinementDeployment#project}
    */
    readonly project?: string;
    /**
    * detection_exclusion_application block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_findings_refinement_deployment#detection_exclusion_application ChronicleFindingsRefinementDeployment#detection_exclusion_application}
    */
    readonly detectionExclusionApplication?: ChronicleFindingsRefinementDeploymentDetectionExclusionApplication;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_findings_refinement_deployment#timeouts ChronicleFindingsRefinementDeployment#timeouts}
    */
    readonly timeouts?: ChronicleFindingsRefinementDeploymentTimeouts;
}
export interface ChronicleFindingsRefinementDeploymentDetectionExclusionApplication {
    /**
    * The CuratedRuleSets this detection exclusion applies to.
    * Format:
    * projects/{project}/locations/{location}/instances/{instance}/curatedRuleSetCategories/{category}/curatedRuleSets/{rule_set}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_findings_refinement_deployment#curated_rule_sets ChronicleFindingsRefinementDeployment#curated_rule_sets}
    */
    readonly curatedRuleSets?: string[];
    /**
    * The CuratedRules this detection exclusion applies to.
    * Format:
    * projects/{project}/locations/{location}/instances/{instance}/curatedRules/{rule}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_findings_refinement_deployment#curated_rules ChronicleFindingsRefinementDeployment#curated_rules}
    */
    readonly curatedRules?: string[];
    /**
    * The Rules this detection exclusion applies to.
    * Format:
    * projects/{project}/locations/{location}/instances/{instance}/rules/{rule}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_findings_refinement_deployment#rules ChronicleFindingsRefinementDeployment#rules}
    */
    readonly rules?: string[];
}
export declare function chronicleFindingsRefinementDeploymentDetectionExclusionApplicationToTerraform(struct?: ChronicleFindingsRefinementDeploymentDetectionExclusionApplicationOutputReference | ChronicleFindingsRefinementDeploymentDetectionExclusionApplication): any;
export declare function chronicleFindingsRefinementDeploymentDetectionExclusionApplicationToHclTerraform(struct?: ChronicleFindingsRefinementDeploymentDetectionExclusionApplicationOutputReference | ChronicleFindingsRefinementDeploymentDetectionExclusionApplication): any;
export declare class ChronicleFindingsRefinementDeploymentDetectionExclusionApplicationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleFindingsRefinementDeploymentDetectionExclusionApplication | undefined;
    set internalValue(value: ChronicleFindingsRefinementDeploymentDetectionExclusionApplication | undefined);
    private _curatedRuleSets?;
    get curatedRuleSets(): string[];
    set curatedRuleSets(value: string[]);
    resetCuratedRuleSets(): void;
    get curatedRuleSetsInput(): string[] | undefined;
    private _curatedRules?;
    get curatedRules(): string[];
    set curatedRules(value: string[]);
    resetCuratedRules(): void;
    get curatedRulesInput(): string[] | undefined;
    get deletedCuratedRuleSets(): string[];
    private _rules?;
    get rules(): string[];
    set rules(value: string[]);
    resetRules(): void;
    get rulesInput(): string[] | undefined;
}
export interface ChronicleFindingsRefinementDeploymentTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_findings_refinement_deployment#create ChronicleFindingsRefinementDeployment#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_findings_refinement_deployment#delete ChronicleFindingsRefinementDeployment#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_findings_refinement_deployment#update ChronicleFindingsRefinementDeployment#update}
    */
    readonly update?: string;
}
export declare function chronicleFindingsRefinementDeploymentTimeoutsToTerraform(struct?: ChronicleFindingsRefinementDeploymentTimeouts | cdktn.IResolvable): any;
export declare function chronicleFindingsRefinementDeploymentTimeoutsToHclTerraform(struct?: ChronicleFindingsRefinementDeploymentTimeouts | cdktn.IResolvable): any;
export declare class ChronicleFindingsRefinementDeploymentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleFindingsRefinementDeploymentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleFindingsRefinementDeploymentTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_findings_refinement_deployment google_chronicle_findings_refinement_deployment}
*/
export declare class ChronicleFindingsRefinementDeployment extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_chronicle_findings_refinement_deployment";
    /**
    * Generates CDKTN code for importing a ChronicleFindingsRefinementDeployment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChronicleFindingsRefinementDeployment to import
    * @param importFromId The id of the existing ChronicleFindingsRefinementDeployment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_findings_refinement_deployment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChronicleFindingsRefinementDeployment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_findings_refinement_deployment google_chronicle_findings_refinement_deployment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChronicleFindingsRefinementDeploymentConfig
    */
    constructor(scope: Construct, id: string, config: ChronicleFindingsRefinementDeploymentConfig);
    private _archived?;
    get archived(): boolean | cdktn.IResolvable;
    set archived(value: boolean | cdktn.IResolvable);
    resetArchived(): void;
    get archivedInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _findingsRefinement?;
    get findingsRefinement(): string;
    set findingsRefinement(value: string);
    get findingsRefinementInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instance?;
    get instance(): string;
    set instance(value: string);
    get instanceInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get updateTime(): string;
    private _detectionExclusionApplication;
    get detectionExclusionApplication(): ChronicleFindingsRefinementDeploymentDetectionExclusionApplicationOutputReference;
    putDetectionExclusionApplication(value: ChronicleFindingsRefinementDeploymentDetectionExclusionApplication): void;
    resetDetectionExclusionApplication(): void;
    get detectionExclusionApplicationInput(): ChronicleFindingsRefinementDeploymentDetectionExclusionApplication | undefined;
    private _timeouts;
    get timeouts(): ChronicleFindingsRefinementDeploymentTimeoutsOutputReference;
    putTimeouts(value: ChronicleFindingsRefinementDeploymentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ChronicleFindingsRefinementDeploymentTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
