/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BiglakeHiveCatalogConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_hive_catalog#deletion_policy BiglakeHiveCatalog#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Description of the Hive catalog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_hive_catalog#description BiglakeHiveCatalog#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_hive_catalog#id BiglakeHiveCatalog#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Cloud Storage location path where the catalog data will be stored. Format: gs://bucket/path/to/catalog
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_hive_catalog#location_uri BiglakeHiveCatalog#location_uri}
    */
    readonly locationUri: string;
    /**
    * Name of the Hive Catalog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_hive_catalog#name BiglakeHiveCatalog#name}
    */
    readonly name: string;
    /**
    * The primary location for mirroring the remote catalog metadata. It must be
    * a BigLake-supported location, and it should be proximate to the remote
    * catalog's location.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_hive_catalog#primary_location BiglakeHiveCatalog#primary_location}
    */
    readonly primaryLocation: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_hive_catalog#project BiglakeHiveCatalog#project}
    */
    readonly project?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_hive_catalog#timeouts BiglakeHiveCatalog#timeouts}
    */
    readonly timeouts?: BiglakeHiveCatalogTimeouts;
}
export interface BiglakeHiveCatalogReplicas {
}
export declare function biglakeHiveCatalogReplicasToTerraform(struct?: BiglakeHiveCatalogReplicas): any;
export declare function biglakeHiveCatalogReplicasToHclTerraform(struct?: BiglakeHiveCatalogReplicas): any;
export declare class BiglakeHiveCatalogReplicasOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BiglakeHiveCatalogReplicas | undefined;
    set internalValue(value: BiglakeHiveCatalogReplicas | undefined);
    get region(): string;
    get state(): string;
}
export declare class BiglakeHiveCatalogReplicasList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BiglakeHiveCatalogReplicasOutputReference;
}
export interface BiglakeHiveCatalogTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_hive_catalog#create BiglakeHiveCatalog#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_hive_catalog#delete BiglakeHiveCatalog#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_hive_catalog#update BiglakeHiveCatalog#update}
    */
    readonly update?: string;
}
export declare function biglakeHiveCatalogTimeoutsToTerraform(struct?: BiglakeHiveCatalogTimeouts | cdktn.IResolvable): any;
export declare function biglakeHiveCatalogTimeoutsToHclTerraform(struct?: BiglakeHiveCatalogTimeouts | cdktn.IResolvable): any;
export declare class BiglakeHiveCatalogTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BiglakeHiveCatalogTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BiglakeHiveCatalogTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_hive_catalog google_biglake_hive_catalog}
*/
export declare class BiglakeHiveCatalog extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_biglake_hive_catalog";
    /**
    * Generates CDKTN code for importing a BiglakeHiveCatalog resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BiglakeHiveCatalog to import
    * @param importFromId The id of the existing BiglakeHiveCatalog that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_hive_catalog#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BiglakeHiveCatalog to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/biglake_hive_catalog google_biglake_hive_catalog} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BiglakeHiveCatalogConfig
    */
    constructor(scope: Construct, id: string, config: BiglakeHiveCatalogConfig);
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _locationUri?;
    get locationUri(): string;
    set locationUri(value: string);
    get locationUriInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _primaryLocation?;
    get primaryLocation(): string;
    set primaryLocation(value: string);
    get primaryLocationInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _replicas;
    get replicas(): BiglakeHiveCatalogReplicasList;
    get updateTime(): string;
    private _timeouts;
    get timeouts(): BiglakeHiveCatalogTimeoutsOutputReference;
    putTimeouts(value: BiglakeHiveCatalogTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BiglakeHiveCatalogTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
