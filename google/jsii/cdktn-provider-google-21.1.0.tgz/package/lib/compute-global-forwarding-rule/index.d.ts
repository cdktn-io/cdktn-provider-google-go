/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeGlobalForwardingRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#deletion_policy ComputeGlobalForwardingRule#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource. Provide this property when
    * you create the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#description ComputeGlobalForwardingRule#description}
    */
    readonly description?: string;
    /**
    * Specifies the canary migration state for the backend buckets attached to this forwarding rule.
    * Possible values are PREPARE, TEST_BY_PERCENTAGE, and TEST_ALL_TRAFFIC.
    *
    * To begin the migration from EXTERNAL to EXTERNAL_MANAGED, the state must be changed to
    * PREPARE. The state must be changed to TEST_ALL_TRAFFIC before the loadBalancingScheme can be
    * changed to EXTERNAL_MANAGED. Optionally, the TEST_BY_PERCENTAGE state can be used to migrate
    * traffic to backend buckets attached to this forwarding rule by percentage using
    * externalManagedBackendBucketMigrationTestingPercentage.
    *
    * Rolling back a migration requires the states to be set in reverse order. So changing the
    * scheme from EXTERNAL_MANAGED to EXTERNAL requires the state to be set to TEST_ALL_TRAFFIC at
    * the same time. Optionally, the TEST_BY_PERCENTAGE state can be used to migrate some traffic
    * back to EXTERNAL or PREPARE can be used to migrate all traffic back to EXTERNAL. Possible values: ["PREPARE", "TEST_BY_PERCENTAGE", "TEST_ALL_TRAFFIC"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#external_managed_backend_bucket_migration_state ComputeGlobalForwardingRule#external_managed_backend_bucket_migration_state}
    */
    readonly externalManagedBackendBucketMigrationState?: string;
    /**
    * Determines the fraction of requests to backend buckets that should be processed by the Global
    * external Application Load Balancer.
    *
    * The value of this field must be in the range [0, 100].
    *
    * This value can only be set if the loadBalancingScheme in the forwarding rule is set to
    * EXTERNAL (when using the Classic ALB) and the migration state is TEST_BY_PERCENTAGE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#external_managed_backend_bucket_migration_testing_percentage ComputeGlobalForwardingRule#external_managed_backend_bucket_migration_testing_percentage}
    */
    readonly externalManagedBackendBucketMigrationTestingPercentage?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#id ComputeGlobalForwardingRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * IP address for which this forwarding rule accepts traffic. When a client
    * sends traffic to this IP address, the forwarding rule directs the traffic
    * to the referenced 'target'.
    *
    * While creating a forwarding rule, specifying an 'IPAddress' is
    * required under the following circumstances:
    *
    * * When the 'target' is set to 'targetGrpcProxy' and
    * 'validateForProxyless' is set to 'true', the
    * 'IPAddress' should be set to '0.0.0.0'.
    * * When the 'target' is a Private Service Connect Google APIs
    * bundle, you must specify an 'IPAddress'.
    *
    * Otherwise, you can optionally specify an IP address that references an
    * existing static (reserved) IP address resource. When omitted, Google Cloud
    * assigns an ephemeral IP address.
    *
    * Use one of the following formats to specify an IP address while creating a
    * forwarding rule:
    *
    * * IP address number, as in '100.1.2.3'
    * * IPv6 address range, as in '2600:1234::/96'
    * * Full resource URL, as in
    * 'https://www.googleapis.com/compute/v1/projects/project_id/regions/region/addresses/address-name'
    * * Partial URL or by name, as in:
    *   * 'projects/project_id/regions/region/addresses/address-name'
    *   * 'regions/region/addresses/address-name'
    *   * 'global/addresses/address-name'
    *   * 'address-name'
    *
    * The forwarding rule's 'target',
    * and in most cases, also the 'loadBalancingScheme', determine the
    * type of IP address that you can use. For detailed information, see
    * [IP address
    * specifications](https://cloud.google.com/load-balancing/docs/forwarding-rule-concepts#ip_address_specifications).
    *
    * When reading an 'IPAddress', the API always returns the IP
    * address number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#ip_address ComputeGlobalForwardingRule#ip_address}
    */
    readonly ipAddress?: string;
    /**
    * The IP protocol to which this rule applies.
    *
    * For protocol forwarding, valid
    * options are 'TCP', 'UDP', 'ESP',
    * 'AH', 'SCTP', 'ICMP' and
    * 'L3_DEFAULT'.
    *
    * The valid IP protocols are different for different load balancing products
    * as described in [Load balancing
    * features](https://cloud.google.com/load-balancing/docs/features#protocols_from_the_load_balancer_to_the_backends). Possible values: ["TCP", "UDP", "ESP", "AH", "SCTP", "ICMP"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#ip_protocol ComputeGlobalForwardingRule#ip_protocol}
    */
    readonly ipProtocol?: string;
    /**
    * The IP Version that will be used by this global forwarding rule. Possible values: ["IPV4", "IPV6"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#ip_version ComputeGlobalForwardingRule#ip_version}
    */
    readonly ipVersion?: string;
    /**
    * Labels to apply to this forwarding rule.  A list of key->value pairs.
    *
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#labels ComputeGlobalForwardingRule#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Specifies the forwarding rule type.
    *
    * For more information about forwarding rules, refer to
    * [Forwarding rule concepts](https://cloud.google.com/load-balancing/docs/forwarding-rule-concepts). Default value: "EXTERNAL_MANAGED" Possible values: ["EXTERNAL", "EXTERNAL_MANAGED", "INTERNAL_MANAGED", "INTERNAL_SELF_MANAGED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#load_balancing_scheme ComputeGlobalForwardingRule#load_balancing_scheme}
    */
    readonly loadBalancingScheme?: string;
    /**
    * Name of the resource; provided by the client when the resource is created.
    * The name must be 1-63 characters long, and comply with
    * [RFC1035](https://www.ietf.org/rfc/rfc1035.txt).
    *
    * Specifically, the name must be 1-63 characters long and match the regular
    * expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the first
    * character must be a lowercase letter, and all following characters must
    * be a dash, lowercase letter, or digit, except the last character, which
    * cannot be a dash.
    *
    * For Private Service Connect forwarding rules that forward traffic to Google
    * APIs, the forwarding rule name must be a 1-20 characters string with
    * lowercase letters and numbers and must start with a letter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#name ComputeGlobalForwardingRule#name}
    */
    readonly name: string;
    /**
    * This field is not used for external load balancing.
    *
    * For Internal TCP/UDP Load Balancing, this field identifies the network that
    * the load balanced IP should belong to for this Forwarding Rule.
    * If the subnetwork is specified, the network of the subnetwork will be used.
    * If neither subnetwork nor this field is specified, the default network will
    * be used.
    *
    * For Private Service Connect forwarding rules that forward traffic to Google
    * APIs, a network must be provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#network ComputeGlobalForwardingRule#network}
    */
    readonly network?: string;
    /**
    * This signifies the networking tier used for configuring
    * this load balancer and can only take the following values:
    * 'PREMIUM', 'STANDARD'.
    *
    * For regional ForwardingRule, the valid values are 'PREMIUM' and
    * 'STANDARD'. For GlobalForwardingRule, the valid value is
    * 'PREMIUM'.
    *
    * If this field is not specified, it is assumed to be 'PREMIUM'.
    * If 'IPAddress' is specified, this value must be equal to the
    * networkTier of the Address. Possible values: ["PREMIUM", "STANDARD"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#network_tier ComputeGlobalForwardingRule#network_tier}
    */
    readonly networkTier?: string;
    /**
    * This is used in PSC consumer ForwardingRule to control whether it should try to auto-generate a DNS zone or not. Non-PSC forwarding rules do not use this field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#no_automate_dns_zone ComputeGlobalForwardingRule#no_automate_dns_zone}
    */
    readonly noAutomateDnsZone?: boolean | cdktn.IResolvable;
    /**
    * The 'portRange' field has the following limitations:
    * * It requires that the forwarding rule 'IPProtocol' be TCP, UDP, or SCTP,
    * and
    * * It's applicable only to the following products: external passthrough
    * Network Load Balancers, internal and external proxy Network Load
    * Balancers, internal and external Application Load Balancers, external
    * protocol forwarding, and Classic VPN.
    * * Some products have restrictions on what ports can be used. See
    * [port specifications](https://cloud.google.com/load-balancing/docs/forwarding-rule-concepts#port_specifications)
    * for details.
    *
    * For external forwarding rules, two or more forwarding rules cannot use the
    * same '[IPAddress, IPProtocol]' pair, and cannot have overlapping
    * 'portRange's.
    *
    * For internal forwarding rules within the same VPC network, two or more
    * forwarding rules cannot use the same '[IPAddress, IPProtocol]' pair, and
    * cannot have overlapping 'portRange's.
    *
    * @pattern: \d+(?:-\d+)?
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#port_range ComputeGlobalForwardingRule#port_range}
    */
    readonly portRange?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#project ComputeGlobalForwardingRule#project}
    */
    readonly project?: string;
    /**
    * If not empty, this Forwarding Rule will only forward the traffic when the source IP address matches one of the IP addresses or CIDR ranges set here. Note that a Forwarding Rule can only have up to 64 source IP ranges, and this field can only be used with a regional Forwarding Rule whose scheme is EXTERNAL. Each sourceIpRange entry should be either an IP address (for example, 1.2.3.4) or a CIDR range (for example, 1.2.3.0/24).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#source_ip_ranges ComputeGlobalForwardingRule#source_ip_ranges}
    */
    readonly sourceIpRanges?: string[];
    /**
    * This field identifies the subnetwork that the load balanced IP should
    * belong to for this Forwarding Rule, used in internal load balancing and
    * network load balancing with IPv6.
    *
    * If the network specified is in auto subnet mode, this field is optional.
    * However, a subnetwork must be specified if the network is in custom subnet
    * mode or when creating external forwarding rule with IPv6.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#subnetwork ComputeGlobalForwardingRule#subnetwork}
    */
    readonly subnetwork?: string;
    /**
    * The URL of the target resource to receive the matched traffic.  For
    * regional forwarding rules, this target must be in the same region as the
    * forwarding rule. For global forwarding rules, this target must be a global
    * load balancing resource.
    *
    * The forwarded traffic must be of a type appropriate to the target object.
    * *  For load balancers, see the "Target" column in [Port specifications](https://cloud.google.com/load-balancing/docs/forwarding-rule-concepts#ip_address_specifications).
    * *  For Private Service Connect forwarding rules that forward traffic to Google APIs, provide the name of a supported Google API bundle:
    *   *  'vpc-sc' - [ APIs that support VPC Service Controls](https://cloud.google.com/vpc-service-controls/docs/supported-products).
    *   *  'all-apis' - [All supported Google APIs](https://cloud.google.com/vpc/docs/private-service-connect#supported-apis).
    *
    * For Private Service Connect forwarding rules that forward traffic to managed services, the target must be a service attachment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#target ComputeGlobalForwardingRule#target}
    */
    readonly target: string;
    /**
    * metadata_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#metadata_filters ComputeGlobalForwardingRule#metadata_filters}
    */
    readonly metadataFilters?: ComputeGlobalForwardingRuleMetadataFilters[] | cdktn.IResolvable;
    /**
    * service_directory_registrations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#service_directory_registrations ComputeGlobalForwardingRule#service_directory_registrations}
    */
    readonly serviceDirectoryRegistrations?: ComputeGlobalForwardingRuleServiceDirectoryRegistrations;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#timeouts ComputeGlobalForwardingRule#timeouts}
    */
    readonly timeouts?: ComputeGlobalForwardingRuleTimeouts;
}
export interface ComputeGlobalForwardingRuleMetadataFiltersFilterLabels {
    /**
    * Name of the metadata label. The length must be between
    * 1 and 1024 characters, inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#name ComputeGlobalForwardingRule#name}
    */
    readonly name: string;
    /**
    * The value that the label must match. The value has a maximum
    * length of 1024 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#value ComputeGlobalForwardingRule#value}
    */
    readonly value: string;
}
export declare function computeGlobalForwardingRuleMetadataFiltersFilterLabelsToTerraform(struct?: ComputeGlobalForwardingRuleMetadataFiltersFilterLabels | cdktn.IResolvable): any;
export declare function computeGlobalForwardingRuleMetadataFiltersFilterLabelsToHclTerraform(struct?: ComputeGlobalForwardingRuleMetadataFiltersFilterLabels | cdktn.IResolvable): any;
export declare class ComputeGlobalForwardingRuleMetadataFiltersFilterLabelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeGlobalForwardingRuleMetadataFiltersFilterLabels | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeGlobalForwardingRuleMetadataFiltersFilterLabels | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ComputeGlobalForwardingRuleMetadataFiltersFilterLabelsList extends cdktn.ComplexList {
    internalValue?: ComputeGlobalForwardingRuleMetadataFiltersFilterLabels[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeGlobalForwardingRuleMetadataFiltersFilterLabelsOutputReference;
}
export interface ComputeGlobalForwardingRuleMetadataFilters {
    /**
    * Specifies how individual filterLabel matches within the list of
    * filterLabels contribute towards the overall metadataFilter match.
    *
    * MATCH_ANY - At least one of the filterLabels must have a matching
    * label in the provided metadata.
    * MATCH_ALL - All filterLabels must have matching labels in the
    * provided metadata. Possible values: ["MATCH_ANY", "MATCH_ALL"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#filter_match_criteria ComputeGlobalForwardingRule#filter_match_criteria}
    */
    readonly filterMatchCriteria: string;
    /**
    * filter_labels block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#filter_labels ComputeGlobalForwardingRule#filter_labels}
    */
    readonly filterLabels: ComputeGlobalForwardingRuleMetadataFiltersFilterLabels[] | cdktn.IResolvable;
}
export declare function computeGlobalForwardingRuleMetadataFiltersToTerraform(struct?: ComputeGlobalForwardingRuleMetadataFilters | cdktn.IResolvable): any;
export declare function computeGlobalForwardingRuleMetadataFiltersToHclTerraform(struct?: ComputeGlobalForwardingRuleMetadataFilters | cdktn.IResolvable): any;
export declare class ComputeGlobalForwardingRuleMetadataFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeGlobalForwardingRuleMetadataFilters | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeGlobalForwardingRuleMetadataFilters | cdktn.IResolvable | undefined);
    private _filterMatchCriteria?;
    get filterMatchCriteria(): string;
    set filterMatchCriteria(value: string);
    get filterMatchCriteriaInput(): string | undefined;
    private _filterLabels;
    get filterLabels(): ComputeGlobalForwardingRuleMetadataFiltersFilterLabelsList;
    putFilterLabels(value: ComputeGlobalForwardingRuleMetadataFiltersFilterLabels[] | cdktn.IResolvable): void;
    get filterLabelsInput(): cdktn.IResolvable | ComputeGlobalForwardingRuleMetadataFiltersFilterLabels[] | undefined;
}
export declare class ComputeGlobalForwardingRuleMetadataFiltersList extends cdktn.ComplexList {
    internalValue?: ComputeGlobalForwardingRuleMetadataFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeGlobalForwardingRuleMetadataFiltersOutputReference;
}
export interface ComputeGlobalForwardingRuleServiceDirectoryRegistrations {
    /**
    * Service Directory namespace to register the forwarding rule under.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#namespace ComputeGlobalForwardingRule#namespace}
    */
    readonly namespace?: string;
    /**
    * [Optional] Service Directory region to register this global forwarding rule under.
    * Default to "us-central1". Only used for PSC for Google APIs. All PSC for
    * Google APIs Forwarding Rules on the same network should use the same Service
    * Directory region.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#service_directory_region ComputeGlobalForwardingRule#service_directory_region}
    */
    readonly serviceDirectoryRegion?: string;
}
export declare function computeGlobalForwardingRuleServiceDirectoryRegistrationsToTerraform(struct?: ComputeGlobalForwardingRuleServiceDirectoryRegistrationsOutputReference | ComputeGlobalForwardingRuleServiceDirectoryRegistrations): any;
export declare function computeGlobalForwardingRuleServiceDirectoryRegistrationsToHclTerraform(struct?: ComputeGlobalForwardingRuleServiceDirectoryRegistrationsOutputReference | ComputeGlobalForwardingRuleServiceDirectoryRegistrations): any;
export declare class ComputeGlobalForwardingRuleServiceDirectoryRegistrationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeGlobalForwardingRuleServiceDirectoryRegistrations | undefined;
    set internalValue(value: ComputeGlobalForwardingRuleServiceDirectoryRegistrations | undefined);
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _serviceDirectoryRegion?;
    get serviceDirectoryRegion(): string;
    set serviceDirectoryRegion(value: string);
    resetServiceDirectoryRegion(): void;
    get serviceDirectoryRegionInput(): string | undefined;
}
export interface ComputeGlobalForwardingRuleTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#create ComputeGlobalForwardingRule#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#delete ComputeGlobalForwardingRule#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#update ComputeGlobalForwardingRule#update}
    */
    readonly update?: string;
}
export declare function computeGlobalForwardingRuleTimeoutsToTerraform(struct?: ComputeGlobalForwardingRuleTimeouts | cdktn.IResolvable): any;
export declare function computeGlobalForwardingRuleTimeoutsToHclTerraform(struct?: ComputeGlobalForwardingRuleTimeouts | cdktn.IResolvable): any;
export declare class ComputeGlobalForwardingRuleTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeGlobalForwardingRuleTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeGlobalForwardingRuleTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule google_compute_global_forwarding_rule}
*/
export declare class ComputeGlobalForwardingRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_global_forwarding_rule";
    /**
    * Generates CDKTN code for importing a ComputeGlobalForwardingRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeGlobalForwardingRule to import
    * @param importFromId The id of the existing ComputeGlobalForwardingRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeGlobalForwardingRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_global_forwarding_rule google_compute_global_forwarding_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeGlobalForwardingRuleConfig
    */
    constructor(scope: Construct, id: string, config: ComputeGlobalForwardingRuleConfig);
    get baseForwardingRule(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _externalManagedBackendBucketMigrationState?;
    get externalManagedBackendBucketMigrationState(): string;
    set externalManagedBackendBucketMigrationState(value: string);
    resetExternalManagedBackendBucketMigrationState(): void;
    get externalManagedBackendBucketMigrationStateInput(): string | undefined;
    private _externalManagedBackendBucketMigrationTestingPercentage?;
    get externalManagedBackendBucketMigrationTestingPercentage(): number;
    set externalManagedBackendBucketMigrationTestingPercentage(value: number);
    resetExternalManagedBackendBucketMigrationTestingPercentage(): void;
    get externalManagedBackendBucketMigrationTestingPercentageInput(): number | undefined;
    get forwardingRuleId(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipAddress?;
    get ipAddress(): string;
    set ipAddress(value: string);
    resetIpAddress(): void;
    get ipAddressInput(): string | undefined;
    private _ipProtocol?;
    get ipProtocol(): string;
    set ipProtocol(value: string);
    resetIpProtocol(): void;
    get ipProtocolInput(): string | undefined;
    private _ipVersion?;
    get ipVersion(): string;
    set ipVersion(value: string);
    resetIpVersion(): void;
    get ipVersionInput(): string | undefined;
    get labelFingerprint(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _loadBalancingScheme?;
    get loadBalancingScheme(): string;
    set loadBalancingScheme(value: string);
    resetLoadBalancingScheme(): void;
    get loadBalancingSchemeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _network?;
    get network(): string;
    set network(value: string);
    resetNetwork(): void;
    get networkInput(): string | undefined;
    private _networkTier?;
    get networkTier(): string;
    set networkTier(value: string);
    resetNetworkTier(): void;
    get networkTierInput(): string | undefined;
    private _noAutomateDnsZone?;
    get noAutomateDnsZone(): boolean | cdktn.IResolvable;
    set noAutomateDnsZone(value: boolean | cdktn.IResolvable);
    resetNoAutomateDnsZone(): void;
    get noAutomateDnsZoneInput(): boolean | cdktn.IResolvable | undefined;
    private _portRange?;
    get portRange(): string;
    set portRange(value: string);
    resetPortRange(): void;
    get portRangeInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get pscConnectionId(): string;
    get pscConnectionStatus(): string;
    get selfLink(): string;
    private _sourceIpRanges?;
    get sourceIpRanges(): string[];
    set sourceIpRanges(value: string[]);
    resetSourceIpRanges(): void;
    get sourceIpRangesInput(): string[] | undefined;
    private _subnetwork?;
    get subnetwork(): string;
    set subnetwork(value: string);
    resetSubnetwork(): void;
    get subnetworkInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _metadataFilters;
    get metadataFilters(): ComputeGlobalForwardingRuleMetadataFiltersList;
    putMetadataFilters(value: ComputeGlobalForwardingRuleMetadataFilters[] | cdktn.IResolvable): void;
    resetMetadataFilters(): void;
    get metadataFiltersInput(): cdktn.IResolvable | ComputeGlobalForwardingRuleMetadataFilters[] | undefined;
    private _serviceDirectoryRegistrations;
    get serviceDirectoryRegistrations(): ComputeGlobalForwardingRuleServiceDirectoryRegistrationsOutputReference;
    putServiceDirectoryRegistrations(value: ComputeGlobalForwardingRuleServiceDirectoryRegistrations): void;
    resetServiceDirectoryRegistrations(): void;
    get serviceDirectoryRegistrationsInput(): ComputeGlobalForwardingRuleServiceDirectoryRegistrations | undefined;
    private _timeouts;
    get timeouts(): ComputeGlobalForwardingRuleTimeoutsOutputReference;
    putTimeouts(value: ComputeGlobalForwardingRuleTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeGlobalForwardingRuleTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
