/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeZoneVmExtensionPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_zone_vm_extension_policy#deletion_policy ComputeZoneVmExtensionPolicy#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_zone_vm_extension_policy#description ComputeZoneVmExtensionPolicy#description}
    */
    readonly description?: string;
    /**
    * Name of the resource. Provided by the client when the resource is created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_zone_vm_extension_policy#name ComputeZoneVmExtensionPolicy#name}
    */
    readonly name: string;
    /**
    * Priority of this policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_zone_vm_extension_policy#priority ComputeZoneVmExtensionPolicy#priority}
    */
    readonly priority?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_zone_vm_extension_policy#project ComputeZoneVmExtensionPolicy#project}
    */
    readonly project?: string;
    /**
    * Name of the zone for this request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_zone_vm_extension_policy#zone ComputeZoneVmExtensionPolicy#zone}
    */
    readonly zone: string;
    /**
    * extension_policies block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_zone_vm_extension_policy#extension_policies ComputeZoneVmExtensionPolicy#extension_policies}
    */
    readonly extensionPolicies: ComputeZoneVmExtensionPolicyExtensionPolicies[] | cdktn.IResolvable;
    /**
    * instance_selectors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_zone_vm_extension_policy#instance_selectors ComputeZoneVmExtensionPolicy#instance_selectors}
    */
    readonly instanceSelectors?: ComputeZoneVmExtensionPolicyInstanceSelectors[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_zone_vm_extension_policy#timeouts ComputeZoneVmExtensionPolicy#timeouts}
    */
    readonly timeouts?: ComputeZoneVmExtensionPolicyTimeouts;
}
export interface ComputeZoneVmExtensionPolicyExtensionPolicies {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_zone_vm_extension_policy#extension_name ComputeZoneVmExtensionPolicy#extension_name}
    */
    readonly extensionName: string;
    /**
    * The specific version of the extension to install.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_zone_vm_extension_policy#pinned_version ComputeZoneVmExtensionPolicy#pinned_version}
    */
    readonly pinnedVersion?: string;
    /**
    * String-based configuration data for the extension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_zone_vm_extension_policy#string_config ComputeZoneVmExtensionPolicy#string_config}
    */
    readonly stringConfig?: string;
}
export declare function computeZoneVmExtensionPolicyExtensionPoliciesToTerraform(struct?: ComputeZoneVmExtensionPolicyExtensionPolicies | cdktn.IResolvable): any;
export declare function computeZoneVmExtensionPolicyExtensionPoliciesToHclTerraform(struct?: ComputeZoneVmExtensionPolicyExtensionPolicies | cdktn.IResolvable): any;
export declare class ComputeZoneVmExtensionPolicyExtensionPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeZoneVmExtensionPolicyExtensionPolicies | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeZoneVmExtensionPolicyExtensionPolicies | cdktn.IResolvable | undefined);
    private _extensionName?;
    get extensionName(): string;
    set extensionName(value: string);
    get extensionNameInput(): string | undefined;
    private _pinnedVersion?;
    get pinnedVersion(): string;
    set pinnedVersion(value: string);
    resetPinnedVersion(): void;
    get pinnedVersionInput(): string | undefined;
    private _stringConfig?;
    get stringConfig(): string;
    set stringConfig(value: string);
    resetStringConfig(): void;
    get stringConfigInput(): string | undefined;
}
export declare class ComputeZoneVmExtensionPolicyExtensionPoliciesList extends cdktn.ComplexList {
    internalValue?: ComputeZoneVmExtensionPolicyExtensionPolicies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeZoneVmExtensionPolicyExtensionPoliciesOutputReference;
}
export interface ComputeZoneVmExtensionPolicyInstanceSelectorsLabelSelector {
    /**
    * A map of key-value pairs representing VM labels.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_zone_vm_extension_policy#inclusion_labels ComputeZoneVmExtensionPolicy#inclusion_labels}
    */
    readonly inclusionLabels?: {
        [key: string]: string;
    };
}
export declare function computeZoneVmExtensionPolicyInstanceSelectorsLabelSelectorToTerraform(struct?: ComputeZoneVmExtensionPolicyInstanceSelectorsLabelSelectorOutputReference | ComputeZoneVmExtensionPolicyInstanceSelectorsLabelSelector): any;
export declare function computeZoneVmExtensionPolicyInstanceSelectorsLabelSelectorToHclTerraform(struct?: ComputeZoneVmExtensionPolicyInstanceSelectorsLabelSelectorOutputReference | ComputeZoneVmExtensionPolicyInstanceSelectorsLabelSelector): any;
export declare class ComputeZoneVmExtensionPolicyInstanceSelectorsLabelSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeZoneVmExtensionPolicyInstanceSelectorsLabelSelector | undefined;
    set internalValue(value: ComputeZoneVmExtensionPolicyInstanceSelectorsLabelSelector | undefined);
    private _inclusionLabels?;
    get inclusionLabels(): {
        [key: string]: string;
    };
    set inclusionLabels(value: {
        [key: string]: string;
    });
    resetInclusionLabels(): void;
    get inclusionLabelsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ComputeZoneVmExtensionPolicyInstanceSelectors {
    /**
    * label_selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_zone_vm_extension_policy#label_selector ComputeZoneVmExtensionPolicy#label_selector}
    */
    readonly labelSelector?: ComputeZoneVmExtensionPolicyInstanceSelectorsLabelSelector;
}
export declare function computeZoneVmExtensionPolicyInstanceSelectorsToTerraform(struct?: ComputeZoneVmExtensionPolicyInstanceSelectors | cdktn.IResolvable): any;
export declare function computeZoneVmExtensionPolicyInstanceSelectorsToHclTerraform(struct?: ComputeZoneVmExtensionPolicyInstanceSelectors | cdktn.IResolvable): any;
export declare class ComputeZoneVmExtensionPolicyInstanceSelectorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeZoneVmExtensionPolicyInstanceSelectors | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeZoneVmExtensionPolicyInstanceSelectors | cdktn.IResolvable | undefined);
    private _labelSelector;
    get labelSelector(): ComputeZoneVmExtensionPolicyInstanceSelectorsLabelSelectorOutputReference;
    putLabelSelector(value: ComputeZoneVmExtensionPolicyInstanceSelectorsLabelSelector): void;
    resetLabelSelector(): void;
    get labelSelectorInput(): ComputeZoneVmExtensionPolicyInstanceSelectorsLabelSelector | undefined;
}
export declare class ComputeZoneVmExtensionPolicyInstanceSelectorsList extends cdktn.ComplexList {
    internalValue?: ComputeZoneVmExtensionPolicyInstanceSelectors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeZoneVmExtensionPolicyInstanceSelectorsOutputReference;
}
export interface ComputeZoneVmExtensionPolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_zone_vm_extension_policy#create ComputeZoneVmExtensionPolicy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_zone_vm_extension_policy#delete ComputeZoneVmExtensionPolicy#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_zone_vm_extension_policy#update ComputeZoneVmExtensionPolicy#update}
    */
    readonly update?: string;
}
export declare function computeZoneVmExtensionPolicyTimeoutsToTerraform(struct?: ComputeZoneVmExtensionPolicyTimeouts | cdktn.IResolvable): any;
export declare function computeZoneVmExtensionPolicyTimeoutsToHclTerraform(struct?: ComputeZoneVmExtensionPolicyTimeouts | cdktn.IResolvable): any;
export declare class ComputeZoneVmExtensionPolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeZoneVmExtensionPolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeZoneVmExtensionPolicyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_zone_vm_extension_policy google_compute_zone_vm_extension_policy}
*/
export declare class ComputeZoneVmExtensionPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_zone_vm_extension_policy";
    /**
    * Generates CDKTN code for importing a ComputeZoneVmExtensionPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeZoneVmExtensionPolicy to import
    * @param importFromId The id of the existing ComputeZoneVmExtensionPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_zone_vm_extension_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeZoneVmExtensionPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_zone_vm_extension_policy google_compute_zone_vm_extension_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeZoneVmExtensionPolicyConfig
    */
    constructor(scope: Construct, id: string, config: ComputeZoneVmExtensionPolicyConfig);
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get kind(): string;
    get managedByGlobal(): cdktn.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get state(): string;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    get zoneInput(): string | undefined;
    private _extensionPolicies;
    get extensionPolicies(): ComputeZoneVmExtensionPolicyExtensionPoliciesList;
    putExtensionPolicies(value: ComputeZoneVmExtensionPolicyExtensionPolicies[] | cdktn.IResolvable): void;
    get extensionPoliciesInput(): cdktn.IResolvable | ComputeZoneVmExtensionPolicyExtensionPolicies[] | undefined;
    private _instanceSelectors;
    get instanceSelectors(): ComputeZoneVmExtensionPolicyInstanceSelectorsList;
    putInstanceSelectors(value: ComputeZoneVmExtensionPolicyInstanceSelectors[] | cdktn.IResolvable): void;
    resetInstanceSelectors(): void;
    get instanceSelectorsInput(): cdktn.IResolvable | ComputeZoneVmExtensionPolicyInstanceSelectors[] | undefined;
    private _timeouts;
    get timeouts(): ComputeZoneVmExtensionPolicyTimeoutsOutputReference;
    putTimeouts(value: ComputeZoneVmExtensionPolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeZoneVmExtensionPolicyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
