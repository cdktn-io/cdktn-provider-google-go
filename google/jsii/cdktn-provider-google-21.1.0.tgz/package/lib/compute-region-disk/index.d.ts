/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeRegionDiskConfig extends cdktn.TerraformMetaArguments {
    /**
    * The access mode of the disk.
    * For example:
    *   * READ_WRITE_SINGLE: The default AccessMode, means the disk can be attached to single instance in RW mode.
    *   * READ_WRITE_MANY: The AccessMode means the disk can be attached to multiple instances in RW mode.
    *   * READ_ONLY_SINGLE: The AccessMode means the disk can be attached to multiple instances in RO mode.
    * The AccessMode is only valid for Hyperdisk disk types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#access_mode ComputeRegionDisk#access_mode}
    */
    readonly accessMode?: string;
    /**
    * If set to true, a snapshot of the disk will be created before it is destroyed.
    * If your disk is encrypted with customer managed encryption keys these will be reused for the snapshot creation.
    * The name of the snapshot by default will be '{{disk-name}}-YYYYMMDD-HHmm'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#create_snapshot_before_destroy ComputeRegionDisk#create_snapshot_before_destroy}
    */
    readonly createSnapshotBeforeDestroy?: boolean | cdktn.IResolvable;
    /**
    * This will set a custom name prefix for the snapshot that's created when the disk is deleted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#create_snapshot_before_destroy_prefix ComputeRegionDisk#create_snapshot_before_destroy_prefix}
    */
    readonly createSnapshotBeforeDestroyPrefix?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#deletion_policy ComputeRegionDisk#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource. Provide this property when
    * you create the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#description ComputeRegionDisk#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#id ComputeRegionDisk#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The image from which to initialize this disk. This can be
    * one of: the image's 'self_link', 'projects/{project}/global/images/{image}',
    * 'projects/{project}/global/images/family/{family}', 'global/images/{image}',
    * 'global/images/family/{family}', 'family/{family}', '{project}/{family}',
    * '{project}/{image}', '{family}', or '{image}'. If referred by family, the
    * images names must include the family name. If they don't, use the
    * [google_compute_image data source](/docs/providers/google/d/compute_image.html).
    * For instance, the image 'centos-6-v20180104' includes its family name 'centos-6'.
    * These images can be referred by family name here.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#image ComputeRegionDisk#image}
    */
    readonly image?: string;
    /**
    * Labels to apply to this disk.  A list of key->value pairs.
    *
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#labels ComputeRegionDisk#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Any applicable license URI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#licenses ComputeRegionDisk#licenses}
    */
    readonly licenses?: string[];
    /**
    * Name of the resource. Provided by the client when the resource is
    * created. The name must be 1-63 characters long, and comply with
    * RFC1035. Specifically, the name must be 1-63 characters long and match
    * the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the
    * first character must be a lowercase letter, and all following
    * characters must be a dash, lowercase letter, or digit, except the last
    * character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#name ComputeRegionDisk#name}
    */
    readonly name: string;
    /**
    * Physical block size of the persistent disk, in bytes. If not present
    * in a request, a default value is used. Currently supported sizes
    * are 4096 and 16384, other sizes may be added in the future.
    * If an unsupported value is requested, the error message will list
    * the supported values for the caller's project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#physical_block_size_bytes ComputeRegionDisk#physical_block_size_bytes}
    */
    readonly physicalBlockSizeBytes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#project ComputeRegionDisk#project}
    */
    readonly project?: string;
    /**
    * Indicates how many IOPS to provision for the disk. This sets the number of I/O operations per second
    * that the disk can handle. Values must be between 10,000 and 120,000.
    * For more details, see the Extreme persistent disk [documentation](https://cloud.google.com/compute/docs/disks/extreme-persistent-disk).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#provisioned_iops ComputeRegionDisk#provisioned_iops}
    */
    readonly provisionedIops?: number;
    /**
    * Indicates how much throughput to provision for the disk. This sets the number of throughput
    * mb per second that the disk can handle. Values must be greater than or equal to 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#provisioned_throughput ComputeRegionDisk#provisioned_throughput}
    */
    readonly provisionedThroughput?: number;
    /**
    * A reference to the region where the disk resides.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#region ComputeRegionDisk#region}
    */
    readonly region?: string;
    /**
    * URLs of the zones where the disk should be replicated to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#replica_zones ComputeRegionDisk#replica_zones}
    */
    readonly replicaZones: string[];
    /**
    * Size of the persistent disk, specified in GB. You can specify this
    * field when creating a persistent disk using the sourceImage or
    * sourceSnapshot parameter, or specify it alone to create an empty
    * persistent disk.
    *
    * If you specify this field along with sourceImage or sourceSnapshot,
    * the value of sizeGb must not be less than the size of the sourceImage
    * or the size of the snapshot.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#size ComputeRegionDisk#size}
    */
    readonly size?: number;
    /**
    * The source snapshot used to create this disk. You can provide this as
    * a partial or full URL to the resource. For example, the following are
    * valid values:
    *
    * * 'https://www.googleapis.com/compute/v1/projects/project/global/snapshots/snapshot'
    * * 'projects/project/global/snapshots/snapshot'
    * * 'global/snapshots/snapshot'
    * * 'snapshot'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#snapshot ComputeRegionDisk#snapshot}
    */
    readonly snapshot?: string;
    /**
    * The source disk used to create this disk. You can provide this as a partial or full URL to the resource.
    * For example, the following are valid values:
    *
    * * https://www.googleapis.com/compute/v1/projects/{project}/zones/{zone}/disks/{disk}
    * * https://www.googleapis.com/compute/v1/projects/{project}/regions/{region}/disks/{disk}
    * * projects/{project}/zones/{zone}/disks/{disk}
    * * projects/{project}/regions/{region}/disks/{disk}
    * * zones/{zone}/disks/{disk}
    * * regions/{region}/disks/{disk}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#source_disk ComputeRegionDisk#source_disk}
    */
    readonly sourceDisk?: string;
    /**
    * URL of the disk type resource describing which disk type to use to
    * create the disk. Provide this when creating the disk.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#type ComputeRegionDisk#type}
    */
    readonly type?: string;
    /**
    * async_primary_disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#async_primary_disk ComputeRegionDisk#async_primary_disk}
    */
    readonly asyncPrimaryDisk?: ComputeRegionDiskAsyncPrimaryDisk;
    /**
    * disk_encryption_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#disk_encryption_key ComputeRegionDisk#disk_encryption_key}
    */
    readonly diskEncryptionKey?: ComputeRegionDiskDiskEncryptionKey;
    /**
    * guest_os_features block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#guest_os_features ComputeRegionDisk#guest_os_features}
    */
    readonly guestOsFeatures?: ComputeRegionDiskGuestOsFeatures[] | cdktn.IResolvable;
    /**
    * source_image_encryption_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#source_image_encryption_key ComputeRegionDisk#source_image_encryption_key}
    */
    readonly sourceImageEncryptionKey?: ComputeRegionDiskSourceImageEncryptionKey;
    /**
    * source_snapshot_encryption_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#source_snapshot_encryption_key ComputeRegionDisk#source_snapshot_encryption_key}
    */
    readonly sourceSnapshotEncryptionKey?: ComputeRegionDiskSourceSnapshotEncryptionKey;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#timeouts ComputeRegionDisk#timeouts}
    */
    readonly timeouts?: ComputeRegionDiskTimeouts;
}
export interface ComputeRegionDiskAsyncPrimaryDisk {
    /**
    * Primary disk for asynchronous disk replication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#disk ComputeRegionDisk#disk}
    */
    readonly disk: string;
}
export declare function computeRegionDiskAsyncPrimaryDiskToTerraform(struct?: ComputeRegionDiskAsyncPrimaryDiskOutputReference | ComputeRegionDiskAsyncPrimaryDisk): any;
export declare function computeRegionDiskAsyncPrimaryDiskToHclTerraform(struct?: ComputeRegionDiskAsyncPrimaryDiskOutputReference | ComputeRegionDiskAsyncPrimaryDisk): any;
export declare class ComputeRegionDiskAsyncPrimaryDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionDiskAsyncPrimaryDisk | undefined;
    set internalValue(value: ComputeRegionDiskAsyncPrimaryDisk | undefined);
    private _disk?;
    get disk(): string;
    set disk(value: string);
    get diskInput(): string | undefined;
}
export interface ComputeRegionDiskDiskEncryptionKey {
    /**
    * The name of the encryption key that is stored in Google Cloud KMS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#kms_key_name ComputeRegionDisk#kms_key_name}
    */
    readonly kmsKeyName?: string;
    /**
    * Specifies a 256-bit customer-supplied encryption key, encoded in
    * RFC 4648 base64 to either encrypt or decrypt this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#raw_key ComputeRegionDisk#raw_key}
    */
    readonly rawKey?: string;
    /**
    * Specifies a 256-bit customer-supplied encryption key, encoded in
    * RFC 4648 base64 to either encrypt or decrypt this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#raw_key_wo ComputeRegionDisk#raw_key_wo}
    */
    readonly rawKeyWo?: string;
    /**
    * Triggers update of 'raw_key_wo' write-only. Increment this value when an update to 'raw_key_wo' is needed. For more info see [updating write-only arguments](/docs/providers/google/guides/using_write_only_arguments.html#updating-write-only-arguments)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#raw_key_wo_version ComputeRegionDisk#raw_key_wo_version}
    */
    readonly rawKeyWoVersion?: string;
    /**
    * Specifies an RFC 4648 base64 encoded, RSA-wrapped 2048-bit
    * customer-supplied encryption key to either encrypt or decrypt
    * this resource. You can provide either the rawKey or the rsaEncryptedKey.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#rsa_encrypted_key ComputeRegionDisk#rsa_encrypted_key}
    */
    readonly rsaEncryptedKey?: string;
    /**
    * Specifies an RFC 4648 base64 encoded, RSA-wrapped 2048-bit
    * customer-supplied encryption key to either encrypt or decrypt
    * this resource. You can provide either the rawKey or the rsaEncryptedKey.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#rsa_encrypted_key_wo ComputeRegionDisk#rsa_encrypted_key_wo}
    */
    readonly rsaEncryptedKeyWo?: string;
    /**
    * Triggers update of 'rsa_encrypted_key_wo' write-only. Increment this value when an update to 'rsa_encrypted_key_wo' is needed. For more info see [updating write-only arguments](/docs/providers/google/guides/using_write_only_arguments.html#updating-write-only-arguments)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#rsa_encrypted_key_wo_version ComputeRegionDisk#rsa_encrypted_key_wo_version}
    */
    readonly rsaEncryptedKeyWoVersion?: string;
}
export declare function computeRegionDiskDiskEncryptionKeyToTerraform(struct?: ComputeRegionDiskDiskEncryptionKeyOutputReference | ComputeRegionDiskDiskEncryptionKey): any;
export declare function computeRegionDiskDiskEncryptionKeyToHclTerraform(struct?: ComputeRegionDiskDiskEncryptionKeyOutputReference | ComputeRegionDiskDiskEncryptionKey): any;
export declare class ComputeRegionDiskDiskEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionDiskDiskEncryptionKey | undefined;
    set internalValue(value: ComputeRegionDiskDiskEncryptionKey | undefined);
    private _kmsKeyName?;
    get kmsKeyName(): string;
    set kmsKeyName(value: string);
    resetKmsKeyName(): void;
    get kmsKeyNameInput(): string | undefined;
    private _rawKey?;
    get rawKey(): string;
    set rawKey(value: string);
    resetRawKey(): void;
    get rawKeyInput(): string | undefined;
    private _rawKeyWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get rawKeyWo(): string;
    set rawKeyWo(value: string);
    resetRawKeyWo(): void;
    get rawKeyWoInput(): string | undefined;
    private _rawKeyWoVersion?;
    get rawKeyWoVersion(): string;
    set rawKeyWoVersion(value: string);
    resetRawKeyWoVersion(): void;
    get rawKeyWoVersionInput(): string | undefined;
    private _rsaEncryptedKey?;
    get rsaEncryptedKey(): string;
    set rsaEncryptedKey(value: string);
    resetRsaEncryptedKey(): void;
    get rsaEncryptedKeyInput(): string | undefined;
    private _rsaEncryptedKeyWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get rsaEncryptedKeyWo(): string;
    set rsaEncryptedKeyWo(value: string);
    resetRsaEncryptedKeyWo(): void;
    get rsaEncryptedKeyWoInput(): string | undefined;
    private _rsaEncryptedKeyWoVersion?;
    get rsaEncryptedKeyWoVersion(): string;
    set rsaEncryptedKeyWoVersion(value: string);
    resetRsaEncryptedKeyWoVersion(): void;
    get rsaEncryptedKeyWoVersionInput(): string | undefined;
    get sha256(): string;
}
export interface ComputeRegionDiskGuestOsFeatures {
    /**
    * The type of supported feature. Read [Enabling guest operating system features](https://cloud.google.com/compute/docs/images/create-delete-deprecate-private-images#guest-os-features) to see a list of available options. Possible values: ["MULTI_IP_SUBNET", "SECURE_BOOT", "SEV_CAPABLE", "UEFI_COMPATIBLE", "VIRTIO_SCSI_MULTIQUEUE", "WINDOWS", "GVNIC", "SEV_LIVE_MIGRATABLE", "SEV_SNP_CAPABLE", "SUSPEND_RESUME_COMPATIBLE", "TDX_CAPABLE", "SEV_LIVE_MIGRATABLE_V2", "SNP_SVSM_CAPABLE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#type ComputeRegionDisk#type}
    */
    readonly type: string;
}
export declare function computeRegionDiskGuestOsFeaturesToTerraform(struct?: ComputeRegionDiskGuestOsFeatures | cdktn.IResolvable): any;
export declare function computeRegionDiskGuestOsFeaturesToHclTerraform(struct?: ComputeRegionDiskGuestOsFeatures | cdktn.IResolvable): any;
export declare class ComputeRegionDiskGuestOsFeaturesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeRegionDiskGuestOsFeatures | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionDiskGuestOsFeatures | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class ComputeRegionDiskGuestOsFeaturesList extends cdktn.ComplexList {
    internalValue?: ComputeRegionDiskGuestOsFeatures[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeRegionDiskGuestOsFeaturesOutputReference;
}
export interface ComputeRegionDiskSourceImageEncryptionKey {
    /**
    * The name of the encryption key that is stored in Google Cloud KMS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#kms_key_name ComputeRegionDisk#kms_key_name}
    */
    readonly kmsKeyName?: string;
    /**
    * The service account used for the encryption request for the given KMS key.
    * If absent, the Compute Engine Service Agent service account is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#kms_key_service_account ComputeRegionDisk#kms_key_service_account}
    */
    readonly kmsKeyServiceAccount?: string;
    /**
    * Specifies a 256-bit customer-supplied encryption key, encoded in
    * RFC 4648 base64 to either encrypt or decrypt this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#raw_key ComputeRegionDisk#raw_key}
    */
    readonly rawKey?: string;
    /**
    * Specifies an RFC 4648 base64 encoded, RSA-wrapped 2048-bit
    * customer-supplied encryption key to either encrypt or decrypt
    * this resource. You can provide either the rawKey or the rsaEncryptedKey.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#rsa_encrypted_key ComputeRegionDisk#rsa_encrypted_key}
    */
    readonly rsaEncryptedKey?: string;
}
export declare function computeRegionDiskSourceImageEncryptionKeyToTerraform(struct?: ComputeRegionDiskSourceImageEncryptionKeyOutputReference | ComputeRegionDiskSourceImageEncryptionKey): any;
export declare function computeRegionDiskSourceImageEncryptionKeyToHclTerraform(struct?: ComputeRegionDiskSourceImageEncryptionKeyOutputReference | ComputeRegionDiskSourceImageEncryptionKey): any;
export declare class ComputeRegionDiskSourceImageEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionDiskSourceImageEncryptionKey | undefined;
    set internalValue(value: ComputeRegionDiskSourceImageEncryptionKey | undefined);
    private _kmsKeyName?;
    get kmsKeyName(): string;
    set kmsKeyName(value: string);
    resetKmsKeyName(): void;
    get kmsKeyNameInput(): string | undefined;
    private _kmsKeyServiceAccount?;
    get kmsKeyServiceAccount(): string;
    set kmsKeyServiceAccount(value: string);
    resetKmsKeyServiceAccount(): void;
    get kmsKeyServiceAccountInput(): string | undefined;
    private _rawKey?;
    get rawKey(): string;
    set rawKey(value: string);
    resetRawKey(): void;
    get rawKeyInput(): string | undefined;
    private _rsaEncryptedKey?;
    get rsaEncryptedKey(): string;
    set rsaEncryptedKey(value: string);
    resetRsaEncryptedKey(): void;
    get rsaEncryptedKeyInput(): string | undefined;
    get sha256(): string;
}
export interface ComputeRegionDiskSourceSnapshotEncryptionKey {
    /**
    * Specifies a 256-bit customer-supplied encryption key, encoded in
    * RFC 4648 base64 to either encrypt or decrypt this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#raw_key ComputeRegionDisk#raw_key}
    */
    readonly rawKey?: string;
}
export declare function computeRegionDiskSourceSnapshotEncryptionKeyToTerraform(struct?: ComputeRegionDiskSourceSnapshotEncryptionKeyOutputReference | ComputeRegionDiskSourceSnapshotEncryptionKey): any;
export declare function computeRegionDiskSourceSnapshotEncryptionKeyToHclTerraform(struct?: ComputeRegionDiskSourceSnapshotEncryptionKeyOutputReference | ComputeRegionDiskSourceSnapshotEncryptionKey): any;
export declare class ComputeRegionDiskSourceSnapshotEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionDiskSourceSnapshotEncryptionKey | undefined;
    set internalValue(value: ComputeRegionDiskSourceSnapshotEncryptionKey | undefined);
    private _rawKey?;
    get rawKey(): string;
    set rawKey(value: string);
    resetRawKey(): void;
    get rawKeyInput(): string | undefined;
    get sha256(): string;
}
export interface ComputeRegionDiskTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#create ComputeRegionDisk#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#delete ComputeRegionDisk#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#update ComputeRegionDisk#update}
    */
    readonly update?: string;
}
export declare function computeRegionDiskTimeoutsToTerraform(struct?: ComputeRegionDiskTimeouts | cdktn.IResolvable): any;
export declare function computeRegionDiskTimeoutsToHclTerraform(struct?: ComputeRegionDiskTimeouts | cdktn.IResolvable): any;
export declare class ComputeRegionDiskTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionDiskTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionDiskTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk google_compute_region_disk}
*/
export declare class ComputeRegionDisk extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_region_disk";
    /**
    * Generates CDKTN code for importing a ComputeRegionDisk resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeRegionDisk to import
    * @param importFromId The id of the existing ComputeRegionDisk that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeRegionDisk to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_disk google_compute_region_disk} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeRegionDiskConfig
    */
    constructor(scope: Construct, id: string, config: ComputeRegionDiskConfig);
    private _accessMode?;
    get accessMode(): string;
    set accessMode(value: string);
    resetAccessMode(): void;
    get accessModeInput(): string | undefined;
    private _createSnapshotBeforeDestroy?;
    get createSnapshotBeforeDestroy(): boolean | cdktn.IResolvable;
    set createSnapshotBeforeDestroy(value: boolean | cdktn.IResolvable);
    resetCreateSnapshotBeforeDestroy(): void;
    get createSnapshotBeforeDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _createSnapshotBeforeDestroyPrefix?;
    get createSnapshotBeforeDestroyPrefix(): string;
    set createSnapshotBeforeDestroyPrefix(value: string);
    resetCreateSnapshotBeforeDestroyPrefix(): void;
    get createSnapshotBeforeDestroyPrefixInput(): string | undefined;
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get diskId(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _image?;
    get image(): string;
    set image(value: string);
    resetImage(): void;
    get imageInput(): string | undefined;
    get labelFingerprint(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    get lastAttachTimestamp(): string;
    get lastDetachTimestamp(): string;
    private _licenses?;
    get licenses(): string[];
    set licenses(value: string[]);
    resetLicenses(): void;
    get licensesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _physicalBlockSizeBytes?;
    get physicalBlockSizeBytes(): number;
    set physicalBlockSizeBytes(value: number);
    resetPhysicalBlockSizeBytes(): void;
    get physicalBlockSizeBytesInput(): number | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _provisionedIops?;
    get provisionedIops(): number;
    set provisionedIops(value: number);
    resetProvisionedIops(): void;
    get provisionedIopsInput(): number | undefined;
    private _provisionedThroughput?;
    get provisionedThroughput(): number;
    set provisionedThroughput(value: number);
    resetProvisionedThroughput(): void;
    get provisionedThroughputInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _replicaZones?;
    get replicaZones(): string[];
    set replicaZones(value: string[]);
    get replicaZonesInput(): string[] | undefined;
    get selfLink(): string;
    private _size?;
    get size(): number;
    set size(value: number);
    resetSize(): void;
    get sizeInput(): number | undefined;
    private _snapshot?;
    get snapshot(): string;
    set snapshot(value: string);
    resetSnapshot(): void;
    get snapshotInput(): string | undefined;
    private _sourceDisk?;
    get sourceDisk(): string;
    set sourceDisk(value: string);
    resetSourceDisk(): void;
    get sourceDiskInput(): string | undefined;
    get sourceDiskId(): string;
    get sourceImageId(): string;
    get sourceSnapshotId(): string;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    get users(): string[];
    private _asyncPrimaryDisk;
    get asyncPrimaryDisk(): ComputeRegionDiskAsyncPrimaryDiskOutputReference;
    putAsyncPrimaryDisk(value: ComputeRegionDiskAsyncPrimaryDisk): void;
    resetAsyncPrimaryDisk(): void;
    get asyncPrimaryDiskInput(): ComputeRegionDiskAsyncPrimaryDisk | undefined;
    private _diskEncryptionKey;
    get diskEncryptionKey(): ComputeRegionDiskDiskEncryptionKeyOutputReference;
    putDiskEncryptionKey(value: ComputeRegionDiskDiskEncryptionKey): void;
    resetDiskEncryptionKey(): void;
    get diskEncryptionKeyInput(): ComputeRegionDiskDiskEncryptionKey | undefined;
    private _guestOsFeatures;
    get guestOsFeatures(): ComputeRegionDiskGuestOsFeaturesList;
    putGuestOsFeatures(value: ComputeRegionDiskGuestOsFeatures[] | cdktn.IResolvable): void;
    resetGuestOsFeatures(): void;
    get guestOsFeaturesInput(): cdktn.IResolvable | ComputeRegionDiskGuestOsFeatures[] | undefined;
    private _sourceImageEncryptionKey;
    get sourceImageEncryptionKey(): ComputeRegionDiskSourceImageEncryptionKeyOutputReference;
    putSourceImageEncryptionKey(value: ComputeRegionDiskSourceImageEncryptionKey): void;
    resetSourceImageEncryptionKey(): void;
    get sourceImageEncryptionKeyInput(): ComputeRegionDiskSourceImageEncryptionKey | undefined;
    private _sourceSnapshotEncryptionKey;
    get sourceSnapshotEncryptionKey(): ComputeRegionDiskSourceSnapshotEncryptionKeyOutputReference;
    putSourceSnapshotEncryptionKey(value: ComputeRegionDiskSourceSnapshotEncryptionKey): void;
    resetSourceSnapshotEncryptionKey(): void;
    get sourceSnapshotEncryptionKeyInput(): ComputeRegionDiskSourceSnapshotEncryptionKey | undefined;
    private _timeouts;
    get timeouts(): ComputeRegionDiskTimeoutsOutputReference;
    putTimeouts(value: ComputeRegionDiskTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeRegionDiskTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
