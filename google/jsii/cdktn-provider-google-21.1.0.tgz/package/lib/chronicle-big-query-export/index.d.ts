/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChronicleBigQueryExportConfig extends cdktn.TerraformMetaArguments {
    /**
    * The BigQueryExportPackage entitled for the Chronicle instance. Possible values: ["BIG_QUERY_EXPORT_PACKAGE_BYOBQ", "BIG_QUERY_EXPORT_PACKAGE_ADVANCED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_big_query_export#big_query_export_package ChronicleBigQueryExport#big_query_export_package}
    */
    readonly bigQueryExportPackage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_big_query_export#id ChronicleBigQueryExport#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_big_query_export#instance ChronicleBigQueryExport#instance}
    */
    readonly instance: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_big_query_export#location ChronicleBigQueryExport#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_big_query_export#project ChronicleBigQueryExport#project}
    */
    readonly project?: string;
    /**
    * entity_graph_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_big_query_export#entity_graph_settings ChronicleBigQueryExport#entity_graph_settings}
    */
    readonly entityGraphSettings?: ChronicleBigQueryExportEntityGraphSettings;
    /**
    * ioc_matches_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_big_query_export#ioc_matches_settings ChronicleBigQueryExport#ioc_matches_settings}
    */
    readonly iocMatchesSettings?: ChronicleBigQueryExportIocMatchesSettings;
    /**
    * rule_detections_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_big_query_export#rule_detections_settings ChronicleBigQueryExport#rule_detections_settings}
    */
    readonly ruleDetectionsSettings?: ChronicleBigQueryExportRuleDetectionsSettings;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_big_query_export#timeouts ChronicleBigQueryExport#timeouts}
    */
    readonly timeouts?: ChronicleBigQueryExportTimeouts;
    /**
    * udm_events_aggregates_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_big_query_export#udm_events_aggregates_settings ChronicleBigQueryExport#udm_events_aggregates_settings}
    */
    readonly udmEventsAggregatesSettings?: ChronicleBigQueryExportUdmEventsAggregatesSettings;
    /**
    * udm_events_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_big_query_export#udm_events_settings ChronicleBigQueryExport#udm_events_settings}
    */
    readonly udmEventsSettings?: ChronicleBigQueryExportUdmEventsSettings;
}
export interface ChronicleBigQueryExportEntityGraphSettings {
    /**
    * Whether the data source is enabled for export.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_big_query_export#enabled ChronicleBigQueryExport#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * The retention period for the data source in days.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_big_query_export#retention_days ChronicleBigQueryExport#retention_days}
    */
    readonly retentionDays: number;
}
export declare function chronicleBigQueryExportEntityGraphSettingsToTerraform(struct?: ChronicleBigQueryExportEntityGraphSettingsOutputReference | ChronicleBigQueryExportEntityGraphSettings): any;
export declare function chronicleBigQueryExportEntityGraphSettingsToHclTerraform(struct?: ChronicleBigQueryExportEntityGraphSettingsOutputReference | ChronicleBigQueryExportEntityGraphSettings): any;
export declare class ChronicleBigQueryExportEntityGraphSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleBigQueryExportEntityGraphSettings | undefined;
    set internalValue(value: ChronicleBigQueryExportEntityGraphSettings | undefined);
    get dataFreshnessTime(): string;
    get dataVolume(): string;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get latestExportJobState(): string;
    private _retentionDays?;
    get retentionDays(): number;
    set retentionDays(value: number);
    get retentionDaysInput(): number | undefined;
}
export interface ChronicleBigQueryExportIocMatchesSettings {
    /**
    * Whether the data source is enabled for export.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_big_query_export#enabled ChronicleBigQueryExport#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * The retention period for the data source in days.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_big_query_export#retention_days ChronicleBigQueryExport#retention_days}
    */
    readonly retentionDays: number;
}
export declare function chronicleBigQueryExportIocMatchesSettingsToTerraform(struct?: ChronicleBigQueryExportIocMatchesSettingsOutputReference | ChronicleBigQueryExportIocMatchesSettings): any;
export declare function chronicleBigQueryExportIocMatchesSettingsToHclTerraform(struct?: ChronicleBigQueryExportIocMatchesSettingsOutputReference | ChronicleBigQueryExportIocMatchesSettings): any;
export declare class ChronicleBigQueryExportIocMatchesSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleBigQueryExportIocMatchesSettings | undefined;
    set internalValue(value: ChronicleBigQueryExportIocMatchesSettings | undefined);
    get dataFreshnessTime(): string;
    get dataVolume(): string;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get latestExportJobState(): string;
    private _retentionDays?;
    get retentionDays(): number;
    set retentionDays(value: number);
    get retentionDaysInput(): number | undefined;
}
export interface ChronicleBigQueryExportRuleDetectionsSettings {
    /**
    * Whether the data source is enabled for export.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_big_query_export#enabled ChronicleBigQueryExport#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * The retention period for the data source in days.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_big_query_export#retention_days ChronicleBigQueryExport#retention_days}
    */
    readonly retentionDays: number;
}
export declare function chronicleBigQueryExportRuleDetectionsSettingsToTerraform(struct?: ChronicleBigQueryExportRuleDetectionsSettingsOutputReference | ChronicleBigQueryExportRuleDetectionsSettings): any;
export declare function chronicleBigQueryExportRuleDetectionsSettingsToHclTerraform(struct?: ChronicleBigQueryExportRuleDetectionsSettingsOutputReference | ChronicleBigQueryExportRuleDetectionsSettings): any;
export declare class ChronicleBigQueryExportRuleDetectionsSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleBigQueryExportRuleDetectionsSettings | undefined;
    set internalValue(value: ChronicleBigQueryExportRuleDetectionsSettings | undefined);
    get dataFreshnessTime(): string;
    get dataVolume(): string;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get latestExportJobState(): string;
    private _retentionDays?;
    get retentionDays(): number;
    set retentionDays(value: number);
    get retentionDaysInput(): number | undefined;
}
export interface ChronicleBigQueryExportTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_big_query_export#create ChronicleBigQueryExport#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_big_query_export#delete ChronicleBigQueryExport#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_big_query_export#update ChronicleBigQueryExport#update}
    */
    readonly update?: string;
}
export declare function chronicleBigQueryExportTimeoutsToTerraform(struct?: ChronicleBigQueryExportTimeouts | cdktn.IResolvable): any;
export declare function chronicleBigQueryExportTimeoutsToHclTerraform(struct?: ChronicleBigQueryExportTimeouts | cdktn.IResolvable): any;
export declare class ChronicleBigQueryExportTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleBigQueryExportTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ChronicleBigQueryExportTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface ChronicleBigQueryExportUdmEventsAggregatesSettings {
    /**
    * Whether the data source is enabled for export.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_big_query_export#enabled ChronicleBigQueryExport#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * The retention period for the data source in days.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_big_query_export#retention_days ChronicleBigQueryExport#retention_days}
    */
    readonly retentionDays: number;
}
export declare function chronicleBigQueryExportUdmEventsAggregatesSettingsToTerraform(struct?: ChronicleBigQueryExportUdmEventsAggregatesSettingsOutputReference | ChronicleBigQueryExportUdmEventsAggregatesSettings): any;
export declare function chronicleBigQueryExportUdmEventsAggregatesSettingsToHclTerraform(struct?: ChronicleBigQueryExportUdmEventsAggregatesSettingsOutputReference | ChronicleBigQueryExportUdmEventsAggregatesSettings): any;
export declare class ChronicleBigQueryExportUdmEventsAggregatesSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleBigQueryExportUdmEventsAggregatesSettings | undefined;
    set internalValue(value: ChronicleBigQueryExportUdmEventsAggregatesSettings | undefined);
    get dataFreshnessTime(): string;
    get dataVolume(): string;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get latestExportJobState(): string;
    private _retentionDays?;
    get retentionDays(): number;
    set retentionDays(value: number);
    get retentionDaysInput(): number | undefined;
}
export interface ChronicleBigQueryExportUdmEventsSettings {
    /**
    * Whether the data source is enabled for export.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_big_query_export#enabled ChronicleBigQueryExport#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * The retention period for the data source in days.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_big_query_export#retention_days ChronicleBigQueryExport#retention_days}
    */
    readonly retentionDays: number;
}
export declare function chronicleBigQueryExportUdmEventsSettingsToTerraform(struct?: ChronicleBigQueryExportUdmEventsSettingsOutputReference | ChronicleBigQueryExportUdmEventsSettings): any;
export declare function chronicleBigQueryExportUdmEventsSettingsToHclTerraform(struct?: ChronicleBigQueryExportUdmEventsSettingsOutputReference | ChronicleBigQueryExportUdmEventsSettings): any;
export declare class ChronicleBigQueryExportUdmEventsSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChronicleBigQueryExportUdmEventsSettings | undefined;
    set internalValue(value: ChronicleBigQueryExportUdmEventsSettings | undefined);
    get dataFreshnessTime(): string;
    get dataVolume(): string;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get latestExportJobState(): string;
    private _retentionDays?;
    get retentionDays(): number;
    set retentionDays(value: number);
    get retentionDaysInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_big_query_export google_chronicle_big_query_export}
*/
export declare class ChronicleBigQueryExport extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_chronicle_big_query_export";
    /**
    * Generates CDKTN code for importing a ChronicleBigQueryExport resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChronicleBigQueryExport to import
    * @param importFromId The id of the existing ChronicleBigQueryExport that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_big_query_export#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChronicleBigQueryExport to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/chronicle_big_query_export google_chronicle_big_query_export} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChronicleBigQueryExportConfig
    */
    constructor(scope: Construct, id: string, config: ChronicleBigQueryExportConfig);
    private _bigQueryExportPackage?;
    get bigQueryExportPackage(): string;
    set bigQueryExportPackage(value: string);
    resetBigQueryExportPackage(): void;
    get bigQueryExportPackageInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instance?;
    get instance(): string;
    set instance(value: string);
    get instanceInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get provisioned(): cdktn.IResolvable;
    private _entityGraphSettings;
    get entityGraphSettings(): ChronicleBigQueryExportEntityGraphSettingsOutputReference;
    putEntityGraphSettings(value: ChronicleBigQueryExportEntityGraphSettings): void;
    resetEntityGraphSettings(): void;
    get entityGraphSettingsInput(): ChronicleBigQueryExportEntityGraphSettings | undefined;
    private _iocMatchesSettings;
    get iocMatchesSettings(): ChronicleBigQueryExportIocMatchesSettingsOutputReference;
    putIocMatchesSettings(value: ChronicleBigQueryExportIocMatchesSettings): void;
    resetIocMatchesSettings(): void;
    get iocMatchesSettingsInput(): ChronicleBigQueryExportIocMatchesSettings | undefined;
    private _ruleDetectionsSettings;
    get ruleDetectionsSettings(): ChronicleBigQueryExportRuleDetectionsSettingsOutputReference;
    putRuleDetectionsSettings(value: ChronicleBigQueryExportRuleDetectionsSettings): void;
    resetRuleDetectionsSettings(): void;
    get ruleDetectionsSettingsInput(): ChronicleBigQueryExportRuleDetectionsSettings | undefined;
    private _timeouts;
    get timeouts(): ChronicleBigQueryExportTimeoutsOutputReference;
    putTimeouts(value: ChronicleBigQueryExportTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ChronicleBigQueryExportTimeouts | undefined;
    private _udmEventsAggregatesSettings;
    get udmEventsAggregatesSettings(): ChronicleBigQueryExportUdmEventsAggregatesSettingsOutputReference;
    putUdmEventsAggregatesSettings(value: ChronicleBigQueryExportUdmEventsAggregatesSettings): void;
    resetUdmEventsAggregatesSettings(): void;
    get udmEventsAggregatesSettingsInput(): ChronicleBigQueryExportUdmEventsAggregatesSettings | undefined;
    private _udmEventsSettings;
    get udmEventsSettings(): ChronicleBigQueryExportUdmEventsSettingsOutputReference;
    putUdmEventsSettings(value: ChronicleBigQueryExportUdmEventsSettings): void;
    resetUdmEventsSettings(): void;
    get udmEventsSettingsInput(): ChronicleBigQueryExportUdmEventsSettings | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
