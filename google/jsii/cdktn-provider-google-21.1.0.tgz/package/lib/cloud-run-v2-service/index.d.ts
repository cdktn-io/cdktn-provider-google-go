/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudRunV2ServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Unstructured key value map that may be set by external tools to store and arbitrary metadata. They are not queryable and should be preserved when modifying objects.
    *
    * Cloud Run API v2 does not support annotations with 'run.googleapis.com', 'cloud.googleapis.com', 'serving.knative.dev', or 'autoscaling.knative.dev' namespaces, and they will be rejected in new resources.
    * All system annotations in v1 now have a corresponding field in v2 Service.
    *
    * This field follows Kubernetes annotations' namespacing, limits, and rules.
    *
    * **Note**: This field is non-authoritative, and will only manage the annotations present in your configuration.
    * Please refer to the field 'effective_annotations' for all of the annotations present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#annotations CloudRunV2Service#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Arbitrary identifier for the API client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#client CloudRunV2Service#client}
    */
    readonly client?: string;
    /**
    * Arbitrary version identifier for the API client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#client_version CloudRunV2Service#client_version}
    */
    readonly clientVersion?: string;
    /**
    * One or more custom audiences that you want this service to support. Specify each custom audience as the full URL in a string. The custom audiences are encoded in the token and used to authenticate requests.
    * For more information, see https://cloud.google.com/run/docs/configuring/custom-audiences.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#custom_audiences CloudRunV2Service#custom_audiences}
    */
    readonly customAudiences?: string[];
    /**
    * Disables public resolution of the default URI of this service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#default_uri_disabled CloudRunV2Service#default_uri_disabled}
    */
    readonly defaultUriDisabled?: boolean | cdktn.IResolvable;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#deletion_policy CloudRunV2Service#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Whether Terraform will be prevented from destroying the service. Defaults to true.
    * When a'terraform destroy' or 'terraform apply' would delete the service,
    * the command will fail if this field is not set to false in Terraform state.
    * When the field is set to true or unset in Terraform state, a 'terraform apply'
    * or 'terraform destroy' that would delete the service will fail.
    * When the field is set to false, deleting the service is allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#deletion_protection CloudRunV2Service#deletion_protection}
    */
    readonly deletionProtection?: boolean | cdktn.IResolvable;
    /**
    * User-provided description of the Service. This field currently has a 512-character limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#description CloudRunV2Service#description}
    */
    readonly description?: string;
    /**
    * Used to enable/disable IAP for the cloud-run service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#iap_enabled CloudRunV2Service#iap_enabled}
    */
    readonly iapEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#id CloudRunV2Service#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Provides the ingress settings for this Service. On output, returns the currently observed ingress settings, or INGRESS_TRAFFIC_UNSPECIFIED if no revision is active. Possible values: ["INGRESS_TRAFFIC_ALL", "INGRESS_TRAFFIC_INTERNAL_ONLY", "INGRESS_TRAFFIC_INTERNAL_LOAD_BALANCER"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#ingress CloudRunV2Service#ingress}
    */
    readonly ingress?: string;
    /**
    * Disables IAM permission check for run.routes.invoke for callers of this service. For more information, visit https://cloud.google.com/run/docs/securing/managing-access#invoker_check.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#invoker_iam_disabled CloudRunV2Service#invoker_iam_disabled}
    */
    readonly invokerIamDisabled?: boolean | cdktn.IResolvable;
    /**
    * Unstructured key value map that can be used to organize and categorize objects. User-provided labels are shared with Google's billing system, so they can be used to filter, or break down billing charges by team, component,
    * environment, state, etc. For more information, visit https://docs.cloud.google.com/resource-manager/docs/creating-managing-labels or https://cloud.google.com/run/docs/configuring/labels.
    *
    * Cloud Run API v2 does not support labels with  'run.googleapis.com', 'cloud.googleapis.com', 'serving.knative.dev', or 'autoscaling.knative.dev' namespaces, and they will be rejected.
    * All system labels in v1 now have a corresponding field in v2 Service.
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#labels CloudRunV2Service#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The launch stage as defined by [Google Cloud Platform Launch Stages](https://cloud.google.com/products#product-launch-stages). Cloud Run supports ALPHA, BETA, and GA.
    * If no value is specified, GA is assumed. Set the launch stage to a preview stage on input to allow use of preview features in that stage. On read (or output), describes whether the resource uses preview features.
    *
    * For example, if ALPHA is provided as input, but only BETA and GA-level features are used, this field will be BETA on output. Possible values: ["UNIMPLEMENTED", "PRELAUNCH", "EARLY_ACCESS", "ALPHA", "BETA", "GA", "DEPRECATED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#launch_stage CloudRunV2Service#launch_stage}
    */
    readonly launchStage?: string;
    /**
    * The location of the cloud run service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#location CloudRunV2Service#location}
    */
    readonly location: string;
    /**
    * Name of the Service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#name CloudRunV2Service#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#project CloudRunV2Service#project}
    */
    readonly project?: string;
    /**
    * Enables SSH access to the Service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#ssh_enabled CloudRunV2Service#ssh_enabled}
    */
    readonly sshEnabled?: boolean | cdktn.IResolvable;
    /**
    * A map of resource manager tags.
    * Resource manager tag keys and values have the same definition as resource manager tags.
    * Keys must be in the format tagKeys/{tag_key_id}, and values are in the format tagValues/{tag_value_id}.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#tags CloudRunV2Service#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * binary_authorization block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#binary_authorization CloudRunV2Service#binary_authorization}
    */
    readonly binaryAuthorization?: CloudRunV2ServiceBinaryAuthorization;
    /**
    * build_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#build_config CloudRunV2Service#build_config}
    */
    readonly buildConfig?: CloudRunV2ServiceBuildConfig;
    /**
    * multi_region_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#multi_region_settings CloudRunV2Service#multi_region_settings}
    */
    readonly multiRegionSettings?: CloudRunV2ServiceMultiRegionSettings;
    /**
    * scaling block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#scaling CloudRunV2Service#scaling}
    */
    readonly scaling?: CloudRunV2ServiceScaling;
    /**
    * template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#template CloudRunV2Service#template}
    */
    readonly template: CloudRunV2ServiceTemplate;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#timeouts CloudRunV2Service#timeouts}
    */
    readonly timeouts?: CloudRunV2ServiceTimeouts;
    /**
    * traffic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#traffic CloudRunV2Service#traffic}
    */
    readonly traffic?: CloudRunV2ServiceTraffic[] | cdktn.IResolvable;
}
export interface CloudRunV2ServiceConditions {
}
export declare function cloudRunV2ServiceConditionsToTerraform(struct?: CloudRunV2ServiceConditions): any;
export declare function cloudRunV2ServiceConditionsToHclTerraform(struct?: CloudRunV2ServiceConditions): any;
export declare class CloudRunV2ServiceConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2ServiceConditions | undefined;
    set internalValue(value: CloudRunV2ServiceConditions | undefined);
    get executionReason(): string;
    get lastTransitionTime(): string;
    get message(): string;
    get reason(): string;
    get revisionReason(): string;
    get severity(): string;
    get state(): string;
    get type(): string;
}
export declare class CloudRunV2ServiceConditionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2ServiceConditionsOutputReference;
}
export interface CloudRunV2ServiceTerminalCondition {
}
export declare function cloudRunV2ServiceTerminalConditionToTerraform(struct?: CloudRunV2ServiceTerminalCondition): any;
export declare function cloudRunV2ServiceTerminalConditionToHclTerraform(struct?: CloudRunV2ServiceTerminalCondition): any;
export declare class CloudRunV2ServiceTerminalConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2ServiceTerminalCondition | undefined;
    set internalValue(value: CloudRunV2ServiceTerminalCondition | undefined);
    get executionReason(): string;
    get lastTransitionTime(): string;
    get message(): string;
    get reason(): string;
    get revisionReason(): string;
    get severity(): string;
    get state(): string;
    get type(): string;
}
export declare class CloudRunV2ServiceTerminalConditionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2ServiceTerminalConditionOutputReference;
}
export interface CloudRunV2ServiceTrafficStatuses {
}
export declare function cloudRunV2ServiceTrafficStatusesToTerraform(struct?: CloudRunV2ServiceTrafficStatuses): any;
export declare function cloudRunV2ServiceTrafficStatusesToHclTerraform(struct?: CloudRunV2ServiceTrafficStatuses): any;
export declare class CloudRunV2ServiceTrafficStatusesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2ServiceTrafficStatuses | undefined;
    set internalValue(value: CloudRunV2ServiceTrafficStatuses | undefined);
    get percent(): number;
    get revision(): string;
    get tag(): string;
    get type(): string;
    get uri(): string;
}
export declare class CloudRunV2ServiceTrafficStatusesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2ServiceTrafficStatusesOutputReference;
}
export interface CloudRunV2ServiceBinaryAuthorization {
    /**
    * If present, indicates to use Breakglass using this justification. If useDefault is False, then it must be empty. For more information on breakglass, see https://cloud.google.com/binary-authorization/docs/using-breakglass
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#breakglass_justification CloudRunV2Service#breakglass_justification}
    */
    readonly breakglassJustification?: string;
    /**
    * The path to a binary authorization policy. Format: projects/{project}/platforms/cloudRun/{policy-name}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#policy CloudRunV2Service#policy}
    */
    readonly policy?: string;
    /**
    * If True, indicates to use the default project's binary authorization policy. If False, binary authorization will be disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#use_default CloudRunV2Service#use_default}
    */
    readonly useDefault?: boolean | cdktn.IResolvable;
}
export declare function cloudRunV2ServiceBinaryAuthorizationToTerraform(struct?: CloudRunV2ServiceBinaryAuthorizationOutputReference | CloudRunV2ServiceBinaryAuthorization): any;
export declare function cloudRunV2ServiceBinaryAuthorizationToHclTerraform(struct?: CloudRunV2ServiceBinaryAuthorizationOutputReference | CloudRunV2ServiceBinaryAuthorization): any;
export declare class CloudRunV2ServiceBinaryAuthorizationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceBinaryAuthorization | undefined;
    set internalValue(value: CloudRunV2ServiceBinaryAuthorization | undefined);
    private _breakglassJustification?;
    get breakglassJustification(): string;
    set breakglassJustification(value: string);
    resetBreakglassJustification(): void;
    get breakglassJustificationInput(): string | undefined;
    private _policy?;
    get policy(): string;
    set policy(value: string);
    resetPolicy(): void;
    get policyInput(): string | undefined;
    private _useDefault?;
    get useDefault(): boolean | cdktn.IResolvable;
    set useDefault(value: boolean | cdktn.IResolvable);
    resetUseDefault(): void;
    get useDefaultInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CloudRunV2ServiceBuildConfig {
    /**
    * The base image used to build the function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#base_image CloudRunV2Service#base_image}
    */
    readonly baseImage?: string;
    /**
    * Sets whether the function will receive automatic base image updates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#enable_automatic_updates CloudRunV2Service#enable_automatic_updates}
    */
    readonly enableAutomaticUpdates?: boolean | cdktn.IResolvable;
    /**
    * User-provided build-time environment variables for the function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#environment_variables CloudRunV2Service#environment_variables}
    */
    readonly environmentVariables?: {
        [key: string]: string;
    };
    /**
    * The name of the function (as defined in source code) that will be executed. Defaults to the resource name suffix, if not specified. For backward compatibility, if function with given name is not found, then the system will try to use function named "function".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#function_target CloudRunV2Service#function_target}
    */
    readonly functionTarget?: string;
    /**
    * Artifact Registry URI to store the built image.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#image_uri CloudRunV2Service#image_uri}
    */
    readonly imageUri?: string;
    /**
    * Service account to be used for building the container. The format of this field is 'projects/{projectId}/serviceAccounts/{serviceAccountEmail}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#service_account CloudRunV2Service#service_account}
    */
    readonly serviceAccount?: string;
    /**
    * The Cloud Storage bucket URI where the function source code is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#source_location CloudRunV2Service#source_location}
    */
    readonly sourceLocation?: string;
    /**
    * Name of the Cloud Build Custom Worker Pool that should be used to build the Cloud Run function. The format of this field is 'projects/{project}/locations/{region}/workerPools/{workerPool}' where {project} and {region} are the project id and region respectively where the worker pool is defined and {workerPool} is the short name of the worker pool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#worker_pool CloudRunV2Service#worker_pool}
    */
    readonly workerPool?: string;
}
export declare function cloudRunV2ServiceBuildConfigToTerraform(struct?: CloudRunV2ServiceBuildConfigOutputReference | CloudRunV2ServiceBuildConfig): any;
export declare function cloudRunV2ServiceBuildConfigToHclTerraform(struct?: CloudRunV2ServiceBuildConfigOutputReference | CloudRunV2ServiceBuildConfig): any;
export declare class CloudRunV2ServiceBuildConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceBuildConfig | undefined;
    set internalValue(value: CloudRunV2ServiceBuildConfig | undefined);
    private _baseImage?;
    get baseImage(): string;
    set baseImage(value: string);
    resetBaseImage(): void;
    get baseImageInput(): string | undefined;
    private _enableAutomaticUpdates?;
    get enableAutomaticUpdates(): boolean | cdktn.IResolvable;
    set enableAutomaticUpdates(value: boolean | cdktn.IResolvable);
    resetEnableAutomaticUpdates(): void;
    get enableAutomaticUpdatesInput(): boolean | cdktn.IResolvable | undefined;
    private _environmentVariables?;
    get environmentVariables(): {
        [key: string]: string;
    };
    set environmentVariables(value: {
        [key: string]: string;
    });
    resetEnvironmentVariables(): void;
    get environmentVariablesInput(): {
        [key: string]: string;
    } | undefined;
    private _functionTarget?;
    get functionTarget(): string;
    set functionTarget(value: string);
    resetFunctionTarget(): void;
    get functionTargetInput(): string | undefined;
    private _imageUri?;
    get imageUri(): string;
    set imageUri(value: string);
    resetImageUri(): void;
    get imageUriInput(): string | undefined;
    get name(): string;
    private _serviceAccount?;
    get serviceAccount(): string;
    set serviceAccount(value: string);
    resetServiceAccount(): void;
    get serviceAccountInput(): string | undefined;
    private _sourceLocation?;
    get sourceLocation(): string;
    set sourceLocation(value: string);
    resetSourceLocation(): void;
    get sourceLocationInput(): string | undefined;
    private _workerPool?;
    get workerPool(): string;
    set workerPool(value: string);
    resetWorkerPool(): void;
    get workerPoolInput(): string | undefined;
}
export interface CloudRunV2ServiceMultiRegionSettings {
    /**
    * The list of regions to deploy the multi-region Service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#regions CloudRunV2Service#regions}
    */
    readonly regions?: string[];
}
export declare function cloudRunV2ServiceMultiRegionSettingsToTerraform(struct?: CloudRunV2ServiceMultiRegionSettingsOutputReference | CloudRunV2ServiceMultiRegionSettings): any;
export declare function cloudRunV2ServiceMultiRegionSettingsToHclTerraform(struct?: CloudRunV2ServiceMultiRegionSettingsOutputReference | CloudRunV2ServiceMultiRegionSettings): any;
export declare class CloudRunV2ServiceMultiRegionSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceMultiRegionSettings | undefined;
    set internalValue(value: CloudRunV2ServiceMultiRegionSettings | undefined);
    get multiRegionId(): string;
    private _regions?;
    get regions(): string[];
    set regions(value: string[]);
    resetRegions(): void;
    get regionsInput(): string[] | undefined;
}
export interface CloudRunV2ServiceScaling {
    /**
    * Total instance count for the service in manual scaling mode. This number of instances is divided among all revisions with specified traffic based on the percent of traffic they are receiving.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#manual_instance_count CloudRunV2Service#manual_instance_count}
    */
    readonly manualInstanceCount?: number;
    /**
    * Combined maximum number of instances for all revisions receiving traffic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#max_instance_count CloudRunV2Service#max_instance_count}
    */
    readonly maxInstanceCount?: number;
    /**
    * Minimum number of instances for the service, to be divided among all revisions receiving traffic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#min_instance_count CloudRunV2Service#min_instance_count}
    */
    readonly minInstanceCount?: number;
    /**
    * The [scaling mode](https://cloud.google.com/run/docs/reference/rest/v2/projects.locations.services#scalingmode) for the service. Possible values: ["AUTOMATIC", "MANUAL"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#scaling_mode CloudRunV2Service#scaling_mode}
    */
    readonly scalingMode?: string;
}
export declare function cloudRunV2ServiceScalingToTerraform(struct?: CloudRunV2ServiceScalingOutputReference | CloudRunV2ServiceScaling): any;
export declare function cloudRunV2ServiceScalingToHclTerraform(struct?: CloudRunV2ServiceScalingOutputReference | CloudRunV2ServiceScaling): any;
export declare class CloudRunV2ServiceScalingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceScaling | undefined;
    set internalValue(value: CloudRunV2ServiceScaling | undefined);
    private _manualInstanceCount?;
    get manualInstanceCount(): number;
    set manualInstanceCount(value: number);
    resetManualInstanceCount(): void;
    get manualInstanceCountInput(): number | undefined;
    private _maxInstanceCount?;
    get maxInstanceCount(): number;
    set maxInstanceCount(value: number);
    resetMaxInstanceCount(): void;
    get maxInstanceCountInput(): number | undefined;
    private _minInstanceCount?;
    get minInstanceCount(): number;
    set minInstanceCount(value: number);
    resetMinInstanceCount(): void;
    get minInstanceCountInput(): number | undefined;
    private _scalingMode?;
    get scalingMode(): string;
    set scalingMode(value: string);
    resetScalingMode(): void;
    get scalingModeInput(): string | undefined;
}
export interface CloudRunV2ServiceTemplateContainersBuildInfo {
}
export declare function cloudRunV2ServiceTemplateContainersBuildInfoToTerraform(struct?: CloudRunV2ServiceTemplateContainersBuildInfo): any;
export declare function cloudRunV2ServiceTemplateContainersBuildInfoToHclTerraform(struct?: CloudRunV2ServiceTemplateContainersBuildInfo): any;
export declare class CloudRunV2ServiceTemplateContainersBuildInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2ServiceTemplateContainersBuildInfo | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateContainersBuildInfo | undefined);
    get functionTarget(): string;
    get sourceLocation(): string;
}
export declare class CloudRunV2ServiceTemplateContainersBuildInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2ServiceTemplateContainersBuildInfoOutputReference;
}
export interface CloudRunV2ServiceTemplateContainersEnvValueSourceSecretKeyRef {
    /**
    * The name of the secret in Cloud Secret Manager. Format: {secretName} if the secret is in the same project. projects/{project}/secrets/{secretName} if the secret is in a different project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#secret CloudRunV2Service#secret}
    */
    readonly secret: string;
    /**
    * The Cloud Secret Manager secret version. Can be 'latest' for the latest value or an integer for a specific version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#version CloudRunV2Service#version}
    */
    readonly version?: string;
}
export declare function cloudRunV2ServiceTemplateContainersEnvValueSourceSecretKeyRefToTerraform(struct?: CloudRunV2ServiceTemplateContainersEnvValueSourceSecretKeyRefOutputReference | CloudRunV2ServiceTemplateContainersEnvValueSourceSecretKeyRef): any;
export declare function cloudRunV2ServiceTemplateContainersEnvValueSourceSecretKeyRefToHclTerraform(struct?: CloudRunV2ServiceTemplateContainersEnvValueSourceSecretKeyRefOutputReference | CloudRunV2ServiceTemplateContainersEnvValueSourceSecretKeyRef): any;
export declare class CloudRunV2ServiceTemplateContainersEnvValueSourceSecretKeyRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceTemplateContainersEnvValueSourceSecretKeyRef | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateContainersEnvValueSourceSecretKeyRef | undefined);
    private _secret?;
    get secret(): string;
    set secret(value: string);
    get secretInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export interface CloudRunV2ServiceTemplateContainersEnvValueSource {
    /**
    * secret_key_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#secret_key_ref CloudRunV2Service#secret_key_ref}
    */
    readonly secretKeyRef?: CloudRunV2ServiceTemplateContainersEnvValueSourceSecretKeyRef;
}
export declare function cloudRunV2ServiceTemplateContainersEnvValueSourceToTerraform(struct?: CloudRunV2ServiceTemplateContainersEnvValueSourceOutputReference | CloudRunV2ServiceTemplateContainersEnvValueSource): any;
export declare function cloudRunV2ServiceTemplateContainersEnvValueSourceToHclTerraform(struct?: CloudRunV2ServiceTemplateContainersEnvValueSourceOutputReference | CloudRunV2ServiceTemplateContainersEnvValueSource): any;
export declare class CloudRunV2ServiceTemplateContainersEnvValueSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceTemplateContainersEnvValueSource | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateContainersEnvValueSource | undefined);
    private _secretKeyRef;
    get secretKeyRef(): CloudRunV2ServiceTemplateContainersEnvValueSourceSecretKeyRefOutputReference;
    putSecretKeyRef(value: CloudRunV2ServiceTemplateContainersEnvValueSourceSecretKeyRef): void;
    resetSecretKeyRef(): void;
    get secretKeyRefInput(): CloudRunV2ServiceTemplateContainersEnvValueSourceSecretKeyRef | undefined;
}
export interface CloudRunV2ServiceTemplateContainersEnv {
    /**
    * Name of the environment variable. Must be a C_IDENTIFIER, and may not exceed 32768 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#name CloudRunV2Service#name}
    */
    readonly name: string;
    /**
    * Literal value of the environment variable. Defaults to "" and the maximum allowed length is 32768 characters. Variable references are not supported in Cloud Run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#value CloudRunV2Service#value}
    */
    readonly value?: string;
    /**
    * value_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#value_source CloudRunV2Service#value_source}
    */
    readonly valueSource?: CloudRunV2ServiceTemplateContainersEnvValueSource;
}
export declare function cloudRunV2ServiceTemplateContainersEnvToTerraform(struct?: CloudRunV2ServiceTemplateContainersEnv | cdktn.IResolvable): any;
export declare function cloudRunV2ServiceTemplateContainersEnvToHclTerraform(struct?: CloudRunV2ServiceTemplateContainersEnv | cdktn.IResolvable): any;
export declare class CloudRunV2ServiceTemplateContainersEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2ServiceTemplateContainersEnv | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateContainersEnv | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _valueSource;
    get valueSource(): CloudRunV2ServiceTemplateContainersEnvValueSourceOutputReference;
    putValueSource(value: CloudRunV2ServiceTemplateContainersEnvValueSource): void;
    resetValueSource(): void;
    get valueSourceInput(): CloudRunV2ServiceTemplateContainersEnvValueSource | undefined;
}
export declare class CloudRunV2ServiceTemplateContainersEnvList extends cdktn.ComplexList {
    internalValue?: CloudRunV2ServiceTemplateContainersEnv[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2ServiceTemplateContainersEnvOutputReference;
}
export interface CloudRunV2ServiceTemplateContainersLivenessProbeGrpc {
    /**
    * Port number to access on the container. Number must be in the range 1 to 65535.
    * If not specified, defaults to the same value as container.ports[0].containerPort.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#port CloudRunV2Service#port}
    */
    readonly port?: number;
    /**
    * The name of the service to place in the gRPC HealthCheckRequest
    * (see https://github.com/grpc/grpc/blob/master/doc/health-checking.md).
    * If this is not specified, the default behavior is defined by gRPC.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#service CloudRunV2Service#service}
    */
    readonly service?: string;
}
export declare function cloudRunV2ServiceTemplateContainersLivenessProbeGrpcToTerraform(struct?: CloudRunV2ServiceTemplateContainersLivenessProbeGrpcOutputReference | CloudRunV2ServiceTemplateContainersLivenessProbeGrpc): any;
export declare function cloudRunV2ServiceTemplateContainersLivenessProbeGrpcToHclTerraform(struct?: CloudRunV2ServiceTemplateContainersLivenessProbeGrpcOutputReference | CloudRunV2ServiceTemplateContainersLivenessProbeGrpc): any;
export declare class CloudRunV2ServiceTemplateContainersLivenessProbeGrpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceTemplateContainersLivenessProbeGrpc | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateContainersLivenessProbeGrpc | undefined);
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
}
export interface CloudRunV2ServiceTemplateContainersLivenessProbeHttpGetHttpHeaders {
    /**
    * The header field name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#name CloudRunV2Service#name}
    */
    readonly name: string;
    /**
    * The header field value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#value CloudRunV2Service#value}
    */
    readonly value?: string;
}
export declare function cloudRunV2ServiceTemplateContainersLivenessProbeHttpGetHttpHeadersToTerraform(struct?: CloudRunV2ServiceTemplateContainersLivenessProbeHttpGetHttpHeaders | cdktn.IResolvable): any;
export declare function cloudRunV2ServiceTemplateContainersLivenessProbeHttpGetHttpHeadersToHclTerraform(struct?: CloudRunV2ServiceTemplateContainersLivenessProbeHttpGetHttpHeaders | cdktn.IResolvable): any;
export declare class CloudRunV2ServiceTemplateContainersLivenessProbeHttpGetHttpHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2ServiceTemplateContainersLivenessProbeHttpGetHttpHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateContainersLivenessProbeHttpGetHttpHeaders | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudRunV2ServiceTemplateContainersLivenessProbeHttpGetHttpHeadersList extends cdktn.ComplexList {
    internalValue?: CloudRunV2ServiceTemplateContainersLivenessProbeHttpGetHttpHeaders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2ServiceTemplateContainersLivenessProbeHttpGetHttpHeadersOutputReference;
}
export interface CloudRunV2ServiceTemplateContainersLivenessProbeHttpGet {
    /**
    * Path to access on the HTTP server. Defaults to '/'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#path CloudRunV2Service#path}
    */
    readonly path?: string;
    /**
    * Port number to access on the container. Number must be in the range 1 to 65535.
    * If not specified, defaults to the same value as container.ports[0].containerPort.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#port CloudRunV2Service#port}
    */
    readonly port?: number;
    /**
    * http_headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#http_headers CloudRunV2Service#http_headers}
    */
    readonly httpHeaders?: CloudRunV2ServiceTemplateContainersLivenessProbeHttpGetHttpHeaders[] | cdktn.IResolvable;
}
export declare function cloudRunV2ServiceTemplateContainersLivenessProbeHttpGetToTerraform(struct?: CloudRunV2ServiceTemplateContainersLivenessProbeHttpGetOutputReference | CloudRunV2ServiceTemplateContainersLivenessProbeHttpGet): any;
export declare function cloudRunV2ServiceTemplateContainersLivenessProbeHttpGetToHclTerraform(struct?: CloudRunV2ServiceTemplateContainersLivenessProbeHttpGetOutputReference | CloudRunV2ServiceTemplateContainersLivenessProbeHttpGet): any;
export declare class CloudRunV2ServiceTemplateContainersLivenessProbeHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceTemplateContainersLivenessProbeHttpGet | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateContainersLivenessProbeHttpGet | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _httpHeaders;
    get httpHeaders(): CloudRunV2ServiceTemplateContainersLivenessProbeHttpGetHttpHeadersList;
    putHttpHeaders(value: CloudRunV2ServiceTemplateContainersLivenessProbeHttpGetHttpHeaders[] | cdktn.IResolvable): void;
    resetHttpHeaders(): void;
    get httpHeadersInput(): cdktn.IResolvable | CloudRunV2ServiceTemplateContainersLivenessProbeHttpGetHttpHeaders[] | undefined;
}
export interface CloudRunV2ServiceTemplateContainersLivenessProbeTcpSocket {
    /**
    * Port number to access on the container. Must be in the range 1 to 65535.
    * If not specified, defaults to the exposed port of the container, which
    * is the value of container.ports[0].containerPort.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#port CloudRunV2Service#port}
    */
    readonly port: number;
}
export declare function cloudRunV2ServiceTemplateContainersLivenessProbeTcpSocketToTerraform(struct?: CloudRunV2ServiceTemplateContainersLivenessProbeTcpSocketOutputReference | CloudRunV2ServiceTemplateContainersLivenessProbeTcpSocket): any;
export declare function cloudRunV2ServiceTemplateContainersLivenessProbeTcpSocketToHclTerraform(struct?: CloudRunV2ServiceTemplateContainersLivenessProbeTcpSocketOutputReference | CloudRunV2ServiceTemplateContainersLivenessProbeTcpSocket): any;
export declare class CloudRunV2ServiceTemplateContainersLivenessProbeTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceTemplateContainersLivenessProbeTcpSocket | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateContainersLivenessProbeTcpSocket | undefined);
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
}
export interface CloudRunV2ServiceTemplateContainersLivenessProbe {
    /**
    * Minimum consecutive failures for the probe to be considered failed after having succeeded. Defaults to 3. Minimum value is 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#failure_threshold CloudRunV2Service#failure_threshold}
    */
    readonly failureThreshold?: number;
    /**
    * Number of seconds after the container has started before the probe is initiated. Defaults to 0 seconds. Minimum value is 0. Maximum value for liveness probe is 3600. Maximum value for startup probe is 240. More info: https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle#container-probes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#initial_delay_seconds CloudRunV2Service#initial_delay_seconds}
    */
    readonly initialDelaySeconds?: number;
    /**
    * How often (in seconds) to perform the probe. Default to 10 seconds. Minimum value is 1. Maximum value for liveness probe is 3600. Maximum value for startup probe is 240. Must be greater or equal than timeoutSeconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#period_seconds CloudRunV2Service#period_seconds}
    */
    readonly periodSeconds?: number;
    /**
    * Number of seconds after which the probe times out. Defaults to 1 second. Minimum value is 1. Maximum value is 3600. Must be smaller than periodSeconds. More info: https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle#container-probes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#timeout_seconds CloudRunV2Service#timeout_seconds}
    */
    readonly timeoutSeconds?: number;
    /**
    * grpc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#grpc CloudRunV2Service#grpc}
    */
    readonly grpc?: CloudRunV2ServiceTemplateContainersLivenessProbeGrpc;
    /**
    * http_get block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#http_get CloudRunV2Service#http_get}
    */
    readonly httpGet?: CloudRunV2ServiceTemplateContainersLivenessProbeHttpGet;
    /**
    * tcp_socket block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#tcp_socket CloudRunV2Service#tcp_socket}
    */
    readonly tcpSocket?: CloudRunV2ServiceTemplateContainersLivenessProbeTcpSocket;
}
export declare function cloudRunV2ServiceTemplateContainersLivenessProbeToTerraform(struct?: CloudRunV2ServiceTemplateContainersLivenessProbeOutputReference | CloudRunV2ServiceTemplateContainersLivenessProbe): any;
export declare function cloudRunV2ServiceTemplateContainersLivenessProbeToHclTerraform(struct?: CloudRunV2ServiceTemplateContainersLivenessProbeOutputReference | CloudRunV2ServiceTemplateContainersLivenessProbe): any;
export declare class CloudRunV2ServiceTemplateContainersLivenessProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceTemplateContainersLivenessProbe | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateContainersLivenessProbe | undefined);
    private _failureThreshold?;
    get failureThreshold(): number;
    set failureThreshold(value: number);
    resetFailureThreshold(): void;
    get failureThresholdInput(): number | undefined;
    private _initialDelaySeconds?;
    get initialDelaySeconds(): number;
    set initialDelaySeconds(value: number);
    resetInitialDelaySeconds(): void;
    get initialDelaySecondsInput(): number | undefined;
    private _periodSeconds?;
    get periodSeconds(): number;
    set periodSeconds(value: number);
    resetPeriodSeconds(): void;
    get periodSecondsInput(): number | undefined;
    private _timeoutSeconds?;
    get timeoutSeconds(): number;
    set timeoutSeconds(value: number);
    resetTimeoutSeconds(): void;
    get timeoutSecondsInput(): number | undefined;
    private _grpc;
    get grpc(): CloudRunV2ServiceTemplateContainersLivenessProbeGrpcOutputReference;
    putGrpc(value: CloudRunV2ServiceTemplateContainersLivenessProbeGrpc): void;
    resetGrpc(): void;
    get grpcInput(): CloudRunV2ServiceTemplateContainersLivenessProbeGrpc | undefined;
    private _httpGet;
    get httpGet(): CloudRunV2ServiceTemplateContainersLivenessProbeHttpGetOutputReference;
    putHttpGet(value: CloudRunV2ServiceTemplateContainersLivenessProbeHttpGet): void;
    resetHttpGet(): void;
    get httpGetInput(): CloudRunV2ServiceTemplateContainersLivenessProbeHttpGet | undefined;
    private _tcpSocket;
    get tcpSocket(): CloudRunV2ServiceTemplateContainersLivenessProbeTcpSocketOutputReference;
    putTcpSocket(value: CloudRunV2ServiceTemplateContainersLivenessProbeTcpSocket): void;
    resetTcpSocket(): void;
    get tcpSocketInput(): CloudRunV2ServiceTemplateContainersLivenessProbeTcpSocket | undefined;
}
export interface CloudRunV2ServiceTemplateContainersPorts {
    /**
    * Port number the container listens on. This must be a valid TCP port number, 0 < containerPort < 65536.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#container_port CloudRunV2Service#container_port}
    */
    readonly containerPort?: number;
    /**
    * If specified, used to specify which protocol to use. Allowed values are "http1" and "h2c".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#name CloudRunV2Service#name}
    */
    readonly name?: string;
}
export declare function cloudRunV2ServiceTemplateContainersPortsToTerraform(struct?: CloudRunV2ServiceTemplateContainersPortsOutputReference | CloudRunV2ServiceTemplateContainersPorts): any;
export declare function cloudRunV2ServiceTemplateContainersPortsToHclTerraform(struct?: CloudRunV2ServiceTemplateContainersPortsOutputReference | CloudRunV2ServiceTemplateContainersPorts): any;
export declare class CloudRunV2ServiceTemplateContainersPortsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceTemplateContainersPorts | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateContainersPorts | undefined);
    private _containerPort?;
    get containerPort(): number;
    set containerPort(value: number);
    resetContainerPort(): void;
    get containerPortInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface CloudRunV2ServiceTemplateContainersReadinessProbeGrpc {
    /**
    * Port number to access on the container. Number must be in the range 1 to 65535.
    * If not specified, defaults to the same value as container.ports[0].containerPort.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#port CloudRunV2Service#port}
    */
    readonly port?: number;
    /**
    * The name of the service to place in the gRPC HealthCheckRequest
    * (see https://github.com/grpc/grpc/blob/master/doc/health-checking.md).
    * If this is not specified, the default behavior is defined by gRPC.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#service CloudRunV2Service#service}
    */
    readonly service?: string;
}
export declare function cloudRunV2ServiceTemplateContainersReadinessProbeGrpcToTerraform(struct?: CloudRunV2ServiceTemplateContainersReadinessProbeGrpcOutputReference | CloudRunV2ServiceTemplateContainersReadinessProbeGrpc): any;
export declare function cloudRunV2ServiceTemplateContainersReadinessProbeGrpcToHclTerraform(struct?: CloudRunV2ServiceTemplateContainersReadinessProbeGrpcOutputReference | CloudRunV2ServiceTemplateContainersReadinessProbeGrpc): any;
export declare class CloudRunV2ServiceTemplateContainersReadinessProbeGrpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceTemplateContainersReadinessProbeGrpc | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateContainersReadinessProbeGrpc | undefined);
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
}
export interface CloudRunV2ServiceTemplateContainersReadinessProbeHttpGet {
    /**
    * Path to access on the HTTP server. If set, it should not be empty string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#path CloudRunV2Service#path}
    */
    readonly path?: string;
    /**
    * Port number to access on the container. Number must be in the range 1 to 65535.
    * If not specified, defaults to the same value as container.ports[0].containerPort.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#port CloudRunV2Service#port}
    */
    readonly port?: number;
}
export declare function cloudRunV2ServiceTemplateContainersReadinessProbeHttpGetToTerraform(struct?: CloudRunV2ServiceTemplateContainersReadinessProbeHttpGetOutputReference | CloudRunV2ServiceTemplateContainersReadinessProbeHttpGet): any;
export declare function cloudRunV2ServiceTemplateContainersReadinessProbeHttpGetToHclTerraform(struct?: CloudRunV2ServiceTemplateContainersReadinessProbeHttpGetOutputReference | CloudRunV2ServiceTemplateContainersReadinessProbeHttpGet): any;
export declare class CloudRunV2ServiceTemplateContainersReadinessProbeHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceTemplateContainersReadinessProbeHttpGet | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateContainersReadinessProbeHttpGet | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
}
export interface CloudRunV2ServiceTemplateContainersReadinessProbe {
    /**
    * Minimum consecutive failures for the probe to be considered failed after
    * having succeeded. Defaults to 3.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#failure_threshold CloudRunV2Service#failure_threshold}
    */
    readonly failureThreshold?: number;
    /**
    * How often (in seconds) to perform the probe.
    * Default to 10 seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#period_seconds CloudRunV2Service#period_seconds}
    */
    readonly periodSeconds?: number;
    /**
    * Minimum consecutive successes for the probe to be considered successful after having failed.
    * Defaults to 2.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#success_threshold CloudRunV2Service#success_threshold}
    */
    readonly successThreshold?: number;
    /**
    * Number of seconds after which the probe times out.
    * Defaults to 1 second. Must be smaller than period_seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#timeout_seconds CloudRunV2Service#timeout_seconds}
    */
    readonly timeoutSeconds?: number;
    /**
    * grpc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#grpc CloudRunV2Service#grpc}
    */
    readonly grpc?: CloudRunV2ServiceTemplateContainersReadinessProbeGrpc;
    /**
    * http_get block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#http_get CloudRunV2Service#http_get}
    */
    readonly httpGet?: CloudRunV2ServiceTemplateContainersReadinessProbeHttpGet;
}
export declare function cloudRunV2ServiceTemplateContainersReadinessProbeToTerraform(struct?: CloudRunV2ServiceTemplateContainersReadinessProbeOutputReference | CloudRunV2ServiceTemplateContainersReadinessProbe): any;
export declare function cloudRunV2ServiceTemplateContainersReadinessProbeToHclTerraform(struct?: CloudRunV2ServiceTemplateContainersReadinessProbeOutputReference | CloudRunV2ServiceTemplateContainersReadinessProbe): any;
export declare class CloudRunV2ServiceTemplateContainersReadinessProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceTemplateContainersReadinessProbe | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateContainersReadinessProbe | undefined);
    private _failureThreshold?;
    get failureThreshold(): number;
    set failureThreshold(value: number);
    resetFailureThreshold(): void;
    get failureThresholdInput(): number | undefined;
    private _periodSeconds?;
    get periodSeconds(): number;
    set periodSeconds(value: number);
    resetPeriodSeconds(): void;
    get periodSecondsInput(): number | undefined;
    private _successThreshold?;
    get successThreshold(): number;
    set successThreshold(value: number);
    resetSuccessThreshold(): void;
    get successThresholdInput(): number | undefined;
    private _timeoutSeconds?;
    get timeoutSeconds(): number;
    set timeoutSeconds(value: number);
    resetTimeoutSeconds(): void;
    get timeoutSecondsInput(): number | undefined;
    private _grpc;
    get grpc(): CloudRunV2ServiceTemplateContainersReadinessProbeGrpcOutputReference;
    putGrpc(value: CloudRunV2ServiceTemplateContainersReadinessProbeGrpc): void;
    resetGrpc(): void;
    get grpcInput(): CloudRunV2ServiceTemplateContainersReadinessProbeGrpc | undefined;
    private _httpGet;
    get httpGet(): CloudRunV2ServiceTemplateContainersReadinessProbeHttpGetOutputReference;
    putHttpGet(value: CloudRunV2ServiceTemplateContainersReadinessProbeHttpGet): void;
    resetHttpGet(): void;
    get httpGetInput(): CloudRunV2ServiceTemplateContainersReadinessProbeHttpGet | undefined;
}
export interface CloudRunV2ServiceTemplateContainersResources {
    /**
    * Determines whether CPU is only allocated during requests. True by default if the parent 'resources' field is not set. However, if
    * 'resources' is set, this field must be explicitly set to true to preserve the default behavior.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#cpu_idle CloudRunV2Service#cpu_idle}
    */
    readonly cpuIdle?: boolean | cdktn.IResolvable;
    /**
    * Only memory, CPU, and nvidia.com/gpu are supported. Use key 'cpu' for CPU limit, 'memory' for memory limit, 'nvidia.com/gpu' for gpu limit. Note: The only supported values for CPU are '1', '2', '4', '6' and '8'. Setting 4 CPU requires at least 2Gi of memory, setting 6 or more CPU requires at least 4Gi of memory. The values of the map is string form of the 'quantity' k8s type: https://github.com/kubernetes/kubernetes/blob/master/staging/src/k8s.io/apimachinery/pkg/api/resource/quantity.go
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#limits CloudRunV2Service#limits}
    */
    readonly limits?: {
        [key: string]: string;
    };
    /**
    * Determines whether CPU should be boosted on startup of a new container instance above the requested CPU threshold, this can help reduce cold-start latency.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#startup_cpu_boost CloudRunV2Service#startup_cpu_boost}
    */
    readonly startupCpuBoost?: boolean | cdktn.IResolvable;
}
export declare function cloudRunV2ServiceTemplateContainersResourcesToTerraform(struct?: CloudRunV2ServiceTemplateContainersResourcesOutputReference | CloudRunV2ServiceTemplateContainersResources): any;
export declare function cloudRunV2ServiceTemplateContainersResourcesToHclTerraform(struct?: CloudRunV2ServiceTemplateContainersResourcesOutputReference | CloudRunV2ServiceTemplateContainersResources): any;
export declare class CloudRunV2ServiceTemplateContainersResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceTemplateContainersResources | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateContainersResources | undefined);
    private _cpuIdle?;
    get cpuIdle(): boolean | cdktn.IResolvable;
    set cpuIdle(value: boolean | cdktn.IResolvable);
    resetCpuIdle(): void;
    get cpuIdleInput(): boolean | cdktn.IResolvable | undefined;
    private _limits?;
    get limits(): {
        [key: string]: string;
    };
    set limits(value: {
        [key: string]: string;
    });
    resetLimits(): void;
    get limitsInput(): {
        [key: string]: string;
    } | undefined;
    private _startupCpuBoost?;
    get startupCpuBoost(): boolean | cdktn.IResolvable;
    set startupCpuBoost(value: boolean | cdktn.IResolvable);
    resetStartupCpuBoost(): void;
    get startupCpuBoostInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CloudRunV2ServiceTemplateContainersStartupProbeGrpc {
    /**
    * Port number to access on the container. Number must be in the range 1 to 65535.
    * If not specified, defaults to the same value as container.ports[0].containerPort.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#port CloudRunV2Service#port}
    */
    readonly port?: number;
    /**
    * The name of the service to place in the gRPC HealthCheckRequest
    * (see https://github.com/grpc/grpc/blob/master/doc/health-checking.md).
    * If this is not specified, the default behavior is defined by gRPC.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#service CloudRunV2Service#service}
    */
    readonly service?: string;
}
export declare function cloudRunV2ServiceTemplateContainersStartupProbeGrpcToTerraform(struct?: CloudRunV2ServiceTemplateContainersStartupProbeGrpcOutputReference | CloudRunV2ServiceTemplateContainersStartupProbeGrpc): any;
export declare function cloudRunV2ServiceTemplateContainersStartupProbeGrpcToHclTerraform(struct?: CloudRunV2ServiceTemplateContainersStartupProbeGrpcOutputReference | CloudRunV2ServiceTemplateContainersStartupProbeGrpc): any;
export declare class CloudRunV2ServiceTemplateContainersStartupProbeGrpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceTemplateContainersStartupProbeGrpc | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateContainersStartupProbeGrpc | undefined);
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
}
export interface CloudRunV2ServiceTemplateContainersStartupProbeHttpGetHttpHeaders {
    /**
    * The header field name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#name CloudRunV2Service#name}
    */
    readonly name: string;
    /**
    * The header field value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#value CloudRunV2Service#value}
    */
    readonly value?: string;
}
export declare function cloudRunV2ServiceTemplateContainersStartupProbeHttpGetHttpHeadersToTerraform(struct?: CloudRunV2ServiceTemplateContainersStartupProbeHttpGetHttpHeaders | cdktn.IResolvable): any;
export declare function cloudRunV2ServiceTemplateContainersStartupProbeHttpGetHttpHeadersToHclTerraform(struct?: CloudRunV2ServiceTemplateContainersStartupProbeHttpGetHttpHeaders | cdktn.IResolvable): any;
export declare class CloudRunV2ServiceTemplateContainersStartupProbeHttpGetHttpHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2ServiceTemplateContainersStartupProbeHttpGetHttpHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateContainersStartupProbeHttpGetHttpHeaders | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudRunV2ServiceTemplateContainersStartupProbeHttpGetHttpHeadersList extends cdktn.ComplexList {
    internalValue?: CloudRunV2ServiceTemplateContainersStartupProbeHttpGetHttpHeaders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2ServiceTemplateContainersStartupProbeHttpGetHttpHeadersOutputReference;
}
export interface CloudRunV2ServiceTemplateContainersStartupProbeHttpGet {
    /**
    * Path to access on the HTTP server. Defaults to '/'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#path CloudRunV2Service#path}
    */
    readonly path?: string;
    /**
    * Port number to access on the container. Must be in the range 1 to 65535.
    * If not specified, defaults to the same value as container.ports[0].containerPort.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#port CloudRunV2Service#port}
    */
    readonly port?: number;
    /**
    * http_headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#http_headers CloudRunV2Service#http_headers}
    */
    readonly httpHeaders?: CloudRunV2ServiceTemplateContainersStartupProbeHttpGetHttpHeaders[] | cdktn.IResolvable;
}
export declare function cloudRunV2ServiceTemplateContainersStartupProbeHttpGetToTerraform(struct?: CloudRunV2ServiceTemplateContainersStartupProbeHttpGetOutputReference | CloudRunV2ServiceTemplateContainersStartupProbeHttpGet): any;
export declare function cloudRunV2ServiceTemplateContainersStartupProbeHttpGetToHclTerraform(struct?: CloudRunV2ServiceTemplateContainersStartupProbeHttpGetOutputReference | CloudRunV2ServiceTemplateContainersStartupProbeHttpGet): any;
export declare class CloudRunV2ServiceTemplateContainersStartupProbeHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceTemplateContainersStartupProbeHttpGet | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateContainersStartupProbeHttpGet | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _httpHeaders;
    get httpHeaders(): CloudRunV2ServiceTemplateContainersStartupProbeHttpGetHttpHeadersList;
    putHttpHeaders(value: CloudRunV2ServiceTemplateContainersStartupProbeHttpGetHttpHeaders[] | cdktn.IResolvable): void;
    resetHttpHeaders(): void;
    get httpHeadersInput(): cdktn.IResolvable | CloudRunV2ServiceTemplateContainersStartupProbeHttpGetHttpHeaders[] | undefined;
}
export interface CloudRunV2ServiceTemplateContainersStartupProbeTcpSocket {
    /**
    * Port number to access on the container. Must be in the range 1 to 65535.
    * If not specified, defaults to the same value as container.ports[0].containerPort.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#port CloudRunV2Service#port}
    */
    readonly port?: number;
}
export declare function cloudRunV2ServiceTemplateContainersStartupProbeTcpSocketToTerraform(struct?: CloudRunV2ServiceTemplateContainersStartupProbeTcpSocketOutputReference | CloudRunV2ServiceTemplateContainersStartupProbeTcpSocket): any;
export declare function cloudRunV2ServiceTemplateContainersStartupProbeTcpSocketToHclTerraform(struct?: CloudRunV2ServiceTemplateContainersStartupProbeTcpSocketOutputReference | CloudRunV2ServiceTemplateContainersStartupProbeTcpSocket): any;
export declare class CloudRunV2ServiceTemplateContainersStartupProbeTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceTemplateContainersStartupProbeTcpSocket | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateContainersStartupProbeTcpSocket | undefined);
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
}
export interface CloudRunV2ServiceTemplateContainersStartupProbe {
    /**
    * Minimum consecutive failures for the probe to be considered failed after having succeeded. Defaults to 3. Minimum value is 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#failure_threshold CloudRunV2Service#failure_threshold}
    */
    readonly failureThreshold?: number;
    /**
    * Number of seconds after the container has started before the probe is initiated. Defaults to 0 seconds. Minimum value is 0. Maximum value for liveness probe is 3600. Maximum value for startup probe is 240. More info: https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle#container-probes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#initial_delay_seconds CloudRunV2Service#initial_delay_seconds}
    */
    readonly initialDelaySeconds?: number;
    /**
    * How often (in seconds) to perform the probe. Default to 10 seconds. Minimum value is 1. Maximum value for liveness probe is 3600. Maximum value for startup probe is 240. Must be greater or equal than timeoutSeconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#period_seconds CloudRunV2Service#period_seconds}
    */
    readonly periodSeconds?: number;
    /**
    * Number of seconds after which the probe times out. Defaults to 1 second. Minimum value is 1. Maximum value is 3600. Must be smaller than periodSeconds. More info: https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle#container-probes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#timeout_seconds CloudRunV2Service#timeout_seconds}
    */
    readonly timeoutSeconds?: number;
    /**
    * grpc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#grpc CloudRunV2Service#grpc}
    */
    readonly grpc?: CloudRunV2ServiceTemplateContainersStartupProbeGrpc;
    /**
    * http_get block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#http_get CloudRunV2Service#http_get}
    */
    readonly httpGet?: CloudRunV2ServiceTemplateContainersStartupProbeHttpGet;
    /**
    * tcp_socket block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#tcp_socket CloudRunV2Service#tcp_socket}
    */
    readonly tcpSocket?: CloudRunV2ServiceTemplateContainersStartupProbeTcpSocket;
}
export declare function cloudRunV2ServiceTemplateContainersStartupProbeToTerraform(struct?: CloudRunV2ServiceTemplateContainersStartupProbeOutputReference | CloudRunV2ServiceTemplateContainersStartupProbe): any;
export declare function cloudRunV2ServiceTemplateContainersStartupProbeToHclTerraform(struct?: CloudRunV2ServiceTemplateContainersStartupProbeOutputReference | CloudRunV2ServiceTemplateContainersStartupProbe): any;
export declare class CloudRunV2ServiceTemplateContainersStartupProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceTemplateContainersStartupProbe | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateContainersStartupProbe | undefined);
    private _failureThreshold?;
    get failureThreshold(): number;
    set failureThreshold(value: number);
    resetFailureThreshold(): void;
    get failureThresholdInput(): number | undefined;
    private _initialDelaySeconds?;
    get initialDelaySeconds(): number;
    set initialDelaySeconds(value: number);
    resetInitialDelaySeconds(): void;
    get initialDelaySecondsInput(): number | undefined;
    private _periodSeconds?;
    get periodSeconds(): number;
    set periodSeconds(value: number);
    resetPeriodSeconds(): void;
    get periodSecondsInput(): number | undefined;
    private _timeoutSeconds?;
    get timeoutSeconds(): number;
    set timeoutSeconds(value: number);
    resetTimeoutSeconds(): void;
    get timeoutSecondsInput(): number | undefined;
    private _grpc;
    get grpc(): CloudRunV2ServiceTemplateContainersStartupProbeGrpcOutputReference;
    putGrpc(value: CloudRunV2ServiceTemplateContainersStartupProbeGrpc): void;
    resetGrpc(): void;
    get grpcInput(): CloudRunV2ServiceTemplateContainersStartupProbeGrpc | undefined;
    private _httpGet;
    get httpGet(): CloudRunV2ServiceTemplateContainersStartupProbeHttpGetOutputReference;
    putHttpGet(value: CloudRunV2ServiceTemplateContainersStartupProbeHttpGet): void;
    resetHttpGet(): void;
    get httpGetInput(): CloudRunV2ServiceTemplateContainersStartupProbeHttpGet | undefined;
    private _tcpSocket;
    get tcpSocket(): CloudRunV2ServiceTemplateContainersStartupProbeTcpSocketOutputReference;
    putTcpSocket(value: CloudRunV2ServiceTemplateContainersStartupProbeTcpSocket): void;
    resetTcpSocket(): void;
    get tcpSocketInput(): CloudRunV2ServiceTemplateContainersStartupProbeTcpSocket | undefined;
}
export interface CloudRunV2ServiceTemplateContainersVolumeMounts {
    /**
    * Path within the container at which the volume should be mounted. Must not contain ':'. For Cloud SQL volumes, it can be left empty, or must otherwise be /cloudsql. All instances defined in the Volume will be available as /cloudsql/[instance]. For more information on Cloud SQL volumes, visit https://cloud.google.com/sql/docs/mysql/connect-run
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#mount_path CloudRunV2Service#mount_path}
    */
    readonly mountPath: string;
    /**
    * This must match the Name of a Volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#name CloudRunV2Service#name}
    */
    readonly name: string;
    /**
    * Path within the volume from which the container's volume should be mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#sub_path CloudRunV2Service#sub_path}
    */
    readonly subPath?: string;
}
export declare function cloudRunV2ServiceTemplateContainersVolumeMountsToTerraform(struct?: CloudRunV2ServiceTemplateContainersVolumeMounts | cdktn.IResolvable): any;
export declare function cloudRunV2ServiceTemplateContainersVolumeMountsToHclTerraform(struct?: CloudRunV2ServiceTemplateContainersVolumeMounts | cdktn.IResolvable): any;
export declare class CloudRunV2ServiceTemplateContainersVolumeMountsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2ServiceTemplateContainersVolumeMounts | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateContainersVolumeMounts | cdktn.IResolvable | undefined);
    private _mountPath?;
    get mountPath(): string;
    set mountPath(value: string);
    get mountPathInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _subPath?;
    get subPath(): string;
    set subPath(value: string);
    resetSubPath(): void;
    get subPathInput(): string | undefined;
}
export declare class CloudRunV2ServiceTemplateContainersVolumeMountsList extends cdktn.ComplexList {
    internalValue?: CloudRunV2ServiceTemplateContainersVolumeMounts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2ServiceTemplateContainersVolumeMountsOutputReference;
}
export interface CloudRunV2ServiceTemplateContainers {
    /**
    * Arguments to the entrypoint. The docker image's CMD is used if this is not provided. Variable references are not supported in Cloud Run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#args CloudRunV2Service#args}
    */
    readonly args?: string[];
    /**
    * Base image for this container. If set, it indicates that the service is enrolled into automatic base image update.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#base_image_uri CloudRunV2Service#base_image_uri}
    */
    readonly baseImageUri?: string;
    /**
    * Entrypoint array. Not executed within a shell. The docker image's ENTRYPOINT is used if this is not provided. Variable references $(VAR_NAME) are expanded using the container's environment. If a variable cannot be resolved, the reference in the input string will be unchanged. The $(VAR_NAME) syntax can be escaped with a double $$, ie: $$(VAR_NAME). Escaped references will never be expanded, regardless of whether the variable exists or not. More info: https://kubernetes.io/docs/tasks/inject-data-application/define-command-argument-container/#running-a-command-in-a-shell
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#command CloudRunV2Service#command}
    */
    readonly command?: string[];
    /**
    * Containers which should be started before this container. If specified the container will wait to start until all containers with the listed names are healthy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#depends_on CloudRunV2Service#depends_on}
    */
    readonly dependsOn?: string[];
    /**
    * URL of the Container image in Google Container Registry or Google Artifact Registry. More info: https://kubernetes.io/docs/concepts/containers/images
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#image CloudRunV2Service#image}
    */
    readonly image: string;
    /**
    * Name of the container specified as a DNS_LABEL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#name CloudRunV2Service#name}
    */
    readonly name?: string;
    /**
    * Indicates that this container can act as a sandbox supervisor and launch sandboxes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#sandbox_launcher CloudRunV2Service#sandbox_launcher}
    */
    readonly sandboxLauncher?: boolean | cdktn.IResolvable;
    /**
    * Container's working directory. If not specified, the container runtime's default will be used, which might be configured in the container image.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#working_dir CloudRunV2Service#working_dir}
    */
    readonly workingDir?: string;
    /**
    * env block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#env CloudRunV2Service#env}
    */
    readonly env?: CloudRunV2ServiceTemplateContainersEnv[] | cdktn.IResolvable;
    /**
    * liveness_probe block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#liveness_probe CloudRunV2Service#liveness_probe}
    */
    readonly livenessProbe?: CloudRunV2ServiceTemplateContainersLivenessProbe;
    /**
    * ports block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#ports CloudRunV2Service#ports}
    */
    readonly ports?: CloudRunV2ServiceTemplateContainersPorts;
    /**
    * readiness_probe block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#readiness_probe CloudRunV2Service#readiness_probe}
    */
    readonly readinessProbe?: CloudRunV2ServiceTemplateContainersReadinessProbe;
    /**
    * resources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#resources CloudRunV2Service#resources}
    */
    readonly resources?: CloudRunV2ServiceTemplateContainersResources;
    /**
    * startup_probe block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#startup_probe CloudRunV2Service#startup_probe}
    */
    readonly startupProbe?: CloudRunV2ServiceTemplateContainersStartupProbe;
    /**
    * volume_mounts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#volume_mounts CloudRunV2Service#volume_mounts}
    */
    readonly volumeMounts?: CloudRunV2ServiceTemplateContainersVolumeMounts[] | cdktn.IResolvable;
}
export declare function cloudRunV2ServiceTemplateContainersToTerraform(struct?: CloudRunV2ServiceTemplateContainers | cdktn.IResolvable): any;
export declare function cloudRunV2ServiceTemplateContainersToHclTerraform(struct?: CloudRunV2ServiceTemplateContainers | cdktn.IResolvable): any;
export declare class CloudRunV2ServiceTemplateContainersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2ServiceTemplateContainers | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateContainers | cdktn.IResolvable | undefined);
    private _args?;
    get args(): string[];
    set args(value: string[]);
    resetArgs(): void;
    get argsInput(): string[] | undefined;
    private _baseImageUri?;
    get baseImageUri(): string;
    set baseImageUri(value: string);
    resetBaseImageUri(): void;
    get baseImageUriInput(): string | undefined;
    private _buildInfo;
    get buildInfo(): CloudRunV2ServiceTemplateContainersBuildInfoList;
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
    private _dependsOn?;
    get dependsOn(): string[];
    set dependsOn(value: string[]);
    resetDependsOn(): void;
    get dependsOnInput(): string[] | undefined;
    private _image?;
    get image(): string;
    set image(value: string);
    get imageInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sandboxLauncher?;
    get sandboxLauncher(): boolean | cdktn.IResolvable;
    set sandboxLauncher(value: boolean | cdktn.IResolvable);
    resetSandboxLauncher(): void;
    get sandboxLauncherInput(): boolean | cdktn.IResolvable | undefined;
    private _workingDir?;
    get workingDir(): string;
    set workingDir(value: string);
    resetWorkingDir(): void;
    get workingDirInput(): string | undefined;
    private _env;
    get env(): CloudRunV2ServiceTemplateContainersEnvList;
    putEnv(value: CloudRunV2ServiceTemplateContainersEnv[] | cdktn.IResolvable): void;
    resetEnv(): void;
    get envInput(): cdktn.IResolvable | CloudRunV2ServiceTemplateContainersEnv[] | undefined;
    private _livenessProbe;
    get livenessProbe(): CloudRunV2ServiceTemplateContainersLivenessProbeOutputReference;
    putLivenessProbe(value: CloudRunV2ServiceTemplateContainersLivenessProbe): void;
    resetLivenessProbe(): void;
    get livenessProbeInput(): CloudRunV2ServiceTemplateContainersLivenessProbe | undefined;
    private _ports;
    get ports(): CloudRunV2ServiceTemplateContainersPortsOutputReference;
    putPorts(value: CloudRunV2ServiceTemplateContainersPorts): void;
    resetPorts(): void;
    get portsInput(): CloudRunV2ServiceTemplateContainersPorts | undefined;
    private _readinessProbe;
    get readinessProbe(): CloudRunV2ServiceTemplateContainersReadinessProbeOutputReference;
    putReadinessProbe(value: CloudRunV2ServiceTemplateContainersReadinessProbe): void;
    resetReadinessProbe(): void;
    get readinessProbeInput(): CloudRunV2ServiceTemplateContainersReadinessProbe | undefined;
    private _resources;
    get resources(): CloudRunV2ServiceTemplateContainersResourcesOutputReference;
    putResources(value: CloudRunV2ServiceTemplateContainersResources): void;
    resetResources(): void;
    get resourcesInput(): CloudRunV2ServiceTemplateContainersResources | undefined;
    private _startupProbe;
    get startupProbe(): CloudRunV2ServiceTemplateContainersStartupProbeOutputReference;
    putStartupProbe(value: CloudRunV2ServiceTemplateContainersStartupProbe): void;
    resetStartupProbe(): void;
    get startupProbeInput(): CloudRunV2ServiceTemplateContainersStartupProbe | undefined;
    private _volumeMounts;
    get volumeMounts(): CloudRunV2ServiceTemplateContainersVolumeMountsList;
    putVolumeMounts(value: CloudRunV2ServiceTemplateContainersVolumeMounts[] | cdktn.IResolvable): void;
    resetVolumeMounts(): void;
    get volumeMountsInput(): cdktn.IResolvable | CloudRunV2ServiceTemplateContainersVolumeMounts[] | undefined;
}
export declare class CloudRunV2ServiceTemplateContainersList extends cdktn.ComplexList {
    internalValue?: CloudRunV2ServiceTemplateContainers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2ServiceTemplateContainersOutputReference;
}
export interface CloudRunV2ServiceTemplateNodeSelector {
    /**
    * The GPU to attach to an instance. See https://cloud.google.com/run/docs/configuring/services/gpu for configuring GPU.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#accelerator CloudRunV2Service#accelerator}
    */
    readonly accelerator: string;
}
export declare function cloudRunV2ServiceTemplateNodeSelectorToTerraform(struct?: CloudRunV2ServiceTemplateNodeSelectorOutputReference | CloudRunV2ServiceTemplateNodeSelector): any;
export declare function cloudRunV2ServiceTemplateNodeSelectorToHclTerraform(struct?: CloudRunV2ServiceTemplateNodeSelectorOutputReference | CloudRunV2ServiceTemplateNodeSelector): any;
export declare class CloudRunV2ServiceTemplateNodeSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceTemplateNodeSelector | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateNodeSelector | undefined);
    private _accelerator?;
    get accelerator(): string;
    set accelerator(value: string);
    get acceleratorInput(): string | undefined;
}
export interface CloudRunV2ServiceTemplateSandboxesTemplatesEnv {
    /**
    * Name of the environment variable. Must be a C_IDENTIFIER, and may not exceed 32768 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#name CloudRunV2Service#name}
    */
    readonly name: string;
    /**
    * Literal value of the environment variable. Defaults to "" and the maximum allowed length is 32768 characters. Variable references are not supported in Cloud Run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#value CloudRunV2Service#value}
    */
    readonly value?: string;
}
export declare function cloudRunV2ServiceTemplateSandboxesTemplatesEnvToTerraform(struct?: CloudRunV2ServiceTemplateSandboxesTemplatesEnv | cdktn.IResolvable): any;
export declare function cloudRunV2ServiceTemplateSandboxesTemplatesEnvToHclTerraform(struct?: CloudRunV2ServiceTemplateSandboxesTemplatesEnv | cdktn.IResolvable): any;
export declare class CloudRunV2ServiceTemplateSandboxesTemplatesEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2ServiceTemplateSandboxesTemplatesEnv | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateSandboxesTemplatesEnv | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudRunV2ServiceTemplateSandboxesTemplatesEnvList extends cdktn.ComplexList {
    internalValue?: CloudRunV2ServiceTemplateSandboxesTemplatesEnv[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2ServiceTemplateSandboxesTemplatesEnvOutputReference;
}
export interface CloudRunV2ServiceTemplateSandboxesTemplatesVolumeMounts {
    /**
    * Path within the container at which the volume should be mounted. Must not contain ':'. For Cloud SQL volumes, it can be left empty, or must otherwise be /cloudsql. All instances defined in the Volume will be available as /cloudsql/[instance]. For more information on Cloud SQL volumes, visit https://cloud.google.com/sql/docs/mysql/connect-run
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#mount_path CloudRunV2Service#mount_path}
    */
    readonly mountPath: string;
    /**
    * This must match the Name of a Volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#name CloudRunV2Service#name}
    */
    readonly name: string;
    /**
    * Path within the volume from which the container's volume should be mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#sub_path CloudRunV2Service#sub_path}
    */
    readonly subPath?: string;
}
export declare function cloudRunV2ServiceTemplateSandboxesTemplatesVolumeMountsToTerraform(struct?: CloudRunV2ServiceTemplateSandboxesTemplatesVolumeMounts | cdktn.IResolvable): any;
export declare function cloudRunV2ServiceTemplateSandboxesTemplatesVolumeMountsToHclTerraform(struct?: CloudRunV2ServiceTemplateSandboxesTemplatesVolumeMounts | cdktn.IResolvable): any;
export declare class CloudRunV2ServiceTemplateSandboxesTemplatesVolumeMountsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2ServiceTemplateSandboxesTemplatesVolumeMounts | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateSandboxesTemplatesVolumeMounts | cdktn.IResolvable | undefined);
    private _mountPath?;
    get mountPath(): string;
    set mountPath(value: string);
    get mountPathInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _subPath?;
    get subPath(): string;
    set subPath(value: string);
    resetSubPath(): void;
    get subPathInput(): string | undefined;
}
export declare class CloudRunV2ServiceTemplateSandboxesTemplatesVolumeMountsList extends cdktn.ComplexList {
    internalValue?: CloudRunV2ServiceTemplateSandboxesTemplatesVolumeMounts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2ServiceTemplateSandboxesTemplatesVolumeMountsOutputReference;
}
export interface CloudRunV2ServiceTemplateSandboxesTemplates {
    /**
    * Arguments to the entrypoint. The docker image's CMD is used if this is not provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#args CloudRunV2Service#args}
    */
    readonly args?: string[];
    /**
    * Entrypoint array. Not executed within a shell. The docker image's ENTRYPOINT is used if this is not provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#command CloudRunV2Service#command}
    */
    readonly command?: string[];
    /**
    * Name of the container image in Dockerhub or Artifact Registry. If the host is not provided, Dockerhub is assumed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#image CloudRunV2Service#image}
    */
    readonly image: string;
    /**
    * Name of the sandbox specified as a DNS_LABEL (RFC 1123).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#name CloudRunV2Service#name}
    */
    readonly name: string;
    /**
    * Container's working directory. If not specified, the container runtime's default will be used, which might be configured in the container image.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#working_dir CloudRunV2Service#working_dir}
    */
    readonly workingDir?: string;
    /**
    * env block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#env CloudRunV2Service#env}
    */
    readonly env?: CloudRunV2ServiceTemplateSandboxesTemplatesEnv[] | cdktn.IResolvable;
    /**
    * volume_mounts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#volume_mounts CloudRunV2Service#volume_mounts}
    */
    readonly volumeMounts?: CloudRunV2ServiceTemplateSandboxesTemplatesVolumeMounts[] | cdktn.IResolvable;
}
export declare function cloudRunV2ServiceTemplateSandboxesTemplatesToTerraform(struct?: CloudRunV2ServiceTemplateSandboxesTemplates | cdktn.IResolvable): any;
export declare function cloudRunV2ServiceTemplateSandboxesTemplatesToHclTerraform(struct?: CloudRunV2ServiceTemplateSandboxesTemplates | cdktn.IResolvable): any;
export declare class CloudRunV2ServiceTemplateSandboxesTemplatesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2ServiceTemplateSandboxesTemplates | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateSandboxesTemplates | cdktn.IResolvable | undefined);
    private _args?;
    get args(): string[];
    set args(value: string[]);
    resetArgs(): void;
    get argsInput(): string[] | undefined;
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
    private _image?;
    get image(): string;
    set image(value: string);
    get imageInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _workingDir?;
    get workingDir(): string;
    set workingDir(value: string);
    resetWorkingDir(): void;
    get workingDirInput(): string | undefined;
    private _env;
    get env(): CloudRunV2ServiceTemplateSandboxesTemplatesEnvList;
    putEnv(value: CloudRunV2ServiceTemplateSandboxesTemplatesEnv[] | cdktn.IResolvable): void;
    resetEnv(): void;
    get envInput(): cdktn.IResolvable | CloudRunV2ServiceTemplateSandboxesTemplatesEnv[] | undefined;
    private _volumeMounts;
    get volumeMounts(): CloudRunV2ServiceTemplateSandboxesTemplatesVolumeMountsList;
    putVolumeMounts(value: CloudRunV2ServiceTemplateSandboxesTemplatesVolumeMounts[] | cdktn.IResolvable): void;
    resetVolumeMounts(): void;
    get volumeMountsInput(): cdktn.IResolvable | CloudRunV2ServiceTemplateSandboxesTemplatesVolumeMounts[] | undefined;
}
export declare class CloudRunV2ServiceTemplateSandboxesTemplatesList extends cdktn.ComplexList {
    internalValue?: CloudRunV2ServiceTemplateSandboxesTemplates[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2ServiceTemplateSandboxesTemplatesOutputReference;
}
export interface CloudRunV2ServiceTemplateSandboxes {
    /**
    * templates block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#templates CloudRunV2Service#templates}
    */
    readonly templates?: CloudRunV2ServiceTemplateSandboxesTemplates[] | cdktn.IResolvable;
}
export declare function cloudRunV2ServiceTemplateSandboxesToTerraform(struct?: CloudRunV2ServiceTemplateSandboxesOutputReference | CloudRunV2ServiceTemplateSandboxes): any;
export declare function cloudRunV2ServiceTemplateSandboxesToHclTerraform(struct?: CloudRunV2ServiceTemplateSandboxesOutputReference | CloudRunV2ServiceTemplateSandboxes): any;
export declare class CloudRunV2ServiceTemplateSandboxesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceTemplateSandboxes | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateSandboxes | undefined);
    private _templates;
    get templates(): CloudRunV2ServiceTemplateSandboxesTemplatesList;
    putTemplates(value: CloudRunV2ServiceTemplateSandboxesTemplates[] | cdktn.IResolvable): void;
    resetTemplates(): void;
    get templatesInput(): cdktn.IResolvable | CloudRunV2ServiceTemplateSandboxesTemplates[] | undefined;
}
export interface CloudRunV2ServiceTemplateScaling {
    /**
    * Determines a threshold for concurrency utilization before scaling begins. Accepted values are between 0.1 and 0.95 (inclusive) or 0.0 to disable concurrency utilization as threshold for scaling. CPU and concurrency scaling cannot both be disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#concurrency_utilization CloudRunV2Service#concurrency_utilization}
    */
    readonly concurrencyUtilization?: number;
    /**
    * Determines a threshold for CPU utilization before scaling begins. Accepted values are between 0.1 and 0.95 (inclusive) or 0.0 to disable CPU utilization as threshold for scaling. CPU and concurrency scaling cannot both be disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#cpu_utilization CloudRunV2Service#cpu_utilization}
    */
    readonly cpuUtilization?: number;
    /**
    * Maximum number of serving instances that this resource should have. Must not be less than minimum instance count. If absent, Cloud Run will calculate
    * a default value based on the project's available container instances quota in the region and specified instance size.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#max_instance_count CloudRunV2Service#max_instance_count}
    */
    readonly maxInstanceCount?: number;
    /**
    * Minimum number of serving instances that this resource should have. Defaults to 0. Must not be greater than maximum instance count.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#min_instance_count CloudRunV2Service#min_instance_count}
    */
    readonly minInstanceCount?: number;
}
export declare function cloudRunV2ServiceTemplateScalingToTerraform(struct?: CloudRunV2ServiceTemplateScalingOutputReference | CloudRunV2ServiceTemplateScaling): any;
export declare function cloudRunV2ServiceTemplateScalingToHclTerraform(struct?: CloudRunV2ServiceTemplateScalingOutputReference | CloudRunV2ServiceTemplateScaling): any;
export declare class CloudRunV2ServiceTemplateScalingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceTemplateScaling | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateScaling | undefined);
    private _concurrencyUtilization?;
    get concurrencyUtilization(): number;
    set concurrencyUtilization(value: number);
    resetConcurrencyUtilization(): void;
    get concurrencyUtilizationInput(): number | undefined;
    private _cpuUtilization?;
    get cpuUtilization(): number;
    set cpuUtilization(value: number);
    resetCpuUtilization(): void;
    get cpuUtilizationInput(): number | undefined;
    private _maxInstanceCount?;
    get maxInstanceCount(): number;
    set maxInstanceCount(value: number);
    resetMaxInstanceCount(): void;
    get maxInstanceCountInput(): number | undefined;
    private _minInstanceCount?;
    get minInstanceCount(): number;
    set minInstanceCount(value: number);
    resetMinInstanceCount(): void;
    get minInstanceCountInput(): number | undefined;
}
export interface CloudRunV2ServiceTemplateVolumesCloudSqlInstance {
    /**
    * The Cloud SQL instance connection names, as can be found in https://console.cloud.google.com/sql/instances. Visit https://cloud.google.com/sql/docs/mysql/connect-run for more information on how to connect Cloud SQL and Cloud Run. Format: {project}:{location}:{instance}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#instances CloudRunV2Service#instances}
    */
    readonly instances?: string[];
}
export declare function cloudRunV2ServiceTemplateVolumesCloudSqlInstanceToTerraform(struct?: CloudRunV2ServiceTemplateVolumesCloudSqlInstanceOutputReference | CloudRunV2ServiceTemplateVolumesCloudSqlInstance): any;
export declare function cloudRunV2ServiceTemplateVolumesCloudSqlInstanceToHclTerraform(struct?: CloudRunV2ServiceTemplateVolumesCloudSqlInstanceOutputReference | CloudRunV2ServiceTemplateVolumesCloudSqlInstance): any;
export declare class CloudRunV2ServiceTemplateVolumesCloudSqlInstanceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceTemplateVolumesCloudSqlInstance | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateVolumesCloudSqlInstance | undefined);
    private _instances?;
    get instances(): string[];
    set instances(value: string[]);
    resetInstances(): void;
    get instancesInput(): string[] | undefined;
}
export interface CloudRunV2ServiceTemplateVolumesEmptyDir {
    /**
    * The different types of medium supported for EmptyDir. Default value: "MEMORY" Possible values: ["MEMORY", "DISK"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#medium CloudRunV2Service#medium}
    */
    readonly medium?: string;
    /**
    * Limit on the storage usable by this EmptyDir volume. The size limit is also applicable for memory medium. The maximum usage on memory medium EmptyDir would be the minimum value between the SizeLimit specified here and the sum of memory limits of all containers in a pod. This field's values are of the 'Quantity' k8s type: https://kubernetes.io/docs/reference/kubernetes-api/common-definitions/quantity/. The default is nil which means that the limit is undefined. More info: https://kubernetes.io/docs/concepts/storage/volumes/#emptydir.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#size_limit CloudRunV2Service#size_limit}
    */
    readonly sizeLimit?: string;
}
export declare function cloudRunV2ServiceTemplateVolumesEmptyDirToTerraform(struct?: CloudRunV2ServiceTemplateVolumesEmptyDirOutputReference | CloudRunV2ServiceTemplateVolumesEmptyDir): any;
export declare function cloudRunV2ServiceTemplateVolumesEmptyDirToHclTerraform(struct?: CloudRunV2ServiceTemplateVolumesEmptyDirOutputReference | CloudRunV2ServiceTemplateVolumesEmptyDir): any;
export declare class CloudRunV2ServiceTemplateVolumesEmptyDirOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceTemplateVolumesEmptyDir | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateVolumesEmptyDir | undefined);
    private _medium?;
    get medium(): string;
    set medium(value: string);
    resetMedium(): void;
    get mediumInput(): string | undefined;
    private _sizeLimit?;
    get sizeLimit(): string;
    set sizeLimit(value: string);
    resetSizeLimit(): void;
    get sizeLimitInput(): string | undefined;
}
export interface CloudRunV2ServiceTemplateVolumesGcs {
    /**
    * GCS Bucket name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#bucket CloudRunV2Service#bucket}
    */
    readonly bucket: string;
    /**
    * A list of flags to pass to the gcsfuse command for configuring this volume.
    * Flags should be passed without leading dashes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#mount_options CloudRunV2Service#mount_options}
    */
    readonly mountOptions?: string[];
    /**
    * If true, mount the GCS bucket as read-only
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#read_only CloudRunV2Service#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
}
export declare function cloudRunV2ServiceTemplateVolumesGcsToTerraform(struct?: CloudRunV2ServiceTemplateVolumesGcsOutputReference | CloudRunV2ServiceTemplateVolumesGcs): any;
export declare function cloudRunV2ServiceTemplateVolumesGcsToHclTerraform(struct?: CloudRunV2ServiceTemplateVolumesGcsOutputReference | CloudRunV2ServiceTemplateVolumesGcs): any;
export declare class CloudRunV2ServiceTemplateVolumesGcsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceTemplateVolumesGcs | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateVolumesGcs | undefined);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _mountOptions?;
    get mountOptions(): string[];
    set mountOptions(value: string[]);
    resetMountOptions(): void;
    get mountOptionsInput(): string[] | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CloudRunV2ServiceTemplateVolumesNfs {
    /**
    * Path that is exported by the NFS server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#path CloudRunV2Service#path}
    */
    readonly path: string;
    /**
    * If true, mount the NFS volume as read only
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#read_only CloudRunV2Service#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Hostname or IP address of the NFS server
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#server CloudRunV2Service#server}
    */
    readonly server: string;
}
export declare function cloudRunV2ServiceTemplateVolumesNfsToTerraform(struct?: CloudRunV2ServiceTemplateVolumesNfsOutputReference | CloudRunV2ServiceTemplateVolumesNfs): any;
export declare function cloudRunV2ServiceTemplateVolumesNfsToHclTerraform(struct?: CloudRunV2ServiceTemplateVolumesNfsOutputReference | CloudRunV2ServiceTemplateVolumesNfs): any;
export declare class CloudRunV2ServiceTemplateVolumesNfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceTemplateVolumesNfs | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateVolumesNfs | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _server?;
    get server(): string;
    set server(value: string);
    get serverInput(): string | undefined;
}
export interface CloudRunV2ServiceTemplateVolumesSecretItems {
    /**
    * Integer octal mode bits to use on this file, must be a value between 01 and 0777 (octal). If 0 or not set, the Volume's default mode will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#mode CloudRunV2Service#mode}
    */
    readonly mode?: number;
    /**
    * The relative path of the secret in the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#path CloudRunV2Service#path}
    */
    readonly path: string;
    /**
    * The Cloud Secret Manager secret version. Can be 'latest' for the latest value or an integer for a specific version
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#version CloudRunV2Service#version}
    */
    readonly version?: string;
}
export declare function cloudRunV2ServiceTemplateVolumesSecretItemsToTerraform(struct?: CloudRunV2ServiceTemplateVolumesSecretItems | cdktn.IResolvable): any;
export declare function cloudRunV2ServiceTemplateVolumesSecretItemsToHclTerraform(struct?: CloudRunV2ServiceTemplateVolumesSecretItems | cdktn.IResolvable): any;
export declare class CloudRunV2ServiceTemplateVolumesSecretItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2ServiceTemplateVolumesSecretItems | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateVolumesSecretItems | cdktn.IResolvable | undefined);
    private _mode?;
    get mode(): number;
    set mode(value: number);
    resetMode(): void;
    get modeInput(): number | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export declare class CloudRunV2ServiceTemplateVolumesSecretItemsList extends cdktn.ComplexList {
    internalValue?: CloudRunV2ServiceTemplateVolumesSecretItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2ServiceTemplateVolumesSecretItemsOutputReference;
}
export interface CloudRunV2ServiceTemplateVolumesSecret {
    /**
    * Integer representation of mode bits to use on created files by default. Must be a value between 0000 and 0777 (octal), defaulting to 0444. Directories within the path are not affected by this setting.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#default_mode CloudRunV2Service#default_mode}
    */
    readonly defaultMode?: number;
    /**
    * The name of the secret in Cloud Secret Manager. Format: {secret} if the secret is in the same project. projects/{project}/secrets/{secret} if the secret is in a different project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#secret CloudRunV2Service#secret}
    */
    readonly secret: string;
    /**
    * items block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#items CloudRunV2Service#items}
    */
    readonly items?: CloudRunV2ServiceTemplateVolumesSecretItems[] | cdktn.IResolvable;
}
export declare function cloudRunV2ServiceTemplateVolumesSecretToTerraform(struct?: CloudRunV2ServiceTemplateVolumesSecretOutputReference | CloudRunV2ServiceTemplateVolumesSecret): any;
export declare function cloudRunV2ServiceTemplateVolumesSecretToHclTerraform(struct?: CloudRunV2ServiceTemplateVolumesSecretOutputReference | CloudRunV2ServiceTemplateVolumesSecret): any;
export declare class CloudRunV2ServiceTemplateVolumesSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceTemplateVolumesSecret | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateVolumesSecret | undefined);
    private _defaultMode?;
    get defaultMode(): number;
    set defaultMode(value: number);
    resetDefaultMode(): void;
    get defaultModeInput(): number | undefined;
    private _secret?;
    get secret(): string;
    set secret(value: string);
    get secretInput(): string | undefined;
    private _items;
    get items(): CloudRunV2ServiceTemplateVolumesSecretItemsList;
    putItems(value: CloudRunV2ServiceTemplateVolumesSecretItems[] | cdktn.IResolvable): void;
    resetItems(): void;
    get itemsInput(): cdktn.IResolvable | CloudRunV2ServiceTemplateVolumesSecretItems[] | undefined;
}
export interface CloudRunV2ServiceTemplateVolumes {
    /**
    * Volume's name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#name CloudRunV2Service#name}
    */
    readonly name: string;
    /**
    * cloud_sql_instance block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#cloud_sql_instance CloudRunV2Service#cloud_sql_instance}
    */
    readonly cloudSqlInstance?: CloudRunV2ServiceTemplateVolumesCloudSqlInstance;
    /**
    * empty_dir block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#empty_dir CloudRunV2Service#empty_dir}
    */
    readonly emptyDir?: CloudRunV2ServiceTemplateVolumesEmptyDir;
    /**
    * gcs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#gcs CloudRunV2Service#gcs}
    */
    readonly gcs?: CloudRunV2ServiceTemplateVolumesGcs;
    /**
    * nfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#nfs CloudRunV2Service#nfs}
    */
    readonly nfs?: CloudRunV2ServiceTemplateVolumesNfs;
    /**
    * secret block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#secret CloudRunV2Service#secret}
    */
    readonly secret?: CloudRunV2ServiceTemplateVolumesSecret;
}
export declare function cloudRunV2ServiceTemplateVolumesToTerraform(struct?: CloudRunV2ServiceTemplateVolumes | cdktn.IResolvable): any;
export declare function cloudRunV2ServiceTemplateVolumesToHclTerraform(struct?: CloudRunV2ServiceTemplateVolumes | cdktn.IResolvable): any;
export declare class CloudRunV2ServiceTemplateVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2ServiceTemplateVolumes | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateVolumes | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _cloudSqlInstance;
    get cloudSqlInstance(): CloudRunV2ServiceTemplateVolumesCloudSqlInstanceOutputReference;
    putCloudSqlInstance(value: CloudRunV2ServiceTemplateVolumesCloudSqlInstance): void;
    resetCloudSqlInstance(): void;
    get cloudSqlInstanceInput(): CloudRunV2ServiceTemplateVolumesCloudSqlInstance | undefined;
    private _emptyDir;
    get emptyDir(): CloudRunV2ServiceTemplateVolumesEmptyDirOutputReference;
    putEmptyDir(value: CloudRunV2ServiceTemplateVolumesEmptyDir): void;
    resetEmptyDir(): void;
    get emptyDirInput(): CloudRunV2ServiceTemplateVolumesEmptyDir | undefined;
    private _gcs;
    get gcs(): CloudRunV2ServiceTemplateVolumesGcsOutputReference;
    putGcs(value: CloudRunV2ServiceTemplateVolumesGcs): void;
    resetGcs(): void;
    get gcsInput(): CloudRunV2ServiceTemplateVolumesGcs | undefined;
    private _nfs;
    get nfs(): CloudRunV2ServiceTemplateVolumesNfsOutputReference;
    putNfs(value: CloudRunV2ServiceTemplateVolumesNfs): void;
    resetNfs(): void;
    get nfsInput(): CloudRunV2ServiceTemplateVolumesNfs | undefined;
    private _secret;
    get secret(): CloudRunV2ServiceTemplateVolumesSecretOutputReference;
    putSecret(value: CloudRunV2ServiceTemplateVolumesSecret): void;
    resetSecret(): void;
    get secretInput(): CloudRunV2ServiceTemplateVolumesSecret | undefined;
}
export declare class CloudRunV2ServiceTemplateVolumesList extends cdktn.ComplexList {
    internalValue?: CloudRunV2ServiceTemplateVolumes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2ServiceTemplateVolumesOutputReference;
}
export interface CloudRunV2ServiceTemplateVpcAccessNetworkInterfaces {
    /**
    * The VPC network that the Cloud Run resource will be able to send traffic to. At least one of network or subnetwork must be specified. If both
    * network and subnetwork are specified, the given VPC subnetwork must belong to the given VPC network. If network is not specified, it will be
    * looked up from the subnetwork.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#network CloudRunV2Service#network}
    */
    readonly network?: string;
    /**
    * The VPC subnetwork that the Cloud Run resource will get IPs from. At least one of network or subnetwork must be specified. If both
    * network and subnetwork are specified, the given VPC subnetwork must belong to the given VPC network. If subnetwork is not specified, the
    * subnetwork with the same name with the network will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#subnetwork CloudRunV2Service#subnetwork}
    */
    readonly subnetwork?: string;
    /**
    * Network tags applied to this Cloud Run service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#tags CloudRunV2Service#tags}
    */
    readonly tags?: string[];
}
export declare function cloudRunV2ServiceTemplateVpcAccessNetworkInterfacesToTerraform(struct?: CloudRunV2ServiceTemplateVpcAccessNetworkInterfaces | cdktn.IResolvable): any;
export declare function cloudRunV2ServiceTemplateVpcAccessNetworkInterfacesToHclTerraform(struct?: CloudRunV2ServiceTemplateVpcAccessNetworkInterfaces | cdktn.IResolvable): any;
export declare class CloudRunV2ServiceTemplateVpcAccessNetworkInterfacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2ServiceTemplateVpcAccessNetworkInterfaces | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateVpcAccessNetworkInterfaces | cdktn.IResolvable | undefined);
    private _network?;
    get network(): string;
    set network(value: string);
    resetNetwork(): void;
    get networkInput(): string | undefined;
    private _subnetwork?;
    get subnetwork(): string;
    set subnetwork(value: string);
    resetSubnetwork(): void;
    get subnetworkInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
}
export declare class CloudRunV2ServiceTemplateVpcAccessNetworkInterfacesList extends cdktn.ComplexList {
    internalValue?: CloudRunV2ServiceTemplateVpcAccessNetworkInterfaces[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2ServiceTemplateVpcAccessNetworkInterfacesOutputReference;
}
export interface CloudRunV2ServiceTemplateVpcAccess {
    /**
    * VPC Access connector name. Format: projects/{project}/locations/{location}/connectors/{connector}, where {project} can be project id or number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#connector CloudRunV2Service#connector}
    */
    readonly connector?: string;
    /**
    * Traffic VPC egress settings. Possible values: ["ALL_TRAFFIC", "PRIVATE_RANGES_ONLY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#egress CloudRunV2Service#egress}
    */
    readonly egress?: string;
    /**
    * network_interfaces block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#network_interfaces CloudRunV2Service#network_interfaces}
    */
    readonly networkInterfaces?: CloudRunV2ServiceTemplateVpcAccessNetworkInterfaces[] | cdktn.IResolvable;
}
export declare function cloudRunV2ServiceTemplateVpcAccessToTerraform(struct?: CloudRunV2ServiceTemplateVpcAccessOutputReference | CloudRunV2ServiceTemplateVpcAccess): any;
export declare function cloudRunV2ServiceTemplateVpcAccessToHclTerraform(struct?: CloudRunV2ServiceTemplateVpcAccessOutputReference | CloudRunV2ServiceTemplateVpcAccess): any;
export declare class CloudRunV2ServiceTemplateVpcAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceTemplateVpcAccess | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateVpcAccess | undefined);
    private _connector?;
    get connector(): string;
    set connector(value: string);
    resetConnector(): void;
    get connectorInput(): string | undefined;
    private _egress?;
    get egress(): string;
    set egress(value: string);
    resetEgress(): void;
    get egressInput(): string | undefined;
    private _networkInterfaces;
    get networkInterfaces(): CloudRunV2ServiceTemplateVpcAccessNetworkInterfacesList;
    putNetworkInterfaces(value: CloudRunV2ServiceTemplateVpcAccessNetworkInterfaces[] | cdktn.IResolvable): void;
    resetNetworkInterfaces(): void;
    get networkInterfacesInput(): cdktn.IResolvable | CloudRunV2ServiceTemplateVpcAccessNetworkInterfaces[] | undefined;
}
export interface CloudRunV2ServiceTemplateWorkloadIdentityConfig {
    /**
    * The Revision's SPIFFE workload identity. Enables provisioning of SPIFFE workload certificates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#identity CloudRunV2Service#identity}
    */
    readonly identity?: string;
    /**
    * Controls whether an instance receives a managed workload identity (MWLID) certificate.
    * Defaults to true when 'identity_type' is 'IDENTITY_TYPE_AGENT_IDENTITY'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#identity_certificate_enabled CloudRunV2Service#identity_certificate_enabled}
    */
    readonly identityCertificateEnabled?: boolean | cdktn.IResolvable;
    /**
    * The type of identity to use. 'IDENTITY_TYPE_AGENT_IDENTITY' assigns a system-managed agent identity and
    * is required when the Service's 'functional_type' is 'FUNCTIONAL_TYPE_AGENT'. Once set, this field
    * cannot be changed or unset. Possible values: ["IDENTITY_TYPE_SERVICE_ACCOUNT", "IDENTITY_TYPE_WORKLOAD_IDENTITY", "IDENTITY_TYPE_AGENT_IDENTITY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#identity_type CloudRunV2Service#identity_type}
    */
    readonly identityType?: string;
}
export declare function cloudRunV2ServiceTemplateWorkloadIdentityConfigToTerraform(struct?: CloudRunV2ServiceTemplateWorkloadIdentityConfigOutputReference | CloudRunV2ServiceTemplateWorkloadIdentityConfig): any;
export declare function cloudRunV2ServiceTemplateWorkloadIdentityConfigToHclTerraform(struct?: CloudRunV2ServiceTemplateWorkloadIdentityConfigOutputReference | CloudRunV2ServiceTemplateWorkloadIdentityConfig): any;
export declare class CloudRunV2ServiceTemplateWorkloadIdentityConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceTemplateWorkloadIdentityConfig | undefined;
    set internalValue(value: CloudRunV2ServiceTemplateWorkloadIdentityConfig | undefined);
    private _identity?;
    get identity(): string;
    set identity(value: string);
    resetIdentity(): void;
    get identityInput(): string | undefined;
    private _identityCertificateEnabled?;
    get identityCertificateEnabled(): boolean | cdktn.IResolvable;
    set identityCertificateEnabled(value: boolean | cdktn.IResolvable);
    resetIdentityCertificateEnabled(): void;
    get identityCertificateEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface CloudRunV2ServiceTemplate {
    /**
    * Unstructured key value map that may be set by external tools to store and arbitrary metadata. They are not queryable and should be preserved when modifying objects.
    *
    * Cloud Run API v2 does not support annotations with 'run.googleapis.com', 'cloud.googleapis.com', 'serving.knative.dev', or 'autoscaling.knative.dev' namespaces, and they will be rejected.
    * All system annotations in v1 now have a corresponding field in v2 RevisionTemplate.
    *
    * This field follows Kubernetes annotations' namespacing, limits, and rules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#annotations CloudRunV2Service#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * A reference to a customer managed encryption key (CMEK) to use to encrypt this container image. For more information, go to https://cloud.google.com/run/docs/securing/using-cmek
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#encryption_key CloudRunV2Service#encryption_key}
    */
    readonly encryptionKey?: string;
    /**
    * The sandbox environment to host this Revision. Possible values: ["EXECUTION_ENVIRONMENT_GEN1", "EXECUTION_ENVIRONMENT_GEN2"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#execution_environment CloudRunV2Service#execution_environment}
    */
    readonly executionEnvironment?: string;
    /**
    * True if GPU zonal redundancy is disabled on this revision.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#gpu_zonal_redundancy_disabled CloudRunV2Service#gpu_zonal_redundancy_disabled}
    */
    readonly gpuZonalRedundancyDisabled?: boolean | cdktn.IResolvable;
    /**
    * Disables health checking containers during deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#health_check_disabled CloudRunV2Service#health_check_disabled}
    */
    readonly healthCheckDisabled?: boolean | cdktn.IResolvable;
    /**
    * Unstructured key value map that can be used to organize and categorize objects. User-provided labels are shared with Google's billing system, so they can be used to filter, or break down billing charges by team, component, environment, state, etc.
    * For more information, visit https://docs.cloud.google.com/resource-manager/docs/creating-managing-labels or https://cloud.google.com/run/docs/configuring/labels.
    *
    * Cloud Run API v2 does not support labels with 'run.googleapis.com', 'cloud.googleapis.com', 'serving.knative.dev', or 'autoscaling.knative.dev' namespaces, and they will be rejected.
    * All system labels in v1 now have a corresponding field in v2 RevisionTemplate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#labels CloudRunV2Service#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Sets the maximum number of requests that each serving instance can receive.
    * If not specified or 0, defaults to 80 when requested CPU >= 1 and defaults to 1 when requested CPU < 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#max_instance_request_concurrency CloudRunV2Service#max_instance_request_concurrency}
    */
    readonly maxInstanceRequestConcurrency?: number;
    /**
    * The unique name for the revision. If this field is omitted, it will be automatically generated based on the Service name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#revision CloudRunV2Service#revision}
    */
    readonly revision?: string;
    /**
    * Email address of the IAM service account associated with the revision of the service. The service account represents the identity of the running revision, and determines what permissions the revision has. If not provided, the revision will use the project's default service account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#service_account CloudRunV2Service#service_account}
    */
    readonly serviceAccount?: string;
    /**
    * Enables session affinity. For more information, go to https://cloud.google.com/run/docs/configuring/session-affinity
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#session_affinity CloudRunV2Service#session_affinity}
    */
    readonly sessionAffinity?: boolean | cdktn.IResolvable;
    /**
    * Max allowed time for an instance to respond to a request.
    *
    * A duration in seconds with up to nine fractional digits, ending with 's'. Example: "3.5s".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#timeout CloudRunV2Service#timeout}
    */
    readonly timeout?: string;
    /**
    * containers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#containers CloudRunV2Service#containers}
    */
    readonly containers?: CloudRunV2ServiceTemplateContainers[] | cdktn.IResolvable;
    /**
    * node_selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#node_selector CloudRunV2Service#node_selector}
    */
    readonly nodeSelector?: CloudRunV2ServiceTemplateNodeSelector;
    /**
    * sandboxes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#sandboxes CloudRunV2Service#sandboxes}
    */
    readonly sandboxes?: CloudRunV2ServiceTemplateSandboxes;
    /**
    * scaling block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#scaling CloudRunV2Service#scaling}
    */
    readonly scaling?: CloudRunV2ServiceTemplateScaling;
    /**
    * volumes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#volumes CloudRunV2Service#volumes}
    */
    readonly volumes?: CloudRunV2ServiceTemplateVolumes[] | cdktn.IResolvable;
    /**
    * vpc_access block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#vpc_access CloudRunV2Service#vpc_access}
    */
    readonly vpcAccess?: CloudRunV2ServiceTemplateVpcAccess;
    /**
    * workload_identity_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#workload_identity_config CloudRunV2Service#workload_identity_config}
    */
    readonly workloadIdentityConfig?: CloudRunV2ServiceTemplateWorkloadIdentityConfig;
}
export declare function cloudRunV2ServiceTemplateToTerraform(struct?: CloudRunV2ServiceTemplateOutputReference | CloudRunV2ServiceTemplate): any;
export declare function cloudRunV2ServiceTemplateToHclTerraform(struct?: CloudRunV2ServiceTemplateOutputReference | CloudRunV2ServiceTemplate): any;
export declare class CloudRunV2ServiceTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceTemplate | undefined;
    set internalValue(value: CloudRunV2ServiceTemplate | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _encryptionKey?;
    get encryptionKey(): string;
    set encryptionKey(value: string);
    resetEncryptionKey(): void;
    get encryptionKeyInput(): string | undefined;
    private _executionEnvironment?;
    get executionEnvironment(): string;
    set executionEnvironment(value: string);
    resetExecutionEnvironment(): void;
    get executionEnvironmentInput(): string | undefined;
    private _gpuZonalRedundancyDisabled?;
    get gpuZonalRedundancyDisabled(): boolean | cdktn.IResolvable;
    set gpuZonalRedundancyDisabled(value: boolean | cdktn.IResolvable);
    resetGpuZonalRedundancyDisabled(): void;
    get gpuZonalRedundancyDisabledInput(): boolean | cdktn.IResolvable | undefined;
    private _healthCheckDisabled?;
    get healthCheckDisabled(): boolean | cdktn.IResolvable;
    set healthCheckDisabled(value: boolean | cdktn.IResolvable);
    resetHealthCheckDisabled(): void;
    get healthCheckDisabledInput(): boolean | cdktn.IResolvable | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _maxInstanceRequestConcurrency?;
    get maxInstanceRequestConcurrency(): number;
    set maxInstanceRequestConcurrency(value: number);
    resetMaxInstanceRequestConcurrency(): void;
    get maxInstanceRequestConcurrencyInput(): number | undefined;
    private _revision?;
    get revision(): string;
    set revision(value: string);
    resetRevision(): void;
    get revisionInput(): string | undefined;
    private _serviceAccount?;
    get serviceAccount(): string;
    set serviceAccount(value: string);
    resetServiceAccount(): void;
    get serviceAccountInput(): string | undefined;
    private _sessionAffinity?;
    get sessionAffinity(): boolean | cdktn.IResolvable;
    set sessionAffinity(value: boolean | cdktn.IResolvable);
    resetSessionAffinity(): void;
    get sessionAffinityInput(): boolean | cdktn.IResolvable | undefined;
    private _timeout?;
    get timeout(): string;
    set timeout(value: string);
    resetTimeout(): void;
    get timeoutInput(): string | undefined;
    private _containers;
    get containers(): CloudRunV2ServiceTemplateContainersList;
    putContainers(value: CloudRunV2ServiceTemplateContainers[] | cdktn.IResolvable): void;
    resetContainers(): void;
    get containersInput(): cdktn.IResolvable | CloudRunV2ServiceTemplateContainers[] | undefined;
    private _nodeSelector;
    get nodeSelector(): CloudRunV2ServiceTemplateNodeSelectorOutputReference;
    putNodeSelector(value: CloudRunV2ServiceTemplateNodeSelector): void;
    resetNodeSelector(): void;
    get nodeSelectorInput(): CloudRunV2ServiceTemplateNodeSelector | undefined;
    private _sandboxes;
    get sandboxes(): CloudRunV2ServiceTemplateSandboxesOutputReference;
    putSandboxes(value: CloudRunV2ServiceTemplateSandboxes): void;
    resetSandboxes(): void;
    get sandboxesInput(): CloudRunV2ServiceTemplateSandboxes | undefined;
    private _scaling;
    get scaling(): CloudRunV2ServiceTemplateScalingOutputReference;
    putScaling(value: CloudRunV2ServiceTemplateScaling): void;
    resetScaling(): void;
    get scalingInput(): CloudRunV2ServiceTemplateScaling | undefined;
    private _volumes;
    get volumes(): CloudRunV2ServiceTemplateVolumesList;
    putVolumes(value: CloudRunV2ServiceTemplateVolumes[] | cdktn.IResolvable): void;
    resetVolumes(): void;
    get volumesInput(): cdktn.IResolvable | CloudRunV2ServiceTemplateVolumes[] | undefined;
    private _vpcAccess;
    get vpcAccess(): CloudRunV2ServiceTemplateVpcAccessOutputReference;
    putVpcAccess(value: CloudRunV2ServiceTemplateVpcAccess): void;
    resetVpcAccess(): void;
    get vpcAccessInput(): CloudRunV2ServiceTemplateVpcAccess | undefined;
    private _workloadIdentityConfig;
    get workloadIdentityConfig(): CloudRunV2ServiceTemplateWorkloadIdentityConfigOutputReference;
    putWorkloadIdentityConfig(value: CloudRunV2ServiceTemplateWorkloadIdentityConfig): void;
    resetWorkloadIdentityConfig(): void;
    get workloadIdentityConfigInput(): CloudRunV2ServiceTemplateWorkloadIdentityConfig | undefined;
}
export interface CloudRunV2ServiceTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#create CloudRunV2Service#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#delete CloudRunV2Service#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#update CloudRunV2Service#update}
    */
    readonly update?: string;
}
export declare function cloudRunV2ServiceTimeoutsToTerraform(struct?: CloudRunV2ServiceTimeouts | cdktn.IResolvable): any;
export declare function cloudRunV2ServiceTimeoutsToHclTerraform(struct?: CloudRunV2ServiceTimeouts | cdktn.IResolvable): any;
export declare class CloudRunV2ServiceTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2ServiceTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2ServiceTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface CloudRunV2ServiceTraffic {
    /**
    * Specifies percent of the traffic to this Revision. This defaults to zero if unspecified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#percent CloudRunV2Service#percent}
    */
    readonly percent?: number;
    /**
    * Revision to which to send this portion of traffic, if traffic allocation is by revision.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#revision CloudRunV2Service#revision}
    */
    readonly revision?: string;
    /**
    * Indicates a string to be part of the URI to exclusively reference this target.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#tag CloudRunV2Service#tag}
    */
    readonly tag?: string;
    /**
    * The allocation type for this traffic target. Possible values: ["TRAFFIC_TARGET_ALLOCATION_TYPE_LATEST", "TRAFFIC_TARGET_ALLOCATION_TYPE_REVISION"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#type CloudRunV2Service#type}
    */
    readonly type?: string;
}
export declare function cloudRunV2ServiceTrafficToTerraform(struct?: CloudRunV2ServiceTraffic | cdktn.IResolvable): any;
export declare function cloudRunV2ServiceTrafficToHclTerraform(struct?: CloudRunV2ServiceTraffic | cdktn.IResolvable): any;
export declare class CloudRunV2ServiceTrafficOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2ServiceTraffic | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2ServiceTraffic | cdktn.IResolvable | undefined);
    private _percent?;
    get percent(): number;
    set percent(value: number);
    resetPercent(): void;
    get percentInput(): number | undefined;
    private _revision?;
    get revision(): string;
    set revision(value: string);
    resetRevision(): void;
    get revisionInput(): string | undefined;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    resetTag(): void;
    get tagInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class CloudRunV2ServiceTrafficList extends cdktn.ComplexList {
    internalValue?: CloudRunV2ServiceTraffic[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2ServiceTrafficOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service google_cloud_run_v2_service}
*/
export declare class CloudRunV2Service extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_cloud_run_v2_service";
    /**
    * Generates CDKTN code for importing a CloudRunV2Service resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudRunV2Service to import
    * @param importFromId The id of the existing CloudRunV2Service that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudRunV2Service to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_service google_cloud_run_v2_service} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudRunV2ServiceConfig
    */
    constructor(scope: Construct, id: string, config: CloudRunV2ServiceConfig);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _client?;
    get client(): string;
    set client(value: string);
    resetClient(): void;
    get clientInput(): string | undefined;
    private _clientVersion?;
    get clientVersion(): string;
    set clientVersion(value: string);
    resetClientVersion(): void;
    get clientVersionInput(): string | undefined;
    private _conditions;
    get conditions(): CloudRunV2ServiceConditionsList;
    get createTime(): string;
    get creator(): string;
    private _customAudiences?;
    get customAudiences(): string[];
    set customAudiences(value: string[]);
    resetCustomAudiences(): void;
    get customAudiencesInput(): string[] | undefined;
    private _defaultUriDisabled?;
    get defaultUriDisabled(): boolean | cdktn.IResolvable;
    set defaultUriDisabled(value: boolean | cdktn.IResolvable);
    resetDefaultUriDisabled(): void;
    get defaultUriDisabledInput(): boolean | cdktn.IResolvable | undefined;
    get deleteTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _deletionProtection?;
    get deletionProtection(): boolean | cdktn.IResolvable;
    set deletionProtection(value: boolean | cdktn.IResolvable);
    resetDeletionProtection(): void;
    get deletionProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _effectiveAnnotations;
    get effectiveAnnotations(): cdktn.StringMap;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get etag(): string;
    get expireTime(): string;
    get generation(): string;
    private _iapEnabled?;
    get iapEnabled(): boolean | cdktn.IResolvable;
    set iapEnabled(value: boolean | cdktn.IResolvable);
    resetIapEnabled(): void;
    get iapEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ingress?;
    get ingress(): string;
    set ingress(value: string);
    resetIngress(): void;
    get ingressInput(): string | undefined;
    private _invokerIamDisabled?;
    get invokerIamDisabled(): boolean | cdktn.IResolvable;
    set invokerIamDisabled(value: boolean | cdktn.IResolvable);
    resetInvokerIamDisabled(): void;
    get invokerIamDisabledInput(): boolean | cdktn.IResolvable | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    get lastModifier(): string;
    get latestCreatedRevision(): string;
    get latestReadyRevision(): string;
    private _launchStage?;
    get launchStage(): string;
    set launchStage(value: string);
    resetLaunchStage(): void;
    get launchStageInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get observedGeneration(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get reconciling(): cdktn.IResolvable;
    private _sshEnabled?;
    get sshEnabled(): boolean | cdktn.IResolvable;
    set sshEnabled(value: boolean | cdktn.IResolvable);
    resetSshEnabled(): void;
    get sshEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _terminalCondition;
    get terminalCondition(): CloudRunV2ServiceTerminalConditionList;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _trafficStatuses;
    get trafficStatuses(): CloudRunV2ServiceTrafficStatusesList;
    get uid(): string;
    get updateTime(): string;
    get uri(): string;
    get urls(): string[];
    private _binaryAuthorization;
    get binaryAuthorization(): CloudRunV2ServiceBinaryAuthorizationOutputReference;
    putBinaryAuthorization(value: CloudRunV2ServiceBinaryAuthorization): void;
    resetBinaryAuthorization(): void;
    get binaryAuthorizationInput(): CloudRunV2ServiceBinaryAuthorization | undefined;
    private _buildConfig;
    get buildConfig(): CloudRunV2ServiceBuildConfigOutputReference;
    putBuildConfig(value: CloudRunV2ServiceBuildConfig): void;
    resetBuildConfig(): void;
    get buildConfigInput(): CloudRunV2ServiceBuildConfig | undefined;
    private _multiRegionSettings;
    get multiRegionSettings(): CloudRunV2ServiceMultiRegionSettingsOutputReference;
    putMultiRegionSettings(value: CloudRunV2ServiceMultiRegionSettings): void;
    resetMultiRegionSettings(): void;
    get multiRegionSettingsInput(): CloudRunV2ServiceMultiRegionSettings | undefined;
    private _scaling;
    get scaling(): CloudRunV2ServiceScalingOutputReference;
    putScaling(value: CloudRunV2ServiceScaling): void;
    resetScaling(): void;
    get scalingInput(): CloudRunV2ServiceScaling | undefined;
    private _template;
    get template(): CloudRunV2ServiceTemplateOutputReference;
    putTemplate(value: CloudRunV2ServiceTemplate): void;
    get templateInput(): CloudRunV2ServiceTemplate | undefined;
    private _timeouts;
    get timeouts(): CloudRunV2ServiceTimeoutsOutputReference;
    putTimeouts(value: CloudRunV2ServiceTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CloudRunV2ServiceTimeouts | undefined;
    private _traffic;
    get traffic(): CloudRunV2ServiceTrafficList;
    putTraffic(value: CloudRunV2ServiceTraffic[] | cdktn.IResolvable): void;
    resetTraffic(): void;
    get trafficInput(): cdktn.IResolvable | CloudRunV2ServiceTraffic[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
