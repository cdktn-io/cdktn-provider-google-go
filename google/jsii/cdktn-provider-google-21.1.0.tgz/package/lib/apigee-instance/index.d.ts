/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigeeInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Optional. Customer accept list represents the list of projects (id/number) on customer
    * side that can privately connect to the service attachment. It is an optional field
    * which the customers can provide during the instance creation. By default, the customer
    * project associated with the Apigee organization will be included to the list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_instance#consumer_accept_list ApigeeInstance#consumer_accept_list}
    */
    readonly consumerAcceptList?: string[];
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_instance#deletion_policy ApigeeInstance#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Description of the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_instance#description ApigeeInstance#description}
    */
    readonly description?: string;
    /**
    * Customer Managed Encryption Key (CMEK) used for disk and volume encryption. Required for Apigee paid subscriptions only.
    * Use the following format: 'projects/([^/]+)/locations/([^/]+)/keyRings/([^/]+)/cryptoKeys/([^/]+)'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_instance#disk_encryption_key_name ApigeeInstance#disk_encryption_key_name}
    */
    readonly diskEncryptionKeyName?: string;
    /**
    * Display name of the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_instance#display_name ApigeeInstance#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_instance#id ApigeeInstance#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * IP range represents the customer-provided CIDR block of length 22 that will be used for
    * the Apigee instance creation. This optional range, if provided, should be freely
    * available as part of larger named range the customer has allocated to the Service
    * Networking peering. If this is not provided, Apigee will automatically request for any
    * available /22 CIDR block from Service Networking. The customer should use this CIDR block
    * for configuring their firewall needs to allow traffic from Apigee.
    * Input format: "a.b.c.d/22"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_instance#ip_range ApigeeInstance#ip_range}
    */
    readonly ipRange?: string;
    /**
    * Required. Compute Engine location where the instance resides.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_instance#location ApigeeInstance#location}
    */
    readonly location: string;
    /**
    * Resource ID of the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_instance#name ApigeeInstance#name}
    */
    readonly name: string;
    /**
    * The Apigee Organization associated with the Apigee instance,
    * in the format 'organizations/{{org_name}}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_instance#org_id ApigeeInstance#org_id}
    */
    readonly orgId: string;
    /**
    * The size of the CIDR block range that will be reserved by the instance. For valid values,
    * see [CidrRange](https://cloud.google.com/apigee/docs/reference/apis/apigee/rest/v1/organizations.instances#CidrRange) on the documentation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_instance#peering_cidr_range ApigeeInstance#peering_cidr_range}
    */
    readonly peeringCidrRange?: string;
    /**
    * access_logging_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_instance#access_logging_config ApigeeInstance#access_logging_config}
    */
    readonly accessLoggingConfig?: ApigeeInstanceAccessLoggingConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_instance#timeouts ApigeeInstance#timeouts}
    */
    readonly timeouts?: ApigeeInstanceTimeouts;
}
export interface ApigeeInstanceAccessLoggingConfig {
    /**
    * Boolean flag that specifies whether the customer access log feature is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_instance#enabled ApigeeInstance#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Ship the access log entries that match the statusCode defined in the filter.
    * The statusCode is the only expected/supported filter field. (Ex: statusCode)
    * The filter will parse it to the Common Expression Language semantics for expression
    * evaluation to build the filter condition. (Ex: "filter": statusCode >= 200 && statusCode < 300 )
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_instance#filter ApigeeInstance#filter}
    */
    readonly filter?: string;
}
export declare function apigeeInstanceAccessLoggingConfigToTerraform(struct?: ApigeeInstanceAccessLoggingConfigOutputReference | ApigeeInstanceAccessLoggingConfig): any;
export declare function apigeeInstanceAccessLoggingConfigToHclTerraform(struct?: ApigeeInstanceAccessLoggingConfigOutputReference | ApigeeInstanceAccessLoggingConfig): any;
export declare class ApigeeInstanceAccessLoggingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeInstanceAccessLoggingConfig | undefined;
    set internalValue(value: ApigeeInstanceAccessLoggingConfig | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
}
export interface ApigeeInstanceTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_instance#create ApigeeInstance#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_instance#delete ApigeeInstance#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_instance#update ApigeeInstance#update}
    */
    readonly update?: string;
}
export declare function apigeeInstanceTimeoutsToTerraform(struct?: ApigeeInstanceTimeouts | cdktn.IResolvable): any;
export declare function apigeeInstanceTimeoutsToHclTerraform(struct?: ApigeeInstanceTimeouts | cdktn.IResolvable): any;
export declare class ApigeeInstanceTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeInstanceTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeInstanceTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_instance google_apigee_instance}
*/
export declare class ApigeeInstance extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apigee_instance";
    /**
    * Generates CDKTN code for importing a ApigeeInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigeeInstance to import
    * @param importFromId The id of the existing ApigeeInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigeeInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_instance google_apigee_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigeeInstanceConfig
    */
    constructor(scope: Construct, id: string, config: ApigeeInstanceConfig);
    private _consumerAcceptList?;
    get consumerAcceptList(): string[];
    set consumerAcceptList(value: string[]);
    resetConsumerAcceptList(): void;
    get consumerAcceptListInput(): string[] | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _diskEncryptionKeyName?;
    get diskEncryptionKeyName(): string;
    set diskEncryptionKeyName(value: string);
    resetDiskEncryptionKeyName(): void;
    get diskEncryptionKeyNameInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    get host(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipRange?;
    get ipRange(): string;
    set ipRange(value: string);
    resetIpRange(): void;
    get ipRangeInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _orgId?;
    get orgId(): string;
    set orgId(value: string);
    get orgIdInput(): string | undefined;
    private _peeringCidrRange?;
    get peeringCidrRange(): string;
    set peeringCidrRange(value: string);
    resetPeeringCidrRange(): void;
    get peeringCidrRangeInput(): string | undefined;
    get port(): string;
    get serviceAttachment(): string;
    private _accessLoggingConfig;
    get accessLoggingConfig(): ApigeeInstanceAccessLoggingConfigOutputReference;
    putAccessLoggingConfig(value: ApigeeInstanceAccessLoggingConfig): void;
    resetAccessLoggingConfig(): void;
    get accessLoggingConfigInput(): ApigeeInstanceAccessLoggingConfig | undefined;
    private _timeouts;
    get timeouts(): ApigeeInstanceTimeoutsOutputReference;
    putTimeouts(value: ApigeeInstanceTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApigeeInstanceTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
