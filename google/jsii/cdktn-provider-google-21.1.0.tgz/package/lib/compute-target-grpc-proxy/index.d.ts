/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeTargetGrpcProxyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_grpc_proxy#deletion_policy ComputeTargetGrpcProxy#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_grpc_proxy#description ComputeTargetGrpcProxy#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_grpc_proxy#id ComputeTargetGrpcProxy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the resource. Provided by the client when the resource
    * is created. The name must be 1-63 characters long, and comply
    * with RFC1035. Specifically, the name must be 1-63 characters long
    * and match the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which
    * means the first character must be a lowercase letter, and all
    * following characters must be a dash, lowercase letter, or digit,
    * except the last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_grpc_proxy#name ComputeTargetGrpcProxy#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_grpc_proxy#project ComputeTargetGrpcProxy#project}
    */
    readonly project?: string;
    /**
    * URL to the UrlMap resource that defines the mapping from URL to
    * the BackendService. The protocol field in the BackendService
    * must be set to GRPC.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_grpc_proxy#url_map ComputeTargetGrpcProxy#url_map}
    */
    readonly urlMap?: string;
    /**
    * If true, indicates that the BackendServices referenced by
    * the urlMap may be accessed by gRPC applications without using
    * a sidecar proxy. This will enable configuration checks on urlMap
    * and its referenced BackendServices to not allow unsupported features.
    * A gRPC application must use "xds:///" scheme in the target URI
    * of the service it is connecting to. If false, indicates that the
    * BackendServices referenced by the urlMap will be accessed by gRPC
    * applications via a sidecar proxy. In this case, a gRPC application
    * must not use "xds:///" scheme in the target URI of the service
    * it is connecting to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_grpc_proxy#validate_for_proxyless ComputeTargetGrpcProxy#validate_for_proxyless}
    */
    readonly validateForProxyless?: boolean | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_grpc_proxy#timeouts ComputeTargetGrpcProxy#timeouts}
    */
    readonly timeouts?: ComputeTargetGrpcProxyTimeouts;
}
export interface ComputeTargetGrpcProxyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_grpc_proxy#create ComputeTargetGrpcProxy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_grpc_proxy#delete ComputeTargetGrpcProxy#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_grpc_proxy#update ComputeTargetGrpcProxy#update}
    */
    readonly update?: string;
}
export declare function computeTargetGrpcProxyTimeoutsToTerraform(struct?: ComputeTargetGrpcProxyTimeouts | cdktn.IResolvable): any;
export declare function computeTargetGrpcProxyTimeoutsToHclTerraform(struct?: ComputeTargetGrpcProxyTimeouts | cdktn.IResolvable): any;
export declare class ComputeTargetGrpcProxyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeTargetGrpcProxyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeTargetGrpcProxyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_grpc_proxy google_compute_target_grpc_proxy}
*/
export declare class ComputeTargetGrpcProxy extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_target_grpc_proxy";
    /**
    * Generates CDKTN code for importing a ComputeTargetGrpcProxy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeTargetGrpcProxy to import
    * @param importFromId The id of the existing ComputeTargetGrpcProxy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_grpc_proxy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeTargetGrpcProxy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_target_grpc_proxy google_compute_target_grpc_proxy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeTargetGrpcProxyConfig
    */
    constructor(scope: Construct, id: string, config: ComputeTargetGrpcProxyConfig);
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get fingerprint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get selfLink(): string;
    get selfLinkWithId(): string;
    private _urlMap?;
    get urlMap(): string;
    set urlMap(value: string);
    resetUrlMap(): void;
    get urlMapInput(): string | undefined;
    private _validateForProxyless?;
    get validateForProxyless(): boolean | cdktn.IResolvable;
    set validateForProxyless(value: boolean | cdktn.IResolvable);
    resetValidateForProxyless(): void;
    get validateForProxylessInput(): boolean | cdktn.IResolvable | undefined;
    private _timeouts;
    get timeouts(): ComputeTargetGrpcProxyTimeoutsOutputReference;
    putTimeouts(value: ComputeTargetGrpcProxyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeTargetGrpcProxyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
