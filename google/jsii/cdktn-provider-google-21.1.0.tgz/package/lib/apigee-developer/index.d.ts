/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigeeDeveloperConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_developer#deletion_policy ApigeeDeveloper#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Email address of the developer. This value is used to uniquely identify the developer in Apigee hybrid. Note that the email address has to be in lowercase only..
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_developer#email ApigeeDeveloper#email}
    */
    readonly email: string;
    /**
    * First name of the developer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_developer#first_name ApigeeDeveloper#first_name}
    */
    readonly firstName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_developer#id ApigeeDeveloper#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Last name of the developer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_developer#last_name ApigeeDeveloper#last_name}
    */
    readonly lastName: string;
    /**
    * The Apigee Organization associated with the Apigee instance,
    * in the format 'organizations/{{org_name}}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_developer#org_id ApigeeDeveloper#org_id}
    */
    readonly orgId: string;
    /**
    * User name of the developer. Not used by Apigee hybrid.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_developer#user_name ApigeeDeveloper#user_name}
    */
    readonly userName: string;
    /**
    * attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_developer#attributes ApigeeDeveloper#attributes}
    */
    readonly attributes?: ApigeeDeveloperAttributes[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_developer#timeouts ApigeeDeveloper#timeouts}
    */
    readonly timeouts?: ApigeeDeveloperTimeouts;
}
export interface ApigeeDeveloperAttributes {
    /**
    * Key of the attribute
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_developer#name ApigeeDeveloper#name}
    */
    readonly name?: string;
    /**
    * Value of the attribute
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_developer#value ApigeeDeveloper#value}
    */
    readonly value?: string;
}
export declare function apigeeDeveloperAttributesToTerraform(struct?: ApigeeDeveloperAttributes | cdktn.IResolvable): any;
export declare function apigeeDeveloperAttributesToHclTerraform(struct?: ApigeeDeveloperAttributes | cdktn.IResolvable): any;
export declare class ApigeeDeveloperAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigeeDeveloperAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeDeveloperAttributes | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApigeeDeveloperAttributesList extends cdktn.ComplexList {
    internalValue?: ApigeeDeveloperAttributes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigeeDeveloperAttributesOutputReference;
}
export interface ApigeeDeveloperTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_developer#create ApigeeDeveloper#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_developer#delete ApigeeDeveloper#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_developer#update ApigeeDeveloper#update}
    */
    readonly update?: string;
}
export declare function apigeeDeveloperTimeoutsToTerraform(struct?: ApigeeDeveloperTimeouts | cdktn.IResolvable): any;
export declare function apigeeDeveloperTimeoutsToHclTerraform(struct?: ApigeeDeveloperTimeouts | cdktn.IResolvable): any;
export declare class ApigeeDeveloperTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeDeveloperTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeDeveloperTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_developer google_apigee_developer}
*/
export declare class ApigeeDeveloper extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apigee_developer";
    /**
    * Generates CDKTN code for importing a ApigeeDeveloper resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigeeDeveloper to import
    * @param importFromId The id of the existing ApigeeDeveloper that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_developer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigeeDeveloper to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_developer google_apigee_developer} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigeeDeveloperConfig
    */
    constructor(scope: Construct, id: string, config: ApigeeDeveloperConfig);
    get createdAt(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    get emailInput(): string | undefined;
    private _firstName?;
    get firstName(): string;
    set firstName(value: string);
    get firstNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastModifiedAt(): string;
    private _lastName?;
    get lastName(): string;
    set lastName(value: string);
    get lastNameInput(): string | undefined;
    private _orgId?;
    get orgId(): string;
    set orgId(value: string);
    get orgIdInput(): string | undefined;
    get organizatioName(): string;
    get status(): string;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    get userNameInput(): string | undefined;
    private _attributes;
    get attributes(): ApigeeDeveloperAttributesList;
    putAttributes(value: ApigeeDeveloperAttributes[] | cdktn.IResolvable): void;
    resetAttributes(): void;
    get attributesInput(): cdktn.IResolvable | ApigeeDeveloperAttributes[] | undefined;
    private _timeouts;
    get timeouts(): ApigeeDeveloperTimeoutsOutputReference;
    putTimeouts(value: ApigeeDeveloperTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApigeeDeveloperTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
