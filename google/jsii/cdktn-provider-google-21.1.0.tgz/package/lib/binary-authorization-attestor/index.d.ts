/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BinaryAuthorizationAttestorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/binary_authorization_attestor#deletion_policy BinaryAuthorizationAttestor#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * A descriptive comment. This field may be updated. The field may be
    * displayed in chooser dialogs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/binary_authorization_attestor#description BinaryAuthorizationAttestor#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/binary_authorization_attestor#id BinaryAuthorizationAttestor#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The resource name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/binary_authorization_attestor#name BinaryAuthorizationAttestor#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/binary_authorization_attestor#project BinaryAuthorizationAttestor#project}
    */
    readonly project?: string;
    /**
    * attestation_authority_note block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/binary_authorization_attestor#attestation_authority_note BinaryAuthorizationAttestor#attestation_authority_note}
    */
    readonly attestationAuthorityNote: BinaryAuthorizationAttestorAttestationAuthorityNote;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/binary_authorization_attestor#timeouts BinaryAuthorizationAttestor#timeouts}
    */
    readonly timeouts?: BinaryAuthorizationAttestorTimeouts;
}
export interface BinaryAuthorizationAttestorAttestationAuthorityNotePublicKeysPkixPublicKey {
    /**
    * A PEM-encoded public key, as described in
    * 'https://tools.ietf.org/html/rfc7468#section-13'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/binary_authorization_attestor#public_key_pem BinaryAuthorizationAttestor#public_key_pem}
    */
    readonly publicKeyPem?: string;
    /**
    * The signature algorithm used to verify a message against
    * a signature using this key. These signature algorithm must
    * match the structure and any object identifiers encoded in
    * publicKeyPem (i.e. this algorithm must match that of the
    * public key).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/binary_authorization_attestor#signature_algorithm BinaryAuthorizationAttestor#signature_algorithm}
    */
    readonly signatureAlgorithm?: string;
}
export declare function binaryAuthorizationAttestorAttestationAuthorityNotePublicKeysPkixPublicKeyToTerraform(struct?: BinaryAuthorizationAttestorAttestationAuthorityNotePublicKeysPkixPublicKeyOutputReference | BinaryAuthorizationAttestorAttestationAuthorityNotePublicKeysPkixPublicKey): any;
export declare function binaryAuthorizationAttestorAttestationAuthorityNotePublicKeysPkixPublicKeyToHclTerraform(struct?: BinaryAuthorizationAttestorAttestationAuthorityNotePublicKeysPkixPublicKeyOutputReference | BinaryAuthorizationAttestorAttestationAuthorityNotePublicKeysPkixPublicKey): any;
export declare class BinaryAuthorizationAttestorAttestationAuthorityNotePublicKeysPkixPublicKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BinaryAuthorizationAttestorAttestationAuthorityNotePublicKeysPkixPublicKey | undefined;
    set internalValue(value: BinaryAuthorizationAttestorAttestationAuthorityNotePublicKeysPkixPublicKey | undefined);
    private _publicKeyPem?;
    get publicKeyPem(): string;
    set publicKeyPem(value: string);
    resetPublicKeyPem(): void;
    get publicKeyPemInput(): string | undefined;
    private _signatureAlgorithm?;
    get signatureAlgorithm(): string;
    set signatureAlgorithm(value: string);
    resetSignatureAlgorithm(): void;
    get signatureAlgorithmInput(): string | undefined;
}
export interface BinaryAuthorizationAttestorAttestationAuthorityNotePublicKeys {
    /**
    * ASCII-armored representation of a PGP public key, as the
    * entire output by the command
    * 'gpg --export --armor foo@example.com' (either LF or CRLF
    * line endings). When using this field, id should be left
    * blank. The BinAuthz API handlers will calculate the ID
    * and fill it in automatically. BinAuthz computes this ID
    * as the OpenPGP RFC4880 V4 fingerprint, represented as
    * upper-case hex. If id is provided by the caller, it will
    * be overwritten by the API-calculated ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/binary_authorization_attestor#ascii_armored_pgp_public_key BinaryAuthorizationAttestor#ascii_armored_pgp_public_key}
    */
    readonly asciiArmoredPgpPublicKey?: string;
    /**
    * A descriptive comment. This field may be updated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/binary_authorization_attestor#comment BinaryAuthorizationAttestor#comment}
    */
    readonly comment?: string;
    /**
    * The ID of this public key. Signatures verified by BinAuthz
    * must include the ID of the public key that can be used to
    * verify them, and that ID must match the contents of this
    * field exactly. Additional restrictions on this field can
    * be imposed based on which public key type is encapsulated.
    * See the documentation on publicKey cases below for details.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/binary_authorization_attestor#id BinaryAuthorizationAttestor#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * pkix_public_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/binary_authorization_attestor#pkix_public_key BinaryAuthorizationAttestor#pkix_public_key}
    */
    readonly pkixPublicKey?: BinaryAuthorizationAttestorAttestationAuthorityNotePublicKeysPkixPublicKey;
}
export declare function binaryAuthorizationAttestorAttestationAuthorityNotePublicKeysToTerraform(struct?: BinaryAuthorizationAttestorAttestationAuthorityNotePublicKeys | cdktn.IResolvable): any;
export declare function binaryAuthorizationAttestorAttestationAuthorityNotePublicKeysToHclTerraform(struct?: BinaryAuthorizationAttestorAttestationAuthorityNotePublicKeys | cdktn.IResolvable): any;
export declare class BinaryAuthorizationAttestorAttestationAuthorityNotePublicKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BinaryAuthorizationAttestorAttestationAuthorityNotePublicKeys | cdktn.IResolvable | undefined;
    set internalValue(value: BinaryAuthorizationAttestorAttestationAuthorityNotePublicKeys | cdktn.IResolvable | undefined);
    private _asciiArmoredPgpPublicKey?;
    get asciiArmoredPgpPublicKey(): string;
    set asciiArmoredPgpPublicKey(value: string);
    resetAsciiArmoredPgpPublicKey(): void;
    get asciiArmoredPgpPublicKeyInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _pkixPublicKey;
    get pkixPublicKey(): BinaryAuthorizationAttestorAttestationAuthorityNotePublicKeysPkixPublicKeyOutputReference;
    putPkixPublicKey(value: BinaryAuthorizationAttestorAttestationAuthorityNotePublicKeysPkixPublicKey): void;
    resetPkixPublicKey(): void;
    get pkixPublicKeyInput(): BinaryAuthorizationAttestorAttestationAuthorityNotePublicKeysPkixPublicKey | undefined;
}
export declare class BinaryAuthorizationAttestorAttestationAuthorityNotePublicKeysList extends cdktn.ComplexList {
    internalValue?: BinaryAuthorizationAttestorAttestationAuthorityNotePublicKeys[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BinaryAuthorizationAttestorAttestationAuthorityNotePublicKeysOutputReference;
}
export interface BinaryAuthorizationAttestorAttestationAuthorityNote {
    /**
    * The resource name of a ATTESTATION_AUTHORITY Note, created by the
    * user. If the Note is in a different project from the Attestor, it
    * should be specified in the format 'projects/* /notes/*' (or the legacy
    * 'providers/* /notes/*'). This field may not be updated.
    * An attestation by this attestor is stored as a Container Analysis
    * ATTESTATION_AUTHORITY Occurrence that names a container image
    * and that links to this Note.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/binary_authorization_attestor#note_reference BinaryAuthorizationAttestor#note_reference}
     *
    * Note: The above comment contained a comment block ending sequence (* followed by /). We have introduced a space between to prevent syntax errors. Please ignore the space.
    */
    readonly noteReference: string;
    /**
    * public_keys block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/binary_authorization_attestor#public_keys BinaryAuthorizationAttestor#public_keys}
    */
    readonly publicKeys?: BinaryAuthorizationAttestorAttestationAuthorityNotePublicKeys[] | cdktn.IResolvable;
}
export declare function binaryAuthorizationAttestorAttestationAuthorityNoteToTerraform(struct?: BinaryAuthorizationAttestorAttestationAuthorityNoteOutputReference | BinaryAuthorizationAttestorAttestationAuthorityNote): any;
export declare function binaryAuthorizationAttestorAttestationAuthorityNoteToHclTerraform(struct?: BinaryAuthorizationAttestorAttestationAuthorityNoteOutputReference | BinaryAuthorizationAttestorAttestationAuthorityNote): any;
export declare class BinaryAuthorizationAttestorAttestationAuthorityNoteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BinaryAuthorizationAttestorAttestationAuthorityNote | undefined;
    set internalValue(value: BinaryAuthorizationAttestorAttestationAuthorityNote | undefined);
    get delegationServiceAccountEmail(): string;
    private _noteReference?;
    get noteReference(): string;
    set noteReference(value: string);
    get noteReferenceInput(): string | undefined;
    private _publicKeys;
    get publicKeys(): BinaryAuthorizationAttestorAttestationAuthorityNotePublicKeysList;
    putPublicKeys(value: BinaryAuthorizationAttestorAttestationAuthorityNotePublicKeys[] | cdktn.IResolvable): void;
    resetPublicKeys(): void;
    get publicKeysInput(): cdktn.IResolvable | BinaryAuthorizationAttestorAttestationAuthorityNotePublicKeys[] | undefined;
}
export interface BinaryAuthorizationAttestorTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/binary_authorization_attestor#create BinaryAuthorizationAttestor#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/binary_authorization_attestor#delete BinaryAuthorizationAttestor#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/binary_authorization_attestor#update BinaryAuthorizationAttestor#update}
    */
    readonly update?: string;
}
export declare function binaryAuthorizationAttestorTimeoutsToTerraform(struct?: BinaryAuthorizationAttestorTimeouts | cdktn.IResolvable): any;
export declare function binaryAuthorizationAttestorTimeoutsToHclTerraform(struct?: BinaryAuthorizationAttestorTimeouts | cdktn.IResolvable): any;
export declare class BinaryAuthorizationAttestorTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BinaryAuthorizationAttestorTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BinaryAuthorizationAttestorTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/binary_authorization_attestor google_binary_authorization_attestor}
*/
export declare class BinaryAuthorizationAttestor extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_binary_authorization_attestor";
    /**
    * Generates CDKTN code for importing a BinaryAuthorizationAttestor resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BinaryAuthorizationAttestor to import
    * @param importFromId The id of the existing BinaryAuthorizationAttestor that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/binary_authorization_attestor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BinaryAuthorizationAttestor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/binary_authorization_attestor google_binary_authorization_attestor} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BinaryAuthorizationAttestorConfig
    */
    constructor(scope: Construct, id: string, config: BinaryAuthorizationAttestorConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _attestationAuthorityNote;
    get attestationAuthorityNote(): BinaryAuthorizationAttestorAttestationAuthorityNoteOutputReference;
    putAttestationAuthorityNote(value: BinaryAuthorizationAttestorAttestationAuthorityNote): void;
    get attestationAuthorityNoteInput(): BinaryAuthorizationAttestorAttestationAuthorityNote | undefined;
    private _timeouts;
    get timeouts(): BinaryAuthorizationAttestorTimeoutsOutputReference;
    putTimeouts(value: BinaryAuthorizationAttestorTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BinaryAuthorizationAttestorTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
