/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BigqueryCapacityCommitmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * The optional capacity commitment ID. Capacity commitment name will be generated automatically if this field is
    * empty. This field must only contain lower case alphanumeric characters or dashes. The first and last character
    * cannot be a dash. Max length is 64 characters. NOTE: this ID won't be kept if the capacity commitment is split
    * or merged.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_capacity_commitment#capacity_commitment_id BigqueryCapacityCommitment#capacity_commitment_id}
    */
    readonly capacityCommitmentId?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_capacity_commitment#deletion_policy BigqueryCapacityCommitment#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The edition type. Valid values are STANDARD, ENTERPRISE, ENTERPRISE_PLUS
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_capacity_commitment#edition BigqueryCapacityCommitment#edition}
    */
    readonly edition?: string;
    /**
    * If true, fail the request if another project in the organization has a capacity commitment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_capacity_commitment#enforce_single_admin_project_per_org BigqueryCapacityCommitment#enforce_single_admin_project_per_org}
    */
    readonly enforceSingleAdminProjectPerOrg?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_capacity_commitment#id BigqueryCapacityCommitment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The geographic location where the transfer config should reside.
    * Examples: US, EU, asia-northeast1. The default value is US.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_capacity_commitment#location BigqueryCapacityCommitment#location}
    */
    readonly location?: string;
    /**
    * Capacity commitment plan. Valid values are at https://cloud.google.com/bigquery/docs/reference/reservations/rpc/google.cloud.bigquery.reservation.v1#commitmentplan
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_capacity_commitment#plan BigqueryCapacityCommitment#plan}
    */
    readonly plan: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_capacity_commitment#project BigqueryCapacityCommitment#project}
    */
    readonly project?: string;
    /**
    * The plan this capacity commitment is converted to after commitmentEndTime passes. Once the plan is changed, committed period is extended according to commitment plan. Only applicable for some commitment plans.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_capacity_commitment#renewal_plan BigqueryCapacityCommitment#renewal_plan}
    */
    readonly renewalPlan?: string;
    /**
    * Number of slots in this commitment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_capacity_commitment#slot_count BigqueryCapacityCommitment#slot_count}
    */
    readonly slotCount: number;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_capacity_commitment#timeouts BigqueryCapacityCommitment#timeouts}
    */
    readonly timeouts?: BigqueryCapacityCommitmentTimeouts;
}
export interface BigqueryCapacityCommitmentTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_capacity_commitment#create BigqueryCapacityCommitment#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_capacity_commitment#delete BigqueryCapacityCommitment#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_capacity_commitment#update BigqueryCapacityCommitment#update}
    */
    readonly update?: string;
}
export declare function bigqueryCapacityCommitmentTimeoutsToTerraform(struct?: BigqueryCapacityCommitmentTimeouts | cdktn.IResolvable): any;
export declare function bigqueryCapacityCommitmentTimeoutsToHclTerraform(struct?: BigqueryCapacityCommitmentTimeouts | cdktn.IResolvable): any;
export declare class BigqueryCapacityCommitmentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BigqueryCapacityCommitmentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BigqueryCapacityCommitmentTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_capacity_commitment google_bigquery_capacity_commitment}
*/
export declare class BigqueryCapacityCommitment extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_bigquery_capacity_commitment";
    /**
    * Generates CDKTN code for importing a BigqueryCapacityCommitment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BigqueryCapacityCommitment to import
    * @param importFromId The id of the existing BigqueryCapacityCommitment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_capacity_commitment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BigqueryCapacityCommitment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/bigquery_capacity_commitment google_bigquery_capacity_commitment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BigqueryCapacityCommitmentConfig
    */
    constructor(scope: Construct, id: string, config: BigqueryCapacityCommitmentConfig);
    private _capacityCommitmentId?;
    get capacityCommitmentId(): string;
    set capacityCommitmentId(value: string);
    resetCapacityCommitmentId(): void;
    get capacityCommitmentIdInput(): string | undefined;
    get commitmentEndTime(): string;
    get commitmentStartTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _edition?;
    get edition(): string;
    set edition(value: string);
    resetEdition(): void;
    get editionInput(): string | undefined;
    private _enforceSingleAdminProjectPerOrg?;
    get enforceSingleAdminProjectPerOrg(): string;
    set enforceSingleAdminProjectPerOrg(value: string);
    resetEnforceSingleAdminProjectPerOrg(): void;
    get enforceSingleAdminProjectPerOrgInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    get name(): string;
    private _plan?;
    get plan(): string;
    set plan(value: string);
    get planInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _renewalPlan?;
    get renewalPlan(): string;
    set renewalPlan(value: string);
    resetRenewalPlan(): void;
    get renewalPlanInput(): string | undefined;
    private _slotCount?;
    get slotCount(): number;
    set slotCount(value: number);
    get slotCountInput(): number | undefined;
    get state(): string;
    private _timeouts;
    get timeouts(): BigqueryCapacityCommitmentTimeoutsOutputReference;
    putTimeouts(value: BigqueryCapacityCommitmentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BigqueryCapacityCommitmentTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
