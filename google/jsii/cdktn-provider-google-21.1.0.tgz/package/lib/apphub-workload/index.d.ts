/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApphubWorkloadConfig extends cdktn.TerraformMetaArguments {
    /**
    * Part of 'parent'.  Full resource name of a parent Application. Example: projects/{HOST_PROJECT_ID}/locations/{LOCATION}/applications/{APPLICATION_ID}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#application_id ApphubWorkload#application_id}
    */
    readonly applicationId: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#deletion_policy ApphubWorkload#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * User-defined description of a Workload.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#description ApphubWorkload#description}
    */
    readonly description?: string;
    /**
    * Immutable. The resource name of the original discovered workload.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#discovered_workload ApphubWorkload#discovered_workload}
    */
    readonly discoveredWorkload: string;
    /**
    * User-defined name for the Workload.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#display_name ApphubWorkload#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#id ApphubWorkload#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Part of 'parent'.  Full resource name of a parent Application. Example: projects/{HOST_PROJECT_ID}/locations/{LOCATION}/applications/{APPLICATION_ID}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#location ApphubWorkload#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#project ApphubWorkload#project}
    */
    readonly project?: string;
    /**
    * The Workload identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#workload_id ApphubWorkload#workload_id}
    */
    readonly workloadId: string;
    /**
    * attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#attributes ApphubWorkload#attributes}
    */
    readonly attributes?: ApphubWorkloadAttributes;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#timeouts ApphubWorkload#timeouts}
    */
    readonly timeouts?: ApphubWorkloadTimeouts;
}
export interface ApphubWorkloadWorkloadPropertiesExtendedMetadataValue {
}
export declare function apphubWorkloadWorkloadPropertiesExtendedMetadataValueToTerraform(struct?: ApphubWorkloadWorkloadPropertiesExtendedMetadataValue): any;
export declare function apphubWorkloadWorkloadPropertiesExtendedMetadataValueToHclTerraform(struct?: ApphubWorkloadWorkloadPropertiesExtendedMetadataValue): any;
export declare class ApphubWorkloadWorkloadPropertiesExtendedMetadataValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApphubWorkloadWorkloadPropertiesExtendedMetadataValue | undefined;
    set internalValue(value: ApphubWorkloadWorkloadPropertiesExtendedMetadataValue | undefined);
    get extendedMetadataSchema(): string;
    get metadataStruct(): string;
}
export declare class ApphubWorkloadWorkloadPropertiesExtendedMetadataValueList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApphubWorkloadWorkloadPropertiesExtendedMetadataValueOutputReference;
}
export interface ApphubWorkloadWorkloadPropertiesExtendedMetadata {
}
export declare function apphubWorkloadWorkloadPropertiesExtendedMetadataToTerraform(struct?: ApphubWorkloadWorkloadPropertiesExtendedMetadata): any;
export declare function apphubWorkloadWorkloadPropertiesExtendedMetadataToHclTerraform(struct?: ApphubWorkloadWorkloadPropertiesExtendedMetadata): any;
export declare class ApphubWorkloadWorkloadPropertiesExtendedMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApphubWorkloadWorkloadPropertiesExtendedMetadata | undefined;
    set internalValue(value: ApphubWorkloadWorkloadPropertiesExtendedMetadata | undefined);
    get key(): string;
    private _value;
    get value(): ApphubWorkloadWorkloadPropertiesExtendedMetadataValueList;
}
export declare class ApphubWorkloadWorkloadPropertiesExtendedMetadataList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApphubWorkloadWorkloadPropertiesExtendedMetadataOutputReference;
}
export interface ApphubWorkloadWorkloadPropertiesFunctionalType {
}
export declare function apphubWorkloadWorkloadPropertiesFunctionalTypeToTerraform(struct?: ApphubWorkloadWorkloadPropertiesFunctionalType): any;
export declare function apphubWorkloadWorkloadPropertiesFunctionalTypeToHclTerraform(struct?: ApphubWorkloadWorkloadPropertiesFunctionalType): any;
export declare class ApphubWorkloadWorkloadPropertiesFunctionalTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApphubWorkloadWorkloadPropertiesFunctionalType | undefined;
    set internalValue(value: ApphubWorkloadWorkloadPropertiesFunctionalType | undefined);
    get type(): string;
}
export declare class ApphubWorkloadWorkloadPropertiesFunctionalTypeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApphubWorkloadWorkloadPropertiesFunctionalTypeOutputReference;
}
export interface ApphubWorkloadWorkloadPropertiesIdentity {
}
export declare function apphubWorkloadWorkloadPropertiesIdentityToTerraform(struct?: ApphubWorkloadWorkloadPropertiesIdentity): any;
export declare function apphubWorkloadWorkloadPropertiesIdentityToHclTerraform(struct?: ApphubWorkloadWorkloadPropertiesIdentity): any;
export declare class ApphubWorkloadWorkloadPropertiesIdentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApphubWorkloadWorkloadPropertiesIdentity | undefined;
    set internalValue(value: ApphubWorkloadWorkloadPropertiesIdentity | undefined);
    get principal(): string;
}
export declare class ApphubWorkloadWorkloadPropertiesIdentityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApphubWorkloadWorkloadPropertiesIdentityOutputReference;
}
export interface ApphubWorkloadWorkloadProperties {
}
export declare function apphubWorkloadWorkloadPropertiesToTerraform(struct?: ApphubWorkloadWorkloadProperties): any;
export declare function apphubWorkloadWorkloadPropertiesToHclTerraform(struct?: ApphubWorkloadWorkloadProperties): any;
export declare class ApphubWorkloadWorkloadPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApphubWorkloadWorkloadProperties | undefined;
    set internalValue(value: ApphubWorkloadWorkloadProperties | undefined);
    private _extendedMetadata;
    get extendedMetadata(): ApphubWorkloadWorkloadPropertiesExtendedMetadataList;
    private _functionalType;
    get functionalType(): ApphubWorkloadWorkloadPropertiesFunctionalTypeList;
    get gcpProject(): string;
    private _identity;
    get identity(): ApphubWorkloadWorkloadPropertiesIdentityList;
    get location(): string;
    get zone(): string;
}
export declare class ApphubWorkloadWorkloadPropertiesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApphubWorkloadWorkloadPropertiesOutputReference;
}
export interface ApphubWorkloadWorkloadReference {
}
export declare function apphubWorkloadWorkloadReferenceToTerraform(struct?: ApphubWorkloadWorkloadReference): any;
export declare function apphubWorkloadWorkloadReferenceToHclTerraform(struct?: ApphubWorkloadWorkloadReference): any;
export declare class ApphubWorkloadWorkloadReferenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApphubWorkloadWorkloadReference | undefined;
    set internalValue(value: ApphubWorkloadWorkloadReference | undefined);
    get uri(): string;
}
export declare class ApphubWorkloadWorkloadReferenceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApphubWorkloadWorkloadReferenceOutputReference;
}
export interface ApphubWorkloadAttributesBusinessOwners {
    /**
    * Contact's name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#display_name ApphubWorkload#display_name}
    */
    readonly displayName?: string;
    /**
    * Email address of the contacts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#email ApphubWorkload#email}
    */
    readonly email: string;
}
export declare function apphubWorkloadAttributesBusinessOwnersToTerraform(struct?: ApphubWorkloadAttributesBusinessOwners | cdktn.IResolvable): any;
export declare function apphubWorkloadAttributesBusinessOwnersToHclTerraform(struct?: ApphubWorkloadAttributesBusinessOwners | cdktn.IResolvable): any;
export declare class ApphubWorkloadAttributesBusinessOwnersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApphubWorkloadAttributesBusinessOwners | cdktn.IResolvable | undefined;
    set internalValue(value: ApphubWorkloadAttributesBusinessOwners | cdktn.IResolvable | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    get emailInput(): string | undefined;
}
export declare class ApphubWorkloadAttributesBusinessOwnersList extends cdktn.ComplexList {
    internalValue?: ApphubWorkloadAttributesBusinessOwners[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApphubWorkloadAttributesBusinessOwnersOutputReference;
}
export interface ApphubWorkloadAttributesCriticality {
    /**
    * Criticality type. Possible values: ["MISSION_CRITICAL", "HIGH", "MEDIUM", "LOW"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#type ApphubWorkload#type}
    */
    readonly type: string;
}
export declare function apphubWorkloadAttributesCriticalityToTerraform(struct?: ApphubWorkloadAttributesCriticalityOutputReference | ApphubWorkloadAttributesCriticality): any;
export declare function apphubWorkloadAttributesCriticalityToHclTerraform(struct?: ApphubWorkloadAttributesCriticalityOutputReference | ApphubWorkloadAttributesCriticality): any;
export declare class ApphubWorkloadAttributesCriticalityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApphubWorkloadAttributesCriticality | undefined;
    set internalValue(value: ApphubWorkloadAttributesCriticality | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface ApphubWorkloadAttributesDeveloperOwners {
    /**
    * Contact's name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#display_name ApphubWorkload#display_name}
    */
    readonly displayName?: string;
    /**
    * Email address of the contacts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#email ApphubWorkload#email}
    */
    readonly email: string;
}
export declare function apphubWorkloadAttributesDeveloperOwnersToTerraform(struct?: ApphubWorkloadAttributesDeveloperOwners | cdktn.IResolvable): any;
export declare function apphubWorkloadAttributesDeveloperOwnersToHclTerraform(struct?: ApphubWorkloadAttributesDeveloperOwners | cdktn.IResolvable): any;
export declare class ApphubWorkloadAttributesDeveloperOwnersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApphubWorkloadAttributesDeveloperOwners | cdktn.IResolvable | undefined;
    set internalValue(value: ApphubWorkloadAttributesDeveloperOwners | cdktn.IResolvable | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    get emailInput(): string | undefined;
}
export declare class ApphubWorkloadAttributesDeveloperOwnersList extends cdktn.ComplexList {
    internalValue?: ApphubWorkloadAttributesDeveloperOwners[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApphubWorkloadAttributesDeveloperOwnersOutputReference;
}
export interface ApphubWorkloadAttributesEnvironment {
    /**
    * Environment type. Possible values: ["PRODUCTION", "STAGING", "TEST", "DEVELOPMENT"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#type ApphubWorkload#type}
    */
    readonly type: string;
}
export declare function apphubWorkloadAttributesEnvironmentToTerraform(struct?: ApphubWorkloadAttributesEnvironmentOutputReference | ApphubWorkloadAttributesEnvironment): any;
export declare function apphubWorkloadAttributesEnvironmentToHclTerraform(struct?: ApphubWorkloadAttributesEnvironmentOutputReference | ApphubWorkloadAttributesEnvironment): any;
export declare class ApphubWorkloadAttributesEnvironmentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApphubWorkloadAttributesEnvironment | undefined;
    set internalValue(value: ApphubWorkloadAttributesEnvironment | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface ApphubWorkloadAttributesOperatorOwners {
    /**
    * Contact's name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#display_name ApphubWorkload#display_name}
    */
    readonly displayName?: string;
    /**
    * Email address of the contacts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#email ApphubWorkload#email}
    */
    readonly email: string;
}
export declare function apphubWorkloadAttributesOperatorOwnersToTerraform(struct?: ApphubWorkloadAttributesOperatorOwners | cdktn.IResolvable): any;
export declare function apphubWorkloadAttributesOperatorOwnersToHclTerraform(struct?: ApphubWorkloadAttributesOperatorOwners | cdktn.IResolvable): any;
export declare class ApphubWorkloadAttributesOperatorOwnersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApphubWorkloadAttributesOperatorOwners | cdktn.IResolvable | undefined;
    set internalValue(value: ApphubWorkloadAttributesOperatorOwners | cdktn.IResolvable | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    get emailInput(): string | undefined;
}
export declare class ApphubWorkloadAttributesOperatorOwnersList extends cdktn.ComplexList {
    internalValue?: ApphubWorkloadAttributesOperatorOwners[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApphubWorkloadAttributesOperatorOwnersOutputReference;
}
export interface ApphubWorkloadAttributes {
    /**
    * business_owners block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#business_owners ApphubWorkload#business_owners}
    */
    readonly businessOwners?: ApphubWorkloadAttributesBusinessOwners[] | cdktn.IResolvable;
    /**
    * criticality block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#criticality ApphubWorkload#criticality}
    */
    readonly criticality?: ApphubWorkloadAttributesCriticality;
    /**
    * developer_owners block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#developer_owners ApphubWorkload#developer_owners}
    */
    readonly developerOwners?: ApphubWorkloadAttributesDeveloperOwners[] | cdktn.IResolvable;
    /**
    * environment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#environment ApphubWorkload#environment}
    */
    readonly environment?: ApphubWorkloadAttributesEnvironment;
    /**
    * operator_owners block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#operator_owners ApphubWorkload#operator_owners}
    */
    readonly operatorOwners?: ApphubWorkloadAttributesOperatorOwners[] | cdktn.IResolvable;
}
export declare function apphubWorkloadAttributesToTerraform(struct?: ApphubWorkloadAttributesOutputReference | ApphubWorkloadAttributes): any;
export declare function apphubWorkloadAttributesToHclTerraform(struct?: ApphubWorkloadAttributesOutputReference | ApphubWorkloadAttributes): any;
export declare class ApphubWorkloadAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApphubWorkloadAttributes | undefined;
    set internalValue(value: ApphubWorkloadAttributes | undefined);
    private _businessOwners;
    get businessOwners(): ApphubWorkloadAttributesBusinessOwnersList;
    putBusinessOwners(value: ApphubWorkloadAttributesBusinessOwners[] | cdktn.IResolvable): void;
    resetBusinessOwners(): void;
    get businessOwnersInput(): cdktn.IResolvable | ApphubWorkloadAttributesBusinessOwners[] | undefined;
    private _criticality;
    get criticality(): ApphubWorkloadAttributesCriticalityOutputReference;
    putCriticality(value: ApphubWorkloadAttributesCriticality): void;
    resetCriticality(): void;
    get criticalityInput(): ApphubWorkloadAttributesCriticality | undefined;
    private _developerOwners;
    get developerOwners(): ApphubWorkloadAttributesDeveloperOwnersList;
    putDeveloperOwners(value: ApphubWorkloadAttributesDeveloperOwners[] | cdktn.IResolvable): void;
    resetDeveloperOwners(): void;
    get developerOwnersInput(): cdktn.IResolvable | ApphubWorkloadAttributesDeveloperOwners[] | undefined;
    private _environment;
    get environment(): ApphubWorkloadAttributesEnvironmentOutputReference;
    putEnvironment(value: ApphubWorkloadAttributesEnvironment): void;
    resetEnvironment(): void;
    get environmentInput(): ApphubWorkloadAttributesEnvironment | undefined;
    private _operatorOwners;
    get operatorOwners(): ApphubWorkloadAttributesOperatorOwnersList;
    putOperatorOwners(value: ApphubWorkloadAttributesOperatorOwners[] | cdktn.IResolvable): void;
    resetOperatorOwners(): void;
    get operatorOwnersInput(): cdktn.IResolvable | ApphubWorkloadAttributesOperatorOwners[] | undefined;
}
export interface ApphubWorkloadTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#create ApphubWorkload#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#delete ApphubWorkload#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#update ApphubWorkload#update}
    */
    readonly update?: string;
}
export declare function apphubWorkloadTimeoutsToTerraform(struct?: ApphubWorkloadTimeouts | cdktn.IResolvable): any;
export declare function apphubWorkloadTimeoutsToHclTerraform(struct?: ApphubWorkloadTimeouts | cdktn.IResolvable): any;
export declare class ApphubWorkloadTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApphubWorkloadTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApphubWorkloadTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload google_apphub_workload}
*/
export declare class ApphubWorkload extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apphub_workload";
    /**
    * Generates CDKTN code for importing a ApphubWorkload resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApphubWorkload to import
    * @param importFromId The id of the existing ApphubWorkload that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApphubWorkload to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apphub_workload google_apphub_workload} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApphubWorkloadConfig
    */
    constructor(scope: Construct, id: string, config: ApphubWorkloadConfig);
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _discoveredWorkload?;
    get discoveredWorkload(): string;
    set discoveredWorkload(value: string);
    get discoveredWorkloadInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get state(): string;
    get uid(): string;
    get updateTime(): string;
    private _workloadId?;
    get workloadId(): string;
    set workloadId(value: string);
    get workloadIdInput(): string | undefined;
    private _workloadProperties;
    get workloadProperties(): ApphubWorkloadWorkloadPropertiesList;
    private _workloadReference;
    get workloadReference(): ApphubWorkloadWorkloadReferenceList;
    private _attributes;
    get attributes(): ApphubWorkloadAttributesOutputReference;
    putAttributes(value: ApphubWorkloadAttributes): void;
    resetAttributes(): void;
    get attributesInput(): ApphubWorkloadAttributes | undefined;
    private _timeouts;
    get timeouts(): ApphubWorkloadTimeoutsOutputReference;
    putTimeouts(value: ApphubWorkloadTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApphubWorkloadTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
