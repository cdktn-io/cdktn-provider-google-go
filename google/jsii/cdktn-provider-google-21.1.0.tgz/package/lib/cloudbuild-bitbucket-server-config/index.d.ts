/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudbuildBitbucketServerConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Immutable. API Key that will be attached to webhook. Once this field has been set, it cannot be changed.
    * Changing this field will result in deleting/ recreating the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_bitbucket_server_config#api_key CloudbuildBitbucketServerConfig#api_key}
    */
    readonly apiKey: string;
    /**
    * The ID to use for the BitbucketServerConfig, which will become the final component of the BitbucketServerConfig's resource name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_bitbucket_server_config#config_id CloudbuildBitbucketServerConfig#config_id}
    */
    readonly configId: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_bitbucket_server_config#deletion_policy CloudbuildBitbucketServerConfig#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Immutable. The URI of the Bitbucket Server host. Once this field has been set, it cannot be changed.
    * If you need to change it, please create another BitbucketServerConfig.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_bitbucket_server_config#host_uri CloudbuildBitbucketServerConfig#host_uri}
    */
    readonly hostUri: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_bitbucket_server_config#id CloudbuildBitbucketServerConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of this bitbucket server config.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_bitbucket_server_config#location CloudbuildBitbucketServerConfig#location}
    */
    readonly location: string;
    /**
    * The network to be used when reaching out to the Bitbucket Server instance. The VPC network must be enabled for private service connection.
    * This should be set if the Bitbucket Server instance is hosted on-premises and not reachable by public internet. If this field is left empty,
    * no network peering will occur and calls to the Bitbucket Server instance will be made over the public internet. Must be in the format
    * projects/{project}/global/networks/{network}, where {project} is a project number or id and {network} is the name of a VPC network in the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_bitbucket_server_config#peered_network CloudbuildBitbucketServerConfig#peered_network}
    */
    readonly peeredNetwork?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_bitbucket_server_config#project CloudbuildBitbucketServerConfig#project}
    */
    readonly project?: string;
    /**
    * SSL certificate to use for requests to Bitbucket Server. The format should be PEM format but the extension can be one of .pem, .cer, or .crt.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_bitbucket_server_config#ssl_ca CloudbuildBitbucketServerConfig#ssl_ca}
    */
    readonly sslCa?: string;
    /**
    * Username of the account Cloud Build will use on Bitbucket Server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_bitbucket_server_config#username CloudbuildBitbucketServerConfig#username}
    */
    readonly username: string;
    /**
    * connected_repositories block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_bitbucket_server_config#connected_repositories CloudbuildBitbucketServerConfig#connected_repositories}
    */
    readonly connectedRepositories?: CloudbuildBitbucketServerConfigConnectedRepositories[] | cdktn.IResolvable;
    /**
    * secrets block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_bitbucket_server_config#secrets CloudbuildBitbucketServerConfig#secrets}
    */
    readonly secrets: CloudbuildBitbucketServerConfigSecrets;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_bitbucket_server_config#timeouts CloudbuildBitbucketServerConfig#timeouts}
    */
    readonly timeouts?: CloudbuildBitbucketServerConfigTimeouts;
}
export interface CloudbuildBitbucketServerConfigConnectedRepositories {
    /**
    * Identifier for the project storing the repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_bitbucket_server_config#project_key CloudbuildBitbucketServerConfig#project_key}
    */
    readonly projectKey: string;
    /**
    * Identifier for the repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_bitbucket_server_config#repo_slug CloudbuildBitbucketServerConfig#repo_slug}
    */
    readonly repoSlug: string;
}
export declare function cloudbuildBitbucketServerConfigConnectedRepositoriesToTerraform(struct?: CloudbuildBitbucketServerConfigConnectedRepositories | cdktn.IResolvable): any;
export declare function cloudbuildBitbucketServerConfigConnectedRepositoriesToHclTerraform(struct?: CloudbuildBitbucketServerConfigConnectedRepositories | cdktn.IResolvable): any;
export declare class CloudbuildBitbucketServerConfigConnectedRepositoriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudbuildBitbucketServerConfigConnectedRepositories | cdktn.IResolvable | undefined;
    set internalValue(value: CloudbuildBitbucketServerConfigConnectedRepositories | cdktn.IResolvable | undefined);
    private _projectKey?;
    get projectKey(): string;
    set projectKey(value: string);
    get projectKeyInput(): string | undefined;
    private _repoSlug?;
    get repoSlug(): string;
    set repoSlug(value: string);
    get repoSlugInput(): string | undefined;
}
export declare class CloudbuildBitbucketServerConfigConnectedRepositoriesList extends cdktn.ComplexList {
    internalValue?: CloudbuildBitbucketServerConfigConnectedRepositories[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudbuildBitbucketServerConfigConnectedRepositoriesOutputReference;
}
export interface CloudbuildBitbucketServerConfigSecrets {
    /**
    * The resource name for the admin access token's secret version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_bitbucket_server_config#admin_access_token_version_name CloudbuildBitbucketServerConfig#admin_access_token_version_name}
    */
    readonly adminAccessTokenVersionName: string;
    /**
    * The resource name for the read access token's secret version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_bitbucket_server_config#read_access_token_version_name CloudbuildBitbucketServerConfig#read_access_token_version_name}
    */
    readonly readAccessTokenVersionName: string;
    /**
    * Immutable. The resource name for the webhook secret's secret version. Once this field has been set, it cannot be changed.
    * Changing this field will result in deleting/ recreating the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_bitbucket_server_config#webhook_secret_version_name CloudbuildBitbucketServerConfig#webhook_secret_version_name}
    */
    readonly webhookSecretVersionName: string;
}
export declare function cloudbuildBitbucketServerConfigSecretsToTerraform(struct?: CloudbuildBitbucketServerConfigSecretsOutputReference | CloudbuildBitbucketServerConfigSecrets): any;
export declare function cloudbuildBitbucketServerConfigSecretsToHclTerraform(struct?: CloudbuildBitbucketServerConfigSecretsOutputReference | CloudbuildBitbucketServerConfigSecrets): any;
export declare class CloudbuildBitbucketServerConfigSecretsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildBitbucketServerConfigSecrets | undefined;
    set internalValue(value: CloudbuildBitbucketServerConfigSecrets | undefined);
    private _adminAccessTokenVersionName?;
    get adminAccessTokenVersionName(): string;
    set adminAccessTokenVersionName(value: string);
    get adminAccessTokenVersionNameInput(): string | undefined;
    private _readAccessTokenVersionName?;
    get readAccessTokenVersionName(): string;
    set readAccessTokenVersionName(value: string);
    get readAccessTokenVersionNameInput(): string | undefined;
    private _webhookSecretVersionName?;
    get webhookSecretVersionName(): string;
    set webhookSecretVersionName(value: string);
    get webhookSecretVersionNameInput(): string | undefined;
}
export interface CloudbuildBitbucketServerConfigTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_bitbucket_server_config#create CloudbuildBitbucketServerConfig#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_bitbucket_server_config#delete CloudbuildBitbucketServerConfig#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_bitbucket_server_config#update CloudbuildBitbucketServerConfig#update}
    */
    readonly update?: string;
}
export declare function cloudbuildBitbucketServerConfigTimeoutsToTerraform(struct?: CloudbuildBitbucketServerConfigTimeouts | cdktn.IResolvable): any;
export declare function cloudbuildBitbucketServerConfigTimeoutsToHclTerraform(struct?: CloudbuildBitbucketServerConfigTimeouts | cdktn.IResolvable): any;
export declare class CloudbuildBitbucketServerConfigTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildBitbucketServerConfigTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CloudbuildBitbucketServerConfigTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_bitbucket_server_config google_cloudbuild_bitbucket_server_config}
*/
export declare class CloudbuildBitbucketServerConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_cloudbuild_bitbucket_server_config";
    /**
    * Generates CDKTN code for importing a CloudbuildBitbucketServerConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudbuildBitbucketServerConfig to import
    * @param importFromId The id of the existing CloudbuildBitbucketServerConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_bitbucket_server_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudbuildBitbucketServerConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_bitbucket_server_config google_cloudbuild_bitbucket_server_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudbuildBitbucketServerConfigConfig
    */
    constructor(scope: Construct, id: string, config: CloudbuildBitbucketServerConfigConfig);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    get apiKeyInput(): string | undefined;
    private _configId?;
    get configId(): string;
    set configId(value: string);
    get configIdInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _hostUri?;
    get hostUri(): string;
    set hostUri(value: string);
    get hostUriInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _peeredNetwork?;
    get peeredNetwork(): string;
    set peeredNetwork(value: string);
    resetPeeredNetwork(): void;
    get peeredNetworkInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _sslCa?;
    get sslCa(): string;
    set sslCa(value: string);
    resetSslCa(): void;
    get sslCaInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
    get webhookKey(): string;
    private _connectedRepositories;
    get connectedRepositories(): CloudbuildBitbucketServerConfigConnectedRepositoriesList;
    putConnectedRepositories(value: CloudbuildBitbucketServerConfigConnectedRepositories[] | cdktn.IResolvable): void;
    resetConnectedRepositories(): void;
    get connectedRepositoriesInput(): cdktn.IResolvable | CloudbuildBitbucketServerConfigConnectedRepositories[] | undefined;
    private _secrets;
    get secrets(): CloudbuildBitbucketServerConfigSecretsOutputReference;
    putSecrets(value: CloudbuildBitbucketServerConfigSecrets): void;
    get secretsInput(): CloudbuildBitbucketServerConfigSecrets | undefined;
    private _timeouts;
    get timeouts(): CloudbuildBitbucketServerConfigTimeoutsOutputReference;
    putTimeouts(value: CloudbuildBitbucketServerConfigTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CloudbuildBitbucketServerConfigTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
