/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigeeSecurityFeedbackConfig extends cdktn.TerraformMetaArguments {
    /**
    * Optional text the user can provide for additional, unstructured context.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_feedback#comment ApigeeSecurityFeedback#comment}
    */
    readonly comment?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_feedback#deletion_policy ApigeeSecurityFeedback#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The display name of the feedback.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_feedback#display_name ApigeeSecurityFeedback#display_name}
    */
    readonly displayName?: string;
    /**
    * Resource ID of the security feedback.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_feedback#feedback_id ApigeeSecurityFeedback#feedback_id}
    */
    readonly feedbackId: string;
    /**
    * The type of feedback being submitted. Possible values: ["EXCLUDED_DETECTION"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_feedback#feedback_type ApigeeSecurityFeedback#feedback_type}
    */
    readonly feedbackType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_feedback#id ApigeeSecurityFeedback#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The Apigee Organization associated with the Apigee Security Feedback,
    * in the format 'organizations/{{org_name}}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_feedback#org_id ApigeeSecurityFeedback#org_id}
    */
    readonly orgId: string;
    /**
    * The reason for the feedback. Possible values: ["INTERNAL_SYSTEM", "NON_RISK_CLIENT", "NAT", "PENETRATION_TEST", "OTHER"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_feedback#reason ApigeeSecurityFeedback#reason}
    */
    readonly reason?: string;
    /**
    * feedback_contexts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_feedback#feedback_contexts ApigeeSecurityFeedback#feedback_contexts}
    */
    readonly feedbackContexts: ApigeeSecurityFeedbackFeedbackContexts[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_feedback#timeouts ApigeeSecurityFeedback#timeouts}
    */
    readonly timeouts?: ApigeeSecurityFeedbackTimeouts;
}
export interface ApigeeSecurityFeedbackFeedbackContexts {
    /**
    * The attribute the user is providing feedback about. Possible values: ["ATTRIBUTE_ENVIRONMENTS", "ATTRIBUTE_IP_ADDRESS_RANGES"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_feedback#attribute ApigeeSecurityFeedback#attribute}
    */
    readonly attribute: string;
    /**
    * The values of the attribute the user is providing feedback about, separated by commas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_feedback#values ApigeeSecurityFeedback#values}
    */
    readonly values: string[];
}
export declare function apigeeSecurityFeedbackFeedbackContextsToTerraform(struct?: ApigeeSecurityFeedbackFeedbackContexts | cdktn.IResolvable): any;
export declare function apigeeSecurityFeedbackFeedbackContextsToHclTerraform(struct?: ApigeeSecurityFeedbackFeedbackContexts | cdktn.IResolvable): any;
export declare class ApigeeSecurityFeedbackFeedbackContextsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigeeSecurityFeedbackFeedbackContexts | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeSecurityFeedbackFeedbackContexts | cdktn.IResolvable | undefined);
    private _attribute?;
    get attribute(): string;
    set attribute(value: string);
    get attributeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class ApigeeSecurityFeedbackFeedbackContextsList extends cdktn.ComplexList {
    internalValue?: ApigeeSecurityFeedbackFeedbackContexts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigeeSecurityFeedbackFeedbackContextsOutputReference;
}
export interface ApigeeSecurityFeedbackTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_feedback#create ApigeeSecurityFeedback#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_feedback#delete ApigeeSecurityFeedback#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_feedback#update ApigeeSecurityFeedback#update}
    */
    readonly update?: string;
}
export declare function apigeeSecurityFeedbackTimeoutsToTerraform(struct?: ApigeeSecurityFeedbackTimeouts | cdktn.IResolvable): any;
export declare function apigeeSecurityFeedbackTimeoutsToHclTerraform(struct?: ApigeeSecurityFeedbackTimeouts | cdktn.IResolvable): any;
export declare class ApigeeSecurityFeedbackTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeSecurityFeedbackTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeSecurityFeedbackTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_feedback google_apigee_security_feedback}
*/
export declare class ApigeeSecurityFeedback extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apigee_security_feedback";
    /**
    * Generates CDKTN code for importing a ApigeeSecurityFeedback resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigeeSecurityFeedback to import
    * @param importFromId The id of the existing ApigeeSecurityFeedback that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_feedback#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigeeSecurityFeedback to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_feedback google_apigee_security_feedback} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigeeSecurityFeedbackConfig
    */
    constructor(scope: Construct, id: string, config: ApigeeSecurityFeedbackConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _feedbackId?;
    get feedbackId(): string;
    set feedbackId(value: string);
    get feedbackIdInput(): string | undefined;
    private _feedbackType?;
    get feedbackType(): string;
    set feedbackType(value: string);
    get feedbackTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _orgId?;
    get orgId(): string;
    set orgId(value: string);
    get orgIdInput(): string | undefined;
    private _reason?;
    get reason(): string;
    set reason(value: string);
    resetReason(): void;
    get reasonInput(): string | undefined;
    get updateTime(): string;
    private _feedbackContexts;
    get feedbackContexts(): ApigeeSecurityFeedbackFeedbackContextsList;
    putFeedbackContexts(value: ApigeeSecurityFeedbackFeedbackContexts[] | cdktn.IResolvable): void;
    get feedbackContextsInput(): cdktn.IResolvable | ApigeeSecurityFeedbackFeedbackContexts[] | undefined;
    private _timeouts;
    get timeouts(): ApigeeSecurityFeedbackTimeoutsOutputReference;
    putTimeouts(value: ApigeeSecurityFeedbackTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApigeeSecurityFeedbackTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
