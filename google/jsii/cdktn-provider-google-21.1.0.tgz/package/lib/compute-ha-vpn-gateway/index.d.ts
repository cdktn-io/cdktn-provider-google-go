/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeHaVpnGatewayConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_ha_vpn_gateway#deletion_policy ComputeHaVpnGateway#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_ha_vpn_gateway#description ComputeHaVpnGateway#description}
    */
    readonly description?: string;
    /**
    * The IP family of the gateway IPs for the HA-VPN gateway interfaces. If not specified, IPV4 will be used. Default value: "IPV4" Possible values: ["IPV4", "IPV6"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_ha_vpn_gateway#gateway_ip_version ComputeHaVpnGateway#gateway_ip_version}
    */
    readonly gatewayIpVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_ha_vpn_gateway#id ComputeHaVpnGateway#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Labels for this resource. These can only be added or modified by the setLabels method.
    * Each label key/value pair must comply with RFC1035. Label values may be empty.
    *
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_ha_vpn_gateway#labels ComputeHaVpnGateway#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the resource. Provided by the client when the resource is
    * created. The name must be 1-63 characters long, and comply with
    * RFC1035.  Specifically, the name must be 1-63 characters long and
    * match the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means
    * the first character must be a lowercase letter, and all following
    * characters must be a dash, lowercase letter, or digit, except the last
    * character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_ha_vpn_gateway#name ComputeHaVpnGateway#name}
    */
    readonly name: string;
    /**
    * The network this VPN gateway is accepting traffic for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_ha_vpn_gateway#network ComputeHaVpnGateway#network}
    */
    readonly network: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_ha_vpn_gateway#project ComputeHaVpnGateway#project}
    */
    readonly project?: string;
    /**
    * The region this gateway should sit in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_ha_vpn_gateway#region ComputeHaVpnGateway#region}
    */
    readonly region?: string;
    /**
    * The stack type for this VPN gateway to identify the IP protocols that are enabled.
    * If not specified, IPV4_ONLY will be used. Default value: "IPV4_ONLY" Possible values: ["IPV4_ONLY", "IPV4_IPV6", "IPV6_ONLY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_ha_vpn_gateway#stack_type ComputeHaVpnGateway#stack_type}
    */
    readonly stackType?: string;
    /**
    * params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_ha_vpn_gateway#params ComputeHaVpnGateway#params}
    */
    readonly params?: ComputeHaVpnGatewayParams;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_ha_vpn_gateway#timeouts ComputeHaVpnGateway#timeouts}
    */
    readonly timeouts?: ComputeHaVpnGatewayTimeouts;
    /**
    * vpn_interfaces block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_ha_vpn_gateway#vpn_interfaces ComputeHaVpnGateway#vpn_interfaces}
    */
    readonly vpnInterfaces?: ComputeHaVpnGatewayVpnInterfaces[] | cdktn.IResolvable;
}
export interface ComputeHaVpnGatewayParams {
    /**
    * Resource manager tags to be bound to the HaVpnGateway. Tag keys and values have the
    * same definition as resource manager tags. Keys must be in the format tagKeys/{tag_key_id},
    * and values are in the format tagValues/456.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_ha_vpn_gateway#resource_manager_tags ComputeHaVpnGateway#resource_manager_tags}
    */
    readonly resourceManagerTags?: {
        [key: string]: string;
    };
}
export declare function computeHaVpnGatewayParamsToTerraform(struct?: ComputeHaVpnGatewayParamsOutputReference | ComputeHaVpnGatewayParams): any;
export declare function computeHaVpnGatewayParamsToHclTerraform(struct?: ComputeHaVpnGatewayParamsOutputReference | ComputeHaVpnGatewayParams): any;
export declare class ComputeHaVpnGatewayParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeHaVpnGatewayParams | undefined;
    set internalValue(value: ComputeHaVpnGatewayParams | undefined);
    private _resourceManagerTags?;
    get resourceManagerTags(): {
        [key: string]: string;
    };
    set resourceManagerTags(value: {
        [key: string]: string;
    });
    resetResourceManagerTags(): void;
    get resourceManagerTagsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ComputeHaVpnGatewayTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_ha_vpn_gateway#create ComputeHaVpnGateway#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_ha_vpn_gateway#delete ComputeHaVpnGateway#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_ha_vpn_gateway#update ComputeHaVpnGateway#update}
    */
    readonly update?: string;
}
export declare function computeHaVpnGatewayTimeoutsToTerraform(struct?: ComputeHaVpnGatewayTimeouts | cdktn.IResolvable): any;
export declare function computeHaVpnGatewayTimeoutsToHclTerraform(struct?: ComputeHaVpnGatewayTimeouts | cdktn.IResolvable): any;
export declare class ComputeHaVpnGatewayTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeHaVpnGatewayTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeHaVpnGatewayTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface ComputeHaVpnGatewayVpnInterfaces {
    /**
    * The numeric ID of this VPN gateway interface.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_ha_vpn_gateway#id ComputeHaVpnGateway#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: number;
    /**
    * URL of the interconnect attachment resource. When the value
    * of this field is present, the VPN Gateway will be used for
    * IPsec-encrypted Cloud Interconnect; all Egress or Ingress
    * traffic for this VPN Gateway interface will go through the
    * specified interconnect attachment resource.
    *
    * Not currently available publicly.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_ha_vpn_gateway#interconnect_attachment ComputeHaVpnGateway#interconnect_attachment}
    */
    readonly interconnectAttachment?: string;
}
export declare function computeHaVpnGatewayVpnInterfacesToTerraform(struct?: ComputeHaVpnGatewayVpnInterfaces | cdktn.IResolvable): any;
export declare function computeHaVpnGatewayVpnInterfacesToHclTerraform(struct?: ComputeHaVpnGatewayVpnInterfaces | cdktn.IResolvable): any;
export declare class ComputeHaVpnGatewayVpnInterfacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeHaVpnGatewayVpnInterfaces | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeHaVpnGatewayVpnInterfaces | cdktn.IResolvable | undefined);
    private _id?;
    get id(): number;
    set id(value: number);
    resetId(): void;
    get idInput(): number | undefined;
    private _interconnectAttachment?;
    get interconnectAttachment(): string;
    set interconnectAttachment(value: string);
    resetInterconnectAttachment(): void;
    get interconnectAttachmentInput(): string | undefined;
    get ipAddress(): string;
}
export declare class ComputeHaVpnGatewayVpnInterfacesList extends cdktn.ComplexList {
    internalValue?: ComputeHaVpnGatewayVpnInterfaces[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeHaVpnGatewayVpnInterfacesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_ha_vpn_gateway google_compute_ha_vpn_gateway}
*/
export declare class ComputeHaVpnGateway extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_ha_vpn_gateway";
    /**
    * Generates CDKTN code for importing a ComputeHaVpnGateway resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeHaVpnGateway to import
    * @param importFromId The id of the existing ComputeHaVpnGateway that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_ha_vpn_gateway#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeHaVpnGateway to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_ha_vpn_gateway google_compute_ha_vpn_gateway} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeHaVpnGatewayConfig
    */
    constructor(scope: Construct, id: string, config: ComputeHaVpnGatewayConfig);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _gatewayIpVersion?;
    get gatewayIpVersion(): string;
    set gatewayIpVersion(value: string);
    resetGatewayIpVersion(): void;
    get gatewayIpVersionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get labelFingerprint(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _network?;
    get network(): string;
    set network(value: string);
    get networkInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get selfLink(): string;
    private _stackType?;
    get stackType(): string;
    set stackType(value: string);
    resetStackType(): void;
    get stackTypeInput(): string | undefined;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _params;
    get params(): ComputeHaVpnGatewayParamsOutputReference;
    putParams(value: ComputeHaVpnGatewayParams): void;
    resetParams(): void;
    get paramsInput(): ComputeHaVpnGatewayParams | undefined;
    private _timeouts;
    get timeouts(): ComputeHaVpnGatewayTimeoutsOutputReference;
    putTimeouts(value: ComputeHaVpnGatewayTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeHaVpnGatewayTimeouts | undefined;
    private _vpnInterfaces;
    get vpnInterfaces(): ComputeHaVpnGatewayVpnInterfacesList;
    putVpnInterfaces(value: ComputeHaVpnGatewayVpnInterfaces[] | cdktn.IResolvable): void;
    resetVpnInterfaces(): void;
    get vpnInterfacesInput(): cdktn.IResolvable | ComputeHaVpnGatewayVpnInterfaces[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
