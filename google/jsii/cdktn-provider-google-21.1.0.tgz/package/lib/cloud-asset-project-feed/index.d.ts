/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudAssetProjectFeedConfig extends cdktn.TerraformMetaArguments {
    /**
    * A list of the full names of the assets to receive updates. You must specify either or both of
    * assetNames and assetTypes. Only asset updates matching specified assetNames and assetTypes are
    * exported to the feed. For example: //compute.googleapis.com/projects/my_project_123/zones/zone1/instances/instance1.
    * See https://cloud.google.com/apis/design/resourceNames#fullResourceName for more info.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_asset_project_feed#asset_names CloudAssetProjectFeed#asset_names}
    */
    readonly assetNames?: string[];
    /**
    * A list of types of the assets to receive updates. You must specify either or both of assetNames
    * and assetTypes. Only asset updates matching specified assetNames and assetTypes are exported to
    * the feed. For example: "compute.googleapis.com/Disk"
    * See https://cloud.google.com/asset-inventory/docs/supported-asset-types for a list of all
    * supported asset types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_asset_project_feed#asset_types CloudAssetProjectFeed#asset_types}
    */
    readonly assetTypes?: string[];
    /**
    * The project whose identity will be used when sending messages to the
    * destination pubsub topic. It also specifies the project for API
    * enablement check, quota, and billing. If not specified, the resource's
    * project will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_asset_project_feed#billing_project CloudAssetProjectFeed#billing_project}
    */
    readonly billingProject?: string;
    /**
    * Asset content type. If not specified, no content but the asset name and type will be returned. Possible values: ["CONTENT_TYPE_UNSPECIFIED", "RESOURCE", "IAM_POLICY", "ORG_POLICY", "OS_INVENTORY", "ACCESS_POLICY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_asset_project_feed#content_type CloudAssetProjectFeed#content_type}
    */
    readonly contentType?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_asset_project_feed#deletion_policy CloudAssetProjectFeed#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * This is the client-assigned asset feed identifier and it needs to be unique under a specific parent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_asset_project_feed#feed_id CloudAssetProjectFeed#feed_id}
    */
    readonly feedId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_asset_project_feed#id CloudAssetProjectFeed#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_asset_project_feed#project CloudAssetProjectFeed#project}
    */
    readonly project?: string;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_asset_project_feed#condition CloudAssetProjectFeed#condition}
    */
    readonly condition?: CloudAssetProjectFeedCondition;
    /**
    * feed_output_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_asset_project_feed#feed_output_config CloudAssetProjectFeed#feed_output_config}
    */
    readonly feedOutputConfig: CloudAssetProjectFeedFeedOutputConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_asset_project_feed#timeouts CloudAssetProjectFeed#timeouts}
    */
    readonly timeouts?: CloudAssetProjectFeedTimeouts;
}
export interface CloudAssetProjectFeedCondition {
    /**
    * Description of the expression. This is a longer text which describes the expression,
    * e.g. when hovered over it in a UI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_asset_project_feed#description CloudAssetProjectFeed#description}
    */
    readonly description?: string;
    /**
    * Textual representation of an expression in Common Expression Language syntax.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_asset_project_feed#expression CloudAssetProjectFeed#expression}
    */
    readonly expression: string;
    /**
    * String indicating the location of the expression for error reporting, e.g. a file
    * name and a position in the file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_asset_project_feed#location CloudAssetProjectFeed#location}
    */
    readonly location?: string;
    /**
    * Title for the expression, i.e. a short string describing its purpose.
    * This can be used e.g. in UIs which allow to enter the expression.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_asset_project_feed#title CloudAssetProjectFeed#title}
    */
    readonly title?: string;
}
export declare function cloudAssetProjectFeedConditionToTerraform(struct?: CloudAssetProjectFeedConditionOutputReference | CloudAssetProjectFeedCondition): any;
export declare function cloudAssetProjectFeedConditionToHclTerraform(struct?: CloudAssetProjectFeedConditionOutputReference | CloudAssetProjectFeedCondition): any;
export declare class CloudAssetProjectFeedConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAssetProjectFeedCondition | undefined;
    set internalValue(value: CloudAssetProjectFeedCondition | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
}
export interface CloudAssetProjectFeedFeedOutputConfigPubsubDestination {
    /**
    * Destination on Cloud Pubsub topic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_asset_project_feed#topic CloudAssetProjectFeed#topic}
    */
    readonly topic: string;
}
export declare function cloudAssetProjectFeedFeedOutputConfigPubsubDestinationToTerraform(struct?: CloudAssetProjectFeedFeedOutputConfigPubsubDestinationOutputReference | CloudAssetProjectFeedFeedOutputConfigPubsubDestination): any;
export declare function cloudAssetProjectFeedFeedOutputConfigPubsubDestinationToHclTerraform(struct?: CloudAssetProjectFeedFeedOutputConfigPubsubDestinationOutputReference | CloudAssetProjectFeedFeedOutputConfigPubsubDestination): any;
export declare class CloudAssetProjectFeedFeedOutputConfigPubsubDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAssetProjectFeedFeedOutputConfigPubsubDestination | undefined;
    set internalValue(value: CloudAssetProjectFeedFeedOutputConfigPubsubDestination | undefined);
    private _topic?;
    get topic(): string;
    set topic(value: string);
    get topicInput(): string | undefined;
}
export interface CloudAssetProjectFeedFeedOutputConfig {
    /**
    * pubsub_destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_asset_project_feed#pubsub_destination CloudAssetProjectFeed#pubsub_destination}
    */
    readonly pubsubDestination: CloudAssetProjectFeedFeedOutputConfigPubsubDestination;
}
export declare function cloudAssetProjectFeedFeedOutputConfigToTerraform(struct?: CloudAssetProjectFeedFeedOutputConfigOutputReference | CloudAssetProjectFeedFeedOutputConfig): any;
export declare function cloudAssetProjectFeedFeedOutputConfigToHclTerraform(struct?: CloudAssetProjectFeedFeedOutputConfigOutputReference | CloudAssetProjectFeedFeedOutputConfig): any;
export declare class CloudAssetProjectFeedFeedOutputConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAssetProjectFeedFeedOutputConfig | undefined;
    set internalValue(value: CloudAssetProjectFeedFeedOutputConfig | undefined);
    private _pubsubDestination;
    get pubsubDestination(): CloudAssetProjectFeedFeedOutputConfigPubsubDestinationOutputReference;
    putPubsubDestination(value: CloudAssetProjectFeedFeedOutputConfigPubsubDestination): void;
    get pubsubDestinationInput(): CloudAssetProjectFeedFeedOutputConfigPubsubDestination | undefined;
}
export interface CloudAssetProjectFeedTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_asset_project_feed#create CloudAssetProjectFeed#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_asset_project_feed#delete CloudAssetProjectFeed#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_asset_project_feed#update CloudAssetProjectFeed#update}
    */
    readonly update?: string;
}
export declare function cloudAssetProjectFeedTimeoutsToTerraform(struct?: CloudAssetProjectFeedTimeouts | cdktn.IResolvable): any;
export declare function cloudAssetProjectFeedTimeoutsToHclTerraform(struct?: CloudAssetProjectFeedTimeouts | cdktn.IResolvable): any;
export declare class CloudAssetProjectFeedTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAssetProjectFeedTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CloudAssetProjectFeedTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_asset_project_feed google_cloud_asset_project_feed}
*/
export declare class CloudAssetProjectFeed extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_cloud_asset_project_feed";
    /**
    * Generates CDKTN code for importing a CloudAssetProjectFeed resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudAssetProjectFeed to import
    * @param importFromId The id of the existing CloudAssetProjectFeed that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_asset_project_feed#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudAssetProjectFeed to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_asset_project_feed google_cloud_asset_project_feed} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudAssetProjectFeedConfig
    */
    constructor(scope: Construct, id: string, config: CloudAssetProjectFeedConfig);
    private _assetNames?;
    get assetNames(): string[];
    set assetNames(value: string[]);
    resetAssetNames(): void;
    get assetNamesInput(): string[] | undefined;
    private _assetTypes?;
    get assetTypes(): string[];
    set assetTypes(value: string[]);
    resetAssetTypes(): void;
    get assetTypesInput(): string[] | undefined;
    private _billingProject?;
    get billingProject(): string;
    set billingProject(value: string);
    resetBillingProject(): void;
    get billingProjectInput(): string | undefined;
    private _contentType?;
    get contentType(): string;
    set contentType(value: string);
    resetContentType(): void;
    get contentTypeInput(): string | undefined;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _feedId?;
    get feedId(): string;
    set feedId(value: string);
    get feedIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _condition;
    get condition(): CloudAssetProjectFeedConditionOutputReference;
    putCondition(value: CloudAssetProjectFeedCondition): void;
    resetCondition(): void;
    get conditionInput(): CloudAssetProjectFeedCondition | undefined;
    private _feedOutputConfig;
    get feedOutputConfig(): CloudAssetProjectFeedFeedOutputConfigOutputReference;
    putFeedOutputConfig(value: CloudAssetProjectFeedFeedOutputConfig): void;
    get feedOutputConfigInput(): CloudAssetProjectFeedFeedOutputConfig | undefined;
    private _timeouts;
    get timeouts(): CloudAssetProjectFeedTimeoutsOutputReference;
    putTimeouts(value: CloudAssetProjectFeedTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CloudAssetProjectFeedTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
