/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigeeSecurityMonitoringConditionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Resource ID of the security monitoring condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_monitoring_condition#condition_id ApigeeSecurityMonitoringCondition#condition_id}
    */
    readonly conditionId: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_monitoring_condition#deletion_policy ApigeeSecurityMonitoringCondition#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_monitoring_condition#id ApigeeSecurityMonitoringCondition#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The Apigee Organization associated with the Apigee Security Monitoring Condition,
    * in the format 'organizations/{{org_name}}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_monitoring_condition#org_id ApigeeSecurityMonitoringCondition#org_id}
    */
    readonly orgId: string;
    /**
    * ID of security profile of the security monitoring condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_monitoring_condition#profile ApigeeSecurityMonitoringCondition#profile}
    */
    readonly profile: string;
    /**
    * ID of security profile of the security monitoring condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_monitoring_condition#scope ApigeeSecurityMonitoringCondition#scope}
    */
    readonly scope: string;
    /**
    * include_all_resources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_monitoring_condition#include_all_resources ApigeeSecurityMonitoringCondition#include_all_resources}
    */
    readonly includeAllResources?: ApigeeSecurityMonitoringConditionIncludeAllResources;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_monitoring_condition#timeouts ApigeeSecurityMonitoringCondition#timeouts}
    */
    readonly timeouts?: ApigeeSecurityMonitoringConditionTimeouts;
}
export interface ApigeeSecurityMonitoringConditionIncludeAllResources {
}
export declare function apigeeSecurityMonitoringConditionIncludeAllResourcesToTerraform(struct?: ApigeeSecurityMonitoringConditionIncludeAllResourcesOutputReference | ApigeeSecurityMonitoringConditionIncludeAllResources): any;
export declare function apigeeSecurityMonitoringConditionIncludeAllResourcesToHclTerraform(struct?: ApigeeSecurityMonitoringConditionIncludeAllResourcesOutputReference | ApigeeSecurityMonitoringConditionIncludeAllResources): any;
export declare class ApigeeSecurityMonitoringConditionIncludeAllResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeSecurityMonitoringConditionIncludeAllResources | undefined;
    set internalValue(value: ApigeeSecurityMonitoringConditionIncludeAllResources | undefined);
}
export interface ApigeeSecurityMonitoringConditionTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_monitoring_condition#create ApigeeSecurityMonitoringCondition#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_monitoring_condition#delete ApigeeSecurityMonitoringCondition#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_monitoring_condition#update ApigeeSecurityMonitoringCondition#update}
    */
    readonly update?: string;
}
export declare function apigeeSecurityMonitoringConditionTimeoutsToTerraform(struct?: ApigeeSecurityMonitoringConditionTimeouts | cdktn.IResolvable): any;
export declare function apigeeSecurityMonitoringConditionTimeoutsToHclTerraform(struct?: ApigeeSecurityMonitoringConditionTimeouts | cdktn.IResolvable): any;
export declare class ApigeeSecurityMonitoringConditionTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeSecurityMonitoringConditionTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeSecurityMonitoringConditionTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_monitoring_condition google_apigee_security_monitoring_condition}
*/
export declare class ApigeeSecurityMonitoringCondition extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apigee_security_monitoring_condition";
    /**
    * Generates CDKTN code for importing a ApigeeSecurityMonitoringCondition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigeeSecurityMonitoringCondition to import
    * @param importFromId The id of the existing ApigeeSecurityMonitoringCondition that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_monitoring_condition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigeeSecurityMonitoringCondition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_monitoring_condition google_apigee_security_monitoring_condition} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigeeSecurityMonitoringConditionConfig
    */
    constructor(scope: Construct, id: string, config: ApigeeSecurityMonitoringConditionConfig);
    private _conditionId?;
    get conditionId(): string;
    set conditionId(value: string);
    get conditionIdInput(): string | undefined;
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _orgId?;
    get orgId(): string;
    set orgId(value: string);
    get orgIdInput(): string | undefined;
    private _profile?;
    get profile(): string;
    set profile(value: string);
    get profileInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
    get totalDeployedResources(): number;
    get totalMonitoredResources(): number;
    get updateTime(): string;
    private _includeAllResources;
    get includeAllResources(): ApigeeSecurityMonitoringConditionIncludeAllResourcesOutputReference;
    putIncludeAllResources(value: ApigeeSecurityMonitoringConditionIncludeAllResources): void;
    resetIncludeAllResources(): void;
    get includeAllResourcesInput(): ApigeeSecurityMonitoringConditionIncludeAllResources | undefined;
    private _timeouts;
    get timeouts(): ApigeeSecurityMonitoringConditionTimeoutsOutputReference;
    putTimeouts(value: ApigeeSecurityMonitoringConditionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApigeeSecurityMonitoringConditionTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
