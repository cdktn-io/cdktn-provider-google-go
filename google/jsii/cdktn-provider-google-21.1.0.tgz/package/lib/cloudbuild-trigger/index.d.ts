/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudbuildTriggerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#deletion_policy CloudbuildTrigger#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Human-readable description of the trigger.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#description CloudbuildTrigger#description}
    */
    readonly description?: string;
    /**
    * Whether the trigger is disabled or not. If true, the trigger will never result in a build.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#disabled CloudbuildTrigger#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Path, from the source root, to a file whose contents is used for the template.
    * Either a filename or build template must be provided. Set this only when using trigger_template or github.
    * When using Pub/Sub, Webhook or Manual set the file name using git_file_source instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#filename CloudbuildTrigger#filename}
    */
    readonly filename?: string;
    /**
    * A Common Expression Language string. Used only with Pub/Sub and Webhook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#filter CloudbuildTrigger#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#id CloudbuildTrigger#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * ignoredFiles and includedFiles are file glob matches using https://golang.org/pkg/path/filepath/#Match
    * extended with support for '**'.
    *
    * If ignoredFiles and changed files are both empty, then they are not
    * used to determine whether or not to trigger a build.
    *
    * If ignoredFiles is not empty, then we ignore any files that match any
    * of the ignored_file globs. If the change has no files that are outside
    * of the ignoredFiles globs, then we do not trigger a build.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#ignored_files CloudbuildTrigger#ignored_files}
    */
    readonly ignoredFiles?: string[];
    /**
    * Build logs will be sent back to GitHub as part of the checkrun
    * result.  Values can be INCLUDE_BUILD_LOGS_UNSPECIFIED or
    * INCLUDE_BUILD_LOGS_WITH_STATUS Possible values: ["INCLUDE_BUILD_LOGS_UNSPECIFIED", "INCLUDE_BUILD_LOGS_WITH_STATUS"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#include_build_logs CloudbuildTrigger#include_build_logs}
    */
    readonly includeBuildLogs?: string;
    /**
    * ignoredFiles and includedFiles are file glob matches using https://golang.org/pkg/path/filepath/#Match
    * extended with support for '**'.
    *
    * If any of the files altered in the commit pass the ignoredFiles filter
    * and includedFiles is empty, then as far as this filter is concerned, we
    * should trigger the build.
    *
    * If any of the files altered in the commit pass the ignoredFiles filter
    * and includedFiles is not empty, then we make sure that at least one of
    * those files matches a includedFiles glob. If not, then we do not trigger
    * a build.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#included_files CloudbuildTrigger#included_files}
    */
    readonly includedFiles?: string[];
    /**
    * The [Cloud Build location](https://cloud.google.com/build/docs/locations) for the trigger.
    * If not specified, "global" is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#location CloudbuildTrigger#location}
    */
    readonly location?: string;
    /**
    * Name of the trigger. Must be unique within the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#name CloudbuildTrigger#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#project CloudbuildTrigger#project}
    */
    readonly project?: string;
    /**
    * The service account used for all user-controlled operations including
    * triggers.patch, triggers.run, builds.create, and builds.cancel.
    *
    * If no service account is set, then the standard Cloud Build service account
    * ([PROJECT_NUM]@system.gserviceaccount.com) will be used instead.
    *
    * Format: projects/{PROJECT_ID}/serviceAccounts/{ACCOUNT_ID_OR_EMAIL}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#service_account CloudbuildTrigger#service_account}
    */
    readonly serviceAccount?: string;
    /**
    * Substitutions data for Build resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#substitutions CloudbuildTrigger#substitutions}
    */
    readonly substitutions?: {
        [key: string]: string;
    };
    /**
    * Tags for annotation of a BuildTrigger
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#tags CloudbuildTrigger#tags}
    */
    readonly tags?: string[];
    /**
    * approval_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#approval_config CloudbuildTrigger#approval_config}
    */
    readonly approvalConfig?: CloudbuildTriggerApprovalConfig;
    /**
    * bitbucket_server_trigger_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#bitbucket_server_trigger_config CloudbuildTrigger#bitbucket_server_trigger_config}
    */
    readonly bitbucketServerTriggerConfig?: CloudbuildTriggerBitbucketServerTriggerConfig;
    /**
    * build block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#build CloudbuildTrigger#build}
    */
    readonly buildAttribute?: CloudbuildTriggerBuild;
    /**
    * developer_connect_event_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#developer_connect_event_config CloudbuildTrigger#developer_connect_event_config}
    */
    readonly developerConnectEventConfig?: CloudbuildTriggerDeveloperConnectEventConfig;
    /**
    * git_file_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#git_file_source CloudbuildTrigger#git_file_source}
    */
    readonly gitFileSource?: CloudbuildTriggerGitFileSource;
    /**
    * github block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#github CloudbuildTrigger#github}
    */
    readonly github?: CloudbuildTriggerGithub;
    /**
    * pubsub_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#pubsub_config CloudbuildTrigger#pubsub_config}
    */
    readonly pubsubConfig?: CloudbuildTriggerPubsubConfig;
    /**
    * repository_event_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#repository_event_config CloudbuildTrigger#repository_event_config}
    */
    readonly repositoryEventConfig?: CloudbuildTriggerRepositoryEventConfig;
    /**
    * source_to_build block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#source_to_build CloudbuildTrigger#source_to_build}
    */
    readonly sourceToBuild?: CloudbuildTriggerSourceToBuild;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#timeouts CloudbuildTrigger#timeouts}
    */
    readonly timeouts?: CloudbuildTriggerTimeouts;
    /**
    * trigger_template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#trigger_template CloudbuildTrigger#trigger_template}
    */
    readonly triggerTemplate?: CloudbuildTriggerTriggerTemplate;
    /**
    * webhook_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#webhook_config CloudbuildTrigger#webhook_config}
    */
    readonly webhookConfig?: CloudbuildTriggerWebhookConfig;
}
export interface CloudbuildTriggerApprovalConfig {
    /**
    * Whether or not approval is needed. If this is set on a build, it will become pending when run,
    * and will need to be explicitly approved to start.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#approval_required CloudbuildTrigger#approval_required}
    */
    readonly approvalRequired?: boolean | cdktn.IResolvable;
}
export declare function cloudbuildTriggerApprovalConfigToTerraform(struct?: CloudbuildTriggerApprovalConfigOutputReference | CloudbuildTriggerApprovalConfig): any;
export declare function cloudbuildTriggerApprovalConfigToHclTerraform(struct?: CloudbuildTriggerApprovalConfigOutputReference | CloudbuildTriggerApprovalConfig): any;
export declare class CloudbuildTriggerApprovalConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildTriggerApprovalConfig | undefined;
    set internalValue(value: CloudbuildTriggerApprovalConfig | undefined);
    private _approvalRequired?;
    get approvalRequired(): boolean | cdktn.IResolvable;
    set approvalRequired(value: boolean | cdktn.IResolvable);
    resetApprovalRequired(): void;
    get approvalRequiredInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CloudbuildTriggerBitbucketServerTriggerConfigPullRequest {
    /**
    * Regex of branches to match.
    * The syntax of the regular expressions accepted is the syntax accepted by RE2 and described at https://github.com/google/re2/wiki/Syntax
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#branch CloudbuildTrigger#branch}
    */
    readonly branch: string;
    /**
    * Configure builds to run whether a repository owner or collaborator need to comment /gcbrun. Possible values: ["COMMENTS_DISABLED", "COMMENTS_ENABLED", "COMMENTS_ENABLED_FOR_EXTERNAL_CONTRIBUTORS_ONLY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#comment_control CloudbuildTrigger#comment_control}
    */
    readonly commentControl?: string;
    /**
    * If true, branches that do NOT match the git_ref will trigger a build.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#invert_regex CloudbuildTrigger#invert_regex}
    */
    readonly invertRegex?: boolean | cdktn.IResolvable;
}
export declare function cloudbuildTriggerBitbucketServerTriggerConfigPullRequestToTerraform(struct?: CloudbuildTriggerBitbucketServerTriggerConfigPullRequestOutputReference | CloudbuildTriggerBitbucketServerTriggerConfigPullRequest): any;
export declare function cloudbuildTriggerBitbucketServerTriggerConfigPullRequestToHclTerraform(struct?: CloudbuildTriggerBitbucketServerTriggerConfigPullRequestOutputReference | CloudbuildTriggerBitbucketServerTriggerConfigPullRequest): any;
export declare class CloudbuildTriggerBitbucketServerTriggerConfigPullRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildTriggerBitbucketServerTriggerConfigPullRequest | undefined;
    set internalValue(value: CloudbuildTriggerBitbucketServerTriggerConfigPullRequest | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    get branchInput(): string | undefined;
    private _commentControl?;
    get commentControl(): string;
    set commentControl(value: string);
    resetCommentControl(): void;
    get commentControlInput(): string | undefined;
    private _invertRegex?;
    get invertRegex(): boolean | cdktn.IResolvable;
    set invertRegex(value: boolean | cdktn.IResolvable);
    resetInvertRegex(): void;
    get invertRegexInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CloudbuildTriggerBitbucketServerTriggerConfigPush {
    /**
    * Regex of branches to match.  Specify only one of branch or tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#branch CloudbuildTrigger#branch}
    */
    readonly branch?: string;
    /**
    * When true, only trigger a build if the revision regex does NOT match the gitRef regex.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#invert_regex CloudbuildTrigger#invert_regex}
    */
    readonly invertRegex?: boolean | cdktn.IResolvable;
    /**
    * Regex of tags to match.  Specify only one of branch or tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#tag CloudbuildTrigger#tag}
    */
    readonly tag?: string;
}
export declare function cloudbuildTriggerBitbucketServerTriggerConfigPushToTerraform(struct?: CloudbuildTriggerBitbucketServerTriggerConfigPushOutputReference | CloudbuildTriggerBitbucketServerTriggerConfigPush): any;
export declare function cloudbuildTriggerBitbucketServerTriggerConfigPushToHclTerraform(struct?: CloudbuildTriggerBitbucketServerTriggerConfigPushOutputReference | CloudbuildTriggerBitbucketServerTriggerConfigPush): any;
export declare class CloudbuildTriggerBitbucketServerTriggerConfigPushOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildTriggerBitbucketServerTriggerConfigPush | undefined;
    set internalValue(value: CloudbuildTriggerBitbucketServerTriggerConfigPush | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _invertRegex?;
    get invertRegex(): boolean | cdktn.IResolvable;
    set invertRegex(value: boolean | cdktn.IResolvable);
    resetInvertRegex(): void;
    get invertRegexInput(): boolean | cdktn.IResolvable | undefined;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    resetTag(): void;
    get tagInput(): string | undefined;
}
export interface CloudbuildTriggerBitbucketServerTriggerConfig {
    /**
    * The Bitbucket server config resource that this trigger config maps to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#bitbucket_server_config_resource CloudbuildTrigger#bitbucket_server_config_resource}
    */
    readonly bitbucketServerConfigResource: string;
    /**
    * Key of the project that the repo is in. For example: The key for https://mybitbucket.server/projects/TEST/repos/test-repo is "TEST".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#project_key CloudbuildTrigger#project_key}
    */
    readonly projectKey: string;
    /**
    * Slug of the repository. A repository slug is a URL-friendly version of a repository name, automatically generated by Bitbucket for use in the URL.
    * For example, if the repository name is 'test repo', in the URL it would become 'test-repo' as in https://mybitbucket.server/projects/TEST/repos/test-repo.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#repo_slug CloudbuildTrigger#repo_slug}
    */
    readonly repoSlug: string;
    /**
    * pull_request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#pull_request CloudbuildTrigger#pull_request}
    */
    readonly pullRequest?: CloudbuildTriggerBitbucketServerTriggerConfigPullRequest;
    /**
    * push block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#push CloudbuildTrigger#push}
    */
    readonly push?: CloudbuildTriggerBitbucketServerTriggerConfigPush;
}
export declare function cloudbuildTriggerBitbucketServerTriggerConfigToTerraform(struct?: CloudbuildTriggerBitbucketServerTriggerConfigOutputReference | CloudbuildTriggerBitbucketServerTriggerConfig): any;
export declare function cloudbuildTriggerBitbucketServerTriggerConfigToHclTerraform(struct?: CloudbuildTriggerBitbucketServerTriggerConfigOutputReference | CloudbuildTriggerBitbucketServerTriggerConfig): any;
export declare class CloudbuildTriggerBitbucketServerTriggerConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildTriggerBitbucketServerTriggerConfig | undefined;
    set internalValue(value: CloudbuildTriggerBitbucketServerTriggerConfig | undefined);
    private _bitbucketServerConfigResource?;
    get bitbucketServerConfigResource(): string;
    set bitbucketServerConfigResource(value: string);
    get bitbucketServerConfigResourceInput(): string | undefined;
    private _projectKey?;
    get projectKey(): string;
    set projectKey(value: string);
    get projectKeyInput(): string | undefined;
    private _repoSlug?;
    get repoSlug(): string;
    set repoSlug(value: string);
    get repoSlugInput(): string | undefined;
    private _pullRequest;
    get pullRequest(): CloudbuildTriggerBitbucketServerTriggerConfigPullRequestOutputReference;
    putPullRequest(value: CloudbuildTriggerBitbucketServerTriggerConfigPullRequest): void;
    resetPullRequest(): void;
    get pullRequestInput(): CloudbuildTriggerBitbucketServerTriggerConfigPullRequest | undefined;
    private _push;
    get push(): CloudbuildTriggerBitbucketServerTriggerConfigPushOutputReference;
    putPush(value: CloudbuildTriggerBitbucketServerTriggerConfigPush): void;
    resetPush(): void;
    get pushInput(): CloudbuildTriggerBitbucketServerTriggerConfigPush | undefined;
}
export interface CloudbuildTriggerBuildArtifactsMavenArtifacts {
    /**
    * Maven artifactId value used when uploading the artifact to Artifact Registry.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#artifact_id CloudbuildTrigger#artifact_id}
    */
    readonly artifactId?: string;
    /**
    * Maven groupId value used when uploading the artifact to Artifact Registry.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#group_id CloudbuildTrigger#group_id}
    */
    readonly groupId?: string;
    /**
    * Path to an artifact in the build's workspace to be uploaded to Artifact Registry. This can be either an absolute path, e.g. /workspace/my-app/target/my-app-1.0.SNAPSHOT.jar or a relative path from /workspace, e.g. my-app/target/my-app-1.0.SNAPSHOT.jar.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#path CloudbuildTrigger#path}
    */
    readonly path?: string;
    /**
    * Artifact Registry repository, in the form "https://$REGION-maven.pkg.dev/$PROJECT/$REPOSITORY"
    *
    * Artifact in the workspace specified by path will be uploaded to Artifact Registry with this location as a prefix.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#repository CloudbuildTrigger#repository}
    */
    readonly repository?: string;
    /**
    * Maven version value used when uploading the artifact to Artifact Registry.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#version CloudbuildTrigger#version}
    */
    readonly version?: string;
}
export declare function cloudbuildTriggerBuildArtifactsMavenArtifactsToTerraform(struct?: CloudbuildTriggerBuildArtifactsMavenArtifacts | cdktn.IResolvable): any;
export declare function cloudbuildTriggerBuildArtifactsMavenArtifactsToHclTerraform(struct?: CloudbuildTriggerBuildArtifactsMavenArtifacts | cdktn.IResolvable): any;
export declare class CloudbuildTriggerBuildArtifactsMavenArtifactsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudbuildTriggerBuildArtifactsMavenArtifacts | cdktn.IResolvable | undefined;
    set internalValue(value: CloudbuildTriggerBuildArtifactsMavenArtifacts | cdktn.IResolvable | undefined);
    private _artifactId?;
    get artifactId(): string;
    set artifactId(value: string);
    resetArtifactId(): void;
    get artifactIdInput(): string | undefined;
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    resetGroupId(): void;
    get groupIdInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _repository?;
    get repository(): string;
    set repository(value: string);
    resetRepository(): void;
    get repositoryInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export declare class CloudbuildTriggerBuildArtifactsMavenArtifactsList extends cdktn.ComplexList {
    internalValue?: CloudbuildTriggerBuildArtifactsMavenArtifacts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudbuildTriggerBuildArtifactsMavenArtifactsOutputReference;
}
export interface CloudbuildTriggerBuildArtifactsNpmPackages {
    /**
    * Path to the package.json. e.g. workspace/path/to/package
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#package_path CloudbuildTrigger#package_path}
    */
    readonly packagePath?: string;
    /**
    * Artifact Registry repository, in the form "https://$REGION-npm.pkg.dev/$PROJECT/$REPOSITORY"
    *
    * Npm package in the workspace specified by path will be zipped and uploaded to Artifact Registry with this location as a prefix.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#repository CloudbuildTrigger#repository}
    */
    readonly repository?: string;
}
export declare function cloudbuildTriggerBuildArtifactsNpmPackagesToTerraform(struct?: CloudbuildTriggerBuildArtifactsNpmPackages | cdktn.IResolvable): any;
export declare function cloudbuildTriggerBuildArtifactsNpmPackagesToHclTerraform(struct?: CloudbuildTriggerBuildArtifactsNpmPackages | cdktn.IResolvable): any;
export declare class CloudbuildTriggerBuildArtifactsNpmPackagesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudbuildTriggerBuildArtifactsNpmPackages | cdktn.IResolvable | undefined;
    set internalValue(value: CloudbuildTriggerBuildArtifactsNpmPackages | cdktn.IResolvable | undefined);
    private _packagePath?;
    get packagePath(): string;
    set packagePath(value: string);
    resetPackagePath(): void;
    get packagePathInput(): string | undefined;
    private _repository?;
    get repository(): string;
    set repository(value: string);
    resetRepository(): void;
    get repositoryInput(): string | undefined;
}
export declare class CloudbuildTriggerBuildArtifactsNpmPackagesList extends cdktn.ComplexList {
    internalValue?: CloudbuildTriggerBuildArtifactsNpmPackages[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudbuildTriggerBuildArtifactsNpmPackagesOutputReference;
}
export interface CloudbuildTriggerBuildArtifactsObjectsTiming {
}
export declare function cloudbuildTriggerBuildArtifactsObjectsTimingToTerraform(struct?: CloudbuildTriggerBuildArtifactsObjectsTiming): any;
export declare function cloudbuildTriggerBuildArtifactsObjectsTimingToHclTerraform(struct?: CloudbuildTriggerBuildArtifactsObjectsTiming): any;
export declare class CloudbuildTriggerBuildArtifactsObjectsTimingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudbuildTriggerBuildArtifactsObjectsTiming | undefined;
    set internalValue(value: CloudbuildTriggerBuildArtifactsObjectsTiming | undefined);
    get endTime(): string;
    get startTime(): string;
}
export declare class CloudbuildTriggerBuildArtifactsObjectsTimingList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudbuildTriggerBuildArtifactsObjectsTimingOutputReference;
}
export interface CloudbuildTriggerBuildArtifactsObjects {
    /**
    * Cloud Storage bucket and optional object path, in the form "gs://bucket/path/to/somewhere/".
    *
    * Files in the workspace matching any path pattern will be uploaded to Cloud Storage with
    * this location as a prefix.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#location CloudbuildTrigger#location}
    */
    readonly location?: string;
    /**
    * Path globs used to match files in the build's workspace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#paths CloudbuildTrigger#paths}
    */
    readonly paths?: string[];
}
export declare function cloudbuildTriggerBuildArtifactsObjectsToTerraform(struct?: CloudbuildTriggerBuildArtifactsObjectsOutputReference | CloudbuildTriggerBuildArtifactsObjects): any;
export declare function cloudbuildTriggerBuildArtifactsObjectsToHclTerraform(struct?: CloudbuildTriggerBuildArtifactsObjectsOutputReference | CloudbuildTriggerBuildArtifactsObjects): any;
export declare class CloudbuildTriggerBuildArtifactsObjectsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildTriggerBuildArtifactsObjects | undefined;
    set internalValue(value: CloudbuildTriggerBuildArtifactsObjects | undefined);
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _paths?;
    get paths(): string[];
    set paths(value: string[]);
    resetPaths(): void;
    get pathsInput(): string[] | undefined;
    private _timing;
    get timing(): CloudbuildTriggerBuildArtifactsObjectsTimingList;
}
export interface CloudbuildTriggerBuildArtifactsPythonPackages {
    /**
    * Path globs used to match files in the build's workspace. For Python/ Twine, this is usually dist/*, and sometimes additionally an .asc file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#paths CloudbuildTrigger#paths}
    */
    readonly paths?: string[];
    /**
    * Artifact Registry repository, in the form "https://$REGION-python.pkg.dev/$PROJECT/$REPOSITORY"
    *
    * Files in the workspace matching any path pattern will be uploaded to Artifact Registry with this location as a prefix.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#repository CloudbuildTrigger#repository}
    */
    readonly repository?: string;
}
export declare function cloudbuildTriggerBuildArtifactsPythonPackagesToTerraform(struct?: CloudbuildTriggerBuildArtifactsPythonPackages | cdktn.IResolvable): any;
export declare function cloudbuildTriggerBuildArtifactsPythonPackagesToHclTerraform(struct?: CloudbuildTriggerBuildArtifactsPythonPackages | cdktn.IResolvable): any;
export declare class CloudbuildTriggerBuildArtifactsPythonPackagesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudbuildTriggerBuildArtifactsPythonPackages | cdktn.IResolvable | undefined;
    set internalValue(value: CloudbuildTriggerBuildArtifactsPythonPackages | cdktn.IResolvable | undefined);
    private _paths?;
    get paths(): string[];
    set paths(value: string[]);
    resetPaths(): void;
    get pathsInput(): string[] | undefined;
    private _repository?;
    get repository(): string;
    set repository(value: string);
    resetRepository(): void;
    get repositoryInput(): string | undefined;
}
export declare class CloudbuildTriggerBuildArtifactsPythonPackagesList extends cdktn.ComplexList {
    internalValue?: CloudbuildTriggerBuildArtifactsPythonPackages[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudbuildTriggerBuildArtifactsPythonPackagesOutputReference;
}
export interface CloudbuildTriggerBuildArtifacts {
    /**
    * A list of images to be pushed upon the successful completion of all build steps.
    *
    * The images will be pushed using the builder service account's credentials.
    *
    * The digests of the pushed images will be stored in the Build resource's results field.
    *
    * If any of the images fail to be pushed, the build is marked FAILURE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#images CloudbuildTrigger#images}
    */
    readonly images?: string[];
    /**
    * maven_artifacts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#maven_artifacts CloudbuildTrigger#maven_artifacts}
    */
    readonly mavenArtifacts?: CloudbuildTriggerBuildArtifactsMavenArtifacts[] | cdktn.IResolvable;
    /**
    * npm_packages block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#npm_packages CloudbuildTrigger#npm_packages}
    */
    readonly npmPackages?: CloudbuildTriggerBuildArtifactsNpmPackages[] | cdktn.IResolvable;
    /**
    * objects block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#objects CloudbuildTrigger#objects}
    */
    readonly objects?: CloudbuildTriggerBuildArtifactsObjects;
    /**
    * python_packages block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#python_packages CloudbuildTrigger#python_packages}
    */
    readonly pythonPackages?: CloudbuildTriggerBuildArtifactsPythonPackages[] | cdktn.IResolvable;
}
export declare function cloudbuildTriggerBuildArtifactsToTerraform(struct?: CloudbuildTriggerBuildArtifactsOutputReference | CloudbuildTriggerBuildArtifacts): any;
export declare function cloudbuildTriggerBuildArtifactsToHclTerraform(struct?: CloudbuildTriggerBuildArtifactsOutputReference | CloudbuildTriggerBuildArtifacts): any;
export declare class CloudbuildTriggerBuildArtifactsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildTriggerBuildArtifacts | undefined;
    set internalValue(value: CloudbuildTriggerBuildArtifacts | undefined);
    private _images?;
    get images(): string[];
    set images(value: string[]);
    resetImages(): void;
    get imagesInput(): string[] | undefined;
    private _mavenArtifacts;
    get mavenArtifacts(): CloudbuildTriggerBuildArtifactsMavenArtifactsList;
    putMavenArtifacts(value: CloudbuildTriggerBuildArtifactsMavenArtifacts[] | cdktn.IResolvable): void;
    resetMavenArtifacts(): void;
    get mavenArtifactsInput(): cdktn.IResolvable | CloudbuildTriggerBuildArtifactsMavenArtifacts[] | undefined;
    private _npmPackages;
    get npmPackages(): CloudbuildTriggerBuildArtifactsNpmPackagesList;
    putNpmPackages(value: CloudbuildTriggerBuildArtifactsNpmPackages[] | cdktn.IResolvable): void;
    resetNpmPackages(): void;
    get npmPackagesInput(): cdktn.IResolvable | CloudbuildTriggerBuildArtifactsNpmPackages[] | undefined;
    private _objects;
    get objects(): CloudbuildTriggerBuildArtifactsObjectsOutputReference;
    putObjects(value: CloudbuildTriggerBuildArtifactsObjects): void;
    resetObjects(): void;
    get objectsInput(): CloudbuildTriggerBuildArtifactsObjects | undefined;
    private _pythonPackages;
    get pythonPackages(): CloudbuildTriggerBuildArtifactsPythonPackagesList;
    putPythonPackages(value: CloudbuildTriggerBuildArtifactsPythonPackages[] | cdktn.IResolvable): void;
    resetPythonPackages(): void;
    get pythonPackagesInput(): cdktn.IResolvable | CloudbuildTriggerBuildArtifactsPythonPackages[] | undefined;
}
export interface CloudbuildTriggerBuildAvailableSecretsSecretManager {
    /**
    * Environment variable name to associate with the secret. Secret environment
    * variables must be unique across all of a build's secrets, and must be used
    * by at least one build step.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#env CloudbuildTrigger#env}
    */
    readonly env: string;
    /**
    * Resource name of the SecretVersion. In format: projects/* /secrets/* /versions/*
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#version_name CloudbuildTrigger#version_name}
     *
    * Note: The above comment contained a comment block ending sequence (* followed by /). We have introduced a space between to prevent syntax errors. Please ignore the space.
    */
    readonly versionName: string;
}
export declare function cloudbuildTriggerBuildAvailableSecretsSecretManagerToTerraform(struct?: CloudbuildTriggerBuildAvailableSecretsSecretManager | cdktn.IResolvable): any;
export declare function cloudbuildTriggerBuildAvailableSecretsSecretManagerToHclTerraform(struct?: CloudbuildTriggerBuildAvailableSecretsSecretManager | cdktn.IResolvable): any;
export declare class CloudbuildTriggerBuildAvailableSecretsSecretManagerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudbuildTriggerBuildAvailableSecretsSecretManager | cdktn.IResolvable | undefined;
    set internalValue(value: CloudbuildTriggerBuildAvailableSecretsSecretManager | cdktn.IResolvable | undefined);
    private _env?;
    get env(): string;
    set env(value: string);
    get envInput(): string | undefined;
    private _versionName?;
    get versionName(): string;
    set versionName(value: string);
    get versionNameInput(): string | undefined;
}
export declare class CloudbuildTriggerBuildAvailableSecretsSecretManagerList extends cdktn.ComplexList {
    internalValue?: CloudbuildTriggerBuildAvailableSecretsSecretManager[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudbuildTriggerBuildAvailableSecretsSecretManagerOutputReference;
}
export interface CloudbuildTriggerBuildAvailableSecrets {
    /**
    * secret_manager block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#secret_manager CloudbuildTrigger#secret_manager}
    */
    readonly secretManager: CloudbuildTriggerBuildAvailableSecretsSecretManager[] | cdktn.IResolvable;
}
export declare function cloudbuildTriggerBuildAvailableSecretsToTerraform(struct?: CloudbuildTriggerBuildAvailableSecretsOutputReference | CloudbuildTriggerBuildAvailableSecrets): any;
export declare function cloudbuildTriggerBuildAvailableSecretsToHclTerraform(struct?: CloudbuildTriggerBuildAvailableSecretsOutputReference | CloudbuildTriggerBuildAvailableSecrets): any;
export declare class CloudbuildTriggerBuildAvailableSecretsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildTriggerBuildAvailableSecrets | undefined;
    set internalValue(value: CloudbuildTriggerBuildAvailableSecrets | undefined);
    private _secretManager;
    get secretManager(): CloudbuildTriggerBuildAvailableSecretsSecretManagerList;
    putSecretManager(value: CloudbuildTriggerBuildAvailableSecretsSecretManager[] | cdktn.IResolvable): void;
    get secretManagerInput(): cdktn.IResolvable | CloudbuildTriggerBuildAvailableSecretsSecretManager[] | undefined;
}
export interface CloudbuildTriggerBuildOptionsVolumes {
    /**
    * Name of the volume to mount.
    *
    * Volume names must be unique per build step and must be valid names for Docker volumes.
    * Each named volume must be used by at least two build steps.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#name CloudbuildTrigger#name}
    */
    readonly name?: string;
    /**
    * Path at which to mount the volume.
    *
    * Paths must be absolute and cannot conflict with other volume paths on the same
    * build step or with certain reserved volume paths.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#path CloudbuildTrigger#path}
    */
    readonly path?: string;
}
export declare function cloudbuildTriggerBuildOptionsVolumesToTerraform(struct?: CloudbuildTriggerBuildOptionsVolumes | cdktn.IResolvable): any;
export declare function cloudbuildTriggerBuildOptionsVolumesToHclTerraform(struct?: CloudbuildTriggerBuildOptionsVolumes | cdktn.IResolvable): any;
export declare class CloudbuildTriggerBuildOptionsVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudbuildTriggerBuildOptionsVolumes | cdktn.IResolvable | undefined;
    set internalValue(value: CloudbuildTriggerBuildOptionsVolumes | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export declare class CloudbuildTriggerBuildOptionsVolumesList extends cdktn.ComplexList {
    internalValue?: CloudbuildTriggerBuildOptionsVolumes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudbuildTriggerBuildOptionsVolumesOutputReference;
}
export interface CloudbuildTriggerBuildOptions {
    /**
    * Requested disk size for the VM that runs the build. Note that this is NOT "disk free";
    * some of the space will be used by the operating system and build utilities.
    * Also note that this is the minimum disk size that will be allocated for the build --
    * the build may run with a larger disk than requested. At present, the maximum disk size
    * is 1000GB; builds that request more than the maximum are rejected with an error.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#disk_size_gb CloudbuildTrigger#disk_size_gb}
    */
    readonly diskSizeGb?: number;
    /**
    * Option to specify whether or not to apply bash style string operations to the substitutions.
    *
    * NOTE this is always enabled for triggered builds and cannot be overridden in the build configuration file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#dynamic_substitutions CloudbuildTrigger#dynamic_substitutions}
    */
    readonly dynamicSubstitutions?: boolean | cdktn.IResolvable;
    /**
    * A list of global environment variable definitions that will exist for all build steps
    * in this build. If a variable is defined in both globally and in a build step,
    * the variable will use the build step value.
    *
    * The elements are of the form "KEY=VALUE" for the environment variable "KEY" being given the value "VALUE".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#env CloudbuildTrigger#env}
    */
    readonly env?: string[];
    /**
    * Option to define build log streaming behavior to Google Cloud Storage. Possible values: ["STREAM_DEFAULT", "STREAM_ON", "STREAM_OFF"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#log_streaming_option CloudbuildTrigger#log_streaming_option}
    */
    readonly logStreamingOption?: string;
    /**
    * Option to specify the logging mode, which determines if and where build logs are stored. Possible values: ["LOGGING_UNSPECIFIED", "LEGACY", "GCS_ONLY", "STACKDRIVER_ONLY", "CLOUD_LOGGING_ONLY", "NONE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#logging CloudbuildTrigger#logging}
    */
    readonly logging?: string;
    /**
    * Compute Engine machine type on which to run the build.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#machine_type CloudbuildTrigger#machine_type}
    */
    readonly machineType?: string;
    /**
    * Requested verifiability options. Possible values: ["NOT_VERIFIED", "VERIFIED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#requested_verify_option CloudbuildTrigger#requested_verify_option}
    */
    readonly requestedVerifyOption?: string;
    /**
    * A list of global environment variables, which are encrypted using a Cloud Key Management
    * Service crypto key. These values must be specified in the build's Secret. These variables
    * will be available to all build steps in this build.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#secret_env CloudbuildTrigger#secret_env}
    */
    readonly secretEnv?: string[];
    /**
    * Requested hash for SourceProvenance. Possible values: ["NONE", "SHA256", "MD5"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#source_provenance_hash CloudbuildTrigger#source_provenance_hash}
    */
    readonly sourceProvenanceHash?: string[];
    /**
    * Option to specify behavior when there is an error in the substitution checks.
    *
    * NOTE this is always set to ALLOW_LOOSE for triggered builds and cannot be overridden
    * in the build configuration file. Possible values: ["MUST_MATCH", "ALLOW_LOOSE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#substitution_option CloudbuildTrigger#substitution_option}
    */
    readonly substitutionOption?: string;
    /**
    * Option to specify a WorkerPool for the build. Format projects/{project}/workerPools/{workerPool}
    *
    * This field is experimental.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#worker_pool CloudbuildTrigger#worker_pool}
    */
    readonly workerPool?: string;
    /**
    * volumes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#volumes CloudbuildTrigger#volumes}
    */
    readonly volumes?: CloudbuildTriggerBuildOptionsVolumes[] | cdktn.IResolvable;
}
export declare function cloudbuildTriggerBuildOptionsToTerraform(struct?: CloudbuildTriggerBuildOptionsOutputReference | CloudbuildTriggerBuildOptions): any;
export declare function cloudbuildTriggerBuildOptionsToHclTerraform(struct?: CloudbuildTriggerBuildOptionsOutputReference | CloudbuildTriggerBuildOptions): any;
export declare class CloudbuildTriggerBuildOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildTriggerBuildOptions | undefined;
    set internalValue(value: CloudbuildTriggerBuildOptions | undefined);
    private _diskSizeGb?;
    get diskSizeGb(): number;
    set diskSizeGb(value: number);
    resetDiskSizeGb(): void;
    get diskSizeGbInput(): number | undefined;
    private _dynamicSubstitutions?;
    get dynamicSubstitutions(): boolean | cdktn.IResolvable;
    set dynamicSubstitutions(value: boolean | cdktn.IResolvable);
    resetDynamicSubstitutions(): void;
    get dynamicSubstitutionsInput(): boolean | cdktn.IResolvable | undefined;
    private _env?;
    get env(): string[];
    set env(value: string[]);
    resetEnv(): void;
    get envInput(): string[] | undefined;
    private _logStreamingOption?;
    get logStreamingOption(): string;
    set logStreamingOption(value: string);
    resetLogStreamingOption(): void;
    get logStreamingOptionInput(): string | undefined;
    private _logging?;
    get logging(): string;
    set logging(value: string);
    resetLogging(): void;
    get loggingInput(): string | undefined;
    private _machineType?;
    get machineType(): string;
    set machineType(value: string);
    resetMachineType(): void;
    get machineTypeInput(): string | undefined;
    private _requestedVerifyOption?;
    get requestedVerifyOption(): string;
    set requestedVerifyOption(value: string);
    resetRequestedVerifyOption(): void;
    get requestedVerifyOptionInput(): string | undefined;
    private _secretEnv?;
    get secretEnv(): string[];
    set secretEnv(value: string[]);
    resetSecretEnv(): void;
    get secretEnvInput(): string[] | undefined;
    private _sourceProvenanceHash?;
    get sourceProvenanceHash(): string[];
    set sourceProvenanceHash(value: string[]);
    resetSourceProvenanceHash(): void;
    get sourceProvenanceHashInput(): string[] | undefined;
    private _substitutionOption?;
    get substitutionOption(): string;
    set substitutionOption(value: string);
    resetSubstitutionOption(): void;
    get substitutionOptionInput(): string | undefined;
    private _workerPool?;
    get workerPool(): string;
    set workerPool(value: string);
    resetWorkerPool(): void;
    get workerPoolInput(): string | undefined;
    private _volumes;
    get volumes(): CloudbuildTriggerBuildOptionsVolumesList;
    putVolumes(value: CloudbuildTriggerBuildOptionsVolumes[] | cdktn.IResolvable): void;
    resetVolumes(): void;
    get volumesInput(): cdktn.IResolvable | CloudbuildTriggerBuildOptionsVolumes[] | undefined;
}
export interface CloudbuildTriggerBuildSecret {
    /**
    * Cloud KMS key name to use to decrypt these envs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#kms_key_name CloudbuildTrigger#kms_key_name}
    */
    readonly kmsKeyName: string;
    /**
    * Map of environment variable name to its encrypted value.
    * Secret environment variables must be unique across all of a build's secrets,
    * and must be used by at least one build step. Values can be at most 64 KB in size.
    * There can be at most 100 secret values across all of a build's secrets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#secret_env CloudbuildTrigger#secret_env}
    */
    readonly secretEnv?: {
        [key: string]: string;
    };
}
export declare function cloudbuildTriggerBuildSecretToTerraform(struct?: CloudbuildTriggerBuildSecret | cdktn.IResolvable): any;
export declare function cloudbuildTriggerBuildSecretToHclTerraform(struct?: CloudbuildTriggerBuildSecret | cdktn.IResolvable): any;
export declare class CloudbuildTriggerBuildSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudbuildTriggerBuildSecret | cdktn.IResolvable | undefined;
    set internalValue(value: CloudbuildTriggerBuildSecret | cdktn.IResolvable | undefined);
    private _kmsKeyName?;
    get kmsKeyName(): string;
    set kmsKeyName(value: string);
    get kmsKeyNameInput(): string | undefined;
    private _secretEnv?;
    get secretEnv(): {
        [key: string]: string;
    };
    set secretEnv(value: {
        [key: string]: string;
    });
    resetSecretEnv(): void;
    get secretEnvInput(): {
        [key: string]: string;
    } | undefined;
}
export declare class CloudbuildTriggerBuildSecretList extends cdktn.ComplexList {
    internalValue?: CloudbuildTriggerBuildSecret[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudbuildTriggerBuildSecretOutputReference;
}
export interface CloudbuildTriggerBuildSourceRepoSource {
    /**
    * Regex matching branches to build. Exactly one a of branch name, tag, or commit SHA must be provided.
    * The syntax of the regular expressions accepted is the syntax accepted by RE2 and
    * described at https://github.com/google/re2/wiki/Syntax
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#branch_name CloudbuildTrigger#branch_name}
    */
    readonly branchName?: string;
    /**
    * Explicit commit SHA to build. Exactly one a of branch name, tag, or commit SHA must be provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#commit_sha CloudbuildTrigger#commit_sha}
    */
    readonly commitSha?: string;
    /**
    * Directory, relative to the source root, in which to run the build.
    * This must be a relative path. If a step's dir is specified and is an absolute path,
    * this value is ignored for that step's execution.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#dir CloudbuildTrigger#dir}
    */
    readonly dir?: string;
    /**
    * Only trigger a build if the revision regex does NOT match the revision regex.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#invert_regex CloudbuildTrigger#invert_regex}
    */
    readonly invertRegex?: boolean | cdktn.IResolvable;
    /**
    * ID of the project that owns the Cloud Source Repository.
    * If omitted, the project ID requesting the build is assumed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#project_id CloudbuildTrigger#project_id}
    */
    readonly projectId?: string;
    /**
    * Name of the Cloud Source Repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#repo_name CloudbuildTrigger#repo_name}
    */
    readonly repoName: string;
    /**
    * Substitutions to use in a triggered build. Should only be used with triggers.run
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#substitutions CloudbuildTrigger#substitutions}
    */
    readonly substitutions?: {
        [key: string]: string;
    };
    /**
    * Regex matching tags to build. Exactly one a of branch name, tag, or commit SHA must be provided.
    * The syntax of the regular expressions accepted is the syntax accepted by RE2 and
    * described at https://github.com/google/re2/wiki/Syntax
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#tag_name CloudbuildTrigger#tag_name}
    */
    readonly tagName?: string;
}
export declare function cloudbuildTriggerBuildSourceRepoSourceToTerraform(struct?: CloudbuildTriggerBuildSourceRepoSourceOutputReference | CloudbuildTriggerBuildSourceRepoSource): any;
export declare function cloudbuildTriggerBuildSourceRepoSourceToHclTerraform(struct?: CloudbuildTriggerBuildSourceRepoSourceOutputReference | CloudbuildTriggerBuildSourceRepoSource): any;
export declare class CloudbuildTriggerBuildSourceRepoSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildTriggerBuildSourceRepoSource | undefined;
    set internalValue(value: CloudbuildTriggerBuildSourceRepoSource | undefined);
    private _branchName?;
    get branchName(): string;
    set branchName(value: string);
    resetBranchName(): void;
    get branchNameInput(): string | undefined;
    private _commitSha?;
    get commitSha(): string;
    set commitSha(value: string);
    resetCommitSha(): void;
    get commitShaInput(): string | undefined;
    private _dir?;
    get dir(): string;
    set dir(value: string);
    resetDir(): void;
    get dirInput(): string | undefined;
    private _invertRegex?;
    get invertRegex(): boolean | cdktn.IResolvable;
    set invertRegex(value: boolean | cdktn.IResolvable);
    resetInvertRegex(): void;
    get invertRegexInput(): boolean | cdktn.IResolvable | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _repoName?;
    get repoName(): string;
    set repoName(value: string);
    get repoNameInput(): string | undefined;
    private _substitutions?;
    get substitutions(): {
        [key: string]: string;
    };
    set substitutions(value: {
        [key: string]: string;
    });
    resetSubstitutions(): void;
    get substitutionsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagName?;
    get tagName(): string;
    set tagName(value: string);
    resetTagName(): void;
    get tagNameInput(): string | undefined;
}
export interface CloudbuildTriggerBuildSourceStorageSource {
    /**
    * Google Cloud Storage bucket containing the source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#bucket CloudbuildTrigger#bucket}
    */
    readonly bucket: string;
    /**
    * Google Cloud Storage generation for the object.
    * If the generation is omitted, the latest generation will be used
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#generation CloudbuildTrigger#generation}
    */
    readonly generation?: string;
    /**
    * Google Cloud Storage object containing the source.
    * This object must be a gzipped archive file (.tar.gz) containing source to build.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#object CloudbuildTrigger#object}
    */
    readonly object: string;
}
export declare function cloudbuildTriggerBuildSourceStorageSourceToTerraform(struct?: CloudbuildTriggerBuildSourceStorageSourceOutputReference | CloudbuildTriggerBuildSourceStorageSource): any;
export declare function cloudbuildTriggerBuildSourceStorageSourceToHclTerraform(struct?: CloudbuildTriggerBuildSourceStorageSourceOutputReference | CloudbuildTriggerBuildSourceStorageSource): any;
export declare class CloudbuildTriggerBuildSourceStorageSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildTriggerBuildSourceStorageSource | undefined;
    set internalValue(value: CloudbuildTriggerBuildSourceStorageSource | undefined);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _generation?;
    get generation(): string;
    set generation(value: string);
    resetGeneration(): void;
    get generationInput(): string | undefined;
    private _object?;
    get object(): string;
    set object(value: string);
    get objectInput(): string | undefined;
}
export interface CloudbuildTriggerBuildSource {
    /**
    * repo_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#repo_source CloudbuildTrigger#repo_source}
    */
    readonly repoSource?: CloudbuildTriggerBuildSourceRepoSource;
    /**
    * storage_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#storage_source CloudbuildTrigger#storage_source}
    */
    readonly storageSource?: CloudbuildTriggerBuildSourceStorageSource;
}
export declare function cloudbuildTriggerBuildSourceToTerraform(struct?: CloudbuildTriggerBuildSourceOutputReference | CloudbuildTriggerBuildSource): any;
export declare function cloudbuildTriggerBuildSourceToHclTerraform(struct?: CloudbuildTriggerBuildSourceOutputReference | CloudbuildTriggerBuildSource): any;
export declare class CloudbuildTriggerBuildSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildTriggerBuildSource | undefined;
    set internalValue(value: CloudbuildTriggerBuildSource | undefined);
    private _repoSource;
    get repoSource(): CloudbuildTriggerBuildSourceRepoSourceOutputReference;
    putRepoSource(value: CloudbuildTriggerBuildSourceRepoSource): void;
    resetRepoSource(): void;
    get repoSourceInput(): CloudbuildTriggerBuildSourceRepoSource | undefined;
    private _storageSource;
    get storageSource(): CloudbuildTriggerBuildSourceStorageSourceOutputReference;
    putStorageSource(value: CloudbuildTriggerBuildSourceStorageSource): void;
    resetStorageSource(): void;
    get storageSourceInput(): CloudbuildTriggerBuildSourceStorageSource | undefined;
}
export interface CloudbuildTriggerBuildStepVolumes {
    /**
    * Name of the volume to mount.
    *
    * Volume names must be unique per build step and must be valid names for
    * Docker volumes. Each named volume must be used by at least two build steps.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#name CloudbuildTrigger#name}
    */
    readonly name: string;
    /**
    * Path at which to mount the volume.
    *
    * Paths must be absolute and cannot conflict with other volume paths on
    * the same build step or with certain reserved volume paths.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#path CloudbuildTrigger#path}
    */
    readonly path: string;
}
export declare function cloudbuildTriggerBuildStepVolumesToTerraform(struct?: CloudbuildTriggerBuildStepVolumes | cdktn.IResolvable): any;
export declare function cloudbuildTriggerBuildStepVolumesToHclTerraform(struct?: CloudbuildTriggerBuildStepVolumes | cdktn.IResolvable): any;
export declare class CloudbuildTriggerBuildStepVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudbuildTriggerBuildStepVolumes | cdktn.IResolvable | undefined;
    set internalValue(value: CloudbuildTriggerBuildStepVolumes | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
}
export declare class CloudbuildTriggerBuildStepVolumesList extends cdktn.ComplexList {
    internalValue?: CloudbuildTriggerBuildStepVolumes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudbuildTriggerBuildStepVolumesOutputReference;
}
export interface CloudbuildTriggerBuildStep {
    /**
    * Allow this build step to fail without failing the entire build if and
    * only if the exit code is one of the specified codes.
    *
    * If 'allowFailure' is also specified, this field will take precedence.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#allow_exit_codes CloudbuildTrigger#allow_exit_codes}
    */
    readonly allowExitCodes?: number[];
    /**
    * Allow this build step to fail without failing the entire build.
    * If false, the entire build will fail if this step fails. Otherwise, the
    * build will succeed, but this step will still have a failure status.
    * Error information will be reported in the 'failureDetail' field.
    *
    * 'allowExitCodes' takes precedence over this field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#allow_failure CloudbuildTrigger#allow_failure}
    */
    readonly allowFailure?: boolean | cdktn.IResolvable;
    /**
    * A list of arguments that will be presented to the step when it is started.
    *
    * If the image used to run the step's container has an entrypoint, the args
    * are used as arguments to that entrypoint. If the image does not define an
    * entrypoint, the first element in args is used as the entrypoint, and the
    * remainder will be used as arguments.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#args CloudbuildTrigger#args}
    */
    readonly args?: string[];
    /**
    * Working directory to use when running this step's container.
    *
    * If this value is a relative path, it is relative to the build's working
    * directory. If this value is absolute, it may be outside the build's working
    * directory, in which case the contents of the path may not be persisted
    * across build step executions, unless a 'volume' for that path is specified.
    *
    * If the build specifies a 'RepoSource' with 'dir' and a step with a
    * 'dir',
    * which specifies an absolute path, the 'RepoSource' 'dir' is ignored
    * for the step's execution.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#dir CloudbuildTrigger#dir}
    */
    readonly dir?: string;
    /**
    * Entrypoint to be used instead of the build step image's
    * default entrypoint.
    * If unset, the image's default entrypoint is used
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#entrypoint CloudbuildTrigger#entrypoint}
    */
    readonly entrypoint?: string;
    /**
    * A list of environment variable definitions to be used when
    * running a step.
    *
    * The elements are of the form "KEY=VALUE" for the environment variable
    * "KEY" being given the value "VALUE".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#env CloudbuildTrigger#env}
    */
    readonly env?: string[];
    /**
    * Unique identifier for this build step, used in 'wait_for' to
    * reference this build step as a dependency.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#id CloudbuildTrigger#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the container image that will run this particular build step.
    *
    * If the image is available in the host's Docker daemon's cache, it will be
    * run directly. If not, the host will attempt to pull the image first, using
    * the builder service account's credentials if necessary.
    *
    * The Docker daemon's cache will already have the latest versions of all of
    * the officially supported build steps (see https://github.com/GoogleCloudPlatform/cloud-builders
    * for images and examples).
    * The Docker daemon will also have cached many of the layers for some popular
    * images, like "ubuntu", "debian", but they will be refreshed at the time
    * you attempt to use them.
    *
    * If you built an image in a previous build step, it will be stored in the
    * host's Docker daemon's cache and is available to use as the name for a
    * later build step.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#name CloudbuildTrigger#name}
    */
    readonly name: string;
    /**
    * A shell script to be executed in the step.
    * When script is provided, the user cannot specify the entrypoint or args.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#script CloudbuildTrigger#script}
    */
    readonly script?: string;
    /**
    * A list of environment variables which are encrypted using
    * a Cloud Key
    * Management Service crypto key. These values must be specified in
    * the build's 'Secret'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#secret_env CloudbuildTrigger#secret_env}
    */
    readonly secretEnv?: string[];
    /**
    * Time limit for executing this build step. If not defined,
    * the step has no
    * time limit and will be allowed to continue to run until either it
    * completes or the build itself times out.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#timeout CloudbuildTrigger#timeout}
    */
    readonly timeout?: string;
    /**
    * Output only. Stores timing information for executing this
    * build step.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#timing CloudbuildTrigger#timing}
    */
    readonly timing?: string;
    /**
    * The ID(s) of the step(s) that this build step depends on.
    *
    * This build step will not start until all the build steps in 'wait_for'
    * have completed successfully. If 'wait_for' is empty, this build step
    * will start when all previous build steps in the 'Build.Steps' list
    * have completed successfully.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#wait_for CloudbuildTrigger#wait_for}
    */
    readonly waitFor?: string[];
    /**
    * volumes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#volumes CloudbuildTrigger#volumes}
    */
    readonly volumes?: CloudbuildTriggerBuildStepVolumes[] | cdktn.IResolvable;
}
export declare function cloudbuildTriggerBuildStepToTerraform(struct?: CloudbuildTriggerBuildStep | cdktn.IResolvable): any;
export declare function cloudbuildTriggerBuildStepToHclTerraform(struct?: CloudbuildTriggerBuildStep | cdktn.IResolvable): any;
export declare class CloudbuildTriggerBuildStepOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudbuildTriggerBuildStep | cdktn.IResolvable | undefined;
    set internalValue(value: CloudbuildTriggerBuildStep | cdktn.IResolvable | undefined);
    private _allowExitCodes?;
    get allowExitCodes(): number[];
    set allowExitCodes(value: number[]);
    resetAllowExitCodes(): void;
    get allowExitCodesInput(): number[] | undefined;
    private _allowFailure?;
    get allowFailure(): boolean | cdktn.IResolvable;
    set allowFailure(value: boolean | cdktn.IResolvable);
    resetAllowFailure(): void;
    get allowFailureInput(): boolean | cdktn.IResolvable | undefined;
    private _args?;
    get args(): string[];
    set args(value: string[]);
    resetArgs(): void;
    get argsInput(): string[] | undefined;
    private _dir?;
    get dir(): string;
    set dir(value: string);
    resetDir(): void;
    get dirInput(): string | undefined;
    private _entrypoint?;
    get entrypoint(): string;
    set entrypoint(value: string);
    resetEntrypoint(): void;
    get entrypointInput(): string | undefined;
    private _env?;
    get env(): string[];
    set env(value: string[]);
    resetEnv(): void;
    get envInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _script?;
    get script(): string;
    set script(value: string);
    resetScript(): void;
    get scriptInput(): string | undefined;
    private _secretEnv?;
    get secretEnv(): string[];
    set secretEnv(value: string[]);
    resetSecretEnv(): void;
    get secretEnvInput(): string[] | undefined;
    private _timeout?;
    get timeout(): string;
    set timeout(value: string);
    resetTimeout(): void;
    get timeoutInput(): string | undefined;
    private _timing?;
    get timing(): string;
    set timing(value: string);
    resetTiming(): void;
    get timingInput(): string | undefined;
    private _waitFor?;
    get waitFor(): string[];
    set waitFor(value: string[]);
    resetWaitFor(): void;
    get waitForInput(): string[] | undefined;
    private _volumes;
    get volumes(): CloudbuildTriggerBuildStepVolumesList;
    putVolumes(value: CloudbuildTriggerBuildStepVolumes[] | cdktn.IResolvable): void;
    resetVolumes(): void;
    get volumesInput(): cdktn.IResolvable | CloudbuildTriggerBuildStepVolumes[] | undefined;
}
export declare class CloudbuildTriggerBuildStepList extends cdktn.ComplexList {
    internalValue?: CloudbuildTriggerBuildStep[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudbuildTriggerBuildStepOutputReference;
}
export interface CloudbuildTriggerBuild {
    /**
    * A list of images to be pushed upon the successful completion of all build steps.
    * The images are pushed using the builder service account's credentials.
    * The digests of the pushed images will be stored in the Build resource's results field.
    * If any of the images fail to be pushed, the build status is marked FAILURE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#images CloudbuildTrigger#images}
    */
    readonly images?: string[];
    /**
    * Google Cloud Storage bucket where logs should be written.
    * Logs file names will be of the format ${logsBucket}/log-${build_id}.txt.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#logs_bucket CloudbuildTrigger#logs_bucket}
    */
    readonly logsBucket?: string;
    /**
    * TTL in queue for this build. If provided and the build is enqueued longer than this value,
    * the build will expire and the build status will be EXPIRED.
    * The TTL starts ticking from createTime.
    * A duration in seconds with up to nine fractional digits, terminated by 's'. Example: "3.5s".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#queue_ttl CloudbuildTrigger#queue_ttl}
    */
    readonly queueTtl?: string;
    /**
    * Substitutions data for Build resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#substitutions CloudbuildTrigger#substitutions}
    */
    readonly substitutions?: {
        [key: string]: string;
    };
    /**
    * Tags for annotation of a Build. These are not docker tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#tags CloudbuildTrigger#tags}
    */
    readonly tags?: string[];
    /**
    * Amount of time that this build should be allowed to run, to second granularity.
    * If this amount of time elapses, work on the build will cease and the build status will be TIMEOUT.
    * This timeout must be equal to or greater than the sum of the timeouts for build steps within the build.
    * The expected format is the number of seconds followed by s.
    * Default time is ten minutes (600s).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#timeout CloudbuildTrigger#timeout}
    */
    readonly timeout?: string;
    /**
    * artifacts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#artifacts CloudbuildTrigger#artifacts}
    */
    readonly artifacts?: CloudbuildTriggerBuildArtifacts;
    /**
    * available_secrets block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#available_secrets CloudbuildTrigger#available_secrets}
    */
    readonly availableSecrets?: CloudbuildTriggerBuildAvailableSecrets;
    /**
    * options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#options CloudbuildTrigger#options}
    */
    readonly options?: CloudbuildTriggerBuildOptions;
    /**
    * secret block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#secret CloudbuildTrigger#secret}
    */
    readonly secret?: CloudbuildTriggerBuildSecret[] | cdktn.IResolvable;
    /**
    * source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#source CloudbuildTrigger#source}
    */
    readonly source?: CloudbuildTriggerBuildSource;
    /**
    * step block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#step CloudbuildTrigger#step}
    */
    readonly step: CloudbuildTriggerBuildStep[] | cdktn.IResolvable;
}
export declare function cloudbuildTriggerBuildToTerraform(struct?: CloudbuildTriggerBuildOutputReference | CloudbuildTriggerBuild): any;
export declare function cloudbuildTriggerBuildToHclTerraform(struct?: CloudbuildTriggerBuildOutputReference | CloudbuildTriggerBuild): any;
export declare class CloudbuildTriggerBuildOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildTriggerBuild | undefined;
    set internalValue(value: CloudbuildTriggerBuild | undefined);
    private _images?;
    get images(): string[];
    set images(value: string[]);
    resetImages(): void;
    get imagesInput(): string[] | undefined;
    private _logsBucket?;
    get logsBucket(): string;
    set logsBucket(value: string);
    resetLogsBucket(): void;
    get logsBucketInput(): string | undefined;
    private _queueTtl?;
    get queueTtl(): string;
    set queueTtl(value: string);
    resetQueueTtl(): void;
    get queueTtlInput(): string | undefined;
    private _substitutions?;
    get substitutions(): {
        [key: string]: string;
    };
    set substitutions(value: {
        [key: string]: string;
    });
    resetSubstitutions(): void;
    get substitutionsInput(): {
        [key: string]: string;
    } | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _timeout?;
    get timeout(): string;
    set timeout(value: string);
    resetTimeout(): void;
    get timeoutInput(): string | undefined;
    private _artifacts;
    get artifacts(): CloudbuildTriggerBuildArtifactsOutputReference;
    putArtifacts(value: CloudbuildTriggerBuildArtifacts): void;
    resetArtifacts(): void;
    get artifactsInput(): CloudbuildTriggerBuildArtifacts | undefined;
    private _availableSecrets;
    get availableSecrets(): CloudbuildTriggerBuildAvailableSecretsOutputReference;
    putAvailableSecrets(value: CloudbuildTriggerBuildAvailableSecrets): void;
    resetAvailableSecrets(): void;
    get availableSecretsInput(): CloudbuildTriggerBuildAvailableSecrets | undefined;
    private _options;
    get options(): CloudbuildTriggerBuildOptionsOutputReference;
    putOptions(value: CloudbuildTriggerBuildOptions): void;
    resetOptions(): void;
    get optionsInput(): CloudbuildTriggerBuildOptions | undefined;
    private _secret;
    get secret(): CloudbuildTriggerBuildSecretList;
    putSecret(value: CloudbuildTriggerBuildSecret[] | cdktn.IResolvable): void;
    resetSecret(): void;
    get secretInput(): cdktn.IResolvable | CloudbuildTriggerBuildSecret[] | undefined;
    private _source;
    get source(): CloudbuildTriggerBuildSourceOutputReference;
    putSource(value: CloudbuildTriggerBuildSource): void;
    resetSource(): void;
    get sourceInput(): CloudbuildTriggerBuildSource | undefined;
    private _step;
    get step(): CloudbuildTriggerBuildStepList;
    putStep(value: CloudbuildTriggerBuildStep[] | cdktn.IResolvable): void;
    get stepInput(): cdktn.IResolvable | CloudbuildTriggerBuildStep[] | undefined;
}
export interface CloudbuildTriggerDeveloperConnectEventConfigPullRequest {
    /**
    * Regex of branches to match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#branch CloudbuildTrigger#branch}
    */
    readonly branch?: string;
    /**
    * Configure builds to run whether a repository owner or collaborator need to comment '/gcbrun'. Possible values: ["COMMENTS_DISABLED", "COMMENTS_ENABLED", "COMMENTS_ENABLED_FOR_EXTERNAL_CONTRIBUTORS_ONLY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#comment_control CloudbuildTrigger#comment_control}
    */
    readonly commentControl?: string;
    /**
    * If true, branches that do NOT match the git_ref will trigger a build.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#invert_regex CloudbuildTrigger#invert_regex}
    */
    readonly invertRegex?: boolean | cdktn.IResolvable;
}
export declare function cloudbuildTriggerDeveloperConnectEventConfigPullRequestToTerraform(struct?: CloudbuildTriggerDeveloperConnectEventConfigPullRequestOutputReference | CloudbuildTriggerDeveloperConnectEventConfigPullRequest): any;
export declare function cloudbuildTriggerDeveloperConnectEventConfigPullRequestToHclTerraform(struct?: CloudbuildTriggerDeveloperConnectEventConfigPullRequestOutputReference | CloudbuildTriggerDeveloperConnectEventConfigPullRequest): any;
export declare class CloudbuildTriggerDeveloperConnectEventConfigPullRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildTriggerDeveloperConnectEventConfigPullRequest | undefined;
    set internalValue(value: CloudbuildTriggerDeveloperConnectEventConfigPullRequest | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _commentControl?;
    get commentControl(): string;
    set commentControl(value: string);
    resetCommentControl(): void;
    get commentControlInput(): string | undefined;
    private _invertRegex?;
    get invertRegex(): boolean | cdktn.IResolvable;
    set invertRegex(value: boolean | cdktn.IResolvable);
    resetInvertRegex(): void;
    get invertRegexInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CloudbuildTriggerDeveloperConnectEventConfigPush {
    /**
    * Regex of branches to match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#branch CloudbuildTrigger#branch}
    */
    readonly branch?: string;
    /**
    * If true, only trigger a build if the revision regex does NOT match the git_ref regex.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#invert_regex CloudbuildTrigger#invert_regex}
    */
    readonly invertRegex?: boolean | cdktn.IResolvable;
    /**
    * Regex of tags to match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#tag CloudbuildTrigger#tag}
    */
    readonly tag?: string;
}
export declare function cloudbuildTriggerDeveloperConnectEventConfigPushToTerraform(struct?: CloudbuildTriggerDeveloperConnectEventConfigPushOutputReference | CloudbuildTriggerDeveloperConnectEventConfigPush): any;
export declare function cloudbuildTriggerDeveloperConnectEventConfigPushToHclTerraform(struct?: CloudbuildTriggerDeveloperConnectEventConfigPushOutputReference | CloudbuildTriggerDeveloperConnectEventConfigPush): any;
export declare class CloudbuildTriggerDeveloperConnectEventConfigPushOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildTriggerDeveloperConnectEventConfigPush | undefined;
    set internalValue(value: CloudbuildTriggerDeveloperConnectEventConfigPush | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _invertRegex?;
    get invertRegex(): boolean | cdktn.IResolvable;
    set invertRegex(value: boolean | cdktn.IResolvable);
    resetInvertRegex(): void;
    get invertRegexInput(): boolean | cdktn.IResolvable | undefined;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    resetTag(): void;
    get tagInput(): string | undefined;
}
export interface CloudbuildTriggerDeveloperConnectEventConfig {
    /**
    * The Developer Connect Git repository link, formatted as 'projects/* /locations/* /connections/* /gitRepositoryLink/*'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#git_repository_link CloudbuildTrigger#git_repository_link}
     *
    * Note: The above comment contained a comment block ending sequence (* followed by /). We have introduced a space between to prevent syntax errors. Please ignore the space.
    */
    readonly gitRepositoryLink: string;
    /**
    * pull_request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#pull_request CloudbuildTrigger#pull_request}
    */
    readonly pullRequest?: CloudbuildTriggerDeveloperConnectEventConfigPullRequest;
    /**
    * push block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#push CloudbuildTrigger#push}
    */
    readonly push?: CloudbuildTriggerDeveloperConnectEventConfigPush;
}
export declare function cloudbuildTriggerDeveloperConnectEventConfigToTerraform(struct?: CloudbuildTriggerDeveloperConnectEventConfigOutputReference | CloudbuildTriggerDeveloperConnectEventConfig): any;
export declare function cloudbuildTriggerDeveloperConnectEventConfigToHclTerraform(struct?: CloudbuildTriggerDeveloperConnectEventConfigOutputReference | CloudbuildTriggerDeveloperConnectEventConfig): any;
export declare class CloudbuildTriggerDeveloperConnectEventConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildTriggerDeveloperConnectEventConfig | undefined;
    set internalValue(value: CloudbuildTriggerDeveloperConnectEventConfig | undefined);
    private _gitRepositoryLink?;
    get gitRepositoryLink(): string;
    set gitRepositoryLink(value: string);
    get gitRepositoryLinkInput(): string | undefined;
    get gitRepositoryLinkType(): string;
    private _pullRequest;
    get pullRequest(): CloudbuildTriggerDeveloperConnectEventConfigPullRequestOutputReference;
    putPullRequest(value: CloudbuildTriggerDeveloperConnectEventConfigPullRequest): void;
    resetPullRequest(): void;
    get pullRequestInput(): CloudbuildTriggerDeveloperConnectEventConfigPullRequest | undefined;
    private _push;
    get push(): CloudbuildTriggerDeveloperConnectEventConfigPushOutputReference;
    putPush(value: CloudbuildTriggerDeveloperConnectEventConfigPush): void;
    resetPush(): void;
    get pushInput(): CloudbuildTriggerDeveloperConnectEventConfigPush | undefined;
}
export interface CloudbuildTriggerGitFileSource {
    /**
    * The full resource name of the bitbucket server config.
    * Format: projects/{project}/locations/{location}/bitbucketServerConfigs/{id}.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#bitbucket_server_config CloudbuildTrigger#bitbucket_server_config}
    */
    readonly bitbucketServerConfig?: string;
    /**
    * The full resource name of the github enterprise config.
    * Format: projects/{project}/locations/{location}/githubEnterpriseConfigs/{id}. projects/{project}/githubEnterpriseConfigs/{id}.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#github_enterprise_config CloudbuildTrigger#github_enterprise_config}
    */
    readonly githubEnterpriseConfig?: string;
    /**
    * The path of the file, with the repo root as the root of the path.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#path CloudbuildTrigger#path}
    */
    readonly path: string;
    /**
    * The type of the repo, since it may not be explicit from the repo field (e.g from a URL).
    * Values can be UNKNOWN, CLOUD_SOURCE_REPOSITORIES, GITHUB, BITBUCKET_SERVER Possible values: ["UNKNOWN", "CLOUD_SOURCE_REPOSITORIES", "GITHUB", "BITBUCKET_SERVER"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#repo_type CloudbuildTrigger#repo_type}
    */
    readonly repoType: string;
    /**
    * The fully qualified resource name of the Repo API repository. The fully qualified resource name of the Repo API repository.
    * If unspecified, the repo from which the trigger invocation originated is assumed to be the repo from which to read the specified path.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#repository CloudbuildTrigger#repository}
    */
    readonly repository?: string;
    /**
    * The branch, tag, arbitrary ref, or SHA version of the repo to use when resolving the
    * filename (optional). This field respects the same syntax/resolution as described here: https://git-scm.com/docs/gitrevisions
    * If unspecified, the revision from which the trigger invocation originated is assumed to be the revision from which to read the specified path.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#revision CloudbuildTrigger#revision}
    */
    readonly revision?: string;
    /**
    * The URI of the repo (optional). If unspecified, the repo from which the trigger
    * invocation originated is assumed to be the repo from which to read the specified path.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#uri CloudbuildTrigger#uri}
    */
    readonly uri?: string;
}
export declare function cloudbuildTriggerGitFileSourceToTerraform(struct?: CloudbuildTriggerGitFileSourceOutputReference | CloudbuildTriggerGitFileSource): any;
export declare function cloudbuildTriggerGitFileSourceToHclTerraform(struct?: CloudbuildTriggerGitFileSourceOutputReference | CloudbuildTriggerGitFileSource): any;
export declare class CloudbuildTriggerGitFileSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildTriggerGitFileSource | undefined;
    set internalValue(value: CloudbuildTriggerGitFileSource | undefined);
    private _bitbucketServerConfig?;
    get bitbucketServerConfig(): string;
    set bitbucketServerConfig(value: string);
    resetBitbucketServerConfig(): void;
    get bitbucketServerConfigInput(): string | undefined;
    private _githubEnterpriseConfig?;
    get githubEnterpriseConfig(): string;
    set githubEnterpriseConfig(value: string);
    resetGithubEnterpriseConfig(): void;
    get githubEnterpriseConfigInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _repoType?;
    get repoType(): string;
    set repoType(value: string);
    get repoTypeInput(): string | undefined;
    private _repository?;
    get repository(): string;
    set repository(value: string);
    resetRepository(): void;
    get repositoryInput(): string | undefined;
    private _revision?;
    get revision(): string;
    set revision(value: string);
    resetRevision(): void;
    get revisionInput(): string | undefined;
    private _uri?;
    get uri(): string;
    set uri(value: string);
    resetUri(): void;
    get uriInput(): string | undefined;
}
export interface CloudbuildTriggerGithubPullRequest {
    /**
    * Regex of branches to match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#branch CloudbuildTrigger#branch}
    */
    readonly branch: string;
    /**
    * Whether to block builds on a "/gcbrun" comment from a repository owner or collaborator. Possible values: ["COMMENTS_DISABLED", "COMMENTS_ENABLED", "COMMENTS_ENABLED_FOR_EXTERNAL_CONTRIBUTORS_ONLY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#comment_control CloudbuildTrigger#comment_control}
    */
    readonly commentControl?: string;
    /**
    * If true, branches that do NOT match the git_ref will trigger a build.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#invert_regex CloudbuildTrigger#invert_regex}
    */
    readonly invertRegex?: boolean | cdktn.IResolvable;
}
export declare function cloudbuildTriggerGithubPullRequestToTerraform(struct?: CloudbuildTriggerGithubPullRequestOutputReference | CloudbuildTriggerGithubPullRequest): any;
export declare function cloudbuildTriggerGithubPullRequestToHclTerraform(struct?: CloudbuildTriggerGithubPullRequestOutputReference | CloudbuildTriggerGithubPullRequest): any;
export declare class CloudbuildTriggerGithubPullRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildTriggerGithubPullRequest | undefined;
    set internalValue(value: CloudbuildTriggerGithubPullRequest | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    get branchInput(): string | undefined;
    private _commentControl?;
    get commentControl(): string;
    set commentControl(value: string);
    resetCommentControl(): void;
    get commentControlInput(): string | undefined;
    private _invertRegex?;
    get invertRegex(): boolean | cdktn.IResolvable;
    set invertRegex(value: boolean | cdktn.IResolvable);
    resetInvertRegex(): void;
    get invertRegexInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CloudbuildTriggerGithubPush {
    /**
    * Regex of branches to match.  Specify only one of branch or tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#branch CloudbuildTrigger#branch}
    */
    readonly branch?: string;
    /**
    * When true, only trigger a build if the revision regex does NOT match the git_ref regex.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#invert_regex CloudbuildTrigger#invert_regex}
    */
    readonly invertRegex?: boolean | cdktn.IResolvable;
    /**
    * Regex of tags to match.  Specify only one of branch or tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#tag CloudbuildTrigger#tag}
    */
    readonly tag?: string;
}
export declare function cloudbuildTriggerGithubPushToTerraform(struct?: CloudbuildTriggerGithubPushOutputReference | CloudbuildTriggerGithubPush): any;
export declare function cloudbuildTriggerGithubPushToHclTerraform(struct?: CloudbuildTriggerGithubPushOutputReference | CloudbuildTriggerGithubPush): any;
export declare class CloudbuildTriggerGithubPushOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildTriggerGithubPush | undefined;
    set internalValue(value: CloudbuildTriggerGithubPush | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _invertRegex?;
    get invertRegex(): boolean | cdktn.IResolvable;
    set invertRegex(value: boolean | cdktn.IResolvable);
    resetInvertRegex(): void;
    get invertRegexInput(): boolean | cdktn.IResolvable | undefined;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    resetTag(): void;
    get tagInput(): string | undefined;
}
export interface CloudbuildTriggerGithub {
    /**
    * The resource name of the github enterprise config that should be applied to this installation.
    * For example: "projects/{$projectId}/locations/{$locationId}/githubEnterpriseConfigs/{$configId}"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#enterprise_config_resource_name CloudbuildTrigger#enterprise_config_resource_name}
    */
    readonly enterpriseConfigResourceName?: string;
    /**
    * Name of the repository. For example: The name for
    * https://github.com/googlecloudplatform/cloud-builders is "cloud-builders".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#name CloudbuildTrigger#name}
    */
    readonly name?: string;
    /**
    * Owner of the repository. For example: The owner for
    * https://github.com/googlecloudplatform/cloud-builders is "googlecloudplatform".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#owner CloudbuildTrigger#owner}
    */
    readonly owner?: string;
    /**
    * pull_request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#pull_request CloudbuildTrigger#pull_request}
    */
    readonly pullRequest?: CloudbuildTriggerGithubPullRequest;
    /**
    * push block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#push CloudbuildTrigger#push}
    */
    readonly push?: CloudbuildTriggerGithubPush;
}
export declare function cloudbuildTriggerGithubToTerraform(struct?: CloudbuildTriggerGithubOutputReference | CloudbuildTriggerGithub): any;
export declare function cloudbuildTriggerGithubToHclTerraform(struct?: CloudbuildTriggerGithubOutputReference | CloudbuildTriggerGithub): any;
export declare class CloudbuildTriggerGithubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildTriggerGithub | undefined;
    set internalValue(value: CloudbuildTriggerGithub | undefined);
    private _enterpriseConfigResourceName?;
    get enterpriseConfigResourceName(): string;
    set enterpriseConfigResourceName(value: string);
    resetEnterpriseConfigResourceName(): void;
    get enterpriseConfigResourceNameInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _pullRequest;
    get pullRequest(): CloudbuildTriggerGithubPullRequestOutputReference;
    putPullRequest(value: CloudbuildTriggerGithubPullRequest): void;
    resetPullRequest(): void;
    get pullRequestInput(): CloudbuildTriggerGithubPullRequest | undefined;
    private _push;
    get push(): CloudbuildTriggerGithubPushOutputReference;
    putPush(value: CloudbuildTriggerGithubPush): void;
    resetPush(): void;
    get pushInput(): CloudbuildTriggerGithubPush | undefined;
}
export interface CloudbuildTriggerPubsubConfig {
    /**
    * Service account that will make the push request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#service_account_email CloudbuildTrigger#service_account_email}
    */
    readonly serviceAccountEmail?: string;
    /**
    * The name of the topic from which this subscription is receiving messages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#topic CloudbuildTrigger#topic}
    */
    readonly topic: string;
}
export declare function cloudbuildTriggerPubsubConfigToTerraform(struct?: CloudbuildTriggerPubsubConfigOutputReference | CloudbuildTriggerPubsubConfig): any;
export declare function cloudbuildTriggerPubsubConfigToHclTerraform(struct?: CloudbuildTriggerPubsubConfigOutputReference | CloudbuildTriggerPubsubConfig): any;
export declare class CloudbuildTriggerPubsubConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildTriggerPubsubConfig | undefined;
    set internalValue(value: CloudbuildTriggerPubsubConfig | undefined);
    private _serviceAccountEmail?;
    get serviceAccountEmail(): string;
    set serviceAccountEmail(value: string);
    resetServiceAccountEmail(): void;
    get serviceAccountEmailInput(): string | undefined;
    get state(): string;
    get subscription(): string;
    private _topic?;
    get topic(): string;
    set topic(value: string);
    get topicInput(): string | undefined;
}
export interface CloudbuildTriggerRepositoryEventConfigPullRequest {
    /**
    * Regex of branches to match.
    *
    * The syntax of the regular expressions accepted is the syntax accepted by
    * RE2 and described at https://github.com/google/re2/wiki/Syntax
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#branch CloudbuildTrigger#branch}
    */
    readonly branch?: string;
    /**
    * Configure builds to run whether a repository owner or collaborator need to comment '/gcbrun'. Possible values: ["COMMENTS_DISABLED", "COMMENTS_ENABLED", "COMMENTS_ENABLED_FOR_EXTERNAL_CONTRIBUTORS_ONLY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#comment_control CloudbuildTrigger#comment_control}
    */
    readonly commentControl?: string;
    /**
    * If true, branches that do NOT match the git_ref will trigger a build.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#invert_regex CloudbuildTrigger#invert_regex}
    */
    readonly invertRegex?: boolean | cdktn.IResolvable;
}
export declare function cloudbuildTriggerRepositoryEventConfigPullRequestToTerraform(struct?: CloudbuildTriggerRepositoryEventConfigPullRequestOutputReference | CloudbuildTriggerRepositoryEventConfigPullRequest): any;
export declare function cloudbuildTriggerRepositoryEventConfigPullRequestToHclTerraform(struct?: CloudbuildTriggerRepositoryEventConfigPullRequestOutputReference | CloudbuildTriggerRepositoryEventConfigPullRequest): any;
export declare class CloudbuildTriggerRepositoryEventConfigPullRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildTriggerRepositoryEventConfigPullRequest | undefined;
    set internalValue(value: CloudbuildTriggerRepositoryEventConfigPullRequest | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _commentControl?;
    get commentControl(): string;
    set commentControl(value: string);
    resetCommentControl(): void;
    get commentControlInput(): string | undefined;
    private _invertRegex?;
    get invertRegex(): boolean | cdktn.IResolvable;
    set invertRegex(value: boolean | cdktn.IResolvable);
    resetInvertRegex(): void;
    get invertRegexInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CloudbuildTriggerRepositoryEventConfigPush {
    /**
    * Regex of branches to match.
    *
    * The syntax of the regular expressions accepted is the syntax accepted by
    * RE2 and described at https://github.com/google/re2/wiki/Syntax
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#branch CloudbuildTrigger#branch}
    */
    readonly branch?: string;
    /**
    * If true, only trigger a build if the revision regex does NOT match the git_ref regex.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#invert_regex CloudbuildTrigger#invert_regex}
    */
    readonly invertRegex?: boolean | cdktn.IResolvable;
    /**
    * Regex of tags to match.
    *
    * The syntax of the regular expressions accepted is the syntax accepted by
    * RE2 and described at https://github.com/google/re2/wiki/Syntax
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#tag CloudbuildTrigger#tag}
    */
    readonly tag?: string;
}
export declare function cloudbuildTriggerRepositoryEventConfigPushToTerraform(struct?: CloudbuildTriggerRepositoryEventConfigPushOutputReference | CloudbuildTriggerRepositoryEventConfigPush): any;
export declare function cloudbuildTriggerRepositoryEventConfigPushToHclTerraform(struct?: CloudbuildTriggerRepositoryEventConfigPushOutputReference | CloudbuildTriggerRepositoryEventConfigPush): any;
export declare class CloudbuildTriggerRepositoryEventConfigPushOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildTriggerRepositoryEventConfigPush | undefined;
    set internalValue(value: CloudbuildTriggerRepositoryEventConfigPush | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _invertRegex?;
    get invertRegex(): boolean | cdktn.IResolvable;
    set invertRegex(value: boolean | cdktn.IResolvable);
    resetInvertRegex(): void;
    get invertRegexInput(): boolean | cdktn.IResolvable | undefined;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    resetTag(): void;
    get tagInput(): string | undefined;
}
export interface CloudbuildTriggerRepositoryEventConfig {
    /**
    * The resource name of the Repo API resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#repository CloudbuildTrigger#repository}
    */
    readonly repository?: string;
    /**
    * pull_request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#pull_request CloudbuildTrigger#pull_request}
    */
    readonly pullRequest?: CloudbuildTriggerRepositoryEventConfigPullRequest;
    /**
    * push block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#push CloudbuildTrigger#push}
    */
    readonly push?: CloudbuildTriggerRepositoryEventConfigPush;
}
export declare function cloudbuildTriggerRepositoryEventConfigToTerraform(struct?: CloudbuildTriggerRepositoryEventConfigOutputReference | CloudbuildTriggerRepositoryEventConfig): any;
export declare function cloudbuildTriggerRepositoryEventConfigToHclTerraform(struct?: CloudbuildTriggerRepositoryEventConfigOutputReference | CloudbuildTriggerRepositoryEventConfig): any;
export declare class CloudbuildTriggerRepositoryEventConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildTriggerRepositoryEventConfig | undefined;
    set internalValue(value: CloudbuildTriggerRepositoryEventConfig | undefined);
    private _repository?;
    get repository(): string;
    set repository(value: string);
    resetRepository(): void;
    get repositoryInput(): string | undefined;
    private _pullRequest;
    get pullRequest(): CloudbuildTriggerRepositoryEventConfigPullRequestOutputReference;
    putPullRequest(value: CloudbuildTriggerRepositoryEventConfigPullRequest): void;
    resetPullRequest(): void;
    get pullRequestInput(): CloudbuildTriggerRepositoryEventConfigPullRequest | undefined;
    private _push;
    get push(): CloudbuildTriggerRepositoryEventConfigPushOutputReference;
    putPush(value: CloudbuildTriggerRepositoryEventConfigPush): void;
    resetPush(): void;
    get pushInput(): CloudbuildTriggerRepositoryEventConfigPush | undefined;
}
export interface CloudbuildTriggerSourceToBuild {
    /**
    * The full resource name of the bitbucket server config.
    * Format: projects/{project}/locations/{location}/bitbucketServerConfigs/{id}.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#bitbucket_server_config CloudbuildTrigger#bitbucket_server_config}
    */
    readonly bitbucketServerConfig?: string;
    /**
    * The full resource name of the github enterprise config.
    * Format: projects/{project}/locations/{location}/githubEnterpriseConfigs/{id}. projects/{project}/githubEnterpriseConfigs/{id}.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#github_enterprise_config CloudbuildTrigger#github_enterprise_config}
    */
    readonly githubEnterpriseConfig?: string;
    /**
    * The branch or tag to use. Must start with "refs/" (required).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#ref CloudbuildTrigger#ref}
    */
    readonly ref: string;
    /**
    * The type of the repo, since it may not be explicit from the repo field (e.g from a URL).
    * Values can be UNKNOWN, CLOUD_SOURCE_REPOSITORIES, GITHUB, BITBUCKET_SERVER Possible values: ["UNKNOWN", "CLOUD_SOURCE_REPOSITORIES", "GITHUB", "BITBUCKET_SERVER"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#repo_type CloudbuildTrigger#repo_type}
    */
    readonly repoType: string;
    /**
    * The qualified resource name of the Repo API repository.
    * Either uri or repository can be specified and is required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#repository CloudbuildTrigger#repository}
    */
    readonly repository?: string;
    /**
    * The URI of the repo.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#uri CloudbuildTrigger#uri}
    */
    readonly uri?: string;
}
export declare function cloudbuildTriggerSourceToBuildToTerraform(struct?: CloudbuildTriggerSourceToBuildOutputReference | CloudbuildTriggerSourceToBuild): any;
export declare function cloudbuildTriggerSourceToBuildToHclTerraform(struct?: CloudbuildTriggerSourceToBuildOutputReference | CloudbuildTriggerSourceToBuild): any;
export declare class CloudbuildTriggerSourceToBuildOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildTriggerSourceToBuild | undefined;
    set internalValue(value: CloudbuildTriggerSourceToBuild | undefined);
    private _bitbucketServerConfig?;
    get bitbucketServerConfig(): string;
    set bitbucketServerConfig(value: string);
    resetBitbucketServerConfig(): void;
    get bitbucketServerConfigInput(): string | undefined;
    private _githubEnterpriseConfig?;
    get githubEnterpriseConfig(): string;
    set githubEnterpriseConfig(value: string);
    resetGithubEnterpriseConfig(): void;
    get githubEnterpriseConfigInput(): string | undefined;
    private _ref?;
    get ref(): string;
    set ref(value: string);
    get refInput(): string | undefined;
    private _repoType?;
    get repoType(): string;
    set repoType(value: string);
    get repoTypeInput(): string | undefined;
    private _repository?;
    get repository(): string;
    set repository(value: string);
    resetRepository(): void;
    get repositoryInput(): string | undefined;
    private _uri?;
    get uri(): string;
    set uri(value: string);
    resetUri(): void;
    get uriInput(): string | undefined;
}
export interface CloudbuildTriggerTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#create CloudbuildTrigger#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#delete CloudbuildTrigger#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#update CloudbuildTrigger#update}
    */
    readonly update?: string;
}
export declare function cloudbuildTriggerTimeoutsToTerraform(struct?: CloudbuildTriggerTimeouts | cdktn.IResolvable): any;
export declare function cloudbuildTriggerTimeoutsToHclTerraform(struct?: CloudbuildTriggerTimeouts | cdktn.IResolvable): any;
export declare class CloudbuildTriggerTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildTriggerTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CloudbuildTriggerTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface CloudbuildTriggerTriggerTemplate {
    /**
    * Name of the branch to build. Exactly one a of branch name, tag, or commit SHA must be provided.
    * This field is a regular expression.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#branch_name CloudbuildTrigger#branch_name}
    */
    readonly branchName?: string;
    /**
    * Explicit commit SHA to build. Exactly one of a branch name, tag, or commit SHA must be provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#commit_sha CloudbuildTrigger#commit_sha}
    */
    readonly commitSha?: string;
    /**
    * Directory, relative to the source root, in which to run the build.
    *
    * This must be a relative path. If a step's dir is specified and
    * is an absolute path, this value is ignored for that step's
    * execution.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#dir CloudbuildTrigger#dir}
    */
    readonly dir?: string;
    /**
    * Only trigger a build if the revision regex does NOT match the revision regex.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#invert_regex CloudbuildTrigger#invert_regex}
    */
    readonly invertRegex?: boolean | cdktn.IResolvable;
    /**
    * ID of the project that owns the Cloud Source Repository. If
    * omitted, the project ID requesting the build is assumed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#project_id CloudbuildTrigger#project_id}
    */
    readonly projectId?: string;
    /**
    * Name of the Cloud Source Repository. If omitted, the name "default" is assumed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#repo_name CloudbuildTrigger#repo_name}
    */
    readonly repoName?: string;
    /**
    * Name of the tag to build. Exactly one of a branch name, tag, or commit SHA must be provided.
    * This field is a regular expression.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#tag_name CloudbuildTrigger#tag_name}
    */
    readonly tagName?: string;
}
export declare function cloudbuildTriggerTriggerTemplateToTerraform(struct?: CloudbuildTriggerTriggerTemplateOutputReference | CloudbuildTriggerTriggerTemplate): any;
export declare function cloudbuildTriggerTriggerTemplateToHclTerraform(struct?: CloudbuildTriggerTriggerTemplateOutputReference | CloudbuildTriggerTriggerTemplate): any;
export declare class CloudbuildTriggerTriggerTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildTriggerTriggerTemplate | undefined;
    set internalValue(value: CloudbuildTriggerTriggerTemplate | undefined);
    private _branchName?;
    get branchName(): string;
    set branchName(value: string);
    resetBranchName(): void;
    get branchNameInput(): string | undefined;
    private _commitSha?;
    get commitSha(): string;
    set commitSha(value: string);
    resetCommitSha(): void;
    get commitShaInput(): string | undefined;
    private _dir?;
    get dir(): string;
    set dir(value: string);
    resetDir(): void;
    get dirInput(): string | undefined;
    private _invertRegex?;
    get invertRegex(): boolean | cdktn.IResolvable;
    set invertRegex(value: boolean | cdktn.IResolvable);
    resetInvertRegex(): void;
    get invertRegexInput(): boolean | cdktn.IResolvable | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _repoName?;
    get repoName(): string;
    set repoName(value: string);
    resetRepoName(): void;
    get repoNameInput(): string | undefined;
    private _tagName?;
    get tagName(): string;
    set tagName(value: string);
    resetTagName(): void;
    get tagNameInput(): string | undefined;
}
export interface CloudbuildTriggerWebhookConfig {
    /**
    * Resource name for the secret required as a URL parameter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#secret CloudbuildTrigger#secret}
    */
    readonly secret: string;
}
export declare function cloudbuildTriggerWebhookConfigToTerraform(struct?: CloudbuildTriggerWebhookConfigOutputReference | CloudbuildTriggerWebhookConfig): any;
export declare function cloudbuildTriggerWebhookConfigToHclTerraform(struct?: CloudbuildTriggerWebhookConfigOutputReference | CloudbuildTriggerWebhookConfig): any;
export declare class CloudbuildTriggerWebhookConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudbuildTriggerWebhookConfig | undefined;
    set internalValue(value: CloudbuildTriggerWebhookConfig | undefined);
    private _secret?;
    get secret(): string;
    set secret(value: string);
    get secretInput(): string | undefined;
    get state(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger google_cloudbuild_trigger}
*/
export declare class CloudbuildTrigger extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_cloudbuild_trigger";
    /**
    * Generates CDKTN code for importing a CloudbuildTrigger resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudbuildTrigger to import
    * @param importFromId The id of the existing CloudbuildTrigger that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudbuildTrigger to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloudbuild_trigger google_cloudbuild_trigger} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudbuildTriggerConfig = {}
    */
    constructor(scope: Construct, id: string, config?: CloudbuildTriggerConfig);
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _filename?;
    get filename(): string;
    set filename(value: string);
    resetFilename(): void;
    get filenameInput(): string | undefined;
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ignoredFiles?;
    get ignoredFiles(): string[];
    set ignoredFiles(value: string[]);
    resetIgnoredFiles(): void;
    get ignoredFilesInput(): string[] | undefined;
    private _includeBuildLogs?;
    get includeBuildLogs(): string;
    set includeBuildLogs(value: string);
    resetIncludeBuildLogs(): void;
    get includeBuildLogsInput(): string | undefined;
    private _includedFiles?;
    get includedFiles(): string[];
    set includedFiles(value: string[]);
    resetIncludedFiles(): void;
    get includedFilesInput(): string[] | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _serviceAccount?;
    get serviceAccount(): string;
    set serviceAccount(value: string);
    resetServiceAccount(): void;
    get serviceAccountInput(): string | undefined;
    private _substitutions?;
    get substitutions(): {
        [key: string]: string;
    };
    set substitutions(value: {
        [key: string]: string;
    });
    resetSubstitutions(): void;
    get substitutionsInput(): {
        [key: string]: string;
    } | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    get triggerId(): string;
    private _approvalConfig;
    get approvalConfig(): CloudbuildTriggerApprovalConfigOutputReference;
    putApprovalConfig(value: CloudbuildTriggerApprovalConfig): void;
    resetApprovalConfig(): void;
    get approvalConfigInput(): CloudbuildTriggerApprovalConfig | undefined;
    private _bitbucketServerTriggerConfig;
    get bitbucketServerTriggerConfig(): CloudbuildTriggerBitbucketServerTriggerConfigOutputReference;
    putBitbucketServerTriggerConfig(value: CloudbuildTriggerBitbucketServerTriggerConfig): void;
    resetBitbucketServerTriggerConfig(): void;
    get bitbucketServerTriggerConfigInput(): CloudbuildTriggerBitbucketServerTriggerConfig | undefined;
    private _build;
    get buildAttribute(): CloudbuildTriggerBuildOutputReference;
    putBuildAttribute(value: CloudbuildTriggerBuild): void;
    resetBuildAttribute(): void;
    get buildAttributeInput(): CloudbuildTriggerBuild | undefined;
    private _developerConnectEventConfig;
    get developerConnectEventConfig(): CloudbuildTriggerDeveloperConnectEventConfigOutputReference;
    putDeveloperConnectEventConfig(value: CloudbuildTriggerDeveloperConnectEventConfig): void;
    resetDeveloperConnectEventConfig(): void;
    get developerConnectEventConfigInput(): CloudbuildTriggerDeveloperConnectEventConfig | undefined;
    private _gitFileSource;
    get gitFileSource(): CloudbuildTriggerGitFileSourceOutputReference;
    putGitFileSource(value: CloudbuildTriggerGitFileSource): void;
    resetGitFileSource(): void;
    get gitFileSourceInput(): CloudbuildTriggerGitFileSource | undefined;
    private _github;
    get github(): CloudbuildTriggerGithubOutputReference;
    putGithub(value: CloudbuildTriggerGithub): void;
    resetGithub(): void;
    get githubInput(): CloudbuildTriggerGithub | undefined;
    private _pubsubConfig;
    get pubsubConfig(): CloudbuildTriggerPubsubConfigOutputReference;
    putPubsubConfig(value: CloudbuildTriggerPubsubConfig): void;
    resetPubsubConfig(): void;
    get pubsubConfigInput(): CloudbuildTriggerPubsubConfig | undefined;
    private _repositoryEventConfig;
    get repositoryEventConfig(): CloudbuildTriggerRepositoryEventConfigOutputReference;
    putRepositoryEventConfig(value: CloudbuildTriggerRepositoryEventConfig): void;
    resetRepositoryEventConfig(): void;
    get repositoryEventConfigInput(): CloudbuildTriggerRepositoryEventConfig | undefined;
    private _sourceToBuild;
    get sourceToBuild(): CloudbuildTriggerSourceToBuildOutputReference;
    putSourceToBuild(value: CloudbuildTriggerSourceToBuild): void;
    resetSourceToBuild(): void;
    get sourceToBuildInput(): CloudbuildTriggerSourceToBuild | undefined;
    private _timeouts;
    get timeouts(): CloudbuildTriggerTimeoutsOutputReference;
    putTimeouts(value: CloudbuildTriggerTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CloudbuildTriggerTimeouts | undefined;
    private _triggerTemplate;
    get triggerTemplate(): CloudbuildTriggerTriggerTemplateOutputReference;
    putTriggerTemplate(value: CloudbuildTriggerTriggerTemplate): void;
    resetTriggerTemplate(): void;
    get triggerTemplateInput(): CloudbuildTriggerTriggerTemplate | undefined;
    private _webhookConfig;
    get webhookConfig(): CloudbuildTriggerWebhookConfigOutputReference;
    putWebhookConfig(value: CloudbuildTriggerWebhookConfig): void;
    resetWebhookConfig(): void;
    get webhookConfigInput(): CloudbuildTriggerWebhookConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
