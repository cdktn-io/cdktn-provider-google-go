/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeRegionHealthSourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_health_source#deletion_policy ComputeRegionHealthSource#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource. Provide this property when you
    * create the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_health_source#description ComputeRegionHealthSource#description}
    */
    readonly description?: string;
    /**
    * URL to the 'HealthAggregationPolicy' resource. Must be set. Must
    * be regional and in the same region as the 'HealthSource'. Can be
    * mutated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_health_source#health_aggregation_policy ComputeRegionHealthSource#health_aggregation_policy}
    */
    readonly healthAggregationPolicy?: string;
    /**
    * Name of the resource. Provided by the client when the resource is created.
    * The name must be 1-63 characters long, and comply with RFC1035.
    * Specifically, the name must be 1-63 characters long and match the regular
    * expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the first
    * character must be a lowercase letter, and all following characters must
    * be a dash, lowercase letter, or digit, except the last character, which
    * cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_health_source#name ComputeRegionHealthSource#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_health_source#project ComputeRegionHealthSource#project}
    */
    readonly project?: string;
    /**
    * URL of the region where the health source resides.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_health_source#region ComputeRegionHealthSource#region}
    */
    readonly region: string;
    /**
    * Specifies the type of the 'HealthSource'. The only allowed value
    * is 'BACKEND_SERVICE'. Must be specified when the
    * 'HealthSource' is created, and cannot be mutated. Possible values: ["BACKEND_SERVICE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_health_source#source_type ComputeRegionHealthSource#source_type}
    */
    readonly sourceType: string;
    /**
    * URLs to the source resources. Must be size 1. Must be a
    * 'BackendService' if the 'sourceType' is 'BACKEND_SERVICE'. The
    * 'BackendService' must have load balancing scheme
    * 'INTERNAL' or 'INTERNAL_MANAGED' and must be regional
    * and in the same region as the 'HealthSource' (cross-region
    * deployment for 'INTERNAL_MANAGED' is not supported). The
    * 'BackendService' may use only IGs, MIGs, or NEGs of type
    * 'GCE_VM_IP' or 'GCE_VM_IP_PORT'. The
    * 'BackendService' may not use 'haPolicy'. Can be
    * mutated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_health_source#sources ComputeRegionHealthSource#sources}
    */
    readonly sources?: string[];
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_health_source#timeouts ComputeRegionHealthSource#timeouts}
    */
    readonly timeouts?: ComputeRegionHealthSourceTimeouts;
}
export interface ComputeRegionHealthSourceTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_health_source#create ComputeRegionHealthSource#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_health_source#delete ComputeRegionHealthSource#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_health_source#update ComputeRegionHealthSource#update}
    */
    readonly update?: string;
}
export declare function computeRegionHealthSourceTimeoutsToTerraform(struct?: ComputeRegionHealthSourceTimeouts | cdktn.IResolvable): any;
export declare function computeRegionHealthSourceTimeoutsToHclTerraform(struct?: ComputeRegionHealthSourceTimeouts | cdktn.IResolvable): any;
export declare class ComputeRegionHealthSourceTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeRegionHealthSourceTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeRegionHealthSourceTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_health_source google_compute_region_health_source}
*/
export declare class ComputeRegionHealthSource extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_region_health_source";
    /**
    * Generates CDKTN code for importing a ComputeRegionHealthSource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeRegionHealthSource to import
    * @param importFromId The id of the existing ComputeRegionHealthSource that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_health_source#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeRegionHealthSource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_region_health_source google_compute_region_health_source} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeRegionHealthSourceConfig
    */
    constructor(scope: Construct, id: string, config: ComputeRegionHealthSourceConfig);
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get fingerprint(): string;
    private _healthAggregationPolicy?;
    get healthAggregationPolicy(): string;
    set healthAggregationPolicy(value: string);
    resetHealthAggregationPolicy(): void;
    get healthAggregationPolicyInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    get selfLinkWithId(): string;
    private _sourceType?;
    get sourceType(): string;
    set sourceType(value: string);
    get sourceTypeInput(): string | undefined;
    private _sources?;
    get sources(): string[];
    set sources(value: string[]);
    resetSources(): void;
    get sourcesInput(): string[] | undefined;
    private _timeouts;
    get timeouts(): ComputeRegionHealthSourceTimeoutsOutputReference;
    putTimeouts(value: ComputeRegionHealthSourceTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeRegionHealthSourceTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
