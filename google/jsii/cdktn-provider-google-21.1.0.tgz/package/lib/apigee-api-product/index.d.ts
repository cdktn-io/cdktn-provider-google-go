/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigeeApiProductConfig extends cdktn.TerraformMetaArguments {
    /**
    * Comma-separated list of API resources to be bundled in the API product. By default, the resource paths are mapped from the proxy.pathsuffix variable.
    * The proxy path suffix is defined as the URI fragment following the ProxyEndpoint base path. For example, if the apiResources element is defined to be /forecastrss and the base path defined for the API proxy is /weather, then only requests to /weather/forecastrss are permitted by the API product.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#api_resources ApigeeApiProduct#api_resources}
    */
    readonly apiResources?: string[];
    /**
    * Flag that specifies how API keys are approved to access the APIs defined by the API product.
    * Valid values are 'auto' or 'manual'. Possible values: ["auto", "manual"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#approval_type ApigeeApiProduct#approval_type}
    */
    readonly approvalType?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#deletion_policy ApigeeApiProduct#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Description of the API product. Include key information about the API product that is not captured by other fields.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#description ApigeeApiProduct#description}
    */
    readonly description?: string;
    /**
    * Name displayed in the UI or developer portal to developers registering for API access.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#display_name ApigeeApiProduct#display_name}
    */
    readonly displayName: string;
    /**
    * Comma-separated list of environment names to which the API product is bound. Requests to environments that are not listed are rejected.
    * By specifying one or more environments, you can bind the resources listed in the API product to a specific environment, preventing developers from accessing those resources through API proxies deployed in another environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#environments ApigeeApiProduct#environments}
    */
    readonly environments?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#id ApigeeApiProduct#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Internal name of the API product.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#name ApigeeApiProduct#name}
    */
    readonly name: string;
    /**
    * The Apigee Organization associated with the Apigee API product,
    * in the format 'organizations/{{org_name}}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#org_id ApigeeApiProduct#org_id}
    */
    readonly orgId: string;
    /**
    * Comma-separated list of API proxy names to which this API product is bound. By specifying API proxies, you can associate resources in the API product with specific API proxies, preventing developers from accessing those resources through other API proxies.
    * Apigee rejects requests to API proxies that are not listed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#proxies ApigeeApiProduct#proxies}
    */
    readonly proxies?: string[];
    /**
    * Number of request messages permitted per app by this API product for the specified quotaInterval and quotaTimeUnit.
    * For example, a quota of 50, for a quotaInterval of 12 and a quotaTimeUnit of hours means 50 requests are allowed every 12 hours.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#quota ApigeeApiProduct#quota}
    */
    readonly quota?: string;
    /**
    * Scope of the quota decides how the quota counter gets applied and evaluate for quota violation. If the Scope is set as PROXY, then all the operations defined for the APIproduct that are associated with the same proxy will share the same quota counter set at the APIproduct level, making it a global counter at a proxy level. If the Scope is set as OPERATION, then each operations get the counter set at the API product dedicated, making it a local counter. Note that, the QuotaCounterScope applies only when an operation does not have dedicated quota set for itself. Possible values: ["QUOTA_COUNTER_SCOPE_UNSPECIFIED", "PROXY", "OPERATION"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#quota_counter_scope ApigeeApiProduct#quota_counter_scope}
    */
    readonly quotaCounterScope?: string;
    /**
    * Time interval over which the number of request messages is calculated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#quota_interval ApigeeApiProduct#quota_interval}
    */
    readonly quotaInterval?: string;
    /**
    * Time unit defined for the quotaInterval. Valid values include second, minute, hour, day, month or year.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#quota_time_unit ApigeeApiProduct#quota_time_unit}
    */
    readonly quotaTimeUnit?: string;
    /**
    * Comma-separated list of OAuth scopes that are validated at runtime. Apigee validates that the scopes in any access token presented match the scopes defined in the OAuth policy associated with the API product.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#scopes ApigeeApiProduct#scopes}
    */
    readonly scopes?: string[];
    /**
    * Optional. The resource ID of the parent Space. If not set, the parent resource will be the Organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#space ApigeeApiProduct#space}
    */
    readonly space?: string;
    /**
    * attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#attributes ApigeeApiProduct#attributes}
    */
    readonly attributes?: ApigeeApiProductAttributes[] | cdktn.IResolvable;
    /**
    * graphql_operation_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#graphql_operation_group ApigeeApiProduct#graphql_operation_group}
    */
    readonly graphqlOperationGroup?: ApigeeApiProductGraphqlOperationGroup;
    /**
    * grpc_operation_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#grpc_operation_group ApigeeApiProduct#grpc_operation_group}
    */
    readonly grpcOperationGroup?: ApigeeApiProductGrpcOperationGroup;
    /**
    * operation_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#operation_group ApigeeApiProduct#operation_group}
    */
    readonly operationGroup?: ApigeeApiProductOperationGroup;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#timeouts ApigeeApiProduct#timeouts}
    */
    readonly timeouts?: ApigeeApiProductTimeouts;
}
export interface ApigeeApiProductAttributes {
    /**
    * Key of the attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#name ApigeeApiProduct#name}
    */
    readonly name?: string;
    /**
    * Value of the attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#value ApigeeApiProduct#value}
    */
    readonly value?: string;
}
export declare function apigeeApiProductAttributesToTerraform(struct?: ApigeeApiProductAttributes | cdktn.IResolvable): any;
export declare function apigeeApiProductAttributesToHclTerraform(struct?: ApigeeApiProductAttributes | cdktn.IResolvable): any;
export declare class ApigeeApiProductAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigeeApiProductAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeApiProductAttributes | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApigeeApiProductAttributesList extends cdktn.ComplexList {
    internalValue?: ApigeeApiProductAttributes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigeeApiProductAttributesOutputReference;
}
export interface ApigeeApiProductGraphqlOperationGroupOperationConfigsAttributes {
    /**
    * Key of the attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#name ApigeeApiProduct#name}
    */
    readonly name?: string;
    /**
    * Value of the attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#value ApigeeApiProduct#value}
    */
    readonly value?: string;
}
export declare function apigeeApiProductGraphqlOperationGroupOperationConfigsAttributesToTerraform(struct?: ApigeeApiProductGraphqlOperationGroupOperationConfigsAttributes | cdktn.IResolvable): any;
export declare function apigeeApiProductGraphqlOperationGroupOperationConfigsAttributesToHclTerraform(struct?: ApigeeApiProductGraphqlOperationGroupOperationConfigsAttributes | cdktn.IResolvable): any;
export declare class ApigeeApiProductGraphqlOperationGroupOperationConfigsAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigeeApiProductGraphqlOperationGroupOperationConfigsAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeApiProductGraphqlOperationGroupOperationConfigsAttributes | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApigeeApiProductGraphqlOperationGroupOperationConfigsAttributesList extends cdktn.ComplexList {
    internalValue?: ApigeeApiProductGraphqlOperationGroupOperationConfigsAttributes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigeeApiProductGraphqlOperationGroupOperationConfigsAttributesOutputReference;
}
export interface ApigeeApiProductGraphqlOperationGroupOperationConfigsOperations {
    /**
    * GraphQL operation name. The name and operation type will be used to apply quotas. If no name is specified, the quota will be applied to all GraphQL operations irrespective of their operation names in the payload.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#operation ApigeeApiProduct#operation}
    */
    readonly operation?: string;
    /**
    * Required. GraphQL operation types. Valid values include query or mutation.
    * Note: Apigee does not currently support subscription types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#operation_types ApigeeApiProduct#operation_types}
    */
    readonly operationTypes?: string[];
}
export declare function apigeeApiProductGraphqlOperationGroupOperationConfigsOperationsToTerraform(struct?: ApigeeApiProductGraphqlOperationGroupOperationConfigsOperations | cdktn.IResolvable): any;
export declare function apigeeApiProductGraphqlOperationGroupOperationConfigsOperationsToHclTerraform(struct?: ApigeeApiProductGraphqlOperationGroupOperationConfigsOperations | cdktn.IResolvable): any;
export declare class ApigeeApiProductGraphqlOperationGroupOperationConfigsOperationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigeeApiProductGraphqlOperationGroupOperationConfigsOperations | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeApiProductGraphqlOperationGroupOperationConfigsOperations | cdktn.IResolvable | undefined);
    private _operation?;
    get operation(): string;
    set operation(value: string);
    resetOperation(): void;
    get operationInput(): string | undefined;
    private _operationTypes?;
    get operationTypes(): string[];
    set operationTypes(value: string[]);
    resetOperationTypes(): void;
    get operationTypesInput(): string[] | undefined;
}
export declare class ApigeeApiProductGraphqlOperationGroupOperationConfigsOperationsList extends cdktn.ComplexList {
    internalValue?: ApigeeApiProductGraphqlOperationGroupOperationConfigsOperations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigeeApiProductGraphqlOperationGroupOperationConfigsOperationsOutputReference;
}
export interface ApigeeApiProductGraphqlOperationGroupOperationConfigsQuota {
    /**
    * Required. Time interval over which the number of request messages is calculated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#interval ApigeeApiProduct#interval}
    */
    readonly interval?: string;
    /**
    * Required. Upper limit allowed for the time interval and time unit specified. Requests exceeding this limit will be rejected.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#limit ApigeeApiProduct#limit}
    */
    readonly limit?: string;
    /**
    * Time unit defined for the interval. Valid values include second, minute, hour, day, month or year. If limit and interval are valid, the default value is hour; otherwise, the default is null.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#time_unit ApigeeApiProduct#time_unit}
    */
    readonly timeUnit?: string;
}
export declare function apigeeApiProductGraphqlOperationGroupOperationConfigsQuotaToTerraform(struct?: ApigeeApiProductGraphqlOperationGroupOperationConfigsQuotaOutputReference | ApigeeApiProductGraphqlOperationGroupOperationConfigsQuota): any;
export declare function apigeeApiProductGraphqlOperationGroupOperationConfigsQuotaToHclTerraform(struct?: ApigeeApiProductGraphqlOperationGroupOperationConfigsQuotaOutputReference | ApigeeApiProductGraphqlOperationGroupOperationConfigsQuota): any;
export declare class ApigeeApiProductGraphqlOperationGroupOperationConfigsQuotaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeApiProductGraphqlOperationGroupOperationConfigsQuota | undefined;
    set internalValue(value: ApigeeApiProductGraphqlOperationGroupOperationConfigsQuota | undefined);
    private _interval?;
    get interval(): string;
    set interval(value: string);
    resetInterval(): void;
    get intervalInput(): string | undefined;
    private _limit?;
    get limit(): string;
    set limit(value: string);
    resetLimit(): void;
    get limitInput(): string | undefined;
    private _timeUnit?;
    get timeUnit(): string;
    set timeUnit(value: string);
    resetTimeUnit(): void;
    get timeUnitInput(): string | undefined;
}
export interface ApigeeApiProductGraphqlOperationGroupOperationConfigs {
    /**
    * Required. Name of the API proxy endpoint or remote service with which the GraphQL operation and quota are associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#api_source ApigeeApiProduct#api_source}
    */
    readonly apiSource?: string;
    /**
    * attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#attributes ApigeeApiProduct#attributes}
    */
    readonly attributes?: ApigeeApiProductGraphqlOperationGroupOperationConfigsAttributes[] | cdktn.IResolvable;
    /**
    * operations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#operations ApigeeApiProduct#operations}
    */
    readonly operations?: ApigeeApiProductGraphqlOperationGroupOperationConfigsOperations[] | cdktn.IResolvable;
    /**
    * quota block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#quota ApigeeApiProduct#quota}
    */
    readonly quota?: ApigeeApiProductGraphqlOperationGroupOperationConfigsQuota;
}
export declare function apigeeApiProductGraphqlOperationGroupOperationConfigsToTerraform(struct?: ApigeeApiProductGraphqlOperationGroupOperationConfigs | cdktn.IResolvable): any;
export declare function apigeeApiProductGraphqlOperationGroupOperationConfigsToHclTerraform(struct?: ApigeeApiProductGraphqlOperationGroupOperationConfigs | cdktn.IResolvable): any;
export declare class ApigeeApiProductGraphqlOperationGroupOperationConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigeeApiProductGraphqlOperationGroupOperationConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeApiProductGraphqlOperationGroupOperationConfigs | cdktn.IResolvable | undefined);
    private _apiSource?;
    get apiSource(): string;
    set apiSource(value: string);
    resetApiSource(): void;
    get apiSourceInput(): string | undefined;
    private _attributes;
    get attributes(): ApigeeApiProductGraphqlOperationGroupOperationConfigsAttributesList;
    putAttributes(value: ApigeeApiProductGraphqlOperationGroupOperationConfigsAttributes[] | cdktn.IResolvable): void;
    resetAttributes(): void;
    get attributesInput(): cdktn.IResolvable | ApigeeApiProductGraphqlOperationGroupOperationConfigsAttributes[] | undefined;
    private _operations;
    get operations(): ApigeeApiProductGraphqlOperationGroupOperationConfigsOperationsList;
    putOperations(value: ApigeeApiProductGraphqlOperationGroupOperationConfigsOperations[] | cdktn.IResolvable): void;
    resetOperations(): void;
    get operationsInput(): cdktn.IResolvable | ApigeeApiProductGraphqlOperationGroupOperationConfigsOperations[] | undefined;
    private _quota;
    get quota(): ApigeeApiProductGraphqlOperationGroupOperationConfigsQuotaOutputReference;
    putQuota(value: ApigeeApiProductGraphqlOperationGroupOperationConfigsQuota): void;
    resetQuota(): void;
    get quotaInput(): ApigeeApiProductGraphqlOperationGroupOperationConfigsQuota | undefined;
}
export declare class ApigeeApiProductGraphqlOperationGroupOperationConfigsList extends cdktn.ComplexList {
    internalValue?: ApigeeApiProductGraphqlOperationGroupOperationConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigeeApiProductGraphqlOperationGroupOperationConfigsOutputReference;
}
export interface ApigeeApiProductGraphqlOperationGroup {
    /**
    * Flag that specifes whether the configuration is for Apigee API proxy or a remote service. Valid values include proxy or remoteservice. Defaults to proxy. Set to proxy when Apigee API proxies are associated with the API product. Set to remoteservice when non-Apigee proxies like Istio-Envoy are associated with the API product. Possible values: ["proxy", "remoteservice"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#operation_config_type ApigeeApiProduct#operation_config_type}
    */
    readonly operationConfigType?: string;
    /**
    * operation_configs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#operation_configs ApigeeApiProduct#operation_configs}
    */
    readonly operationConfigs?: ApigeeApiProductGraphqlOperationGroupOperationConfigs[] | cdktn.IResolvable;
}
export declare function apigeeApiProductGraphqlOperationGroupToTerraform(struct?: ApigeeApiProductGraphqlOperationGroupOutputReference | ApigeeApiProductGraphqlOperationGroup): any;
export declare function apigeeApiProductGraphqlOperationGroupToHclTerraform(struct?: ApigeeApiProductGraphqlOperationGroupOutputReference | ApigeeApiProductGraphqlOperationGroup): any;
export declare class ApigeeApiProductGraphqlOperationGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeApiProductGraphqlOperationGroup | undefined;
    set internalValue(value: ApigeeApiProductGraphqlOperationGroup | undefined);
    private _operationConfigType?;
    get operationConfigType(): string;
    set operationConfigType(value: string);
    resetOperationConfigType(): void;
    get operationConfigTypeInput(): string | undefined;
    private _operationConfigs;
    get operationConfigs(): ApigeeApiProductGraphqlOperationGroupOperationConfigsList;
    putOperationConfigs(value: ApigeeApiProductGraphqlOperationGroupOperationConfigs[] | cdktn.IResolvable): void;
    resetOperationConfigs(): void;
    get operationConfigsInput(): cdktn.IResolvable | ApigeeApiProductGraphqlOperationGroupOperationConfigs[] | undefined;
}
export interface ApigeeApiProductGrpcOperationGroupOperationConfigsAttributes {
    /**
    * Key of the attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#name ApigeeApiProduct#name}
    */
    readonly name?: string;
    /**
    * Value of the attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#value ApigeeApiProduct#value}
    */
    readonly value?: string;
}
export declare function apigeeApiProductGrpcOperationGroupOperationConfigsAttributesToTerraform(struct?: ApigeeApiProductGrpcOperationGroupOperationConfigsAttributes | cdktn.IResolvable): any;
export declare function apigeeApiProductGrpcOperationGroupOperationConfigsAttributesToHclTerraform(struct?: ApigeeApiProductGrpcOperationGroupOperationConfigsAttributes | cdktn.IResolvable): any;
export declare class ApigeeApiProductGrpcOperationGroupOperationConfigsAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigeeApiProductGrpcOperationGroupOperationConfigsAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeApiProductGrpcOperationGroupOperationConfigsAttributes | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApigeeApiProductGrpcOperationGroupOperationConfigsAttributesList extends cdktn.ComplexList {
    internalValue?: ApigeeApiProductGrpcOperationGroupOperationConfigsAttributes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigeeApiProductGrpcOperationGroupOperationConfigsAttributesOutputReference;
}
export interface ApigeeApiProductGrpcOperationGroupOperationConfigsQuota {
    /**
    * Required. Time interval over which the number of request messages is calculated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#interval ApigeeApiProduct#interval}
    */
    readonly interval?: string;
    /**
    * Required. Upper limit allowed for the time interval and time unit specified. Requests exceeding this limit will be rejected.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#limit ApigeeApiProduct#limit}
    */
    readonly limit?: string;
    /**
    * Time unit defined for the interval. Valid values include second, minute, hour, day, month or year. If limit and interval are valid, the default value is hour; otherwise, the default is null.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#time_unit ApigeeApiProduct#time_unit}
    */
    readonly timeUnit?: string;
}
export declare function apigeeApiProductGrpcOperationGroupOperationConfigsQuotaToTerraform(struct?: ApigeeApiProductGrpcOperationGroupOperationConfigsQuotaOutputReference | ApigeeApiProductGrpcOperationGroupOperationConfigsQuota): any;
export declare function apigeeApiProductGrpcOperationGroupOperationConfigsQuotaToHclTerraform(struct?: ApigeeApiProductGrpcOperationGroupOperationConfigsQuotaOutputReference | ApigeeApiProductGrpcOperationGroupOperationConfigsQuota): any;
export declare class ApigeeApiProductGrpcOperationGroupOperationConfigsQuotaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeApiProductGrpcOperationGroupOperationConfigsQuota | undefined;
    set internalValue(value: ApigeeApiProductGrpcOperationGroupOperationConfigsQuota | undefined);
    private _interval?;
    get interval(): string;
    set interval(value: string);
    resetInterval(): void;
    get intervalInput(): string | undefined;
    private _limit?;
    get limit(): string;
    set limit(value: string);
    resetLimit(): void;
    get limitInput(): string | undefined;
    private _timeUnit?;
    get timeUnit(): string;
    set timeUnit(value: string);
    resetTimeUnit(): void;
    get timeUnitInput(): string | undefined;
}
export interface ApigeeApiProductGrpcOperationGroupOperationConfigs {
    /**
    * Required. Name of the API proxy with which the gRPC operation and quota are associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#api_source ApigeeApiProduct#api_source}
    */
    readonly apiSource?: string;
    /**
    * List of unqualified gRPC method names for the proxy to which quota will be applied. If this field is empty, the Quota will apply to all operations on the gRPC service defined on the proxy.
    *
    * Example: Given a proxy that is configured to serve com.petstore.PetService, the methods com.petstore.PetService.ListPets and com.petstore.PetService.GetPet would be specified here as simply ["ListPets", "GetPet"].
    *
    * Note: Currently, you can specify only a single GraphQLOperation. Specifying more than one will cause the operation to fail.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#methods ApigeeApiProduct#methods}
    */
    readonly methods?: string[];
    /**
    * Required. gRPC Service name associated to be associated with the API proxy, on which quota rules can be applied upon.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#service ApigeeApiProduct#service}
    */
    readonly service?: string;
    /**
    * attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#attributes ApigeeApiProduct#attributes}
    */
    readonly attributes?: ApigeeApiProductGrpcOperationGroupOperationConfigsAttributes[] | cdktn.IResolvable;
    /**
    * quota block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#quota ApigeeApiProduct#quota}
    */
    readonly quota?: ApigeeApiProductGrpcOperationGroupOperationConfigsQuota;
}
export declare function apigeeApiProductGrpcOperationGroupOperationConfigsToTerraform(struct?: ApigeeApiProductGrpcOperationGroupOperationConfigs | cdktn.IResolvable): any;
export declare function apigeeApiProductGrpcOperationGroupOperationConfigsToHclTerraform(struct?: ApigeeApiProductGrpcOperationGroupOperationConfigs | cdktn.IResolvable): any;
export declare class ApigeeApiProductGrpcOperationGroupOperationConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigeeApiProductGrpcOperationGroupOperationConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeApiProductGrpcOperationGroupOperationConfigs | cdktn.IResolvable | undefined);
    private _apiSource?;
    get apiSource(): string;
    set apiSource(value: string);
    resetApiSource(): void;
    get apiSourceInput(): string | undefined;
    private _methods?;
    get methods(): string[];
    set methods(value: string[]);
    resetMethods(): void;
    get methodsInput(): string[] | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
    private _attributes;
    get attributes(): ApigeeApiProductGrpcOperationGroupOperationConfigsAttributesList;
    putAttributes(value: ApigeeApiProductGrpcOperationGroupOperationConfigsAttributes[] | cdktn.IResolvable): void;
    resetAttributes(): void;
    get attributesInput(): cdktn.IResolvable | ApigeeApiProductGrpcOperationGroupOperationConfigsAttributes[] | undefined;
    private _quota;
    get quota(): ApigeeApiProductGrpcOperationGroupOperationConfigsQuotaOutputReference;
    putQuota(value: ApigeeApiProductGrpcOperationGroupOperationConfigsQuota): void;
    resetQuota(): void;
    get quotaInput(): ApigeeApiProductGrpcOperationGroupOperationConfigsQuota | undefined;
}
export declare class ApigeeApiProductGrpcOperationGroupOperationConfigsList extends cdktn.ComplexList {
    internalValue?: ApigeeApiProductGrpcOperationGroupOperationConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigeeApiProductGrpcOperationGroupOperationConfigsOutputReference;
}
export interface ApigeeApiProductGrpcOperationGroup {
    /**
    * operation_configs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#operation_configs ApigeeApiProduct#operation_configs}
    */
    readonly operationConfigs?: ApigeeApiProductGrpcOperationGroupOperationConfigs[] | cdktn.IResolvable;
}
export declare function apigeeApiProductGrpcOperationGroupToTerraform(struct?: ApigeeApiProductGrpcOperationGroupOutputReference | ApigeeApiProductGrpcOperationGroup): any;
export declare function apigeeApiProductGrpcOperationGroupToHclTerraform(struct?: ApigeeApiProductGrpcOperationGroupOutputReference | ApigeeApiProductGrpcOperationGroup): any;
export declare class ApigeeApiProductGrpcOperationGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeApiProductGrpcOperationGroup | undefined;
    set internalValue(value: ApigeeApiProductGrpcOperationGroup | undefined);
    private _operationConfigs;
    get operationConfigs(): ApigeeApiProductGrpcOperationGroupOperationConfigsList;
    putOperationConfigs(value: ApigeeApiProductGrpcOperationGroupOperationConfigs[] | cdktn.IResolvable): void;
    resetOperationConfigs(): void;
    get operationConfigsInput(): cdktn.IResolvable | ApigeeApiProductGrpcOperationGroupOperationConfigs[] | undefined;
}
export interface ApigeeApiProductOperationGroupOperationConfigsAttributes {
    /**
    * Key of the attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#name ApigeeApiProduct#name}
    */
    readonly name?: string;
    /**
    * Value of the attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#value ApigeeApiProduct#value}
    */
    readonly value?: string;
}
export declare function apigeeApiProductOperationGroupOperationConfigsAttributesToTerraform(struct?: ApigeeApiProductOperationGroupOperationConfigsAttributes | cdktn.IResolvable): any;
export declare function apigeeApiProductOperationGroupOperationConfigsAttributesToHclTerraform(struct?: ApigeeApiProductOperationGroupOperationConfigsAttributes | cdktn.IResolvable): any;
export declare class ApigeeApiProductOperationGroupOperationConfigsAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigeeApiProductOperationGroupOperationConfigsAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeApiProductOperationGroupOperationConfigsAttributes | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApigeeApiProductOperationGroupOperationConfigsAttributesList extends cdktn.ComplexList {
    internalValue?: ApigeeApiProductOperationGroupOperationConfigsAttributes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigeeApiProductOperationGroupOperationConfigsAttributesOutputReference;
}
export interface ApigeeApiProductOperationGroupOperationConfigsOperations {
    /**
    * Methods refers to the REST verbs, when none specified, all verb types are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#methods ApigeeApiProduct#methods}
    */
    readonly methods?: string[];
    /**
    * Required. REST resource path associated with the API proxy or remote service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#resource ApigeeApiProduct#resource}
    */
    readonly resource?: string;
}
export declare function apigeeApiProductOperationGroupOperationConfigsOperationsToTerraform(struct?: ApigeeApiProductOperationGroupOperationConfigsOperations | cdktn.IResolvable): any;
export declare function apigeeApiProductOperationGroupOperationConfigsOperationsToHclTerraform(struct?: ApigeeApiProductOperationGroupOperationConfigsOperations | cdktn.IResolvable): any;
export declare class ApigeeApiProductOperationGroupOperationConfigsOperationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigeeApiProductOperationGroupOperationConfigsOperations | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeApiProductOperationGroupOperationConfigsOperations | cdktn.IResolvable | undefined);
    private _methods?;
    get methods(): string[];
    set methods(value: string[]);
    resetMethods(): void;
    get methodsInput(): string[] | undefined;
    private _resource?;
    get resource(): string;
    set resource(value: string);
    resetResource(): void;
    get resourceInput(): string | undefined;
}
export declare class ApigeeApiProductOperationGroupOperationConfigsOperationsList extends cdktn.ComplexList {
    internalValue?: ApigeeApiProductOperationGroupOperationConfigsOperations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigeeApiProductOperationGroupOperationConfigsOperationsOutputReference;
}
export interface ApigeeApiProductOperationGroupOperationConfigsQuota {
    /**
    * Required. Time interval over which the number of request messages is calculated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#interval ApigeeApiProduct#interval}
    */
    readonly interval?: string;
    /**
    * Required. Upper limit allowed for the time interval and time unit specified. Requests exceeding this limit will be rejected.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#limit ApigeeApiProduct#limit}
    */
    readonly limit?: string;
    /**
    * Time unit defined for the interval. Valid values include second, minute, hour, day, month or year. If limit and interval are valid, the default value is hour; otherwise, the default is null.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#time_unit ApigeeApiProduct#time_unit}
    */
    readonly timeUnit?: string;
}
export declare function apigeeApiProductOperationGroupOperationConfigsQuotaToTerraform(struct?: ApigeeApiProductOperationGroupOperationConfigsQuotaOutputReference | ApigeeApiProductOperationGroupOperationConfigsQuota): any;
export declare function apigeeApiProductOperationGroupOperationConfigsQuotaToHclTerraform(struct?: ApigeeApiProductOperationGroupOperationConfigsQuotaOutputReference | ApigeeApiProductOperationGroupOperationConfigsQuota): any;
export declare class ApigeeApiProductOperationGroupOperationConfigsQuotaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeApiProductOperationGroupOperationConfigsQuota | undefined;
    set internalValue(value: ApigeeApiProductOperationGroupOperationConfigsQuota | undefined);
    private _interval?;
    get interval(): string;
    set interval(value: string);
    resetInterval(): void;
    get intervalInput(): string | undefined;
    private _limit?;
    get limit(): string;
    set limit(value: string);
    resetLimit(): void;
    get limitInput(): string | undefined;
    private _timeUnit?;
    get timeUnit(): string;
    set timeUnit(value: string);
    resetTimeUnit(): void;
    get timeUnitInput(): string | undefined;
}
export interface ApigeeApiProductOperationGroupOperationConfigs {
    /**
    * Required. Name of the API proxy or remote service with which the resources, methods, and quota are associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#api_source ApigeeApiProduct#api_source}
    */
    readonly apiSource?: string;
    /**
    * attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#attributes ApigeeApiProduct#attributes}
    */
    readonly attributes?: ApigeeApiProductOperationGroupOperationConfigsAttributes[] | cdktn.IResolvable;
    /**
    * operations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#operations ApigeeApiProduct#operations}
    */
    readonly operations?: ApigeeApiProductOperationGroupOperationConfigsOperations[] | cdktn.IResolvable;
    /**
    * quota block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#quota ApigeeApiProduct#quota}
    */
    readonly quota?: ApigeeApiProductOperationGroupOperationConfigsQuota;
}
export declare function apigeeApiProductOperationGroupOperationConfigsToTerraform(struct?: ApigeeApiProductOperationGroupOperationConfigs | cdktn.IResolvable): any;
export declare function apigeeApiProductOperationGroupOperationConfigsToHclTerraform(struct?: ApigeeApiProductOperationGroupOperationConfigs | cdktn.IResolvable): any;
export declare class ApigeeApiProductOperationGroupOperationConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigeeApiProductOperationGroupOperationConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeApiProductOperationGroupOperationConfigs | cdktn.IResolvable | undefined);
    private _apiSource?;
    get apiSource(): string;
    set apiSource(value: string);
    resetApiSource(): void;
    get apiSourceInput(): string | undefined;
    private _attributes;
    get attributes(): ApigeeApiProductOperationGroupOperationConfigsAttributesList;
    putAttributes(value: ApigeeApiProductOperationGroupOperationConfigsAttributes[] | cdktn.IResolvable): void;
    resetAttributes(): void;
    get attributesInput(): cdktn.IResolvable | ApigeeApiProductOperationGroupOperationConfigsAttributes[] | undefined;
    private _operations;
    get operations(): ApigeeApiProductOperationGroupOperationConfigsOperationsList;
    putOperations(value: ApigeeApiProductOperationGroupOperationConfigsOperations[] | cdktn.IResolvable): void;
    resetOperations(): void;
    get operationsInput(): cdktn.IResolvable | ApigeeApiProductOperationGroupOperationConfigsOperations[] | undefined;
    private _quota;
    get quota(): ApigeeApiProductOperationGroupOperationConfigsQuotaOutputReference;
    putQuota(value: ApigeeApiProductOperationGroupOperationConfigsQuota): void;
    resetQuota(): void;
    get quotaInput(): ApigeeApiProductOperationGroupOperationConfigsQuota | undefined;
}
export declare class ApigeeApiProductOperationGroupOperationConfigsList extends cdktn.ComplexList {
    internalValue?: ApigeeApiProductOperationGroupOperationConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigeeApiProductOperationGroupOperationConfigsOutputReference;
}
export interface ApigeeApiProductOperationGroup {
    /**
    * Flag that specifes whether the configuration is for Apigee API proxy or a remote service. Valid values include proxy or remoteservice. Defaults to proxy. Set to proxy when Apigee API proxies are associated with the API product. Set to remoteservice when non-Apigee proxies like Istio-Envoy are associated with the API product. Possible values: ["proxy", "remoteservice"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#operation_config_type ApigeeApiProduct#operation_config_type}
    */
    readonly operationConfigType?: string;
    /**
    * operation_configs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#operation_configs ApigeeApiProduct#operation_configs}
    */
    readonly operationConfigs?: ApigeeApiProductOperationGroupOperationConfigs[] | cdktn.IResolvable;
}
export declare function apigeeApiProductOperationGroupToTerraform(struct?: ApigeeApiProductOperationGroupOutputReference | ApigeeApiProductOperationGroup): any;
export declare function apigeeApiProductOperationGroupToHclTerraform(struct?: ApigeeApiProductOperationGroupOutputReference | ApigeeApiProductOperationGroup): any;
export declare class ApigeeApiProductOperationGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeApiProductOperationGroup | undefined;
    set internalValue(value: ApigeeApiProductOperationGroup | undefined);
    private _operationConfigType?;
    get operationConfigType(): string;
    set operationConfigType(value: string);
    resetOperationConfigType(): void;
    get operationConfigTypeInput(): string | undefined;
    private _operationConfigs;
    get operationConfigs(): ApigeeApiProductOperationGroupOperationConfigsList;
    putOperationConfigs(value: ApigeeApiProductOperationGroupOperationConfigs[] | cdktn.IResolvable): void;
    resetOperationConfigs(): void;
    get operationConfigsInput(): cdktn.IResolvable | ApigeeApiProductOperationGroupOperationConfigs[] | undefined;
}
export interface ApigeeApiProductTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#create ApigeeApiProduct#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#delete ApigeeApiProduct#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#update ApigeeApiProduct#update}
    */
    readonly update?: string;
}
export declare function apigeeApiProductTimeoutsToTerraform(struct?: ApigeeApiProductTimeouts | cdktn.IResolvable): any;
export declare function apigeeApiProductTimeoutsToHclTerraform(struct?: ApigeeApiProductTimeouts | cdktn.IResolvable): any;
export declare class ApigeeApiProductTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeApiProductTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeApiProductTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product google_apigee_api_product}
*/
export declare class ApigeeApiProduct extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apigee_api_product";
    /**
    * Generates CDKTN code for importing a ApigeeApiProduct resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigeeApiProduct to import
    * @param importFromId The id of the existing ApigeeApiProduct that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigeeApiProduct to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_api_product google_apigee_api_product} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigeeApiProductConfig
    */
    constructor(scope: Construct, id: string, config: ApigeeApiProductConfig);
    private _apiResources?;
    get apiResources(): string[];
    set apiResources(value: string[]);
    resetApiResources(): void;
    get apiResourcesInput(): string[] | undefined;
    private _approvalType?;
    get approvalType(): string;
    set approvalType(value: string);
    resetApprovalType(): void;
    get approvalTypeInput(): string | undefined;
    get createdAt(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _environments?;
    get environments(): string[];
    set environments(value: string[]);
    resetEnvironments(): void;
    get environmentsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastModifiedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _orgId?;
    get orgId(): string;
    set orgId(value: string);
    get orgIdInput(): string | undefined;
    private _proxies?;
    get proxies(): string[];
    set proxies(value: string[]);
    resetProxies(): void;
    get proxiesInput(): string[] | undefined;
    private _quota?;
    get quota(): string;
    set quota(value: string);
    resetQuota(): void;
    get quotaInput(): string | undefined;
    private _quotaCounterScope?;
    get quotaCounterScope(): string;
    set quotaCounterScope(value: string);
    resetQuotaCounterScope(): void;
    get quotaCounterScopeInput(): string | undefined;
    private _quotaInterval?;
    get quotaInterval(): string;
    set quotaInterval(value: string);
    resetQuotaInterval(): void;
    get quotaIntervalInput(): string | undefined;
    private _quotaTimeUnit?;
    get quotaTimeUnit(): string;
    set quotaTimeUnit(value: string);
    resetQuotaTimeUnit(): void;
    get quotaTimeUnitInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
    private _space?;
    get space(): string;
    set space(value: string);
    resetSpace(): void;
    get spaceInput(): string | undefined;
    private _attributes;
    get attributes(): ApigeeApiProductAttributesList;
    putAttributes(value: ApigeeApiProductAttributes[] | cdktn.IResolvable): void;
    resetAttributes(): void;
    get attributesInput(): cdktn.IResolvable | ApigeeApiProductAttributes[] | undefined;
    private _graphqlOperationGroup;
    get graphqlOperationGroup(): ApigeeApiProductGraphqlOperationGroupOutputReference;
    putGraphqlOperationGroup(value: ApigeeApiProductGraphqlOperationGroup): void;
    resetGraphqlOperationGroup(): void;
    get graphqlOperationGroupInput(): ApigeeApiProductGraphqlOperationGroup | undefined;
    private _grpcOperationGroup;
    get grpcOperationGroup(): ApigeeApiProductGrpcOperationGroupOutputReference;
    putGrpcOperationGroup(value: ApigeeApiProductGrpcOperationGroup): void;
    resetGrpcOperationGroup(): void;
    get grpcOperationGroupInput(): ApigeeApiProductGrpcOperationGroup | undefined;
    private _operationGroup;
    get operationGroup(): ApigeeApiProductOperationGroupOutputReference;
    putOperationGroup(value: ApigeeApiProductOperationGroup): void;
    resetOperationGroup(): void;
    get operationGroupInput(): ApigeeApiProductOperationGroup | undefined;
    private _timeouts;
    get timeouts(): ApigeeApiProductTimeoutsOutputReference;
    putTimeouts(value: ApigeeApiProductTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApigeeApiProductTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
