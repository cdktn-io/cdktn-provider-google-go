/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeVpnTunnelConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#deletion_policy ComputeVpnTunnel#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * An optional description of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#description ComputeVpnTunnel#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#id ComputeVpnTunnel#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * IKE protocol version to use when establishing the VPN tunnel with
    * peer VPN gateway.
    * Acceptable IKE versions are 1 or 2. Default version is 2.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#ike_version ComputeVpnTunnel#ike_version}
    */
    readonly ikeVersion?: number;
    /**
    * Labels to apply to this VpnTunnel.
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#labels ComputeVpnTunnel#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Local traffic selector to use when establishing the VPN tunnel with
    * peer VPN gateway. The value should be a CIDR formatted string,
    * for example '192.168.0.0/16'. The ranges should be disjoint.
    * Only IPv4 is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#local_traffic_selector ComputeVpnTunnel#local_traffic_selector}
    */
    readonly localTrafficSelector?: string[];
    /**
    * Name of the resource. The name must be 1-63 characters long, and
    * comply with RFC1035. Specifically, the name must be 1-63
    * characters long and match the regular expression
    * '[a-z]([-a-z0-9]*[a-z0-9])?' which means the first character
    * must be a lowercase letter, and all following characters must
    * be a dash, lowercase letter, or digit,
    * except the last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#name ComputeVpnTunnel#name}
    */
    readonly name: string;
    /**
    * URL of the peer side external VPN gateway to which this VPN tunnel is connected.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#peer_external_gateway ComputeVpnTunnel#peer_external_gateway}
    */
    readonly peerExternalGateway?: string;
    /**
    * The interface ID of the external VPN gateway to which this VPN tunnel is connected.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#peer_external_gateway_interface ComputeVpnTunnel#peer_external_gateway_interface}
    */
    readonly peerExternalGatewayInterface?: number;
    /**
    * URL of the peer side HA GCP VPN gateway to which this VPN tunnel is connected.
    * If provided, the VPN tunnel will automatically use the same vpn_gateway_interface
    * ID in the peer GCP VPN gateway.
    * This field must reference a 'google_compute_ha_vpn_gateway' resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#peer_gcp_gateway ComputeVpnTunnel#peer_gcp_gateway}
    */
    readonly peerGcpGateway?: string;
    /**
    * IP address of the peer VPN gateway. Only IPv4 is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#peer_ip ComputeVpnTunnel#peer_ip}
    */
    readonly peerIp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#project ComputeVpnTunnel#project}
    */
    readonly project?: string;
    /**
    * The region where the tunnel is located. If unset, is set to the region of 'target_vpn_gateway'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#region ComputeVpnTunnel#region}
    */
    readonly region?: string;
    /**
    * Remote traffic selector to use when establishing the VPN tunnel with
    * peer VPN gateway. The value should be a CIDR formatted string,
    * for example '192.168.0.0/16'. The ranges should be disjoint.
    * Only IPv4 is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#remote_traffic_selector ComputeVpnTunnel#remote_traffic_selector}
    */
    readonly remoteTrafficSelector?: string[];
    /**
    * URL of router resource to be used for dynamic routing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#router ComputeVpnTunnel#router}
    */
    readonly router?: string;
    /**
    * Shared secret used to set the secure session between the Cloud VPN
    * gateway and the peer VPN gateway.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#shared_secret ComputeVpnTunnel#shared_secret}
    */
    readonly sharedSecret?: string;
    /**
    * Shared secret used to set the secure session between the Cloud VPN
    * gateway and the peer VPN gateway.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#shared_secret_wo ComputeVpnTunnel#shared_secret_wo}
    */
    readonly sharedSecretWo?: string;
    /**
    * Triggers update of 'shared_secret_wo' write-only. Increment this value when an update to 'shared_secret_wo' is needed. For more info see [updating write-only arguments](/docs/providers/google/guides/using_write_only_arguments.html#updating-write-only-arguments)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#shared_secret_wo_version ComputeVpnTunnel#shared_secret_wo_version}
    */
    readonly sharedSecretWoVersion?: string;
    /**
    * URL of the Target VPN gateway with which this VPN tunnel is
    * associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#target_vpn_gateway ComputeVpnTunnel#target_vpn_gateway}
    */
    readonly targetVpnGateway?: string;
    /**
    * URL of the VPN gateway with which this VPN tunnel is associated.
    * This must be used if a High Availability VPN gateway resource is created.
    * This field must reference a 'google_compute_ha_vpn_gateway' resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#vpn_gateway ComputeVpnTunnel#vpn_gateway}
    */
    readonly vpnGateway?: string;
    /**
    * The interface ID of the VPN gateway with which this VPN tunnel is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#vpn_gateway_interface ComputeVpnTunnel#vpn_gateway_interface}
    */
    readonly vpnGatewayInterface?: number;
    /**
    * cipher_suite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#cipher_suite ComputeVpnTunnel#cipher_suite}
    */
    readonly cipherSuite?: ComputeVpnTunnelCipherSuite;
    /**
    * params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#params ComputeVpnTunnel#params}
    */
    readonly params?: ComputeVpnTunnelParams;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#timeouts ComputeVpnTunnel#timeouts}
    */
    readonly timeouts?: ComputeVpnTunnelTimeouts;
}
export interface ComputeVpnTunnelCipherSuitePhase1 {
    /**
    * Diffie-Hellman groups.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#dh ComputeVpnTunnel#dh}
    */
    readonly dh?: string[];
    /**
    * Encryption algorithms.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#encryption ComputeVpnTunnel#encryption}
    */
    readonly encryption?: string[];
    /**
    * Integrity algorithms.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#integrity ComputeVpnTunnel#integrity}
    */
    readonly integrity?: string[];
    /**
    * Pseudo-random functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#prf ComputeVpnTunnel#prf}
    */
    readonly prf?: string[];
}
export declare function computeVpnTunnelCipherSuitePhase1ToTerraform(struct?: ComputeVpnTunnelCipherSuitePhase1OutputReference | ComputeVpnTunnelCipherSuitePhase1): any;
export declare function computeVpnTunnelCipherSuitePhase1ToHclTerraform(struct?: ComputeVpnTunnelCipherSuitePhase1OutputReference | ComputeVpnTunnelCipherSuitePhase1): any;
export declare class ComputeVpnTunnelCipherSuitePhase1OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeVpnTunnelCipherSuitePhase1 | undefined;
    set internalValue(value: ComputeVpnTunnelCipherSuitePhase1 | undefined);
    private _dh?;
    get dh(): string[];
    set dh(value: string[]);
    resetDh(): void;
    get dhInput(): string[] | undefined;
    private _encryption?;
    get encryption(): string[];
    set encryption(value: string[]);
    resetEncryption(): void;
    get encryptionInput(): string[] | undefined;
    private _integrity?;
    get integrity(): string[];
    set integrity(value: string[]);
    resetIntegrity(): void;
    get integrityInput(): string[] | undefined;
    private _prf?;
    get prf(): string[];
    set prf(value: string[]);
    resetPrf(): void;
    get prfInput(): string[] | undefined;
}
export interface ComputeVpnTunnelCipherSuitePhase2 {
    /**
    * Encryption algorithms.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#encryption ComputeVpnTunnel#encryption}
    */
    readonly encryption?: string[];
    /**
    * Integrity algorithms.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#integrity ComputeVpnTunnel#integrity}
    */
    readonly integrity?: string[];
    /**
    * Perfect forward secrecy groups.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#pfs ComputeVpnTunnel#pfs}
    */
    readonly pfs?: string[];
}
export declare function computeVpnTunnelCipherSuitePhase2ToTerraform(struct?: ComputeVpnTunnelCipherSuitePhase2OutputReference | ComputeVpnTunnelCipherSuitePhase2): any;
export declare function computeVpnTunnelCipherSuitePhase2ToHclTerraform(struct?: ComputeVpnTunnelCipherSuitePhase2OutputReference | ComputeVpnTunnelCipherSuitePhase2): any;
export declare class ComputeVpnTunnelCipherSuitePhase2OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeVpnTunnelCipherSuitePhase2 | undefined;
    set internalValue(value: ComputeVpnTunnelCipherSuitePhase2 | undefined);
    private _encryption?;
    get encryption(): string[];
    set encryption(value: string[]);
    resetEncryption(): void;
    get encryptionInput(): string[] | undefined;
    private _integrity?;
    get integrity(): string[];
    set integrity(value: string[]);
    resetIntegrity(): void;
    get integrityInput(): string[] | undefined;
    private _pfs?;
    get pfs(): string[];
    set pfs(value: string[]);
    resetPfs(): void;
    get pfsInput(): string[] | undefined;
}
export interface ComputeVpnTunnelCipherSuite {
    /**
    * phase1 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#phase1 ComputeVpnTunnel#phase1}
    */
    readonly phase1?: ComputeVpnTunnelCipherSuitePhase1;
    /**
    * phase2 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#phase2 ComputeVpnTunnel#phase2}
    */
    readonly phase2?: ComputeVpnTunnelCipherSuitePhase2;
}
export declare function computeVpnTunnelCipherSuiteToTerraform(struct?: ComputeVpnTunnelCipherSuiteOutputReference | ComputeVpnTunnelCipherSuite): any;
export declare function computeVpnTunnelCipherSuiteToHclTerraform(struct?: ComputeVpnTunnelCipherSuiteOutputReference | ComputeVpnTunnelCipherSuite): any;
export declare class ComputeVpnTunnelCipherSuiteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeVpnTunnelCipherSuite | undefined;
    set internalValue(value: ComputeVpnTunnelCipherSuite | undefined);
    private _phase1;
    get phase1(): ComputeVpnTunnelCipherSuitePhase1OutputReference;
    putPhase1(value: ComputeVpnTunnelCipherSuitePhase1): void;
    resetPhase1(): void;
    get phase1Input(): ComputeVpnTunnelCipherSuitePhase1 | undefined;
    private _phase2;
    get phase2(): ComputeVpnTunnelCipherSuitePhase2OutputReference;
    putPhase2(value: ComputeVpnTunnelCipherSuitePhase2): void;
    resetPhase2(): void;
    get phase2Input(): ComputeVpnTunnelCipherSuitePhase2 | undefined;
}
export interface ComputeVpnTunnelParams {
    /**
    * Resource manager tags to be bound to the Vpn Tunnel. Tag keys and values have the
    * same definition as resource manager tags. Keys must be in the format tagKeys/{tag_key_id},
    * and values are in the format tagValues/456.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#resource_manager_tags ComputeVpnTunnel#resource_manager_tags}
    */
    readonly resourceManagerTags?: {
        [key: string]: string;
    };
}
export declare function computeVpnTunnelParamsToTerraform(struct?: ComputeVpnTunnelParamsOutputReference | ComputeVpnTunnelParams): any;
export declare function computeVpnTunnelParamsToHclTerraform(struct?: ComputeVpnTunnelParamsOutputReference | ComputeVpnTunnelParams): any;
export declare class ComputeVpnTunnelParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeVpnTunnelParams | undefined;
    set internalValue(value: ComputeVpnTunnelParams | undefined);
    private _resourceManagerTags?;
    get resourceManagerTags(): {
        [key: string]: string;
    };
    set resourceManagerTags(value: {
        [key: string]: string;
    });
    resetResourceManagerTags(): void;
    get resourceManagerTagsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ComputeVpnTunnelTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#create ComputeVpnTunnel#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#delete ComputeVpnTunnel#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#update ComputeVpnTunnel#update}
    */
    readonly update?: string;
}
export declare function computeVpnTunnelTimeoutsToTerraform(struct?: ComputeVpnTunnelTimeouts | cdktn.IResolvable): any;
export declare function computeVpnTunnelTimeoutsToHclTerraform(struct?: ComputeVpnTunnelTimeouts | cdktn.IResolvable): any;
export declare class ComputeVpnTunnelTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeVpnTunnelTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeVpnTunnelTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel google_compute_vpn_tunnel}
*/
export declare class ComputeVpnTunnel extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_vpn_tunnel";
    /**
    * Generates CDKTN code for importing a ComputeVpnTunnel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeVpnTunnel to import
    * @param importFromId The id of the existing ComputeVpnTunnel that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeVpnTunnel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_vpn_tunnel google_compute_vpn_tunnel} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeVpnTunnelConfig
    */
    constructor(scope: Construct, id: string, config: ComputeVpnTunnelConfig);
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get detailedStatus(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ikeVersion?;
    get ikeVersion(): number;
    set ikeVersion(value: number);
    resetIkeVersion(): void;
    get ikeVersionInput(): number | undefined;
    get labelFingerprint(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _localTrafficSelector?;
    get localTrafficSelector(): string[];
    set localTrafficSelector(value: string[]);
    resetLocalTrafficSelector(): void;
    get localTrafficSelectorInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _peerExternalGateway?;
    get peerExternalGateway(): string;
    set peerExternalGateway(value: string);
    resetPeerExternalGateway(): void;
    get peerExternalGatewayInput(): string | undefined;
    private _peerExternalGatewayInterface?;
    get peerExternalGatewayInterface(): number;
    set peerExternalGatewayInterface(value: number);
    resetPeerExternalGatewayInterface(): void;
    get peerExternalGatewayInterfaceInput(): number | undefined;
    private _peerGcpGateway?;
    get peerGcpGateway(): string;
    set peerGcpGateway(value: string);
    resetPeerGcpGateway(): void;
    get peerGcpGatewayInput(): string | undefined;
    private _peerIp?;
    get peerIp(): string;
    set peerIp(value: string);
    resetPeerIp(): void;
    get peerIpInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _remoteTrafficSelector?;
    get remoteTrafficSelector(): string[];
    set remoteTrafficSelector(value: string[]);
    resetRemoteTrafficSelector(): void;
    get remoteTrafficSelectorInput(): string[] | undefined;
    private _router?;
    get router(): string;
    set router(value: string);
    resetRouter(): void;
    get routerInput(): string | undefined;
    get selfLink(): string;
    private _sharedSecret?;
    get sharedSecret(): string;
    set sharedSecret(value: string);
    resetSharedSecret(): void;
    get sharedSecretInput(): string | undefined;
    get sharedSecretHash(): string;
    private _sharedSecretWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get sharedSecretWo(): string;
    set sharedSecretWo(value: string);
    resetSharedSecretWo(): void;
    get sharedSecretWoInput(): string | undefined;
    private _sharedSecretWoVersion?;
    get sharedSecretWoVersion(): string;
    set sharedSecretWoVersion(value: string);
    resetSharedSecretWoVersion(): void;
    get sharedSecretWoVersionInput(): string | undefined;
    private _targetVpnGateway?;
    get targetVpnGateway(): string;
    set targetVpnGateway(value: string);
    resetTargetVpnGateway(): void;
    get targetVpnGatewayInput(): string | undefined;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get tunnelId(): string;
    private _vpnGateway?;
    get vpnGateway(): string;
    set vpnGateway(value: string);
    resetVpnGateway(): void;
    get vpnGatewayInput(): string | undefined;
    private _vpnGatewayInterface?;
    get vpnGatewayInterface(): number;
    set vpnGatewayInterface(value: number);
    resetVpnGatewayInterface(): void;
    get vpnGatewayInterfaceInput(): number | undefined;
    private _cipherSuite;
    get cipherSuite(): ComputeVpnTunnelCipherSuiteOutputReference;
    putCipherSuite(value: ComputeVpnTunnelCipherSuite): void;
    resetCipherSuite(): void;
    get cipherSuiteInput(): ComputeVpnTunnelCipherSuite | undefined;
    private _params;
    get params(): ComputeVpnTunnelParamsOutputReference;
    putParams(value: ComputeVpnTunnelParams): void;
    resetParams(): void;
    get paramsInput(): ComputeVpnTunnelParams | undefined;
    private _timeouts;
    get timeouts(): ComputeVpnTunnelTimeoutsOutputReference;
    putTimeouts(value: ComputeVpnTunnelTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeVpnTunnelTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
