/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeStoragePoolConfig extends cdktn.TerraformMetaArguments {
    /**
    * Provisioning type of the byte capacity of the pool. Possible values: ["STANDARD", "ADVANCED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_storage_pool#capacity_provisioning_type ComputeStoragePool#capacity_provisioning_type}
    */
    readonly capacityProvisioningType?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_storage_pool#deletion_policy ComputeStoragePool#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Whether Terraform will be prevented from destroying the StoragePool.
    * When the field is set to true or unset in Terraform state, a 'terraform apply'
    * or 'terraform destroy' that would delete the StoragePool will fail.
    * When the field is set to false, deleting the StoragePool is allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_storage_pool#deletion_protection ComputeStoragePool#deletion_protection}
    */
    readonly deletionProtection?: boolean | cdktn.IResolvable;
    /**
    * A description of this resource. Provide this property when you create the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_storage_pool#description ComputeStoragePool#description}
    */
    readonly description?: string;
    /**
    * Labels to apply to this storage pool. These can be later modified by the setLabels method.
    *
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_storage_pool#labels ComputeStoragePool#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the resource. Provided by the client when the resource is created.
    * The name must be 1-63 characters long, and comply with RFC1035.
    * Specifically, the name must be 1-63 characters long and match
    * the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?'
    * which means the first character must be a lowercase letter,
    * and all following characters must be a dash, lowercase letter, or digit,
    * except the last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_storage_pool#name ComputeStoragePool#name}
    */
    readonly name: string;
    /**
    * Provisioning type of the performance-related parameters of the pool, such as throughput and IOPS. Possible values: ["STANDARD", "ADVANCED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_storage_pool#performance_provisioning_type ComputeStoragePool#performance_provisioning_type}
    */
    readonly performanceProvisioningType?: string;
    /**
    * Size, in GiB, of the storage pool. For more information about the size limits,
    * see https://cloud.google.com/compute/docs/disks/storage-pools.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_storage_pool#pool_provisioned_capacity_gb ComputeStoragePool#pool_provisioned_capacity_gb}
    */
    readonly poolProvisionedCapacityGb: string;
    /**
    * Provisioned IOPS of the storage pool.
    * Only relevant if the storage pool type is 'hyperdisk-balanced'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_storage_pool#pool_provisioned_iops ComputeStoragePool#pool_provisioned_iops}
    */
    readonly poolProvisionedIops?: string;
    /**
    * Provisioned throughput, in MB/s, of the storage pool.
    * Only relevant if the storage pool type is 'hyperdisk-balanced' or 'hyperdisk-throughput'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_storage_pool#pool_provisioned_throughput ComputeStoragePool#pool_provisioned_throughput}
    */
    readonly poolProvisionedThroughput: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_storage_pool#project ComputeStoragePool#project}
    */
    readonly project?: string;
    /**
    * Type of the storage pool. For example, the
    * following are valid values:
    *
    * * 'https://www.googleapis.com/compute/v1/projects/{project_id}/zones/{zone}/storagePoolTypes/hyperdisk-balanced'
    * * 'hyperdisk-throughput'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_storage_pool#storage_pool_type ComputeStoragePool#storage_pool_type}
    */
    readonly storagePoolType: string;
    /**
    * A reference to the zone where the storage pool resides.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_storage_pool#zone ComputeStoragePool#zone}
    */
    readonly zone?: string;
    /**
    * params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_storage_pool#params ComputeStoragePool#params}
    */
    readonly params?: ComputeStoragePoolParams;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_storage_pool#timeouts ComputeStoragePool#timeouts}
    */
    readonly timeouts?: ComputeStoragePoolTimeouts;
}
export interface ComputeStoragePoolResourceStatus {
}
export declare function computeStoragePoolResourceStatusToTerraform(struct?: ComputeStoragePoolResourceStatus): any;
export declare function computeStoragePoolResourceStatusToHclTerraform(struct?: ComputeStoragePoolResourceStatus): any;
export declare class ComputeStoragePoolResourceStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeStoragePoolResourceStatus | undefined;
    set internalValue(value: ComputeStoragePoolResourceStatus | undefined);
    get diskCount(): string;
    get lastResizeTimestamp(): string;
    get maxTotalProvisionedDiskCapacityGb(): string;
    get poolUsedCapacityBytes(): string;
    get poolUsedIops(): string;
    get poolUsedThroughput(): string;
    get poolUserWrittenBytes(): string;
    get totalProvisionedDiskCapacityGb(): string;
    get totalProvisionedDiskIops(): string;
    get totalProvisionedDiskThroughput(): string;
}
export declare class ComputeStoragePoolResourceStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeStoragePoolResourceStatusOutputReference;
}
export interface ComputeStoragePoolStatus {
}
export declare function computeStoragePoolStatusToTerraform(struct?: ComputeStoragePoolStatus): any;
export declare function computeStoragePoolStatusToHclTerraform(struct?: ComputeStoragePoolStatus): any;
export declare class ComputeStoragePoolStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeStoragePoolStatus | undefined;
    set internalValue(value: ComputeStoragePoolStatus | undefined);
    get diskCount(): string;
    get lastResizeTimestamp(): string;
    get maxTotalProvisionedDiskCapacityGb(): string;
    get poolUsedCapacityBytes(): string;
    get poolUsedIops(): string;
    get poolUsedThroughput(): string;
    get poolUserWrittenBytes(): string;
    get totalProvisionedDiskCapacityGb(): string;
    get totalProvisionedDiskIops(): string;
    get totalProvisionedDiskThroughput(): string;
}
export declare class ComputeStoragePoolStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeStoragePoolStatusOutputReference;
}
export interface ComputeStoragePoolParams {
    /**
    * Resource manager tags to be bound to the storage pool. Tag keys and values have the
    * same definition as resource manager tags. Keys and values can be either in numeric format,
    * such as tagKeys/{tag_key_id} and tagValues/{tag_value_id} or in namespaced format such as
    * {org_id|projectId}/{tag_key_short_name} and {tag_value_short_name}. The field is ignored when empty.
    * The field is immutable and causes resource replacement when mutated. This field is only
    * set at create time and modifying this field after creation will trigger recreation.
    * To apply tags to an existing resource, see the google_tags_tag_binding resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_storage_pool#resource_manager_tags ComputeStoragePool#resource_manager_tags}
    */
    readonly resourceManagerTags?: {
        [key: string]: string;
    };
}
export declare function computeStoragePoolParamsToTerraform(struct?: ComputeStoragePoolParamsOutputReference | ComputeStoragePoolParams): any;
export declare function computeStoragePoolParamsToHclTerraform(struct?: ComputeStoragePoolParamsOutputReference | ComputeStoragePoolParams): any;
export declare class ComputeStoragePoolParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeStoragePoolParams | undefined;
    set internalValue(value: ComputeStoragePoolParams | undefined);
    private _resourceManagerTags?;
    get resourceManagerTags(): {
        [key: string]: string;
    };
    set resourceManagerTags(value: {
        [key: string]: string;
    });
    resetResourceManagerTags(): void;
    get resourceManagerTagsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ComputeStoragePoolTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_storage_pool#create ComputeStoragePool#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_storage_pool#delete ComputeStoragePool#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_storage_pool#update ComputeStoragePool#update}
    */
    readonly update?: string;
}
export declare function computeStoragePoolTimeoutsToTerraform(struct?: ComputeStoragePoolTimeouts | cdktn.IResolvable): any;
export declare function computeStoragePoolTimeoutsToHclTerraform(struct?: ComputeStoragePoolTimeouts | cdktn.IResolvable): any;
export declare class ComputeStoragePoolTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeStoragePoolTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeStoragePoolTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_storage_pool google_compute_storage_pool}
*/
export declare class ComputeStoragePool extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_compute_storage_pool";
    /**
    * Generates CDKTN code for importing a ComputeStoragePool resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeStoragePool to import
    * @param importFromId The id of the existing ComputeStoragePool that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_storage_pool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeStoragePool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/compute_storage_pool google_compute_storage_pool} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeStoragePoolConfig
    */
    constructor(scope: Construct, id: string, config: ComputeStoragePoolConfig);
    private _capacityProvisioningType?;
    get capacityProvisioningType(): string;
    set capacityProvisioningType(value: string);
    resetCapacityProvisioningType(): void;
    get capacityProvisioningTypeInput(): string | undefined;
    get creationTimestamp(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _deletionProtection?;
    get deletionProtection(): boolean | cdktn.IResolvable;
    set deletionProtection(value: boolean | cdktn.IResolvable);
    resetDeletionProtection(): void;
    get deletionProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get id(): string;
    get kind(): string;
    get labelFingerprint(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _performanceProvisioningType?;
    get performanceProvisioningType(): string;
    set performanceProvisioningType(value: string);
    resetPerformanceProvisioningType(): void;
    get performanceProvisioningTypeInput(): string | undefined;
    private _poolProvisionedCapacityGb?;
    get poolProvisionedCapacityGb(): string;
    set poolProvisionedCapacityGb(value: string);
    get poolProvisionedCapacityGbInput(): string | undefined;
    private _poolProvisionedIops?;
    get poolProvisionedIops(): string;
    set poolProvisionedIops(value: string);
    resetPoolProvisionedIops(): void;
    get poolProvisionedIopsInput(): string | undefined;
    private _poolProvisionedThroughput?;
    get poolProvisionedThroughput(): string;
    set poolProvisionedThroughput(value: string);
    get poolProvisionedThroughputInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _resourceStatus;
    get resourceStatus(): ComputeStoragePoolResourceStatusList;
    private _status;
    get status(): ComputeStoragePoolStatusList;
    private _storagePoolType?;
    get storagePoolType(): string;
    set storagePoolType(value: string);
    get storagePoolTypeInput(): string | undefined;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    resetZone(): void;
    get zoneInput(): string | undefined;
    private _params;
    get params(): ComputeStoragePoolParamsOutputReference;
    putParams(value: ComputeStoragePoolParams): void;
    resetParams(): void;
    get paramsInput(): ComputeStoragePoolParams | undefined;
    private _timeouts;
    get timeouts(): ComputeStoragePoolTimeoutsOutputReference;
    putTimeouts(value: ComputeStoragePoolTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ComputeStoragePoolTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
