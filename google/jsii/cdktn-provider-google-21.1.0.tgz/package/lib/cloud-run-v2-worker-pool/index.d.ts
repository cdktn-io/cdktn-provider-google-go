/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudRunV2WorkerPoolConfig extends cdktn.TerraformMetaArguments {
    /**
    * Unstructured key value map that may be set by external tools to store and arbitrary metadata. They are not queryable and should be preserved when modifying objects.
    *
    * Cloud Run API v2 does not support annotations with 'run.googleapis.com', 'cloud.googleapis.com', 'serving.knative.dev', or 'autoscaling.knative.dev' namespaces, and they will be rejected in new resources.
    * All system annotations in v1 now have a corresponding field in v2 WorkerPool.
    *
    * This field follows Kubernetes annotations' namespacing, limits, and rules.
    *
    * **Note**: This field is non-authoritative, and will only manage the annotations present in your configuration.
    * Please refer to the field 'effective_annotations' for all of the annotations present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#annotations CloudRunV2WorkerPool#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Arbitrary identifier for the API client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#client CloudRunV2WorkerPool#client}
    */
    readonly client?: string;
    /**
    * Arbitrary version identifier for the API client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#client_version CloudRunV2WorkerPool#client_version}
    */
    readonly clientVersion?: string;
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#deletion_policy CloudRunV2WorkerPool#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Whether Terraform will be prevented from destroying the service. Defaults to true.
    * When a'terraform destroy' or 'terraform apply' would delete the service,
    * the command will fail if this field is not set to false in Terraform state.
    * When the field is set to true or unset in Terraform state, a 'terraform apply'
    * or 'terraform destroy' that would delete the WorkerPool will fail.
    * When the field is set to false, deleting the WorkerPool is allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#deletion_protection CloudRunV2WorkerPool#deletion_protection}
    */
    readonly deletionProtection?: boolean | cdktn.IResolvable;
    /**
    * User-provided description of the WorkerPool. This field currently has a 512-character limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#description CloudRunV2WorkerPool#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#id CloudRunV2WorkerPool#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Unstructured key value map that can be used to organize and categorize objects. User-provided labels are shared with Google's billing system, so they can be used to filter, or break down billing charges by team, component,
    * environment, state, etc. For more information, visit https://docs.cloud.google.com/resource-manager/docs/creating-managing-labels or https://cloud.google.com/run/docs/configuring/labels.
    *
    * Cloud Run API v2 does not support labels with  'run.googleapis.com', 'cloud.googleapis.com', 'serving.knative.dev', or 'autoscaling.knative.dev' namespaces, and they will be rejected.
    * All system labels in v1 now have a corresponding field in v2 WorkerPool.
    *
    * **Note**: This field is non-authoritative, and will only manage the labels present in your configuration.
    * Please refer to the field 'effective_labels' for all of the labels present on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#labels CloudRunV2WorkerPool#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The launch stage as defined by [Google Cloud Platform Launch Stages](https://cloud.google.com/products#product-launch-stages). Cloud Run supports ALPHA, BETA, and GA.
    * If no value is specified, GA is assumed. Set the launch stage to a preview stage on input to allow use of preview features in that stage. On read (or output), describes whether the resource uses preview features.
    *
    * For example, if ALPHA is provided as input, but only BETA and GA-level features are used, this field will be BETA on output. Possible values: ["UNIMPLEMENTED", "PRELAUNCH", "EARLY_ACCESS", "ALPHA", "BETA", "GA", "DEPRECATED"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#launch_stage CloudRunV2WorkerPool#launch_stage}
    */
    readonly launchStage?: string;
    /**
    * The location of the cloud run worker pool
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#location CloudRunV2WorkerPool#location}
    */
    readonly location: string;
    /**
    * Name of the WorkerPool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#name CloudRunV2WorkerPool#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#project CloudRunV2WorkerPool#project}
    */
    readonly project?: string;
    /**
    * binary_authorization block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#binary_authorization CloudRunV2WorkerPool#binary_authorization}
    */
    readonly binaryAuthorization?: CloudRunV2WorkerPoolBinaryAuthorization;
    /**
    * instance_splits block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#instance_splits CloudRunV2WorkerPool#instance_splits}
    */
    readonly instanceSplits?: CloudRunV2WorkerPoolInstanceSplits[] | cdktn.IResolvable;
    /**
    * scaling block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#scaling CloudRunV2WorkerPool#scaling}
    */
    readonly scaling?: CloudRunV2WorkerPoolScaling;
    /**
    * template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#template CloudRunV2WorkerPool#template}
    */
    readonly template: CloudRunV2WorkerPoolTemplate;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#timeouts CloudRunV2WorkerPool#timeouts}
    */
    readonly timeouts?: CloudRunV2WorkerPoolTimeouts;
}
export interface CloudRunV2WorkerPoolConditions {
}
export declare function cloudRunV2WorkerPoolConditionsToTerraform(struct?: CloudRunV2WorkerPoolConditions): any;
export declare function cloudRunV2WorkerPoolConditionsToHclTerraform(struct?: CloudRunV2WorkerPoolConditions): any;
export declare class CloudRunV2WorkerPoolConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2WorkerPoolConditions | undefined;
    set internalValue(value: CloudRunV2WorkerPoolConditions | undefined);
    get executionReason(): string;
    get lastTransitionTime(): string;
    get message(): string;
    get reason(): string;
    get revisionReason(): string;
    get severity(): string;
    get state(): string;
    get type(): string;
}
export declare class CloudRunV2WorkerPoolConditionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2WorkerPoolConditionsOutputReference;
}
export interface CloudRunV2WorkerPoolInstanceSplitStatuses {
}
export declare function cloudRunV2WorkerPoolInstanceSplitStatusesToTerraform(struct?: CloudRunV2WorkerPoolInstanceSplitStatuses): any;
export declare function cloudRunV2WorkerPoolInstanceSplitStatusesToHclTerraform(struct?: CloudRunV2WorkerPoolInstanceSplitStatuses): any;
export declare class CloudRunV2WorkerPoolInstanceSplitStatusesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2WorkerPoolInstanceSplitStatuses | undefined;
    set internalValue(value: CloudRunV2WorkerPoolInstanceSplitStatuses | undefined);
    get percent(): number;
    get revision(): string;
    get type(): string;
}
export declare class CloudRunV2WorkerPoolInstanceSplitStatusesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2WorkerPoolInstanceSplitStatusesOutputReference;
}
export interface CloudRunV2WorkerPoolTerminalCondition {
}
export declare function cloudRunV2WorkerPoolTerminalConditionToTerraform(struct?: CloudRunV2WorkerPoolTerminalCondition): any;
export declare function cloudRunV2WorkerPoolTerminalConditionToHclTerraform(struct?: CloudRunV2WorkerPoolTerminalCondition): any;
export declare class CloudRunV2WorkerPoolTerminalConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2WorkerPoolTerminalCondition | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTerminalCondition | undefined);
    get executionReason(): string;
    get lastTransitionTime(): string;
    get message(): string;
    get reason(): string;
    get revisionReason(): string;
    get severity(): string;
    get state(): string;
    get type(): string;
}
export declare class CloudRunV2WorkerPoolTerminalConditionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2WorkerPoolTerminalConditionOutputReference;
}
export interface CloudRunV2WorkerPoolBinaryAuthorization {
    /**
    * If present, indicates to use Breakglass using this justification. If useDefault is False, then it must be empty. For more information on breakglass, see https://cloud.google.com/binary-authorization/docs/using-breakglass
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#breakglass_justification CloudRunV2WorkerPool#breakglass_justification}
    */
    readonly breakglassJustification?: string;
    /**
    * The path to a binary authorization policy. Format: projects/{project}/platforms/cloudRun/{policy-name}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#policy CloudRunV2WorkerPool#policy}
    */
    readonly policy?: string;
    /**
    * If True, indicates to use the default project's binary authorization policy. If False, binary authorization will be disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#use_default CloudRunV2WorkerPool#use_default}
    */
    readonly useDefault?: boolean | cdktn.IResolvable;
}
export declare function cloudRunV2WorkerPoolBinaryAuthorizationToTerraform(struct?: CloudRunV2WorkerPoolBinaryAuthorizationOutputReference | CloudRunV2WorkerPoolBinaryAuthorization): any;
export declare function cloudRunV2WorkerPoolBinaryAuthorizationToHclTerraform(struct?: CloudRunV2WorkerPoolBinaryAuthorizationOutputReference | CloudRunV2WorkerPoolBinaryAuthorization): any;
export declare class CloudRunV2WorkerPoolBinaryAuthorizationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2WorkerPoolBinaryAuthorization | undefined;
    set internalValue(value: CloudRunV2WorkerPoolBinaryAuthorization | undefined);
    private _breakglassJustification?;
    get breakglassJustification(): string;
    set breakglassJustification(value: string);
    resetBreakglassJustification(): void;
    get breakglassJustificationInput(): string | undefined;
    private _policy?;
    get policy(): string;
    set policy(value: string);
    resetPolicy(): void;
    get policyInput(): string | undefined;
    private _useDefault?;
    get useDefault(): boolean | cdktn.IResolvable;
    set useDefault(value: boolean | cdktn.IResolvable);
    resetUseDefault(): void;
    get useDefaultInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CloudRunV2WorkerPoolInstanceSplits {
    /**
    * Specifies percent of the instance split to this Revision. This defaults to zero if unspecified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#percent CloudRunV2WorkerPool#percent}
    */
    readonly percent?: number;
    /**
    * Revision to which to assign this portion of instances, if split allocation is by revision.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#revision CloudRunV2WorkerPool#revision}
    */
    readonly revision?: string;
    /**
    * The allocation type for this instance split. Possible values: ["INSTANCE_SPLIT_ALLOCATION_TYPE_LATEST", "INSTANCE_SPLIT_ALLOCATION_TYPE_REVISION"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#type CloudRunV2WorkerPool#type}
    */
    readonly type?: string;
}
export declare function cloudRunV2WorkerPoolInstanceSplitsToTerraform(struct?: CloudRunV2WorkerPoolInstanceSplits | cdktn.IResolvable): any;
export declare function cloudRunV2WorkerPoolInstanceSplitsToHclTerraform(struct?: CloudRunV2WorkerPoolInstanceSplits | cdktn.IResolvable): any;
export declare class CloudRunV2WorkerPoolInstanceSplitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2WorkerPoolInstanceSplits | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2WorkerPoolInstanceSplits | cdktn.IResolvable | undefined);
    private _percent?;
    get percent(): number;
    set percent(value: number);
    resetPercent(): void;
    get percentInput(): number | undefined;
    private _revision?;
    get revision(): string;
    set revision(value: string);
    resetRevision(): void;
    get revisionInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class CloudRunV2WorkerPoolInstanceSplitsList extends cdktn.ComplexList {
    internalValue?: CloudRunV2WorkerPoolInstanceSplits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2WorkerPoolInstanceSplitsOutputReference;
}
export interface CloudRunV2WorkerPoolScaling {
    /**
    * The total number of instances in manual scaling mode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#manual_instance_count CloudRunV2WorkerPool#manual_instance_count}
    */
    readonly manualInstanceCount?: number;
    /**
    * The maximum count of instances distributed among revisions based on the specified instance split percentages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#max_instance_count CloudRunV2WorkerPool#max_instance_count}
    */
    readonly maxInstanceCount?: number;
    /**
    * The minimum count of instances distributed among revisions based on the specified instance split percentages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#min_instance_count CloudRunV2WorkerPool#min_instance_count}
    */
    readonly minInstanceCount?: number;
    /**
    * The scaling mode for the worker pool. It defaults to MANUAL. Possible values: ["AUTOMATIC", "MANUAL"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#scaling_mode CloudRunV2WorkerPool#scaling_mode}
    */
    readonly scalingMode?: string;
}
export declare function cloudRunV2WorkerPoolScalingToTerraform(struct?: CloudRunV2WorkerPoolScalingOutputReference | CloudRunV2WorkerPoolScaling): any;
export declare function cloudRunV2WorkerPoolScalingToHclTerraform(struct?: CloudRunV2WorkerPoolScalingOutputReference | CloudRunV2WorkerPoolScaling): any;
export declare class CloudRunV2WorkerPoolScalingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2WorkerPoolScaling | undefined;
    set internalValue(value: CloudRunV2WorkerPoolScaling | undefined);
    private _manualInstanceCount?;
    get manualInstanceCount(): number;
    set manualInstanceCount(value: number);
    resetManualInstanceCount(): void;
    get manualInstanceCountInput(): number | undefined;
    private _maxInstanceCount?;
    get maxInstanceCount(): number;
    set maxInstanceCount(value: number);
    resetMaxInstanceCount(): void;
    get maxInstanceCountInput(): number | undefined;
    private _minInstanceCount?;
    get minInstanceCount(): number;
    set minInstanceCount(value: number);
    resetMinInstanceCount(): void;
    get minInstanceCountInput(): number | undefined;
    private _scalingMode?;
    get scalingMode(): string;
    set scalingMode(value: string);
    resetScalingMode(): void;
    get scalingModeInput(): string | undefined;
}
export interface CloudRunV2WorkerPoolTemplateContainersEnvValueSourceSecretKeyRef {
    /**
    * The name of the secret in Cloud Secret Manager. Format: {secretName} if the secret is in the same project. projects/{project}/secrets/{secretName} if the secret is in a different project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#secret CloudRunV2WorkerPool#secret}
    */
    readonly secret: string;
    /**
    * The Cloud Secret Manager secret version. Can be 'latest' for the latest value or an integer for a specific version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#version CloudRunV2WorkerPool#version}
    */
    readonly version?: string;
}
export declare function cloudRunV2WorkerPoolTemplateContainersEnvValueSourceSecretKeyRefToTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersEnvValueSourceSecretKeyRefOutputReference | CloudRunV2WorkerPoolTemplateContainersEnvValueSourceSecretKeyRef): any;
export declare function cloudRunV2WorkerPoolTemplateContainersEnvValueSourceSecretKeyRefToHclTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersEnvValueSourceSecretKeyRefOutputReference | CloudRunV2WorkerPoolTemplateContainersEnvValueSourceSecretKeyRef): any;
export declare class CloudRunV2WorkerPoolTemplateContainersEnvValueSourceSecretKeyRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2WorkerPoolTemplateContainersEnvValueSourceSecretKeyRef | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTemplateContainersEnvValueSourceSecretKeyRef | undefined);
    private _secret?;
    get secret(): string;
    set secret(value: string);
    get secretInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export interface CloudRunV2WorkerPoolTemplateContainersEnvValueSource {
    /**
    * secret_key_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#secret_key_ref CloudRunV2WorkerPool#secret_key_ref}
    */
    readonly secretKeyRef?: CloudRunV2WorkerPoolTemplateContainersEnvValueSourceSecretKeyRef;
}
export declare function cloudRunV2WorkerPoolTemplateContainersEnvValueSourceToTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersEnvValueSourceOutputReference | CloudRunV2WorkerPoolTemplateContainersEnvValueSource): any;
export declare function cloudRunV2WorkerPoolTemplateContainersEnvValueSourceToHclTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersEnvValueSourceOutputReference | CloudRunV2WorkerPoolTemplateContainersEnvValueSource): any;
export declare class CloudRunV2WorkerPoolTemplateContainersEnvValueSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2WorkerPoolTemplateContainersEnvValueSource | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTemplateContainersEnvValueSource | undefined);
    private _secretKeyRef;
    get secretKeyRef(): CloudRunV2WorkerPoolTemplateContainersEnvValueSourceSecretKeyRefOutputReference;
    putSecretKeyRef(value: CloudRunV2WorkerPoolTemplateContainersEnvValueSourceSecretKeyRef): void;
    resetSecretKeyRef(): void;
    get secretKeyRefInput(): CloudRunV2WorkerPoolTemplateContainersEnvValueSourceSecretKeyRef | undefined;
}
export interface CloudRunV2WorkerPoolTemplateContainersEnv {
    /**
    * Name of the environment variable. Must be a C_IDENTIFIER, and may not exceed 32768 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#name CloudRunV2WorkerPool#name}
    */
    readonly name: string;
    /**
    * Literal value of the environment variable. Defaults to "" and the maximum allowed length is 32768 characters. Variable references are not supported in Cloud Run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#value CloudRunV2WorkerPool#value}
    */
    readonly value?: string;
    /**
    * value_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#value_source CloudRunV2WorkerPool#value_source}
    */
    readonly valueSource?: CloudRunV2WorkerPoolTemplateContainersEnvValueSource;
}
export declare function cloudRunV2WorkerPoolTemplateContainersEnvToTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersEnv | cdktn.IResolvable): any;
export declare function cloudRunV2WorkerPoolTemplateContainersEnvToHclTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersEnv | cdktn.IResolvable): any;
export declare class CloudRunV2WorkerPoolTemplateContainersEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2WorkerPoolTemplateContainersEnv | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTemplateContainersEnv | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _valueSource;
    get valueSource(): CloudRunV2WorkerPoolTemplateContainersEnvValueSourceOutputReference;
    putValueSource(value: CloudRunV2WorkerPoolTemplateContainersEnvValueSource): void;
    resetValueSource(): void;
    get valueSourceInput(): CloudRunV2WorkerPoolTemplateContainersEnvValueSource | undefined;
}
export declare class CloudRunV2WorkerPoolTemplateContainersEnvList extends cdktn.ComplexList {
    internalValue?: CloudRunV2WorkerPoolTemplateContainersEnv[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2WorkerPoolTemplateContainersEnvOutputReference;
}
export interface CloudRunV2WorkerPoolTemplateContainersLivenessProbeGrpc {
    /**
    * Optional. Port number of the gRPC service. Number must be in the range 1 to 65535. If not specified, defaults to the exposed port of the container, which is the value of container.ports[0].containerPort.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#port CloudRunV2WorkerPool#port}
    */
    readonly port?: number;
    /**
    * Optional. Service is the name of the service to place in the gRPC HealthCheckRequest (see https://github.com/grpc/grpc/blob/master/doc/health-checking.md ). If this is not specified, the default behavior is defined by gRPC
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#service CloudRunV2WorkerPool#service}
    */
    readonly service?: string;
}
export declare function cloudRunV2WorkerPoolTemplateContainersLivenessProbeGrpcToTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersLivenessProbeGrpcOutputReference | CloudRunV2WorkerPoolTemplateContainersLivenessProbeGrpc): any;
export declare function cloudRunV2WorkerPoolTemplateContainersLivenessProbeGrpcToHclTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersLivenessProbeGrpcOutputReference | CloudRunV2WorkerPoolTemplateContainersLivenessProbeGrpc): any;
export declare class CloudRunV2WorkerPoolTemplateContainersLivenessProbeGrpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2WorkerPoolTemplateContainersLivenessProbeGrpc | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTemplateContainersLivenessProbeGrpc | undefined);
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
}
export interface CloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetHttpHeaders {
    /**
    * Required. The header field name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#name CloudRunV2WorkerPool#name}
    */
    readonly name: string;
    /**
    * Optional. The header field value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#value CloudRunV2WorkerPool#value}
    */
    readonly value?: string;
}
export declare function cloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetHttpHeadersToTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetHttpHeaders | cdktn.IResolvable): any;
export declare function cloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetHttpHeadersToHclTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetHttpHeaders | cdktn.IResolvable): any;
export declare class CloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetHttpHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetHttpHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetHttpHeaders | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetHttpHeadersList extends cdktn.ComplexList {
    internalValue?: CloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetHttpHeaders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetHttpHeadersOutputReference;
}
export interface CloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGet {
    /**
    * Optional. Path to access on the HTTP server. Defaults to '/'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#path CloudRunV2WorkerPool#path}
    */
    readonly path?: string;
    /**
    * Optional. Port number to access on the container. Must be in the range 1 to 65535. If not specified, defaults to the exposed port of the container, which is the value of container.ports[0].containerPort.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#port CloudRunV2WorkerPool#port}
    */
    readonly port?: number;
    /**
    * http_headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#http_headers CloudRunV2WorkerPool#http_headers}
    */
    readonly httpHeaders?: CloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetHttpHeaders[] | cdktn.IResolvable;
}
export declare function cloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetToTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetOutputReference | CloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGet): any;
export declare function cloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetToHclTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetOutputReference | CloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGet): any;
export declare class CloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGet | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGet | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _httpHeaders;
    get httpHeaders(): CloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetHttpHeadersList;
    putHttpHeaders(value: CloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetHttpHeaders[] | cdktn.IResolvable): void;
    resetHttpHeaders(): void;
    get httpHeadersInput(): cdktn.IResolvable | CloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetHttpHeaders[] | undefined;
}
export interface CloudRunV2WorkerPoolTemplateContainersLivenessProbeTcpSocket {
    /**
    * Optional. Port number to access on the container. Must be in the range 1 to 65535. If not specified, defaults to the exposed port of the container, which is the value of container.ports[0].containerPort.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#port CloudRunV2WorkerPool#port}
    */
    readonly port?: number;
}
export declare function cloudRunV2WorkerPoolTemplateContainersLivenessProbeTcpSocketToTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersLivenessProbeTcpSocketOutputReference | CloudRunV2WorkerPoolTemplateContainersLivenessProbeTcpSocket): any;
export declare function cloudRunV2WorkerPoolTemplateContainersLivenessProbeTcpSocketToHclTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersLivenessProbeTcpSocketOutputReference | CloudRunV2WorkerPoolTemplateContainersLivenessProbeTcpSocket): any;
export declare class CloudRunV2WorkerPoolTemplateContainersLivenessProbeTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2WorkerPoolTemplateContainersLivenessProbeTcpSocket | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTemplateContainersLivenessProbeTcpSocket | undefined);
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
}
export interface CloudRunV2WorkerPoolTemplateContainersLivenessProbe {
    /**
    * Optional. Minimum consecutive failures for the probe to be considered failed after having succeeded. Defaults to 3. Minimum value is 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#failure_threshold CloudRunV2WorkerPool#failure_threshold}
    */
    readonly failureThreshold?: number;
    /**
    * Optional. Number of seconds after the container has started before the probe is initiated. Defaults to 0 seconds. Minimum value is 0. Maximum value for liveness probe is 3600. Maximum value for startup probe is 240.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#initial_delay_seconds CloudRunV2WorkerPool#initial_delay_seconds}
    */
    readonly initialDelaySeconds?: number;
    /**
    * Optional. How often (in seconds) to perform the probe. Default to 10 seconds. Minimum value is 1. Maximum value for liveness probe is 3600. Maximum value for startup probe is 240. Must be greater or equal than timeout_seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#period_seconds CloudRunV2WorkerPool#period_seconds}
    */
    readonly periodSeconds?: number;
    /**
    * Optional. Number of seconds after which the probe times out. Defaults to 1 second. Minimum value is 1. Maximum value is 3600. Must be smaller than period_seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#timeout_seconds CloudRunV2WorkerPool#timeout_seconds}
    */
    readonly timeoutSeconds?: number;
    /**
    * grpc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#grpc CloudRunV2WorkerPool#grpc}
    */
    readonly grpc?: CloudRunV2WorkerPoolTemplateContainersLivenessProbeGrpc;
    /**
    * http_get block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#http_get CloudRunV2WorkerPool#http_get}
    */
    readonly httpGet?: CloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGet;
    /**
    * tcp_socket block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#tcp_socket CloudRunV2WorkerPool#tcp_socket}
    */
    readonly tcpSocket?: CloudRunV2WorkerPoolTemplateContainersLivenessProbeTcpSocket;
}
export declare function cloudRunV2WorkerPoolTemplateContainersLivenessProbeToTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersLivenessProbeOutputReference | CloudRunV2WorkerPoolTemplateContainersLivenessProbe): any;
export declare function cloudRunV2WorkerPoolTemplateContainersLivenessProbeToHclTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersLivenessProbeOutputReference | CloudRunV2WorkerPoolTemplateContainersLivenessProbe): any;
export declare class CloudRunV2WorkerPoolTemplateContainersLivenessProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2WorkerPoolTemplateContainersLivenessProbe | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTemplateContainersLivenessProbe | undefined);
    private _failureThreshold?;
    get failureThreshold(): number;
    set failureThreshold(value: number);
    resetFailureThreshold(): void;
    get failureThresholdInput(): number | undefined;
    private _initialDelaySeconds?;
    get initialDelaySeconds(): number;
    set initialDelaySeconds(value: number);
    resetInitialDelaySeconds(): void;
    get initialDelaySecondsInput(): number | undefined;
    private _periodSeconds?;
    get periodSeconds(): number;
    set periodSeconds(value: number);
    resetPeriodSeconds(): void;
    get periodSecondsInput(): number | undefined;
    private _timeoutSeconds?;
    get timeoutSeconds(): number;
    set timeoutSeconds(value: number);
    resetTimeoutSeconds(): void;
    get timeoutSecondsInput(): number | undefined;
    private _grpc;
    get grpc(): CloudRunV2WorkerPoolTemplateContainersLivenessProbeGrpcOutputReference;
    putGrpc(value: CloudRunV2WorkerPoolTemplateContainersLivenessProbeGrpc): void;
    resetGrpc(): void;
    get grpcInput(): CloudRunV2WorkerPoolTemplateContainersLivenessProbeGrpc | undefined;
    private _httpGet;
    get httpGet(): CloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetOutputReference;
    putHttpGet(value: CloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGet): void;
    resetHttpGet(): void;
    get httpGetInput(): CloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGet | undefined;
    private _tcpSocket;
    get tcpSocket(): CloudRunV2WorkerPoolTemplateContainersLivenessProbeTcpSocketOutputReference;
    putTcpSocket(value: CloudRunV2WorkerPoolTemplateContainersLivenessProbeTcpSocket): void;
    resetTcpSocket(): void;
    get tcpSocketInput(): CloudRunV2WorkerPoolTemplateContainersLivenessProbeTcpSocket | undefined;
}
export interface CloudRunV2WorkerPoolTemplateContainersResources {
    /**
    * Only memory, CPU, and nvidia.com/gpu are supported. Use key 'cpu' for CPU limit, 'memory' for memory limit, 'nvidia.com/gpu' for gpu limit. Note: The only supported values for CPU are '1', '2', '4', '6', and '8'. Setting 4 CPU requires at least 2Gi of memory, setting 6 or more CPU requires at least 4Gi of memory. The values of the map is string form of the 'quantity' k8s type: https://github.com/kubernetes/kubernetes/blob/master/staging/src/k8s.io/apimachinery/pkg/api/resource/quantity.go
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#limits CloudRunV2WorkerPool#limits}
    */
    readonly limits?: {
        [key: string]: string;
    };
}
export declare function cloudRunV2WorkerPoolTemplateContainersResourcesToTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersResourcesOutputReference | CloudRunV2WorkerPoolTemplateContainersResources): any;
export declare function cloudRunV2WorkerPoolTemplateContainersResourcesToHclTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersResourcesOutputReference | CloudRunV2WorkerPoolTemplateContainersResources): any;
export declare class CloudRunV2WorkerPoolTemplateContainersResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2WorkerPoolTemplateContainersResources | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTemplateContainersResources | undefined);
    private _limits?;
    get limits(): {
        [key: string]: string;
    };
    set limits(value: {
        [key: string]: string;
    });
    resetLimits(): void;
    get limitsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface CloudRunV2WorkerPoolTemplateContainersStartupProbeGrpc {
    /**
    * Optional. Port number of the gRPC service. Number must be in the range 1 to 65535. If not specified, defaults to the exposed port of the container, which is the value of container.ports[0].containerPort.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#port CloudRunV2WorkerPool#port}
    */
    readonly port?: number;
    /**
    * Optional. Service is the name of the service to place in the gRPC HealthCheckRequest (see https://github.com/grpc/grpc/blob/master/doc/health-checking.md ). If this is not specified, the default behavior is defined by gRPC
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#service CloudRunV2WorkerPool#service}
    */
    readonly service?: string;
}
export declare function cloudRunV2WorkerPoolTemplateContainersStartupProbeGrpcToTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersStartupProbeGrpcOutputReference | CloudRunV2WorkerPoolTemplateContainersStartupProbeGrpc): any;
export declare function cloudRunV2WorkerPoolTemplateContainersStartupProbeGrpcToHclTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersStartupProbeGrpcOutputReference | CloudRunV2WorkerPoolTemplateContainersStartupProbeGrpc): any;
export declare class CloudRunV2WorkerPoolTemplateContainersStartupProbeGrpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2WorkerPoolTemplateContainersStartupProbeGrpc | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTemplateContainersStartupProbeGrpc | undefined);
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
}
export interface CloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetHttpHeaders {
    /**
    * Required. The header field name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#name CloudRunV2WorkerPool#name}
    */
    readonly name: string;
    /**
    * Optional. The header field value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#value CloudRunV2WorkerPool#value}
    */
    readonly value?: string;
}
export declare function cloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetHttpHeadersToTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetHttpHeaders | cdktn.IResolvable): any;
export declare function cloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetHttpHeadersToHclTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetHttpHeaders | cdktn.IResolvable): any;
export declare class CloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetHttpHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetHttpHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetHttpHeaders | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetHttpHeadersList extends cdktn.ComplexList {
    internalValue?: CloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetHttpHeaders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetHttpHeadersOutputReference;
}
export interface CloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGet {
    /**
    * Optional. Path to access on the HTTP server. Defaults to '/'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#path CloudRunV2WorkerPool#path}
    */
    readonly path?: string;
    /**
    * Optional. Port number to access on the container. Must be in the range 1 to 65535. If not specified, defaults to the exposed port of the container, which is the value of container.ports[0].containerPort.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#port CloudRunV2WorkerPool#port}
    */
    readonly port?: number;
    /**
    * http_headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#http_headers CloudRunV2WorkerPool#http_headers}
    */
    readonly httpHeaders?: CloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetHttpHeaders[] | cdktn.IResolvable;
}
export declare function cloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetToTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetOutputReference | CloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGet): any;
export declare function cloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetToHclTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetOutputReference | CloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGet): any;
export declare class CloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGet | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGet | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _httpHeaders;
    get httpHeaders(): CloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetHttpHeadersList;
    putHttpHeaders(value: CloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetHttpHeaders[] | cdktn.IResolvable): void;
    resetHttpHeaders(): void;
    get httpHeadersInput(): cdktn.IResolvable | CloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetHttpHeaders[] | undefined;
}
export interface CloudRunV2WorkerPoolTemplateContainersStartupProbeTcpSocket {
    /**
    * Optional. Port number to access on the container. Must be in the range 1 to 65535. If not specified, defaults to the exposed port of the container, which is the value of container.ports[0].containerPort.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#port CloudRunV2WorkerPool#port}
    */
    readonly port?: number;
}
export declare function cloudRunV2WorkerPoolTemplateContainersStartupProbeTcpSocketToTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersStartupProbeTcpSocketOutputReference | CloudRunV2WorkerPoolTemplateContainersStartupProbeTcpSocket): any;
export declare function cloudRunV2WorkerPoolTemplateContainersStartupProbeTcpSocketToHclTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersStartupProbeTcpSocketOutputReference | CloudRunV2WorkerPoolTemplateContainersStartupProbeTcpSocket): any;
export declare class CloudRunV2WorkerPoolTemplateContainersStartupProbeTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2WorkerPoolTemplateContainersStartupProbeTcpSocket | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTemplateContainersStartupProbeTcpSocket | undefined);
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
}
export interface CloudRunV2WorkerPoolTemplateContainersStartupProbe {
    /**
    * Optional. Minimum consecutive failures for the probe to be considered failed after having succeeded. Defaults to 3. Minimum value is 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#failure_threshold CloudRunV2WorkerPool#failure_threshold}
    */
    readonly failureThreshold?: number;
    /**
    * Optional. Number of seconds after the container has started before the probe is initiated. Defaults to 0 seconds. Minimum value is 0. Maximum value for liveness probe is 3600. Maximum value for startup probe is 240.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#initial_delay_seconds CloudRunV2WorkerPool#initial_delay_seconds}
    */
    readonly initialDelaySeconds?: number;
    /**
    * Optional. How often (in seconds) to perform the probe. Default to 10 seconds. Minimum value is 1. Maximum value for liveness probe is 3600. Maximum value for startup probe is 240. Must be greater or equal than timeout_seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#period_seconds CloudRunV2WorkerPool#period_seconds}
    */
    readonly periodSeconds?: number;
    /**
    * Optional. Number of seconds after which the probe times out. Defaults to 1 second. Minimum value is 1. Maximum value is 3600. Must be smaller than period_seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#timeout_seconds CloudRunV2WorkerPool#timeout_seconds}
    */
    readonly timeoutSeconds?: number;
    /**
    * grpc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#grpc CloudRunV2WorkerPool#grpc}
    */
    readonly grpc?: CloudRunV2WorkerPoolTemplateContainersStartupProbeGrpc;
    /**
    * http_get block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#http_get CloudRunV2WorkerPool#http_get}
    */
    readonly httpGet?: CloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGet;
    /**
    * tcp_socket block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#tcp_socket CloudRunV2WorkerPool#tcp_socket}
    */
    readonly tcpSocket?: CloudRunV2WorkerPoolTemplateContainersStartupProbeTcpSocket;
}
export declare function cloudRunV2WorkerPoolTemplateContainersStartupProbeToTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersStartupProbeOutputReference | CloudRunV2WorkerPoolTemplateContainersStartupProbe): any;
export declare function cloudRunV2WorkerPoolTemplateContainersStartupProbeToHclTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersStartupProbeOutputReference | CloudRunV2WorkerPoolTemplateContainersStartupProbe): any;
export declare class CloudRunV2WorkerPoolTemplateContainersStartupProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2WorkerPoolTemplateContainersStartupProbe | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTemplateContainersStartupProbe | undefined);
    private _failureThreshold?;
    get failureThreshold(): number;
    set failureThreshold(value: number);
    resetFailureThreshold(): void;
    get failureThresholdInput(): number | undefined;
    private _initialDelaySeconds?;
    get initialDelaySeconds(): number;
    set initialDelaySeconds(value: number);
    resetInitialDelaySeconds(): void;
    get initialDelaySecondsInput(): number | undefined;
    private _periodSeconds?;
    get periodSeconds(): number;
    set periodSeconds(value: number);
    resetPeriodSeconds(): void;
    get periodSecondsInput(): number | undefined;
    private _timeoutSeconds?;
    get timeoutSeconds(): number;
    set timeoutSeconds(value: number);
    resetTimeoutSeconds(): void;
    get timeoutSecondsInput(): number | undefined;
    private _grpc;
    get grpc(): CloudRunV2WorkerPoolTemplateContainersStartupProbeGrpcOutputReference;
    putGrpc(value: CloudRunV2WorkerPoolTemplateContainersStartupProbeGrpc): void;
    resetGrpc(): void;
    get grpcInput(): CloudRunV2WorkerPoolTemplateContainersStartupProbeGrpc | undefined;
    private _httpGet;
    get httpGet(): CloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetOutputReference;
    putHttpGet(value: CloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGet): void;
    resetHttpGet(): void;
    get httpGetInput(): CloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGet | undefined;
    private _tcpSocket;
    get tcpSocket(): CloudRunV2WorkerPoolTemplateContainersStartupProbeTcpSocketOutputReference;
    putTcpSocket(value: CloudRunV2WorkerPoolTemplateContainersStartupProbeTcpSocket): void;
    resetTcpSocket(): void;
    get tcpSocketInput(): CloudRunV2WorkerPoolTemplateContainersStartupProbeTcpSocket | undefined;
}
export interface CloudRunV2WorkerPoolTemplateContainersVolumeMounts {
    /**
    * Path within the container at which the volume should be mounted. Must not contain ':'. For Cloud SQL volumes, it can be left empty, or must otherwise be /cloudsql. All instances defined in the Volume will be available as /cloudsql/[instance]. For more information on Cloud SQL volumes, visit https://cloud.google.com/sql/docs/mysql/connect-run
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#mount_path CloudRunV2WorkerPool#mount_path}
    */
    readonly mountPath: string;
    /**
    * This must match the Name of a Volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#name CloudRunV2WorkerPool#name}
    */
    readonly name: string;
    /**
    * Path within the volume from which the container's volume should be mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#sub_path CloudRunV2WorkerPool#sub_path}
    */
    readonly subPath?: string;
}
export declare function cloudRunV2WorkerPoolTemplateContainersVolumeMountsToTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersVolumeMounts | cdktn.IResolvable): any;
export declare function cloudRunV2WorkerPoolTemplateContainersVolumeMountsToHclTerraform(struct?: CloudRunV2WorkerPoolTemplateContainersVolumeMounts | cdktn.IResolvable): any;
export declare class CloudRunV2WorkerPoolTemplateContainersVolumeMountsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2WorkerPoolTemplateContainersVolumeMounts | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTemplateContainersVolumeMounts | cdktn.IResolvable | undefined);
    private _mountPath?;
    get mountPath(): string;
    set mountPath(value: string);
    get mountPathInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _subPath?;
    get subPath(): string;
    set subPath(value: string);
    resetSubPath(): void;
    get subPathInput(): string | undefined;
}
export declare class CloudRunV2WorkerPoolTemplateContainersVolumeMountsList extends cdktn.ComplexList {
    internalValue?: CloudRunV2WorkerPoolTemplateContainersVolumeMounts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2WorkerPoolTemplateContainersVolumeMountsOutputReference;
}
export interface CloudRunV2WorkerPoolTemplateContainers {
    /**
    * Arguments to the entrypoint. The docker image's CMD is used if this is not provided. Variable references are not supported in Cloud Run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#args CloudRunV2WorkerPool#args}
    */
    readonly args?: string[];
    /**
    * Entrypoint array. Not executed within a shell. The docker image's ENTRYPOINT is used if this is not provided. Variable references $(VAR_NAME) are expanded using the container's environment. If a variable cannot be resolved, the reference in the input string will be unchanged. The $(VAR_NAME) syntax can be escaped with a double $$, ie: $$(VAR_NAME). Escaped references will never be expanded, regardless of whether the variable exists or not. More info: https://kubernetes.io/docs/tasks/inject-data-application/define-command-argument-container/#running-a-command-in-a-shell
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#command CloudRunV2WorkerPool#command}
    */
    readonly command?: string[];
    /**
    * Names of the containers that must start before this container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#depends_on CloudRunV2WorkerPool#depends_on}
    */
    readonly dependsOn?: string[];
    /**
    * URL of the Container image in Google Container Registry or Google Artifact Registry. More info: https://kubernetes.io/docs/concepts/containers/images
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#image CloudRunV2WorkerPool#image}
    */
    readonly image: string;
    /**
    * Name of the container specified as a DNS_LABEL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#name CloudRunV2WorkerPool#name}
    */
    readonly name?: string;
    /**
    * Indicates that this container can act as a sandbox supervisor and launch sandboxes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#sandbox_launcher CloudRunV2WorkerPool#sandbox_launcher}
    */
    readonly sandboxLauncher?: boolean | cdktn.IResolvable;
    /**
    * Container's working directory. If not specified, the container runtime's default will be used, which might be configured in the container image.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#working_dir CloudRunV2WorkerPool#working_dir}
    */
    readonly workingDir?: string;
    /**
    * env block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#env CloudRunV2WorkerPool#env}
    */
    readonly env?: CloudRunV2WorkerPoolTemplateContainersEnv[] | cdktn.IResolvable;
    /**
    * liveness_probe block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#liveness_probe CloudRunV2WorkerPool#liveness_probe}
    */
    readonly livenessProbe?: CloudRunV2WorkerPoolTemplateContainersLivenessProbe;
    /**
    * resources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#resources CloudRunV2WorkerPool#resources}
    */
    readonly resources?: CloudRunV2WorkerPoolTemplateContainersResources;
    /**
    * startup_probe block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#startup_probe CloudRunV2WorkerPool#startup_probe}
    */
    readonly startupProbe?: CloudRunV2WorkerPoolTemplateContainersStartupProbe;
    /**
    * volume_mounts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#volume_mounts CloudRunV2WorkerPool#volume_mounts}
    */
    readonly volumeMounts?: CloudRunV2WorkerPoolTemplateContainersVolumeMounts[] | cdktn.IResolvable;
}
export declare function cloudRunV2WorkerPoolTemplateContainersToTerraform(struct?: CloudRunV2WorkerPoolTemplateContainers | cdktn.IResolvable): any;
export declare function cloudRunV2WorkerPoolTemplateContainersToHclTerraform(struct?: CloudRunV2WorkerPoolTemplateContainers | cdktn.IResolvable): any;
export declare class CloudRunV2WorkerPoolTemplateContainersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2WorkerPoolTemplateContainers | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTemplateContainers | cdktn.IResolvable | undefined);
    private _args?;
    get args(): string[];
    set args(value: string[]);
    resetArgs(): void;
    get argsInput(): string[] | undefined;
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
    private _dependsOn?;
    get dependsOn(): string[];
    set dependsOn(value: string[]);
    resetDependsOn(): void;
    get dependsOnInput(): string[] | undefined;
    private _image?;
    get image(): string;
    set image(value: string);
    get imageInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sandboxLauncher?;
    get sandboxLauncher(): boolean | cdktn.IResolvable;
    set sandboxLauncher(value: boolean | cdktn.IResolvable);
    resetSandboxLauncher(): void;
    get sandboxLauncherInput(): boolean | cdktn.IResolvable | undefined;
    private _workingDir?;
    get workingDir(): string;
    set workingDir(value: string);
    resetWorkingDir(): void;
    get workingDirInput(): string | undefined;
    private _env;
    get env(): CloudRunV2WorkerPoolTemplateContainersEnvList;
    putEnv(value: CloudRunV2WorkerPoolTemplateContainersEnv[] | cdktn.IResolvable): void;
    resetEnv(): void;
    get envInput(): cdktn.IResolvable | CloudRunV2WorkerPoolTemplateContainersEnv[] | undefined;
    private _livenessProbe;
    get livenessProbe(): CloudRunV2WorkerPoolTemplateContainersLivenessProbeOutputReference;
    putLivenessProbe(value: CloudRunV2WorkerPoolTemplateContainersLivenessProbe): void;
    resetLivenessProbe(): void;
    get livenessProbeInput(): CloudRunV2WorkerPoolTemplateContainersLivenessProbe | undefined;
    private _resources;
    get resources(): CloudRunV2WorkerPoolTemplateContainersResourcesOutputReference;
    putResources(value: CloudRunV2WorkerPoolTemplateContainersResources): void;
    resetResources(): void;
    get resourcesInput(): CloudRunV2WorkerPoolTemplateContainersResources | undefined;
    private _startupProbe;
    get startupProbe(): CloudRunV2WorkerPoolTemplateContainersStartupProbeOutputReference;
    putStartupProbe(value: CloudRunV2WorkerPoolTemplateContainersStartupProbe): void;
    resetStartupProbe(): void;
    get startupProbeInput(): CloudRunV2WorkerPoolTemplateContainersStartupProbe | undefined;
    private _volumeMounts;
    get volumeMounts(): CloudRunV2WorkerPoolTemplateContainersVolumeMountsList;
    putVolumeMounts(value: CloudRunV2WorkerPoolTemplateContainersVolumeMounts[] | cdktn.IResolvable): void;
    resetVolumeMounts(): void;
    get volumeMountsInput(): cdktn.IResolvable | CloudRunV2WorkerPoolTemplateContainersVolumeMounts[] | undefined;
}
export declare class CloudRunV2WorkerPoolTemplateContainersList extends cdktn.ComplexList {
    internalValue?: CloudRunV2WorkerPoolTemplateContainers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2WorkerPoolTemplateContainersOutputReference;
}
export interface CloudRunV2WorkerPoolTemplateNodeSelector {
    /**
    * The GPU to attach to an instance. See https://cloud.google.com/run/docs/configuring/services/gpu for configuring GPU.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#accelerator CloudRunV2WorkerPool#accelerator}
    */
    readonly accelerator: string;
}
export declare function cloudRunV2WorkerPoolTemplateNodeSelectorToTerraform(struct?: CloudRunV2WorkerPoolTemplateNodeSelectorOutputReference | CloudRunV2WorkerPoolTemplateNodeSelector): any;
export declare function cloudRunV2WorkerPoolTemplateNodeSelectorToHclTerraform(struct?: CloudRunV2WorkerPoolTemplateNodeSelectorOutputReference | CloudRunV2WorkerPoolTemplateNodeSelector): any;
export declare class CloudRunV2WorkerPoolTemplateNodeSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2WorkerPoolTemplateNodeSelector | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTemplateNodeSelector | undefined);
    private _accelerator?;
    get accelerator(): string;
    set accelerator(value: string);
    get acceleratorInput(): string | undefined;
}
export interface CloudRunV2WorkerPoolTemplateVolumesCloudSqlInstance {
    /**
    * The Cloud SQL instance connection names, as can be found in https://console.cloud.google.com/sql/instances. Visit https://cloud.google.com/sql/docs/mysql/connect-run for more information on how to connect Cloud SQL and Cloud Run. Format: {project}:{location}:{instance}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#instances CloudRunV2WorkerPool#instances}
    */
    readonly instances?: string[];
}
export declare function cloudRunV2WorkerPoolTemplateVolumesCloudSqlInstanceToTerraform(struct?: CloudRunV2WorkerPoolTemplateVolumesCloudSqlInstanceOutputReference | CloudRunV2WorkerPoolTemplateVolumesCloudSqlInstance): any;
export declare function cloudRunV2WorkerPoolTemplateVolumesCloudSqlInstanceToHclTerraform(struct?: CloudRunV2WorkerPoolTemplateVolumesCloudSqlInstanceOutputReference | CloudRunV2WorkerPoolTemplateVolumesCloudSqlInstance): any;
export declare class CloudRunV2WorkerPoolTemplateVolumesCloudSqlInstanceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2WorkerPoolTemplateVolumesCloudSqlInstance | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTemplateVolumesCloudSqlInstance | undefined);
    private _instances?;
    get instances(): string[];
    set instances(value: string[]);
    resetInstances(): void;
    get instancesInput(): string[] | undefined;
}
export interface CloudRunV2WorkerPoolTemplateVolumesEmptyDir {
    /**
    * The different types of medium supported for EmptyDir. Default value: "MEMORY" Possible values: ["MEMORY", "DISK"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#medium CloudRunV2WorkerPool#medium}
    */
    readonly medium?: string;
    /**
    * Limit on the storage usable by this EmptyDir volume. The size limit is also applicable for memory medium. The maximum usage on memory medium EmptyDir would be the minimum value between the SizeLimit specified here and the sum of memory limits of all containers in a pod. This field's values are of the 'Quantity' k8s type: https://kubernetes.io/docs/reference/kubernetes-api/common-definitions/quantity/. The default is nil which means that the limit is undefined. More info: https://kubernetes.io/docs/concepts/storage/volumes/#emptydir.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#size_limit CloudRunV2WorkerPool#size_limit}
    */
    readonly sizeLimit?: string;
}
export declare function cloudRunV2WorkerPoolTemplateVolumesEmptyDirToTerraform(struct?: CloudRunV2WorkerPoolTemplateVolumesEmptyDirOutputReference | CloudRunV2WorkerPoolTemplateVolumesEmptyDir): any;
export declare function cloudRunV2WorkerPoolTemplateVolumesEmptyDirToHclTerraform(struct?: CloudRunV2WorkerPoolTemplateVolumesEmptyDirOutputReference | CloudRunV2WorkerPoolTemplateVolumesEmptyDir): any;
export declare class CloudRunV2WorkerPoolTemplateVolumesEmptyDirOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2WorkerPoolTemplateVolumesEmptyDir | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTemplateVolumesEmptyDir | undefined);
    private _medium?;
    get medium(): string;
    set medium(value: string);
    resetMedium(): void;
    get mediumInput(): string | undefined;
    private _sizeLimit?;
    get sizeLimit(): string;
    set sizeLimit(value: string);
    resetSizeLimit(): void;
    get sizeLimitInput(): string | undefined;
}
export interface CloudRunV2WorkerPoolTemplateVolumesGcs {
    /**
    * GCS Bucket name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#bucket CloudRunV2WorkerPool#bucket}
    */
    readonly bucket: string;
    /**
    * A list of flags to pass to the gcsfuse command for configuring this volume.
    * Flags should be passed without leading dashes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#mount_options CloudRunV2WorkerPool#mount_options}
    */
    readonly mountOptions?: string[];
    /**
    * If true, mount the GCS bucket as read-only
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#read_only CloudRunV2WorkerPool#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
}
export declare function cloudRunV2WorkerPoolTemplateVolumesGcsToTerraform(struct?: CloudRunV2WorkerPoolTemplateVolumesGcsOutputReference | CloudRunV2WorkerPoolTemplateVolumesGcs): any;
export declare function cloudRunV2WorkerPoolTemplateVolumesGcsToHclTerraform(struct?: CloudRunV2WorkerPoolTemplateVolumesGcsOutputReference | CloudRunV2WorkerPoolTemplateVolumesGcs): any;
export declare class CloudRunV2WorkerPoolTemplateVolumesGcsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2WorkerPoolTemplateVolumesGcs | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTemplateVolumesGcs | undefined);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _mountOptions?;
    get mountOptions(): string[];
    set mountOptions(value: string[]);
    resetMountOptions(): void;
    get mountOptionsInput(): string[] | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CloudRunV2WorkerPoolTemplateVolumesNfs {
    /**
    * Path that is exported by the NFS server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#path CloudRunV2WorkerPool#path}
    */
    readonly path: string;
    /**
    * If true, mount the NFS volume as read only
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#read_only CloudRunV2WorkerPool#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Hostname or IP address of the NFS server
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#server CloudRunV2WorkerPool#server}
    */
    readonly server: string;
}
export declare function cloudRunV2WorkerPoolTemplateVolumesNfsToTerraform(struct?: CloudRunV2WorkerPoolTemplateVolumesNfsOutputReference | CloudRunV2WorkerPoolTemplateVolumesNfs): any;
export declare function cloudRunV2WorkerPoolTemplateVolumesNfsToHclTerraform(struct?: CloudRunV2WorkerPoolTemplateVolumesNfsOutputReference | CloudRunV2WorkerPoolTemplateVolumesNfs): any;
export declare class CloudRunV2WorkerPoolTemplateVolumesNfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2WorkerPoolTemplateVolumesNfs | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTemplateVolumesNfs | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _server?;
    get server(): string;
    set server(value: string);
    get serverInput(): string | undefined;
}
export interface CloudRunV2WorkerPoolTemplateVolumesSecretItems {
    /**
    * Integer octal mode bits to use on this file, must be a value between 01 and 0777 (octal). If 0 or not set, the Volume's default mode will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#mode CloudRunV2WorkerPool#mode}
    */
    readonly mode?: number;
    /**
    * The relative path of the secret in the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#path CloudRunV2WorkerPool#path}
    */
    readonly path: string;
    /**
    * The Cloud Secret Manager secret version. Can be 'latest' for the latest value or an integer for a specific version
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#version CloudRunV2WorkerPool#version}
    */
    readonly version?: string;
}
export declare function cloudRunV2WorkerPoolTemplateVolumesSecretItemsToTerraform(struct?: CloudRunV2WorkerPoolTemplateVolumesSecretItems | cdktn.IResolvable): any;
export declare function cloudRunV2WorkerPoolTemplateVolumesSecretItemsToHclTerraform(struct?: CloudRunV2WorkerPoolTemplateVolumesSecretItems | cdktn.IResolvable): any;
export declare class CloudRunV2WorkerPoolTemplateVolumesSecretItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2WorkerPoolTemplateVolumesSecretItems | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTemplateVolumesSecretItems | cdktn.IResolvable | undefined);
    private _mode?;
    get mode(): number;
    set mode(value: number);
    resetMode(): void;
    get modeInput(): number | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export declare class CloudRunV2WorkerPoolTemplateVolumesSecretItemsList extends cdktn.ComplexList {
    internalValue?: CloudRunV2WorkerPoolTemplateVolumesSecretItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2WorkerPoolTemplateVolumesSecretItemsOutputReference;
}
export interface CloudRunV2WorkerPoolTemplateVolumesSecret {
    /**
    * Integer representation of mode bits to use on created files by default. Must be a value between 0000 and 0777 (octal), defaulting to 0444. Directories within the path are not affected by this setting.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#default_mode CloudRunV2WorkerPool#default_mode}
    */
    readonly defaultMode?: number;
    /**
    * The name of the secret in Cloud Secret Manager. Format: {secret} if the secret is in the same project. projects/{project}/secrets/{secret} if the secret is in a different project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#secret CloudRunV2WorkerPool#secret}
    */
    readonly secret: string;
    /**
    * items block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#items CloudRunV2WorkerPool#items}
    */
    readonly items?: CloudRunV2WorkerPoolTemplateVolumesSecretItems[] | cdktn.IResolvable;
}
export declare function cloudRunV2WorkerPoolTemplateVolumesSecretToTerraform(struct?: CloudRunV2WorkerPoolTemplateVolumesSecretOutputReference | CloudRunV2WorkerPoolTemplateVolumesSecret): any;
export declare function cloudRunV2WorkerPoolTemplateVolumesSecretToHclTerraform(struct?: CloudRunV2WorkerPoolTemplateVolumesSecretOutputReference | CloudRunV2WorkerPoolTemplateVolumesSecret): any;
export declare class CloudRunV2WorkerPoolTemplateVolumesSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2WorkerPoolTemplateVolumesSecret | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTemplateVolumesSecret | undefined);
    private _defaultMode?;
    get defaultMode(): number;
    set defaultMode(value: number);
    resetDefaultMode(): void;
    get defaultModeInput(): number | undefined;
    private _secret?;
    get secret(): string;
    set secret(value: string);
    get secretInput(): string | undefined;
    private _items;
    get items(): CloudRunV2WorkerPoolTemplateVolumesSecretItemsList;
    putItems(value: CloudRunV2WorkerPoolTemplateVolumesSecretItems[] | cdktn.IResolvable): void;
    resetItems(): void;
    get itemsInput(): cdktn.IResolvable | CloudRunV2WorkerPoolTemplateVolumesSecretItems[] | undefined;
}
export interface CloudRunV2WorkerPoolTemplateVolumes {
    /**
    * Volume's name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#name CloudRunV2WorkerPool#name}
    */
    readonly name: string;
    /**
    * cloud_sql_instance block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#cloud_sql_instance CloudRunV2WorkerPool#cloud_sql_instance}
    */
    readonly cloudSqlInstance?: CloudRunV2WorkerPoolTemplateVolumesCloudSqlInstance;
    /**
    * empty_dir block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#empty_dir CloudRunV2WorkerPool#empty_dir}
    */
    readonly emptyDir?: CloudRunV2WorkerPoolTemplateVolumesEmptyDir;
    /**
    * gcs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#gcs CloudRunV2WorkerPool#gcs}
    */
    readonly gcs?: CloudRunV2WorkerPoolTemplateVolumesGcs;
    /**
    * nfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#nfs CloudRunV2WorkerPool#nfs}
    */
    readonly nfs?: CloudRunV2WorkerPoolTemplateVolumesNfs;
    /**
    * secret block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#secret CloudRunV2WorkerPool#secret}
    */
    readonly secret?: CloudRunV2WorkerPoolTemplateVolumesSecret;
}
export declare function cloudRunV2WorkerPoolTemplateVolumesToTerraform(struct?: CloudRunV2WorkerPoolTemplateVolumes | cdktn.IResolvable): any;
export declare function cloudRunV2WorkerPoolTemplateVolumesToHclTerraform(struct?: CloudRunV2WorkerPoolTemplateVolumes | cdktn.IResolvable): any;
export declare class CloudRunV2WorkerPoolTemplateVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2WorkerPoolTemplateVolumes | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTemplateVolumes | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _cloudSqlInstance;
    get cloudSqlInstance(): CloudRunV2WorkerPoolTemplateVolumesCloudSqlInstanceOutputReference;
    putCloudSqlInstance(value: CloudRunV2WorkerPoolTemplateVolumesCloudSqlInstance): void;
    resetCloudSqlInstance(): void;
    get cloudSqlInstanceInput(): CloudRunV2WorkerPoolTemplateVolumesCloudSqlInstance | undefined;
    private _emptyDir;
    get emptyDir(): CloudRunV2WorkerPoolTemplateVolumesEmptyDirOutputReference;
    putEmptyDir(value: CloudRunV2WorkerPoolTemplateVolumesEmptyDir): void;
    resetEmptyDir(): void;
    get emptyDirInput(): CloudRunV2WorkerPoolTemplateVolumesEmptyDir | undefined;
    private _gcs;
    get gcs(): CloudRunV2WorkerPoolTemplateVolumesGcsOutputReference;
    putGcs(value: CloudRunV2WorkerPoolTemplateVolumesGcs): void;
    resetGcs(): void;
    get gcsInput(): CloudRunV2WorkerPoolTemplateVolumesGcs | undefined;
    private _nfs;
    get nfs(): CloudRunV2WorkerPoolTemplateVolumesNfsOutputReference;
    putNfs(value: CloudRunV2WorkerPoolTemplateVolumesNfs): void;
    resetNfs(): void;
    get nfsInput(): CloudRunV2WorkerPoolTemplateVolumesNfs | undefined;
    private _secret;
    get secret(): CloudRunV2WorkerPoolTemplateVolumesSecretOutputReference;
    putSecret(value: CloudRunV2WorkerPoolTemplateVolumesSecret): void;
    resetSecret(): void;
    get secretInput(): CloudRunV2WorkerPoolTemplateVolumesSecret | undefined;
}
export declare class CloudRunV2WorkerPoolTemplateVolumesList extends cdktn.ComplexList {
    internalValue?: CloudRunV2WorkerPoolTemplateVolumes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2WorkerPoolTemplateVolumesOutputReference;
}
export interface CloudRunV2WorkerPoolTemplateVpcAccessNetworkInterfaces {
    /**
    * The VPC network that the Cloud Run resource will be able to send traffic to. At least one of network or subnetwork must be specified. If both
    * network and subnetwork are specified, the given VPC subnetwork must belong to the given VPC network. If network is not specified, it will be
    * looked up from the subnetwork.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#network CloudRunV2WorkerPool#network}
    */
    readonly network?: string;
    /**
    * The VPC subnetwork that the Cloud Run resource will get IPs from. At least one of network or subnetwork must be specified. If both
    * network and subnetwork are specified, the given VPC subnetwork must belong to the given VPC network. If subnetwork is not specified, the
    * subnetwork with the same name with the network will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#subnetwork CloudRunV2WorkerPool#subnetwork}
    */
    readonly subnetwork?: string;
    /**
    * Network tags applied to this Cloud Run WorkerPool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#tags CloudRunV2WorkerPool#tags}
    */
    readonly tags?: string[];
}
export declare function cloudRunV2WorkerPoolTemplateVpcAccessNetworkInterfacesToTerraform(struct?: CloudRunV2WorkerPoolTemplateVpcAccessNetworkInterfaces | cdktn.IResolvable): any;
export declare function cloudRunV2WorkerPoolTemplateVpcAccessNetworkInterfacesToHclTerraform(struct?: CloudRunV2WorkerPoolTemplateVpcAccessNetworkInterfaces | cdktn.IResolvable): any;
export declare class CloudRunV2WorkerPoolTemplateVpcAccessNetworkInterfacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudRunV2WorkerPoolTemplateVpcAccessNetworkInterfaces | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTemplateVpcAccessNetworkInterfaces | cdktn.IResolvable | undefined);
    private _network?;
    get network(): string;
    set network(value: string);
    resetNetwork(): void;
    get networkInput(): string | undefined;
    private _subnetwork?;
    get subnetwork(): string;
    set subnetwork(value: string);
    resetSubnetwork(): void;
    get subnetworkInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
}
export declare class CloudRunV2WorkerPoolTemplateVpcAccessNetworkInterfacesList extends cdktn.ComplexList {
    internalValue?: CloudRunV2WorkerPoolTemplateVpcAccessNetworkInterfaces[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudRunV2WorkerPoolTemplateVpcAccessNetworkInterfacesOutputReference;
}
export interface CloudRunV2WorkerPoolTemplateVpcAccess {
    /**
    * VPC Access connector name. Format: projects/{project}/locations/{location}/connectors/{connector}, where {project} can be project id or number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#connector CloudRunV2WorkerPool#connector}
    */
    readonly connector?: string;
    /**
    * Traffic VPC egress settings. Possible values: ["ALL_TRAFFIC", "PRIVATE_RANGES_ONLY"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#egress CloudRunV2WorkerPool#egress}
    */
    readonly egress?: string;
    /**
    * network_interfaces block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#network_interfaces CloudRunV2WorkerPool#network_interfaces}
    */
    readonly networkInterfaces?: CloudRunV2WorkerPoolTemplateVpcAccessNetworkInterfaces[] | cdktn.IResolvable;
}
export declare function cloudRunV2WorkerPoolTemplateVpcAccessToTerraform(struct?: CloudRunV2WorkerPoolTemplateVpcAccessOutputReference | CloudRunV2WorkerPoolTemplateVpcAccess): any;
export declare function cloudRunV2WorkerPoolTemplateVpcAccessToHclTerraform(struct?: CloudRunV2WorkerPoolTemplateVpcAccessOutputReference | CloudRunV2WorkerPoolTemplateVpcAccess): any;
export declare class CloudRunV2WorkerPoolTemplateVpcAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2WorkerPoolTemplateVpcAccess | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTemplateVpcAccess | undefined);
    private _connector?;
    get connector(): string;
    set connector(value: string);
    resetConnector(): void;
    get connectorInput(): string | undefined;
    private _egress?;
    get egress(): string;
    set egress(value: string);
    resetEgress(): void;
    get egressInput(): string | undefined;
    private _networkInterfaces;
    get networkInterfaces(): CloudRunV2WorkerPoolTemplateVpcAccessNetworkInterfacesList;
    putNetworkInterfaces(value: CloudRunV2WorkerPoolTemplateVpcAccessNetworkInterfaces[] | cdktn.IResolvable): void;
    resetNetworkInterfaces(): void;
    get networkInterfacesInput(): cdktn.IResolvable | CloudRunV2WorkerPoolTemplateVpcAccessNetworkInterfaces[] | undefined;
}
export interface CloudRunV2WorkerPoolTemplate {
    /**
    * Unstructured key value map that may be set by external tools to store and arbitrary metadata. They are not queryable and should be preserved when modifying objects.
    *
    * Cloud Run API v2 does not support annotations with 'run.googleapis.com', 'cloud.googleapis.com', 'serving.knative.dev', or 'autoscaling.knative.dev' namespaces, and they will be rejected.
    * All system annotations in v1 now have a corresponding field in v2 WorkerPoolRevisionTemplate.
    *
    * This field follows Kubernetes annotations' namespacing, limits, and rules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#annotations CloudRunV2WorkerPool#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Arbitrary identifier for the API client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#client CloudRunV2WorkerPool#client}
    */
    readonly client?: string;
    /**
    * Arbitrary version identifier for the API client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#client_version CloudRunV2WorkerPool#client_version}
    */
    readonly clientVersion?: string;
    /**
    * A reference to a customer managed encryption key (CMEK) to use to encrypt this container image. For more information, go to https://cloud.google.com/run/docs/securing/using-cmek
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#encryption_key CloudRunV2WorkerPool#encryption_key}
    */
    readonly encryptionKey?: string;
    /**
    * The action to take if the encryption key is revoked. Possible values: ["PREVENT_NEW", "SHUTDOWN"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#encryption_key_revocation_action CloudRunV2WorkerPool#encryption_key_revocation_action}
    */
    readonly encryptionKeyRevocationAction?: string;
    /**
    * If encryptionKeyRevocationAction is SHUTDOWN, the duration before shutting down all instances. The minimum increment is 1 hour.
    *
    * A duration in seconds with up to nine fractional digits, ending with 's'. Example: "3.5s".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#encryption_key_shutdown_duration CloudRunV2WorkerPool#encryption_key_shutdown_duration}
    */
    readonly encryptionKeyShutdownDuration?: string;
    /**
    * True if GPU zonal redundancy is disabled on this revision.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#gpu_zonal_redundancy_disabled CloudRunV2WorkerPool#gpu_zonal_redundancy_disabled}
    */
    readonly gpuZonalRedundancyDisabled?: boolean | cdktn.IResolvable;
    /**
    * Unstructured key value map that can be used to organize and categorize objects. User-provided labels are shared with Google's billing system, so they can be used to filter, or break down billing charges by team, component, environment, state, etc.
    * For more information, visit https://docs.cloud.google.com/resource-manager/docs/creating-managing-labels or https://cloud.google.com/run/docs/configuring/labels.
    *
    * Cloud Run API v2 does not support labels with 'run.googleapis.com', 'cloud.googleapis.com', 'serving.knative.dev', or 'autoscaling.knative.dev' namespaces, and they will be rejected.
    * All system labels in v1 now have a corresponding field in v2 WorkerPoolRevisionTemplate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#labels CloudRunV2WorkerPool#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The unique name for the revision. If this field is omitted, it will be automatically generated based on the WorkerPool name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#revision CloudRunV2WorkerPool#revision}
    */
    readonly revision?: string;
    /**
    * Email address of the IAM service account associated with the revision of the WorkerPool. The service account represents the identity of the running revision, and determines what permissions the revision has. If not provided, the revision will use the project's default service account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#service_account CloudRunV2WorkerPool#service_account}
    */
    readonly serviceAccount?: string;
    /**
    * containers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#containers CloudRunV2WorkerPool#containers}
    */
    readonly containers?: CloudRunV2WorkerPoolTemplateContainers[] | cdktn.IResolvable;
    /**
    * node_selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#node_selector CloudRunV2WorkerPool#node_selector}
    */
    readonly nodeSelector?: CloudRunV2WorkerPoolTemplateNodeSelector;
    /**
    * volumes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#volumes CloudRunV2WorkerPool#volumes}
    */
    readonly volumes?: CloudRunV2WorkerPoolTemplateVolumes[] | cdktn.IResolvable;
    /**
    * vpc_access block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#vpc_access CloudRunV2WorkerPool#vpc_access}
    */
    readonly vpcAccess?: CloudRunV2WorkerPoolTemplateVpcAccess;
}
export declare function cloudRunV2WorkerPoolTemplateToTerraform(struct?: CloudRunV2WorkerPoolTemplateOutputReference | CloudRunV2WorkerPoolTemplate): any;
export declare function cloudRunV2WorkerPoolTemplateToHclTerraform(struct?: CloudRunV2WorkerPoolTemplateOutputReference | CloudRunV2WorkerPoolTemplate): any;
export declare class CloudRunV2WorkerPoolTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2WorkerPoolTemplate | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTemplate | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _client?;
    get client(): string;
    set client(value: string);
    resetClient(): void;
    get clientInput(): string | undefined;
    private _clientVersion?;
    get clientVersion(): string;
    set clientVersion(value: string);
    resetClientVersion(): void;
    get clientVersionInput(): string | undefined;
    private _encryptionKey?;
    get encryptionKey(): string;
    set encryptionKey(value: string);
    resetEncryptionKey(): void;
    get encryptionKeyInput(): string | undefined;
    private _encryptionKeyRevocationAction?;
    get encryptionKeyRevocationAction(): string;
    set encryptionKeyRevocationAction(value: string);
    resetEncryptionKeyRevocationAction(): void;
    get encryptionKeyRevocationActionInput(): string | undefined;
    private _encryptionKeyShutdownDuration?;
    get encryptionKeyShutdownDuration(): string;
    set encryptionKeyShutdownDuration(value: string);
    resetEncryptionKeyShutdownDuration(): void;
    get encryptionKeyShutdownDurationInput(): string | undefined;
    private _gpuZonalRedundancyDisabled?;
    get gpuZonalRedundancyDisabled(): boolean | cdktn.IResolvable;
    set gpuZonalRedundancyDisabled(value: boolean | cdktn.IResolvable);
    resetGpuZonalRedundancyDisabled(): void;
    get gpuZonalRedundancyDisabledInput(): boolean | cdktn.IResolvable | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _revision?;
    get revision(): string;
    set revision(value: string);
    resetRevision(): void;
    get revisionInput(): string | undefined;
    private _serviceAccount?;
    get serviceAccount(): string;
    set serviceAccount(value: string);
    resetServiceAccount(): void;
    get serviceAccountInput(): string | undefined;
    private _containers;
    get containers(): CloudRunV2WorkerPoolTemplateContainersList;
    putContainers(value: CloudRunV2WorkerPoolTemplateContainers[] | cdktn.IResolvable): void;
    resetContainers(): void;
    get containersInput(): cdktn.IResolvable | CloudRunV2WorkerPoolTemplateContainers[] | undefined;
    private _nodeSelector;
    get nodeSelector(): CloudRunV2WorkerPoolTemplateNodeSelectorOutputReference;
    putNodeSelector(value: CloudRunV2WorkerPoolTemplateNodeSelector): void;
    resetNodeSelector(): void;
    get nodeSelectorInput(): CloudRunV2WorkerPoolTemplateNodeSelector | undefined;
    private _volumes;
    get volumes(): CloudRunV2WorkerPoolTemplateVolumesList;
    putVolumes(value: CloudRunV2WorkerPoolTemplateVolumes[] | cdktn.IResolvable): void;
    resetVolumes(): void;
    get volumesInput(): cdktn.IResolvable | CloudRunV2WorkerPoolTemplateVolumes[] | undefined;
    private _vpcAccess;
    get vpcAccess(): CloudRunV2WorkerPoolTemplateVpcAccessOutputReference;
    putVpcAccess(value: CloudRunV2WorkerPoolTemplateVpcAccess): void;
    resetVpcAccess(): void;
    get vpcAccessInput(): CloudRunV2WorkerPoolTemplateVpcAccess | undefined;
}
export interface CloudRunV2WorkerPoolTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#create CloudRunV2WorkerPool#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#delete CloudRunV2WorkerPool#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#update CloudRunV2WorkerPool#update}
    */
    readonly update?: string;
}
export declare function cloudRunV2WorkerPoolTimeoutsToTerraform(struct?: CloudRunV2WorkerPoolTimeouts | cdktn.IResolvable): any;
export declare function cloudRunV2WorkerPoolTimeoutsToHclTerraform(struct?: CloudRunV2WorkerPoolTimeouts | cdktn.IResolvable): any;
export declare class CloudRunV2WorkerPoolTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudRunV2WorkerPoolTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CloudRunV2WorkerPoolTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool google_cloud_run_v2_worker_pool}
*/
export declare class CloudRunV2WorkerPool extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_cloud_run_v2_worker_pool";
    /**
    * Generates CDKTN code for importing a CloudRunV2WorkerPool resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudRunV2WorkerPool to import
    * @param importFromId The id of the existing CloudRunV2WorkerPool that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudRunV2WorkerPool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/cloud_run_v2_worker_pool google_cloud_run_v2_worker_pool} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudRunV2WorkerPoolConfig
    */
    constructor(scope: Construct, id: string, config: CloudRunV2WorkerPoolConfig);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _client?;
    get client(): string;
    set client(value: string);
    resetClient(): void;
    get clientInput(): string | undefined;
    private _clientVersion?;
    get clientVersion(): string;
    set clientVersion(value: string);
    resetClientVersion(): void;
    get clientVersionInput(): string | undefined;
    private _conditions;
    get conditions(): CloudRunV2WorkerPoolConditionsList;
    get createTime(): string;
    get creator(): string;
    get deleteTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _deletionProtection?;
    get deletionProtection(): boolean | cdktn.IResolvable;
    set deletionProtection(value: boolean | cdktn.IResolvable);
    resetDeletionProtection(): void;
    get deletionProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _effectiveAnnotations;
    get effectiveAnnotations(): cdktn.StringMap;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get etag(): string;
    get expireTime(): string;
    get generation(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceSplitStatuses;
    get instanceSplitStatuses(): CloudRunV2WorkerPoolInstanceSplitStatusesList;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    get lastModifier(): string;
    get latestCreatedRevision(): string;
    get latestReadyRevision(): string;
    private _launchStage?;
    get launchStage(): string;
    set launchStage(value: string);
    resetLaunchStage(): void;
    get launchStageInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get observedGeneration(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get reconciling(): cdktn.IResolvable;
    private _terminalCondition;
    get terminalCondition(): CloudRunV2WorkerPoolTerminalConditionList;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get uid(): string;
    get updateTime(): string;
    private _binaryAuthorization;
    get binaryAuthorization(): CloudRunV2WorkerPoolBinaryAuthorizationOutputReference;
    putBinaryAuthorization(value: CloudRunV2WorkerPoolBinaryAuthorization): void;
    resetBinaryAuthorization(): void;
    get binaryAuthorizationInput(): CloudRunV2WorkerPoolBinaryAuthorization | undefined;
    private _instanceSplits;
    get instanceSplits(): CloudRunV2WorkerPoolInstanceSplitsList;
    putInstanceSplits(value: CloudRunV2WorkerPoolInstanceSplits[] | cdktn.IResolvable): void;
    resetInstanceSplits(): void;
    get instanceSplitsInput(): cdktn.IResolvable | CloudRunV2WorkerPoolInstanceSplits[] | undefined;
    private _scaling;
    get scaling(): CloudRunV2WorkerPoolScalingOutputReference;
    putScaling(value: CloudRunV2WorkerPoolScaling): void;
    resetScaling(): void;
    get scalingInput(): CloudRunV2WorkerPoolScaling | undefined;
    private _template;
    get template(): CloudRunV2WorkerPoolTemplateOutputReference;
    putTemplate(value: CloudRunV2WorkerPoolTemplate): void;
    get templateInput(): CloudRunV2WorkerPoolTemplate | undefined;
    private _timeouts;
    get timeouts(): CloudRunV2WorkerPoolTimeoutsOutputReference;
    putTimeouts(value: CloudRunV2WorkerPoolTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CloudRunV2WorkerPoolTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
