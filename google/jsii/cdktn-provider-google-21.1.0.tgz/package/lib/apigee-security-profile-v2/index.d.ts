/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigeeSecurityProfileV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_profile_v2#deletion_policy ApigeeSecurityProfileV2#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Description of the security profile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_profile_v2#description ApigeeSecurityProfileV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_profile_v2#id ApigeeSecurityProfileV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The Apigee Organization associated with the Apigee Security Profile V2,
    * in the format 'organizations/{{org_name}}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_profile_v2#org_id ApigeeSecurityProfileV2#org_id}
    */
    readonly orgId: string;
    /**
    * Resource ID of the security profile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_profile_v2#profile_id ApigeeSecurityProfileV2#profile_id}
    */
    readonly profileId: string;
    /**
    * profile_assessment_configs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_profile_v2#profile_assessment_configs ApigeeSecurityProfileV2#profile_assessment_configs}
    */
    readonly profileAssessmentConfigs: ApigeeSecurityProfileV2ProfileAssessmentConfigs[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_profile_v2#timeouts ApigeeSecurityProfileV2#timeouts}
    */
    readonly timeouts?: ApigeeSecurityProfileV2Timeouts;
}
export interface ApigeeSecurityProfileV2ProfileAssessmentConfigs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_profile_v2#assessment ApigeeSecurityProfileV2#assessment}
    */
    readonly assessment: string;
    /**
    * The weight of the assessment. Possible values: ["MINOR", "MODERATE", "MAJOR"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_profile_v2#weight ApigeeSecurityProfileV2#weight}
    */
    readonly weight: string;
}
export declare function apigeeSecurityProfileV2ProfileAssessmentConfigsToTerraform(struct?: ApigeeSecurityProfileV2ProfileAssessmentConfigs | cdktn.IResolvable): any;
export declare function apigeeSecurityProfileV2ProfileAssessmentConfigsToHclTerraform(struct?: ApigeeSecurityProfileV2ProfileAssessmentConfigs | cdktn.IResolvable): any;
export declare class ApigeeSecurityProfileV2ProfileAssessmentConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigeeSecurityProfileV2ProfileAssessmentConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeSecurityProfileV2ProfileAssessmentConfigs | cdktn.IResolvable | undefined);
    private _assessment?;
    get assessment(): string;
    set assessment(value: string);
    get assessmentInput(): string | undefined;
    private _weight?;
    get weight(): string;
    set weight(value: string);
    get weightInput(): string | undefined;
}
export declare class ApigeeSecurityProfileV2ProfileAssessmentConfigsList extends cdktn.ComplexList {
    internalValue?: ApigeeSecurityProfileV2ProfileAssessmentConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigeeSecurityProfileV2ProfileAssessmentConfigsOutputReference;
}
export interface ApigeeSecurityProfileV2Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_profile_v2#create ApigeeSecurityProfileV2#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_profile_v2#delete ApigeeSecurityProfileV2#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_profile_v2#update ApigeeSecurityProfileV2#update}
    */
    readonly update?: string;
}
export declare function apigeeSecurityProfileV2TimeoutsToTerraform(struct?: ApigeeSecurityProfileV2Timeouts | cdktn.IResolvable): any;
export declare function apigeeSecurityProfileV2TimeoutsToHclTerraform(struct?: ApigeeSecurityProfileV2Timeouts | cdktn.IResolvable): any;
export declare class ApigeeSecurityProfileV2TimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeSecurityProfileV2Timeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeSecurityProfileV2Timeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_profile_v2 google_apigee_security_profile_v2}
*/
export declare class ApigeeSecurityProfileV2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apigee_security_profile_v2";
    /**
    * Generates CDKTN code for importing a ApigeeSecurityProfileV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigeeSecurityProfileV2 to import
    * @param importFromId The id of the existing ApigeeSecurityProfileV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_profile_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigeeSecurityProfileV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_security_profile_v2 google_apigee_security_profile_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigeeSecurityProfileV2Config
    */
    constructor(scope: Construct, id: string, config: ApigeeSecurityProfileV2Config);
    get createTime(): string;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _orgId?;
    get orgId(): string;
    set orgId(value: string);
    get orgIdInput(): string | undefined;
    private _profileId?;
    get profileId(): string;
    set profileId(value: string);
    get profileIdInput(): string | undefined;
    get updateTime(): string;
    private _profileAssessmentConfigs;
    get profileAssessmentConfigs(): ApigeeSecurityProfileV2ProfileAssessmentConfigsList;
    putProfileAssessmentConfigs(value: ApigeeSecurityProfileV2ProfileAssessmentConfigs[] | cdktn.IResolvable): void;
    get profileAssessmentConfigsInput(): cdktn.IResolvable | ApigeeSecurityProfileV2ProfileAssessmentConfigs[] | undefined;
    private _timeouts;
    get timeouts(): ApigeeSecurityProfileV2TimeoutsOutputReference;
    putTimeouts(value: ApigeeSecurityProfileV2Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApigeeSecurityProfileV2Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
