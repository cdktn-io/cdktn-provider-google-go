/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigeeEnvKeystoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether Terraform will be prevented from destroying the instance. Defaults to "DELETE".
    * When a 'terraform destroy' or 'terraform apply' would delete the instance,
    * the command will fail if this field is set to "PREVENT" in Terraform state.
    * When set to "ABANDON", the command will remove the resource from Terraform
    * management without updating or deleting the resource in the API.
    * When set to "DELETE", deleting the resource is allowed.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_env_keystore#deletion_policy ApigeeEnvKeystore#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The Apigee environment group associated with the Apigee environment,
    * in the format 'organizations/{{org_name}}/environments/{{env_name}}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_env_keystore#env_id ApigeeEnvKeystore#env_id}
    */
    readonly envId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_env_keystore#id ApigeeEnvKeystore#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the newly created keystore.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_env_keystore#name ApigeeEnvKeystore#name}
    */
    readonly name: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_env_keystore#timeouts ApigeeEnvKeystore#timeouts}
    */
    readonly timeouts?: ApigeeEnvKeystoreTimeouts;
}
export interface ApigeeEnvKeystoreTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_env_keystore#create ApigeeEnvKeystore#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_env_keystore#delete ApigeeEnvKeystore#delete}
    */
    readonly delete?: string;
}
export declare function apigeeEnvKeystoreTimeoutsToTerraform(struct?: ApigeeEnvKeystoreTimeouts | cdktn.IResolvable): any;
export declare function apigeeEnvKeystoreTimeoutsToHclTerraform(struct?: ApigeeEnvKeystoreTimeouts | cdktn.IResolvable): any;
export declare class ApigeeEnvKeystoreTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigeeEnvKeystoreTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApigeeEnvKeystoreTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_env_keystore google_apigee_env_keystore}
*/
export declare class ApigeeEnvKeystore extends cdktn.TerraformResource {
    static readonly tfResourceType = "google_apigee_env_keystore";
    /**
    * Generates CDKTN code for importing a ApigeeEnvKeystore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigeeEnvKeystore to import
    * @param importFromId The id of the existing ApigeeEnvKeystore that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_env_keystore#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigeeEnvKeystore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google/8.7.0/docs/resources/apigee_env_keystore google_apigee_env_keystore} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigeeEnvKeystoreConfig
    */
    constructor(scope: Construct, id: string, config: ApigeeEnvKeystoreConfig);
    get aliases(): string[];
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _envId?;
    get envId(): string;
    set envId(value: string);
    get envIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _timeouts;
    get timeouts(): ApigeeEnvKeystoreTimeoutsOutputReference;
    putTimeouts(value: ApigeeEnvKeystoreTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApigeeEnvKeystoreTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
